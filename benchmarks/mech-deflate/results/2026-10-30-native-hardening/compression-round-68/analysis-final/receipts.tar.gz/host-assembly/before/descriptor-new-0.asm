
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102dacf14 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new>:
102dacf14:     	stp	x28, x27, [sp, #-0x60]!
102dacf18:     	stp	x26, x25, [sp, #0x10]
102dacf1c:     	stp	x24, x23, [sp, #0x20]
102dacf20:     	stp	x22, x21, [sp, #0x30]
102dacf24:     	stp	x20, x19, [sp, #0x40]
102dacf28:     	stp	x29, x30, [sp, #0x50]
102dacf2c:     	add	x29, sp, #0x50
102dacf30:     	sub	sp, sp, #0x1c0
102dacf34:     	mov	x23, x3
102dacf38:     	mov	x20, x2
102dacf3c:     	mov	x22, x1
102dacf40:     	mov	x19, x0
102dacf44:     	mov	x25, x8
102dacf48:     	mov	x26, #0x0               ; =0
102dacf4c:     	lsl	x21, x3, #3
102dacf50:     	lsr	x8, x3, #61
102dacf54:     	cbnz	x8, 0x102dacfa0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x8c>
102dacf58:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102dacf5c:     	cmp	x21, x8
102dacf60:     	b.hi	0x102dacfa0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x8c>
102dacf64:     	cbz	x21, 0x102dacfb0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x9c>
102dacf68:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102dacf6c:     	mov	w26, #0x8               ; =8
102dacf70:     	mov	x0, x21
102dacf74:     	mov	w1, #0x8                ; =8
102dacf78:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102dacf7c:     	cbz	x0, 0x102dacfa0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x8c>
102dacf80:     	mov	x24, x0
102dacf84:     	cbz	x23, 0x102dacfbc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0xa8>
102dacf88:     	mov	x0, x24
102dacf8c:     	mov	x1, x20
102dacf90:     	mov	x2, x21
102dacf94:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102dacf98:     	mov	w27, #0x0               ; =0
102dacf9c:     	b	0x102dacfc0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0xac>
102dacfa0:     	mov	x0, x26
102dacfa4:     	mov	x1, x21
102dacfa8:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102dacfac:     	brk	#0x1
102dacfb0:     	mov	w27, #0x1               ; =1
102dacfb4:     	mov	w24, #0x8               ; =8
102dacfb8:     	b	0x102dacfc0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0xac>
102dacfbc:     	mov	w27, #0x1               ; =1
102dacfc0:     	add	x8, sp, #0xd0
102dacfc4:     	mov	x0, x22
102dacfc8:     	mov	x1, x24
102dacfcc:     	mov	x2, x23
102dacfd0:     	bl	0x102dad3ec <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema25validate_shape_parameters>
102dacfd4:     	add	x28, sp, #0x70
102dacfd8:     	ldr	x26, [sp, #0xd0]
102dacfdc:     	cmp	x26, #0x1e
102dacfe0:     	b.ne	0x102dad050 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x13c>
102dacfe4:     	stp	x24, x23, [sp, #0x10]
102dacfe8:     	add	x8, sp, #0xd0
102dacfec:     	add	x1, sp, #0x10
102dacff0:     	mov	x0, x22
102dacff4:     	bl	0x102d165e8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core11type_system8resolvedNtB5_12ResolvedType11from_schema>
102dacff8:     	ldr	x8, [sp, #0xd0]
102dacffc:     	cmp	x8, #0x1
102dad000:     	b.ne	0x102dad124 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x210>
102dad004:     	ldur	q0, [x28, #0x88]
102dad008:     	ldur	q1, [x28, #0x98]
102dad00c:     	stp	q0, q1, [sp, #0x90]
102dad010:     	ldur	q2, [x28, #0xa8]
102dad014:     	str	q2, [sp, #0xb0]
102dad018:     	ldr	x8, [sp, #0x128]
102dad01c:     	str	x8, [sp, #0xc0]
102dad020:     	ldur	q3, [x28, #0x68]
102dad024:     	ldur	q4, [x28, #0x78]
102dad028:     	stp	q3, q4, [sp, #0x70]
102dad02c:     	stur	q0, [x25, #0x28]
102dad030:     	stur	q1, [x25, #0x38]
102dad034:     	stur	q2, [x25, #0x48]
102dad038:     	str	x8, [x25, #0x58]
102dad03c:     	stur	q3, [x25, #0x8]
102dad040:     	stur	q4, [x25, #0x18]
102dad044:     	mov	w8, #0x15               ; =21
102dad048:     	strb	w8, [x25]
102dad04c:     	b	0x102dad260 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x34c>
102dad050:     	str	w27, [sp, #0xc]
102dad054:     	mov	x0, x24
102dad058:     	mov	x24, x19
102dad05c:     	mov	x19, x20
102dad060:     	ldp	x27, x20, [sp, #0xd8]
102dad064:     	ldur	q0, [x28, #0x78]
102dad068:     	str	q0, [sp, #0x70]
102dad06c:     	cbz	x23, 0x102dad07c <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x168>
102dad070:     	mov	x1, x21
102dad074:     	mov	w2, #0x8                ; =8
102dad078:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad07c:     	stp	x26, x27, [x29, #-0xa0]
102dad080:     	stur	x20, [x29, #-0x90]
102dad084:     	ldr	q0, [sp, #0x70]
102dad088:     	sub	x8, x29, #0xa0
102dad08c:     	stur	q0, [x8, #0x18]
102dad090:     	add	x8, sp, #0xd0
102dad094:     	sub	x0, x29, #0xa0
102dad098:     	mov	x20, x19
102dad09c:     	mov	x19, x24
102dad0a0:     	bl	0x102d5564c <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core11type_system10diagnosticNtB5_19TypeResolutionError8semantic>
102dad0a4:     	ldr	q0, [sp, #0xd0]
102dad0a8:     	ldr	x8, [sp, #0xe0]
102dad0ac:     	ldur	q1, [x28, #0x78]
102dad0b0:     	ldur	q2, [x28, #0x88]
102dad0b4:     	stp	q1, q2, [x25, #0x20]
102dad0b8:     	ldur	q1, [x28, #0x98]
102dad0bc:     	ldur	q2, [x28, #0xa8]
102dad0c0:     	stp	q1, q2, [x25, #0x40]
102dad0c4:     	stur	q0, [x25, #0x8]
102dad0c8:     	str	x8, [x25, #0x18]
102dad0cc:     	mov	w8, #0x15               ; =21
102dad0d0:     	strb	w8, [x25]
102dad0d4:     	ldr	w8, [sp, #0xc]
102dad0d8:     	cbnz	w8, 0x102dad0ec <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x1d8>
102dad0dc:     	mov	x0, x20
102dad0e0:     	mov	x1, x21
102dad0e4:     	mov	w2, #0x8                ; =8
102dad0e8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad0ec:     	add	x0, x22, #0x40
102dad0f0:     	bl	0x102d99188 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102dad0f4:     	mov	x0, x22
102dad0f8:     	bl	0x102d996d4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema10SchemaBodyEBK_>
102dad0fc:     	mov	x0, x19
102dad100:     	bl	0x102d9a170 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dad104:     	add	sp, sp, #0x1c0
102dad108:     	ldp	x29, x30, [sp, #0x50]
102dad10c:     	ldp	x20, x19, [sp, #0x40]
102dad110:     	ldp	x22, x21, [sp, #0x30]
102dad114:     	ldp	x24, x23, [sp, #0x20]
102dad118:     	ldp	x26, x25, [sp, #0x10]
102dad11c:     	ldp	x28, x27, [sp], #0x60
102dad120:     	ret
102dad124:     	ldp	q1, q0, [sp, #0x100]
102dad128:     	stur	q0, [x28, #0x38]
102dad12c:     	ldr	q2, [sp, #0x120]
102dad130:     	stur	q2, [x28, #0x48]
102dad134:     	ldp	q3, q4, [sp, #0xe0]
102dad138:     	stp	q1, q0, [sp, #0x40]
102dad13c:     	str	q2, [sp, #0x60]
102dad140:     	stp	q3, q4, [sp, #0x20]
102dad144:     	add	x1, sp, #0x20
102dad148:     	mov	x0, x19
102dad14c:     	bl	0x102d3b4c0 <__RNvXs_NtNtCskIfnrfrMWVM_9mech_core11type_system8resolvedNtB4_12ResolvedTypeNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
102dad150:     	tbz	w0, #0x0, 0x102dad1cc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x2b8>
102dad154:     	ldp	q0, q1, [x19, #0x20]
102dad158:     	stp	q0, q1, [sp, #0xf0]
102dad15c:     	ldp	q1, q0, [x19]
102dad160:     	stp	q1, q0, [sp, #0xd0]
102dad164:     	ldp	q1, q2, [x22, #0x20]
102dad168:     	ldp	q4, q3, [x22]
102dad16c:     	stp	q3, q1, [sp, #0x130]
102dad170:     	ldr	q1, [x22, #0x40]
102dad174:     	stp	q2, q1, [sp, #0x150]
102dad178:     	ldr	q1, [x19, #0x40]
102dad17c:     	stp	q1, q4, [sp, #0x110]
102dad180:     	ldr	q1, [sp, #0xd0]
102dad184:     	stp	q1, q0, [x25]
102dad188:     	ldp	q1, q0, [sp, #0x150]
102dad18c:     	stp	q1, q0, [x25, #0x80]
102dad190:     	ldr	q0, [sp, #0x140]
102dad194:     	stp	q3, q0, [x25, #0x60]
102dad198:     	ldp	q0, q1, [sp, #0x110]
102dad19c:     	ldp	q2, q3, [sp, #0xf0]
102dad1a0:     	stp	q0, q1, [x25, #0x40]
102dad1a4:     	stp	q2, q3, [x25, #0x20]
102dad1a8:     	stp	x24, x23, [x25, #0xa0]
102dad1ac:     	add	x0, sp, #0x20
102dad1b0:     	bl	0x102d9a170 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dad1b4:     	tbnz	w27, #0x0, 0x102dad104 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x1f0>
102dad1b8:     	mov	x0, x20
102dad1bc:     	mov	x1, x21
102dad1c0:     	mov	w2, #0x8                ; =8
102dad1c4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad1c8:     	b	0x102dad104 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x1f0>
102dad1cc:     	sub	x8, x29, #0x78
102dad1d0:     	mov	x0, x19
102dad1d4:     	bl	0x102d56878 <__RNvNtNtCskIfnrfrMWVM_9mech_core11type_system10diagnostic18semantic_kind_name>
102dad1d8:     	add	x8, sp, #0xd0
102dad1dc:     	add	x0, sp, #0x20
102dad1e0:     	bl	0x102d56878 <__RNvNtNtCskIfnrfrMWVM_9mech_core11type_system10diagnostic18semantic_kind_name>
102dad1e4:     	sub	x8, x29, #0xa0
102dad1e8:     	ldur	q0, [x8, #0x28]
102dad1ec:     	stur	q0, [sp, #0x78]
102dad1f0:     	ldur	x8, [x29, #-0x68]
102dad1f4:     	str	x8, [sp, #0x88]
102dad1f8:     	ldr	q0, [sp, #0xd0]
102dad1fc:     	str	q0, [sp, #0x90]
102dad200:     	ldr	x8, [sp, #0xe0]
102dad204:     	str	x8, [sp, #0xa0]
102dad208:     	mov	w8, #0x10               ; =16
102dad20c:     	strh	w8, [sp, #0x70]
102dad210:     	adrp	x0, 0x107709000 <_anon.82b36ed75173c614d12914eaef5c5804.588+0x954>
102dad214:     	add	x0, x0, #0x6e4
102dad218:     	add	x8, sp, #0xd0
102dad21c:     	add	x2, sp, #0x70
102dad220:     	mov	w1, #0x19               ; =25
102dad224:     	bl	0x102d46768 <__RINvMs0_NtNtCskIfnrfrMWVM_9mech_core11type_system10diagnosticNtB6_19TypeResolutionError12incompatibleReEBa_>
102dad228:     	ldp	q0, q1, [sp, #0xf0]
102dad22c:     	stur	q0, [x25, #0x28]
102dad230:     	stur	q1, [x25, #0x38]
102dad234:     	ldr	q0, [sp, #0x110]
102dad238:     	stur	q0, [x25, #0x48]
102dad23c:     	ldr	x8, [sp, #0x120]
102dad240:     	str	x8, [x25, #0x58]
102dad244:     	ldp	q0, q1, [sp, #0xd0]
102dad248:     	stur	q0, [x25, #0x8]
102dad24c:     	stur	q1, [x25, #0x18]
102dad250:     	mov	w8, #0x15               ; =21
102dad254:     	strb	w8, [x25]
102dad258:     	add	x0, sp, #0x20
102dad25c:     	bl	0x102d9a170 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dad260:     	cbz	x23, 0x102dad274 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x360>
102dad264:     	mov	x0, x24
102dad268:     	mov	x1, x21
102dad26c:     	mov	w2, #0x8                ; =8
102dad270:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad274:     	tbz	w27, #0x0, 0x102dad0dc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x1c8>
102dad278:     	b	0x102dad0ec <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x1d8>
102dad27c:     	mov	x25, x0
102dad280:     	ldur	x1, [x29, #-0x78]
102dad284:     	cbz	x1, 0x102dad2bc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x3a8>
102dad288:     	ldur	x0, [x29, #-0x70]
102dad28c:     	mov	w2, #0x1                ; =1
102dad290:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad294:     	b	0x102dad2bc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x3a8>
102dad298:     	mov	x25, x0
102dad29c:     	tbnz	w27, #0x0, 0x102dad334 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x420>
102dad2a0:     	mov	x0, x20
102dad2a4:     	mov	x1, x21
102dad2a8:     	mov	w2, #0x8                ; =8
102dad2ac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad2b0:     	mov	x0, x25
102dad2b4:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102dad2b8:     	mov	x25, x0
102dad2bc:     	add	x0, sp, #0x20
102dad2c0:     	bl	0x102d9a170 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dad2c4:     	b	0x102dad2cc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x3b8>
102dad2c8:     	mov	x25, x0
102dad2cc:     	cbnz	x23, 0x102dad2f8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x3e4>
102dad2d0:     	b	0x102dad324 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x410>
102dad2d4:     	mov	x25, x0
102dad2d8:     	b	0x102dad32c <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x418>
102dad2dc:     	mov	x25, x0
102dad2e0:     	mov	x0, x22
102dad2e4:     	bl	0x102d996d4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema10SchemaBodyEBK_>
102dad2e8:     	b	0x102dad32c <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x418>
102dad2ec:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dad2f0:     	mov	x25, x0
102dad2f4:     	cbz	x23, 0x102dad324 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x410>
102dad2f8:     	mov	x0, x24
102dad2fc:     	mov	x1, x21
102dad300:     	mov	w2, #0x8                ; =8
102dad304:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad308:     	b	0x102dad314 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x400>
102dad30c:     	mov	x25, x0
102dad310:     	cbz	x23, 0x102dad324 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor3new+0x410>
102dad314:     	mov	x0, x20
102dad318:     	mov	x1, x21
102dad31c:     	mov	w2, #0x8                ; =8
102dad320:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dad324:     	mov	x0, x22
102dad328:     	bl	0x102d99c50 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102dad32c:     	mov	x0, x19
102dad330:     	bl	0x102d9a170 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dad334:     	mov	x0, x25
102dad338:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102dad33c:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
