
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027674b4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>:
1027674b4:     	sub	sp, sp, #0x120
1027674b8:     	stp	x24, x23, [sp, #0xe0]
1027674bc:     	stp	x22, x21, [sp, #0xf0]
1027674c0:     	stp	x20, x19, [sp, #0x100]
1027674c4:     	stp	x29, x30, [sp, #0x110]
1027674c8:     	add	x29, sp, #0x110
1027674cc:     	ldr	x23, [x0, #0x8]
1027674d0:     	mov	w8, #0xb0               ; =176
1027674d4:     	mul	x19, x23, x8
1027674d8:     	mov	x8, #0xba2e             ; =47662
1027674dc:     	movk	x8, #0xa2e8, lsl #16
1027674e0:     	movk	x8, #0x2e8b, lsl #32
1027674e4:     	movk	x8, #0xba, lsl #48
1027674e8:     	cmp	x23, x8
1027674ec:     	b.ls	0x102767500 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x4c>
1027674f0:     	mov	x22, #0x0               ; =0
1027674f4:     	mov	x0, x22
1027674f8:     	mov	x1, x19
1027674fc:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102767500:     	cbz	x19, 0x10276758c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0xd8>
102767504:     	ldr	x20, [x0]
102767508:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10276750c:     	mov	w22, #0x10              ; =16
102767510:     	mov	x0, x19
102767514:     	mov	w1, #0x10               ; =16
102767518:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10276751c:     	cbz	x0, 0x1027674f4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x40>
102767520:     	mov	x21, x0
102767524:     	stp	x23, x0, [sp, #0x18]
102767528:     	cbz	x23, 0x102767594 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0xe0>
10276752c:     	mov	x22, #0x0               ; =0
102767530:     	cbz	x19, 0x102767594 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0xe0>
102767534:     	add	x0, sp, #0x30
102767538:     	mov	x1, x20
10276753c:     	bl	0x10275ae14 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102767540:     	add	x22, x22, #0x1
102767544:     	add	x20, x20, #0xb0
102767548:     	ldp	q0, q1, [sp, #0xb0]
10276754c:     	stp	q0, q1, [x21, #0x80]
102767550:     	ldr	q0, [sp, #0xd0]
102767554:     	str	q0, [x21, #0xa0]
102767558:     	ldp	q0, q1, [sp, #0x70]
10276755c:     	stp	q0, q1, [x21, #0x40]
102767560:     	ldp	q1, q0, [sp, #0x90]
102767564:     	stp	q1, q0, [x21, #0x60]
102767568:     	ldp	q0, q1, [sp, #0x30]
10276756c:     	stp	q0, q1, [x21]
102767570:     	ldp	q1, q0, [sp, #0x50]
102767574:     	sub	x19, x19, #0xb0
102767578:     	stp	q1, q0, [x21, #0x20]
10276757c:     	add	x21, x21, #0xb0
102767580:     	cmp	x23, x22
102767584:     	b.ne	0x102767530 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x7c>
102767588:     	b	0x102767594 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0xe0>
10276758c:     	mov	w8, #0x10               ; =16
102767590:     	stp	xzr, x8, [sp, #0x18]
102767594:     	ldur	q0, [sp, #0x18]
102767598:     	str	q0, [sp]
10276759c:     	str	x23, [sp, #0x10]
1027675a0:     	mov	x0, sp
1027675a4:     	bl	0x1027924d8 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE16into_boxed_sliceCs1qJAwyMG1lC_11mech_engine>
1027675a8:     	ldp	x29, x30, [sp, #0x110]
1027675ac:     	ldp	x20, x19, [sp, #0x100]
1027675b0:     	ldp	x22, x21, [sp, #0xf0]
1027675b4:     	ldp	x24, x23, [sp, #0xe0]
1027675b8:     	add	sp, sp, #0x120
1027675bc:     	ret
1027675c0:     	mov	x19, x0
1027675c4:     	str	x22, [sp, #0x28]
1027675c8:     	add	x0, sp, #0x18
1027675cc:     	bl	0x102700448 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
1027675d0:     	mov	x0, x19
1027675d4:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
1027675d8:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
