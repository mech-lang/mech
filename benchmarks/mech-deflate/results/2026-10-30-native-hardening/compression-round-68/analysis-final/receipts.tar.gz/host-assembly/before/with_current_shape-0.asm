
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102dacc44 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape>:
102dacc44:     	sub	sp, sp, #0x1c0
102dacc48:     	stp	x28, x27, [sp, #0x160]
102dacc4c:     	stp	x26, x25, [sp, #0x170]
102dacc50:     	stp	x24, x23, [sp, #0x180]
102dacc54:     	stp	x22, x21, [sp, #0x190]
102dacc58:     	stp	x20, x19, [sp, #0x1a0]
102dacc5c:     	stp	x29, x30, [sp, #0x1b0]
102dacc60:     	add	x29, sp, #0x1b0
102dacc64:     	mov	x21, x2
102dacc68:     	mov	x19, x1
102dacc6c:     	mov	x23, x8
102dacc70:     	mov	x25, #0x0               ; =0
102dacc74:     	lsl	x20, x2, #3
102dacc78:     	lsr	x8, x2, #61
102dacc7c:     	cbnz	x8, 0x102dacccc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x88>
102dacc80:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102dacc84:     	cmp	x20, x8
102dacc88:     	b.hi	0x102dacccc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x88>
102dacc8c:     	mov	x24, x0
102dacc90:     	cbz	x20, 0x102daccdc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x98>
102dacc94:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102dacc98:     	mov	w25, #0x8               ; =8
102dacc9c:     	mov	x0, x20
102dacca0:     	mov	w1, #0x8                ; =8
102dacca4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102dacca8:     	cbz	x0, 0x102dacccc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x88>
102daccac:     	mov	x22, x0
102daccb0:     	cbz	x21, 0x102dacce8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0xa4>
102daccb4:     	mov	x0, x22
102daccb8:     	mov	x1, x19
102daccbc:     	mov	x2, x20
102daccc0:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102daccc4:     	mov	w27, #0x0               ; =0
102daccc8:     	b	0x102daccec <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0xa8>
102dacccc:     	mov	x0, x25
102daccd0:     	mov	x1, x20
102daccd4:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102daccd8:     	brk	#0x1
102daccdc:     	mov	w27, #0x1               ; =1
102dacce0:     	mov	w22, #0x8               ; =8
102dacce4:     	b	0x102daccec <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0xa8>
102dacce8:     	mov	w27, #0x1               ; =1
102daccec:     	mov	x8, sp
102daccf0:     	add	x0, x24, #0x50
102daccf4:     	mov	x1, x22
102daccf8:     	mov	x2, x21
102daccfc:     	bl	0x102dad3ec <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema25validate_shape_parameters>
102dacd00:     	ldr	x25, [sp]
102dacd04:     	cmp	x25, #0x1e
102dacd08:     	b.ne	0x102dacdd8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x194>
102dacd0c:     	ldp	x1, x2, [x24, #0x30]
102dacd10:     	mov	x0, sp
102dacd14:     	bl	0x102dcb540 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102dacd18:     	mov	x0, sp
102dacd1c:     	bl	0x102cd92e8 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102dacd20:     	mov	x25, x0
102dacd24:     	mov	x26, x1
102dacd28:     	stp	x0, x1, [x29, #-0x90]
102dacd2c:     	mov	x0, sp
102dacd30:     	mov	x1, x24
102dacd34:     	bl	0x102db62b4 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102dacd38:     	add	x0, x24, #0x40
102dacd3c:     	bl	0x102dd9ab8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102dacd40:     	stp	x25, x26, [sp, #0xc0]
102dacd44:     	ldp	q0, q1, [sp]
102dacd48:     	stp	q0, q1, [sp, #0x90]
102dacd4c:     	ldr	q0, [sp, #0x20]
102dacd50:     	str	q0, [sp, #0xb0]
102dacd54:     	stp	x0, x1, [sp, #0xd0]
102dacd58:     	add	x0, x24, #0x90
102dacd5c:     	bl	0x102dd8c9c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102dacd60:     	mov	x25, x0
102dacd64:     	mov	x26, x1
102dacd68:     	stp	x0, x1, [x29, #-0xa0]
102dacd6c:     	sub	x0, x29, #0x90
102dacd70:     	add	x1, x24, #0x50
102dacd74:     	bl	0x102db8e84 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102dacd78:     	ldp	q0, q1, [x29, #-0x90]
102dacd7c:     	ldp	q2, q3, [x29, #-0x70]
102dacd80:     	stp	q1, q2, [sp, #0x60]
102dacd84:     	str	q3, [sp, #0x80]
102dacd88:     	ldp	q1, q2, [sp, #0xb0]
102dacd8c:     	stp	q1, q2, [sp, #0x20]
102dacd90:     	ldr	q1, [sp, #0xd0]
102dacd94:     	stp	q1, q0, [sp, #0x40]
102dacd98:     	ldp	q1, q0, [sp, #0x90]
102dacd9c:     	stp	q1, q0, [sp]
102dacda0:     	ldp	q0, q1, [sp, #0x60]
102dacda4:     	stp	q0, q1, [x23, #0x60]
102dacda8:     	ldr	q0, [sp, #0x80]
102dacdac:     	str	q0, [x23, #0x80]
102dacdb0:     	ldp	q0, q1, [sp, #0x20]
102dacdb4:     	stp	q0, q1, [x23, #0x20]
102dacdb8:     	ldp	q1, q0, [sp, #0x40]
102dacdbc:     	stp	q1, q0, [x23, #0x40]
102dacdc0:     	ldp	q1, q0, [sp]
102dacdc4:     	stp	q1, q0, [x23]
102dacdc8:     	stp	x25, x26, [x23, #0x90]
102dacdcc:     	stp	x22, x21, [x23, #0xa0]
102dacdd0:     	tbz	w27, #0x0, 0x102dace48 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x204>
102dacdd4:     	b	0x102dace58 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x214>
102dacdd8:     	ldp	x24, x26, [sp, #0x8]
102dacddc:     	ldur	q0, [sp, #0x18]
102dacde0:     	str	q0, [sp, #0x90]
102dacde4:     	cbz	x21, 0x102dacdf8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x1b4>
102dacde8:     	mov	x0, x22
102dacdec:     	mov	x1, x20
102dacdf0:     	mov	w2, #0x8                ; =8
102dacdf4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dacdf8:     	stp	x25, x24, [x29, #-0xc8]
102dacdfc:     	stur	x26, [x29, #-0xb8]
102dace00:     	ldr	q0, [sp, #0x90]
102dace04:     	stur	q0, [x29, #-0xb0]
102dace08:     	mov	x8, sp
102dace0c:     	sub	x0, x29, #0xc8
102dace10:     	bl	0x102d5564c <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core11type_system10diagnosticNtB5_19TypeResolutionError8semantic>
102dace14:     	ldr	q0, [sp]
102dace18:     	ldr	x8, [sp, #0x10]
102dace1c:     	ldur	q1, [sp, #0x18]
102dace20:     	ldur	q2, [sp, #0x28]
102dace24:     	stp	q1, q2, [x23, #0x20]
102dace28:     	ldur	q1, [sp, #0x38]
102dace2c:     	ldur	q2, [sp, #0x48]
102dace30:     	stp	q1, q2, [x23, #0x40]
102dace34:     	stur	q0, [x23, #0x8]
102dace38:     	str	x8, [x23, #0x18]
102dace3c:     	mov	w8, #0x15               ; =21
102dace40:     	strb	w8, [x23]
102dace44:     	tbnz	w27, #0x0, 0x102dace58 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x214>
102dace48:     	mov	x0, x19
102dace4c:     	mov	x1, x20
102dace50:     	mov	w2, #0x8                ; =8
102dace54:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dace58:     	ldp	x29, x30, [sp, #0x1b0]
102dace5c:     	ldp	x20, x19, [sp, #0x1a0]
102dace60:     	ldp	x22, x21, [sp, #0x190]
102dace64:     	ldp	x24, x23, [sp, #0x180]
102dace68:     	ldp	x26, x25, [sp, #0x170]
102dace6c:     	ldp	x28, x27, [sp, #0x160]
102dace70:     	add	sp, sp, #0x1c0
102dace74:     	ret
102dace78:     	mov	x23, x0
102dace7c:     	sub	x0, x29, #0xa0
102dace80:     	bl	0x102d99188 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102dace84:     	b	0x102dace90 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x24c>
102dace88:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dace8c:     	mov	x23, x0
102dace90:     	add	x0, sp, #0x90
102dace94:     	bl	0x102d9a170 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dace98:     	b	0x102dacec8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x284>
102dace9c:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dacea0:     	mov	x23, x0
102dacea4:     	mov	x0, sp
102dacea8:     	bl	0x102d99d08 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102daceac:     	b	0x102daceb4 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x270>
102daceb0:     	mov	x23, x0
102daceb4:     	sub	x0, x29, #0x90
102daceb8:     	bl	0x102d9928c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102dacebc:     	b	0x102dacec8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x284>
102dacec0:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dacec4:     	mov	x23, x0
102dacec8:     	cbnz	x21, 0x102dacedc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x298>
102dacecc:     	mov	x0, x23
102daced0:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102daced4:     	mov	x23, x0
102daced8:     	cbz	x21, 0x102dacecc <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x288>
102dacedc:     	mov	x0, x22
102dacee0:     	mov	x1, x20
102dacee4:     	mov	w2, #0x8                ; =8
102dacee8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102daceec:     	mov	x0, x23
102dacef0:     	b	0x102dacef8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x2b4>
102dacef4:     	cbz	x21, 0x102dacf10 <__RNvMNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB2_23ResolvedValueDescriptor18with_current_shape+0x2cc>
102dacef8:     	mov	x21, x0
102dacefc:     	mov	x0, x19
102dacf00:     	mov	x1, x20
102dacf04:     	mov	w2, #0x8                ; =8
102dacf08:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102dacf0c:     	mov	x0, x21
102dacf10:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
