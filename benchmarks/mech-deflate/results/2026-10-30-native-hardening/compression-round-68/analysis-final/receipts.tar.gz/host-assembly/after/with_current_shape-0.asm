
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e30dc4 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape>:
102e30dc4:     	sub	sp, sp, #0xf0
102e30dc8:     	stp	x28, x27, [sp, #0x90]
102e30dcc:     	stp	x26, x25, [sp, #0xa0]
102e30dd0:     	stp	x24, x23, [sp, #0xb0]
102e30dd4:     	stp	x22, x21, [sp, #0xc0]
102e30dd8:     	stp	x20, x19, [sp, #0xd0]
102e30ddc:     	stp	x29, x30, [sp, #0xe0]
102e30de0:     	add	x29, sp, #0xe0
102e30de4:     	mov	x21, x2
102e30de8:     	mov	x19, x1
102e30dec:     	mov	x22, x8
102e30df0:     	mov	x24, #0x0               ; =0
102e30df4:     	lsl	x20, x2, #3
102e30df8:     	lsr	x8, x2, #61
102e30dfc:     	cbnz	x8, 0x102e30e4c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x88>
102e30e00:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102e30e04:     	cmp	x20, x8
102e30e08:     	b.hi	0x102e30e4c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x88>
102e30e0c:     	ldr	x25, [x0]
102e30e10:     	cbz	x20, 0x102e30e5c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x98>
102e30e14:     	bl	0x100023aa4 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e30e18:     	mov	w24, #0x8               ; =8
102e30e1c:     	mov	x0, x20
102e30e20:     	mov	w1, #0x8                ; =8
102e30e24:     	bl	0x1000094b0 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e30e28:     	cbz	x0, 0x102e30e4c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x88>
102e30e2c:     	mov	x23, x0
102e30e30:     	cbz	x21, 0x102e30e68 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0xa4>
102e30e34:     	mov	x0, x23
102e30e38:     	mov	x1, x19
102e30e3c:     	mov	x2, x20
102e30e40:     	bl	0x103a078cc <dyld_stub_binder+0x103a078cc>
102e30e44:     	mov	w24, #0x0               ; =0
102e30e48:     	b	0x102e30e6c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0xa8>
102e30e4c:     	mov	x0, x24
102e30e50:     	mov	x1, x20
102e30e54:     	bl	0x103a060c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102e30e58:     	b	0x102e30f44 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x180>
102e30e5c:     	mov	w24, #0x1               ; =1
102e30e60:     	mov	w23, #0x8               ; =8
102e30e64:     	b	0x102e30e6c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0xa8>
102e30e68:     	mov	w24, #0x1               ; =1
102e30e6c:     	add	x8, sp, #0x38
102e30e70:     	add	x0, x25, #0x60
102e30e74:     	mov	x1, x23
102e30e78:     	mov	x2, x21
102e30e7c:     	bl	0x102e2fc90 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema25validate_shape_parameters>
102e30e80:     	ldr	x26, [sp, #0x38]
102e30e84:     	cmp	x26, #0x1e
102e30e88:     	b.ne	0x102e30eac <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0xe8>
102e30e8c:     	mov	w8, #0x1                ; =1
102e30e90:     	ldadd	x8, x8, [x25]
102e30e94:     	tbnz	x8, #0x3f, 0x102e30f44 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x180>
102e30e98:     	stp	x23, x21, [x22, #0x10]
102e30e9c:     	mov	w8, #0x2                ; =2
102e30ea0:     	stp	x8, x25, [x22]
102e30ea4:     	tbz	w24, #0x0, 0x102e30f14 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x150>
102e30ea8:     	b	0x102e30f24 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x160>
102e30eac:     	ldp	x25, x27, [sp, #0x40]
102e30eb0:     	ldur	q0, [sp, #0x50]
102e30eb4:     	str	q0, [sp]
102e30eb8:     	cbz	x21, 0x102e30ecc <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x108>
102e30ebc:     	mov	x0, x23
102e30ec0:     	mov	x1, x20
102e30ec4:     	mov	w2, #0x8                ; =8
102e30ec8:     	bl	0x1000094c8 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102e30ecc:     	stp	x26, x25, [sp, #0x10]
102e30ed0:     	str	x27, [sp, #0x20]
102e30ed4:     	ldr	q0, [sp]
102e30ed8:     	stur	q0, [sp, #0x28]
102e30edc:     	add	x8, sp, #0x38
102e30ee0:     	add	x0, sp, #0x10
102e30ee4:     	bl	0x102d8817c <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core11type_system10diagnosticNtB5_19TypeResolutionError8semantic>
102e30ee8:     	ldur	q0, [sp, #0x38]
102e30eec:     	ldr	x8, [sp, #0x48]
102e30ef0:     	ldp	q2, q1, [sp, #0x50]
102e30ef4:     	stur	q2, [x22, #0x18]
102e30ef8:     	stur	q1, [x22, #0x28]
102e30efc:     	ldp	q2, q1, [sp, #0x70]
102e30f00:     	stur	q2, [x22, #0x38]
102e30f04:     	stur	q1, [x22, #0x48]
102e30f08:     	str	q0, [x22]
102e30f0c:     	str	x8, [x22, #0x10]
102e30f10:     	tbnz	w24, #0x0, 0x102e30f24 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x160>
102e30f14:     	mov	x0, x19
102e30f18:     	mov	x1, x20
102e30f1c:     	mov	w2, #0x8                ; =8
102e30f20:     	bl	0x1000094c8 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102e30f24:     	ldp	x29, x30, [sp, #0xe0]
102e30f28:     	ldp	x20, x19, [sp, #0xd0]
102e30f2c:     	ldp	x22, x21, [sp, #0xc0]
102e30f30:     	ldp	x24, x23, [sp, #0xb0]
102e30f34:     	ldp	x26, x25, [sp, #0xa0]
102e30f38:     	ldp	x28, x27, [sp, #0x90]
102e30f3c:     	add	sp, sp, #0xf0
102e30f40:     	ret
102e30f44:     	brk	#0x1
102e30f48:     	mov	x22, x0
102e30f4c:     	cbnz	x21, 0x102e30f58 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x194>
102e30f50:     	mov	x0, x22
102e30f54:     	bl	0x103a076e0 <dyld_stub_binder+0x103a076e0>
102e30f58:     	mov	x0, x23
102e30f5c:     	mov	x1, x20
102e30f60:     	mov	w2, #0x8                ; =8
102e30f64:     	bl	0x1000094c8 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102e30f68:     	mov	x0, x22
102e30f6c:     	b	0x102e30f74 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x1b0>
102e30f70:     	cbz	x21, 0x102e30f8c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB4_23ResolvedValueDescriptor18with_current_shape+0x1c8>
102e30f74:     	mov	x21, x0
102e30f78:     	mov	x0, x19
102e30f7c:     	mov	x1, x20
102e30f80:     	mov	w2, #0x8                ; =8
102e30f84:     	bl	0x1000094c8 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102e30f88:     	mov	x0, x21
102e30f8c:     	bl	0x103a076e0 <dyld_stub_binder+0x103a076e0>
