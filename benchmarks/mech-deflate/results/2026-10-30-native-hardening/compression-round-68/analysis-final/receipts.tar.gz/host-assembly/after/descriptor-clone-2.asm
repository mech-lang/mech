
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d9ff24 <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d9ff24:     	sub	sp, sp, #0x60
102d9ff28:     	stp	x26, x25, [sp, #0x10]
102d9ff2c:     	stp	x24, x23, [sp, #0x20]
102d9ff30:     	stp	x22, x21, [sp, #0x30]
102d9ff34:     	stp	x20, x19, [sp, #0x40]
102d9ff38:     	stp	x29, x30, [sp, #0x50]
102d9ff3c:     	add	x29, sp, #0x50
102d9ff40:     	ldr	x23, [x1]
102d9ff44:     	mov	w8, #0x1                ; =1
102d9ff48:     	ldadd	x8, x8, [x23]
102d9ff4c:     	tbnz	x8, #0x3f, 0x102d9ff80 <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x5c>
102d9ff50:     	str	x23, [sp, #0x8]
102d9ff54:     	ldr	x24, [x1, #0x10]
102d9ff58:     	lsl	x19, x24, #3
102d9ff5c:     	lsr	x8, x24, #61
102d9ff60:     	cmp	x8, #0x0
102d9ff64:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102d9ff68:     	ccmp	x19, x8, #0x2, eq
102d9ff6c:     	b.ls	0x102d9ff84 <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x60>
102d9ff70:     	mov	x22, #0x0               ; =0
102d9ff74:     	mov	x0, x22
102d9ff78:     	mov	x1, x19
102d9ff7c:     	bl	0x103a060c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d9ff80:     	brk	#0x1
102d9ff84:     	cbz	x19, 0x102d9ffc8 <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa4>
102d9ff88:     	mov	x25, x0
102d9ff8c:     	ldr	x21, [x1, #0x8]
102d9ff90:     	bl	0x100023aa4 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d9ff94:     	mov	w22, #0x8               ; =8
102d9ff98:     	mov	x0, x19
102d9ff9c:     	mov	w1, #0x8                ; =8
102d9ffa0:     	bl	0x1000094b0 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d9ffa4:     	cbz	x0, 0x102d9ff74 <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x50>
102d9ffa8:     	mov	x20, x0
102d9ffac:     	cbz	x24, 0x102d9ffc0 <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9c>
102d9ffb0:     	mov	x0, x20
102d9ffb4:     	mov	x1, x21
102d9ffb8:     	mov	x2, x19
102d9ffbc:     	bl	0x103a078cc <dyld_stub_binder+0x103a078cc>
102d9ffc0:     	mov	x0, x25
102d9ffc4:     	b	0x102d9ffcc <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa8>
102d9ffc8:     	mov	w20, #0x8               ; =8
102d9ffcc:     	stp	x23, x20, [x0]
102d9ffd0:     	str	x24, [x0, #0x10]
102d9ffd4:     	ldp	x29, x30, [sp, #0x50]
102d9ffd8:     	ldp	x20, x19, [sp, #0x40]
102d9ffdc:     	ldp	x22, x21, [sp, #0x30]
102d9ffe0:     	ldp	x24, x23, [sp, #0x20]
102d9ffe4:     	ldp	x26, x25, [sp, #0x10]
102d9ffe8:     	add	sp, sp, #0x60
102d9ffec:     	ret
102d9fff0:     	mov	x8, #-0x1               ; =-1
102d9fff4:     	ldaddl	x8, x8, [x23]
102d9fff8:     	cmp	x8, #0x1
102d9fffc:     	b.ne	0x102da0014 <__RNvXs5_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xf0>
102da0000:     	dmb	ishld
102da0004:     	mov	x19, x0
102da0008:     	add	x0, sp, #0x8
102da000c:     	bl	0x102d4efbc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value22ResolvedValueSemanticsE9drop_slowBM_>
102da0010:     	mov	x0, x19
102da0014:     	bl	0x103a076e0 <dyld_stub_binder+0x103a076e0>
102da0018:     	bl	0x103a062fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
