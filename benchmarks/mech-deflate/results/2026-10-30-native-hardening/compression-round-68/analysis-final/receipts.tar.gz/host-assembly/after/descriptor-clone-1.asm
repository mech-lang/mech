
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d2a78c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>:
102d2a78c:     	sub	sp, sp, #0x90
102d2a790:     	stp	x28, x27, [sp, #0x30]
102d2a794:     	stp	x26, x25, [sp, #0x40]
102d2a798:     	stp	x24, x23, [sp, #0x50]
102d2a79c:     	stp	x22, x21, [sp, #0x60]
102d2a7a0:     	stp	x20, x19, [sp, #0x70]
102d2a7a4:     	stp	x29, x30, [sp, #0x80]
102d2a7a8:     	add	x29, sp, #0x80
102d2a7ac:     	ldr	x24, [x0, #0x8]
102d2a7b0:     	add	x8, x24, x24, lsl #1
102d2a7b4:     	lsl	x19, x8, #3
102d2a7b8:     	mov	x8, #0x5555555555555555 ; =6148914691236517205
102d2a7bc:     	movk	x8, #0x555, lsl #48
102d2a7c0:     	cmp	x24, x8
102d2a7c4:     	b.ls	0x102d2a7d8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x4c>
102d2a7c8:     	mov	x20, #0x0               ; =0
102d2a7cc:     	mov	x0, x20
102d2a7d0:     	mov	x1, x19
102d2a7d4:     	bl	0x103a060c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d2a7d8:     	cbz	x19, 0x102d2a8b0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x124>
102d2a7dc:     	ldr	x22, [x0]
102d2a7e0:     	bl	0x100023aa4 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d2a7e4:     	mov	w20, #0x8               ; =8
102d2a7e8:     	mov	x0, x19
102d2a7ec:     	mov	w1, #0x8                ; =8
102d2a7f0:     	bl	0x1000094b0 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d2a7f4:     	cbz	x0, 0x102d2a7cc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x40>
102d2a7f8:     	stp	x24, x0, [sp, #0x18]
102d2a7fc:     	str	xzr, [sp, #0x28]
102d2a800:     	cbz	x24, 0x102d2a8b8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x12c>
102d2a804:     	mov	x25, #0x0               ; =0
102d2a808:     	add	x26, x0, #0x10
102d2a80c:     	mov	w9, #0x1                ; =1
102d2a810:     	mov	x10, #0x7ffffffffffffff8 ; =9223372036854775800
102d2a814:     	cbz	x19, 0x102d2a8b8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x12c>
102d2a818:     	mov	x28, x22
102d2a81c:     	ldr	x27, [x28], #0x18
102d2a820:     	ldadd	x9, x8, [x27]
102d2a824:     	tbnz	x8, #0x3f, 0x102d2a8f4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x168>
102d2a828:     	str	x27, [sp]
102d2a82c:     	ldr	x20, [x22, #0x10]
102d2a830:     	lsl	x21, x20, #3
102d2a834:     	lsr	x8, x20, #61
102d2a838:     	cmp	x8, #0x0
102d2a83c:     	ccmp	x21, x10, #0x2, eq
102d2a840:     	b.hi	0x102d2a8ec <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x160>
102d2a844:     	cbz	x21, 0x102d2a888 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0xfc>
102d2a848:     	ldr	x23, [x22, #0x8]
102d2a84c:     	bl	0x100023aa4 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d2a850:     	mov	x0, x21
102d2a854:     	mov	w1, #0x8                ; =8
102d2a858:     	bl	0x1000094b0 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d2a85c:     	cbz	x0, 0x102d2a8f8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x16c>
102d2a860:     	mov	x22, x0
102d2a864:     	cbz	x20, 0x102d2a878 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0xec>
102d2a868:     	mov	x0, x22
102d2a86c:     	mov	x1, x23
102d2a870:     	mov	x2, x21
102d2a874:     	bl	0x103a078cc <dyld_stub_binder+0x103a078cc>
102d2a878:     	mov	x1, x22
102d2a87c:     	mov	w9, #0x1                ; =1
102d2a880:     	mov	x10, #0x7ffffffffffffff8 ; =9223372036854775800
102d2a884:     	b	0x102d2a890 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x104>
102d2a888:     	mov	w1, #0x8                ; =8
102d2a88c:     	mov	w22, #0x8               ; =8
102d2a890:     	add	x25, x25, #0x1
102d2a894:     	stp	x27, x22, [x26, #-0x10]
102d2a898:     	str	x20, [x26], #0x18
102d2a89c:     	sub	x19, x19, #0x18
102d2a8a0:     	mov	x22, x28
102d2a8a4:     	cmp	x24, x25
102d2a8a8:     	b.ne	0x102d2a814 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x88>
102d2a8ac:     	b	0x102d2a8b8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x12c>
102d2a8b0:     	mov	w8, #0x8                ; =8
102d2a8b4:     	stp	xzr, x8, [sp, #0x18]
102d2a8b8:     	ldur	q0, [sp, #0x18]
102d2a8bc:     	str	q0, [sp]
102d2a8c0:     	str	x24, [sp, #0x10]
102d2a8c4:     	mov	x0, sp
102d2a8c8:     	bl	0x102cdd848 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE16into_boxed_sliceBK_>
102d2a8cc:     	ldp	x29, x30, [sp, #0x80]
102d2a8d0:     	ldp	x20, x19, [sp, #0x70]
102d2a8d4:     	ldp	x22, x21, [sp, #0x60]
102d2a8d8:     	ldp	x24, x23, [sp, #0x50]
102d2a8dc:     	ldp	x26, x25, [sp, #0x40]
102d2a8e0:     	ldp	x28, x27, [sp, #0x30]
102d2a8e4:     	add	sp, sp, #0x90
102d2a8e8:     	ret
102d2a8ec:     	mov	x0, #0x0                ; =0
102d2a8f0:     	bl	0x103a060c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d2a8f4:     	brk	#0x1
102d2a8f8:     	mov	x1, x21
102d2a8fc:     	mov	w0, #0x8                ; =8
102d2a900:     	b	0x102d2a8f0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x164>
102d2a904:     	mov	x19, x0
102d2a908:     	mov	x8, #-0x1               ; =-1
102d2a90c:     	ldaddl	x8, x8, [x27]
102d2a910:     	cmp	x8, #0x1
102d2a914:     	b.ne	0x102d2a924 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x198>
102d2a918:     	dmb	ishld
102d2a91c:     	mov	x0, sp
102d2a920:     	bl	0x102d4efbc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value22ResolvedValueSemanticsE9drop_slowBM_>
102d2a924:     	str	x25, [sp, #0x28]
102d2a928:     	add	x0, sp, #0x18
102d2a92c:     	bl	0x102d0d0e4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1j_>
102d2a930:     	mov	x0, x19
102d2a934:     	bl	0x103a076e0 <dyld_stub_binder+0x103a076e0>
102d2a938:     	bl	0x103a062fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d2a93c:     	bl	0x103a062fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
