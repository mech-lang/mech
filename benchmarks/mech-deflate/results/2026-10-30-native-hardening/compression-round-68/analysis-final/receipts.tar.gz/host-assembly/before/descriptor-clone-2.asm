
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d79c64 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d79c64:     	sub	sp, sp, #0x130
102d79c68:     	stp	x28, x27, [sp, #0xe0]
102d79c6c:     	stp	x24, x23, [sp, #0xf0]
102d79c70:     	stp	x22, x21, [sp, #0x100]
102d79c74:     	stp	x20, x19, [sp, #0x110]
102d79c78:     	stp	x29, x30, [sp, #0x120]
102d79c7c:     	add	x29, sp, #0x120
102d79c80:     	mov	x20, x1
102d79c84:     	mov	x19, x0
102d79c88:     	ldr	x1, [x1, #0x30]
102d79c8c:     	ldr	x2, [x20, #0x38]
102d79c90:     	add	x0, sp, #0x50
102d79c94:     	bl	0x102dcb540 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102d79c98:     	add	x0, sp, #0x50
102d79c9c:     	bl	0x102cd92e8 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102d79ca0:     	mov	x22, x0
102d79ca4:     	mov	x21, x1
102d79ca8:     	add	x0, sp, #0x50
102d79cac:     	mov	x1, x20
102d79cb0:     	bl	0x102d78434 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d79cb4:     	add	x0, x20, #0x40
102d79cb8:     	bl	0x102dd9ab8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d79cbc:     	stp	x22, x21, [sp, #0x30]
102d79cc0:     	ldp	q0, q1, [sp, #0x50]
102d79cc4:     	stp	q0, q1, [sp]
102d79cc8:     	ldr	q0, [sp, #0x70]
102d79ccc:     	str	q0, [sp, #0x20]
102d79cd0:     	stp	x0, x1, [sp, #0x40]
102d79cd4:     	add	x0, x20, #0x90
102d79cd8:     	bl	0x102dd8c9c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102d79cdc:     	mov	x23, x0
102d79ce0:     	mov	x21, x1
102d79ce4:     	sub	x0, x29, #0x80
102d79ce8:     	add	x1, x20, #0x50
102d79cec:     	bl	0x102d7a794 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d79cf0:     	mov	x22, #0x0               ; =0
102d79cf4:     	stp	x23, x21, [sp, #0x90]
102d79cf8:     	ldp	q0, q1, [x29, #-0x80]
102d79cfc:     	stp	q0, q1, [sp, #0x50]
102d79d00:     	ldp	q0, q1, [x29, #-0x60]
102d79d04:     	ldr	x24, [x20, #0xa8]
102d79d08:     	lsl	x21, x24, #3
102d79d0c:     	lsr	x8, x24, #61
102d79d10:     	stp	q0, q1, [sp, #0x70]
102d79d14:     	cbnz	x8, 0x102d79d60 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102d79d18:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102d79d1c:     	cmp	x21, x8
102d79d20:     	b.hi	0x102d79d60 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102d79d24:     	cbz	x21, 0x102d79d70 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102d79d28:     	ldr	x23, [x20, #0xa0]
102d79d2c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d79d30:     	mov	w22, #0x8               ; =8
102d79d34:     	mov	x0, x21
102d79d38:     	mov	w1, #0x8                ; =8
102d79d3c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d79d40:     	cbz	x0, 0x102d79d60 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102d79d44:     	mov	x20, x0
102d79d48:     	cbz	x24, 0x102d79d74 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102d79d4c:     	mov	x0, x20
102d79d50:     	mov	x1, x23
102d79d54:     	mov	x2, x21
102d79d58:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d79d5c:     	b	0x102d79d74 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102d79d60:     	mov	x0, x22
102d79d64:     	mov	x1, x21
102d79d68:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d79d6c:     	brk	#0x1
102d79d70:     	mov	w20, #0x8               ; =8
102d79d74:     	ldp	q0, q1, [sp, #0x20]
102d79d78:     	stp	q0, q1, [x19, #0x20]
102d79d7c:     	ldp	q1, q0, [sp]
102d79d80:     	stp	q1, q0, [x19]
102d79d84:     	ldp	q0, q1, [sp, #0x70]
102d79d88:     	ldp	q3, q2, [sp, #0x50]
102d79d8c:     	stp	q2, q0, [x19, #0x60]
102d79d90:     	ldr	q0, [sp, #0x90]
102d79d94:     	stp	q1, q0, [x19, #0x80]
102d79d98:     	ldr	q0, [sp, #0x40]
102d79d9c:     	stp	q0, q3, [x19, #0x40]
102d79da0:     	stp	x20, x24, [x19, #0xa0]
102d79da4:     	ldp	x29, x30, [sp, #0x120]
102d79da8:     	ldp	x20, x19, [sp, #0x110]
102d79dac:     	ldp	x22, x21, [sp, #0x100]
102d79db0:     	ldp	x24, x23, [sp, #0xf0]
102d79db4:     	ldp	x28, x27, [sp, #0xe0]
102d79db8:     	add	sp, sp, #0x130
102d79dbc:     	ret
102d79dc0:     	mov	x19, x0
102d79dc4:     	mov	x0, x23
102d79dc8:     	mov	x1, x21
102d79dcc:     	bl	0x102d5df04 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102d79dd0:     	b	0x102d79e14 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102d79dd4:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d79dd8:     	mov	x19, x0
102d79ddc:     	b	0x102d79e14 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102d79de0:     	mov	x19, x0
102d79de4:     	add	x0, sp, #0x50
102d79de8:     	bl	0x102d5f04c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102d79dec:     	b	0x102d79df4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x190>
102d79df0:     	mov	x19, x0
102d79df4:     	mov	x0, x22
102d79df8:     	mov	x1, x21
102d79dfc:     	bl	0x102d5dff4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102d79e00:     	b	0x102d79e1c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102d79e04:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d79e08:     	mov	x19, x0
102d79e0c:     	add	x0, sp, #0x50
102d79e10:     	bl	0x102d5edec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102d79e14:     	mov	x0, sp
102d79e18:     	bl	0x102d5f7b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102d79e1c:     	mov	x0, x19
102d79e20:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102d79e24:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
