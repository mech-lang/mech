
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102dd7844 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102dd7844:     	sub	sp, sp, #0x130
102dd7848:     	stp	x28, x27, [sp, #0xe0]
102dd784c:     	stp	x24, x23, [sp, #0xf0]
102dd7850:     	stp	x22, x21, [sp, #0x100]
102dd7854:     	stp	x20, x19, [sp, #0x110]
102dd7858:     	stp	x29, x30, [sp, #0x120]
102dd785c:     	add	x29, sp, #0x120
102dd7860:     	mov	x20, x1
102dd7864:     	mov	x19, x0
102dd7868:     	ldr	x1, [x1, #0x30]
102dd786c:     	ldr	x2, [x20, #0x38]
102dd7870:     	add	x0, sp, #0x50
102dd7874:     	bl	0x102dcb540 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102dd7878:     	add	x0, sp, #0x50
102dd787c:     	bl	0x102cd92e8 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102dd7880:     	mov	x22, x0
102dd7884:     	mov	x21, x1
102dd7888:     	add	x0, sp, #0x50
102dd788c:     	mov	x1, x20
102dd7890:     	bl	0x102dd53dc <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102dd7894:     	add	x0, x20, #0x40
102dd7898:     	bl	0x102dd9ab8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102dd789c:     	stp	x22, x21, [sp, #0x30]
102dd78a0:     	ldp	q0, q1, [sp, #0x50]
102dd78a4:     	stp	q0, q1, [sp]
102dd78a8:     	ldr	q0, [sp, #0x70]
102dd78ac:     	str	q0, [sp, #0x20]
102dd78b0:     	stp	x0, x1, [sp, #0x40]
102dd78b4:     	add	x0, x20, #0x90
102dd78b8:     	bl	0x102dd8c9c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102dd78bc:     	mov	x23, x0
102dd78c0:     	mov	x21, x1
102dd78c4:     	sub	x0, x29, #0x80
102dd78c8:     	add	x1, x20, #0x50
102dd78cc:     	bl	0x102ddc4b4 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102dd78d0:     	mov	x22, #0x0               ; =0
102dd78d4:     	stp	x23, x21, [sp, #0x90]
102dd78d8:     	ldp	q0, q1, [x29, #-0x80]
102dd78dc:     	stp	q0, q1, [sp, #0x50]
102dd78e0:     	ldp	q0, q1, [x29, #-0x60]
102dd78e4:     	ldr	x24, [x20, #0xa8]
102dd78e8:     	lsl	x21, x24, #3
102dd78ec:     	lsr	x8, x24, #61
102dd78f0:     	stp	q0, q1, [sp, #0x70]
102dd78f4:     	cbnz	x8, 0x102dd7940 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102dd78f8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102dd78fc:     	cmp	x21, x8
102dd7900:     	b.hi	0x102dd7940 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102dd7904:     	cbz	x21, 0x102dd7950 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102dd7908:     	ldr	x23, [x20, #0xa0]
102dd790c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102dd7910:     	mov	w22, #0x8               ; =8
102dd7914:     	mov	x0, x21
102dd7918:     	mov	w1, #0x8                ; =8
102dd791c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102dd7920:     	cbz	x0, 0x102dd7940 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102dd7924:     	mov	x20, x0
102dd7928:     	cbz	x24, 0x102dd7954 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102dd792c:     	mov	x0, x20
102dd7930:     	mov	x1, x23
102dd7934:     	mov	x2, x21
102dd7938:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102dd793c:     	b	0x102dd7954 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102dd7940:     	mov	x0, x22
102dd7944:     	mov	x1, x21
102dd7948:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102dd794c:     	brk	#0x1
102dd7950:     	mov	w20, #0x8               ; =8
102dd7954:     	ldp	q0, q1, [sp, #0x20]
102dd7958:     	stp	q0, q1, [x19, #0x20]
102dd795c:     	ldp	q1, q0, [sp]
102dd7960:     	stp	q1, q0, [x19]
102dd7964:     	ldp	q0, q1, [sp, #0x70]
102dd7968:     	ldp	q3, q2, [sp, #0x50]
102dd796c:     	stp	q2, q0, [x19, #0x60]
102dd7970:     	ldr	q0, [sp, #0x90]
102dd7974:     	stp	q1, q0, [x19, #0x80]
102dd7978:     	ldr	q0, [sp, #0x40]
102dd797c:     	stp	q0, q3, [x19, #0x40]
102dd7980:     	stp	x20, x24, [x19, #0xa0]
102dd7984:     	ldp	x29, x30, [sp, #0x120]
102dd7988:     	ldp	x20, x19, [sp, #0x110]
102dd798c:     	ldp	x22, x21, [sp, #0x100]
102dd7990:     	ldp	x24, x23, [sp, #0xf0]
102dd7994:     	ldp	x28, x27, [sp, #0xe0]
102dd7998:     	add	sp, sp, #0x130
102dd799c:     	ret
102dd79a0:     	mov	x19, x0
102dd79a4:     	mov	x0, x23
102dd79a8:     	mov	x1, x21
102dd79ac:     	bl	0x102dbcbb8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102dd79b0:     	b	0x102dd79f4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102dd79b4:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dd79b8:     	mov	x19, x0
102dd79bc:     	b	0x102dd79f4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102dd79c0:     	mov	x19, x0
102dd79c4:     	add	x0, sp, #0x50
102dd79c8:     	bl	0x102dbe584 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102dd79cc:     	b	0x102dd79d4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x190>
102dd79d0:     	mov	x19, x0
102dd79d4:     	mov	x0, x22
102dd79d8:     	mov	x1, x21
102dd79dc:     	bl	0x102dbcca8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102dd79e0:     	b	0x102dd79fc <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102dd79e4:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dd79e8:     	mov	x19, x0
102dd79ec:     	add	x0, sp, #0x50
102dd79f0:     	bl	0x102dbe2b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102dd79f4:     	mov	x0, sp
102dd79f8:     	bl	0x102dbed18 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dd79fc:     	mov	x0, x19
102dd7a00:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102dd7a04:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
