
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102dd97f8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>:
102dd97f8:     	sub	sp, sp, #0x120
102dd97fc:     	stp	x24, x23, [sp, #0xe0]
102dd9800:     	stp	x22, x21, [sp, #0xf0]
102dd9804:     	stp	x20, x19, [sp, #0x100]
102dd9808:     	stp	x29, x30, [sp, #0x110]
102dd980c:     	add	x29, sp, #0x110
102dd9810:     	ldr	x23, [x0, #0x8]
102dd9814:     	mov	w8, #0xb0               ; =176
102dd9818:     	mul	x19, x23, x8
102dd981c:     	mov	x8, #0xba2e             ; =47662
102dd9820:     	movk	x8, #0xa2e8, lsl #16
102dd9824:     	movk	x8, #0x2e8b, lsl #32
102dd9828:     	movk	x8, #0xba, lsl #48
102dd982c:     	cmp	x23, x8
102dd9830:     	b.ls	0x102dd9844 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x4c>
102dd9834:     	mov	x22, #0x0               ; =0
102dd9838:     	mov	x0, x22
102dd983c:     	mov	x1, x19
102dd9840:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102dd9844:     	cbz	x19, 0x102dd98d0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0xd8>
102dd9848:     	ldr	x20, [x0]
102dd984c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102dd9850:     	mov	w22, #0x10              ; =16
102dd9854:     	mov	x0, x19
102dd9858:     	mov	w1, #0x10               ; =16
102dd985c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102dd9860:     	cbz	x0, 0x102dd9838 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x40>
102dd9864:     	mov	x21, x0
102dd9868:     	stp	x23, x0, [sp, #0x18]
102dd986c:     	cbz	x23, 0x102dd98d8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0xe0>
102dd9870:     	mov	x22, #0x0               ; =0
102dd9874:     	cbz	x19, 0x102dd98d8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0xe0>
102dd9878:     	add	x0, sp, #0x30
102dd987c:     	mov	x1, x20
102dd9880:     	bl	0x102dd7844 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102dd9884:     	add	x22, x22, #0x1
102dd9888:     	add	x20, x20, #0xb0
102dd988c:     	ldp	q0, q1, [sp, #0xb0]
102dd9890:     	stp	q0, q1, [x21, #0x80]
102dd9894:     	ldr	q0, [sp, #0xd0]
102dd9898:     	str	q0, [x21, #0xa0]
102dd989c:     	ldp	q0, q1, [sp, #0x70]
102dd98a0:     	stp	q0, q1, [x21, #0x40]
102dd98a4:     	ldp	q1, q0, [sp, #0x90]
102dd98a8:     	stp	q1, q0, [x21, #0x60]
102dd98ac:     	ldp	q0, q1, [sp, #0x30]
102dd98b0:     	stp	q0, q1, [x21]
102dd98b4:     	ldp	q1, q0, [sp, #0x50]
102dd98b8:     	sub	x19, x19, #0xb0
102dd98bc:     	stp	q1, q0, [x21, #0x20]
102dd98c0:     	add	x21, x21, #0xb0
102dd98c4:     	cmp	x23, x22
102dd98c8:     	b.ne	0x102dd9874 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0x7c>
102dd98cc:     	b	0x102dd98d8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_+0xe0>
102dd98d0:     	mov	w8, #0x10               ; =16
102dd98d4:     	stp	xzr, x8, [sp, #0x18]
102dd98d8:     	ldur	q0, [sp, #0x18]
102dd98dc:     	str	q0, [sp]
102dd98e0:     	str	x23, [sp, #0x10]
102dd98e4:     	mov	x0, sp
102dd98e8:     	bl	0x102cd9ba4 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE16into_boxed_sliceBK_>
102dd98ec:     	ldp	x29, x30, [sp, #0x110]
102dd98f0:     	ldp	x20, x19, [sp, #0x100]
102dd98f4:     	ldp	x22, x21, [sp, #0xf0]
102dd98f8:     	ldp	x24, x23, [sp, #0xe0]
102dd98fc:     	add	sp, sp, #0x120
102dd9900:     	ret
102dd9904:     	mov	x19, x0
102dd9908:     	str	x22, [sp, #0x28]
102dd990c:     	add	x0, sp, #0x18
102dd9910:     	bl	0x102dbb5dc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1j_>
102dd9914:     	mov	x0, x19
102dd9918:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102dd991c:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
