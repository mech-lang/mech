
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d962c8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d962c8:     	sub	sp, sp, #0x140
102d962cc:     	stp	x28, x27, [sp, #0xf0]
102d962d0:     	stp	x24, x23, [sp, #0x100]
102d962d4:     	stp	x22, x21, [sp, #0x110]
102d962d8:     	stp	x20, x19, [sp, #0x120]
102d962dc:     	stp	x29, x30, [sp, #0x130]
102d962e0:     	add	x29, sp, #0x130
102d962e4:     	mov	x20, x1
102d962e8:     	mov	x19, x0
102d962ec:     	ldr	x1, [x1, #0x30]
102d962f0:     	ldr	x2, [x20, #0x38]
102d962f4:     	add	x0, sp, #0x50
102d962f8:     	bl	0x102dcb540 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102d962fc:     	add	x0, sp, #0x50
102d96300:     	bl	0x102cd92e8 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102d96304:     	mov	x21, x0
102d96308:     	mov	x22, x1
102d9630c:     	stp	x0, x1, [x29, #-0x80]
102d96310:     	add	x0, sp, #0x50
102d96314:     	mov	x1, x20
102d96318:     	bl	0x102d91670 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d9631c:     	add	x0, x20, #0x40
102d96320:     	bl	0x102dd9ab8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d96324:     	stp	x21, x22, [sp, #0x30]
102d96328:     	ldp	q0, q1, [sp, #0x50]
102d9632c:     	stp	q0, q1, [sp]
102d96330:     	ldr	q0, [sp, #0x70]
102d96334:     	str	q0, [sp, #0x20]
102d96338:     	stp	x0, x1, [sp, #0x40]
102d9633c:     	add	x0, x20, #0x90
102d96340:     	bl	0x102dd8c9c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102d96344:     	mov	x21, x0
102d96348:     	mov	x23, x1
102d9634c:     	stp	x0, x1, [x29, #-0x90]
102d96350:     	sub	x0, x29, #0x80
102d96354:     	add	x1, x20, #0x50
102d96358:     	bl	0x102d98664 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d9635c:     	mov	x22, #0x0               ; =0
102d96360:     	stp	x21, x23, [sp, #0x90]
102d96364:     	ldp	q0, q1, [x29, #-0x80]
102d96368:     	stp	q0, q1, [sp, #0x50]
102d9636c:     	ldp	q0, q1, [x29, #-0x60]
102d96370:     	ldr	x24, [x20, #0xa8]
102d96374:     	lsl	x21, x24, #3
102d96378:     	lsr	x8, x24, #61
102d9637c:     	stp	q0, q1, [sp, #0x70]
102d96380:     	cbnz	x8, 0x102d963cc <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102d96384:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102d96388:     	cmp	x21, x8
102d9638c:     	b.hi	0x102d963cc <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102d96390:     	cbz	x21, 0x102d963dc <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x114>
102d96394:     	ldr	x23, [x20, #0xa0]
102d96398:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d9639c:     	mov	w22, #0x8               ; =8
102d963a0:     	mov	x0, x21
102d963a4:     	mov	w1, #0x8                ; =8
102d963a8:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d963ac:     	cbz	x0, 0x102d963cc <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102d963b0:     	mov	x20, x0
102d963b4:     	cbz	x24, 0x102d963e0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x118>
102d963b8:     	mov	x0, x20
102d963bc:     	mov	x1, x23
102d963c0:     	mov	x2, x21
102d963c4:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d963c8:     	b	0x102d963e0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x118>
102d963cc:     	mov	x0, x22
102d963d0:     	mov	x1, x21
102d963d4:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d963d8:     	brk	#0x1
102d963dc:     	mov	w20, #0x8               ; =8
102d963e0:     	ldp	q0, q1, [sp, #0x20]
102d963e4:     	stp	q0, q1, [x19, #0x20]
102d963e8:     	ldp	q1, q0, [sp]
102d963ec:     	stp	q1, q0, [x19]
102d963f0:     	ldp	q0, q1, [sp, #0x70]
102d963f4:     	ldp	q3, q2, [sp, #0x50]
102d963f8:     	stp	q2, q0, [x19, #0x60]
102d963fc:     	ldr	q0, [sp, #0x90]
102d96400:     	stp	q1, q0, [x19, #0x80]
102d96404:     	ldr	q0, [sp, #0x40]
102d96408:     	stp	q0, q3, [x19, #0x40]
102d9640c:     	stp	x20, x24, [x19, #0xa0]
102d96410:     	ldp	x29, x30, [sp, #0x130]
102d96414:     	ldp	x20, x19, [sp, #0x120]
102d96418:     	ldp	x22, x21, [sp, #0x110]
102d9641c:     	ldp	x24, x23, [sp, #0x100]
102d96420:     	ldp	x28, x27, [sp, #0xf0]
102d96424:     	add	sp, sp, #0x140
102d96428:     	ret
102d9642c:     	mov	x19, x0
102d96430:     	sub	x0, x29, #0x90
102d96434:     	bl	0x102d7f35c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102d96438:     	b	0x102d96478 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102d9643c:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d96440:     	mov	x19, x0
102d96444:     	b	0x102d96478 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102d96448:     	mov	x19, x0
102d9644c:     	add	x0, sp, #0x50
102d96450:     	bl	0x102d80790 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102d96454:     	b	0x102d9645c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
102d96458:     	mov	x19, x0
102d9645c:     	sub	x0, x29, #0x80
102d96460:     	bl	0x102d7f44c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102d96464:     	b	0x102d96480 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102d96468:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d9646c:     	mov	x19, x0
102d96470:     	add	x0, sp, #0x50
102d96474:     	bl	0x102d80534 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102d96478:     	mov	x0, sp
102d9647c:     	bl	0x102d81624 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102d96480:     	mov	x0, x19
102d96484:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102d96488:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
