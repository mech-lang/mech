
/private/tmp/mech-shared-descriptor-round68-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102809378 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>:
102809378:     	sub	sp, sp, #0x90
10280937c:     	stp	x28, x27, [sp, #0x30]
102809380:     	stp	x26, x25, [sp, #0x40]
102809384:     	stp	x24, x23, [sp, #0x50]
102809388:     	stp	x22, x21, [sp, #0x60]
10280938c:     	stp	x20, x19, [sp, #0x70]
102809390:     	stp	x29, x30, [sp, #0x80]
102809394:     	add	x29, sp, #0x80
102809398:     	ldr	x24, [x0, #0x8]
10280939c:     	add	x8, x24, x24, lsl #1
1028093a0:     	lsl	x19, x8, #3
1028093a4:     	mov	x8, #0x5555555555555555 ; =6148914691236517205
1028093a8:     	movk	x8, #0x555, lsl #48
1028093ac:     	cmp	x24, x8
1028093b0:     	b.ls	0x1028093c4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x4c>
1028093b4:     	mov	x20, #0x0               ; =0
1028093b8:     	mov	x0, x20
1028093bc:     	mov	x1, x19
1028093c0:     	bl	0x103a060c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028093c4:     	cbz	x19, 0x10280949c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x124>
1028093c8:     	ldr	x22, [x0]
1028093cc:     	bl	0x100023aa4 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028093d0:     	mov	w20, #0x8               ; =8
1028093d4:     	mov	x0, x19
1028093d8:     	mov	w1, #0x8                ; =8
1028093dc:     	bl	0x1000094b0 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028093e0:     	cbz	x0, 0x1028093b8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x40>
1028093e4:     	stp	x24, x0, [sp, #0x18]
1028093e8:     	str	xzr, [sp, #0x28]
1028093ec:     	cbz	x24, 0x1028094a4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x12c>
1028093f0:     	mov	x25, #0x0               ; =0
1028093f4:     	add	x26, x0, #0x10
1028093f8:     	mov	w9, #0x1                ; =1
1028093fc:     	mov	x10, #0x7ffffffffffffff8 ; =9223372036854775800
102809400:     	cbz	x19, 0x1028094a4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x12c>
102809404:     	mov	x28, x22
102809408:     	ldr	x27, [x28], #0x18
10280940c:     	ldadd	x9, x8, [x27]
102809410:     	tbnz	x8, #0x3f, 0x1028094e0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x168>
102809414:     	str	x27, [sp]
102809418:     	ldr	x20, [x22, #0x10]
10280941c:     	lsl	x21, x20, #3
102809420:     	lsr	x8, x20, #61
102809424:     	cmp	x8, #0x0
102809428:     	ccmp	x21, x10, #0x2, eq
10280942c:     	b.hi	0x1028094d8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x160>
102809430:     	cbz	x21, 0x102809474 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0xfc>
102809434:     	ldr	x23, [x22, #0x8]
102809438:     	bl	0x100023aa4 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10280943c:     	mov	x0, x21
102809440:     	mov	w1, #0x8                ; =8
102809444:     	bl	0x1000094b0 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102809448:     	cbz	x0, 0x1028094e4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x16c>
10280944c:     	mov	x22, x0
102809450:     	cbz	x20, 0x102809464 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0xec>
102809454:     	mov	x0, x22
102809458:     	mov	x1, x23
10280945c:     	mov	x2, x21
102809460:     	bl	0x103a078cc <dyld_stub_binder+0x103a078cc>
102809464:     	mov	x1, x22
102809468:     	mov	w9, #0x1                ; =1
10280946c:     	mov	x10, #0x7ffffffffffffff8 ; =9223372036854775800
102809470:     	b	0x10280947c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x104>
102809474:     	mov	w1, #0x8                ; =8
102809478:     	mov	w22, #0x8               ; =8
10280947c:     	add	x25, x25, #0x1
102809480:     	stp	x27, x22, [x26, #-0x10]
102809484:     	str	x20, [x26], #0x18
102809488:     	sub	x19, x19, #0x18
10280948c:     	mov	x22, x28
102809490:     	cmp	x24, x25
102809494:     	b.ne	0x102809400 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x88>
102809498:     	b	0x1028094a4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x12c>
10280949c:     	mov	w8, #0x8                ; =8
1028094a0:     	stp	xzr, x8, [sp, #0x18]
1028094a4:     	ldur	q0, [sp, #0x18]
1028094a8:     	str	q0, [sp]
1028094ac:     	str	x24, [sp, #0x10]
1028094b0:     	mov	x0, sp
1028094b4:     	bl	0x10289b5ac <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE16into_boxed_sliceCs1qJAwyMG1lC_11mech_engine>
1028094b8:     	ldp	x29, x30, [sp, #0x80]
1028094bc:     	ldp	x20, x19, [sp, #0x70]
1028094c0:     	ldp	x22, x21, [sp, #0x60]
1028094c4:     	ldp	x24, x23, [sp, #0x50]
1028094c8:     	ldp	x26, x25, [sp, #0x40]
1028094cc:     	ldp	x28, x27, [sp, #0x30]
1028094d0:     	add	sp, sp, #0x90
1028094d4:     	ret
1028094d8:     	mov	x0, #0x0                ; =0
1028094dc:     	bl	0x103a060c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028094e0:     	brk	#0x1
1028094e4:     	mov	x1, x21
1028094e8:     	mov	w0, #0x8                ; =8
1028094ec:     	b	0x1028094dc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x164>
1028094f0:     	mov	x19, x0
1028094f4:     	mov	x8, #-0x1               ; =-1
1028094f8:     	ldaddl	x8, x8, [x27]
1028094fc:     	cmp	x8, #0x1
102809500:     	b.ne	0x102809510 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine+0x198>
102809504:     	dmb	ishld
102809508:     	mov	x0, sp
10280950c:     	bl	0x102d4efbc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value22ResolvedValueSemanticsE9drop_slowBM_>
102809510:     	str	x25, [sp, #0x28]
102809514:     	add	x0, sp, #0x18
102809518:     	bl	0x10279d918 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
10280951c:     	mov	x0, x19
102809520:     	bl	0x103a076e0 <dyld_stub_binder+0x103a076e0>
102809524:     	bl	0x103a062fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102809528:     	bl	0x103a062fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
