"""Qualify only the two repaired source-contract guards; keep baseline evidence."""
from pathlib import Path
import json,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];assert phase in ['focused','complete'];p=r/('source-contracts-'+phase);p.mkdir();results=[]
planner='scripts.tests.test_check_memory_planner.MemoryPlannerCheckerTests.';runtime='scripts.tests.test_check_memory_runtime.MemoryRuntimeCheckerTests.'
cases=[planner+name for name in ['test_00_repository_fixture_passes','test_24_turn_budget_recheck_fails','test_shared_turn_derivation_cannot_drop_the_current_budget','test_single_call_projection_cannot_replace_the_current_limits','test_each_turn_projection_must_reach_the_shared_derivation']]+[runtime+name for name in ['test_00_repository_fixture_passes','test_00b_receipt_cache_must_live_on_the_shared_data_owner','test_00c_receipt_cache_must_not_be_an_independent_value_field','test_00d_receipt_lookup_must_use_the_actual_owner_cache','test_00e_each_finalizer_must_initialize_a_fresh_owner_cache','test_receipt_cache_must_use_the_current_schema_and_shape_prefix','test_receipt_cache_hit_cannot_ignore_the_prefix','test_receipt_cache_miss_cannot_return_the_stale_token']]
commands=[('planner',['python3','scripts/check-memory-planner.py'],None),('runtime',['python3','scripts/check-memory-runtime.py'],None)] if phase=='focused' else []
commands += [('mutations',['python3','-B','-m','unittest',*(cases if phase=='focused' else ['scripts.tests.test_check_memory_planner','scripts.tests.test_check_memory_runtime']),'-v'],13 if phase=='focused' else 212)]
for name,command,expected in commands:
 at=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'scope':'Source-contract guard repair only. No compiler artifact or compressor source changes. Baseline failures are preserved separately.'}
 if expected is not None:
  match=re.search(r'Ran (\d+) tests? in',q.stderr);row.update(expected_tests=expected,executed_tests=int(match[1]) if match else None)
 (p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');results.append(row);(p/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'source-contracts-'+phase+'-'+name,str(p),str(r/'source-contracts.py')],check=True)
 print(phase,name,q.returncode,row.get('executed_tests'),flush=True)
 if q.returncode:print(q.stdout[-3500:]+q.stderr[-5000:],flush=True)
 q.check_returncode()
 if expected is not None:assert row['executed_tests']==expected,row
