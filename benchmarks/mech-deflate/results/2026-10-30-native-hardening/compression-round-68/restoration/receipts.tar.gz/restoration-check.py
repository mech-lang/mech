"""Qualify the restored accepted source and retained independent regressions."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time,statistics
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'restoration';p.mkdir();base='5dff1496b523749e5f10f5085e2206be0c930a7e';production='src/core/src/type_system/resolved_value.rs'
assert (w/production).read_bytes()==subprocess.check_output(['git','show',base+':'+production],cwd=w)
changed=subprocess.check_output(['git','diff','--name-only',base,'--','src','hosts/gpu/src'],cwd=w,text=True).splitlines();assert changed==['src/core/src/type_system/resolved_value_witness_tests.rs'],changed
core_before=json.loads((r/'core-before/build.json').read_text());unit_path='src/core/src/type_system/resolved_value_witness_tests.rs';assert hashlib.sha256((w/unit_path).read_bytes()).hexdigest()==core_before['source_sha256'][unit_path];assert hashlib.sha256((w/production).read_bytes()).hexdigest()==core_before['source_sha256'][production]
results=[]
def run(name,command,expected=None,environment=None):
 start=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**(environment or {})},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'exit':q.returncode,'seconds':time.monotonic()-start,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'scope':'Restored exact R67 production source; no rejected representation is used. Retained baseline libraries are pinned separately, not relabeled as a newly rebuilt head.'}
 if expected is not None:
  row['expected_tests']=expected
  if name.endswith('inventory'):row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;observed=row['executed_tests']
 (p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');results.append(row)
 if q.returncode:print(q.stdout[-3000:]+q.stderr[-5000:],flush=True)
 q.check_returncode()
 if expected is not None:assert observed==expected,row
 print(name,q.returncode,row.get('executed_tests',row.get('listed_tests')),flush=True);return q
old=json.loads((r/'allocation-before/build.json').read_text());command=old['command'].copy();command[-1]=str(p/'tests');run('allocation-build',command,environment=old['environment']);run('allocation-inventory',[command[-1],'--list'],4);run('allocation',[command[-1],'--nocapture','--test-threads=1'],4)
workflow=(w/'.github/workflows/ci-full.yml').read_text();guard=next(x.strip() for x in workflow.splitlines() if '$CONSTRUCTOR_TESTS' in x and 'test "' in x);assert guard.endswith('-eq 4');listing=(p/'allocation-inventory.stdout').read_text();run('constructor-ci',['bash','--noprofile','--norc','-euo','pipefail','-c',guard],environment={'CONSTRUCTOR_TESTS':listing})
worker=r/'linked-primary/before/worker';binding=json.loads((worker.parent/'binding.json').read_text());assert hashlib.sha256(worker.read_bytes()).hexdigest()==binding['worker_sha256'];q=run('compression',[str(worker),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','32'])
rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];assert len(rows)==34 and all(x['exact_reference'] and x['independent_inflation'] and x['work']==60260219686 and x['capacity']==13 for x in rows);assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n');measured=[x for x in rows if not x['warmup'] and not x['profile']];assert len(measured)==32
# These scans follow restoration and occur outside all timing/counter intervals.
for script in ['check-type-system.py','check-semantic-type-authority.py','check-type-memory-boundary.py','check-memory-planner.py','check-memory-runtime.py']:run(script,['python3','scripts/'+script])
result={'status':'passed','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'baseline_checkpoint':base,'production_source_equal_to_baseline':True,'only_rust_difference':changed,'retained_new_core_tests_match_successful_parent_execution':True,'parent_core_receipt':'core-before/selected.json','parent_core_executed_tests':369,'current_allocation_tests':4,'current_constructor_ci_guard':4,'compiler_source_of_confirmation_binary':binding['compiler_source'],'confirmation_observations':32,'confirmation_median_seconds':statistics.median(x['seconds'] for x in measured),'confirmation_scope':'Unpaired restoration confirmation only, excluded from R68 primary or improvement claims. Retained accepted executable/libraries, exact production-source equality, raw bytes/inflate/work/capacity/aliases/cleanup checked.','checks':results}
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n');subprocess.run(['python3',str(r/'archive.py'),'restoration',*map(str,[x for x in p.iterdir() if x.is_file() and x.name!='tests']),str(r/'restoration-check.py'),str(r/'restoration-scope.json')],check=True);(p/'tests').unlink();print('RESTORATION_PASS',result['confirmation_median_seconds'],flush=True)
