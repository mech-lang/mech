"""Execute the maintained constructor list/count guard with the actual fresh inventory."""
from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');workflow=(w/'.github/workflows/ci-full.yml').read_text();guard=next(line.strip() for line in workflow.splitlines() if '$CONSTRUCTOR_TESTS' in line and 'test "' in line);assert guard.endswith('-eq 5');listing=(r/'allocation-after/inventory.stdout').read_text();rows=[]
for name,line,expected in [('old',guard.replace('-eq 5','-eq 4'),1),('current',guard,0)]:
 command=['bash','--noprofile','--norc','-euo','pipefail','-c',line];q=subprocess.run(command,cwd=w,env={**os.environ,'CONSTRUCTOR_TESTS':listing},capture_output=True,text=True);rows.append({'name':name,'command':command,'exit':q.returncode,'expected_exit':expected,'expected_negative_control':bool(expected),'inventory_receipt':'allocation-after/inventory.stdout'});assert q.returncode==expected
(r/'constructor-ci.json').write_text(json.dumps({'command':['python3',str(r/'constructor-ci.py')],'exit':0,'actual_listed_tests':5,'checks':rows,'scope':'New fifth regression is included in the strict maintained count/run step. The old four-count guard rejects this expanded inventory; updated five-count guard passes. Actual Rust execution is separately retained in allocation-after/complete.json.'},indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'constructor-ci',str(r/'constructor-ci.json'),str(r/'constructor-ci.py')],check=True)
print('CONSTRUCTOR_CI_GUARD',[(x['name'],x['exit']) for x in rows],flush=True)
