"""Compile and execute the new allocation witness against exact baseline/candidate Core."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-borrowed-turn-source-round67-20261031');phase=sys.argv[1];assert phase in ['before','after'];p=r/('allocation-'+phase);p.mkdir()
libs=json.loads(((old if phase=='before' else r)/'final-libraries.json').read_text());pin=libs['mech_core'];assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256'];dep=(old if phase=='before' else r)/'variants/after/dependency'
base=json.loads(Path('/private/tmp/mech-allocation-sites-round54-20261031/allocation-after/build.json').read_text());cmd=base['command'].copy();cmd[-1]=str(p/'tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  name,path=a.split('=',1);target=Path(pin['path']) if name=='mech_core' else dep/Path(path).name;assert target.exists(),target;cmd[i]=name+'='+str(target)
for i in range(len(cmd)-1,0,-1):
 if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
cmd[1:1]=['-L','dependency='+str(dep)]
name='prepared_descriptor_clones_have_no_schema_size_or_repetition_allocation_slope'
selections=[('build',cmd,None,0),('inventory',[cmd[-1],'--list'],5,0),('descriptor',[cmd[-1],name,'--exact','--nocapture','--test-threads=1'],1,101 if phase=='before' else 0)]
if phase=='after':selections += [('complete',[cmd[-1],'--nocapture','--test-threads=1'],5,0)]
for label,command,count,expected_exit in selections:
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':base['environment'],'exit':q.returncode,'expected_exit':expected_exit,'seconds':time.monotonic()-at,'core_library':pin,'test_source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'test_source_sha256':hashlib.sha256((w/'src/core/tests/composite_constructor_allocation.rs').read_bytes()).hexdigest(),'scope':'Same current test against exact baseline or candidate Core library. All actual production code is in the pinned library; uncommitted source is never linked. System allocator is a diagnostic witness, excluded from primary timing.'}
 if count is not None:
  row['expected_tests']=count
  if label=='inventory':row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout);assert m,q.stdout;row.update(passed_tests=int(m[1]),failed_tests=int(m[2]),executed_tests=int(m[1])+int(m[2]));observed=row['executed_tests']
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'allocation-'+phase+'-'+label,*map(str,[p/(label+'.'+ext) for ext in ['json','stdout','stderr']]),str(r/'allocation-test.py'),str(r/'configuration.json'),str(r/'allocation-target.json')],check=True)
 print(phase,label,q.returncode,row.get('executed_tests',row.get('listed_tests')),flush=True)
 assert q.returncode==expected_exit,row
 if count is not None:assert observed==count,row
 if expected_exit:assert row['failed_tests']==1 and 'a closed descriptor clone must retain semantic authority' in q.stderr;print(q.stderr,flush=True)
