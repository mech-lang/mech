from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');d=r/'engine-unit';d.mkdir()
b=json.loads(Path('/private/tmp/mech-ownership-round29-20261029/engine-after/build.json').read_text());c=b['command'][:]
c[c.index('-C')+1]='opt-level=1';c[c.index('-o')+1]=str(d/'engine-tests')
libs=json.loads(Path('/private/tmp/mech-work-charge-inline-round34-20261030/libraries.json').read_text())
assert {c[i+1] for i,x in enumerate(c) if x=='--cfg'}=={'feature="'+f+'"' for f in libs['mech_engine']['features']}
for i,x in enumerate(c):
 if '=' in x and x.split('=',1)[0] in libs:c[i]=x.split('=',1)[0]+'='+libs[x.split('=',1)[0]]['path']
 for_check=c[i]
 if i>0 and c[i-1]=='--extern':assert Path(for_check.split('=',1)[1]).is_file(),for_check
environment={'CARGO_MANIFEST_DIR':str(w/'src/engine'),'CARGO_PKG_NAME':'mech-engine','CARGO_PKG_VERSION':'0.3.5'}
start=time.monotonic();p=subprocess.run(c,cwd=w,env={**os.environ,**environment},capture_output=True,text=True);(d/'build.stdout').write_text(p.stdout);(d/'build.stderr').write_text(p.stderr)
m={'command':c,'exit':p.returncode,'seconds':time.monotonic()-start,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'environment':environment,'scope':'Actual maintained Engine unit root; same 178 selected-operation features, opt1, warnings as errors','libraries':{name:data for name,data in libs.items() if name in {'mech_core','mech_syntax','serde','serde_json'}},'dependency_note':'Upstream unchanged libraries frozen by hash; this unit root compiles current Engine source directly, not an Engine rlib'}
if p.returncode==0:m['binary_sha256']=hashlib.sha256((d/'engine-tests').read_bytes()).hexdigest()
(d/'build.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({k:v for k,v in m.items() if k not in {'command','libraries'}},indent=2),p.stderr[-3500:],flush=True);p.check_returncode()
