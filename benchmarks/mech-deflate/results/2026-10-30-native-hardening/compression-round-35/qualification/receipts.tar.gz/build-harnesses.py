from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-work-charge-inline-round34-20261030')
libs=json.loads((r/'libraries.json').read_text());base=json.loads((old/'workers/after-build.json').read_text())
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for folder,label,source in [('workers','after',r/'workers/session.rs'),('primary','current',Path('/private/tmp/mech-timing-round.rs'))]:
 d=r/folder;d.mkdir(exist_ok=True);assert not (d/label).exists();c=base['command'][:]
 for i,x in enumerate(c):
  if '=' in x and x.split('=',1)[0] in libs:c[i]=x.split('=',1)[0]+'='+libs[x.split('=',1)[0]]['path']
 c[-3:]=[str(source),'-o',str(d/label)]
 started=time.monotonic();p=subprocess.run(c,cwd=w,capture_output=True,text=True);(d/(label+'-build.log')).write_text(p.stdout+p.stderr)
 m={'command':c,'exit':p.returncode,'seconds':time.monotonic()-started,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'source_sha256':digest(source),'libraries':libs}
 if p.returncode==0:m['binary_sha256']=digest(d/label)
 (d/(label+'-build.json')).write_text(json.dumps(m,indent=2)+'\n');p.check_returncode();print(folder,label,m['binary_sha256'],flush=True)
rows=[json.loads(line) for line in (r/'release.log').read_text().splitlines() if line.startswith('{')]
row=next(row for row in rows if row.get('reason')=='compiler-artifact' and row['target']['name']=='native_frame_transport')
frame_after=Path(row['executable']);frame_before=old/'primary/frame-after'
for label,source in [('before',frame_before),('after',frame_after)]:
 target=r/'primary'/('frame-'+label);shutil.copy2(source,target)
 (r/'primary'/('frame-'+label+'.json')).write_text(json.dumps({'path':str(source),'sha256':digest(target),'head':base['head'] if label=='before' else m['head']},indent=2)+'\n')
