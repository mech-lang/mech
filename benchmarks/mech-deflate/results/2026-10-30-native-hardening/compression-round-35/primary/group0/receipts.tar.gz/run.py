from pathlib import Path
import datetime, hashlib, json, math, os, select, statistics, subprocess, tarfile, time

root = Path(__file__).resolve().parent
workspace = Path('/private/tmp/mech-deflate-linear-stack')
packet = workspace/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-35/primary'
artifact = Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(artifact) == 'a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
assert digest(artifact.with_suffix('.mec')) == '331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=workspace,text=True).strip()
active = subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines()
assert not [s for s in active if Path(s.strip()).name in {'rustc','cargo','gpu-unit-tests','nested-component-tests','artifact_review','native_frame_transport','before','after','current','roc-profile'}]
for label in ['before','after']:
    metadata=json.loads((root/(label+'-build.json')).read_text())
    assert digest(root/label) == metadata['binary_sha256']
    assert digest(root/'session.rs') == metadata['source_sha256']

def archive(stage, files, receipt):
    destination=packet/stage
    destination.mkdir(parents=True)
    files=sorted(set(files))
    with tarfile.open(destination/'receipts.tar.gz','w:gz') as output:
        for f in files:
            output.add(f,arcname=str(f.relative_to(root)),recursive=False)
    receipt['files']=[{'path':str(f.relative_to(root)),'sha256':digest(f),'bytes':f.stat().st_size} for f in files]
    (destination/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
    subprocess.run(['git','add',str(destination)],cwd=workspace,check=True)
    subprocess.run(['git','commit','-m','Record native library-debit inline primary '+stage+' observations immediately'],cwd=workspace,check=True)

reference=Path('/private/tmp/mech-deflate-profiling-20261028/roc-profile')
assert digest(reference)=='3941ef59b2c9343d0493cc6b6d14ca4803e6bd27acfe520b1fb59d9b63026324'
command=[str(reference),'12']
with (root/'reference.stdout').open('wb') as out,(root/'reference.stderr').open('wb') as err:
    ref_result=subprocess.run(command,stdout=out,stderr=err,timeout=60)
raw=(root/'reference.stdout').read_text()
reference_rows=[l.split('\t') for l in raw.splitlines() if l.startswith('rep\troc-deflate\t')]
assert ref_result.returncode==0 and len(reference_rows)==20000
reference_seconds=statistics.median(int(row[3]) for row in reference_rows)/1e9
(root/'reference.json').write_text(json.dumps({'command':command,'exit':ref_result.returncode,'observations':len(reference_rows),'median_seconds':reference_seconds,'binary_sha256':digest(reference)},indent=2)+'\n')
archive('reference',[root/'reference.stdout',root/'reference.stderr',root/'reference.json'],{'scope':'Fresh reference only; shared by the four groups','observations':20000})
print('REFERENCE',reference_seconds,flush=True)

expected_work={"before":44443887150,"after":44443887150}
all_groups=[]
for group in range(4):
    folder=root/f'group{group}';folder.mkdir()
    workers={};files=[]
    receipt={'group':group,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip(),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reference_seconds':reference_seconds,'source_sha256':digest(root/'session.rs'),'artifact_sha256':digest(artifact),'preparation_order':['before','after'] if group%2==0 else ['after','before'],'all_observations':{},'blocks':[],'primary_per_worker':496,'statistical_scope':'16 descriptive block pairs within one worker pair; not 16 independent executable pairs','timed_boundary':'Unchanged evaluate_into-only line; readiness, stdin wait, clear/rebind, verify and drops outside'}
    failure=None
    def read_line(process,timeout=240):
        ready,_,_=select.select([process.stdout],[],[],timeout)
        assert ready,'worker output timeout'
        text=process.stdout.readline()
        assert text,'worker terminated before required observation'
        return text
    def request(label):
        worker=workers[label];process=worker['process']
        process.stdin.write('N');process.stdin.flush()
        line=read_line(process,30);worker['journal'].write(line);worker['journal'].flush()
        row=json.loads(line)
        assert row['exact_reference'] and row['independent_inflation'] and row['capacity']==13
        assert row['input_bytes']==8 and row['raw_bytes']==10
        if expected_work[label] is None: expected_work[label]=row['work']
        assert row['work']==expected_work[label]
        receipt['all_observations'][label].append(row)
        return row
    try:
        for label in receipt['preparation_order']:
            stderr=(folder/(label+'.stderr')).open('w')
            journal=(folder/(label+'.stdout')).open('w')
            command=[str(root/label),str(artifact),'496']
            process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1,env={**os.environ,'MECH_BENCH_SESSION':'1'})
            workers[label]={'process':process,'stderr':stderr,'journal':journal,'command':command,'binary_sha256':digest(root/label)}
            marker=read_line(process)
            assert marker=='SESSION_READY\n',marker
            journal.write(marker);journal.flush()
            receipt['all_observations'][label]=[]
        # Both JITs and all preparation are complete. Only the requested worker
        # computes; its peer remains blocked on the input byte.
        for label in receipt['preparation_order']:
            row=request(label);assert row['warmup'] and row['sample']==0
        for block in range(16):
            order=['before','after'] if (block+group)%2==0 else ['after','before']
            result={'block':block,'order':order}
            for label in order:
                rows=[request(label) for _ in range(31)]
                assert all(not x['warmup'] and not x['profile'] for x in rows)
                result[label]=statistics.median(x['seconds'] for x in rows)
            result['after_over_before']=result['after']/result['before']
            receipt['blocks'].append(result)
            (folder/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
        for label in reversed(receipt['preparation_order']):
            row=request(label);assert row['profile'] and row['sample']==497
        for label,worker in workers.items():
            worker['process'].stdin.close()
            assert worker['process'].wait(timeout=30)==0
            worker['stderr'].flush()
            assert (folder/(label+'.stderr')).read_text().endswith('CLEANUP bytes=0 nodes=0\n')
        receipt['summary']={}
        for label in ['before','after']:
            primary=[x for x in receipt['all_observations'][label] if not x['warmup'] and not x['profile']]
            assert len(primary)==496 and len(receipt['all_observations'][label])==498
            median=statistics.median(x['seconds'] for x in primary)
            receipt['summary'][label]={'median_seconds':median,'multiple_of_roc':median/reference_seconds}
        receipt['summary']['pooled_ratio']=receipt['summary']['after']['median_seconds']/receipt['summary']['before']['median_seconds']
        receipt['summary']['median_block_ratio']=statistics.median(x['after_over_before'] for x in receipt['blocks'])
        receipt['summary']['geometric_block_ratio']=math.exp(statistics.mean(math.log(x['after_over_before']) for x in receipt['blocks']))
        receipt['summary']['improving_blocks']=sum(x['after_over_before']<1 for x in receipt['blocks'])
        receipt['exit']=0
    except BaseException as error:
        failure=error;receipt['exit']=1;receipt['error']=repr(error)
    finally:
        for worker in workers.values():
            process=worker['process']
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
            worker['journal'].close();worker['stderr'].close()
        receipt['workers']={label:{'command':x['command'],'binary_sha256':x['binary_sha256'],'exit':x['process'].returncode} for label,x in workers.items()}
        (folder/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
        archive(f'group{group}',list(folder.iterdir())+[root/'session.rs',root/'source-adaptation.json',root/'before-build.json',root/'after-build.json',root/'run.py'],{'scope':'All observations from this fixed worker group, including partial evidence on failure','receipt':{k:v for k,v in receipt.items() if k not in ['all_observations']}})
    if failure:raise failure
    all_groups.append(receipt)
    print('GROUP',group,json.dumps(receipt['summary']),flush=True)

summary={'groups':[{'group':g['group'],**g['summary']} for g in all_groups],'reference_seconds':reference_seconds,'primary_observations':3968,'all_observations':3984,'scope':'Four fixed independent worker groups with descriptive within-group block comparisons'}
for label in ['before','after']:
    rows=[x for g in all_groups for x in g['all_observations'][label] if not x['warmup'] and not x['profile']]
    median=statistics.median(x['seconds'] for x in rows)
    summary[label]={'median_seconds':median,'multiple_of_roc':median/reference_seconds}
summary['pooled_ratio']=summary['after']['median_seconds']/summary['before']['median_seconds']
ratios=[b['after_over_before'] for g in all_groups for b in g['blocks']]
summary['median_block_ratio']=statistics.median(ratios)
summary['geometric_block_ratio']=math.exp(statistics.mean(math.log(x) for x in ratios))
summary['improving_blocks']=sum(x<1 for x in ratios)
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
archive('summary',[root/'summary.json'],{'scope':'Derived descriptive summary of both immediately committed worker groups','summary':summary})
print('COMPLETE',json.dumps(summary),flush=True)
