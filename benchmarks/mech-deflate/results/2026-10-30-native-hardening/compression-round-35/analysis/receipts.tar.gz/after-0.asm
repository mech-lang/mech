
/private/tmp/mech-library-debit-inline-round35-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014b87a4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>:
1014b87a4: d101c3ff    	sub	sp, sp, #0x70
1014b87a8: a9035ff8    	stp	x24, x23, [sp, #0x30]
1014b87ac: a90457f6    	stp	x22, x21, [sp, #0x40]
1014b87b0: a9054ff4    	stp	x20, x19, [sp, #0x50]
1014b87b4: a9067bfd    	stp	x29, x30, [sp, #0x60]
1014b87b8: 910183fd    	add	x29, sp, #0x60
1014b87bc: aa0303f4    	mov	x20, x3
1014b87c0: aa0203f5    	mov	x21, x2
1014b87c4: aa0103f6    	mov	x22, x1
1014b87c8: aa0003f3    	mov	x19, x0
1014b87cc: f8418c29    	ldr	x9, [x1, #0x18]!
1014b87d0: b4000269    	cbz	x9, 0x1014b881c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x78>
1014b87d4: f9400ac8    	ldr	x8, [x22, #0x10]
1014b87d8: f90017e4    	str	x4, [sp, #0x28]
1014b87dc: f940092a    	ldr	x10, [x9, #0x10]
1014b87e0: 92f0000b    	mov	x11, #0x7fffffffffffffff ; =9223372036854775807
1014b87e4: eb0b015f    	cmp	x10, x11
1014b87e8: 54000902    	b.hs	0x1014b8908 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x164>
1014b87ec: f9401d29    	ldr	x9, [x9, #0x38]
1014b87f0: ab040129    	adds	x9, x9, x4
1014b87f4: 54000902    	b.hs	0x1014b8914 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x170>
1014b87f8: eb08013f    	cmp	x9, x8
1014b87fc: 54000209    	b.ls	0x1014b883c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x98>
1014b8800: 5280002a    	mov	w10, #0x1               ; =1
1014b8804: 39000bea    	strb	w10, [sp, #0x2]
1014b8808: 528000ca    	mov	w10, #0x6               ; =6
1014b880c: 528000cb    	mov	w11, #0x6               ; =6
1014b8810: 7100197f    	cmp	w11, #0x6
1014b8814: 54000440    	b.eq	0x1014b889c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf8>
1014b8818: 14000026    	b	0x1014b88b0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x10c>
1014b881c: aa0403f7    	mov	x23, x4
1014b8820: 943992fc    	bl	0x10231d410 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1014b8824: 36000200    	tbz	w0, #0x0, 0x1014b8864 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xc0>
1014b8828: 29065275    	stp	w21, w20, [x19, #0x30]
1014b882c: 3900227f    	strb	wzr, [x19, #0x8]
1014b8830: 528000e8    	mov	w8, #0x7                ; =7
1014b8834: 39000268    	strb	w8, [x19]
1014b8838: 1400002a    	b	0x1014b88e0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x13c>
1014b883c: d00128c0    	adrp	x0, 0x1039d2000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.214+0x100>
1014b8840: 91334000    	add	x0, x0, #0xcd0
1014b8844: 910003e8    	mov	x8, sp
1014b8848: 9100a3e2    	add	x2, sp, #0x28
1014b884c: 94014f66    	bl	0x10150c5e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu>
1014b8850: 394003eb    	ldrb	w11, [sp]
1014b8854: 7100217f    	cmp	w11, #0x8
1014b8858: 540001a1    	b.ne	0x1014b888c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xe8>
1014b885c: 528001ca    	mov	w10, #0xe               ; =14
1014b8860: 1400001f    	b	0x1014b88dc <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x138>
1014b8864: a940a2c9    	ldp	x9, x8, [x22, #0x8]
1014b8868: ab170129    	adds	x9, x9, x23
1014b886c: 54000582    	b.hs	0x1014b891c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x178>
1014b8870: eb08013f    	cmp	x9, x8
1014b8874: 54000429    	b.ls	0x1014b88f8 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x154>
1014b8878: 528000ca    	mov	w10, #0x6               ; =6
1014b887c: 3900026a    	strb	w10, [x19]
1014b8880: a900a269    	stp	x9, x8, [x19, #0x8]
1014b8884: 29035275    	stp	w21, w20, [x19, #0x18]
1014b8888: 14000016    	b	0x1014b88e0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x13c>
1014b888c: 394007ea    	ldrb	w10, [sp, #0x1]
1014b8890: a940a3e9    	ldp	x9, x8, [sp, #0x8]
1014b8894: 7100197f    	cmp	w11, #0x6
1014b8898: 540000c1    	b.ne	0x1014b88b0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x10c>
1014b889c: 7100195f    	cmp	w10, #0x6
1014b88a0: 54000081    	b.ne	0x1014b88b0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x10c>
1014b88a4: 29035275    	stp	w21, w20, [x19, #0x18]
1014b88a8: a900a269    	stp	x9, x8, [x19, #0x8]
1014b88ac: 1400000c    	b	0x1014b88dc <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x138>
1014b88b0: 29065275    	stp	w21, w20, [x19, #0x30]
1014b88b4: 3900226b    	strb	w11, [x19, #0x8]
1014b88b8: 3900266a    	strb	w10, [x19, #0x9]
1014b88bc: b84023ea    	ldur	w10, [sp, #0x2]
1014b88c0: b800a26a    	stur	w10, [x19, #0xa]
1014b88c4: 79400fea    	ldrh	w10, [sp, #0x6]
1014b88c8: 79001e6a    	strh	w10, [x19, #0xe]
1014b88cc: a9012269    	stp	x9, x8, [x19, #0x10]
1014b88d0: 3cc183e0    	ldur	q0, [sp, #0x18]
1014b88d4: 528000ea    	mov	w10, #0x7               ; =7
1014b88d8: 3d800a60    	str	q0, [x19, #0x20]
1014b88dc: 3900026a    	strb	w10, [x19]
1014b88e0: a9467bfd    	ldp	x29, x30, [sp, #0x60]
1014b88e4: a9454ff4    	ldp	x20, x19, [sp, #0x50]
1014b88e8: a94457f6    	ldp	x22, x21, [sp, #0x40]
1014b88ec: a9435ff8    	ldp	x24, x23, [sp, #0x30]
1014b88f0: 9101c3ff    	add	sp, sp, #0x70
1014b88f4: d65f03c0    	ret
1014b88f8: f90006c9    	str	x9, [x22, #0x8]
1014b88fc: 528001c8    	mov	w8, #0xe                ; =14
1014b8900: 39000268    	strb	w8, [x19]
1014b8904: 17fffff7    	b	0x1014b88e0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x13c>
1014b8908: f00128c0    	adrp	x0, 0x1039d3000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.664+0x28>
1014b890c: 91032000    	add	x0, x0, #0xc8
1014b8910: 94650585    	bl	0x102df9f24 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1014b8914: 92800009    	mov	x9, #-0x1               ; =-1
1014b8918: 17ffffba    	b	0x1014b8800 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x5c>
1014b891c: 528000c9    	mov	w9, #0x6                ; =6
1014b8920: 39000269    	strb	w9, [x19]
1014b8924: 92800009    	mov	x9, #-0x1               ; =-1
1014b8928: 17ffffd6    	b	0x1014b8880 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xdc>

00000001015195a8 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>:
1015195a8: d101c3ff    	sub	sp, sp, #0x70
1015195ac: a9035ff8    	stp	x24, x23, [sp, #0x30]
1015195b0: a90457f6    	stp	x22, x21, [sp, #0x40]
1015195b4: a9054ff4    	stp	x20, x19, [sp, #0x50]
1015195b8: a9067bfd    	stp	x29, x30, [sp, #0x60]
1015195bc: 910183fd    	add	x29, sp, #0x60
1015195c0: aa0303f4    	mov	x20, x3
1015195c4: aa0203f5    	mov	x21, x2
1015195c8: aa0103f6    	mov	x22, x1
1015195cc: aa0003f3    	mov	x19, x0
1015195d0: f8418c29    	ldr	x9, [x1, #0x18]!
1015195d4: b4000269    	cbz	x9, 0x101519620 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x78>
1015195d8: f9400ac8    	ldr	x8, [x22, #0x10]
1015195dc: f90017e4    	str	x4, [sp, #0x28]
1015195e0: f940092a    	ldr	x10, [x9, #0x10]
1015195e4: 92f0000b    	mov	x11, #0x7fffffffffffffff ; =9223372036854775807
1015195e8: eb0b015f    	cmp	x10, x11
1015195ec: 54000902    	b.hs	0x10151970c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x164>
1015195f0: f9401d29    	ldr	x9, [x9, #0x38]
1015195f4: ab040129    	adds	x9, x9, x4
1015195f8: 54000902    	b.hs	0x101519718 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x170>
1015195fc: eb08013f    	cmp	x9, x8
101519600: 54000209    	b.ls	0x101519640 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x98>
101519604: 5280002a    	mov	w10, #0x1               ; =1
101519608: 39000bea    	strb	w10, [sp, #0x2]
10151960c: 528000ca    	mov	w10, #0x6               ; =6
101519610: 528000cb    	mov	w11, #0x6               ; =6
101519614: 7100197f    	cmp	w11, #0x6
101519618: 54000440    	b.eq	0x1015196a0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf8>
10151961c: 14000026    	b	0x1015196b4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x10c>
101519620: aa0403f7    	mov	x23, x4
101519624: 94380f7b    	bl	0x10231d410 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
101519628: 36000200    	tbz	w0, #0x0, 0x101519668 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xc0>
10151962c: 29065275    	stp	w21, w20, [x19, #0x30]
101519630: 3900227f    	strb	wzr, [x19, #0x8]
101519634: 528000e8    	mov	w8, #0x7                ; =7
101519638: 39000268    	strb	w8, [x19]
10151963c: 1400002a    	b	0x1015196e4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x13c>
101519640: f00125c0    	adrp	x0, 0x1039d4000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.1062+0x28>
101519644: 913c8000    	add	x0, x0, #0xf20
101519648: 910003e8    	mov	x8, sp
10151964c: 9100a3e2    	add	x2, sp, #0x28
101519650: 97ffcbe5    	bl	0x10150c5e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu>
101519654: 394003eb    	ldrb	w11, [sp]
101519658: 7100217f    	cmp	w11, #0x8
10151965c: 540001a1    	b.ne	0x101519690 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xe8>
101519660: 528001ca    	mov	w10, #0xe               ; =14
101519664: 1400001f    	b	0x1015196e0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x138>
101519668: a940a2c9    	ldp	x9, x8, [x22, #0x8]
10151966c: ab170129    	adds	x9, x9, x23
101519670: 54000582    	b.hs	0x101519720 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x178>
101519674: eb08013f    	cmp	x9, x8
101519678: 54000429    	b.ls	0x1015196fc <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x154>
10151967c: 528000ca    	mov	w10, #0x6               ; =6
101519680: 3900026a    	strb	w10, [x19]
101519684: a900a269    	stp	x9, x8, [x19, #0x8]
101519688: 29035275    	stp	w21, w20, [x19, #0x18]
10151968c: 14000016    	b	0x1015196e4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x13c>
101519690: 394007ea    	ldrb	w10, [sp, #0x1]
101519694: a940a3e9    	ldp	x9, x8, [sp, #0x8]
101519698: 7100197f    	cmp	w11, #0x6
10151969c: 540000c1    	b.ne	0x1015196b4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x10c>
1015196a0: 7100195f    	cmp	w10, #0x6
1015196a4: 54000081    	b.ne	0x1015196b4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x10c>
1015196a8: 29035275    	stp	w21, w20, [x19, #0x18]
1015196ac: a900a269    	stp	x9, x8, [x19, #0x8]
1015196b0: 1400000c    	b	0x1015196e0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x138>
1015196b4: 29065275    	stp	w21, w20, [x19, #0x30]
1015196b8: 3900226b    	strb	w11, [x19, #0x8]
1015196bc: 3900266a    	strb	w10, [x19, #0x9]
1015196c0: b84023ea    	ldur	w10, [sp, #0x2]
1015196c4: b800a26a    	stur	w10, [x19, #0xa]
1015196c8: 79400fea    	ldrh	w10, [sp, #0x6]
1015196cc: 79001e6a    	strh	w10, [x19, #0xe]
1015196d0: a9012269    	stp	x9, x8, [x19, #0x10]
1015196d4: 3cc183e0    	ldur	q0, [sp, #0x18]
1015196d8: 528000ea    	mov	w10, #0x7               ; =7
1015196dc: 3d800a60    	str	q0, [x19, #0x20]
1015196e0: 3900026a    	strb	w10, [x19]
1015196e4: a9467bfd    	ldp	x29, x30, [sp, #0x60]
1015196e8: a9454ff4    	ldp	x20, x19, [sp, #0x50]
1015196ec: a94457f6    	ldp	x22, x21, [sp, #0x40]
1015196f0: a9435ff8    	ldp	x24, x23, [sp, #0x30]
1015196f4: 9101c3ff    	add	sp, sp, #0x70
1015196f8: d65f03c0    	ret
1015196fc: f90006c9    	str	x9, [x22, #0x8]
101519700: 528001c8    	mov	w8, #0xe                ; =14
101519704: 39000268    	strb	w8, [x19]
101519708: 17fffff7    	b	0x1015196e4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x13c>
10151970c: f00125c0    	adrp	x0, 0x1039d4000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.1062+0x28>
101519710: 913c2000    	add	x0, x0, #0xf08
101519714: 94638204    	bl	0x102df9f24 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
101519718: 92800009    	mov	x9, #-0x1               ; =-1
10151971c: 17ffffba    	b	0x101519604 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x5c>
101519720: 528000c9    	mov	w9, #0x6                ; =6
101519724: 39000269    	strb	w9, [x19]
101519728: 92800009    	mov	x9, #-0x1               ; =-1
10151972c: 17ffffd6    	b	0x101519684 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xdc>
