
/private/tmp/mech-library-debit-inline-round35-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014bb650 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>:
1014bb650: d10243ff    	sub	sp, sp, #0x90
1014bb654: a90467fa    	stp	x26, x25, [sp, #0x40]
1014bb658: a9055ff8    	stp	x24, x23, [sp, #0x50]
1014bb65c: a90657f6    	stp	x22, x21, [sp, #0x60]
1014bb660: a9074ff4    	stp	x20, x19, [sp, #0x70]
1014bb664: a9087bfd    	stp	x29, x30, [sp, #0x80]
1014bb668: 910203fd    	add	x29, sp, #0x80
1014bb66c: aa0003f3    	mov	x19, x0
1014bb670: 2a0303e8    	mov	w8, w3
1014bb674: f9400449    	ldr	x9, [x2, #0x8]
1014bb678: eb08013f    	cmp	x9, x8
1014bb67c: 54000469    	b.ls	0x1014bb708 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb8>
1014bb680: f9400049    	ldr	x9, [x2]
1014bb684: 8b081529    	add	x9, x9, x8, lsl #5
1014bb688: f9400128    	ldr	x8, [x9]
1014bb68c: f100051f    	cmp	x8, #0x1
1014bb690: 540003c1    	b.ne	0x1014bb708 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xb8>
1014bb694: f9400c48    	ldr	x8, [x2, #0x18]
1014bb698: a940d536    	ldp	x22, x21, [x9, #0x8]
1014bb69c: eb1602bf    	cmp	x21, x22
1014bb6a0: fa4822a2    	ccmp	x21, x8, #0x2, hs
1014bb6a4: 54001268    	b.hi	0x1014bb8f0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x2a0>
1014bb6a8: aa0103f4    	mov	x20, x1
1014bb6ac: f9400857    	ldr	x23, [x2, #0x10]
1014bb6b0: f9400d38    	ldr	x24, [x9, #0x18]
1014bb6b4: aa0403e1    	mov	x1, x4
1014bb6b8: f8418c29    	ldr	x9, [x1, #0x18]!
1014bb6bc: b40003a9    	cbz	x9, 0x1014bb730 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xe0>
1014bb6c0: f9400888    	ldr	x8, [x4, #0x10]
1014bb6c4: f9001ff8    	str	x24, [sp, #0x38]
1014bb6c8: f940092a    	ldr	x10, [x9, #0x10]
1014bb6cc: 92f0000b    	mov	x11, #0x7fffffffffffffff ; =9223372036854775807
1014bb6d0: eb0b015f    	cmp	x10, x11
1014bb6d4: 540011a2    	b.hs	0x1014bb908 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x2b8>
1014bb6d8: f9401d29    	ldr	x9, [x9, #0x38]
1014bb6dc: ab180129    	adds	x9, x9, x24
1014bb6e0: 540011a2    	b.hs	0x1014bb914 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x2c4>
1014bb6e4: eb08013f    	cmp	x9, x8
1014bb6e8: 54000349    	b.ls	0x1014bb750 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x100>
1014bb6ec: 5280002a    	mov	w10, #0x1               ; =1
1014bb6f0: 39004bea    	strb	w10, [sp, #0x12]
1014bb6f4: 528000cb    	mov	w11, #0x6               ; =6
1014bb6f8: 528000ca    	mov	w10, #0x6               ; =6
1014bb6fc: 7100195f    	cmp	w10, #0x6
1014bb700: 54000400    	b.eq	0x1014bb780 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x130>
1014bb704: 14000028    	b	0x1014bb7a4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x154>
1014bb708: 3900127f    	strb	wzr, [x19, #0x4]
1014bb70c: 528000c8    	mov	w8, #0x6                ; =6
1014bb710: b9000268    	str	w8, [x19]
1014bb714: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1014bb718: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1014bb71c: a94657f6    	ldp	x22, x21, [sp, #0x60]
1014bb720: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1014bb724: a94467fa    	ldp	x26, x25, [sp, #0x40]
1014bb728: 910243ff    	add	sp, sp, #0x90
1014bb72c: d65f03c0    	ret
1014bb730: aa0403f9    	mov	x25, x4
1014bb734: 94398737    	bl	0x10231d410 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1014bb738: 36000440    	tbz	w0, #0x0, 0x1014bb7c0 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x170>
1014bb73c: d2800008    	mov	x8, #0x0                ; =0
1014bb740: 5280000a    	mov	w10, #0x0               ; =0
1014bb744: 5280000b    	mov	w11, #0x0               ; =0
1014bb748: 528000ed    	mov	w13, #0x7               ; =7
1014bb74c: 14000027    	b	0x1014bb7e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x198>
1014bb750: f00128a0    	adrp	x0, 0x1039d2000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.214+0x100>
1014bb754: 91334000    	add	x0, x0, #0xcd0
1014bb758: 910043e8    	add	x8, sp, #0x10
1014bb75c: 9100e3e2    	add	x2, sp, #0x38
1014bb760: 940143a1    	bl	0x10150c5e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu>
1014bb764: 394043ea    	ldrb	w10, [sp, #0x10]
1014bb768: 7100215f    	cmp	w10, #0x8
1014bb76c: 54000580    	b.eq	0x1014bb81c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1cc>
1014bb770: 394047eb    	ldrb	w11, [sp, #0x11]
1014bb774: a941a3e9    	ldp	x9, x8, [sp, #0x18]
1014bb778: 7100195f    	cmp	w10, #0x6
1014bb77c: 54000141    	b.ne	0x1014bb7a4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x154>
1014bb780: 7100197f    	cmp	w11, #0x6
1014bb784: 54000101    	b.ne	0x1014bb7a4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x154>
1014bb788: 12001d2a    	and	w10, w9, #0xff
1014bb78c: 53083d2b    	ubfx	w11, w9, #8, #8
1014bb790: d350fd2c    	lsr	x12, x9, #16
1014bb794: 528000cd    	mov	w13, #0x6               ; =6
1014bb798: aa0803e9    	mov	x9, x8
1014bb79c: d2800008    	mov	x8, #0x0                ; =0
1014bb7a0: 14000012    	b	0x1014bb7e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x198>
1014bb7a4: 79402fec    	ldrh	w12, [sp, #0x16]
1014bb7a8: b84123ed    	ldur	w13, [sp, #0x12]
1014bb7ac: aa0c81ac    	orr	x12, x13, x12, lsl #32
1014bb7b0: 3cc283e0    	ldur	q0, [sp, #0x28]
1014bb7b4: 3d8003e0    	str	q0, [sp]
1014bb7b8: 528000ed    	mov	w13, #0x7               ; =7
1014bb7bc: 1400000b    	b	0x1014bb7e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x198>
1014bb7c0: a940a72a    	ldp	x10, x9, [x25, #0x8]
1014bb7c4: ab18014c    	adds	x12, x10, x24
1014bb7c8: 54000aa2    	b.hs	0x1014bb91c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x2cc>
1014bb7cc: eb09019f    	cmp	x12, x9
1014bb7d0: 54000249    	b.ls	0x1014bb818 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1c8>
1014bb7d4: d2800008    	mov	x8, #0x0                ; =0
1014bb7d8: 12001d8a    	and	w10, w12, #0xff
1014bb7dc: 53083d8b    	ubfx	w11, w12, #8, #8
1014bb7e0: d350fd8c    	lsr	x12, x12, #16
1014bb7e4: 528000cd    	mov	w13, #0x6               ; =6
1014bb7e8: d3787d6b    	ubfiz	x11, x11, #8, #32
1014bb7ec: aa0c416b    	orr	x11, x11, x12, lsl #16
1014bb7f0: 2a0a03ea    	mov	w10, w10
1014bb7f4: aa0a016a    	orr	x10, x11, x10
1014bb7f8: b900027f    	str	wzr, [x19]
1014bb7fc: 3900226d    	strb	w13, [x19, #0x8]
1014bb800: a901266a    	stp	x10, x9, [x19, #0x10]
1014bb804: f9001268    	str	x8, [x19, #0x20]
1014bb808: 3dc003e0    	ldr	q0, [sp]
1014bb80c: 3c828260    	stur	q0, [x19, #0x28]
1014bb810: b9003a7f    	str	wzr, [x19, #0x38]
1014bb814: 17ffffc0    	b	0x1014bb714 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xc4>
1014bb818: f900072c    	str	x12, [x25, #0x8]
1014bb81c: b4000554    	cbz	x20, 0x1014bb8c4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x274>
1014bb820: eb1502df    	cmp	x22, x21
1014bb824: 540004a0    	b.eq	0x1014bb8b8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x268>
1014bb828: 8b1606c8    	add	x8, x22, x22, lsl #1
1014bb82c: d37df108    	lsl	x8, x8, #3
1014bb830: 8b170109    	add	x9, x8, x23
1014bb834: 91002136    	add	x22, x9, #0x8
1014bb838: 52800309    	mov	w9, #0x18               ; =24
1014bb83c: cb0803e8    	neg	x8, x8
1014bb840: 9b0922b7    	madd	x23, x21, x9, x8
1014bb844: 14000005    	b	0x1014bb858 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x208>
1014bb848: f90002bf    	str	xzr, [x21]
1014bb84c: 910062d6    	add	x22, x22, #0x18
1014bb850: f10062f7    	subs	x23, x23, #0x18
1014bb854: 54000320    	b.eq	0x1014bb8b8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x268>
1014bb858: b85f82c8    	ldur	w8, [x22, #-0x8]
1014bb85c: 36000188    	tbz	w8, #0x0, 0x1014bb88c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x23c>
1014bb860: f9407a81    	ldr	x1, [x20, #0xf0]
1014bb864: f94002c0    	ldr	x0, [x22]
1014bb868: eb01001f    	cmp	x0, x1
1014bb86c: 54000642    	b.hs	0x1014bb934 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x2e4>
1014bb870: f9407688    	ldr	x8, [x20, #0xe8]
1014bb874: 8b001915    	add	x21, x8, x0, lsl #6
1014bb878: f94002a8    	ldr	x8, [x21]
1014bb87c: b4fffe68    	cbz	x8, 0x1014bb848 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1f8>
1014bb880: aa1503e0    	mov	x0, x21
1014bb884: 97ffdf18    	bl	0x1014b34e4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs29QkOtpKx6e_8mech_gpu>
1014bb888: 17fffff0    	b	0x1014bb848 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x1f8>
1014bb88c: f9408e82    	ldr	x2, [x20, #0x118]
1014bb890: a8c186c0    	ldp	x0, x1, [x22], #0x18
1014bb894: eb000028    	subs	x8, x1, x0
1014bb898: fa422022    	ccmp	x1, x2, #0x2, hs
1014bb89c: 54000248    	b.hi	0x1014bb8e4 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x294>
1014bb8a0: f9408a89    	ldr	x9, [x20, #0x110]
1014bb8a4: 8b000d20    	add	x0, x9, x0, lsl #3
1014bb8a8: d37df101    	lsl	x1, x8, #3
1014bb8ac: 9464fefa    	bl	0x102dfb494 <dyld_stub_binder+0x102dfb494>
1014bb8b0: f10062f7    	subs	x23, x23, #0x18
1014bb8b4: 54fffd21    	b.ne	0x1014bb858 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x208>
1014bb8b8: 52800028    	mov	w8, #0x1                ; =1
1014bb8bc: 39001268    	strb	w8, [x19, #0x4]
1014bb8c0: 17ffff93    	b	0x1014bb70c <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xbc>
1014bb8c4: b900027f    	str	wzr, [x19]
1014bb8c8: 52800188    	mov	w8, #0xc                ; =12
1014bb8cc: d000dbc9    	adrp	x9, 0x103035000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.104+0x5f1>
1014bb8d0: 913d1d29    	add	x9, x9, #0xf47
1014bb8d4: a900a668    	stp	x8, x9, [x19, #0x8]
1014bb8d8: 52800368    	mov	w8, #0x1b               ; =27
1014bb8dc: f9000e68    	str	x8, [x19, #0x18]
1014bb8e0: 17ffff8d    	b	0x1014bb714 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0xc4>
1014bb8e4: f00128a3    	adrp	x3, 0x1039d2000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.214+0x100>
1014bb8e8: 91088063    	add	x3, x3, #0x220
1014bb8ec: 9464fa3a    	bl	0x102dfa1d4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1014bb8f0: f00128a3    	adrp	x3, 0x1039d2000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.214+0x100>
1014bb8f4: 91022063    	add	x3, x3, #0x88
1014bb8f8: aa1603e0    	mov	x0, x22
1014bb8fc: aa1503e1    	mov	x1, x21
1014bb900: aa0803e2    	mov	x2, x8
1014bb904: 9464fa34    	bl	0x102dfa1d4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1014bb908: 900128c0    	adrp	x0, 0x1039d3000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.664+0x28>
1014bb90c: 91032000    	add	x0, x0, #0xc8
1014bb910: 9464f985    	bl	0x102df9f24 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1014bb914: 92800009    	mov	x9, #-0x1               ; =-1
1014bb918: 17ffff75    	b	0x1014bb6ec <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x9c>
1014bb91c: d2800008    	mov	x8, #0x0                ; =0
1014bb920: 92ffffec    	mov	x12, #0xffffffffffff    ; =281474976710655
1014bb924: 52801fea    	mov	w10, #0xff              ; =255
1014bb928: 528000cd    	mov	w13, #0x6               ; =6
1014bb92c: 52801feb    	mov	w11, #0xff              ; =255
1014bb930: 17ffffae    	b	0x1014bb7e8 <__RNvMNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire+0x198>
1014bb934: f00128a2    	adrp	x2, 0x1039d2000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.214+0x100>
1014bb938: 9108e042    	add	x2, x2, #0x238
1014bb93c: 9464f9b9    	bl	0x102dfa020 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014bb940: f90002bf    	str	xzr, [x21]
1014bb944: 9464feaa    	bl	0x102dfb3ec <dyld_stub_binder+0x102dfb3ec>
