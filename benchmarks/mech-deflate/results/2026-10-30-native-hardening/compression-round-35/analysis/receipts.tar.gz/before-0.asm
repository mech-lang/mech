
/private/tmp/mech-library-debit-inline-round35-20261030/workers/before:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101540bb4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>:
101540bb4: d10183ff    	sub	sp, sp, #0x60
101540bb8: a90357f6    	stp	x22, x21, [sp, #0x30]
101540bbc: a9044ff4    	stp	x20, x19, [sp, #0x40]
101540bc0: a9057bfd    	stp	x29, x30, [sp, #0x50]
101540bc4: 910143fd    	add	x29, sp, #0x50
101540bc8: aa0003f3    	mov	x19, x0
101540bcc: aa0103e0    	mov	x0, x1
101540bd0: f8418c08    	ldr	x8, [x0, #0x18]!
101540bd4: b4000168    	cbz	x8, 0x101540c00 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x4c>
101540bd8: f9400829    	ldr	x9, [x1, #0x10]
101540bdc: 910023e8    	add	x8, sp, #0x8
101540be0: aa0203e1    	mov	x1, x2
101540be4: aa0903e2    	mov	x2, x9
101540be8: 9437674d    	bl	0x10231a91c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
101540bec: 394023ea    	ldrb	w10, [sp, #0x8]
101540bf0: 7100215f    	cmp	w10, #0x8
101540bf4: 54000181    	b.ne	0x101540c24 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x70>
101540bf8: 528001ca    	mov	w10, #0xe               ; =14
101540bfc: 14000029    	b	0x101540ca0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xec>
101540c00: aa0203f4    	mov	x20, x2
101540c04: aa0103f5    	mov	x21, x1
101540c08: 9437654c    	bl	0x10231a138 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
101540c0c: 360002e0    	tbz	w0, #0x0, 0x101540c68 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xb4>
101540c10: b900327f    	str	wzr, [x19, #0x30]
101540c14: 3900227f    	strb	wzr, [x19, #0x8]
101540c18: 528000e8    	mov	w8, #0x7                ; =7
101540c1c: 39000268    	strb	w8, [x19]
101540c20: 14000021    	b	0x101540ca4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf0>
101540c24: 394027eb    	ldrb	w11, [sp, #0x9]
101540c28: a94123e9    	ldp	x9, x8, [sp, #0x10]
101540c2c: 7100195f    	cmp	w10, #0x6
101540c30: 7a460960    	ccmp	w11, #0x6, #0x0, eq
101540c34: 54000300    	b.eq	0x101540c94 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xe0>
101540c38: b900327f    	str	wzr, [x19, #0x30]
101540c3c: 3900226a    	strb	w10, [x19, #0x8]
101540c40: 3900266b    	strb	w11, [x19, #0x9]
101540c44: b840a3ea    	ldur	w10, [sp, #0xa]
101540c48: b800a26a    	stur	w10, [x19, #0xa]
101540c4c: 79401fea    	ldrh	w10, [sp, #0xe]
101540c50: 79001e6a    	strh	w10, [x19, #0xe]
101540c54: a9012269    	stp	x9, x8, [x19, #0x10]
101540c58: 3cc203e0    	ldur	q0, [sp, #0x20]
101540c5c: 528000ea    	mov	w10, #0x7               ; =7
101540c60: 3d800a60    	str	q0, [x19, #0x20]
101540c64: 1400000f    	b	0x101540ca0 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xec>
101540c68: a940a2aa    	ldp	x10, x8, [x21, #0x8]
101540c6c: ab14014a    	adds	x10, x10, x20
101540c70: 540002c2    	b.hs	0x101540cc8 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x114>
101540c74: eb08015f    	cmp	x10, x8
101540c78: 54000209    	b.ls	0x101540cb8 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x104>
101540c7c: 528000c9    	mov	w9, #0x6                ; =6
101540c80: 39000269    	strb	w9, [x19]
101540c84: f900066a    	str	x10, [x19, #0x8]
101540c88: f9000a68    	str	x8, [x19, #0x10]
101540c8c: b9001a7f    	str	wzr, [x19, #0x18]
101540c90: 14000005    	b	0x101540ca4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf0>
101540c94: b9001a7f    	str	wzr, [x19, #0x18]
101540c98: 528000ca    	mov	w10, #0x6               ; =6
101540c9c: a900a269    	stp	x9, x8, [x19, #0x8]
101540ca0: 3900026a    	strb	w10, [x19]
101540ca4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101540ca8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101540cac: a94357f6    	ldp	x22, x21, [sp, #0x30]
101540cb0: 910183ff    	add	sp, sp, #0x60
101540cb4: d65f03c0    	ret
101540cb8: f90006aa    	str	x10, [x21, #0x8]
101540cbc: 528001c8    	mov	w8, #0xe                ; =14
101540cc0: 39000268    	strb	w8, [x19]
101540cc4: 17fffff8    	b	0x101540ca4 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf0>
101540cc8: 528000c9    	mov	w9, #0x6                ; =6
101540ccc: 39000269    	strb	w9, [x19]
101540cd0: 92800009    	mov	x9, #-0x1               ; =-1
101540cd4: f9000669    	str	x9, [x19, #0x8]
101540cd8: 17ffffec    	b	0x101540c88 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xd4>

00000001015a8b44 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>:
1015a8b44: d101c3ff    	sub	sp, sp, #0x70
1015a8b48: a9035ff8    	stp	x24, x23, [sp, #0x30]
1015a8b4c: a90457f6    	stp	x22, x21, [sp, #0x40]
1015a8b50: a9054ff4    	stp	x20, x19, [sp, #0x50]
1015a8b54: a9067bfd    	stp	x29, x30, [sp, #0x60]
1015a8b58: 910183fd    	add	x29, sp, #0x60
1015a8b5c: aa0303f4    	mov	x20, x3
1015a8b60: aa0203f5    	mov	x21, x2
1015a8b64: aa0003f3    	mov	x19, x0
1015a8b68: aa0103e0    	mov	x0, x1
1015a8b6c: f8418c08    	ldr	x8, [x0, #0x18]!
1015a8b70: b4000148    	cbz	x8, 0x1015a8b98 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x54>
1015a8b74: f9400822    	ldr	x2, [x1, #0x10]
1015a8b78: 910023e8    	add	x8, sp, #0x8
1015a8b7c: aa0403e1    	mov	x1, x4
1015a8b80: 9435c767    	bl	0x10231a91c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015a8b84: 394023ea    	ldrb	w10, [sp, #0x8]
1015a8b88: 7100215f    	cmp	w10, #0x8
1015a8b8c: 54000181    	b.ne	0x1015a8bbc <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x78>
1015a8b90: 528001ca    	mov	w10, #0xe               ; =14
1015a8b94: 14000029    	b	0x1015a8c38 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf4>
1015a8b98: aa0403f6    	mov	x22, x4
1015a8b9c: aa0103f7    	mov	x23, x1
1015a8ba0: 9435c566    	bl	0x10231a138 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015a8ba4: 360002e0    	tbz	w0, #0x0, 0x1015a8c00 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xbc>
1015a8ba8: 29065275    	stp	w21, w20, [x19, #0x30]
1015a8bac: 3900227f    	strb	wzr, [x19, #0x8]
1015a8bb0: 528000e8    	mov	w8, #0x7                ; =7
1015a8bb4: 39000268    	strb	w8, [x19]
1015a8bb8: 14000021    	b	0x1015a8c3c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf8>
1015a8bbc: 394027eb    	ldrb	w11, [sp, #0x9]
1015a8bc0: a94123e9    	ldp	x9, x8, [sp, #0x10]
1015a8bc4: 7100195f    	cmp	w10, #0x6
1015a8bc8: 7a460960    	ccmp	w11, #0x6, #0x0, eq
1015a8bcc: 54000300    	b.eq	0x1015a8c2c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xe8>
1015a8bd0: 29065275    	stp	w21, w20, [x19, #0x30]
1015a8bd4: 3900226a    	strb	w10, [x19, #0x8]
1015a8bd8: 3900266b    	strb	w11, [x19, #0x9]
1015a8bdc: b840a3ea    	ldur	w10, [sp, #0xa]
1015a8be0: b800a26a    	stur	w10, [x19, #0xa]
1015a8be4: 79401fea    	ldrh	w10, [sp, #0xe]
1015a8be8: 79001e6a    	strh	w10, [x19, #0xe]
1015a8bec: a9012269    	stp	x9, x8, [x19, #0x10]
1015a8bf0: 3cc203e0    	ldur	q0, [sp, #0x20]
1015a8bf4: 528000ea    	mov	w10, #0x7               ; =7
1015a8bf8: 3d800a60    	str	q0, [x19, #0x20]
1015a8bfc: 1400000f    	b	0x1015a8c38 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf4>
1015a8c00: a940a2ea    	ldp	x10, x8, [x23, #0x8]
1015a8c04: ab16014a    	adds	x10, x10, x22
1015a8c08: 540002e2    	b.hs	0x1015a8c64 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x120>
1015a8c0c: eb08015f    	cmp	x10, x8
1015a8c10: 54000229    	b.ls	0x1015a8c54 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0x110>
1015a8c14: 528000c9    	mov	w9, #0x6                ; =6
1015a8c18: 39000269    	strb	w9, [x19]
1015a8c1c: f900066a    	str	x10, [x19, #0x8]
1015a8c20: f9000a68    	str	x8, [x19, #0x10]
1015a8c24: 29035275    	stp	w21, w20, [x19, #0x18]
1015a8c28: 14000005    	b	0x1015a8c3c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf8>
1015a8c2c: 29035275    	stp	w21, w20, [x19, #0x18]
1015a8c30: 528000ca    	mov	w10, #0x6               ; =6
1015a8c34: a900a269    	stp	x9, x8, [x19, #0x8]
1015a8c38: 3900026a    	strb	w10, [x19]
1015a8c3c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
1015a8c40: a9454ff4    	ldp	x20, x19, [sp, #0x50]
1015a8c44: a94457f6    	ldp	x22, x21, [sp, #0x40]
1015a8c48: a9435ff8    	ldp	x24, x23, [sp, #0x30]
1015a8c4c: 9101c3ff    	add	sp, sp, #0x70
1015a8c50: d65f03c0    	ret
1015a8c54: f90006ea    	str	x10, [x23, #0x8]
1015a8c58: 528001c8    	mov	w8, #0xe                ; =14
1015a8c5c: 39000268    	strb	w8, [x19]
1015a8c60: 17fffff7    	b	0x1015a8c3c <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xf8>
1015a8c64: 528000c9    	mov	w9, #0x6                ; =6
1015a8c68: 39000269    	strb	w9, [x19]
1015a8c6c: 92800009    	mov	x9, #-0x1               ; =-1
1015a8c70: f9000669    	str	x9, [x19, #0x8]
1015a8c74: 17ffffeb    	b	0x1015a8c20 <__RNvMNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge+0xdc>
