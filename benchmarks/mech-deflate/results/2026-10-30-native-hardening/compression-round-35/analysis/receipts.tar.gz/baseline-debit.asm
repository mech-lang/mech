
/private/tmp/mech-work-charge-inline-round34-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010231a91c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
10231a91c: d10203ff    	sub	sp, sp, #0x80
10231a920: a9064ff4    	stp	x20, x19, [sp, #0x60]
10231a924: a9077bfd    	stp	x29, x30, [sp, #0x70]
10231a928: 9101c3fd    	add	x29, sp, #0x70
10231a92c: f9400013    	ldr	x19, [x0]
10231a930: f9400a69    	ldr	x9, [x19, #0x10]
10231a934: 92f0000a    	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10231a938: eb0a013f    	cmp	x9, x10
10231a93c: 54000362    	b.hs	0x10231a9a8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x8c>
10231a940: 9100052a    	add	x10, x9, #0x1
10231a944: f9000a6a    	str	x10, [x19, #0x10]
10231a948: f9401e6a    	ldr	x10, [x19, #0x38]
10231a94c: ab01014a    	adds	x10, x10, x1
10231a950: 54000322    	b.hs	0x10231a9b4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x98>
10231a954: f9000a69    	str	x9, [x19, #0x10]
10231a958: eb02015f    	cmp	x10, x2
10231a95c: 540000e9    	b.ls	0x10231a978 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x5c>
10231a960: 5280c0c9    	mov	w9, #0x606              ; =1542
10231a964: 79000109    	strh	w9, [x8]
10231a968: 52800029    	mov	w9, #0x1                ; =1
10231a96c: 39000909    	strb	w9, [x8, #0x2]
10231a970: a900890a    	stp	x10, x2, [x8, #0x8]
10231a974: 1400004d    	b	0x10231aaa8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
10231a978: b000c080    	adrp	x0, 0x103b2b000 <__mi_heap_main+0xb28>
10231a97c: 9115a000    	add	x0, x0, #0x568
10231a980: f9400009    	ldr	x9, [x0]
10231a984: d63f0120    	blr	x9
10231a988: 39412009    	ldrb	w9, [x0, #0x48]
10231a98c: 7100053f    	cmp	w9, #0x1
10231a990: 54000360    	b.eq	0x10231a9fc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe0>
10231a994: 7100093f    	cmp	w9, #0x2
10231a998: 540001e1    	b.ne	0x10231a9d4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xb8>
10231a99c: d000bec0    	adrp	x0, 0x103af4000 <_anon.686517066f445f70c1782692b9896900.7+0x566c0>
10231a9a0: 91126000    	add	x0, x0, #0x498
10231a9a4: 942b62da    	bl	0x102df350c <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10231a9a8: f000bec0    	adrp	x0, 0x103af5000 <_anon.b04a84545da479ddfbeac64712713f7a.204+0x8>
10231a9ac: 912a4000    	add	x0, x0, #0xa90
10231a9b0: 942b6484    	bl	0x102df3bc0 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10231a9b4: 5280c0ca    	mov	w10, #0x606             ; =1542
10231a9b8: 7900010a    	strh	w10, [x8]
10231a9bc: 5280002a    	mov	w10, #0x1               ; =1
10231a9c0: 3900090a    	strb	w10, [x8, #0x2]
10231a9c4: 9280000a    	mov	x10, #-0x1              ; =-1
10231a9c8: a900890a    	stp	x10, x2, [x8, #0x8]
10231a9cc: f9000a69    	str	x9, [x19, #0x10]
10231a9d0: 14000036    	b	0x10231aaa8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
10231a9d4: d0003129    	adrp	x9, 0x102940000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy5_EB8_+0x3f0>
10231a9d8: 913f4129    	add	x9, x9, #0xfd0
10231a9dc: a90003e1    	stp	x1, x0, [sp]
10231a9e0: aa0903e1    	mov	x1, x9
10231a9e4: aa0803f4    	mov	x20, x8
10231a9e8: 942a1f26    	bl	0x102da2680 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10231a9ec: a94003e1    	ldp	x1, x0, [sp]
10231a9f0: aa1403e8    	mov	x8, x20
10231a9f4: 52800029    	mov	w9, #0x1                ; =1
10231a9f8: 39012009    	strb	w9, [x0, #0x48]
10231a9fc: f9401009    	ldr	x9, [x0, #0x20]
10231aa00: 92f0000a    	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10231aa04: eb0a013f    	cmp	x9, x10
10231aa08: 54000582    	b.hs	0x10231aab8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x19c>
10231aa0c: f9401409    	ldr	x9, [x0, #0x28]
10231aa10: f100013f    	cmp	x9, #0x0
10231aa14: fa531124    	ccmp	x9, x19, #0x4, ne
10231aa18: 540003a1    	b.ne	0x10231aa8c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x170>
10231aa1c: aa0803f4    	mov	x20, x8
10231aa20: f9400a68    	ldr	x8, [x19, #0x10]
10231aa24: b5000508    	cbnz	x8, 0x10231aac4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
10231aa28: aa0103e2    	mov	x2, x1
10231aa2c: 92800008    	mov	x8, #-0x1               ; =-1
10231aa30: f9000a68    	str	x8, [x19, #0x10]
10231aa34: 3dc00c00    	ldr	q0, [x0, #0x30]
10231aa38: 3d8007e0    	str	q0, [sp, #0x10]
10231aa3c: f9402008    	ldr	x8, [x0, #0x40]
10231aa40: f90013e8    	str	x8, [sp, #0x20]
10231aa44: 9100e3e0    	add	x0, sp, #0x38
10231aa48: 91006261    	add	x1, x19, #0x18
10231aa4c: 910043e4    	add	x4, sp, #0x10
10231aa50: d2800003    	mov	x3, #0x0                ; =0
10231aa54: 940061db    	bl	0x1023331c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits>
10231aa58: f9400a68    	ldr	x8, [x19, #0x10]
10231aa5c: 91000508    	add	x8, x8, #0x1
10231aa60: f9000a68    	str	x8, [x19, #0x10]
10231aa64: 3940e3e9    	ldrb	w9, [sp, #0x38]
10231aa68: 3cc393e0    	ldur	q0, [sp, #0x39]
10231aa6c: 3cc493e1    	ldur	q1, [sp, #0x49]
10231aa70: ad0087e0    	stp	q0, q1, [sp, #0x10]
10231aa74: f9402fe8    	ldr	x8, [sp, #0x58]
10231aa78: f802f3e8    	stur	x8, [sp, #0x2f]
10231aa7c: 7100253f    	cmp	w9, #0x9
10231aa80: aa1403e8    	mov	x8, x20
10231aa84: 54000061    	b.ne	0x10231aa90 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x174>
10231aa88: 17ffffc5    	b	0x10231a99c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x80>
10231aa8c: 52800009    	mov	w9, #0x0                ; =0
10231aa90: 39000109    	strb	w9, [x8]
10231aa94: ad4087e0    	ldp	q0, q1, [sp, #0x10]
10231aa98: 3c801100    	stur	q0, [x8, #0x1]
10231aa9c: 3c811101    	stur	q1, [x8, #0x11]
10231aaa0: f842f3e9    	ldur	x9, [sp, #0x2f]
10231aaa4: f9001109    	str	x9, [x8, #0x20]
10231aaa8: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10231aaac: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10231aab0: 910203ff    	add	sp, sp, #0x80
10231aab4: d65f03c0    	ret
10231aab8: f000bec0    	adrp	x0, 0x103af5000 <_anon.b04a84545da479ddfbeac64712713f7a.204+0x8>
10231aabc: 91292000    	add	x0, x0, #0xa48
10231aac0: 942b6440    	bl	0x102df3bc0 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10231aac4: f000bec0    	adrp	x0, 0x103af5000 <_anon.b04a84545da479ddfbeac64712713f7a.204+0x8>
10231aac8: 91298000    	add	x0, x0, #0xa60
10231aacc: 942b6431    	bl	0x102df3b90 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10231aad0: f9400a68    	ldr	x8, [x19, #0x10]
10231aad4: 91000508    	add	x8, x8, #0x1
10231aad8: f9000a68    	str	x8, [x19, #0x10]
10231aadc: 942b696b    	bl	0x102df5088 <dyld_stub_binder+0x102df5088>
