
/private/tmp/mech-library-debit-inline-round35-20261030/workers/after:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010150c5e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu>:
10150c5e4: d10203ff    	sub	sp, sp, #0x80
10150c5e8: a90557f6    	stp	x22, x21, [sp, #0x50]
10150c5ec: a9064ff4    	stp	x20, x19, [sp, #0x60]
10150c5f0: a9077bfd    	stp	x29, x30, [sp, #0x70]
10150c5f4: 9101c3fd    	add	x29, sp, #0x70
10150c5f8: aa0803f3    	mov	x19, x8
10150c5fc: f9400008    	ldr	x8, [x0]
10150c600: f9400035    	ldr	x21, [x1]
10150c604: f9400054    	ldr	x20, [x2]
10150c608: d2800000    	mov	x0, #0x0                ; =0
10150c60c: d63f0100    	blr	x8
10150c610: b4000440    	cbz	x0, 0x10150c698 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu+0xb4>
10150c614: f9401008    	ldr	x8, [x0, #0x20]
10150c618: 92f00009    	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10150c61c: eb09011f    	cmp	x8, x9
10150c620: 540005a2    	b.hs	0x10150c6d4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu+0xf0>
10150c624: f9401408    	ldr	x8, [x0, #0x28]
10150c628: f100011f    	cmp	x8, #0x0
10150c62c: fa551104    	ccmp	x8, x21, #0x4, ne
10150c630: 540003a1    	b.ne	0x10150c6a4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu+0xc0>
10150c634: f9400aa8    	ldr	x8, [x21, #0x10]
10150c638: b5000548    	cbnz	x8, 0x10150c6e0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu+0xfc>
10150c63c: 92800008    	mov	x8, #-0x1               ; =-1
10150c640: f9000aa8    	str	x8, [x21, #0x10]
10150c644: 3dc00c00    	ldr	q0, [x0, #0x30]
10150c648: 3d8003e0    	str	q0, [sp]
10150c64c: f9402008    	ldr	x8, [x0, #0x40]
10150c650: f9000be8    	str	x8, [sp, #0x10]
10150c654: 9100a3e8    	add	x8, sp, #0x28
10150c658: 910062a0    	add	x0, x21, #0x18
10150c65c: 910003e3    	mov	x3, sp
10150c660: aa1403e1    	mov	x1, x20
10150c664: d2800002    	mov	x2, #0x0                ; =0
10150c668: 9438a90c    	bl	0x102336a98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits>
10150c66c: f9400aa8    	ldr	x8, [x21, #0x10]
10150c670: 91000508    	add	x8, x8, #0x1
10150c674: f9000aa8    	str	x8, [x21, #0x10]
10150c678: 3940a3e8    	ldrb	w8, [sp, #0x28]
10150c67c: 3cc293e0    	ldur	q0, [sp, #0x29]
10150c680: 3cc393e1    	ldur	q1, [sp, #0x39]
10150c684: ad0007e0    	stp	q0, q1, [sp]
10150c688: f94027e9    	ldr	x9, [sp, #0x48]
10150c68c: f801f3e9    	stur	x9, [sp, #0x1f]
10150c690: 7100251f    	cmp	w8, #0x9
10150c694: 540000a1    	b.ne	0x10150c6a8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs29QkOtpKx6e_8mech_gpu+0xc4>
10150c698: 90012640    	adrp	x0, 0x1039d4000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.1062+0x28>
10150c69c: 912c0000    	add	x0, x0, #0xb00
10150c6a0: 9463b474    	bl	0x102df9870 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10150c6a4: 52800008    	mov	w8, #0x0                ; =0
10150c6a8: 39000268    	strb	w8, [x19]
10150c6ac: ad4007e0    	ldp	q0, q1, [sp]
10150c6b0: 3c801260    	stur	q0, [x19, #0x1]
10150c6b4: 3c811261    	stur	q1, [x19, #0x11]
10150c6b8: f841f3e8    	ldur	x8, [sp, #0x1f]
10150c6bc: f9001268    	str	x8, [x19, #0x20]
10150c6c0: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10150c6c4: a9464ff4    	ldp	x20, x19, [sp, #0x60]
10150c6c8: a94557f6    	ldp	x22, x21, [sp, #0x50]
10150c6cc: 910203ff    	add	sp, sp, #0x80
10150c6d0: d65f03c0    	ret
10150c6d4: 90012640    	adrp	x0, 0x1039d4000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.1062+0x28>
10150c6d8: 913b6000    	add	x0, x0, #0xed8
10150c6dc: 9463b612    	bl	0x102df9f24 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10150c6e0: 90012640    	adrp	x0, 0x1039d4000 <_anon.beefbc4e3c9957de1d2068c3086b1ff4.1062+0x28>
10150c6e4: 913bc000    	add	x0, x0, #0xef0
10150c6e8: 9463b603    	bl	0x102df9ef4 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10150c6ec: f9400aa8    	ldr	x8, [x21, #0x10]
10150c6f0: 91000508    	add	x8, x8, #0x1
10150c6f4: f9000aa8    	str	x8, [x21, #0x10]
10150c6f8: 9463bb3d    	bl	0x102dfb3ec <dyld_stub_binder+0x102dfb3ec>
