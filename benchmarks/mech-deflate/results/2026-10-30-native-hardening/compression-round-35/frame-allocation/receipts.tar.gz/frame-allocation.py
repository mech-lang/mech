from pathlib import Path
import json,subprocess,hashlib,statistics
r=Path('/private/tmp/mech-library-debit-inline-round35-20261030');p=r/'primary';o=r/'frame-allocation';o.mkdir()
results=[]
for i,(case,form,steps) in enumerate((case,form,steps) for case in ['exclusive','aliased'] for form in ['original','decoded'] for steps in [0,64]):
 pair={}
 order=['before','after'] if i%2==0 else ['after','before']
 for label in order:
  binary=p/('frame-'+label);command=[str(binary),case,form,str(steps),'2','10'];q=subprocess.run(command,capture_output=True,text=True,timeout=120)
  stem=case+'-'+form+'-'+str(steps)+'-'+label;(o/(stem+'.stdout')).write_text(q.stdout);(o/(stem+'.stderr')).write_text(q.stderr)
  q.check_returncode();rows=[json.loads(l) for l in q.stdout.splitlines() if l.startswith('{')];assert len(rows)==3
  pair[label]={'command':command,'exit':q.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'observations':rows}
 b=pair['before']['observations'];a=pair['after']['observations'];assert all(x['artifact_sha256']==y['artifact_sha256'] and y['allocation_requests']<=x['allocation_requests'] and y['requested_bytes']<=x['requested_bytes'] and y['work_per_invocation']<=x['work_per_invocation'] for x,y in zip(b,a))
 row={'case':case,'form':form,'steps':steps,'allocation_requests':a[1]['allocation_requests'],'requested_bytes':a[1]['requested_bytes'],'no_request_byte_or_work_increase':True,'timing_claimed':False,**pair};results.append(row);(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(case,form,steps,row['allocation_requests'],row['requested_bytes'],flush=True)
