from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'ci';p.mkdir(exist_ok=True)
selection=['composition_tests','parent_continuation_is_single_use','native_runtime_consolidation','buffer_frames::tests::batching','buffer_frames::tests::transfer','work::retirement::tests','exhausted_retirement_generation','cleanup_effects::tests','numeric_shadow'];unit=str(r/'units-after/gpu-unit-tests')
commands=[('inventory',[unit,*selection,'--list']),('selected',[unit,*selection,'--nocapture','--test-threads=1'])]
results=[json.loads((p/'workflow-python.json').read_text())]
assert results[0]['exit']==0 and results[0]['executed_tests']==132
for label,cmd in commands:
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr)
 row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at}
 if label=='inventory':row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));assert row['listed_tests']==32,row
 if label=='selected':row['executed_tests']=int(re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout)[1]) if q.returncode==0 else None
 if label=='workflow-python':row['executed_tests']=int(re.search(r'Ran (\d+) tests',q.stderr)[1]) if q.returncode==0 else None
 results.append(row);(p/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(label,row,flush=True)
 if q.returncode:print(q.stdout[-2200:]+q.stderr[-2200:],flush=True)
 assert q.returncode==0
 if label=='selected':assert row['executed_tests']==32
 if label=='workflow-python':assert row['executed_tests']==132
subprocess.run(['python3',str(r/'archive.py'),'ci-inventory-boundary',str(p),str(r/'ci.py')],cwd=w,check=True)
