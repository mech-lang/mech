from pathlib import Path
import hashlib,json,os,shlex,shutil,subprocess,time,tomllib
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-buffer-liveness-round56-20261031');p=r/'variants/after';d=p/'dependency';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
changed=['mech_engine','mech_compute','mech_stdlib','mech_runtime']
for f in (old/'variants/after/dependency').iterdir():
 if any(f.name.startswith('lib'+n+'-') for n in changed):continue
 target=d/f.name
 if not target.exists():target.symlink_to(f)
commands={}
for line in (old/'variants/after/cargo.stderr').read_text().splitlines():
 if 'Running `' not in line or '--crate-name ' not in line:continue
 a=shlex.split(line.strip().removeprefix('Running `').removesuffix('`'));name=a[a.index('--crate-name')+1]
 if name in changed:commands[name]=a
results=[]
def run(name,cmd,env):
 t=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'environment':env,'source_head':head,'exit':q.returncode,'seconds':time.monotonic()-t,'scope':'Exact retained release flags; unchanged Core, math, syntax and external dependencies. Rebuild only changed Engine and its required dependants, serially.'};(p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');results.append(row)
 subprocess.run(['python3',str(r/'archive.py'),'build-'+name,str(p/(name+'.json')),str(p/(name+'.stdout')),str(p/(name+'.stderr')),str(r/'build-changed.py')],cwd=w,check=True)
 print('BUILD',name,q.returncode,row['seconds'],flush=True)
 if q.returncode:print(q.stderr[-8000:],flush=True)
 q.check_returncode();return row
for name in changed:
 cmd=commands[name].copy();out=p/('build-'+name);out.mkdir();cmd[cmd.index('--out-dir')+1]=str(out)
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern':
   key,f=a.split('=',1);candidate=d/Path(f).name
   if candidate.exists():cmd[i]=key+'='+str(candidate)
 cmd[1:1]=['-L','dependency='+str(d)]
 source=next(Path(x) for x in cmd if x.endswith('/src/lib.rs'));manifest=source.parent.parent;package=tomllib.loads((manifest/'Cargo.toml').read_text())['package'];env={'CARGO_MANIFEST_DIR':str(manifest),'CARGO_PKG_VERSION':package['version'],'CARGO_PKG_NAME':package['name'],'CARGO_INCREMENTAL':'0'}
 run(name,cmd,env)
 for f in out.iterdir():
  if f.suffix in {'.rlib','.rmeta'}:shutil.copy2(f,d/f.name)
libs=json.loads((old/'final-libraries.json').read_text())
for name,item in libs.items():
 if name=='mech_gpu':continue
 candidate=d/Path(item['path']).name
 if candidate.exists():item['path']=str(candidate);item['sha256']=sha(candidate)
b=json.loads((old/'final-release.json').read_text());cmd=b['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key,f=a.split('=',1);candidate=d/Path(f).name
  if candidate.exists():cmd[i]=key+'='+str(candidate)
 if a.startswith('dependency=') and '/variants/' in a:cmd[i]='dependency='+str(d)
cmd[1:1]=['-L','dependency='+str(d)];cmd[-1]=str(p/'libmech_gpu.rlib');host=run('host',cmd,b['environment']);libs['mech_gpu']={**libs['mech_gpu'],'path':str(p/'libmech_gpu.rlib'),'sha256':sha(p/'libmech_gpu.rlib')}
aux={'scope':'Frozen exact changed-dependant graph; unchanged files point to immutable R56 artifacts.','files':[{'path':str(f),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(d.iterdir()) if f.suffix in {'.rlib','.rmeta'} and f.name.startswith('libmech_')]}
for target,data in [(p/'host.json',host),(p/'libraries.json',libs),(r/'final-libraries.json',libs),(r/'final-release.json',host),(r/'auxiliary-dependencies.json',aux),(p/'build-summary.json',{'source_head':head,'builds':results})]:target.write_text(json.dumps(data,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-frozen',str(p/'host.json'),str(p/'libraries.json'),str(r/'auxiliary-dependencies.json'),str(p/'build-summary.json'),str(r/'build-changed.py')],cwd=w,check=True)
print('FROZEN',head,flush=True)
