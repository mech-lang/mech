
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152bc4c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>:
10152bc4c:     	stp	x28, x27, [sp, #-0x60]!
10152bc50:     	stp	x26, x25, [sp, #0x10]
10152bc54:     	stp	x24, x23, [sp, #0x20]
10152bc58:     	stp	x22, x21, [sp, #0x30]
10152bc5c:     	stp	x20, x19, [sp, #0x40]
10152bc60:     	stp	x29, x30, [sp, #0x50]
10152bc64:     	add	x29, sp, #0x50
10152bc68:     	sub	sp, sp, #0x4c0
10152bc6c:     	str	xzr, [sp]
10152bc70:     	ldr	x27, [x1, #0x4a0]
10152bc74:     	ldr	x8, [x27, #0x4a0]
10152bc78:     	cmp	x2, x8
10152bc7c:     	b.hs	0x10152bd48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
10152bc80:     	mov	x22, x5
10152bc84:     	mov	x23, x4
10152bc88:     	mov	x20, x2
10152bc8c:     	mov	x21, x1
10152bc90:     	add	x26, sp, #0x400
10152bc94:     	ldr	x8, [x27, #0x498]
10152bc98:     	mov	w9, #0x28               ; =40
10152bc9c:     	madd	x24, x2, x9, x8
10152bca0:     	ldr	w8, [x24]
10152bca4:     	cmp	w8, #0x1
10152bca8:     	b.gt	0x10152bd2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe0>
10152bcac:     	cbnz	w8, 0x10152bd5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x110>
10152bcb0:     	cbnz	x3, 0x10152bfb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bcb4:     	ldr	x1, [x27, #0x380]
10152bcb8:     	cmp	x20, x1
10152bcbc:     	b.hs	0x10152cfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1380>
10152bcc0:     	ldr	x8, [x27, #0x378]
10152bcc4:     	mov	w9, #0x170              ; =368
10152bcc8:     	madd	x8, x20, x9, x8
10152bccc:     	ldp	x10, x9, [x8]
10152bcd0:     	cmp	x10, #0x2
10152bcd4:     	sbcs	xzr, x9, xzr
10152bcd8:     	b.hs	0x10152c184 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x538>
10152bcdc:     	ldr	w9, [x8, #0x130]
10152bce0:     	ldr	w10, [x24, #0x4]
10152bce4:     	cmp	w9, w10
10152bce8:     	b.ne	0x10152c1a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
10152bcec:     	ldr	x9, [x8, #0x128]
10152bcf0:     	cmp	x22, x9
10152bcf4:     	b.ne	0x10152c1a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
10152bcf8:     	stp	x24, x0, [sp, #0x38]
10152bcfc:     	add	x9, x27, #0x488
10152bd00:     	ldr	x8, [x8, #0x120]
10152bd04:     	str	x8, [sp, #0x30]
10152bd08:     	lsl	x8, x22, #2
10152bd0c:     	stp	x8, x9, [sp, #0x18]
10152bd10:     	cbz	x22, 0x10152c378 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
10152bd14:     	mov	x10, #0x0               ; =0
10152bd18:     	mov	x25, #0x0               ; =0
10152bd1c:     	ldr	x24, [x21, #0x490]
10152bd20:     	ldr	x26, [sp, #0x18]
10152bd24:     	str	x24, [sp, #0x28]
10152bd28:     	b	0x10152bde8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x19c>
10152bd2c:     	cmp	w8, #0x2
10152bd30:     	b.ne	0x10152bd48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
10152bd34:     	cbz	x3, 0x10152bf9c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
10152bd38:     	cmp	x3, #0x12
10152bd3c:     	b.ne	0x10152bfb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bd40:     	cbnz	x22, 0x10152bfb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bd44:     	b	0x10152c00c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
10152bd48:     	mov	w8, #0x2                ; =2
10152bd4c:     	str	x8, [x0, #0x8]
10152bd50:     	mov	w8, #0x6                ; =6
10152bd54:     	str	w8, [x0]
10152bd58:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152bd5c:     	cmp	x3, #0x1
10152bd60:     	b.ne	0x10152bfb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bd64:     	cbnz	x22, 0x10152bfb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bd68:     	mov	x19, x0
10152bd6c:     	add	x0, sp, #0x400
10152bd70:     	mov	x1, x21
10152bd74:     	mov	x2, x20
10152bd78:     	bl	0x10153ebe8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
10152bd7c:     	ldr	w8, [sp, #0x400]
10152bd80:     	cmp	w8, #0x1
10152bd84:     	b.ne	0x10152bfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3a0>
10152bd88:     	ldr	w3, [sp, #0x404]
10152bd8c:     	ldr	w4, [sp, #0x408]
10152bd90:     	ldp	w8, w9, [x24, #0x4]
10152bd94:     	cmp	w3, w8
10152bd98:     	ccmp	w4, w9, #0x0, eq
10152bd9c:     	mov	x11, x19
10152bda0:     	b.eq	0x10152c1bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x570>
10152bda4:     	str	wzr, [x11]
10152bda8:     	mov	w8, #0xc                ; =12
10152bdac:     	strb	w8, [x11, #0x8]
10152bdb0:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152bdb4:     	add	x8, x8, #0xeb
10152bdb8:     	mov	w9, #0x2e               ; =46
10152bdbc:     	stp	x8, x9, [x11, #0x10]
10152bdc0:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152bdc4:     	ldp	q0, q1, [sp, #0x2f0]
10152bdc8:     	ldp	q2, q3, [sp, #0x310]
10152bdcc:     	stp	q2, q3, [x24, #0x20]
10152bdd0:     	stp	q0, q1, [x24]
10152bdd4:     	add	x10, x19, #0x40
10152bdd8:     	add	x25, x25, #0x1
10152bddc:     	subs	x26, x26, #0x4
10152bde0:     	ldr	x24, [sp, #0x28]
10152bde4:     	b.eq	0x10152c378 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
10152bde8:     	str	x26, [sp, #0x48]
10152bdec:     	ldr	x8, [x27, #0x360]
10152bdf0:     	ldr	x9, [sp, #0x30]
10152bdf4:     	ldr	w1, [x9, x25, lsl #2]
10152bdf8:     	cmp	x8, x1
10152bdfc:     	b.ls	0x10152cfb8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
10152be00:     	ldr	x8, [x27, #0x358]
10152be04:     	mov	w9, #0x140              ; =320
10152be08:     	umaddl	x8, w1, w9, x8
10152be0c:     	ldrb	w9, [x8, #0x124]
10152be10:     	cmp	w9, #0x7
10152be14:     	b.ne	0x10152bee0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x294>
10152be18:     	cmp	x25, x22
10152be1c:     	b.hs	0x10152cfdc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1390>
10152be20:     	ldr	x8, [x23, x25, lsl #3]
10152be24:     	cbnz	x8, 0x10152c534 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8e8>
10152be28:     	ldr	x8, [x27, #0x490]
10152be2c:     	cmp	x8, x1
10152be30:     	b.ls	0x10152be68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
10152be34:     	ldr	x8, [sp, #0x20]
10152be38:     	ldr	x8, [x8]
10152be3c:     	mov	w9, #0x18               ; =24
10152be40:     	umaddl	x8, w1, w9, x8
10152be44:     	ldr	x9, [x8]
10152be48:     	cmp	x9, #0x1
10152be4c:     	b.ne	0x10152be68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
10152be50:     	ldp	x8, x9, [x8, #0x8]
10152be54:     	adds	x8, x8, x9
10152be58:     	b.hs	0x10152be68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
10152be5c:     	ldr	x9, [x27, #0x4b0]
10152be60:     	cmp	x8, x9
10152be64:     	b.ls	0x10152bf30 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152be68:     	mov	x26, x10
10152be6c:     	add	x8, sp, #0x400
10152be70:     	add	x0, x24, #0xf0
10152be74:     	add	x2, x24, #0x2f8
10152be78:     	bl	0x10163723c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152be7c:     	ldr	x8, [sp, #0x400]
10152be80:     	add	x9, sp, #0x400
10152be84:     	ldur	q0, [x9, #0x8]
10152be88:     	ldur	q1, [x9, #0x18]
10152be8c:     	stp	q0, q1, [sp, #0x50]
10152be90:     	ldur	q0, [x9, #0x28]
10152be94:     	str	q0, [sp, #0x70]
10152be98:     	ldur	x9, [x9, #0x38]
10152be9c:     	str	x9, [sp, #0x80]
10152bea0:     	cbz	x8, 0x10152c574 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x928>
10152bea4:     	mov	w19, #0x0               ; =0
10152bea8:     	ldp	q0, q1, [sp, #0x50]
10152beac:     	add	x10, sp, #0x2f0
10152beb0:     	stur	q0, [x10, #0x8]
10152beb4:     	stur	q1, [x10, #0x18]
10152beb8:     	ldr	q0, [sp, #0x70]
10152bebc:     	stur	q0, [x10, #0x28]
10152bec0:     	ldr	x9, [sp, #0x80]
10152bec4:     	stur	x9, [x10, #0x38]
10152bec8:     	mov	x10, x26
10152becc:     	str	x8, [sp, #0x2f0]
10152bed0:     	ldr	x1, [x24, #0xd8]
10152bed4:     	cmp	x25, x1
10152bed8:     	b.lo	0x10152bf48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
10152bedc:     	b	0x10152bf88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
10152bee0:     	cmp	x25, x22
10152bee4:     	b.hs	0x10152cff0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13a4>
10152bee8:     	ldr	x8, [x23, x25, lsl #3]
10152beec:     	cmp	w9, #0x3
10152bef0:     	b.gt	0x10152bf0c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2c0>
10152bef4:     	sub	w9, w9, #0x1
10152bef8:     	cmp	w9, #0x3
10152befc:     	b.lo	0x10152bf30 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152bf00:     	cmp	x8, #0x2
10152bf04:     	b.lo	0x10152bf30 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152bf08:     	b	0x10152c5c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152bf0c:     	cmp	w9, #0x4
10152bf10:     	b.eq	0x10152bf28 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2dc>
10152bf14:     	cmp	w9, #0x5
10152bf18:     	b.ne	0x10152bf6c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x320>
10152bf1c:     	cmp	x8, #0x10, lsl #12      ; =0x10000
10152bf20:     	b.lo	0x10152bf30 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152bf24:     	b	0x10152c5c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152bf28:     	cmp	x8, #0x100
10152bf2c:     	b.hs	0x10152c5c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152bf30:     	mov	x8, #0x0                ; =0
10152bf34:     	mov	w19, #0x1               ; =1
10152bf38:     	str	x8, [sp, #0x2f0]
10152bf3c:     	ldr	x1, [x24, #0xd8]
10152bf40:     	cmp	x25, x1
10152bf44:     	b.hs	0x10152bf88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
10152bf48:     	ldr	x28, [x24, #0xd0]
10152bf4c:     	add	x24, x28, x10
10152bf50:     	ldr	x8, [x24]
10152bf54:     	mov	x19, x10
10152bf58:     	ldr	x26, [sp, #0x48]
10152bf5c:     	cbz	x8, 0x10152bdc4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
10152bf60:     	add	x0, x28, x19
10152bf64:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152bf68:     	b	0x10152bdc4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
10152bf6c:     	lsr	x8, x8, #32
10152bf70:     	cbnz	x8, 0x10152c5c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152bf74:     	mov	w19, #0x1               ; =1
10152bf78:     	str	x8, [sp, #0x2f0]
10152bf7c:     	ldr	x1, [x24, #0xd8]
10152bf80:     	cmp	x25, x1
10152bf84:     	b.lo	0x10152bf48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
10152bf88:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152bf8c:     	add	x2, x2, #0x888
10152bf90:     	mov	x0, x25
10152bf94:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152bf98:     	b	0x10152d0b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152bf9c:     	cmp	x22, #0x2
10152bfa0:     	b.ne	0x10152bfb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bfa4:     	ldp	x9, x8, [x23]
10152bfa8:     	orr	x8, x9, x8
10152bfac:     	cbz	x8, 0x10152c00c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
10152bfb0:     	str	wzr, [x0]
10152bfb4:     	mov	w8, #0xc                ; =12
10152bfb8:     	strb	w8, [x0, #0x8]
10152bfbc:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152bfc0:     	add	x8, x8, #0x21e
10152bfc4:     	mov	w9, #0x34               ; =52
10152bfc8:     	stp	x8, x9, [x0, #0x10]
10152bfcc:     	add	sp, sp, #0x4c0
10152bfd0:     	ldp	x29, x30, [sp, #0x50]
10152bfd4:     	ldp	x20, x19, [sp, #0x40]
10152bfd8:     	ldp	x22, x21, [sp, #0x30]
10152bfdc:     	ldp	x24, x23, [sp, #0x20]
10152bfe0:     	ldp	x26, x25, [sp, #0x10]
10152bfe4:     	ldp	x28, x27, [sp], #0x60
10152bfe8:     	ret
10152bfec:     	str	wzr, [x19]
10152bff0:     	mov	w8, #0xc                ; =12
10152bff4:     	str	w8, [x19, #0x8]
10152bff8:     	adrp	x8, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
10152bffc:     	add	x8, x8, #0x179
10152c000:     	mov	w9, #0x27               ; =39
10152c004:     	stp	x8, x9, [x19, #0x10]
10152c008:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c00c:     	ldr	x1, [x27, #0x380]
10152c010:     	cmp	x20, x1
10152c014:     	b.hs	0x10152d004 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13b8>
10152c018:     	stp	x24, x0, [sp, #0x38]
10152c01c:     	ldr	x8, [x27, #0x378]
10152c020:     	mov	w9, #0x170              ; =368
10152c024:     	madd	x26, x20, x9, x8
10152c028:     	cbz	x3, 0x10152c2ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6a0>
10152c02c:     	cmp	x3, #0x12
10152c030:     	b.ne	0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c034:     	ldp	x9, x8, [x26]
10152c038:     	eor	x9, x9, #0x3
10152c03c:     	orr	x8, x9, x8
10152c040:     	cbnz	x8, 0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c044:     	ldr	w22, [x26, #0x28]
10152c048:     	ldr	x8, [sp, #0x38]
10152c04c:     	ldr	w8, [x8, #0x4]
10152c050:     	cmp	w22, w8
10152c054:     	b.ne	0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c058:     	ldr	w24, [x26, #0x2c]
10152c05c:     	ldr	x8, [sp, #0x38]
10152c060:     	ldr	w8, [x8, #0x8]
10152c064:     	cmp	w24, w8
10152c068:     	b.ne	0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c06c:     	mov	x25, #0x0               ; =0
10152c070:     	mov	w28, #0x3               ; =3
10152c074:     	add	x0, x27, #0x488
10152c078:     	mov	x1, x22
10152c07c:     	bl	0x10153eb34 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
10152c080:     	cbz	x0, 0x10152c550 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
10152c084:     	ldr	x8, [sp, #0x38]
10152c088:     	ldr	x23, [x8, #0x10]
10152c08c:     	cmp	x23, x1
10152c090:     	b.hs	0x10152c550 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
10152c094:     	add	x8, x0, x23, lsl #5
10152c098:     	ldrb	w9, [x8]
10152c09c:     	cmp	w9, #0x2
10152c0a0:     	b.ne	0x10152c778 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
10152c0a4:     	ldp	x8, x9, [x8, #0x8]
10152c0a8:     	adds	x8, x8, x9
10152c0ac:     	b.hs	0x10152c778 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
10152c0b0:     	ldr	x9, [x27, #0x4b0]
10152c0b4:     	cmp	x8, x9
10152c0b8:     	b.hi	0x10152c778 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
10152c0bc:     	cmp	x28, #0x2
10152c0c0:     	sbcs	xzr, x25, xzr
10152c0c4:     	b.hs	0x10152c8e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc94>
10152c0c8:     	ldr	x1, [x26, #0x128]
10152c0cc:     	cmp	x1, #0x1
10152c0d0:     	b.ls	0x10152d07c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1430>
10152c0d4:     	ldr	x8, [x26, #0x120]
10152c0d8:     	ldr	x25, [x21, #0x490]
10152c0dc:     	ldr	w1, [x8, #0x4]
10152c0e0:     	add	x8, sp, #0x400
10152c0e4:     	add	x0, x25, #0xf0
10152c0e8:     	add	x2, x25, #0x2f8
10152c0ec:     	bl	0x10163723c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152c0f0:     	add	x8, sp, #0x400
10152c0f4:     	ldur	q0, [x8, #0x8]
10152c0f8:     	ldur	q1, [x8, #0x18]
10152c0fc:     	stp	q0, q1, [sp, #0x150]
10152c100:     	ldur	q0, [x8, #0x28]
10152c104:     	str	q0, [sp, #0x170]
10152c108:     	ldr	x8, [sp, #0x400]
10152c10c:     	ldr	x9, [sp, #0x438]
10152c110:     	str	x9, [sp, #0x180]
10152c114:     	cbz	x8, 0x10152c9e8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd9c>
10152c118:     	ldp	q0, q1, [sp, #0x150]
10152c11c:     	add	x9, sp, #0x230
10152c120:     	stur	q0, [x9, #0x48]
10152c124:     	stur	q1, [x9, #0x58]
10152c128:     	ldr	q0, [sp, #0x170]
10152c12c:     	stur	q0, [x9, #0x68]
10152c130:     	ldr	x9, [sp, #0x180]
10152c134:     	str	x9, [sp, #0x2a8]
10152c138:     	str	x8, [sp, #0x270]
10152c13c:     	ldr	x1, [x27, #0x408]
10152c140:     	cmp	x20, x1
10152c144:     	b.hs	0x10152d0a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1454>
10152c148:     	ldr	x8, [x27, #0x400]
10152c14c:     	add	x23, x8, x20, lsl #9
10152c150:     	ldp	x9, x8, [x23]
10152c154:     	eor	x9, x9, #0x2
10152c158:     	orr	x8, x9, x8
10152c15c:     	cbnz	x8, 0x10152ca08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xdbc>
10152c160:     	ldr	x10, [sp, #0x40]
10152c164:     	str	wzr, [x10]
10152c168:     	mov	w8, #0xc                ; =12
10152c16c:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
10152c170:     	add	x9, x9, #0x1c0
10152c174:     	stp	x8, x9, [x10, #0x8]
10152c178:     	mov	w8, #0x23               ; =35
10152c17c:     	str	x8, [x10, #0x18]
10152c180:     	b	0x10152ce90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
10152c184:     	str	wzr, [x0]
10152c188:     	mov	w8, #0xc                ; =12
10152c18c:     	strb	w8, [x0, #0x8]
10152c190:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152c194:     	add	x8, x8, #0xc3
10152c198:     	mov	w9, #0x28               ; =40
10152c19c:     	b	0x10152bfc8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
10152c1a0:     	str	wzr, [x0]
10152c1a4:     	mov	w8, #0xc                ; =12
10152c1a8:     	strb	w8, [x0, #0x8]
10152c1ac:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152c1b0:     	add	x8, x8, #0xa1
10152c1b4:     	mov	w9, #0x22               ; =34
10152c1b8:     	b	0x10152bfc8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
10152c1bc:     	ldp	x8, x9, [x24, #0x18]
10152c1c0:     	lsl	x9, x9, #2
10152c1c4:     	stp	x24, x11, [sp, #0x38]
10152c1c8:     	cbz	x9, 0x10152c1f8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ac>
10152c1cc:     	ldr	w10, [x8], #0x4
10152c1d0:     	sub	x9, x9, #0x4
10152c1d4:     	cmp	w10, w3
10152c1d8:     	b.ne	0x10152c1c8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x57c>
10152c1dc:     	ldr	x25, [x21, #0x490]
10152c1e0:     	add	x0, sp, #0x400
10152c1e4:     	add	x1, x25, #0x3c0
10152c1e8:     	add	x2, x27, #0x488
10152c1ec:     	add	x5, x25, #0x2f8
10152c1f0:     	bl	0x101522878 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb1_EBb_>
10152c1f4:     	b	0x10152c210 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5c4>
10152c1f8:     	ldr	x25, [x21, #0x490]
10152c1fc:     	add	x0, sp, #0x400
10152c200:     	add	x1, x25, #0x3c0
10152c204:     	add	x2, x27, #0x488
10152c208:     	add	x5, x25, #0x2f8
10152c20c:     	bl	0x101522554 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb0_EBb_>
10152c210:     	ldr	w8, [sp, #0x400]
10152c214:     	cmp	w8, #0x6
10152c218:     	b.ne	0x10152c91c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
10152c21c:     	mov	x22, #0x0               ; =0
10152c220:     	ldr	x9, [sp, #0x38]
10152c224:     	ldr	x8, [x9, #0x20]
10152c228:     	cbz	x8, 0x10152c364 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
10152c22c:     	ldr	x23, [x9, #0x18]
10152c230:     	lsl	x24, x8, #2
10152c234:     	b	0x10152c240 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5f4>
10152c238:     	subs	x24, x24, #0x4
10152c23c:     	b.eq	0x10152c364 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
10152c240:     	ldr	w20, [x23], #0x4
10152c244:     	add	x8, sp, #0x400
10152c248:     	add	x0, x25, #0x3c0
10152c24c:     	add	x1, x27, #0x4d0
10152c250:     	add	x3, x25, #0x2f8
10152c254:     	mov	x2, x20
10152c258:     	bl	0x10152b69c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
10152c25c:     	ldr	w9, [sp, #0x400]
10152c260:     	ldrb	w8, [sp, #0x404]
10152c264:     	cmp	w9, #0x6
10152c268:     	b.ne	0x10152c3c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x774>
10152c26c:     	tbnz	w8, #0x0, 0x10152c238 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
10152c270:     	add	x8, sp, #0x400
10152c274:     	add	x0, x25, #0xf0
10152c278:     	add	x2, x25, #0x2f8
10152c27c:     	mov	x1, x20
10152c280:     	bl	0x101637848 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
10152c284:     	ldrb	w8, [sp, #0x400]
10152c288:     	cmp	w8, #0x14
10152c28c:     	b.eq	0x10152c238 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
10152c290:     	ldr	q0, [sp, #0x400]
10152c294:     	ldr	q1, [sp, #0x410]
10152c298:     	stp	q0, q1, [sp, #0x2f0]
10152c29c:     	ldr	q2, [sp, #0x420]
10152c2a0:     	str	q2, [sp, #0x310]
10152c2a4:     	ldr	x8, [sp, #0x430]
10152c2a8:     	str	x8, [sp, #0x320]
10152c2ac:     	stur	q0, [x26, #0x4]
10152c2b0:     	stur	q1, [x26, #0x14]
10152c2b4:     	stur	q2, [x26, #0x24]
10152c2b8:     	stur	x8, [x26, #0x34]
10152c2bc:     	mov	w8, #0x2                ; =2
10152c2c0:     	ldr	x9, [sp, #0x40]
10152c2c4:     	str	w8, [x9]
10152c2c8:     	ldr	q0, [sp, #0x400]
10152c2cc:     	ldr	q1, [sp, #0x410]
10152c2d0:     	stur	q0, [x9, #0x4]
10152c2d4:     	stur	q1, [x9, #0x14]
10152c2d8:     	ldr	q0, [sp, #0x420]
10152c2dc:     	stur	q0, [x9, #0x24]
10152c2e0:     	ldur	q0, [x26, #0x2c]
10152c2e4:     	str	q0, [x9, #0x30]
10152c2e8:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c2ec:     	ldp	x28, x25, [x26]
10152c2f0:     	cmp	x28, #0x2
10152c2f4:     	sbcs	xzr, x25, xzr
10152c2f8:     	b.hs	0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c2fc:     	ldr	x8, [x26, #0x128]
10152c300:     	cmp	x8, #0x2
10152c304:     	b.ne	0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c308:     	ldr	x8, [x26, #0x120]
10152c30c:     	ldr	w22, [x8]
10152c310:     	ldr	x8, [sp, #0x38]
10152c314:     	ldr	w8, [x8, #0x4]
10152c318:     	cmp	w22, w8
10152c31c:     	b.ne	0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c320:     	ldr	w24, [x26, #0x130]
10152c324:     	ldr	x8, [sp, #0x38]
10152c328:     	ldr	w8, [x8, #0x8]
10152c32c:     	cmp	w24, w8
10152c330:     	b.ne	0x10152c340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c334:     	ldr	x8, [x26, #0x10]
10152c338:     	cmp	x8, #0xb
10152c33c:     	b.eq	0x10152c074 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x428>
10152c340:     	ldr	x10, [sp, #0x40]
10152c344:     	str	wzr, [x10]
10152c348:     	mov	w8, #0xc                ; =12
10152c34c:     	strb	w8, [x10, #0x8]
10152c350:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152c354:     	add	x8, x8, #0x1f3
10152c358:     	mov	w9, #0x2b               ; =43
10152c35c:     	stp	x8, x9, [x10, #0x10]
10152c360:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c364:     	ldr	x9, [sp, #0x40]
10152c368:     	stp	x22, x21, [x9, #0x8]
10152c36c:     	mov	w8, #0x6                ; =6
10152c370:     	str	w8, [x9]
10152c374:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c378:     	ldr	x1, [x27, #0x408]
10152c37c:     	cmp	x20, x1
10152c380:     	b.hs	0x10152d014 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13c8>
10152c384:     	ldr	x8, [x27, #0x400]
10152c388:     	add	x28, x8, x20, lsl #9
10152c38c:     	ldp	x9, x8, [x28]
10152c390:     	eor	x9, x9, #0x2
10152c394:     	orr	x8, x9, x8
10152c398:     	ldr	x19, [sp, #0x40]
10152c39c:     	cbnz	x8, 0x10152c3f8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7ac>
10152c3a0:     	str	wzr, [x19]
10152c3a4:     	mov	w8, #0xc                ; =12
10152c3a8:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
10152c3ac:     	add	x9, x9, #0x156
10152c3b0:     	stp	x8, x9, [x19, #0x8]
10152c3b4:     	mov	w8, #0x23               ; =35
10152c3b8:     	str	x8, [x19, #0x18]
10152c3bc:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c3c0:     	ldur	q0, [x26, #0x15]
10152c3c4:     	ldr	x10, [sp, #0x40]
10152c3c8:     	stur	q0, [x10, #0x15]
10152c3cc:     	ldur	q0, [x26, #0x25]
10152c3d0:     	stur	q0, [x10, #0x25]
10152c3d4:     	ldur	q0, [x26, #0x35]
10152c3d8:     	stur	q0, [x10, #0x35]
10152c3dc:     	ldr	q0, [sp, #0x440]
10152c3e0:     	str	q0, [x10, #0x40]
10152c3e4:     	ldur	q0, [x26, #0x5]
10152c3e8:     	stur	q0, [x10, #0x5]
10152c3ec:     	str	w9, [x10]
10152c3f0:     	strb	w8, [x10, #0x4]
10152c3f4:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c3f8:     	add	x24, sp, #0x400
10152c3fc:     	add	x8, sp, #0x400
10152c400:     	mov	x0, x21
10152c404:     	mov	w1, #0x0                ; =0
10152c408:     	bl	0x10154b014 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10152c40c:     	ldr	w8, [sp, #0x400]
10152c410:     	tbz	w8, #0x0, 0x10152c444 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7f8>
10152c414:     	ldur	q0, [x24, #0x18]
10152c418:     	ldur	q1, [x24, #0x28]
10152c41c:     	ldur	q2, [x24, #0x38]
10152c420:     	stp	q1, q2, [sp, #0x310]
10152c424:     	ldur	q3, [x24, #0x48]
10152c428:     	str	q3, [sp, #0x330]
10152c42c:     	ldur	q4, [x24, #0x8]
10152c430:     	stp	q4, q0, [sp, #0x2f0]
10152c434:     	stp	q1, q2, [x19, #0x20]
10152c438:     	str	q3, [x19, #0x40]
10152c43c:     	stp	q4, q0, [x19]
10152c440:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c444:     	ldr	x10, [sp, #0x30]
10152c448:     	ldr	x8, [sp, #0x18]
10152c44c:     	add	x8, x10, x8
10152c450:     	ldur	q0, [x24, #0x48]
10152c454:     	ldur	q1, [x24, #0x58]
10152c458:     	stp	q0, q1, [sp, #0x330]
10152c45c:     	ldur	x9, [x24, #0x68]
10152c460:     	str	x9, [sp, #0x350]
10152c464:     	ldur	q2, [x24, #0x8]
10152c468:     	str	q2, [sp, #0x2f0]
10152c46c:     	ldur	q3, [x24, #0x38]
10152c470:     	ldur	q4, [x24, #0x18]
10152c474:     	ldur	q5, [x24, #0x28]
10152c478:     	stp	q2, q4, [sp, #0x90]
10152c47c:     	stp	q5, q3, [sp, #0xb0]
10152c480:     	str	x9, [sp, #0xf0]
10152c484:     	stp	q0, q1, [sp, #0xd0]
10152c488:     	str	x10, [sp, #0x400]
10152c48c:     	str	x8, [sp, #0x408]
10152c490:     	add	x0, sp, #0x400
10152c494:     	add	x1, x27, #0x488
10152c498:     	bl	0x101527d88 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>
10152c49c:     	ldr	x25, [x21, #0x490]
10152c4a0:     	ldr	x2, [x25, #0xd8]
10152c4a4:     	cmp	x22, x2
10152c4a8:     	add	x26, sp, #0x400
10152c4ac:     	tbz	w0, #0x0, 0x10152c5e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x998>
10152c4b0:     	b.hi	0x10152cf4c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1300>
10152c4b4:     	ldr	x1, [x25, #0xd0]
10152c4b8:     	ldp	q0, q1, [x21, #0x80]
10152c4bc:     	str	q0, [sp, #0x480]
10152c4c0:     	str	q1, [sp, #0x490]
10152c4c4:     	ldr	x8, [x21, #0xa0]
10152c4c8:     	str	x8, [sp, #0x4a0]
10152c4cc:     	ldp	q0, q1, [x21, #0x40]
10152c4d0:     	str	q0, [sp, #0x440]
10152c4d4:     	str	q1, [sp, #0x450]
10152c4d8:     	ldp	q1, q0, [x21, #0x60]
10152c4dc:     	str	q0, [sp, #0x470]
10152c4e0:     	str	q1, [sp, #0x460]
10152c4e4:     	ldp	q0, q1, [x21]
10152c4e8:     	str	q0, [sp, #0x400]
10152c4ec:     	str	q1, [sp, #0x410]
10152c4f0:     	ldp	q1, q0, [x21, #0x20]
10152c4f4:     	add	x8, x25, #0x3b8
10152c4f8:     	str	q0, [sp, #0x430]
10152c4fc:     	str	q1, [sp, #0x420]
10152c500:     	add	x9, sp, #0x90
10152c504:     	stp	x8, x9, [sp, #0x8]
10152c508:     	add	x9, sp, #0x400
10152c50c:     	str	x9, [sp]
10152c510:     	add	x8, sp, #0xf8
10152c514:     	add	x5, x25, #0x3c0
10152c518:     	mov	x0, x28
10152c51c:     	mov	x2, x22
10152c520:     	mov	x3, x23
10152c524:     	mov	x4, x22
10152c528:     	mov	x6, #0x0                ; =0
10152c52c:     	bl	0x10150da44 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>
10152c530:     	b	0x10152c654 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa08>
10152c534:     	ldr	x10, [sp, #0x40]
10152c538:     	str	wzr, [x10]
10152c53c:     	mov	w8, #0xc                ; =12
10152c540:     	strb	w8, [x10, #0x8]
10152c544:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152c548:     	add	x8, x8, #0x4c
10152c54c:     	b	0x10152c358 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x70c>
10152c550:     	ldr	x10, [sp, #0x40]
10152c554:     	str	wzr, [x10]
10152c558:     	mov	w8, #0xc                ; =12
10152c55c:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
10152c560:     	add	x9, x9, #0x1a0
10152c564:     	stp	x8, x9, [x10, #0x8]
10152c568:     	mov	w8, #0x20               ; =32
10152c56c:     	str	x8, [x10, #0x18]
10152c570:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c574:     	ldp	q0, q1, [sp, #0x50]
10152c578:     	add	x9, sp, #0x400
10152c57c:     	stur	q0, [x9, #0x4]
10152c580:     	stur	q1, [x9, #0x14]
10152c584:     	ldr	q0, [sp, #0x70]
10152c588:     	stur	q0, [x9, #0x24]
10152c58c:     	ldr	x8, [sp, #0x80]
10152c590:     	stur	x8, [x9, #0x34]
10152c594:     	ldr	q0, [sp, #0x400]
10152c598:     	ldr	q1, [sp, #0x410]
10152c59c:     	ldr	x10, [sp, #0x40]
10152c5a0:     	stur	q0, [x10, #0x4]
10152c5a4:     	mov	w8, #0x2                ; =2
10152c5a8:     	str	w8, [x10]
10152c5ac:     	stur	q1, [x10, #0x14]
10152c5b0:     	ldr	q0, [sp, #0x420]
10152c5b4:     	stur	q0, [x10, #0x24]
10152c5b8:     	ldur	q0, [x9, #0x2c]
10152c5bc:     	str	q0, [x10, #0x30]
10152c5c0:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c5c4:     	ldr	x10, [sp, #0x40]
10152c5c8:     	str	wzr, [x10]
10152c5cc:     	mov	w8, #0xc                ; =12
10152c5d0:     	strb	w8, [x10, #0x8]
10152c5d4:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152c5d8:     	add	x8, x8, #0x77
10152c5dc:     	mov	w9, #0x2a               ; =42
10152c5e0:     	b	0x10152c35c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
10152c5e4:     	b.hi	0x10152cf60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1314>
10152c5e8:     	ldr	x1, [x25, #0xd0]
10152c5ec:     	ldp	q0, q1, [x21, #0x80]
10152c5f0:     	str	q0, [sp, #0x480]
10152c5f4:     	str	q1, [sp, #0x490]
10152c5f8:     	ldr	x8, [x21, #0xa0]
10152c5fc:     	str	x8, [sp, #0x4a0]
10152c600:     	ldp	q0, q1, [x21, #0x40]
10152c604:     	str	q0, [sp, #0x440]
10152c608:     	str	q1, [sp, #0x450]
10152c60c:     	ldp	q1, q0, [x21, #0x60]
10152c610:     	str	q0, [sp, #0x470]
10152c614:     	str	q1, [sp, #0x460]
10152c618:     	ldp	q0, q1, [x21]
10152c61c:     	str	q0, [sp, #0x400]
10152c620:     	str	q1, [sp, #0x410]
10152c624:     	ldp	q1, q0, [x21, #0x20]
10152c628:     	str	q0, [sp, #0x430]
10152c62c:     	str	q1, [sp, #0x420]
10152c630:     	add	x8, sp, #0xf8
10152c634:     	add	x5, sp, #0x400
10152c638:     	add	x6, x25, #0x3b8
10152c63c:     	add	x7, sp, #0x90
10152c640:     	mov	x0, x28
10152c644:     	mov	x2, x22
10152c648:     	mov	x3, x23
10152c64c:     	mov	x4, x22
10152c650:     	bl	0x10253c140 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_frame_words>
10152c654:     	ldrb	w8, [sp, #0xf8]
10152c658:     	cmp	w8, #0x2e
10152c65c:     	b.ne	0x10152c6fc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xab0>
10152c660:     	ldr	x2, [x25, #0xd8]
10152c664:     	cmp	x22, x2
10152c668:     	b.hi	0x10152cf74 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1328>
10152c66c:     	ldr	x6, [x25, #0xd0]
10152c670:     	ldp	x4, x8, [sp, #0x30]
10152c674:     	ldr	w3, [x8, #0x4]
10152c678:     	add	x8, x25, #0x2f8
10152c67c:     	stp	x22, x8, [sp, #0x8]
10152c680:     	add	x0, sp, #0x400
10152c684:     	add	x1, x25, #0x3c0
10152c688:     	add	x2, x27, #0x488
10152c68c:     	str	x23, [sp]
10152c690:     	mov	x5, x22
10152c694:     	mov	x7, x22
10152c698:     	bl	0x10152af9c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4pack>
10152c69c:     	ldr	x2, [x25, #0xd8]
10152c6a0:     	cmp	x22, x2
10152c6a4:     	b.hi	0x10152cfa0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1354>
10152c6a8:     	ldr	x0, [x25, #0xd0]
10152c6ac:     	str	xzr, [sp, #0x2f0]
10152c6b0:     	add	x2, sp, #0x2f0
10152c6b4:     	mov	x1, x22
10152c6b8:     	bl	0x101613448 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
10152c6bc:     	ldr	w8, [sp, #0x400]
10152c6c0:     	cmp	w8, #0x6
10152c6c4:     	b.eq	0x10152c21c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d0>
10152c6c8:     	ldur	q0, [x26, #0x14]
10152c6cc:     	ldr	x9, [sp, #0x40]
10152c6d0:     	stur	q0, [x9, #0x14]
10152c6d4:     	ldur	q0, [x26, #0x24]
10152c6d8:     	stur	q0, [x9, #0x24]
10152c6dc:     	ldur	q0, [x26, #0x34]
10152c6e0:     	stur	q0, [x9, #0x34]
10152c6e4:     	ldr	q0, [sp, #0x440]
10152c6e8:     	str	q0, [x9, #0x40]
10152c6ec:     	ldur	q0, [x26, #0x4]
10152c6f0:     	stur	q0, [x9, #0x4]
10152c6f4:     	str	w8, [x9]
10152c6f8:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c6fc:     	ldr	x2, [x25, #0xd8]
10152c700:     	cmp	x22, x2
10152c704:     	b.hi	0x10152cf88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x133c>
10152c708:     	ldr	x0, [x25, #0xd0]
10152c70c:     	str	xzr, [sp, #0x400]
10152c710:     	add	x2, sp, #0x400
10152c714:     	mov	x1, x22
10152c718:     	bl	0x101613448 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
10152c71c:     	ldr	x1, [x27, #0x380]
10152c720:     	cmp	x20, x1
10152c724:     	b.hs	0x10152d024 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13d8>
10152c728:     	ldr	x8, [x27, #0x378]
10152c72c:     	mov	w9, #0x170              ; =368
10152c730:     	madd	x8, x20, x9, x8
10152c734:     	ldr	w9, [x8, #0x158]
10152c738:     	add	x10, sp, #0xf8
10152c73c:     	add	x8, x8, #0x148
10152c740:     	ldr	q0, [x8]
10152c744:     	ldp	q1, q2, [x10]
10152c748:     	ldr	x11, [sp, #0x40]
10152c74c:     	stur	q1, [x11, #0x18]
10152c750:     	stur	q2, [x11, #0x28]
10152c754:     	ldr	q1, [x10, #0x20]
10152c758:     	stur	q1, [x11, #0x38]
10152c75c:     	ldr	x8, [sp, #0x128]
10152c760:     	str	x8, [x11, #0x48]
10152c764:     	mov	w8, #0x3                ; =3
10152c768:     	str	w8, [x11]
10152c76c:     	stur	q0, [x11, #0x4]
10152c770:     	str	w9, [x11, #0x14]
10152c774:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c778:     	ldr	x25, [x21, #0x490]
10152c77c:     	ldr	x1, [x25, #0x3c0]
10152c780:     	add	x0, sp, #0x400
10152c784:     	add	x2, x27, #0x488
10152c788:     	add	x5, x25, #0x2f8
10152c78c:     	mov	x3, x22
10152c790:     	mov	x4, x23
10152c794:     	bl	0x10152b904 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames7project>
10152c798:     	ldr	w8, [sp, #0x400]
10152c79c:     	cmp	w8, #0x6
10152c7a0:     	b.ne	0x10152c894 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc48>
10152c7a4:     	add	x8, sp, #0x400
10152c7a8:     	ldur	q0, [x8, #0x38]
10152c7ac:     	ldur	q1, [x8, #0x28]
10152c7b0:     	ldur	q2, [x8, #0x18]
10152c7b4:     	ldur	q3, [x8, #0x8]
10152c7b8:     	stp	q3, q2, [sp, #0x230]
10152c7bc:     	stp	q1, q0, [sp, #0x250]
10152c7c0:     	ldp	x9, x8, [x26]
10152c7c4:     	mov	w10, #0x1               ; =1
10152c7c8:     	cmp	x10, x9
10152c7cc:     	ngcs	xzr, x8
10152c7d0:     	b.lo	0x10152cc7c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1030>
10152c7d4:     	ldr	x8, [x26, #0x128]
10152c7d8:     	cmp	x8, #0x2
10152c7dc:     	b.lo	0x10152d044 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13f8>
10152c7e0:     	ldr	x8, [x26, #0x120]
10152c7e4:     	ldr	w1, [x8, #0x4]
10152c7e8:     	mov	w22, #0x1               ; =1
10152c7ec:     	add	x8, sp, #0x400
10152c7f0:     	add	x0, x25, #0xf0
10152c7f4:     	add	x2, x25, #0x2f8
10152c7f8:     	bl	0x10163723c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152c7fc:     	add	x8, sp, #0x400
10152c800:     	ldur	q0, [x8, #0x8]
10152c804:     	ldur	q1, [x8, #0x18]
10152c808:     	stp	q0, q1, [sp, #0x2b0]
10152c80c:     	ldur	q0, [x8, #0x28]
10152c810:     	str	q0, [sp, #0x2d0]
10152c814:     	ldr	x8, [sp, #0x400]
10152c818:     	ldr	x9, [sp, #0x438]
10152c81c:     	str	x9, [sp, #0x2e0]
10152c820:     	cbz	x8, 0x10152c944 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcf8>
10152c824:     	ldp	q0, q1, [sp, #0x2b0]
10152c828:     	add	x9, sp, #0x230
10152c82c:     	stur	q0, [x9, #0x48]
10152c830:     	stur	q1, [x9, #0x58]
10152c834:     	ldr	q0, [sp, #0x2d0]
10152c838:     	add	x26, sp, #0x230
10152c83c:     	stur	q0, [x9, #0x68]
10152c840:     	ldr	x9, [sp, #0x2e0]
10152c844:     	str	x9, [sp, #0x2a8]
10152c848:     	str	x8, [sp, #0x270]
10152c84c:     	ldr	x1, [x27, #0x408]
10152c850:     	cmp	x20, x1
10152c854:     	b.hs	0x10152d08c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1440>
10152c858:     	ldr	x8, [x27, #0x400]
10152c85c:     	add	x22, x8, x20, lsl #9
10152c860:     	ldp	x9, x8, [x22]
10152c864:     	eor	x9, x9, #0x2
10152c868:     	orr	x8, x9, x8
10152c86c:     	cbnz	x8, 0x10152c994 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd48>
10152c870:     	ldr	x10, [sp, #0x40]
10152c874:     	str	wzr, [x10]
10152c878:     	mov	w8, #0xc                ; =12
10152c87c:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
10152c880:     	add	x9, x9, #0x1e3
10152c884:     	stp	x8, x9, [x10, #0x8]
10152c888:     	mov	w8, #0x2a               ; =42
10152c88c:     	str	x8, [x10, #0x18]
10152c890:     	b	0x10152ce1c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
10152c894:     	add	x10, sp, #0x400
10152c898:     	ldur	q0, [x10, #0x14]
10152c89c:     	ldur	q1, [x10, #0x24]
10152c8a0:     	ldur	q2, [x10, #0x34]
10152c8a4:     	stp	q1, q2, [sp, #0x310]
10152c8a8:     	ldr	w9, [sp, #0x444]
10152c8ac:     	str	w9, [sp, #0x330]
10152c8b0:     	ldur	q3, [x10, #0x4]
10152c8b4:     	stp	q3, q0, [sp, #0x2f0]
10152c8b8:     	ldr	x10, [sp, #0x448]
10152c8bc:     	ldr	x11, [sp, #0x40]
10152c8c0:     	stur	q0, [x11, #0x14]
10152c8c4:     	stur	q1, [x11, #0x24]
10152c8c8:     	stur	q2, [x11, #0x34]
10152c8cc:     	str	w9, [x11, #0x44]
10152c8d0:     	stur	q3, [x11, #0x4]
10152c8d4:     	str	w8, [x11]
10152c8d8:     	str	x10, [x11, #0x48]
10152c8dc:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c8e0:     	ldr	x25, [x21, #0x490]
10152c8e4:     	add	x0, sp, #0x400
10152c8e8:     	add	x1, x25, #0x3c0
10152c8ec:     	add	x2, x27, #0x488
10152c8f0:     	add	x6, x25, #0x2f8
10152c8f4:     	mov	x3, x22
10152c8f8:     	mov	x4, x23
10152c8fc:     	mov	x5, x24
10152c900:     	bl	0x10152a330 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames17project_composite>
10152c904:     	ldr	w8, [sp, #0x400]
10152c908:     	cmp	w8, #0x6
10152c90c:     	b.ne	0x10152c91c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
10152c910:     	mov	x22, #0x0               ; =0
10152c914:     	add	x26, sp, #0x400
10152c918:     	b	0x10152c220 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10152c91c:     	ldr	q0, [sp, #0x420]
10152c920:     	ldr	q1, [sp, #0x430]
10152c924:     	ldr	x8, [sp, #0x40]
10152c928:     	stp	q0, q1, [x8, #0x20]
10152c92c:     	ldr	q0, [sp, #0x440]
10152c930:     	str	q0, [x8, #0x40]
10152c934:     	ldr	q0, [sp, #0x410]
10152c938:     	ldr	q1, [sp, #0x400]
10152c93c:     	stp	q1, q0, [x8]
10152c940:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c944:     	ldp	q0, q1, [sp, #0x2b0]
10152c948:     	add	x9, sp, #0x400
10152c94c:     	stur	q0, [x9, #0x4]
10152c950:     	stur	q1, [x9, #0x14]
10152c954:     	ldr	q0, [sp, #0x2d0]
10152c958:     	stur	q0, [x9, #0x24]
10152c95c:     	ldr	x8, [sp, #0x2e0]
10152c960:     	stur	x8, [x9, #0x34]
10152c964:     	ldr	q0, [sp, #0x400]
10152c968:     	ldr	q1, [sp, #0x410]
10152c96c:     	ldr	x10, [sp, #0x40]
10152c970:     	stur	q0, [x10, #0x4]
10152c974:     	mov	w8, #0x2                ; =2
10152c978:     	str	w8, [x10]
10152c97c:     	stur	q1, [x10, #0x14]
10152c980:     	ldr	q0, [sp, #0x420]
10152c984:     	stur	q0, [x10, #0x24]
10152c988:     	ldur	q0, [x9, #0x2c]
10152c98c:     	str	q0, [x10, #0x30]
10152c990:     	b	0x10152ce28 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11dc>
10152c994:     	add	x24, sp, #0x400
10152c998:     	add	x8, sp, #0x400
10152c99c:     	mov	x0, x21
10152c9a0:     	mov	w1, #0x0                ; =0
10152c9a4:     	bl	0x10154b014 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10152c9a8:     	ldr	x8, [sp, #0x400]
10152c9ac:     	cmp	x8, #0x1
10152c9b0:     	b.ne	0x10152ca5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe10>
10152c9b4:     	ldur	q0, [x24, #0x18]
10152c9b8:     	ldur	q1, [x24, #0x28]
10152c9bc:     	ldur	q2, [x24, #0x38]
10152c9c0:     	stp	q1, q2, [sp, #0x310]
10152c9c4:     	ldur	q3, [x24, #0x48]
10152c9c8:     	str	q3, [sp, #0x330]
10152c9cc:     	ldur	q4, [x24, #0x8]
10152c9d0:     	stp	q4, q0, [sp, #0x2f0]
10152c9d4:     	ldr	x8, [sp, #0x40]
10152c9d8:     	stp	q1, q2, [x8, #0x20]
10152c9dc:     	str	q3, [x8, #0x40]
10152c9e0:     	stp	q4, q0, [x8]
10152c9e4:     	b	0x10152ce1c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
10152c9e8:     	ldp	q0, q1, [sp, #0x150]
10152c9ec:     	add	x9, sp, #0x400
10152c9f0:     	stur	q0, [x9, #0x4]
10152c9f4:     	stur	q1, [x9, #0x14]
10152c9f8:     	ldr	q0, [sp, #0x170]
10152c9fc:     	stur	q0, [x9, #0x24]
10152ca00:     	ldr	x8, [sp, #0x180]
10152ca04:     	b	0x10152c590 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x944>
10152ca08:     	add	x24, sp, #0x400
10152ca0c:     	add	x8, sp, #0x400
10152ca10:     	mov	x0, x21
10152ca14:     	mov	w1, #0x0                ; =0
10152ca18:     	bl	0x10154b014 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10152ca1c:     	ldr	x8, [sp, #0x400]
10152ca20:     	cmp	x8, #0x1
10152ca24:     	b.ne	0x10152cb08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xebc>
10152ca28:     	ldur	q0, [x24, #0x18]
10152ca2c:     	ldur	q1, [x24, #0x28]
10152ca30:     	ldur	q2, [x24, #0x38]
10152ca34:     	stp	q1, q2, [sp, #0x310]
10152ca38:     	ldur	q3, [x24, #0x48]
10152ca3c:     	str	q3, [sp, #0x330]
10152ca40:     	ldur	q4, [x24, #0x8]
10152ca44:     	stp	q4, q0, [sp, #0x2f0]
10152ca48:     	ldr	x8, [sp, #0x40]
10152ca4c:     	stp	q1, q2, [x8, #0x20]
10152ca50:     	str	q3, [x8, #0x40]
10152ca54:     	stp	q4, q0, [x8]
10152ca58:     	b	0x10152ce90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
10152ca5c:     	ldur	q0, [x24, #0x48]
10152ca60:     	ldur	q1, [x24, #0x58]
10152ca64:     	stp	q0, q1, [sp, #0x330]
10152ca68:     	ldur	x8, [x24, #0x68]
10152ca6c:     	str	x8, [sp, #0x350]
10152ca70:     	ldur	q2, [x24, #0x8]
10152ca74:     	ldur	q3, [x24, #0x18]
10152ca78:     	stp	q2, q3, [sp, #0x2f0]
10152ca7c:     	ldur	q4, [x24, #0x38]
10152ca80:     	ldur	q5, [x24, #0x28]
10152ca84:     	stp	q2, q3, [sp, #0x360]
10152ca88:     	stp	q5, q4, [sp, #0x380]
10152ca8c:     	str	x8, [sp, #0x3c0]
10152ca90:     	stp	q0, q1, [sp, #0x3a0]
10152ca94:     	ldr	x8, [sp, #0x230]
10152ca98:     	cbz	x8, 0x10152cbf0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfa4>
10152ca9c:     	ldp	q0, q1, [x21, #0x80]
10152caa0:     	str	q0, [sp, #0x480]
10152caa4:     	str	q1, [sp, #0x490]
10152caa8:     	ldr	x8, [x21, #0xa0]
10152caac:     	str	x8, [sp, #0x4a0]
10152cab0:     	ldp	q0, q1, [x21, #0x40]
10152cab4:     	str	q0, [sp, #0x440]
10152cab8:     	str	q1, [sp, #0x450]
10152cabc:     	ldp	q1, q0, [x21, #0x60]
10152cac0:     	str	q0, [sp, #0x470]
10152cac4:     	str	q1, [sp, #0x460]
10152cac8:     	ldp	q0, q1, [x21]
10152cacc:     	str	q0, [sp, #0x400]
10152cad0:     	str	q1, [sp, #0x410]
10152cad4:     	ldp	q1, q0, [x21, #0x20]
10152cad8:     	str	q0, [sp, #0x430]
10152cadc:     	str	q1, [sp, #0x420]
10152cae0:     	add	x8, sp, #0x3c8
10152cae4:     	add	x1, sp, #0x270
10152cae8:     	add	x3, sp, #0x230
10152caec:     	add	x4, sp, #0x400
10152caf0:     	add	x5, x25, #0x3b8
10152caf4:     	add	x6, sp, #0x360
10152caf8:     	mov	x0, x22
10152cafc:     	mov	x2, x23
10152cb00:     	bl	0x10253c4e4 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall25admit_buffer_record_field>
10152cb04:     	b	0x10152cc64 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1018>
10152cb08:     	ldur	q0, [x24, #0x48]
10152cb0c:     	ldur	q1, [x24, #0x58]
10152cb10:     	stp	q0, q1, [sp, #0x330]
10152cb14:     	ldur	x8, [x24, #0x68]
10152cb18:     	str	x8, [sp, #0x350]
10152cb1c:     	ldur	q2, [x24, #0x8]
10152cb20:     	ldur	q3, [x24, #0x18]
10152cb24:     	stp	q2, q3, [sp, #0x2f0]
10152cb28:     	ldur	q4, [x24, #0x38]
10152cb2c:     	ldur	q5, [x24, #0x28]
10152cb30:     	stp	q2, q3, [sp, #0x190]
10152cb34:     	stp	q5, q4, [sp, #0x1b0]
10152cb38:     	str	x8, [sp, #0x1f0]
10152cb3c:     	stp	q0, q1, [sp, #0x1d0]
10152cb40:     	ldr	x8, [sp, #0x38]
10152cb44:     	ldr	x7, [x8, #0x10]
10152cb48:     	ldp	q0, q1, [x21, #0x80]
10152cb4c:     	str	q0, [sp, #0x480]
10152cb50:     	str	q1, [sp, #0x490]
10152cb54:     	ldr	x8, [x21, #0xa0]
10152cb58:     	str	x8, [sp, #0x4a0]
10152cb5c:     	ldp	q0, q1, [x21, #0x40]
10152cb60:     	str	q0, [sp, #0x440]
10152cb64:     	str	q1, [sp, #0x450]
10152cb68:     	ldp	q1, q0, [x21, #0x60]
10152cb6c:     	str	q0, [sp, #0x470]
10152cb70:     	str	q1, [sp, #0x460]
10152cb74:     	ldp	q0, q1, [x21]
10152cb78:     	str	q0, [sp, #0x400]
10152cb7c:     	str	q1, [sp, #0x410]
10152cb80:     	ldp	q1, q0, [x21, #0x20]
10152cb84:     	add	x8, x25, #0x3b8
10152cb88:     	str	q0, [sp, #0x430]
10152cb8c:     	str	q1, [sp, #0x420]
10152cb90:     	add	x9, sp, #0x190
10152cb94:     	stp	x8, x9, [sp, #0x8]
10152cb98:     	add	x9, sp, #0x400
10152cb9c:     	adrp	x1, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152cba0:     	add	x1, x1, #0x120
10152cba4:     	str	x9, [sp]
10152cba8:     	add	x8, sp, #0x1f8
10152cbac:     	add	x5, x25, #0x3c0
10152cbb0:     	add	x6, sp, #0x270
10152cbb4:     	adrp	x3, 0x107552000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.933+0x8e1>
10152cbb8:     	add	x3, x3, #0x590
10152cbbc:     	mov	x0, x23
10152cbc0:     	mov	w2, #0x2                ; =2
10152cbc4:     	mov	w4, #0x2                ; =2
10152cbc8:     	bl	0x10150dc8c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>
10152cbcc:     	ldrb	w8, [sp, #0x1f8]
10152cbd0:     	cmp	w8, #0x2e
10152cbd4:     	b.ne	0x10152ce54 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1208>
10152cbd8:     	add	x0, sp, #0x270
10152cbdc:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cbe0:     	ldr	x8, [sp, #0x38]
10152cbe4:     	ldr	x23, [x8, #0x10]
10152cbe8:     	ldr	w24, [x8, #0x8]
10152cbec:     	b	0x10152c8e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc98>
10152cbf0:     	ldr	w3, [sp, #0x248]
10152cbf4:     	ldur	q0, [x26, #0x8]
10152cbf8:     	str	q0, [sp, #0x2f0]
10152cbfc:     	ldp	q0, q1, [x21, #0x80]
10152cc00:     	str	q0, [sp, #0x480]
10152cc04:     	str	q1, [sp, #0x490]
10152cc08:     	ldr	x8, [x21, #0xa0]
10152cc0c:     	str	x8, [sp, #0x4a0]
10152cc10:     	ldp	q0, q1, [x21, #0x40]
10152cc14:     	str	q0, [sp, #0x440]
10152cc18:     	str	q1, [sp, #0x450]
10152cc1c:     	ldp	q1, q0, [x21, #0x60]
10152cc20:     	str	q0, [sp, #0x470]
10152cc24:     	str	q1, [sp, #0x460]
10152cc28:     	ldp	q0, q1, [x21]
10152cc2c:     	str	q0, [sp, #0x400]
10152cc30:     	str	q1, [sp, #0x410]
10152cc34:     	ldp	q1, q0, [x21, #0x20]
10152cc38:     	str	q0, [sp, #0x430]
10152cc3c:     	str	q1, [sp, #0x420]
10152cc40:     	add	x8, sp, #0x3c8
10152cc44:     	add	x1, sp, #0x270
10152cc48:     	add	x4, sp, #0x2f0
10152cc4c:     	add	x5, sp, #0x400
10152cc50:     	add	x6, x25, #0x3b8
10152cc54:     	add	x7, sp, #0x360
10152cc58:     	mov	x0, x22
10152cc5c:     	mov	x2, x23
10152cc60:     	bl	0x10253c19c <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_record_word>
10152cc64:     	ldrb	w8, [sp, #0x3c8]
10152cc68:     	cmp	w8, #0x2e
10152cc6c:     	b.ne	0x10152cde0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1194>
10152cc70:     	mov	w22, #0x1               ; =1
10152cc74:     	add	x0, sp, #0x270
10152cc78:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cc7c:     	ldr	x8, [x27, #0x360]
10152cc80:     	ldr	x9, [sp, #0x38]
10152cc84:     	ldr	w1, [x9, #0x8]
10152cc88:     	cmp	x8, x1
10152cc8c:     	b.ls	0x10152d038 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13ec>
10152cc90:     	ldr	x8, [x27, #0x358]
10152cc94:     	mov	w9, #0x140              ; =320
10152cc98:     	umaddl	x9, w1, w9, x8
10152cc9c:     	ldr	x8, [sp, #0x230]
10152cca0:     	cbz	x8, 0x10152cd84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1138>
10152cca4:     	ldp	q0, q1, [sp, #0x230]
10152cca8:     	str	q0, [sp, #0x400]
10152ccac:     	str	q1, [sp, #0x410]
10152ccb0:     	ldp	q0, q1, [sp, #0x250]
10152ccb4:     	str	q0, [sp, #0x420]
10152ccb8:     	str	q1, [sp, #0x430]
10152ccbc:     	ldr	x8, [x27, #0x448]
10152ccc0:     	cmp	x8, x1
10152ccc4:     	b.ls	0x10152d064 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1418>
10152ccc8:     	ldr	x8, [x27, #0x440]
10152cccc:     	mov	w10, #0x24              ; =36
10152ccd0:     	umaddl	x8, w1, w10, x8
10152ccd4:     	ldr	w10, [sp, #0x438]
10152ccd8:     	ldr	w11, [x8, #0x20]
10152ccdc:     	cmp	w10, w11
10152cce0:     	b.ne	0x10152cd54 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
10152cce4:     	ldp	q0, q1, [sp, #0x240]
10152cce8:     	stp	q0, q1, [sp, #0x2f0]
10152ccec:     	ldr	x10, [sp, #0x2f0]
10152ccf0:     	ldr	x11, [sp, #0x2f8]
10152ccf4:     	ldp	x12, x13, [x8]
10152ccf8:     	ldr	x14, [sp, #0x300]
10152ccfc:     	ldr	x15, [sp, #0x308]
10152cd00:     	ldp	x16, x8, [x8, #0x10]
10152cd04:     	cmp	x10, x12
10152cd08:     	ccmp	x11, x13, #0x0, eq
10152cd0c:     	ccmp	x14, x16, #0x0, eq
10152cd10:     	ccmp	x15, x8, #0x0, eq
10152cd14:     	b.ne	0x10152cd54 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
10152cd18:     	ldrb	w8, [x9, #0x124]
10152cd1c:     	cmp	w8, #0x7
10152cd20:     	b.ne	0x10152cd54 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
10152cd24:     	add	x8, sp, #0x2f0
10152cd28:     	add	x0, x25, #0xf0
10152cd2c:     	add	x2, sp, #0x400
10152cd30:     	add	x3, x25, #0x2f8
10152cd34:     	bl	0x101638bf8 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
10152cd38:     	ldrb	w8, [sp, #0x2f0]
10152cd3c:     	cmp	w8, #0x14
10152cd40:     	b.ne	0x10152ce9c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1250>
10152cd44:     	mov	w22, #0x0               ; =0
10152cd48:     	add	x0, sp, #0x400
10152cd4c:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cd50:     	b	0x10152c910 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcc4>
10152cd54:     	ldr	x10, [sp, #0x40]
10152cd58:     	str	wzr, [x10]
10152cd5c:     	mov	w8, #0xc                ; =12
10152cd60:     	strb	w8, [x10, #0x8]
10152cd64:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152cd68:     	add	x8, x8, #0x1c9
10152cd6c:     	mov	w9, #0x2a               ; =42
10152cd70:     	stp	x8, x9, [x10, #0x10]
10152cd74:     	mov	w22, #0x0               ; =0
10152cd78:     	add	x0, sp, #0x400
10152cd7c:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cd80:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152cd84:     	ldr	w8, [sp, #0x248]
10152cd88:     	ldr	w10, [x9, #0x130]
10152cd8c:     	cmp	w8, w10
10152cd90:     	b.ne	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cd94:     	ldrb	w8, [sp, #0x239]
10152cd98:     	ldr	x21, [sp, #0x240]
10152cd9c:     	ldrb	w10, [sp, #0x238]
10152cda0:     	ldrb	w9, [x9, #0x124]
10152cda4:     	cmp	w10, #0x2
10152cda8:     	b.le	0x10152cdc8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x117c>
10152cdac:     	cmp	w10, #0x4
10152cdb0:     	b.gt	0x10152ce3c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11f0>
10152cdb4:     	cmp	w10, #0x3
10152cdb8:     	b.ne	0x10152cefc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12b0>
10152cdbc:     	cmp	w9, #0x3
10152cdc0:     	b.eq	0x10152cf20 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152cdc4:     	b	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cdc8:     	cbz	w10, 0x10152cee4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1298>
10152cdcc:     	cmp	w10, #0x1
10152cdd0:     	b.ne	0x10152cef0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a4>
10152cdd4:     	cmp	w9, #0x1
10152cdd8:     	b.eq	0x10152cf20 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152cddc:     	b	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cde0:     	ldr	x1, [x27, #0x378]
10152cde4:     	ldr	x2, [x27, #0x380]
10152cde8:     	add	x0, sp, #0x400
10152cdec:     	add	x4, sp, #0x3c8
10152cdf0:     	mov	x3, x20
10152cdf4:     	bl	0x1015284b0 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>
10152cdf8:     	ldr	q0, [sp, #0x420]
10152cdfc:     	ldr	q1, [sp, #0x430]
10152ce00:     	ldr	x8, [sp, #0x40]
10152ce04:     	stp	q0, q1, [x8, #0x20]
10152ce08:     	ldr	q0, [sp, #0x440]
10152ce0c:     	str	q0, [x8, #0x40]
10152ce10:     	ldr	q0, [sp, #0x410]
10152ce14:     	ldr	q1, [sp, #0x400]
10152ce18:     	stp	q1, q0, [x8]
10152ce1c:     	mov	w22, #0x1               ; =1
10152ce20:     	add	x0, sp, #0x270
10152ce24:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152ce28:     	ldr	x8, [sp, #0x230]
10152ce2c:     	cbz	x8, 0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152ce30:     	add	x0, sp, #0x230
10152ce34:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152ce38:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152ce3c:     	cmp	w10, #0x5
10152ce40:     	b.ne	0x10152cf14 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12c8>
10152ce44:     	cmp	w9, #0x5
10152ce48:     	b.ne	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152ce4c:     	ldrh	w21, [sp, #0x23a]
10152ce50:     	b	0x10152cf20 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152ce54:     	ldr	x1, [x27, #0x378]
10152ce58:     	ldr	x2, [x27, #0x380]
10152ce5c:     	add	x0, sp, #0x400
10152ce60:     	add	x4, sp, #0x1f8
10152ce64:     	mov	x3, x20
10152ce68:     	bl	0x10152841c <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>
10152ce6c:     	ldr	q0, [sp, #0x420]
10152ce70:     	ldr	q1, [sp, #0x430]
10152ce74:     	ldr	x8, [sp, #0x40]
10152ce78:     	stp	q0, q1, [x8, #0x20]
10152ce7c:     	ldr	q0, [sp, #0x440]
10152ce80:     	str	q0, [x8, #0x40]
10152ce84:     	ldr	q0, [sp, #0x410]
10152ce88:     	ldr	q1, [sp, #0x400]
10152ce8c:     	stp	q1, q0, [x8]
10152ce90:     	add	x0, sp, #0x270
10152ce94:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152ce98:     	b	0x10152bfcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152ce9c:     	add	x10, sp, #0x230
10152cea0:     	ldur	w9, [x10, #0xc1]
10152cea4:     	ldr	x11, [sp, #0x40]
10152cea8:     	stur	w9, [x11, #0x9]
10152ceac:     	ldr	w9, [sp, #0x2f4]
10152ceb0:     	str	w9, [x11, #0xc]
10152ceb4:     	ldr	q0, [sp, #0x310]
10152ceb8:     	stur	q0, [x11, #0x28]
10152cebc:     	ldr	x9, [sp, #0x320]
10152cec0:     	str	x9, [x11, #0x38]
10152cec4:     	ldr	d0, [sp, #0x308]
10152cec8:     	ldur	q1, [x10, #0xc8]
10152cecc:     	mov	w9, #0x2                ; =2
10152ced0:     	str	w9, [x11]
10152ced4:     	strb	w8, [x11, #0x8]
10152ced8:     	str	q1, [x11, #0x10]
10152cedc:     	str	d0, [x11, #0x20]
10152cee0:     	b	0x10152cd74 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1128>
10152cee4:     	cbnz	w9, 0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cee8:     	and	x21, x8, #0x1
10152ceec:     	b	0x10152cf20 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152cef0:     	cmp	w9, #0x2
10152cef4:     	b.eq	0x10152cf20 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152cef8:     	b	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cefc:     	cmp	w9, #0x4
10152cf00:     	b.ne	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cf04:     	mov	w22, #0x1               ; =1
10152cf08:     	mov	x21, x8
10152cf0c:     	add	x26, sp, #0x400
10152cf10:     	b	0x10152c220 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10152cf14:     	cmp	w9, #0x6
10152cf18:     	b.ne	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cf1c:     	ldr	w21, [sp, #0x23c]
10152cf20:     	mov	w22, #0x1               ; =1
10152cf24:     	add	x26, sp, #0x400
10152cf28:     	b	0x10152c220 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10152cf2c:     	ldr	x10, [sp, #0x40]
10152cf30:     	str	wzr, [x10]
10152cf34:     	mov	w8, #0xc                ; =12
10152cf38:     	strb	w8, [x10, #0x8]
10152cf3c:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10152cf40:     	add	x8, x8, #0x1a0
10152cf44:     	mov	w9, #0x29               ; =41
10152cf48:     	b	0x10152c35c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
10152cf4c:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf50:     	add	x3, x3, #0x828
10152cf54:     	mov	x0, #0x0                ; =0
10152cf58:     	mov	x1, x22
10152cf5c:     	bl	0x103a02658 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152cf60:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf64:     	add	x3, x3, #0x7b0
10152cf68:     	mov	x0, #0x0                ; =0
10152cf6c:     	mov	x1, x22
10152cf70:     	bl	0x103a02658 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152cf74:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf78:     	add	x3, x3, #0x810
10152cf7c:     	mov	x0, #0x0                ; =0
10152cf80:     	mov	x1, x22
10152cf84:     	bl	0x103a02658 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152cf88:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf8c:     	add	x3, x3, #0x7e0
10152cf90:     	mov	x0, #0x0                ; =0
10152cf94:     	mov	x1, x22
10152cf98:     	bl	0x103a02658 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152cf9c:     	b	0x10152d0b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cfa0:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfa4:     	add	x3, x3, #0x7f8
10152cfa8:     	mov	x0, #0x0                ; =0
10152cfac:     	mov	x1, x22
10152cfb0:     	bl	0x103a02658 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152cfb4:     	b	0x10152d0b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cfb8:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfbc:     	add	x2, x2, #0x840
10152cfc0:     	mov	x0, x1
10152cfc4:     	mov	x1, x8
10152cfc8:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cfcc:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfd0:     	add	x2, x2, #0x780
10152cfd4:     	mov	x0, x20
10152cfd8:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cfdc:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfe0:     	add	x2, x2, #0x858
10152cfe4:     	mov	x0, x25
10152cfe8:     	mov	x1, x22
10152cfec:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cff0:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cff4:     	add	x2, x2, #0x870
10152cff8:     	mov	x0, x25
10152cffc:     	mov	x1, x22
10152d000:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d004:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d008:     	add	x2, x2, #0x8a0
10152d00c:     	mov	x0, x20
10152d010:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d014:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d018:     	add	x2, x2, #0x798
10152d01c:     	mov	x0, x20
10152d020:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d024:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d028:     	add	x2, x2, #0x7c8
10152d02c:     	mov	x0, x20
10152d030:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d034:     	b	0x10152d0b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152d038:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d03c:     	add	x2, x2, #0x918
10152d040:     	b	0x10152d050 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1404>
10152d044:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d048:     	add	x2, x2, #0x8e8
10152d04c:     	mov	w1, #0x1                ; =1
10152d050:     	mov	w22, #0x1               ; =1
10152d054:     	mov	x0, x1
10152d058:     	mov	x1, x8
10152d05c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d060:     	b	0x10152d0b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152d064:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d068:     	add	x2, x2, #0x930
10152d06c:     	mov	x0, x1
10152d070:     	mov	x1, x8
10152d074:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d078:     	b	0x10152d0b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152d07c:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d080:     	add	x2, x2, #0x8b8
10152d084:     	mov	w0, #0x1                ; =1
10152d088:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d08c:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d090:     	add	x2, x2, #0x900
10152d094:     	mov	x0, x20
10152d098:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d09c:     	b	0x10152d0b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152d0a0:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152d0a4:     	add	x2, x2, #0x8d0
10152d0a8:     	mov	x0, x20
10152d0ac:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152d0b0:     	brk	#0x1
10152d0b4:     	mov	x20, x0
10152d0b8:     	add	x0, sp, #0x400
10152d0bc:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d0c0:     	b	0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d0c4:     	mov	x20, x0
10152d0c8:     	add	x0, sp, #0x270
10152d0cc:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d0d0:     	b	0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d0d4:     	mov	x20, x0
10152d0d8:     	add	x0, sp, #0x270
10152d0dc:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d0e0:     	mov	w22, #0x1               ; =1
10152d0e4:     	b	0x10152d0ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14a0>
10152d0e8:     	mov	x20, x0
10152d0ec:     	cbz	w22, 0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d0f0:     	ldr	x8, [sp, #0x230]
10152d0f4:     	cbz	x8, 0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d0f8:     	add	x0, sp, #0x230
10152d0fc:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d100:     	b	0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d104:     	add	x8, x28, x19
10152d108:     	ldp	q0, q1, [sp, #0x2f0]
10152d10c:     	ldp	q2, q3, [sp, #0x310]
10152d110:     	stp	q2, q3, [x8, #0x20]
10152d114:     	stp	q0, q1, [x8]
10152d118:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
10152d11c:     	mov	x20, x0
10152d120:     	tbnz	w19, #0x0, 0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d124:     	add	x0, sp, #0x2f0
10152d128:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d12c:     	b	0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d130:     	bl	0x103a0248c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10152d134:     	mov	x20, x0
10152d138:     	ldr	w8, [sp, #0x400]
10152d13c:     	cmp	w8, #0x6
10152d140:     	b.eq	0x10152d160 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d144:     	add	x0, sp, #0x400
10152d148:     	bl	0x101525710 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10152d14c:     	mov	x0, x20
10152d150:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
10152d154:     	mov	x20, x0
10152d158:     	add	x0, sp, #0xf8
10152d15c:     	bl	0x1015258a4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10152d160:     	mov	x0, x20
10152d164:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
