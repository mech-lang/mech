
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102372d60 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped>:
102372d60:     	sub	sp, sp, #0x60
102372d64:     	stp	x22, x21, [sp, #0x30]
102372d68:     	stp	x20, x19, [sp, #0x40]
102372d6c:     	stp	x29, x30, [sp, #0x50]
102372d70:     	add	x29, sp, #0x50
102372d74:     	mov	x19, x8
102372d78:     	ldr	x20, [x0]
102372d7c:     	ldr	x8, [x20, #0x10]
102372d80:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102372d84:     	cmp	x8, x9
102372d88:     	b.hs	0x102372ee4 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x184>
102372d8c:     	ldr	x8, [x20, #0x38]
102372d90:     	adds	x8, x8, x2
102372d94:     	b.hs	0x102372ef0 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x190>
102372d98:     	cmp	x8, x3
102372d9c:     	b.ls	0x102372db8 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x58>
102372da0:     	mov	w9, #0x606              ; =1542
102372da4:     	strh	w9, [x19]
102372da8:     	mov	w9, #0x1                ; =1
102372dac:     	strb	w9, [x19, #0x2]
102372db0:     	stp	x8, x3, [x19, #0x8]
102372db4:     	b	0x102372e88 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x128>
102372db8:     	ldr	x8, [x1, #0x20]
102372dbc:     	cmp	x8, x9
102372dc0:     	b.hs	0x102372f00 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x1a0>
102372dc4:     	ldr	x8, [x1, #0x28]
102372dc8:     	cbz	x8, 0x102372ddc <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x7c>
102372dcc:     	cmp	x8, x20
102372dd0:     	b.eq	0x102372ddc <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x7c>
102372dd4:     	strb	wzr, [x19]
102372dd8:     	b	0x102372e88 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x128>
102372ddc:     	ldr	x8, [x20, #0x10]
102372de0:     	cbnz	x8, 0x102372f0c <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x1ac>
102372de4:     	mov	x8, #-0x1               ; =-1
102372de8:     	str	x8, [x20, #0x10]
102372dec:     	ldr	w8, [x1, #0x30]
102372df0:     	ldp	x9, x10, [x1, #0x38]
102372df4:     	ldp	x11, x12, [x20, #0x60]
102372df8:     	cmp	x9, x11
102372dfc:     	csel	x9, x9, x11, lo
102372e00:     	cmp	x10, x12
102372e04:     	csel	x10, x10, x12, lo
102372e08:     	tst	w8, #0x1
102372e0c:     	csel	x8, x9, x11, ne
102372e10:     	csel	x12, x10, x12, ne
102372e14:     	ldr	x9, [x20, #0x38]
102372e18:     	adds	x21, x9, x2
102372e1c:     	b.hs	0x102372ef8 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x198>
102372e20:     	ldr	x9, [x20, #0x48]
102372e24:     	adds	x9, x9, x21
102372e28:     	b.hs	0x102372ef8 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x198>
102372e2c:     	ldr	x22, [x20, #0x40]
102372e30:     	ldr	x10, [x20, #0x50]
102372e34:     	adds	x13, x10, x22
102372e38:     	b.hs	0x102372ef8 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x198>
102372e3c:     	cmp	x9, x8
102372e40:     	b.ls	0x102372e50 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0xf0>
102372e44:     	mov	w10, #0x6               ; =6
102372e48:     	mov	w11, #0x6               ; =6
102372e4c:     	b	0x102372e68 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x108>
102372e50:     	cmp	x13, x12
102372e54:     	b.ls	0x102372e9c <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x13c>
102372e58:     	mov	w11, #0x5               ; =5
102372e5c:     	mov	w10, #0x6               ; =6
102372e60:     	mov	x9, x13
102372e64:     	mov	x8, x12
102372e68:     	strb	w10, [x19]
102372e6c:     	strb	w11, [x19, #0x1]
102372e70:     	mov	w10, #0x1               ; =1
102372e74:     	strb	w10, [x19, #0x2]
102372e78:     	stp	x9, x8, [x19, #0x8]
102372e7c:     	ldr	x8, [x20, #0x10]
102372e80:     	add	x8, x8, #0x1
102372e84:     	str	x8, [x20, #0x10]
102372e88:     	ldp	x29, x30, [sp, #0x50]
102372e8c:     	ldp	x20, x19, [sp, #0x40]
102372e90:     	ldp	x22, x21, [sp, #0x30]
102372e94:     	add	sp, sp, #0x60
102372e98:     	ret
102372e9c:     	ldr	x1, [x20, #0x70]
102372ea0:     	cbz	x1, 0x102372ebc <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x15c>
102372ea4:     	add	x0, sp, #0x8
102372ea8:     	mov	x3, #0x0                ; =0
102372eac:     	bl	0x10236e80c <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102372eb0:     	ldrb	w8, [sp, #0x8]
102372eb4:     	cmp	w8, #0x8
102372eb8:     	b.ne	0x102372ecc <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x16c>
102372ebc:     	stp	x21, x22, [x20, #0x38]
102372ec0:     	mov	w8, #0x8                ; =8
102372ec4:     	strb	w8, [x19]
102372ec8:     	b	0x102372e7c <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x11c>
102372ecc:     	ldur	q0, [sp, #0x8]
102372ed0:     	ldur	q1, [sp, #0x18]
102372ed4:     	stp	q0, q1, [x19]
102372ed8:     	ldr	x8, [sp, #0x28]
102372edc:     	str	x8, [x19, #0x20]
102372ee0:     	b	0x102372e7c <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x11c>
102372ee4:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
102372ee8:     	add	x0, x0, #0x130
102372eec:     	bl	0x103a023a8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102372ef0:     	mov	x8, #-0x1               ; =-1
102372ef4:     	b	0x102372da0 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x40>
102372ef8:     	mov	w10, #0x2               ; =2
102372efc:     	b	0x102372e68 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x108>
102372f00:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
102372f04:     	add	x0, x0, #0xe8
102372f08:     	bl	0x103a023a8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102372f0c:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
102372f10:     	add	x0, x0, #0x100
102372f14:     	bl	0x103a02378 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102372f18:     	ldr	x8, [x20, #0x10]
102372f1c:     	add	x8, x8, #0x1
102372f20:     	str	x8, [x20, #0x10]
102372f24:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
