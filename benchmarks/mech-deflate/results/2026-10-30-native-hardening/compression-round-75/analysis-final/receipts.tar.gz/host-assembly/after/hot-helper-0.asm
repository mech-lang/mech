
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015403d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>:
1015403d4:     	stp	x28, x27, [sp, #-0x60]!
1015403d8:     	stp	x26, x25, [sp, #0x10]
1015403dc:     	stp	x24, x23, [sp, #0x20]
1015403e0:     	stp	x22, x21, [sp, #0x30]
1015403e4:     	stp	x20, x19, [sp, #0x40]
1015403e8:     	stp	x29, x30, [sp, #0x50]
1015403ec:     	add	x29, sp, #0x50
1015403f0:     	sub	sp, sp, #0x810
1015403f4:     	str	xzr, [sp]
1015403f8:     	add	x9, x2, #0x1d
1015403fc:     	cmp	x9, #0x1f
101540400:     	b.hi	0x10154042c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101540404:     	mov	w10, #-0x10000001       ; =-268435457
101540408:     	lsr	w10, w10, w9
10154040c:     	tbz	w10, #0x0, 0x10154042c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101540410:     	adrp	x10, 0x107552000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.933+0x8e1>
101540414:     	add	x10, x10, #0x420
101540418:     	ldr	x22, [x10, x9, lsl #3]
10154041c:     	ldr	x9, [x0, #0x238]
101540420:     	cmp	x9, #0x3
101540424:     	b.ne	0x101540440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6c>
101540428:     	b	0x101540468 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
10154042c:     	sub	x21, x2, #0x3
101540430:     	mov	w22, #0x3               ; =3
101540434:     	ldr	x9, [x0, #0x238]
101540438:     	cmp	x9, #0x3
10154043c:     	b.eq	0x101540468 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101540440:     	ldr	w9, [x0, #0x268]
101540444:     	cbz	w9, 0x101540468 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101540448:     	str	wzr, [x8]
10154044c:     	mov	w9, #0xc                ; =12
101540450:     	strb	w9, [x8, #0x8]
101540454:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540458:     	add	x9, x9, #0xac6
10154045c:     	mov	w10, #0x25              ; =37
101540460:     	stp	x9, x10, [x8, #0x10]
101540464:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540468:     	cmp	x22, #0xb
10154046c:     	b.eq	0x101540544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
101540470:     	add	x27, sp, #0x550
101540474:     	add	x24, sp, #0x440
101540478:     	add	x26, sp, #0x330
10154047c:     	add	x25, sp, #0x220
101540480:     	cmp	x22, #0x1d
101540484:     	b.eq	0x1015404d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104>
101540488:     	cmp	x22, #0x1f
10154048c:     	b.ne	0x101540574 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a0>
101540490:     	ldp	x20, x28, [x3]
101540494:     	ldr	x10, [x3, #0x10]
101540498:     	ldp	x12, x11, [x0, #0xc0]
10154049c:     	ldp	x26, x19, [x0, #0xd0]
1015404a0:     	ldp	x22, x25, [x0, #0xe0]
1015404a4:     	ldr	w9, [x0, #0xf0]
1015404a8:     	mov	w13, #0x2               ; =2
1015404ac:     	str	x13, [x0, #0xc0]
1015404b0:     	cbz	x12, 0x1015405f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x21c>
1015404b4:     	cmp	x12, #0x2
1015404b8:     	b.ne	0x10154060c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x238>
1015404bc:     	str	wzr, [x8]
1015404c0:     	mov	w9, #0xc                ; =12
1015404c4:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015404c8:     	add	x10, x10, #0x379
1015404cc:     	stp	x9, x10, [x8, #0x8]
1015404d0:     	mov	w9, #0x20               ; =32
1015404d4:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015404d8:     	ldr	x19, [x0, #0x4a0]
1015404dc:     	ldr	x9, [x19, #0x270]
1015404e0:     	cmp	x1, x9
1015404e4:     	b.hs	0x1015405b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
1015404e8:     	ldr	x9, [x19, #0x268]
1015404ec:     	add	x9, x9, x1, lsl #4
1015404f0:     	ldr	w10, [x9]
1015404f4:     	tbz	w10, #0x0, 0x1015405b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
1015404f8:     	ldr	x9, [x9, #0x8]
1015404fc:     	ldr	x10, [x19, #0x258]
101540500:     	cmp	x9, x10
101540504:     	b.hs	0x101542c68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2894>
101540508:     	ldr	x10, [x19, #0x250]
10154050c:     	mov	w11, #0x160             ; =352
101540510:     	madd	x21, x9, x11, x10
101540514:     	mov	x20, x21
101540518:     	ldr	x10, [x20, #0x30]!
10154051c:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
101540520:     	cmp	x10, x11
101540524:     	b.ne	0x10154070c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x338>
101540528:     	str	wzr, [x8]
10154052c:     	mov	w9, #0xc                ; =12
101540530:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
101540534:     	add	x10, x10, #0x301
101540538:     	stp	x9, x10, [x8, #0x8]
10154053c:     	mov	w9, #0x23               ; =35
101540540:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540544:     	mov	x9, x0
101540548:     	mov	x0, x8
10154054c:     	mov	x2, x1
101540550:     	mov	x1, x9
101540554:     	add	sp, sp, #0x810
101540558:     	ldp	x29, x30, [sp, #0x50]
10154055c:     	ldp	x20, x19, [sp, #0x40]
101540560:     	ldp	x22, x21, [sp, #0x30]
101540564:     	ldp	x24, x23, [sp, #0x20]
101540568:     	ldp	x26, x25, [sp, #0x10]
10154056c:     	ldp	x28, x27, [sp], #0x60
101540570:     	b	0x101533a90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
101540574:     	ldr	x9, [x0, #0xc0]
101540578:     	cmp	x9, #0x2
10154057c:     	b.ne	0x1015405d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x200>
101540580:     	cmp	x22, #0x15
101540584:     	b.gt	0x1015406c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4>
101540588:     	sub	x9, x22, #0xc
10154058c:     	cmp	x9, #0x4
101540590:     	b.hs	0x101540990 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5bc>
101540594:     	lsr	x9, x1, #32
101540598:     	cbz	x9, 0x10154074c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x378>
10154059c:     	str	wzr, [x8]
1015405a0:     	mov	w9, #0xc                ; =12
1015405a4:     	strb	w9, [x8, #0x8]
1015405a8:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015405ac:     	add	x9, x9, #0x6ef
1015405b0:     	mov	w10, #0x15              ; =21
1015405b4:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015405b8:     	str	wzr, [x8]
1015405bc:     	mov	w9, #0xc                ; =12
1015405c0:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015405c4:     	add	x10, x10, #0x20d
1015405c8:     	stp	x9, x10, [x8, #0x8]
1015405cc:     	mov	w9, #0x2d               ; =45
1015405d0:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015405d4:     	str	wzr, [x8]
1015405d8:     	mov	w9, #0xc                ; =12
1015405dc:     	strb	w9, [x8, #0x8]
1015405e0:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
1015405e4:     	add	x9, x9, #0x906
1015405e8:     	mov	w10, #0x35              ; =53
1015405ec:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015405f0:     	str	wzr, [x8]
1015405f4:     	mov	w9, #0xc                ; =12
1015405f8:     	strb	w9, [x8, #0x8]
1015405fc:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101540600:     	add	x9, x9, #0x594
101540604:     	mov	w10, #0x27              ; =39
101540608:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154060c:     	ldr	x21, [x0, #0x4a0]
101540610:     	ldr	x12, [x21, #0x178]
101540614:     	cmp	x11, x12
101540618:     	b.hs	0x10154068c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
10154061c:     	ldr	x12, [x21, #0x170]
101540620:     	add	x12, x12, x11, lsl #4
101540624:     	ldr	x11, [x12]
101540628:     	ldr	x13, [x21, #0x160]
10154062c:     	cmp	x11, x13
101540630:     	b.hs	0x10154068c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101540634:     	ldr	x12, [x12, #0x8]
101540638:     	ldr	x13, [x21, #0x158]
10154063c:     	mov	w14, #0x48              ; =72
101540640:     	madd	x11, x11, x14, x13
101540644:     	ldr	x13, [x11, #0x28]
101540648:     	cmp	x12, x13
10154064c:     	b.hs	0x10154068c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101540650:     	ldr	x13, [x11, #0x20]
101540654:     	mov	w14, #0x110             ; =272
101540658:     	madd	x23, x12, x14, x13
10154065c:     	mov	x24, x23
101540660:     	ldr	x13, [x24, #0x30]!
101540664:     	mov	x12, #-0x8000000000000000 ; =-9223372036854775808
101540668:     	cmp	x13, x12
10154066c:     	b.ne	0x101540c08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x834>
101540670:     	str	wzr, [x8]
101540674:     	mov	w9, #0xc                ; =12
101540678:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
10154067c:     	add	x10, x10, #0x399
101540680:     	stp	x9, x10, [x8, #0x8]
101540684:     	mov	w9, #0x1f               ; =31
101540688:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10154068c:     	str	wzr, [x8]
101540690:     	mov	w9, #0xc                ; =12
101540694:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
101540698:     	add	x10, x10, #0x4f6
10154069c:     	stp	x9, x10, [x8, #0x8]
1015406a0:     	mov	w9, #0x29               ; =41
1015406a4:     	str	x9, [x8, #0x18]
1015406a8:     	add	sp, sp, #0x810
1015406ac:     	ldp	x29, x30, [sp, #0x50]
1015406b0:     	ldp	x20, x19, [sp, #0x40]
1015406b4:     	ldp	x22, x21, [sp, #0x30]
1015406b8:     	ldp	x24, x23, [sp, #0x20]
1015406bc:     	ldp	x26, x25, [sp, #0x10]
1015406c0:     	ldp	x28, x27, [sp], #0x60
1015406c4:     	ret
1015406c8:     	sub	x9, x22, #0x17
1015406cc:     	cmp	x9, #0x4
1015406d0:     	b.hs	0x1015409c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f4>
1015406d4:     	cmn	x2, #0x17
1015406d8:     	b.gt	0x1015407c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f0>
1015406dc:     	cmn	x2, #0x18
1015406e0:     	b.eq	0x101540ae4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x710>
1015406e4:     	cmn	x2, #0x17
1015406e8:     	b.ne	0x101540ac8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f4>
1015406ec:     	ldr	x9, [x0, #0xf8]
1015406f0:     	cmp	x9, #0x2
1015406f4:     	b.ne	0x101540c58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x884>
1015406f8:     	str	wzr, [x8]
1015406fc:     	mov	w9, #0xc                ; =12
101540700:     	adrp	x10, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540704:     	add	x10, x10, #0xe14
101540708:     	b	0x101540c28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x854>
10154070c:     	ldp	x10, x11, [x21, #0x68]
101540710:     	sub	x23, x10, #0x18
101540714:     	lsl	x10, x11, #5
101540718:     	cbz	x10, 0x101540978 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a4>
10154071c:     	ldr	x11, [x23, #0x18]
101540720:     	add	x23, x23, #0x20
101540724:     	sub	x10, x10, #0x20
101540728:     	cmp	x11, x1
10154072c:     	b.ne	0x101540718 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344>
101540730:     	ldr	w10, [x23]
101540734:     	cmp	w10, #0x5
101540738:     	b.eq	0x101540c34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x860>
10154073c:     	cmp	w10, #0x6
101540740:     	b.ne	0x101540978 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a4>
101540744:     	mov	w22, #0x8               ; =8
101540748:     	b	0x101540c38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x864>
10154074c:     	ldr	x9, [x0, #0x4c0]
101540750:     	lsr	x10, x9, #59
101540754:     	cbnz	x10, 0x101541994 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15c0>
101540758:     	mov	x10, #-0x21             ; =-33
10154075c:     	movk	x10, #0x7ff, lsl #48
101540760:     	cmp	x9, x10
101540764:     	b.hi	0x101541994 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15c0>
101540768:     	mov	x25, x2
10154076c:     	mov	x21, x3
101540770:     	mov	x19, x1
101540774:     	mov	x23, x8
101540778:     	mov	x20, x0
10154077c:     	ldr	x26, [x0, #0x490]
101540780:     	lsl	x8, x9, #5
101540784:     	and	x8, x8, #0xffffffffffffffc0
101540788:     	add	x22, x8, #0x400
10154078c:     	ldr	x8, [x26, #0x310]
101540790:     	cbz	x8, 0x101540b98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c4>
101540794:     	ldr	x2, [x26, #0x308]
101540798:     	add	x8, sp, #0x550
10154079c:     	add	x0, x26, #0x310
1015407a0:     	mov	x1, x22
1015407a4:     	bl	0x10236d3d4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015407a8:     	ldrb	w8, [sp, #0x550]
1015407ac:     	cmp	w8, #0x8
1015407b0:     	b.ne	0x101540bb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7e4>
1015407b4:     	mov	x0, x20
1015407b8:     	mov	x1, x19
1015407bc:     	mov	x10, x25
1015407c0:     	b	0x1015411dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe08>
1015407c4:     	cmn	x2, #0x16
1015407c8:     	b.eq	0x101540b0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x738>
1015407cc:     	cmn	x2, #0x15
1015407d0:     	b.ne	0x101540ac8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f4>
1015407d4:     	ldr	x9, [x0, #0x4a0]
1015407d8:     	str	x9, [sp, #0x660]
1015407dc:     	ldr	x19, [x3, #0x10]
1015407e0:     	ldr	x10, [x9, #0x5a0]
1015407e4:     	cmp	x19, x10
1015407e8:     	b.hs	0x101540d84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
1015407ec:     	ldr	x9, [x9, #0x598]
1015407f0:     	mov	w10, #0x58              ; =88
1015407f4:     	madd	x22, x19, x10, x9
1015407f8:     	ldr	w9, [x22, #0x3c]
1015407fc:     	cmp	x1, x9
101540800:     	b.ne	0x101540e54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540804:     	ldr	x24, [x0, #0x490]
101540808:     	ldr	w9, [x24, #0x2f0]
10154080c:     	cmp	w9, #0x1
101540810:     	b.ne	0x101540e54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540814:     	ldr	w9, [x24, #0x2f4]
101540818:     	cmp	w9, w1
10154081c:     	b.ne	0x101540e54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540820:     	ldr	w9, [x24, #0x2e8]
101540824:     	cmp	w9, #0x1
101540828:     	b.ne	0x101540e54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
10154082c:     	ldr	w9, [x22, #0x34]
101540830:     	ldr	w10, [x24, #0x2ec]
101540834:     	cmp	w10, w9
101540838:     	b.ne	0x101540e54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
10154083c:     	ldrb	w10, [x24, #0x460]
101540840:     	cmp	w10, #0x1
101540844:     	b.ne	0x101540e54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540848:     	mov	x23, x8
10154084c:     	str	x0, [sp, #0x58]
101540850:     	ldr	x8, [x0, #0xf8]
101540854:     	cmp	x8, #0x2
101540858:     	b.ne	0x10154183c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
10154085c:     	ldr	x8, [sp, #0x58]
101540860:     	ldrb	w8, [x8, #0x510]
101540864:     	tbnz	w8, #0x0, 0x10154183c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
101540868:     	lsl	x0, x9, #1
10154086c:     	ldr	x8, [sp, #0x58]
101540870:     	ldr	x1, [x8, #0x4c0]
101540874:     	cmp	x0, x1
101540878:     	b.hs	0x10154398c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35b8>
10154087c:     	ldr	x8, [sp, #0x58]
101540880:     	ldr	x9, [x8, #0x4b8]
101540884:     	ldr	x28, [x9, x0, lsl #3]
101540888:     	ldr	x8, [x8, #0x3c0]
10154088c:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101540890:     	cmp	x8, x9
101540894:     	b.ne	0x101541a28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1654>
101540898:     	mov	x21, x3
10154089c:     	bl	0x102e6b6dc <__RNvNtNtCsgirOGyZpP7g_3std6thread9functions21available_parallelism>
1015408a0:     	cmp	x0, #0x1
1015408a4:     	b.ne	0x1015408b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e0>
1015408a8:     	mov	x0, x1
1015408ac:     	bl	0x10152323c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtNtB4_3num7nonzero7NonZerojENtNtNtCsgirOGyZpP7g_3std2io5error5ErrorEECs7fdMCt8k5K6_8mech_gpu>
1015408b0:     	mov	w1, #0x1                ; =1
1015408b4:     	mov	w8, #0x20               ; =32
1015408b8:     	cmp	x1, #0x20
1015408bc:     	csel	x20, x1, x8, lo
1015408c0:     	sub	x8, x28, #0x1
1015408c4:     	cmp	x8, x20
1015408c8:     	b.hs	0x10154183c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
1015408cc:     	ldr	x8, [x22, #0x28]
1015408d0:     	str	x8, [sp, #0x50]
1015408d4:     	cmp	x8, x20
1015408d8:     	b.hi	0x10154183c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
1015408dc:     	ldr	x8, [x22, #0x20]
1015408e0:     	str	x8, [sp, #0x48]
1015408e4:     	add	x8, sp, #0x550
1015408e8:     	add	x0, x24, #0x3b8
1015408ec:     	bl	0x10236cbc4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015408f0:     	ldr	x8, [sp, #0x550]
1015408f4:     	cmp	x8, #0x1
1015408f8:     	b.ne	0x10154183c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
1015408fc:     	ldr	x8, [sp, #0x558]
101540900:     	cbz	x8, 0x10154183c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
101540904:     	ldr	x8, [x21]
101540908:     	str	x8, [sp, #0x40]
10154090c:     	cbz	x8, 0x101542084 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cb0>
101540910:     	ldr	x8, [x21, #0x8]
101540914:     	cbz	x8, 0x101542084 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cb0>
101540918:     	mov	x21, x8
10154091c:     	ldr	x9, [x8, #0x38]
101540920:     	ldr	x8, [sp, #0x58]
101540924:     	cmp	x9, x8
101540928:     	b.ne	0x101540960 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
10154092c:     	ldr	x8, [x21]
101540930:     	cmp	x8, #0x25
101540934:     	b.ne	0x101540960 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
101540938:     	ldr	x8, [x21, #0x10]
10154093c:     	ldr	x9, [sp, #0x660]
101540940:     	ldr	x9, [x9, #0x360]
101540944:     	cmp	x8, x9
101540948:     	b.lo	0x101540960 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
10154094c:     	ldr	x8, [x21, #0x28]
101540950:     	cbz	x8, 0x101540960 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
101540954:     	ldr	x8, [x21, #0x70]
101540958:     	cmp	x8, #0x4
10154095c:     	b.ne	0x101542f84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bb0>
101540960:     	str	wzr, [x23]
101540964:     	mov	w8, #0xc                ; =12
101540968:     	strb	w8, [x23, #0x8]
10154096c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540970:     	add	x8, x8, #0xca6
101540974:     	b	0x101541ba0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17cc>
101540978:     	str	wzr, [x8]
10154097c:     	mov	w9, #0xc                ; =12
101540980:     	strb	w9, [x8, #0x8]
101540984:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101540988:     	add	x9, x9, #0x2a3
10154098c:     	b	0x101540e30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa5c>
101540990:     	mov	x19, x2
101540994:     	mov	x23, x3
101540998:     	cmp	x22, #0x14
10154099c:     	b.ne	0x101540a3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x668>
1015409a0:     	ldr	x9, [x0, #0x490]
1015409a4:     	ldr	x10, [x0, #0x4a0]
1015409a8:     	mov	x24, x0
1015409ac:     	mov	x0, x9
1015409b0:     	mov	x20, x1
1015409b4:     	mov	x1, x10
1015409b8:     	mov	x2, x20
1015409bc:     	mov	x25, x8
1015409c0:     	bl	0x101550064 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015409c4:     	b	0x1015409fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x628>
1015409c8:     	mov	x19, x2
1015409cc:     	mov	x23, x3
1015409d0:     	cmp	x22, #0x16
1015409d4:     	b.ne	0x101540a3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x668>
1015409d8:     	ldr	x9, [x0, #0x490]
1015409dc:     	ldr	x10, [x0, #0x4a0]
1015409e0:     	mov	x24, x0
1015409e4:     	mov	x0, x9
1015409e8:     	mov	x20, x1
1015409ec:     	mov	x1, x10
1015409f0:     	mov	x2, x20
1015409f4:     	mov	x25, x8
1015409f8:     	bl	0x10153c274 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
1015409fc:     	mov	x1, x20
101540a00:     	mov	x8, x25
101540a04:     	mov	x9, x0
101540a08:     	mov	x0, x24
101540a0c:     	tbz	w9, #0x0, 0x101540a3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x668>
101540a10:     	mov	x20, x8
101540a14:     	add	x8, sp, #0x550
101540a18:     	mov	x24, x0
101540a1c:     	mov	x25, x1
101540a20:     	bl	0x10153f5b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
101540a24:     	ldr	w8, [sp, #0x550]
101540a28:     	cmp	w8, #0x6
101540a2c:     	b.ne	0x101540be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x810>
101540a30:     	mov	x8, x20
101540a34:     	mov	x0, x24
101540a38:     	mov	x1, x25
101540a3c:     	ldr	x9, [x0, #0x490]
101540a40:     	ldr	w10, [x9, #0x2f0]
101540a44:     	tbz	w10, #0x0, 0x101540aac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6d8>
101540a48:     	ldr	w10, [x9, #0x2f4]
101540a4c:     	cmp	x1, x10
101540a50:     	b.ne	0x101540aac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6d8>
101540a54:     	mov	x3, x23
101540a58:     	ldr	x23, [x0, #0x4a0]
101540a5c:     	mov	x20, x1
101540a60:     	mov	x25, x0
101540a64:     	cmp	x22, #0x1a
101540a68:     	b.gt	0x101541044 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc70>
101540a6c:     	sub	x10, x22, #0x13
101540a70:     	cmp	x10, #0x4
101540a74:     	b.hs	0x101541320 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf4c>
101540a78:     	mov	x0, x8
101540a7c:     	mov	x1, x25
101540a80:     	mov	x2, x20
101540a84:     	mov	x4, x3
101540a88:     	mov	x3, x19
101540a8c:     	add	sp, sp, #0x810
101540a90:     	ldp	x29, x30, [sp, #0x50]
101540a94:     	ldp	x20, x19, [sp, #0x40]
101540a98:     	ldp	x22, x21, [sp, #0x30]
101540a9c:     	ldp	x24, x23, [sp, #0x20]
101540aa0:     	ldp	x26, x25, [sp, #0x10]
101540aa4:     	ldp	x28, x27, [sp], #0x60
101540aa8:     	b	0x10154e5f4 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation19retained_map_helper>
101540aac:     	str	wzr, [x8]
101540ab0:     	mov	w9, #0xc                ; =12
101540ab4:     	strb	w9, [x8, #0x8]
101540ab8:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540abc:     	add	x9, x9, #0xaa3
101540ac0:     	mov	w10, #0x23              ; =35
101540ac4:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540ac8:     	str	wzr, [x8]
101540acc:     	mov	w9, #0xc                ; =12
101540ad0:     	strb	w9, [x8, #0x8]
101540ad4:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540ad8:     	add	x9, x9, #0xede
101540adc:     	mov	w10, #0x20              ; =32
101540ae0:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540ae4:     	ldr	x9, [x0, #0xf8]
101540ae8:     	cmp	x9, #0x2
101540aec:     	b.ne	0x101540da0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
101540af0:     	str	wzr, [x8]
101540af4:     	mov	w9, #0xc                ; =12
101540af8:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101540afc:     	add	x10, x10, #0x473
101540b00:     	stp	x9, x10, [x8, #0x8]
101540b04:     	mov	w9, #0x26               ; =38
101540b08:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540b0c:     	ldr	x9, [x3]
101540b10:     	ldr	x23, [x0, #0x4a0]
101540b14:     	ldr	x10, [x23, #0x5a0]
101540b18:     	cmp	x9, x10
101540b1c:     	b.hs	0x101540e38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa64>
101540b20:     	ldp	x11, x10, [x3, #0x8]
101540b24:     	orr	x10, x11, x10
101540b28:     	cbnz	x10, 0x101540e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540b2c:     	ldr	x10, [x23, #0x598]
101540b30:     	mov	w11, #0x58              ; =88
101540b34:     	madd	x19, x9, x11, x10
101540b38:     	ldr	w10, [x19, #0x44]
101540b3c:     	cmp	x1, x10
101540b40:     	b.ne	0x101540e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540b44:     	ldr	x10, [x0, #0x490]
101540b48:     	ldr	w11, [x10, #0x2f0]
101540b4c:     	cmp	w11, #0x1
101540b50:     	b.ne	0x101540e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540b54:     	ldr	w11, [x10, #0x2f4]
101540b58:     	cmp	w11, w1
101540b5c:     	b.ne	0x101540e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540b60:     	ldrb	w11, [x10, #0x460]
101540b64:     	cmp	w11, #0x1
101540b68:     	b.ne	0x101540e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540b6c:     	mov	x21, x8
101540b70:     	ldr	x8, [x0, #0x3c0]
101540b74:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
101540b78:     	cmp	x8, x11
101540b7c:     	b.ne	0x10154176c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1398>
101540b80:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
101540b84:     	ldr	q0, [x8, #0x80]
101540b88:     	stur	q0, [x21, #0x8]
101540b8c:     	mov	w8, #0x6                ; =6
101540b90:     	str	w8, [x21]
101540b94:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540b98:     	bl	0x10236cb38 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
101540b9c:     	tbz	w0, #0x0, 0x101540e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
101540ba0:     	mov	w11, #0x0               ; =0
101540ba4:     	mov	w10, #0x0               ; =0
101540ba8:     	mov	x8, #0x0                ; =0
101540bac:     	mov	w13, #0x7               ; =7
101540bb0:     	mov	x12, x23
101540bb4:     	b	0x101541008 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101540bb8:     	ldr	x8, [sp, #0x550]
101540bbc:     	ldr	x14, [sp, #0x558]
101540bc0:     	ldr	x9, [sp, #0x560]
101540bc4:     	and	x10, x8, #0xffff
101540bc8:     	cmp	x10, #0x606
101540bcc:     	mov	x12, x23
101540bd0:     	b.ne	0x101540ff0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc1c>
101540bd4:     	mov	w10, #0x0               ; =0
101540bd8:     	mov	w13, #0x6               ; =6
101540bdc:     	mov	x8, x14
101540be0:     	b	0x101541008 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101540be4:     	ldr	q0, [sp, #0x570]
101540be8:     	ldr	q1, [sp, #0x580]
101540bec:     	stp	q0, q1, [x20, #0x20]
101540bf0:     	ldr	q0, [sp, #0x590]
101540bf4:     	str	q0, [x20, #0x40]
101540bf8:     	ldr	q0, [sp, #0x560]
101540bfc:     	ldr	q1, [sp, #0x550]
101540c00:     	stp	q1, q0, [x20]
101540c04:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540c08:     	mov	x14, x23
101540c0c:     	ldr	x13, [x14, #0xb0]!
101540c10:     	cmp	x13, x12
101540c14:     	b.ne	0x101541088 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xcb4>
101540c18:     	str	wzr, [x8]
101540c1c:     	mov	w9, #0xc                ; =12
101540c20:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
101540c24:     	add	x10, x10, #0x3b8
101540c28:     	stp	x9, x10, [x8, #0x8]
101540c2c:     	mov	w9, #0x21               ; =33
101540c30:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540c34:     	mov	w22, #0x10              ; =16
101540c38:     	ldr	x10, [x3, #0x10]
101540c3c:     	cbz	x10, 0x101540eb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xae4>
101540c40:     	str	wzr, [x8]
101540c44:     	mov	w9, #0xc                ; =12
101540c48:     	strb	w9, [x8, #0x8]
101540c4c:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101540c50:     	add	x9, x9, #0x275
101540c54:     	b	0x101540e30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa5c>
101540c58:     	ldr	x24, [x0, #0x4a0]
101540c5c:     	ldr	x11, [x24, #0x5a0]
101540c60:     	ldr	x10, [x0, #0x1c0]
101540c64:     	cmp	x10, x11
101540c68:     	b.hs	0x101541194 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdc0>
101540c6c:     	ldr	x22, [x0, #0x490]
101540c70:     	ldr	w11, [x22, #0x2f0]
101540c74:     	cmp	w11, #0x1
101540c78:     	b.ne	0x101541388 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
101540c7c:     	ldr	x11, [x3, #0x8]
101540c80:     	cmp	x11, x10
101540c84:     	b.ne	0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540c88:     	ldr	x11, [x3, #0x10]
101540c8c:     	cbnz	x11, 0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540c90:     	cbnz	x9, 0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540c94:     	ldr	x9, [x24, #0x598]
101540c98:     	mov	w11, #0x58              ; =88
101540c9c:     	madd	x21, x10, x11, x9
101540ca0:     	ldr	w26, [x21, #0x48]
101540ca4:     	cmp	x1, x26
101540ca8:     	b.ne	0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540cac:     	ldr	w9, [x22, #0x2e8]
101540cb0:     	tbz	w9, #0x0, 0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540cb4:     	ldr	w9, [x21, #0x34]
101540cb8:     	ldr	w10, [x22, #0x2ec]
101540cbc:     	cmp	w10, w9
101540cc0:     	b.ne	0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540cc4:     	ldr	w19, [x22, #0x2f4]
101540cc8:     	mov	x20, x0
101540ccc:     	mov	x0, x21
101540cd0:     	mov	x1, x19
101540cd4:     	mov	x23, x8
101540cd8:     	mov	x25, x3
101540cdc:     	bl	0x1015182c4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare8parallelNtB2_6Region8contains>
101540ce0:     	mov	x8, x23
101540ce4:     	cbz	w0, 0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540ce8:     	ldr	x1, [x24, #0x380]
101540cec:     	cmp	x1, x19
101540cf0:     	b.ls	0x101543998 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35c4>
101540cf4:     	ldr	x8, [x24, #0x378]
101540cf8:     	mov	w9, #0x170              ; =368
101540cfc:     	umaddl	x8, w19, w9, x8
101540d00:     	add	x9, x8, #0x15c
101540d04:     	ldr	w8, [x8, #0x16c]
101540d08:     	str	w8, [sp, #0x560]
101540d0c:     	ldr	q0, [x9]
101540d10:     	str	q0, [sp, #0x550]
101540d14:     	add	x8, sp, #0x440
101540d18:     	add	x0, sp, #0x550
101540d1c:     	bl	0x102a33cd4 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
101540d20:     	ldr	w8, [sp, #0x440]
101540d24:     	cmp	w8, #0x1
101540d28:     	b.ne	0x101540d38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x964>
101540d2c:     	ldr	w8, [sp, #0x444]
101540d30:     	cmp	w8, w26
101540d34:     	b.eq	0x101540d50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x97c>
101540d38:     	ldr	w8, [sp, #0x448]
101540d3c:     	cmp	w8, #0x1
101540d40:     	b.ne	0x101541be0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x180c>
101540d44:     	ldr	w8, [sp, #0x44c]
101540d48:     	cmp	w8, w26
101540d4c:     	b.ne	0x101541be0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x180c>
101540d50:     	mov	x0, x20
101540d54:     	mov	x1, x19
101540d58:     	bl	0x10153f02c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
101540d5c:     	cbz	w0, 0x101541b3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1768>
101540d60:     	ldrb	w8, [x22, #0x460]
101540d64:     	cmp	w8, #0x1
101540d68:     	mov	x8, x23
101540d6c:     	b.ne	0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540d70:     	mov	x9, x20
101540d74:     	ldr	x10, [x20, #0xc0]
101540d78:     	cmp	x10, #0x2
101540d7c:     	b.eq	0x101541b50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x177c>
101540d80:     	b	0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101540d84:     	str	wzr, [x8]
101540d88:     	mov	w9, #0xc                ; =12
101540d8c:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101540d90:     	add	x10, x10, #0x1fc
101540d94:     	stp	x9, x10, [x8, #0x8]
101540d98:     	mov	w9, #0x22               ; =34
101540d9c:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540da0:     	ldr	x11, [x0, #0x4a0]
101540da4:     	ldr	x12, [x11, #0x5a0]
101540da8:     	ldr	x10, [x0, #0x1c0]
101540dac:     	cmp	x10, x12
101540db0:     	b.hs	0x1015411b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xddc>
101540db4:     	ldr	x11, [x11, #0x598]
101540db8:     	mov	w12, #0x58              ; =88
101540dbc:     	madd	x11, x10, x12, x11
101540dc0:     	ldr	w11, [x11, #0x38]
101540dc4:     	cmp	x1, x11
101540dc8:     	b.ne	0x101540e1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540dcc:     	add	x11, x0, #0x1c8
101540dd0:     	ldr	q0, [x11]
101540dd4:     	stur	q0, [x27, #0x8]
101540dd8:     	ldp	x11, x12, [x3]
101540ddc:     	ldr	x13, [x3, #0x10]
101540de0:     	ldr	x14, [sp, #0x558]
101540de4:     	ldr	x15, [sp, #0x560]
101540de8:     	cmp	x11, x10
101540dec:     	ccmp	x12, x14, #0x0, eq
101540df0:     	ccmp	x13, x15, #0x0, eq
101540df4:     	cset	w10, ne
101540df8:     	cbnz	x9, 0x101540e1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540dfc:     	cbnz	w10, 0x101540e1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540e00:     	ldr	x9, [x0, #0x490]
101540e04:     	ldr	w10, [x9, #0x2f0]
101540e08:     	cbnz	w10, 0x101540e1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540e0c:     	ldr	w10, [x9, #0x2e8]
101540e10:     	cbnz	w10, 0x101540e1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540e14:     	ldrb	w10, [x9, #0x338]
101540e18:     	tbz	w10, #0x0, 0x1015418e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x150c>
101540e1c:     	str	wzr, [x8]
101540e20:     	mov	w9, #0xc                ; =12
101540e24:     	strb	w9, [x8, #0x8]
101540e28:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540e2c:     	add	x9, x9, #0xeb0
101540e30:     	mov	w10, #0x2e              ; =46
101540e34:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540e38:     	str	wzr, [x8]
101540e3c:     	mov	w9, #0xc                ; =12
101540e40:     	adrp	x10, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540e44:     	add	x10, x10, #0xd04
101540e48:     	stp	x9, x10, [x8, #0x8]
101540e4c:     	mov	w9, #0x14               ; =20
101540e50:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540e54:     	str	wzr, [x8]
101540e58:     	mov	w9, #0xc                ; =12
101540e5c:     	strb	w9, [x8, #0x8]
101540e60:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540e64:     	add	x9, x9, #0xcce
101540e68:     	mov	w10, #0x36              ; =54
101540e6c:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540e70:     	str	wzr, [x8]
101540e74:     	mov	w9, #0xc                ; =12
101540e78:     	strb	w9, [x8, #0x8]
101540e7c:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540e80:     	add	x9, x9, #0xdee
101540e84:     	mov	w10, #0x26              ; =38
101540e88:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540e8c:     	ldr	x8, [x26, #0x300]
101540e90:     	ldr	x9, [x26, #0x308]
101540e94:     	adds	x8, x8, x22
101540e98:     	b.hs	0x101541e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a84>
101540e9c:     	cmp	x8, x9
101540ea0:     	b.ls	0x1015411cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdf8>
101540ea4:     	mov	x12, x23
101540ea8:     	mov	w11, #0x0               ; =0
101540eac:     	mov	w10, #0x0               ; =0
101540eb0:     	mov	w13, #0x6               ; =6
101540eb4:     	b	0x101541008 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101540eb8:     	ldr	x10, [x0, #0x490]
101540ebc:     	ldr	x10, [x10, #0x3c0]
101540ec0:     	cbz	x10, 0x101541028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540ec4:     	ldr	x11, [x10, #0x40]
101540ec8:     	cmp	x11, #0x2
101540ecc:     	b.eq	0x101541028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540ed0:     	ldr	x11, [x10, #0xd8]
101540ed4:     	cmp	x11, x9
101540ed8:     	b.ne	0x101541028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540edc:     	ldr	x11, [x23, x22]
101540ee0:     	ldr	x12, [x10, #0x78]
101540ee4:     	cmp	x11, x12
101540ee8:     	b.hs	0x101541028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540eec:     	ldr	x10, [x10, #0x70]
101540ef0:     	mov	w12, #0x108             ; =264
101540ef4:     	mul	x11, x11, x12
101540ef8:     	ldr	x10, [x10, x11]
101540efc:     	cbnz	x10, 0x101540c40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x86c>
101540f00:     	add	x24, sp, #0x440
101540f04:     	stp	x9, x1, [sp, #0x48]
101540f08:     	mov	x28, x8
101540f0c:     	ldr	x8, [x0, #0x4d8]
101540f10:     	cbz	x8, 0x1015416d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1300>
101540f14:     	ldr	x10, [x21, #0xb8]
101540f18:     	add	x9, x10, #0x2
101540f1c:     	ldr	x11, [x0, #0x4e0]
101540f20:     	cmp	x9, x11
101540f24:     	b.hs	0x1015416d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1300>
101540f28:     	str	x0, [sp, #0x58]
101540f2c:     	add	x10, x10, #0x3
101540f30:     	cmp	x10, x11
101540f34:     	b.hs	0x1015416d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1300>
101540f38:     	ldr	x9, [x8, x9, lsl #3]
101540f3c:     	ldr	x8, [x8, x10, lsl #3]
101540f40:     	stp	x9, x8, [sp, #0x38]
101540f44:     	ldr	q0, [x3]
101540f48:     	str	q0, [sp, #0x440]
101540f4c:     	mov	w8, #0x5                ; =5
101540f50:     	str	x8, [sp, #0x450]
101540f54:     	add	x0, sp, #0x550
101540f58:     	add	x3, sp, #0x440
101540f5c:     	ldp	x2, x1, [sp, #0x50]
101540f60:     	bl	0x101533a90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
101540f64:     	ldr	w8, [sp, #0x550]
101540f68:     	cmp	w8, #0x6
101540f6c:     	b.ne	0x101541b08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1734>
101540f70:     	ldr	x1, [x19, #0x380]
101540f74:     	ldr	x8, [sp, #0x50]
101540f78:     	cmp	x8, x1
101540f7c:     	b.hs	0x1015439f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x361c>
101540f80:     	ldr	x9, [x19, #0x378]
101540f84:     	mov	w10, #0x170             ; =368
101540f88:     	ldr	x8, [sp, #0x50]
101540f8c:     	madd	x8, x8, x10, x9
101540f90:     	ldp	x8, x9, [x8]
101540f94:     	cmp	x8, #0x2
101540f98:     	sbcs	xzr, x9, xzr
101540f9c:     	b.hs	0x101541c5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1888>
101540fa0:     	ldr	x1, [x19, #0x408]
101540fa4:     	ldr	x8, [sp, #0x50]
101540fa8:     	cmp	x8, x1
101540fac:     	b.hs	0x101543a00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x362c>
101540fb0:     	ldr	x9, [x19, #0x400]
101540fb4:     	ldr	x8, [sp, #0x50]
101540fb8:     	add	x9, x9, x8, lsl #9
101540fbc:     	str	x9, [sp, #0x30]
101540fc0:     	ldp	x9, x8, [x9]
101540fc4:     	eor	x9, x9, #0x2
101540fc8:     	orr	x8, x9, x8
101540fcc:     	cbnz	x8, 0x101541c9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18c8>
101540fd0:     	str	wzr, [x28]
101540fd4:     	mov	w8, #0xc                ; =12
101540fd8:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
101540fdc:     	add	x9, x9, #0x23a
101540fe0:     	stp	x8, x9, [x28, #0x8]
101540fe4:     	mov	w8, #0x23               ; =35
101540fe8:     	str	x8, [x28, #0x18]
101540fec:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540ff0:     	mov	x10, x9
101540ff4:     	lsr	x11, x9, #32
101540ff8:     	ldur	q0, [x27, #0x18]
101540ffc:     	stur	q0, [x29, #-0x70]
101541000:     	mov	w13, #0x7               ; =7
101541004:     	mov	x9, x14
101541008:     	str	wzr, [x12]
10154100c:     	strb	w13, [x12, #0x8]
101541010:     	stp	x8, x9, [x12, #0x10]
101541014:     	stp	w10, w11, [x12, #0x20]
101541018:     	ldur	q0, [x29, #-0x70]
10154101c:     	stur	q0, [x12, #0x28]
101541020:     	str	wzr, [x12, #0x38]
101541024:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541028:     	str	wzr, [x8]
10154102c:     	mov	w9, #0xc                ; =12
101541030:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101541034:     	add	x10, x10, #0xa70
101541038:     	stp	x9, x10, [x8, #0x8]
10154103c:     	mov	w9, #0x2b               ; =43
101541040:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101541044:     	sub	x10, x22, #0x1b
101541048:     	cmp	x10, #0x2
10154104c:     	b.hs	0x101541354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf80>
101541050:     	ldp	x5, x6, [x3, #0x8]
101541054:     	ldr	x4, [x3]
101541058:     	mov	x0, x8
10154105c:     	mov	x1, x25
101541060:     	mov	x2, x20
101541064:     	mov	x3, x19
101541068:     	add	sp, sp, #0x810
10154106c:     	ldp	x29, x30, [sp, #0x50]
101541070:     	ldp	x20, x19, [sp, #0x40]
101541074:     	ldp	x22, x21, [sp, #0x30]
101541078:     	ldp	x24, x23, [sp, #0x20]
10154107c:     	ldp	x26, x25, [sp, #0x10]
101541080:     	ldp	x28, x27, [sp], #0x60
101541084:     	b	0x10153e820 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation17frozen_map_helper>
101541088:     	cbnz	x10, 0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
10154108c:     	ldr	x12, [x0, #0x490]
101541090:     	ldr	w10, [x12, #0x2f0]
101541094:     	cmp	w10, #0x1
101541098:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
10154109c:     	ldr	w10, [x12, #0x2f4]
1015410a0:     	cmp	w10, w9
1015410a4:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
1015410a8:     	ldr	w9, [x12, #0x2e8]
1015410ac:     	cmp	w9, #0x1
1015410b0:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
1015410b4:     	ldr	w9, [x11, #0x30]
1015410b8:     	ldr	w10, [x12, #0x2ec]
1015410bc:     	cmp	w10, w9
1015410c0:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
1015410c4:     	stp	x14, x12, [sp, #0x38]
1015410c8:     	stp	x8, x1, [sp, #0x48]
1015410cc:     	mov	w8, #0x1                ; =1
1015410d0:     	orr	x8, x8, x9, lsl #1
1015410d4:     	str	x0, [sp, #0x58]
1015410d8:     	ldr	x1, [x0, #0x4c0]
1015410dc:     	cmp	x8, x1
1015410e0:     	b.hs	0x10154396c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3598>
1015410e4:     	ldr	x9, [sp, #0x58]
1015410e8:     	ldr	x9, [x9, #0x4b8]
1015410ec:     	ldr	x8, [x9, x8, lsl #3]
1015410f0:     	cmp	x8, #0x1
1015410f4:     	ldp	x9, x8, [sp, #0x40]
1015410f8:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
1015410fc:     	add	x0, x9, #0x3b8
101541100:     	bl	0x10236d8b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101541104:     	ldp	x9, x8, [sp, #0x40]
101541108:     	cmp	x0, x26
10154110c:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541110:     	cmp	x1, x19
101541114:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541118:     	add	x8, sp, #0x550
10154111c:     	add	x0, x9, #0x3b8
101541120:     	bl	0x10236cbc4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101541124:     	ldr	x8, [sp, #0x48]
101541128:     	ldr	x9, [sp, #0x550]
10154112c:     	cmp	x9, #0x1
101541130:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541134:     	ldr	x9, [sp, #0x558]
101541138:     	cmp	x9, x22
10154113c:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541140:     	ldr	x9, [sp, #0x560]
101541144:     	cmp	x9, x25
101541148:     	b.ne	0x101541178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
10154114c:     	cbz	x20, 0x101541eac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ad8>
101541150:     	cmp	x20, #0x2
101541154:     	b.eq	0x101541e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a9c>
101541158:     	cmp	x20, #0x3
10154115c:     	b.ne	0x101541e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab8>
101541160:     	cbnz	x28, 0x101541e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab8>
101541164:     	ldp	x1, x2, [x23, #0x8]
101541168:     	ldr	x0, [sp, #0x50]
10154116c:     	bl	0x1015577a4 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
101541170:     	tbnz	w0, #0x0, 0x101541e84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab0>
101541174:     	b	0x101541e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab8>
101541178:     	str	wzr, [x8]
10154117c:     	mov	w9, #0xc                ; =12
101541180:     	strb	w9, [x8, #0x8]
101541184:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101541188:     	add	x9, x9, #0x556
10154118c:     	mov	w10, #0x3e              ; =62
101541190:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541194:     	str	wzr, [x8]
101541198:     	mov	w9, #0xc                ; =12
10154119c:     	adrp	x10, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
1015411a0:     	add	x10, x10, #0xe35
1015411a4:     	stp	x9, x10, [x8, #0x8]
1015411a8:     	mov	w9, #0x13               ; =19
1015411ac:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015411b0:     	str	wzr, [x8]
1015411b4:     	mov	w9, #0xc                ; =12
1015411b8:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015411bc:     	add	x10, x10, #0x499
1015411c0:     	stp	x9, x10, [x8, #0x8]
1015411c4:     	mov	w9, #0x19               ; =25
1015411c8:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015411cc:     	mov	x0, x20
1015411d0:     	mov	x1, x19
1015411d4:     	mov	x10, x25
1015411d8:     	str	x8, [x26, #0x300]
1015411dc:     	add	x8, sp, #0x550
1015411e0:     	cmn	x10, #0xd
1015411e4:     	b.ne	0x101541204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe30>
1015411e8:     	bl	0x101546b1c <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation17check_prefix_exit>
1015411ec:     	ldr	w8, [sp, #0x550]
1015411f0:     	cmp	w8, #0x6
1015411f4:     	b.ne	0x101541238 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe64>
1015411f8:     	mov	x8, x23
1015411fc:     	mov	x9, x25
101541200:     	b	0x10154125c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe88>
101541204:     	bl	0x101546c80 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation19check_prefix_header>
101541208:     	ldr	w8, [sp, #0x550]
10154120c:     	cmp	w8, #0x6
101541210:     	b.ne	0x101541238 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe64>
101541214:     	mov	x9, x25
101541218:     	cmn	x25, #0xa
10154121c:     	mov	x8, x23
101541220:     	b.ne	0x10154125c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe88>
101541224:     	mov	x1, x20
101541228:     	ldr	x10, [x20, #0xa8]
10154122c:     	mov	x3, x21
101541230:     	cbnz	x10, 0x101541304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf30>
101541234:     	b	0x101541280 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xeac>
101541238:     	ldr	q0, [sp, #0x570]
10154123c:     	ldr	q1, [sp, #0x580]
101541240:     	stp	q0, q1, [x23, #0x20]
101541244:     	ldr	q0, [sp, #0x590]
101541248:     	str	q0, [x23, #0x40]
10154124c:     	ldr	q0, [sp, #0x560]
101541250:     	ldr	q1, [sp, #0x550]
101541254:     	stp	q1, q0, [x23]
101541258:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154125c:     	mov	x3, x21
101541260:     	ldp	x10, x11, [x21]
101541264:     	ldr	x12, [x21, #0x10]
101541268:     	orr	x10, x10, x11
10154126c:     	mov	x1, x20
101541270:     	ldr	x11, [x20, #0xa8]
101541274:     	orr	x11, x12, x11
101541278:     	orr	x10, x10, x11
10154127c:     	cbnz	x10, 0x101541304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf30>
101541280:     	ldr	x10, [x1, #0x290]
101541284:     	cmp	x10, #0x6
101541288:     	b.ne	0x101541304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf30>
10154128c:     	ldr	x10, [x1, #0x4a0]
101541290:     	ldr	x11, [x10]
101541294:     	cmp	x11, #0x2
101541298:     	b.eq	0x10154215c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d88>
10154129c:     	add	x25, x1, #0x238
1015412a0:     	ldr	x11, [x25]
1015412a4:     	cmp	x11, #0x3
1015412a8:     	b.eq	0x101542168 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d94>
1015412ac:     	ldr	x22, [x10, #0x138]
1015412b0:     	ldr	w11, [x1, #0x280]
1015412b4:     	cmn	x9, #0xc
1015412b8:     	b.gt	0x101541440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x106c>
1015412bc:     	cmn	x9, #0xd
1015412c0:     	b.eq	0x10154156c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1198>
1015412c4:     	cmn	x9, #0xc
1015412c8:     	b.ne	0x101541550 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x117c>
1015412cc:     	mov	x9, x19
1015412d0:     	cmp	w11, w9
1015412d4:     	b.ne	0x1015412e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf14>
1015412d8:     	ldrb	w11, [x1, #0x288]
1015412dc:     	tbz	w11, #0x0, 0x1015412e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf14>
1015412e0:     	ldrb	w11, [x1, #0x289]
1015412e4:     	tbz	w11, #0x0, 0x101541714 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1340>
1015412e8:     	str	wzr, [x8]
1015412ec:     	mov	w9, #0xc                ; =12
1015412f0:     	strb	w9, [x8, #0x8]
1015412f4:     	adrp	x9, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
1015412f8:     	add	x9, x9, #0x1ba
1015412fc:     	mov	w10, #0x29              ; =41
101541300:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541304:     	str	wzr, [x8]
101541308:     	mov	w9, #0xc                ; =12
10154130c:     	strb	w9, [x8, #0x8]
101541310:     	adrp	x9, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101541314:     	add	x9, x9, #0x1ff
101541318:     	mov	w10, #0x24              ; =36
10154131c:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541320:     	cmp	x22, #0xa
101541324:     	b.ne	0x1015413a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd0>
101541328:     	mov	x0, x8
10154132c:     	mov	x1, x25
101541330:     	mov	x2, x20
101541334:     	add	sp, sp, #0x810
101541338:     	ldp	x29, x30, [sp, #0x50]
10154133c:     	ldp	x20, x19, [sp, #0x40]
101541340:     	ldp	x22, x21, [sp, #0x30]
101541344:     	ldp	x24, x23, [sp, #0x20]
101541348:     	ldp	x26, x25, [sp, #0x10]
10154134c:     	ldp	x28, x27, [sp], #0x60
101541350:     	b	0x1015340d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation17begin_closed_tail>
101541354:     	cmp	x22, #0x1e
101541358:     	b.ne	0x1015413a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd0>
10154135c:     	mov	x0, x8
101541360:     	mov	x1, x25
101541364:     	mov	x2, x20
101541368:     	add	sp, sp, #0x810
10154136c:     	ldp	x29, x30, [sp, #0x50]
101541370:     	ldp	x20, x19, [sp, #0x40]
101541374:     	ldp	x22, x21, [sp, #0x30]
101541378:     	ldp	x24, x23, [sp, #0x20]
10154137c:     	ldp	x26, x25, [sp, #0x10]
101541380:     	ldp	x28, x27, [sp], #0x60
101541384:     	b	0x101530e44 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB4_10Invocation21begin_numeric_segment>
101541388:     	str	wzr, [x8]
10154138c:     	mov	w9, #0xc                ; =12
101541390:     	strb	w9, [x8, #0x8]
101541394:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541398:     	add	x9, x9, #0xe48
10154139c:     	mov	w10, #0x18              ; =24
1015413a0:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015413a4:     	mov	x24, x3
1015413a8:     	mov	x19, x8
1015413ac:     	mov	x0, x9
1015413b0:     	mov	x1, x23
1015413b4:     	mov	x2, x20
1015413b8:     	bl	0x10153ea74 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation20frozen_native_action>
1015413bc:     	tbnz	w0, #0x0, 0x101541420 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
1015413c0:     	mov	x8, x25
1015413c4:     	ldr	x25, [x25, #0x490]
1015413c8:     	str	x8, [sp, #0x58]
1015413cc:     	ldr	x26, [x8, #0x4a0]
1015413d0:     	mov	x0, x25
1015413d4:     	mov	x1, x26
1015413d8:     	mov	x2, x20
1015413dc:     	bl	0x101550134 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
1015413e0:     	tbnz	w0, #0x0, 0x101541420 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
1015413e4:     	mov	x0, x25
1015413e8:     	mov	x1, x26
1015413ec:     	mov	x2, x20
1015413f0:     	bl	0x101550064 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015413f4:     	tbnz	w0, #0x0, 0x101541420 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
1015413f8:     	mov	x0, x25
1015413fc:     	mov	x1, x26
101541400:     	mov	x2, x20
101541404:     	bl	0x1015500cc <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_exit>
101541408:     	tbnz	w0, #0x0, 0x101541420 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
10154140c:     	mov	x0, x25
101541410:     	mov	x1, x26
101541414:     	mov	x2, x20
101541418:     	bl	0x10153c274 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
10154141c:     	tbz	w0, #0x0, 0x101541954 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1580>
101541420:     	str	wzr, [x19]
101541424:     	mov	w8, #0xc                ; =12
101541428:     	strb	w8, [x19, #0x8]
10154142c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541430:     	add	x8, x8, #0xa78
101541434:     	mov	w9, #0x2b               ; =43
101541438:     	stp	x8, x9, [x19, #0x10]
10154143c:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541440:     	cmn	x9, #0xb
101541444:     	b.eq	0x101541618 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1244>
101541448:     	cmn	x9, #0xa
10154144c:     	b.ne	0x101541550 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x117c>
101541450:     	ldrb	w21, [x1, #0x284]
101541454:     	ldr	x2, [x1, #0x278]
101541458:     	mov	x8, x1
10154145c:     	add	x0, sp, #0x550
101541460:     	mov	x1, x3
101541464:     	add	x3, x8, #0x250
101541468:     	bl	0x10154b414 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB4_9Retention7checked>
10154146c:     	ldr	w8, [sp, #0x550]
101541470:     	cmp	w8, #0x6
101541474:     	b.ne	0x10154169c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12c8>
101541478:     	ldr	x8, [sp, #0x568]
10154147c:     	ldur	q0, [x27, #0x8]
101541480:     	str	q0, [sp, #0x220]
101541484:     	str	x8, [sp, #0x230]
101541488:     	tbnz	w21, #0x0, 0x1015416f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1320>
10154148c:     	mov	x8, x20
101541490:     	ldr	x9, [x20, #0xc0]
101541494:     	cmp	x9, #0x2
101541498:     	b.ne	0x1015416f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1320>
10154149c:     	ldr	x9, [x8, #0x220]
1015414a0:     	cmp	x9, #0x2
1015414a4:     	b.eq	0x1015416f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1320>
1015414a8:     	ldr	x9, [x8, #0x1d8]
1015414ac:     	cmp	x9, x22
1015414b0:     	b.ne	0x1015416f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1320>
1015414b4:     	ldr	x21, [x8, #0x4e0]
1015414b8:     	mov	x8, #-0x41              ; =-65
1015414bc:     	movk	x8, #0xfff, lsl #48
1015414c0:     	cmp	x21, x8
1015414c4:     	b.hi	0x101542b98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27c4>
1015414c8:     	ldr	x8, [x20, #0x490]
1015414cc:     	lsl	x9, x21, #4
1015414d0:     	add	x0, sp, #0x550
1015414d4:     	add	x1, x8, #0x2f8
1015414d8:     	add	x4, x9, #0x400
1015414dc:     	mov	w2, #0x0                ; =0
1015414e0:     	bl	0x1015293e0 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015414e4:     	ldrb	w8, [sp, #0x550]
1015414e8:     	cmp	w8, #0xe
1015414ec:     	b.ne	0x101541888 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b4>
1015414f0:     	cbz	x21, 0x101541504 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1130>
1015414f4:     	ldr	x0, [x20, #0x4d8]
1015414f8:     	cbz	x0, 0x101541bc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17f0>
1015414fc:     	lsl	x1, x21, #3
101541500:     	bl	0x103a03918 <dyld_stub_binder+0x103a03918>
101541504:     	add	x0, x20, #0x1d8
101541508:     	bl	0x101526bb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
10154150c:     	mov	w8, #0x2                ; =2
101541510:     	str	x8, [x20, #0x220]
101541514:     	ldr	x8, [x20, #0x238]
101541518:     	cmp	x8, #0x3
10154151c:     	b.eq	0x101543394 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc0>
101541520:     	ldr	q0, [sp, #0x220]
101541524:     	str	q0, [x25]
101541528:     	ldr	x8, [sp, #0x230]
10154152c:     	str	x8, [x25, #0x10]
101541530:     	ldr	x8, [x25]
101541534:     	cmp	x8, #0x3
101541538:     	b.eq	0x1015433a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fcc>
10154153c:     	mov	w8, #0x1                ; =1
101541540:     	str	w8, [x20, #0x268]
101541544:     	str	w19, [x20, #0x26c]
101541548:     	str	xzr, [x23, #0x8]
10154154c:     	b	0x101541848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1474>
101541550:     	str	wzr, [x8]
101541554:     	mov	w9, #0xc                ; =12
101541558:     	strb	w9, [x8, #0x8]
10154155c:     	adrp	x9, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101541560:     	add	x9, x9, #0x1e3
101541564:     	mov	w10, #0x1c              ; =28
101541568:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154156c:     	ldr	w9, [x1, #0x270]
101541570:     	cbnz	w9, 0x101541668 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1294>
101541574:     	ldr	x9, [x1, #0xc0]
101541578:     	cmp	x9, #0x2
10154157c:     	b.ne	0x101541668 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1294>
101541580:     	ldr	x9, [x1, #0x220]
101541584:     	cmp	x9, #0x2
101541588:     	b.eq	0x101541668 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1294>
10154158c:     	ldr	x9, [x1, #0x1d8]
101541590:     	cmp	x9, x22
101541594:     	b.ne	0x101541668 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1294>
101541598:     	ldr	x21, [x1, #0x4e0]
10154159c:     	mov	x8, #-0x41              ; =-65
1015415a0:     	movk	x8, #0xfff, lsl #48
1015415a4:     	cmp	x21, x8
1015415a8:     	b.hi	0x101542b98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27c4>
1015415ac:     	ldr	x8, [x20, #0x490]
1015415b0:     	lsl	x9, x21, #4
1015415b4:     	add	x0, sp, #0x550
1015415b8:     	add	x1, x8, #0x2f8
1015415bc:     	add	x4, x9, #0x400
1015415c0:     	mov	w2, #0x0                ; =0
1015415c4:     	bl	0x1015293e0 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015415c8:     	ldrb	w8, [sp, #0x550]
1015415cc:     	cmp	w8, #0xe
1015415d0:     	b.ne	0x101541888 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b4>
1015415d4:     	cbz	x21, 0x1015415e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1214>
1015415d8:     	ldr	x0, [x20, #0x4d8]
1015415dc:     	cbz	x0, 0x101541bc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17f0>
1015415e0:     	lsl	x1, x21, #3
1015415e4:     	bl	0x103a03918 <dyld_stub_binder+0x103a03918>
1015415e8:     	add	x0, x20, #0x1d8
1015415ec:     	bl	0x101526bb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
1015415f0:     	mov	w8, #0x2                ; =2
1015415f4:     	str	x8, [x20, #0x220]
1015415f8:     	ldr	x8, [x20, #0x238]
1015415fc:     	cmp	x8, #0x3
101541600:     	b.eq	0x1015432c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ef4>
101541604:     	mov	w8, #0x1                ; =1
101541608:     	str	w8, [x20, #0x270]
10154160c:     	str	w19, [x20, #0x274]
101541610:     	str	xzr, [x23, #0x8]
101541614:     	b	0x101541848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1474>
101541618:     	cmp	w11, w19
10154161c:     	b.ne	0x101541684 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12b0>
101541620:     	ldrb	w9, [x1, #0x288]
101541624:     	tbnz	w9, #0x0, 0x101541684 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12b0>
101541628:     	ldrb	w9, [x1, #0x289]
10154162c:     	tbnz	w9, #0x0, 0x101541684 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12b0>
101541630:     	add	x0, sp, #0x550
101541634:     	mov	x2, x19
101541638:     	mov	x4, x22
10154163c:     	bl	0x101536a40 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23prepare_borrowed_region>
101541640:     	ldr	w8, [sp, #0x550]
101541644:     	cmp	w8, #0x6
101541648:     	b.ne	0x101541854 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1480>
10154164c:     	ldr	x8, [x25]
101541650:     	cmp	x8, #0x3
101541654:     	b.eq	0x101543028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c54>
101541658:     	ldur	q0, [x27, #0x8]
10154165c:     	mov	w8, #0x1                ; =1
101541660:     	strb	w8, [x20, #0x288]
101541664:     	b	0x101541844 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1470>
101541668:     	str	wzr, [x8]
10154166c:     	mov	w9, #0xc                ; =12
101541670:     	strb	w9, [x8, #0x8]
101541674:     	adrp	x9, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101541678:     	add	x9, x9, #0x12b
10154167c:     	mov	w10, #0x2f              ; =47
101541680:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541684:     	str	wzr, [x8]
101541688:     	mov	w9, #0xc                ; =12
10154168c:     	strb	w9, [x8, #0x8]
101541690:     	adrp	x9, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101541694:     	add	x9, x9, #0x18c
101541698:     	b	0x101540e30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa5c>
10154169c:     	ldr	q0, [sp, #0x560]
1015416a0:     	ldr	q1, [sp, #0x570]
1015416a4:     	stur	q0, [x24, #0xc]
1015416a8:     	ldur	q0, [x27, #0x4]
1015416ac:     	str	q0, [sp, #0x440]
1015416b0:     	ldr	q0, [sp, #0x580]
1015416b4:     	ldr	q2, [sp, #0x590]
1015416b8:     	stp	q0, q2, [x23, #0x30]
1015416bc:     	ldr	q0, [sp, #0x440]
1015416c0:     	stur	q0, [x23, #0x4]
1015416c4:     	ldur	q0, [x24, #0xc]
1015416c8:     	stp	q0, q1, [x23, #0x10]
1015416cc:     	str	w8, [x23]
1015416d0:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015416d4:     	str	wzr, [x28]
1015416d8:     	mov	w8, #0xc                ; =12
1015416dc:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015416e0:     	add	x9, x9, #0x454
1015416e4:     	stp	x8, x9, [x28, #0x8]
1015416e8:     	mov	w8, #0x30               ; =48
1015416ec:     	str	x8, [x28, #0x18]
1015416f0:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015416f4:     	str	wzr, [x23]
1015416f8:     	mov	w8, #0xc                ; =12
1015416fc:     	strb	w8, [x23, #0x8]
101541700:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101541704:     	add	x8, x8, #0x15a
101541708:     	mov	w9, #0x32               ; =50
10154170c:     	stp	x8, x9, [x23, #0x10]
101541710:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541714:     	ldr	x1, [x10, #0x270]
101541718:     	cmp	x9, x1
10154171c:     	b.hs	0x10154397c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35a8>
101541720:     	ldr	x8, [x10, #0x268]
101541724:     	add	x8, x8, x19, lsl #4
101541728:     	ldr	w9, [x8]
10154172c:     	tbz	w9, #0x0, 0x101541934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1560>
101541730:     	ldr	x3, [x8, #0x8]
101541734:     	add	x0, sp, #0x550
101541738:     	mov	x1, x20
10154173c:     	mov	x2, x21
101541740:     	bl	0x101534124 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation19begin_closed_region>
101541744:     	ldr	w8, [sp, #0x550]
101541748:     	cmp	w8, #0x6
10154174c:     	b.ne	0x101541854 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1480>
101541750:     	ldr	x8, [x25]
101541754:     	cmp	x8, #0x3
101541758:     	b.eq	0x101543354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f80>
10154175c:     	ldur	q0, [x27, #0x8]
101541760:     	mov	w8, #0x1                ; =1
101541764:     	strb	w8, [x20, #0x289]
101541768:     	b	0x101541844 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1470>
10154176c:     	mov	x22, x0
101541770:     	ldr	x11, [x0, #0x3d8]
101541774:     	cbz	x11, 0x1015419b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15dc>
101541778:     	ldr	x12, [x22, #0x3d0]
10154177c:     	cmp	x12, x8
101541780:     	csel	x8, xzr, x8, lo
101541784:     	sub	x8, x12, x8
101541788:     	ldr	x11, [x22, #0x3c8]
10154178c:     	mov	w12, #0x58              ; =88
101541790:     	madd	x8, x8, x12, x11
101541794:     	ldr	x11, [x8, #0x40]
101541798:     	cmp	x11, x9
10154179c:     	b.ne	0x101541914 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1540>
1015417a0:     	ldr	w9, [x10, #0x2e8]
1015417a4:     	cmp	w9, #0x1
1015417a8:     	b.ne	0x101541914 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1540>
1015417ac:     	ldr	w9, [x19, #0x34]
1015417b0:     	ldr	w10, [x10, #0x2ec]
1015417b4:     	cmp	w10, w9
1015417b8:     	b.ne	0x101541914 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1540>
1015417bc:     	lsl	x0, x9, #1
1015417c0:     	ldr	x1, [x22, #0x4c0]
1015417c4:     	cmp	x0, x1
1015417c8:     	b.hs	0x101543a64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3690>
1015417cc:     	ldr	x9, [x8, #0x50]
1015417d0:     	ldr	x10, [x22, #0x4b8]
1015417d4:     	ldr	x10, [x10, x0, lsl #3]
1015417d8:     	subs	x9, x9, x10
1015417dc:     	b.lo	0x101541914 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1540>
1015417e0:     	ldr	x10, [x8, #0x48]
1015417e4:     	cmp	x9, x10
1015417e8:     	b.ne	0x101541914 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1540>
1015417ec:     	ldr	x10, [x22, #0x3f8]
1015417f0:     	ldr	x9, [x22, #0x3e8]
1015417f4:     	cmp	x9, x10
1015417f8:     	b.eq	0x101541820 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x144c>
1015417fc:     	add	x10, x9, #0xc8
101541800:     	str	x10, [x22, #0x3e8]
101541804:     	ldr	x15, [x9]
101541808:     	ldp	w14, w13, [x9, #0x8]
10154180c:     	ldrb	w12, [x9, #0x10]
101541810:     	ldp	x11, x10, [x9, #0x18]
101541814:     	cbz	x15, 0x10154284c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2478>
101541818:     	cmp	x15, #0x2
10154181c:     	b.ne	0x101542a40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x266c>
101541820:     	str	wzr, [x21]
101541824:     	mov	w8, #0xc                ; =12
101541828:     	strb	w8, [x21, #0x8]
10154182c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541830:     	add	x8, x8, #0xd35
101541834:     	mov	w9, #0x16               ; =22
101541838:     	b	0x10154192c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1558>
10154183c:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
101541840:     	ldr	q0, [x8, #0x80]
101541844:     	stur	q0, [x23, #0x8]
101541848:     	mov	w8, #0x6                ; =6
10154184c:     	str	w8, [x23]
101541850:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541854:     	ldr	w9, [sp, #0x554]
101541858:     	ldur	q0, [x27, #0x18]
10154185c:     	stur	q0, [x23, #0x18]
101541860:     	ldur	q0, [x27, #0x28]
101541864:     	stur	q0, [x23, #0x28]
101541868:     	ldur	q0, [x27, #0x38]
10154186c:     	stur	q0, [x23, #0x38]
101541870:     	ldr	x10, [sp, #0x598]
101541874:     	str	x10, [x23, #0x48]
101541878:     	ldur	q0, [x27, #0x8]
10154187c:     	stp	w8, w9, [x23]
101541880:     	stur	q0, [x23, #0x8]
101541884:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541888:     	ldr	q0, [sp, #0x550]
10154188c:     	ldr	q1, [sp, #0x560]
101541890:     	str	q0, [sp, #0x440]
101541894:     	str	q1, [sp, #0x450]
101541898:     	ldr	q2, [sp, #0x570]
10154189c:     	str	q2, [sp, #0x460]
1015418a0:     	ldr	x8, [sp, #0x580]
1015418a4:     	str	x8, [sp, #0x470]
1015418a8:     	stur	q0, [x27, #0x4]
1015418ac:     	stur	q1, [x27, #0x14]
1015418b0:     	stur	q2, [x27, #0x24]
1015418b4:     	stur	x8, [x27, #0x34]
1015418b8:     	str	wzr, [x23]
1015418bc:     	ldr	q0, [sp, #0x550]
1015418c0:     	ldr	q1, [sp, #0x560]
1015418c4:     	stur	q0, [x23, #0x4]
1015418c8:     	stur	q1, [x23, #0x14]
1015418cc:     	ldr	q0, [sp, #0x570]
1015418d0:     	stur	q0, [x23, #0x24]
1015418d4:     	ldur	q0, [x27, #0x2c]
1015418d8:     	str	q0, [x23, #0x30]
1015418dc:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015418e0:     	mov	x19, x8
1015418e4:     	add	x0, sp, #0x550
1015418e8:     	add	x1, x9, #0x2f8
1015418ec:     	mov	w2, #0x0                ; =0
1015418f0:     	mov	w4, #0x100              ; =256
1015418f4:     	bl	0x1015293e0 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015418f8:     	ldrb	w8, [sp, #0x550]
1015418fc:     	cmp	w8, #0xe
101541900:     	b.ne	0x1015419d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15fc>
101541904:     	str	xzr, [x19, #0x8]
101541908:     	mov	w8, #0x6                ; =6
10154190c:     	str	w8, [x19]
101541910:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541914:     	str	wzr, [x21]
101541918:     	mov	w8, #0xc                ; =12
10154191c:     	strb	w8, [x21, #0x8]
101541920:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541924:     	add	x8, x8, #0xdbb
101541928:     	mov	w9, #0x33               ; =51
10154192c:     	stp	x8, x9, [x21, #0x10]
101541930:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541934:     	str	wzr, [x23]
101541938:     	mov	w8, #0xc                ; =12
10154193c:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101541940:     	add	x9, x9, #0x704
101541944:     	stp	x8, x9, [x23, #0x8]
101541948:     	mov	w8, #0x26               ; =38
10154194c:     	str	x8, [x23, #0x18]
101541950:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541954:     	cmp	x22, #0x9
101541958:     	b.eq	0x101541c00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x182c>
10154195c:     	cmp	x22, #0x8
101541960:     	b.ne	0x101541c30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x185c>
101541964:     	mov	x0, x19
101541968:     	ldr	x1, [sp, #0x58]
10154196c:     	mov	x2, x20
101541970:     	mov	x3, x24
101541974:     	add	sp, sp, #0x810
101541978:     	ldp	x29, x30, [sp, #0x50]
10154197c:     	ldp	x20, x19, [sp, #0x40]
101541980:     	ldp	x22, x21, [sp, #0x30]
101541984:     	ldp	x24, x23, [sp, #0x20]
101541988:     	ldp	x26, x25, [sp, #0x10]
10154198c:     	ldp	x28, x27, [sp], #0x60
101541990:     	b	0x101537bdc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation24prepare_borrowed_strings>
101541994:     	str	wzr, [x8]
101541998:     	mov	w9, #0xc                ; =12
10154199c:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015419a0:     	add	x10, x10, #0x7d
1015419a4:     	stp	x9, x10, [x8, #0x8]
1015419a8:     	mov	w9, #0x1a               ; =26
1015419ac:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015419b0:     	str	wzr, [x21]
1015419b4:     	mov	w8, #0xc                ; =12
1015419b8:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
1015419bc:     	add	x9, x9, #0xd18
1015419c0:     	stp	x8, x9, [x21, #0x8]
1015419c4:     	mov	w8, #0x1d               ; =29
1015419c8:     	str	x8, [x21, #0x18]
1015419cc:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015419d0:     	ldr	q0, [sp, #0x550]
1015419d4:     	ldr	q1, [sp, #0x560]
1015419d8:     	str	q0, [sp, #0x440]
1015419dc:     	str	q1, [sp, #0x450]
1015419e0:     	ldr	q2, [sp, #0x570]
1015419e4:     	str	q2, [sp, #0x460]
1015419e8:     	ldr	x8, [sp, #0x580]
1015419ec:     	str	x8, [sp, #0x470]
1015419f0:     	stur	q0, [x27, #0x4]
1015419f4:     	stur	q1, [x27, #0x14]
1015419f8:     	stur	q2, [x27, #0x24]
1015419fc:     	stur	x8, [x27, #0x34]
101541a00:     	str	wzr, [x19]
101541a04:     	ldr	q0, [sp, #0x550]
101541a08:     	ldr	q1, [sp, #0x560]
101541a0c:     	stur	q0, [x19, #0x4]
101541a10:     	stur	q1, [x19, #0x14]
101541a14:     	ldr	q0, [sp, #0x570]
101541a18:     	stur	q0, [x19, #0x24]
101541a1c:     	ldur	q0, [x27, #0x2c]
101541a20:     	str	q0, [x19, #0x30]
101541a24:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541a28:     	ldr	x9, [sp, #0x58]
101541a2c:     	ldr	x9, [x9, #0x3d8]
101541a30:     	cbz	x9, 0x101541c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18a8>
101541a34:     	ldr	x9, [sp, #0x58]
101541a38:     	ldr	x10, [x9, #0x3d0]
101541a3c:     	cmp	x10, x8
101541a40:     	csel	x8, xzr, x8, lo
101541a44:     	sub	x8, x10, x8
101541a48:     	ldr	x9, [x9, #0x3c8]
101541a4c:     	mov	w10, #0x58              ; =88
101541a50:     	madd	x20, x8, x10, x9
101541a54:     	ldr	x8, [x20, #0x40]
101541a58:     	cmp	x8, x19
101541a5c:     	b.ne	0x101541ba8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17d4>
101541a60:     	ldr	x8, [x20, #0x48]
101541a64:     	cbnz	x8, 0x101541ba8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17d4>
101541a68:     	ldr	x8, [x20, #0x50]
101541a6c:     	cmp	x8, x28
101541a70:     	b.ne	0x101541ba8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17d4>
101541a74:     	ldr	w1, [x22, #0x50]
101541a78:     	add	x8, sp, #0x550
101541a7c:     	add	x0, x24, #0xf0
101541a80:     	add	x2, x24, #0x2f8
101541a84:     	bl	0x10163723c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101541a88:     	ldur	q0, [x27, #0x8]
101541a8c:     	ldur	q1, [x27, #0x18]
101541a90:     	stp	q0, q1, [sp, #0x3a0]
101541a94:     	ldur	q0, [x27, #0x28]
101541a98:     	str	q0, [sp, #0x3c0]
101541a9c:     	ldr	x8, [sp, #0x550]
101541aa0:     	ldr	x9, [sp, #0x588]
101541aa4:     	str	x9, [sp, #0x3d0]
101541aa8:     	cbz	x8, 0x101542270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e9c>
101541aac:     	ldp	q0, q1, [sp, #0x3a0]
101541ab0:     	add	x9, sp, #0x440
101541ab4:     	stur	q0, [x9, #0x8]
101541ab8:     	ldr	x10, [sp, #0x3d0]
101541abc:     	ldr	q0, [sp, #0x3c0]
101541ac0:     	stur	q0, [x9, #0x28]
101541ac4:     	stur	q1, [x9, #0x18]
101541ac8:     	str	x10, [sp, #0x478]
101541acc:     	str	x8, [sp, #0x440]
101541ad0:     	ldr	x8, [sp, #0x448]
101541ad4:     	ldr	x9, [x20, #0x8]
101541ad8:     	ldr	x8, [x8, #0x10]
101541adc:     	ldr	x9, [x9, #0x10]
101541ae0:     	cmp	x8, x9
101541ae4:     	b.eq	0x1015423c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fec>
101541ae8:     	mov	w8, #0x0                ; =0
101541aec:     	mov	w9, #0xc                ; =12
101541af0:     	strb	w9, [x23, #0x8]
101541af4:     	mov	w9, #0x27               ; =39
101541af8:     	str	x9, [x23, #0x18]
101541afc:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541b00:     	add	x9, x9, #0xb45
101541b04:     	b	0x1015423d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ffc>
101541b08:     	ldr	w9, [sp, #0x554]
101541b0c:     	ldur	q0, [x27, #0x18]
101541b10:     	stur	q0, [x28, #0x18]
101541b14:     	ldur	q0, [x27, #0x28]
101541b18:     	stur	q0, [x28, #0x28]
101541b1c:     	ldur	q0, [x27, #0x38]
101541b20:     	stur	q0, [x28, #0x38]
101541b24:     	ldr	x10, [sp, #0x598]
101541b28:     	str	x10, [x28, #0x48]
101541b2c:     	ldur	q0, [x27, #0x8]
101541b30:     	stp	w8, w9, [x28]
101541b34:     	stur	q0, [x28, #0x8]
101541b38:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541b3c:     	mov	x9, x20
101541b40:     	ldr	x8, [x20, #0xc0]
101541b44:     	cmp	x8, #0x2
101541b48:     	mov	x8, x23
101541b4c:     	b.ne	0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101541b50:     	ldr	x9, [x9, #0x220]
101541b54:     	cmp	x9, #0x2
101541b58:     	b.ne	0x101541be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101541b5c:     	ldr	x8, [x24, #0x360]
101541b60:     	ldr	w1, [x21, #0x4c]
101541b64:     	cmp	x8, x1
101541b68:     	b.ls	0x101543a10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x363c>
101541b6c:     	ldr	x8, [x24, #0x358]
101541b70:     	mov	w9, #0x140              ; =320
101541b74:     	umaddl	x8, w1, w9, x8
101541b78:     	ldrb	w9, [x8, #0x124]
101541b7c:     	ldr	x8, [x25]
101541b80:     	cmp	w9, #0x7
101541b84:     	b.ne	0x101541d90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19bc>
101541b88:     	cbz	x8, 0x101541fa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bcc>
101541b8c:     	str	wzr, [x23]
101541b90:     	mov	w8, #0xc                ; =12
101541b94:     	strb	w8, [x23, #0x8]
101541b98:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541b9c:     	add	x8, x8, #0xe60
101541ba0:     	mov	w9, #0x28               ; =40
101541ba4:     	b	0x10154170c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
101541ba8:     	str	wzr, [x23]
101541bac:     	mov	w8, #0xc                ; =12
101541bb0:     	strb	w8, [x23, #0x8]
101541bb4:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541bb8:     	add	x8, x8, #0xb6c
101541bbc:     	mov	w9, #0x36               ; =54
101541bc0:     	b	0x10154170c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
101541bc4:     	str	wzr, [x23]
101541bc8:     	mov	w8, #0xc                ; =12
101541bcc:     	strb	w8, [x23, #0x8]
101541bd0:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101541bd4:     	add	x8, x8, #0x67e
101541bd8:     	mov	w9, #0x29               ; =41
101541bdc:     	b	0x10154170c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
101541be0:     	mov	x8, x23
101541be4:     	str	wzr, [x8]
101541be8:     	mov	w9, #0xc                ; =12
101541bec:     	strb	w9, [x8, #0x8]
101541bf0:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541bf4:     	add	x9, x9, #0xe88
101541bf8:     	mov	w10, #0x28              ; =40
101541bfc:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541c00:     	mov	x0, x19
101541c04:     	ldr	x1, [sp, #0x58]
101541c08:     	mov	x2, x20
101541c0c:     	mov	x3, x24
101541c10:     	add	sp, sp, #0x810
101541c14:     	ldp	x29, x30, [sp, #0x50]
101541c18:     	ldp	x20, x19, [sp, #0x40]
101541c1c:     	ldp	x22, x21, [sp, #0x30]
101541c20:     	ldp	x24, x23, [sp, #0x20]
101541c24:     	ldp	x26, x25, [sp, #0x10]
101541c28:     	ldp	x28, x27, [sp], #0x60
101541c2c:     	b	0x101535634 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23borrowed_string_failure>
101541c30:     	ldr	x0, [sp, #0x58]
101541c34:     	mov	x1, x20
101541c38:     	bl	0x101535574 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
101541c3c:     	cbz	x0, 0x101541dec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a18>
101541c40:     	str	wzr, [x19]
101541c44:     	mov	w8, #0xc                ; =12
101541c48:     	strb	w8, [x19, #0x8]
101541c4c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101541c50:     	add	x8, x8, #0x93b
101541c54:     	mov	w9, #0x2e               ; =46
101541c58:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101541c5c:     	str	wzr, [x28]
101541c60:     	mov	w8, #0xc                ; =12
101541c64:     	strb	w8, [x28, #0x8]
101541c68:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101541c6c:     	add	x8, x8, #0x252
101541c70:     	mov	w9, #0x23               ; =35
101541c74:     	stp	x8, x9, [x28, #0x10]
101541c78:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541c7c:     	str	wzr, [x23]
101541c80:     	mov	w8, #0xc                ; =12
101541c84:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101541c88:     	add	x9, x9, #0xf6
101541c8c:     	stp	x8, x9, [x23, #0x8]
101541c90:     	mov	w8, #0x14               ; =20
101541c94:     	str	x8, [x23, #0x18]
101541c98:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541c9c:     	ldr	x8, [sp, #0x58]
101541ca0:     	ldr	x8, [x8, #0x490]
101541ca4:     	add	x0, sp, #0x550
101541ca8:     	add	x1, x8, #0x2f8
101541cac:     	mov	w2, #0x0                ; =0
101541cb0:     	mov	w4, #0x40               ; =64
101541cb4:     	bl	0x1015293e0 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101541cb8:     	ldrb	w8, [sp, #0x550]
101541cbc:     	cmp	w8, #0xe
101541cc0:     	b.ne	0x101541f28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b54>
101541cc4:     	ldr	x0, [x23, x22]
101541cc8:     	ldr	x8, [x21, #0x40]
101541ccc:     	str	x8, [sp, #0x28]
101541cd0:     	cmp	x0, x8
101541cd4:     	b.hs	0x101543ab4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36e0>
101541cd8:     	ldr	x10, [x21, #0x38]
101541cdc:     	ldr	w3, [x21, #0xe0]
101541ce0:     	ldr	x8, [sp, #0x58]
101541ce4:     	ldr	x8, [x8, #0x490]
101541ce8:     	mov	w9, #0x18               ; =24
101541cec:     	mul	x9, x0, x9
101541cf0:     	str	x10, [sp, #0x20]
101541cf4:     	ldr	x4, [x10, x9]
101541cf8:     	ldr	x1, [x8, #0x3c0]
101541cfc:     	add	x0, sp, #0x550
101541d00:     	add	x2, x19, #0x488
101541d04:     	bl	0x10152a804 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames18take_managed_owner>
101541d08:     	ldr	w8, [sp, #0x550]
101541d0c:     	cmp	w8, #0x6
101541d10:     	b.ne	0x101542038 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c64>
101541d14:     	ldur	q0, [x27, #0x28]
101541d18:     	stur	q0, [x24, #0x24]
101541d1c:     	ldur	q1, [x27, #0x38]
101541d20:     	ldur	q2, [x27, #0x18]
101541d24:     	ldur	q3, [x27, #0x8]
101541d28:     	stp	q3, q2, [sp, #0x60]
101541d2c:     	stp	q0, q1, [sp, #0x80]
101541d30:     	add	x24, sp, #0x550
101541d34:     	add	x8, sp, #0x550
101541d38:     	ldr	x0, [sp, #0x58]
101541d3c:     	mov	w1, #0x0                ; =0
101541d40:     	bl	0x10154b014 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101541d44:     	ldr	x8, [sp, #0x550]
101541d48:     	cmp	x8, #0x1
101541d4c:     	b.ne	0x101542198 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dc4>
101541d50:     	ldur	q0, [x24, #0x18]
101541d54:     	ldur	q1, [x24, #0x28]
101541d58:     	ldur	q2, [x24, #0x38]
101541d5c:     	str	q1, [sp, #0x460]
101541d60:     	str	q2, [sp, #0x470]
101541d64:     	ldur	q3, [x24, #0x48]
101541d68:     	str	q3, [sp, #0x480]
101541d6c:     	ldur	q4, [x24, #0x8]
101541d70:     	str	q0, [sp, #0x450]
101541d74:     	str	q4, [sp, #0x440]
101541d78:     	stp	q1, q2, [x28, #0x20]
101541d7c:     	str	q3, [x28, #0x40]
101541d80:     	stp	q4, q0, [x28]
101541d84:     	add	x0, sp, #0x60
101541d88:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101541d8c:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541d90:     	mov	x9, #0x0                ; =0
101541d94:     	ldr	x10, [x22, #0x330]
101541d98:     	ldr	x11, [x22, #0x3c8]
101541d9c:     	ldr	x12, [x22, #0x430]
101541da0:     	ldp	q0, q1, [x22, #0x3d0]
101541da4:     	ldp	q2, q3, [x22, #0x3f0]
101541da8:     	ldr	q4, [x22, #0x410]
101541dac:     	ldr	q5, [x22, #0x420]
101541db0:     	mov	w13, #0x1               ; =1
101541db4:     	stp	x13, x9, [x20, #0xf8]
101541db8:     	str	x8, [x20, #0x108]
101541dbc:     	ldp	q6, q7, [sp, #0x60]
101541dc0:     	stp	q6, q7, [x20, #0x110]
101541dc4:     	ldr	q6, [sp, #0x80]
101541dc8:     	str	q6, [x20, #0x130]
101541dcc:     	stp	x10, x11, [x20, #0x140]
101541dd0:     	stp	q0, q1, [x20, #0x150]
101541dd4:     	stp	q2, q3, [x20, #0x170]
101541dd8:     	stp	q4, q5, [x20, #0x190]
101541ddc:     	str	x12, [x20, #0x1b0]
101541de0:     	str	w19, [x20, #0x1b8]
101541de4:     	dup.2d	v0, x13
101541de8:     	b	0x101541844 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1470>
101541dec:     	ldr	x8, [x23, #0x558]
101541df0:     	cmp	x20, x8
101541df4:     	b.hs	0x101541e10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a3c>
101541df8:     	ldr	x8, [x23, #0x550]
101541dfc:     	mov	w9, #0x28               ; =40
101541e00:     	mul	x9, x20, x9
101541e04:     	ldr	w8, [x8, x9]
101541e08:     	cmp	w8, #0x5
101541e0c:     	b.ne	0x1015420a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ccc>
101541e10:     	cmp	x22, #0x6
101541e14:     	b.gt	0x101541fec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c18>
101541e18:     	cmp	x22, #0x4
101541e1c:     	b.eq	0x1015422a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ed0>
101541e20:     	cmp	x22, #0x5
101541e24:     	b.eq	0x10154232c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f58>
101541e28:     	cmp	x22, #0x6
101541e2c:     	b.ne	0x101542304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f30>
101541e30:     	ldr	q0, [x24]
101541e34:     	str	q0, [sp, #0x550]
101541e38:     	ldr	x8, [x24, #0x10]
101541e3c:     	str	x8, [sp, #0x560]
101541e40:     	add	x3, sp, #0x550
101541e44:     	mov	x0, x19
101541e48:     	ldr	x1, [sp, #0x58]
101541e4c:     	mov	x2, x20
101541e50:     	bl	0x101539868 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation25prepare_string_map_region>
101541e54:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541e58:     	mov	w11, #0x0               ; =0
101541e5c:     	mov	w10, #0x0               ; =0
101541e60:     	mov	w13, #0x6               ; =6
101541e64:     	mov	x8, #-0x1               ; =-1
101541e68:     	mov	x12, x23
101541e6c:     	b	0x101541008 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101541e70:     	cbnz	x28, 0x101541e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab8>
101541e74:     	ldp	x1, x2, [x23, #0x8]
101541e78:     	ldr	x0, [sp, #0x50]
101541e7c:     	bl	0x1015577a4 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
101541e80:     	tbz	w0, #0x0, 0x101541e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab8>
101541e84:     	mov	x8, #0x0                ; =0
101541e88:     	b	0x101541ee8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b14>
101541e8c:     	ldr	x8, [sp, #0x48]
101541e90:     	str	wzr, [x8]
101541e94:     	mov	w9, #0xc                ; =12
101541e98:     	strb	w9, [x8, #0x8]
101541e9c:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101541ea0:     	add	x9, x9, #0x51e
101541ea4:     	mov	w10, #0x38              ; =56
101541ea8:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541eac:     	ldr	x9, [x23, #0xa0]
101541eb0:     	cbz	x9, 0x101541f80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bac>
101541eb4:     	ldr	x8, [x23, #0x98]
101541eb8:     	lsl	x9, x9, #5
101541ebc:     	b	0x101541ecc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1af8>
101541ec0:     	add	x8, x8, #0x20
101541ec4:     	subs	x9, x9, #0x20
101541ec8:     	b.eq	0x101541f80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bac>
101541ecc:     	ldr	w11, [x8, #0x18]
101541ed0:     	ldr	x10, [sp, #0x50]
101541ed4:     	cmp	x10, x11
101541ed8:     	b.ne	0x101541ec0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
101541edc:     	ldr	w10, [x8, #0x1c]
101541ee0:     	cmp	x28, x10
101541ee4:     	b.ne	0x101541ec0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
101541ee8:     	str	x8, [sp, #0x220]
101541eec:     	ldr	x9, [sp, #0x40]
101541ef0:     	ldp	x8, x9, [x9, #0xd0]
101541ef4:     	lsl	x9, x9, #6
101541ef8:     	cbz	x9, 0x1015420bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ce8>
101541efc:     	ldr	x10, [x8], #0x40
101541f00:     	sub	x9, x9, #0x40
101541f04:     	cbz	x10, 0x101541ef8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b24>
101541f08:     	ldr	x8, [sp, #0x48]
101541f0c:     	str	wzr, [x8]
101541f10:     	mov	w9, #0xc                ; =12
101541f14:     	strb	w9, [x8, #0x8]
101541f18:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101541f1c:     	add	x9, x9, #0x4ec
101541f20:     	mov	w10, #0x32              ; =50
101541f24:     	b	0x101540460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541f28:     	ldr	q0, [sp, #0x550]
101541f2c:     	ldr	q1, [sp, #0x560]
101541f30:     	str	q0, [sp, #0x440]
101541f34:     	str	q1, [sp, #0x450]
101541f38:     	ldr	q2, [sp, #0x570]
101541f3c:     	str	q2, [sp, #0x460]
101541f40:     	ldr	x8, [sp, #0x580]
101541f44:     	str	x8, [sp, #0x470]
101541f48:     	stur	q0, [x27, #0x4]
101541f4c:     	stur	q1, [x27, #0x14]
101541f50:     	stur	q2, [x27, #0x24]
101541f54:     	stur	x8, [x27, #0x34]
101541f58:     	str	wzr, [x28]
101541f5c:     	ldr	q0, [sp, #0x550]
101541f60:     	ldr	q1, [sp, #0x560]
101541f64:     	stur	q0, [x28, #0x4]
101541f68:     	stur	q1, [x28, #0x14]
101541f6c:     	ldr	q0, [sp, #0x570]
101541f70:     	stur	q0, [x28, #0x24]
101541f74:     	ldur	q0, [x27, #0x2c]
101541f78:     	str	q0, [x28, #0x30]
101541f7c:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541f80:     	ldr	x8, [sp, #0x48]
101541f84:     	str	wzr, [x8]
101541f88:     	mov	w9, #0xc                ; =12
101541f8c:     	adrp	x10, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
101541f90:     	add	x10, x10, #0x3d9
101541f94:     	stp	x9, x10, [x8, #0x8]
101541f98:     	mov	w9, #0x31               ; =49
101541f9c:     	b	0x1015406a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101541fa0:     	add	x8, sp, #0x550
101541fa4:     	add	x0, x22, #0xf0
101541fa8:     	add	x2, x22, #0x2f8
101541fac:     	bl	0x10163723c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101541fb0:     	ldr	x9, [sp, #0x550]
101541fb4:     	ldr	x8, [sp, #0x558]
101541fb8:     	ldr	q0, [sp, #0x560]
101541fbc:     	ldr	q1, [sp, #0x570]
101541fc0:     	str	q0, [sp, #0x440]
101541fc4:     	str	q1, [sp, #0x450]
101541fc8:     	ldr	q0, [sp, #0x580]
101541fcc:     	str	q0, [sp, #0x460]
101541fd0:     	cbz	x9, 0x101542174 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1da0>
101541fd4:     	ldr	q0, [sp, #0x440]
101541fd8:     	ldr	q1, [sp, #0x450]
101541fdc:     	stp	q0, q1, [sp, #0x60]
101541fe0:     	ldr	q0, [sp, #0x460]
101541fe4:     	str	q0, [sp, #0x80]
101541fe8:     	b	0x101541d94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19c0>
101541fec:     	cmp	x22, #0x7
101541ff0:     	b.eq	0x1015422d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f00>
101541ff4:     	cmp	x22, #0x10
101541ff8:     	b.eq	0x10154235c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f88>
101541ffc:     	cmp	x22, #0x11
101542000:     	b.ne	0x101542304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f30>
101542004:     	ldp	x4, x5, [x24, #0x8]
101542008:     	ldr	x3, [x24]
10154200c:     	mov	x0, x19
101542010:     	ldr	x1, [sp, #0x58]
101542014:     	mov	x2, x20
101542018:     	add	sp, sp, #0x810
10154201c:     	ldp	x29, x30, [sp, #0x50]
101542020:     	ldp	x20, x19, [sp, #0x40]
101542024:     	ldp	x22, x21, [sp, #0x30]
101542028:     	ldp	x24, x23, [sp, #0x20]
10154202c:     	ldp	x26, x25, [sp, #0x10]
101542030:     	ldp	x28, x27, [sp], #0x60
101542034:     	b	0x10154dd88 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation21finish_join_map_chunk>
101542038:     	ldur	q0, [x27, #0x14]
10154203c:     	ldur	q1, [x27, #0x24]
101542040:     	ldur	q2, [x27, #0x34]
101542044:     	str	q1, [sp, #0x460]
101542048:     	str	q2, [sp, #0x470]
10154204c:     	ldr	w9, [sp, #0x594]
101542050:     	str	w9, [sp, #0x480]
101542054:     	ldur	q3, [x27, #0x4]
101542058:     	str	q0, [sp, #0x450]
10154205c:     	str	q3, [sp, #0x440]
101542060:     	ldr	x10, [sp, #0x598]
101542064:     	stur	q0, [x28, #0x14]
101542068:     	stur	q1, [x28, #0x24]
10154206c:     	stur	q2, [x28, #0x34]
101542070:     	str	w9, [x28, #0x44]
101542074:     	stur	q3, [x28, #0x4]
101542078:     	str	w8, [x28]
10154207c:     	str	x10, [x28, #0x48]
101542080:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542084:     	str	wzr, [x23]
101542088:     	mov	w8, #0xc                ; =12
10154208c:     	strb	w8, [x23, #0x8]
101542090:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101542094:     	add	x8, x8, #0xba2
101542098:     	mov	w9, #0x24               ; =36
10154209c:     	b	0x10154170c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
1015420a0:     	str	wzr, [x19]
1015420a4:     	mov	w8, #0xc                ; =12
1015420a8:     	strb	w8, [x19, #0x8]
1015420ac:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
1015420b0:     	add	x8, x8, #0xa54
1015420b4:     	mov	w9, #0x24               ; =36
1015420b8:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
1015420bc:     	add	x8, sp, #0x220
1015420c0:     	str	x8, [sp, #0x440]
1015420c4:     	str	x24, [sp, #0x448]
1015420c8:     	ldr	x19, [sp, #0x58]
1015420cc:     	str	x19, [sp, #0x450]
1015420d0:     	ldr	x8, [sp, #0x38]
1015420d4:     	str	x8, [sp, #0x458]
1015420d8:     	str	x21, [sp, #0x460]
1015420dc:     	add	x0, sp, #0x550
1015420e0:     	add	x1, sp, #0x440
1015420e4:     	bl	0x1015286f8 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB6_10Invocation19end_numeric_segments4_0Be_>
1015420e8:     	ldr	x8, [x19, #0x490]
1015420ec:     	ldr	x2, [x8, #0xd8]
1015420f0:     	ldr	x1, [x23, #0x40]
1015420f4:     	cmp	x1, x2
1015420f8:     	b.hi	0x101543628 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3254>
1015420fc:     	ldr	x0, [x8, #0xd0]
101542100:     	str	xzr, [sp, #0x440]
101542104:     	add	x2, sp, #0x440
101542108:     	bl	0x101613448 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
10154210c:     	ldr	w8, [sp, #0x550]
101542110:     	cmp	w8, #0x6
101542114:     	b.ne	0x10154238c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fb8>
101542118:     	ldr	x9, [sp, #0x58]
10154211c:     	ldr	x8, [x9, #0x490]
101542120:     	str	wzr, [x8, #0x340]
101542124:     	ldr	x10, [x9, #0x490]
101542128:     	mov	w8, #0x1                ; =1
10154212c:     	str	w8, [x10, #0x2f0]
101542130:     	ldr	x8, [sp, #0x50]
101542134:     	str	w8, [x10, #0x2f4]
101542138:     	ldr	x8, [x9, #0x490]
10154213c:     	cmp	x20, #0x2
101542140:     	cset	w9, ne
101542144:     	strb	w9, [x8, #0x460]
101542148:     	ldr	x8, [sp, #0x48]
10154214c:     	str	xzr, [x8, #0x8]
101542150:     	mov	w9, #0x6                ; =6
101542154:     	str	w9, [x8]
101542158:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154215c:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101542160:     	add	x0, x0, #0x910
101542164:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101542168:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154216c:     	add	x0, x0, #0x928
101542170:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101542174:     	ldr	q0, [sp, #0x440]
101542178:     	ldr	q1, [sp, #0x450]
10154217c:     	stp	q0, q1, [x23, #0x10]
101542180:     	ldr	q0, [sp, #0x460]
101542184:     	str	q0, [x23, #0x30]
101542188:     	mov	w9, #0x2                ; =2
10154218c:     	str	w9, [x23]
101542190:     	str	x8, [x23, #0x8]
101542194:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542198:     	ldur	q0, [x24, #0x48]
10154219c:     	ldur	q1, [x24, #0x58]
1015421a0:     	str	q0, [sp, #0x480]
1015421a4:     	str	q1, [sp, #0x490]
1015421a8:     	ldur	x8, [x24, #0x68]
1015421ac:     	str	x8, [sp, #0x4a0]
1015421b0:     	ldur	q2, [x24, #0x8]
1015421b4:     	ldur	q3, [x24, #0x18]
1015421b8:     	str	q2, [sp, #0x440]
1015421bc:     	str	q3, [sp, #0x450]
1015421c0:     	ldur	q4, [x24, #0x38]
1015421c4:     	ldur	q5, [x24, #0x28]
1015421c8:     	stp	q2, q3, [sp, #0xa0]
1015421cc:     	stp	q5, q4, [sp, #0xc0]
1015421d0:     	str	x8, [sp, #0x100]
1015421d4:     	stp	q0, q1, [sp, #0xe0]
1015421d8:     	ldr	w8, [x23]
1015421dc:     	cmp	w8, #0x6
1015421e0:     	b.ne	0x1015423e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2010>
1015421e4:     	ldp	q0, q1, [sp, #0x60]
1015421e8:     	str	q0, [sp, #0x440]
1015421ec:     	str	q1, [sp, #0x450]
1015421f0:     	ldp	q0, q1, [sp, #0x80]
1015421f4:     	str	q0, [sp, #0x460]
1015421f8:     	str	q1, [sp, #0x470]
1015421fc:     	ldr	x8, [sp, #0x58]
101542200:     	ldp	q0, q1, [x8, #0x80]
101542204:     	str	q0, [sp, #0x5d0]
101542208:     	str	q1, [sp, #0x5e0]
10154220c:     	ldr	x9, [x8, #0xa0]
101542210:     	str	x9, [sp, #0x5f0]
101542214:     	ldp	q0, q1, [x8, #0x40]
101542218:     	str	q0, [sp, #0x590]
10154221c:     	str	q1, [sp, #0x5a0]
101542220:     	ldp	q1, q0, [x8, #0x60]
101542224:     	str	q0, [sp, #0x5c0]
101542228:     	str	q1, [sp, #0x5b0]
10154222c:     	ldp	q0, q1, [x8]
101542230:     	str	q0, [sp, #0x550]
101542234:     	str	q1, [sp, #0x560]
101542238:     	ldp	q1, q0, [x8, #0x20]
10154223c:     	str	q0, [sp, #0x580]
101542240:     	str	q1, [sp, #0x570]
101542244:     	ldr	x9, [x8, #0x490]
101542248:     	add	x8, sp, #0x110
10154224c:     	add	x1, sp, #0x440
101542250:     	add	x4, sp, #0x550
101542254:     	add	x5, x9, #0x3b8
101542258:     	add	x6, sp, #0xa0
10154225c:     	ldr	x0, [sp, #0x30]
101542260:     	ldr	x2, [sp, #0x40]
101542264:     	mov	w3, #0x1                ; =1
101542268:     	bl	0x102532444 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private>
10154226c:     	b	0x10154246c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2098>
101542270:     	ldp	q0, q1, [sp, #0x3a0]
101542274:     	stur	q0, [x27, #0x4]
101542278:     	stur	q1, [x27, #0x14]
10154227c:     	ldr	q0, [sp, #0x3c0]
101542280:     	stur	q0, [x27, #0x24]
101542284:     	ldr	x8, [sp, #0x3d0]
101542288:     	stur	x8, [x27, #0x34]
10154228c:     	ldr	q0, [sp, #0x550]
101542290:     	ldr	q1, [sp, #0x560]
101542294:     	stur	q0, [x23, #0x4]
101542298:     	mov	w8, #0x2                ; =2
10154229c:     	str	w8, [x23]
1015422a0:     	b	0x1015418c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14f4>
1015422a4:     	mov	x0, x19
1015422a8:     	ldr	x1, [sp, #0x58]
1015422ac:     	mov	x2, x20
1015422b0:     	mov	x3, x24
1015422b4:     	add	sp, sp, #0x810
1015422b8:     	ldp	x29, x30, [sp, #0x50]
1015422bc:     	ldp	x20, x19, [sp, #0x40]
1015422c0:     	ldp	x22, x21, [sp, #0x30]
1015422c4:     	ldp	x24, x23, [sp, #0x20]
1015422c8:     	ldp	x26, x25, [sp, #0x10]
1015422cc:     	ldp	x28, x27, [sp], #0x60
1015422d0:     	b	0x101534d5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation21prepare_window_region>
1015422d4:     	mov	x0, x19
1015422d8:     	ldr	x1, [sp, #0x58]
1015422dc:     	mov	x2, x20
1015422e0:     	mov	x3, x24
1015422e4:     	add	sp, sp, #0x810
1015422e8:     	ldp	x29, x30, [sp, #0x50]
1015422ec:     	ldp	x20, x19, [sp, #0x40]
1015422f0:     	ldp	x22, x21, [sp, #0x30]
1015422f4:     	ldp	x24, x23, [sp, #0x20]
1015422f8:     	ldp	x26, x25, [sp, #0x10]
1015422fc:     	ldp	x28, x27, [sp], #0x60
101542300:     	b	0x1015394c0 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation24finish_string_map_region>
101542304:     	ldr	x8, [sp, #0x58]
101542308:     	ldr	x8, [x8, #0xa8]
10154230c:     	cbz	x8, 0x101542b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2784>
101542310:     	str	wzr, [x19]
101542314:     	mov	w8, #0xc                ; =12
101542318:     	strb	w8, [x19, #0x8]
10154231c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101542320:     	add	x8, x8, #0x969
101542324:     	mov	w9, #0x2d               ; =45
101542328:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
10154232c:     	mov	x0, x19
101542330:     	ldr	x1, [sp, #0x58]
101542334:     	mov	x2, x20
101542338:     	mov	x3, x24
10154233c:     	add	sp, sp, #0x810
101542340:     	ldp	x29, x30, [sp, #0x50]
101542344:     	ldp	x20, x19, [sp, #0x40]
101542348:     	ldp	x22, x21, [sp, #0x30]
10154234c:     	ldp	x24, x23, [sp, #0x20]
101542350:     	ldp	x26, x25, [sp, #0x10]
101542354:     	ldp	x28, x27, [sp], #0x60
101542358:     	b	0x101534760 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation20finish_window_region>
10154235c:     	mov	x0, x19
101542360:     	ldr	x1, [sp, #0x58]
101542364:     	mov	x2, x20
101542368:     	mov	x3, x24
10154236c:     	add	sp, sp, #0x810
101542370:     	ldp	x29, x30, [sp, #0x50]
101542374:     	ldp	x20, x19, [sp, #0x40]
101542378:     	ldp	x22, x21, [sp, #0x30]
10154237c:     	ldp	x24, x23, [sp, #0x20]
101542380:     	ldp	x26, x25, [sp, #0x10]
101542384:     	ldp	x28, x27, [sp], #0x60
101542388:     	b	0x10154e0e8 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation22prepare_join_map_chunk>
10154238c:     	ldur	q0, [x27, #0x14]
101542390:     	ldr	x9, [sp, #0x48]
101542394:     	stur	q0, [x9, #0x14]
101542398:     	ldur	q0, [x27, #0x24]
10154239c:     	stur	q0, [x9, #0x24]
1015423a0:     	ldur	q0, [x27, #0x34]
1015423a4:     	stur	q0, [x9, #0x34]
1015423a8:     	ldr	q0, [sp, #0x590]
1015423ac:     	str	q0, [x9, #0x40]
1015423b0:     	ldur	q0, [x27, #0x4]
1015423b4:     	stur	q0, [x9, #0x4]
1015423b8:     	str	w8, [x9]
1015423bc:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015423c0:     	mov	w8, #0x1                ; =1
1015423c4:     	str	x8, [x23, #0x8]
1015423c8:     	mov	w8, #0x6                ; =6
1015423cc:     	mov	w9, #0x2                ; =2
1015423d0:     	str	x9, [x23, #0x10]
1015423d4:     	str	w8, [x23]
1015423d8:     	add	x0, sp, #0x440
1015423dc:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015423e0:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015423e4:     	ldp	q0, q1, [sp, #0x60]
1015423e8:     	str	q0, [sp, #0x440]
1015423ec:     	str	q1, [sp, #0x450]
1015423f0:     	ldp	q0, q1, [sp, #0x80]
1015423f4:     	str	q0, [sp, #0x460]
1015423f8:     	str	q1, [sp, #0x470]
1015423fc:     	ldr	x8, [sp, #0x58]
101542400:     	ldp	q0, q1, [x8, #0x80]
101542404:     	str	q0, [sp, #0x5d0]
101542408:     	str	q1, [sp, #0x5e0]
10154240c:     	ldr	x9, [x8, #0xa0]
101542410:     	str	x9, [sp, #0x5f0]
101542414:     	ldp	q0, q1, [x8, #0x40]
101542418:     	str	q0, [sp, #0x590]
10154241c:     	str	q1, [sp, #0x5a0]
101542420:     	ldp	q1, q0, [x8, #0x60]
101542424:     	str	q0, [sp, #0x5c0]
101542428:     	str	q1, [sp, #0x5b0]
10154242c:     	ldp	q0, q1, [x8]
101542430:     	str	q0, [sp, #0x550]
101542434:     	str	q1, [sp, #0x560]
101542438:     	ldp	q1, q0, [x8, #0x20]
10154243c:     	str	q0, [sp, #0x580]
101542440:     	str	q1, [sp, #0x570]
101542444:     	ldr	x9, [x8, #0x490]
101542448:     	add	x8, sp, #0x110
10154244c:     	add	x1, sp, #0x440
101542450:     	add	x5, sp, #0x550
101542454:     	add	x6, x9, #0x3b8
101542458:     	add	x7, sp, #0xa0
10154245c:     	ldp	x0, x2, [sp, #0x30]
101542460:     	ldr	x3, [sp, #0x40]
101542464:     	mov	w4, #0x1                ; =1
101542468:     	bl	0x102531e5c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private>
10154246c:     	ldr	x9, [sp, #0x110]
101542470:     	add	x8, sp, #0x110
101542474:     	cbz	x9, 0x101542a94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26c0>
101542478:     	add	x10, sp, #0x110
10154247c:     	ldur	q0, [x10, #0xc8]
101542480:     	stur	q0, [x25, #0xc8]
101542484:     	ldur	q0, [x10, #0xd8]
101542488:     	stur	q0, [x25, #0xd8]
10154248c:     	ldur	q0, [x10, #0xe8]
101542490:     	stur	q0, [x25, #0xe8]
101542494:     	ldur	q0, [x10, #0xf8]
101542498:     	stur	q0, [x25, #0xf8]
10154249c:     	ldur	q0, [x10, #0x88]
1015424a0:     	stur	q0, [x25, #0x88]
1015424a4:     	ldur	q0, [x10, #0x98]
1015424a8:     	stur	q0, [x25, #0x98]
1015424ac:     	ldur	q0, [x10, #0xa8]
1015424b0:     	stur	q0, [x25, #0xa8]
1015424b4:     	ldur	q0, [x10, #0xb8]
1015424b8:     	stur	q0, [x25, #0xb8]
1015424bc:     	ldur	q0, [x10, #0x58]
1015424c0:     	stur	q0, [x25, #0x58]
1015424c4:     	ldur	q0, [x10, #0x68]
1015424c8:     	stur	q0, [x25, #0x68]
1015424cc:     	ldur	q0, [x10, #0x78]
1015424d0:     	stur	q0, [x25, #0x78]
1015424d4:     	ldur	q0, [x8, #0x18]
1015424d8:     	stur	q0, [x25, #0x18]
1015424dc:     	ldur	q0, [x8, #0x28]
1015424e0:     	stur	q0, [x25, #0x28]
1015424e4:     	ldur	q0, [x8, #0x38]
1015424e8:     	stur	q0, [x25, #0x38]
1015424ec:     	ldur	q0, [x8, #0x48]
1015424f0:     	stur	q0, [x25, #0x48]
1015424f4:     	ldur	q0, [x8, #0x8]
1015424f8:     	stur	q0, [x25, #0x8]
1015424fc:     	str	x9, [sp, #0x220]
101542500:     	ldr	x8, [sp, #0x58]
101542504:     	ldr	x9, [x8, #0x490]
101542508:     	add	x8, sp, #0x720
10154250c:     	add	x0, x9, #0x3b8
101542510:     	bl	0x10236caa0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
101542514:     	ldr	x8, [x19, #0x5e8]
101542518:     	cmn	x8, #0x1, lsl #12       ; =0x1000
10154251c:     	b.hs	0x1015438c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34f0>
101542520:     	add	x24, x8, #0x1, lsl #12  ; =0x1000
101542524:     	lsr	x8, x24, #60
101542528:     	cbnz	x8, 0x1015438e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3510>
10154252c:     	ldr	x8, [sp, #0x58]
101542530:     	ldr	x8, [x8, #0x490]
101542534:     	lsl	x4, x24, #4
101542538:     	mov	w19, #0x1               ; =1
10154253c:     	add	x0, sp, #0x550
101542540:     	add	x1, x8, #0x2f8
101542544:     	mov	w2, #0x0                ; =0
101542548:     	bl	0x1015293e0 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10154254c:     	ldrb	w8, [sp, #0x550]
101542550:     	cmp	w8, #0xe
101542554:     	b.ne	0x101542ad0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26fc>
101542558:     	add	x8, sp, #0x550
10154255c:     	add	x0, sp, #0x720
101542560:     	mov	x1, x24
101542564:     	bl	0x102d50dfc <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101542568:     	ldr	w8, [sp, #0x550]
10154256c:     	cmp	w8, #0x1a
101542570:     	b.ne	0x101542bb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27e4>
101542574:     	ldur	q0, [x27, #0x18]
101542578:     	ldur	q1, [x27, #0x8]
10154257c:     	stp	q1, q0, [x29, #-0x90]
101542580:     	ldr	x1, [x23, x22]
101542584:     	ldr	x8, [sp, #0x28]
101542588:     	cmp	x1, x8
10154258c:     	b.hs	0x1015440c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cf0>
101542590:     	mov	w8, #0x18               ; =24
101542594:     	ldr	x9, [sp, #0x20]
101542598:     	madd	x8, x1, x8, x9
10154259c:     	ldrb	w8, [x8, #0x12]
1015425a0:     	tbz	w8, #0x0, 0x101542758 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2384>
1015425a4:     	ldr	x8, [sp, #0x58]
1015425a8:     	ldr	x8, [x8, #0x490]
1015425ac:     	ldr	x8, [x8, #0x3c0]
1015425b0:     	cbz	x8, 0x101542c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28a8>
1015425b4:     	ldr	x9, [x8, #0x40]
1015425b8:     	cmp	x9, #0x2
1015425bc:     	b.eq	0x101542c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28a8>
1015425c0:     	ldr	x10, [x8, #0xd8]
1015425c4:     	ldr	x9, [sp, #0x48]
1015425c8:     	cmp	x10, x9
1015425cc:     	b.ne	0x101542c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28a8>
1015425d0:     	ldr	x9, [x8, #0x80]
1015425d4:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1015425d8:     	cmp	x9, x10
1015425dc:     	b.eq	0x101542c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28a8>
1015425e0:     	ldr	x9, [x8, #0x90]
1015425e4:     	cmp	x1, x9
1015425e8:     	b.hs	0x101542c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28a8>
1015425ec:     	ldr	x8, [x8, #0x88]
1015425f0:     	mov	w9, #0x70               ; =112
1015425f4:     	madd	x8, x1, x9, x8
1015425f8:     	ldr	x11, [x8]
1015425fc:     	ldr	d0, [x8, #0x8]
101542600:     	ldrb	w12, [x8, #0x10]
101542604:     	ldp	x9, x10, [x8, #0x18]
101542608:     	str	xzr, [x8]
10154260c:     	cbz	x11, 0x10154363c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3268>
101542610:     	ldur	q1, [x8, #0x58]
101542614:     	stur	q1, [x26, #0x58]
101542618:     	ldr	x13, [x8, #0x68]
10154261c:     	str	x13, [sp, #0x398]
101542620:     	str	x11, [sp, #0x330]
101542624:     	str	d0, [sp, #0x338]
101542628:     	strb	w12, [sp, #0x340]
10154262c:     	ldur	w11, [x8, #0x11]
101542630:     	stur	w11, [x26, #0x11]
101542634:     	ldr	w11, [x8, #0x14]
101542638:     	str	w11, [sp, #0x344]
10154263c:     	str	x9, [sp, #0x348]
101542640:     	str	x10, [sp, #0x350]
101542644:     	ldur	q0, [x8, #0x28]
101542648:     	stur	q0, [x26, #0x28]
10154264c:     	ldur	q0, [x8, #0x38]
101542650:     	stur	q0, [x26, #0x38]
101542654:     	ldur	q0, [x8, #0x48]
101542658:     	stur	q0, [x26, #0x48]
10154265c:     	add	x0, sp, #0x550
101542660:     	add	x1, sp, #0x220
101542664:     	mov	w2, #0x108              ; =264
101542668:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
10154266c:     	mov	w19, #0x0               ; =0
101542670:     	add	x24, sp, #0x440
101542674:     	add	x8, sp, #0x440
101542678:     	add	x0, sp, #0x550
10154267c:     	add	x1, sp, #0x330
101542680:     	bl	0x102e0e5f8 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix23with_append_preparation>
101542684:     	ldr	x8, [sp, #0x440]
101542688:     	cbz	x8, 0x101543748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3374>
10154268c:     	add	x9, sp, #0x220
101542690:     	ldr	w10, [sp, #0x448]
101542694:     	add	x11, sp, #0x440
101542698:     	ldur	q0, [x11, #0x1c]
10154269c:     	ldur	q1, [x11, #0x2c]
1015426a0:     	ldur	q2, [x11, #0x3c]
1015426a4:     	str	q1, [sp, #0x410]
1015426a8:     	str	q2, [sp, #0x420]
1015426ac:     	ldur	q1, [x11, #0x48]
1015426b0:     	stur	q1, [x26, #0xfc]
1015426b4:     	ldur	q1, [x11, #0xc]
1015426b8:     	stp	q1, q0, [sp, #0x3f0]
1015426bc:     	ldur	q0, [x11, #0xc8]
1015426c0:     	stur	q0, [x9, #0xc8]
1015426c4:     	ldur	q0, [x11, #0xd8]
1015426c8:     	stur	q0, [x9, #0xd8]
1015426cc:     	ldur	q0, [x11, #0xe8]
1015426d0:     	stur	q0, [x9, #0xe8]
1015426d4:     	ldur	q0, [x11, #0xf8]
1015426d8:     	stur	q0, [x9, #0xf8]
1015426dc:     	ldur	q0, [x11, #0x88]
1015426e0:     	stur	q0, [x9, #0x88]
1015426e4:     	ldur	q0, [x11, #0x98]
1015426e8:     	stur	q0, [x9, #0x98]
1015426ec:     	ldur	q0, [x11, #0xa8]
1015426f0:     	stur	q0, [x9, #0xa8]
1015426f4:     	ldur	q0, [x11, #0xb8]
1015426f8:     	stur	q0, [x9, #0xb8]
1015426fc:     	ldur	q0, [x11, #0x58]
101542700:     	stur	q0, [x9, #0x58]
101542704:     	ldur	q0, [x11, #0x68]
101542708:     	stur	q0, [x9, #0x68]
10154270c:     	ldur	q0, [x11, #0x78]
101542710:     	stur	q0, [x9, #0x78]
101542714:     	ldur	q0, [x26, #0xfc]
101542718:     	stur	q0, [x26, #0xac]
10154271c:     	ldr	q0, [sp, #0x420]
101542720:     	ldr	q1, [sp, #0x410]
101542724:     	stp	q1, q0, [sp, #0x3c0]
101542728:     	ldp	q2, q0, [sp, #0x3f0]
10154272c:     	stp	q2, q0, [sp, #0x3a0]
101542730:     	stur	q0, [x25, #0x1c]
101542734:     	stur	q1, [x25, #0x2c]
101542738:     	stur	q2, [x25, #0xc]
10154273c:     	ldr	q0, [sp, #0x3d0]
101542740:     	stur	q0, [x25, #0x3c]
101542744:     	ldur	q0, [x26, #0xac]
101542748:     	stur	q0, [x25, #0x48]
10154274c:     	str	x8, [sp, #0x220]
101542750:     	str	w10, [sp, #0x228]
101542754:     	ldr	x1, [x23, x22]
101542758:     	mov	w19, #0x1               ; =1
10154275c:     	mov	x0, x20
101542760:     	bl	0x101587058 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare16readonly_numericNtB2_5Proof8capacity>
101542764:     	cmp	x0, #0x1
101542768:     	b.ne	0x101542e10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a3c>
10154276c:     	mov	x20, x1
101542770:     	add	x8, sp, #0x550
101542774:     	add	x0, sp, #0x220
101542778:     	bl	0x102e0e4e0 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix20reserved_native_view>
10154277c:     	ldr	w8, [sp, #0x550]
101542780:     	tbz	w8, #0x0, 0x1015432d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f00>
101542784:     	ldr	x8, [sp, #0x58]
101542788:     	ldr	x10, [x8, #0x4d8]
10154278c:     	cbz	x10, 0x101543564 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3190>
101542790:     	ldr	x8, [x23, x22]
101542794:     	ldr	x9, [x21, #0xb0]
101542798:     	add	x8, x9, x8, lsl #2
10154279c:     	add	x11, x8, #0x3
1015427a0:     	ldr	x8, [sp, #0x58]
1015427a4:     	ldr	x8, [x8, #0x4e0]
1015427a8:     	cmp	x11, x8
1015427ac:     	b.hs	0x101543564 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3190>
1015427b0:     	ldr	x19, [sp, #0x558]
1015427b4:     	ldr	x9, [sp, #0x560]
1015427b8:     	ldr	x8, [sp, #0x568]
1015427bc:     	str	x9, [x10, x11, lsl #3]
1015427c0:     	ldr	x10, [sp, #0x58]
1015427c4:     	ldr	x10, [x10, #0x4d8]
1015427c8:     	cbz	x10, 0x101543498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
1015427cc:     	ldr	x11, [x23, x22]
1015427d0:     	ldr	x12, [x21, #0xb0]
1015427d4:     	add	x11, x12, x11, lsl #2
1015427d8:     	add	x11, x11, #0x4
1015427dc:     	ldr	x12, [sp, #0x58]
1015427e0:     	ldr	x12, [x12, #0x4e0]
1015427e4:     	cmp	x11, x12
1015427e8:     	b.hs	0x101543498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
1015427ec:     	mov	w12, #0x1               ; =1
1015427f0:     	str	x12, [x10, x11, lsl #3]
1015427f4:     	ldr	x10, [sp, #0x58]
1015427f8:     	ldr	x10, [x10, #0x4d8]
1015427fc:     	cbz	x10, 0x101543498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
101542800:     	ldr	x11, [x23, x22]
101542804:     	ldr	x12, [x21, #0xb0]
101542808:     	add	x11, x12, x11, lsl #2
10154280c:     	add	x11, x11, #0x5
101542810:     	ldr	x12, [sp, #0x58]
101542814:     	ldr	x12, [x12, #0x4e0]
101542818:     	cmp	x11, x12
10154281c:     	b.hs	0x101543498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
101542820:     	str	x9, [x10, x11, lsl #3]
101542824:     	ldr	x9, [sp, #0x58]
101542828:     	ldr	x9, [x9, #0x4d8]
10154282c:     	cbz	x9, 0x101543498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
101542830:     	add	x10, x20, #0x2
101542834:     	ldr	x11, [sp, #0x58]
101542838:     	ldr	x11, [x11, #0x4e0]
10154283c:     	cmp	x10, x11
101542840:     	b.hs	0x101543498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30c4>
101542844:     	str	x8, [x9, x10, lsl #3]
101542848:     	b	0x101542e20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a4c>
10154284c:     	ldur	w15, [x9, #0x11]
101542850:     	stur	w15, [x27, #0x9]
101542854:     	ldur	w15, [x9, #0x14]
101542858:     	str	w15, [sp, #0x55c]
10154285c:     	str	w14, [sp, #0x550]
101542860:     	str	w13, [sp, #0x554]
101542864:     	strb	w12, [sp, #0x558]
101542868:     	str	x11, [sp, #0x560]
10154286c:     	str	x10, [sp, #0x568]
101542870:     	ldur	q0, [x9, #0x28]
101542874:     	ldur	q1, [x9, #0x38]
101542878:     	str	q1, [sp, #0x580]
10154287c:     	str	q0, [sp, #0x570]
101542880:     	ldur	q0, [x9, #0x48]
101542884:     	ldur	q1, [x9, #0x58]
101542888:     	ldur	q2, [x9, #0x68]
10154288c:     	ldur	q3, [x9, #0x78]
101542890:     	ldur	q4, [x9, #0x88]
101542894:     	ldur	q5, [x9, #0x98]
101542898:     	ldur	q6, [x9, #0xa8]
10154289c:     	ldur	q7, [x9, #0xb8]
1015428a0:     	str	q7, [sp, #0x600]
1015428a4:     	str	q6, [sp, #0x5f0]
1015428a8:     	str	q5, [sp, #0x5e0]
1015428ac:     	str	q4, [sp, #0x5d0]
1015428b0:     	str	q3, [sp, #0x5c0]
1015428b4:     	str	q2, [sp, #0x5b0]
1015428b8:     	str	q0, [sp, #0x590]
1015428bc:     	str	q1, [sp, #0x5a0]
1015428c0:     	ldr	x9, [x8, #0x48]
1015428c4:     	cmn	x9, #0x1
1015428c8:     	b.eq	0x101543924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3550>
1015428cc:     	add	x9, x9, #0x1
1015428d0:     	str	x9, [x8, #0x48]
1015428d4:     	ldr	x8, [x8, #0x50]
1015428d8:     	cmp	x9, x8
1015428dc:     	b.ne	0x101542954 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2580>
1015428e0:     	ldr	x8, [x22, #0x3d8]
1015428e4:     	cbz	x8, 0x101542954 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2580>
1015428e8:     	ldr	x10, [x22, #0x3d0]
1015428ec:     	add	x11, x10, #0x1
1015428f0:     	ldr	x12, [x22, #0x3c0]
1015428f4:     	cmp	x11, x12
1015428f8:     	csel	x12, xzr, x12, lo
1015428fc:     	sub	x11, x11, x12
101542900:     	str	x11, [x22, #0x3d0]
101542904:     	sub	x8, x8, #0x1
101542908:     	str	x8, [x22, #0x3d8]
10154290c:     	ldr	x8, [x22, #0x3c8]
101542910:     	mov	w9, #0x58               ; =88
101542914:     	madd	x8, x10, x9, x8
101542918:     	ldp	q1, q0, [x8]
10154291c:     	str	q1, [sp, #0x440]
101542920:     	str	q0, [sp, #0x450]
101542924:     	ldp	q1, q0, [x8, #0x30]
101542928:     	ldr	x9, [x8, #0x50]
10154292c:     	ldr	q2, [x8, #0x20]
101542930:     	str	x9, [sp, #0x490]
101542934:     	str	q0, [sp, #0x480]
101542938:     	str	q2, [sp, #0x460]
10154293c:     	str	q1, [sp, #0x470]
101542940:     	ldr	x8, [sp, #0x440]
101542944:     	cbz	x8, 0x101542954 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2580>
101542948:     	mov	w24, #0x1               ; =1
10154294c:     	add	x0, sp, #0x440
101542950:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542954:     	ldr	w20, [sp, #0x608]
101542958:     	mov	x0, x19
10154295c:     	mov	x1, x20
101542960:     	bl	0x1015182c4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare8parallelNtB2_6Region8contains>
101542964:     	tbz	w0, #0x0, 0x101542b28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2754>
101542968:     	ldr	x1, [x23, #0x380]
10154296c:     	cmp	x1, x20
101542970:     	b.ls	0x101544030 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c5c>
101542974:     	ldr	x8, [x23, #0x378]
101542978:     	mov	w9, #0x170              ; =368
10154297c:     	umaddl	x8, w20, w9, x8
101542980:     	add	x9, x8, #0x15c
101542984:     	ldr	w8, [x8, #0x16c]
101542988:     	str	w8, [sp, #0x450]
10154298c:     	ldr	q0, [x9]
101542990:     	str	q0, [sp, #0x440]
101542994:     	mov	w24, #0x1               ; =1
101542998:     	add	x8, sp, #0x220
10154299c:     	add	x0, sp, #0x440
1015429a0:     	bl	0x102a33cd4 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
1015429a4:     	ldr	w8, [x19, #0x48]
1015429a8:     	ldr	w9, [sp, #0x220]
1015429ac:     	cmp	w9, #0x1
1015429b0:     	b.ne	0x1015429c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25ec>
1015429b4:     	ldr	w9, [sp, #0x224]
1015429b8:     	cmp	w9, w8
1015429bc:     	b.eq	0x1015429d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2604>
1015429c0:     	ldr	w9, [sp, #0x228]
1015429c4:     	cmp	w9, #0x1
1015429c8:     	b.ne	0x101542b28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2754>
1015429cc:     	ldr	w9, [sp, #0x22c]
1015429d0:     	cmp	w9, w8
1015429d4:     	b.ne	0x101542b28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2754>
1015429d8:     	ldr	x20, [sp, #0x550]
1015429dc:     	cmp	x20, #0x0
1015429e0:     	cset	w23, eq
1015429e4:     	cbz	x20, 0x101542c98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28c4>
1015429e8:     	ldr	q0, [sp, #0x550]
1015429ec:     	ldr	q1, [sp, #0x560]
1015429f0:     	str	q0, [sp, #0x440]
1015429f4:     	str	q1, [sp, #0x450]
1015429f8:     	ldr	q0, [sp, #0x570]
1015429fc:     	ldr	q1, [sp, #0x580]
101542a00:     	str	q0, [sp, #0x460]
101542a04:     	str	q1, [sp, #0x470]
101542a08:     	ldr	x9, [x22, #0x490]
101542a0c:     	ldr	w1, [x19, #0x4c]
101542a10:     	add	x8, sp, #0x220
101542a14:     	add	x0, x9, #0xf0
101542a18:     	add	x2, sp, #0x440
101542a1c:     	add	x3, x9, #0x2f8
101542a20:     	bl	0x101638bf8 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
101542a24:     	ldrb	w8, [sp, #0x220]
101542a28:     	cmp	w8, #0x14
101542a2c:     	b.ne	0x101542d18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2944>
101542a30:     	mov	w24, #0x0               ; =0
101542a34:     	add	x0, sp, #0x440
101542a38:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542a3c:     	b	0x101542cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28dc>
101542a40:     	ldur	w8, [x9, #0x11]
101542a44:     	str	w8, [sp, #0xa0]
101542a48:     	ldur	w8, [x9, #0x14]
101542a4c:     	stur	w8, [sp, #0xa3]
101542a50:     	ldur	q0, [x9, #0x28]
101542a54:     	ldur	q1, [x9, #0x38]
101542a58:     	stp	q0, q1, [sp, #0x110]
101542a5c:     	ldur	q0, [x9, #0x48]
101542a60:     	str	q0, [sp, #0x330]
101542a64:     	stp	w14, w13, [x21]
101542a68:     	strb	w12, [x21, #0x8]
101542a6c:     	mov	w8, w8
101542a70:     	str	w8, [x21, #0xc]
101542a74:     	ldr	w8, [sp, #0xa0]
101542a78:     	stur	w8, [x21, #0x9]
101542a7c:     	stp	x11, x10, [x21, #0x10]
101542a80:     	ldp	q1, q0, [sp, #0x110]
101542a84:     	stp	q1, q0, [x21, #0x20]
101542a88:     	ldr	q0, [sp, #0x330]
101542a8c:     	str	q0, [x21, #0x40]
101542a90:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542a94:     	ldr	x1, [x19, #0x378]
101542a98:     	ldr	x2, [x19, #0x380]
101542a9c:     	add	x0, sp, #0x550
101542aa0:     	add	x4, x8, #0x8
101542aa4:     	ldr	x3, [sp, #0x50]
101542aa8:     	bl	0x101528544 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14numeric_writesNtB6_10Invocation21prepare_numeric_writes1_0Be_>
101542aac:     	ldr	q0, [sp, #0x570]
101542ab0:     	ldr	q1, [sp, #0x580]
101542ab4:     	stp	q0, q1, [x28, #0x20]
101542ab8:     	ldr	q0, [sp, #0x590]
101542abc:     	str	q0, [x28, #0x40]
101542ac0:     	ldr	q0, [sp, #0x560]
101542ac4:     	ldr	q1, [sp, #0x550]
101542ac8:     	stp	q1, q0, [x28]
101542acc:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542ad0:     	ldr	q0, [sp, #0x550]
101542ad4:     	ldr	q1, [sp, #0x560]
101542ad8:     	str	q0, [sp, #0x440]
101542adc:     	str	q1, [sp, #0x450]
101542ae0:     	ldr	q2, [sp, #0x570]
101542ae4:     	str	q2, [sp, #0x460]
101542ae8:     	ldr	x8, [sp, #0x580]
101542aec:     	str	x8, [sp, #0x470]
101542af0:     	stur	q0, [x27, #0x4]
101542af4:     	stur	q1, [x27, #0x14]
101542af8:     	stur	q2, [x27, #0x24]
101542afc:     	stur	x8, [x27, #0x34]
101542b00:     	str	wzr, [x28]
101542b04:     	ldr	q0, [sp, #0x550]
101542b08:     	ldr	q1, [sp, #0x560]
101542b0c:     	stur	q0, [x28, #0x4]
101542b10:     	stur	q1, [x28, #0x14]
101542b14:     	ldr	q0, [sp, #0x570]
101542b18:     	stur	q0, [x28, #0x24]
101542b1c:     	ldur	q0, [x27, #0x2c]
101542b20:     	str	q0, [x28, #0x30]
101542b24:     	b	0x101542bf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2820>
101542b28:     	str	wzr, [x21]
101542b2c:     	mov	w9, #0xc                ; =12
101542b30:     	strb	w9, [x21, #0x8]
101542b34:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101542b38:     	add	x8, x8, #0xd4b
101542b3c:     	mov	w9, #0x2d               ; =45
101542b40:     	stp	x8, x9, [x21, #0x10]
101542b44:     	ldr	x8, [sp, #0x550]
101542b48:     	cbz	x8, 0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542b4c:     	add	x0, sp, #0x550
101542b50:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542b54:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542b58:     	cmp	x22, #0x1
101542b5c:     	b.gt	0x101542c18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2844>
101542b60:     	cbz	x22, 0x101542d64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2990>
101542b64:     	cmp	x22, #0x1
101542b68:     	b.ne	0x101542dd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a04>
101542b6c:     	ldr	x8, [sp, #0x58]
101542b70:     	ldr	x8, [x8, #0x490]
101542b74:     	ldrb	w8, [x8, #0x460]
101542b78:     	tbz	w8, #0x0, 0x101543034 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c60>
101542b7c:     	str	wzr, [x19]
101542b80:     	mov	w8, #0xc                ; =12
101542b84:     	strb	w8, [x19, #0x8]
101542b88:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101542b8c:     	add	x8, x8, #0x9b1
101542b90:     	mov	w9, #0x16               ; =22
101542b94:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101542b98:     	str	wzr, [x23]
101542b9c:     	mov	w8, #0xc                ; =12
101542ba0:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
101542ba4:     	add	x9, x9, #0x7d
101542ba8:     	stp	x8, x9, [x23, #0x8]
101542bac:     	mov	w8, #0x1a               ; =26
101542bb0:     	str	x8, [x23, #0x18]
101542bb4:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542bb8:     	ldur	q0, [x27, #0x4]
101542bbc:     	ldur	q1, [x27, #0x14]
101542bc0:     	str	q0, [sp, #0x440]
101542bc4:     	str	q1, [sp, #0x450]
101542bc8:     	ldr	w9, [sp, #0x574]
101542bcc:     	str	w9, [sp, #0x460]
101542bd0:     	ldr	x10, [sp, #0x578]
101542bd4:     	stur	q0, [x28, #0x14]
101542bd8:     	stur	q1, [x28, #0x24]
101542bdc:     	str	w9, [x28, #0x34]
101542be0:     	str	wzr, [x28]
101542be4:     	mov	w9, #0xd                ; =13
101542be8:     	strb	w9, [x28, #0x8]
101542bec:     	str	w8, [x28, #0x10]
101542bf0:     	str	x10, [x28, #0x38]
101542bf4:     	ldr	x8, [sp, #0x720]
101542bf8:     	mov	x9, #-0x1               ; =-1
101542bfc:     	ldaddl	x9, x8, [x8]
101542c00:     	cmp	x8, #0x1
101542c04:     	b.ne	0x10154331c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f48>
101542c08:     	dmb	ishld
101542c0c:     	add	x0, sp, #0x720
101542c10:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101542c14:     	b	0x10154331c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f48>
101542c18:     	cmp	x22, #0x2
101542c1c:     	b.eq	0x101542d90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29bc>
101542c20:     	cmp	x22, #0x12
101542c24:     	b.ne	0x101542dd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a04>
101542c28:     	ldr	x8, [sp, #0x58]
101542c2c:     	ldr	x8, [x8, #0x490]
101542c30:     	ldrb	w8, [x8, #0x460]
101542c34:     	tbnz	w8, #0x0, 0x101542c4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2878>
101542c38:     	ldp	x8, x9, [x24]
101542c3c:     	ldr	x10, [x24, #0x10]
101542c40:     	orr	x8, x8, x9
101542c44:     	orr	x8, x8, x10
101542c48:     	cbz	x8, 0x1015433ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fd8>
101542c4c:     	str	wzr, [x19]
101542c50:     	mov	w8, #0xc                ; =12
101542c54:     	strb	w8, [x19, #0x8]
101542c58:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101542c5c:     	add	x8, x8, #0xa27
101542c60:     	mov	w9, #0x2d               ; =45
101542c64:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101542c68:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101542c6c:     	add	x2, x2, #0x948
101542c70:     	mov	x0, x9
101542c74:     	mov	x1, x10
101542c78:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542c7c:     	str	wzr, [x28]
101542c80:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101542c84:     	add	x8, x8, #0xc87
101542c88:     	mov	w9, #0xc                ; =12
101542c8c:     	stp	x9, x8, [x28, #0x8]
101542c90:     	mov	w8, #0x30               ; =48
101542c94:     	b	0x1015432ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f18>
101542c98:     	ldr	x8, [x22, #0x4d8]
101542c9c:     	cbz	x8, 0x10154300c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c38>
101542ca0:     	ldr	x9, [x22, #0x4e0]
101542ca4:     	cbz	x9, 0x10154300c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c38>
101542ca8:     	ldr	x9, [sp, #0x558]
101542cac:     	str	x9, [x8]
101542cb0:     	ldr	w8, [sp, #0x608]
101542cb4:     	ldr	x10, [x22, #0x490]
101542cb8:     	mov	w11, #0x1               ; =1
101542cbc:     	str	w11, [x10, #0x2f0]
101542cc0:     	str	w8, [x10, #0x2f4]
101542cc4:     	ldr	x8, [x22, #0x490]
101542cc8:     	strb	w11, [x8, #0x460]
101542ccc:     	ldr	x8, [x22, #0x3c0]
101542cd0:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101542cd4:     	cmp	x8, x9
101542cd8:     	b.eq	0x101543348 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f74>
101542cdc:     	ldr	x8, [x22, #0x3d8]
101542ce0:     	cbnz	x8, 0x101543348 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f74>
101542ce4:     	ldr	x9, [x22, #0x3e8]
101542ce8:     	ldr	x8, [x22, #0x3f8]
101542cec:     	cmp	x8, x9
101542cf0:     	b.eq	0x101543334 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f60>
101542cf4:     	str	wzr, [x21]
101542cf8:     	mov	w8, #0xc                ; =12
101542cfc:     	strb	w8, [x21, #0x8]
101542d00:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101542d04:     	add	x8, x8, #0xd78
101542d08:     	mov	w9, #0x25               ; =37
101542d0c:     	stp	x8, x9, [x21, #0x10]
101542d10:     	cbz	x20, 0x101542b44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2770>
101542d14:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542d18:     	ldur	w9, [x25, #0x1]
101542d1c:     	stur	w9, [x21, #0x9]
101542d20:     	ldr	w9, [sp, #0x224]
101542d24:     	str	w9, [x21, #0xc]
101542d28:     	ldr	q0, [sp, #0x240]
101542d2c:     	stur	q0, [x21, #0x28]
101542d30:     	ldr	x9, [sp, #0x250]
101542d34:     	str	x9, [x21, #0x38]
101542d38:     	ldr	d0, [sp, #0x238]
101542d3c:     	ldur	q1, [x25, #0x8]
101542d40:     	mov	w9, #0x2                ; =2
101542d44:     	str	w9, [x21]
101542d48:     	strb	w8, [x21, #0x8]
101542d4c:     	str	q1, [x21, #0x10]
101542d50:     	str	d0, [x21, #0x20]
101542d54:     	mov	w24, #0x0               ; =0
101542d58:     	add	x0, sp, #0x440
101542d5c:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542d60:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542d64:     	ldr	x8, [sp, #0x58]
101542d68:     	ldr	x8, [x8, #0x490]
101542d6c:     	ldrb	w8, [x8, #0x460]
101542d70:     	tbz	w8, #0x0, 0x101543168 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d94>
101542d74:     	str	wzr, [x19]
101542d78:     	mov	w8, #0xc                ; =12
101542d7c:     	strb	w8, [x19, #0x8]
101542d80:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101542d84:     	add	x8, x8, #0xa0f
101542d88:     	mov	w9, #0x18               ; =24
101542d8c:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101542d90:     	ldr	x8, [sp, #0x58]
101542d94:     	ldr	x8, [x8, #0x490]
101542d98:     	ldrb	w8, [x8, #0x460]
101542d9c:     	tbnz	w8, #0x0, 0x1015432ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ed8>
101542da0:     	ldr	x8, [x24, #0x10]
101542da4:     	cbnz	x8, 0x1015432ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ed8>
101542da8:     	ldp	x3, x4, [x24]
101542dac:     	mov	x0, x19
101542db0:     	ldr	x1, [sp, #0x58]
101542db4:     	mov	x2, x20
101542db8:     	add	sp, sp, #0x810
101542dbc:     	ldp	x29, x30, [sp, #0x50]
101542dc0:     	ldp	x20, x19, [sp, #0x40]
101542dc4:     	ldp	x22, x21, [sp, #0x30]
101542dc8:     	ldp	x24, x23, [sp, #0x20]
101542dcc:     	ldp	x26, x25, [sp, #0x10]
101542dd0:     	ldp	x28, x27, [sp], #0x60
101542dd4:     	b	0x10152f6bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper>
101542dd8:     	ldr	x5, [x24]
101542ddc:     	mov	x0, x19
101542de0:     	ldr	x1, [sp, #0x58]
101542de4:     	mov	x2, x20
101542de8:     	mov	x3, x22
101542dec:     	mov	x4, x21
101542df0:     	add	sp, sp, #0x810
101542df4:     	ldp	x29, x30, [sp, #0x50]
101542df8:     	ldp	x20, x19, [sp, #0x40]
101542dfc:     	ldp	x22, x21, [sp, #0x30]
101542e00:     	ldp	x24, x23, [sp, #0x20]
101542e04:     	ldp	x26, x25, [sp, #0x10]
101542e08:     	ldp	x28, x27, [sp], #0x60
101542e0c:     	b	0x10152f9ac <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper>
101542e10:     	add	x8, sp, #0x550
101542e14:     	add	x0, sp, #0x220
101542e18:     	bl	0x102e09674 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix12elements_mut>
101542e1c:     	ldr	x19, [sp, #0x558]
101542e20:     	add	x0, sp, #0x550
101542e24:     	add	x1, sp, #0x220
101542e28:     	mov	w2, #0x108              ; =264
101542e2c:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
101542e30:     	ldr	x8, [sp, #0x58]
101542e34:     	ldr	x8, [x8, #0x490]
101542e38:     	ldr	x8, [x8, #0x3c0]
101542e3c:     	cbz	x8, 0x101542f54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b80>
101542e40:     	ldr	x9, [x8, #0x40]
101542e44:     	cmp	x9, #0x2
101542e48:     	b.eq	0x101542f54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b80>
101542e4c:     	ldr	x10, [x8, #0xd8]
101542e50:     	ldr	x9, [sp, #0x48]
101542e54:     	cmp	x10, x9
101542e58:     	b.ne	0x101542f54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b80>
101542e5c:     	ldr	x9, [x23, x22]
101542e60:     	ldr	x10, [x8, #0x78]
101542e64:     	cmp	x9, x10
101542e68:     	b.hs	0x101542f54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b80>
101542e6c:     	ldr	x8, [x8, #0x70]
101542e70:     	mov	w10, #0x108             ; =264
101542e74:     	madd	x20, x9, x10, x8
101542e78:     	mov	x0, x20
101542e7c:     	bl	0x101522dc8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
101542e80:     	add	x1, sp, #0x550
101542e84:     	mov	x0, x20
101542e88:     	mov	w2, #0x108              ; =264
101542e8c:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
101542e90:     	ldr	x8, [sp, #0x58]
101542e94:     	ldr	x8, [x8, #0x4d8]
101542e98:     	cbz	x8, 0x101543560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x318c>
101542e9c:     	ldr	x9, [x23, x22]
101542ea0:     	ldr	x10, [x21, #0xb0]
101542ea4:     	add	x9, x10, x9, lsl #2
101542ea8:     	add	x9, x9, #0x2
101542eac:     	ldr	x10, [sp, #0x58]
101542eb0:     	ldr	x10, [x10, #0x4e0]
101542eb4:     	cmp	x9, x10
101542eb8:     	b.hs	0x101543560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x318c>
101542ebc:     	str	x19, [x8, x9, lsl #3]
101542ec0:     	ldr	x8, [sp, #0x58]
101542ec4:     	ldr	x8, [x8, #0x4d8]
101542ec8:     	cbz	x8, 0x101543560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x318c>
101542ecc:     	ldr	x9, [x23, x22]
101542ed0:     	ldr	x10, [x21, #0x40]
101542ed4:     	ldr	x11, [x21, #0xb0]
101542ed8:     	add	x9, x9, x10, lsl #2
101542edc:     	add	x9, x9, x11
101542ee0:     	add	x9, x9, #0x2
101542ee4:     	ldr	x10, [sp, #0x58]
101542ee8:     	ldr	x10, [x10, #0x4e0]
101542eec:     	cmp	x9, x10
101542ef0:     	b.hs	0x101543560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x318c>
101542ef4:     	mov	w10, #0x1               ; =1
101542ef8:     	str	x10, [x8, x9, lsl #3]
101542efc:     	mov	w19, #0x0               ; =0
101542f00:     	add	x0, sp, #0x550
101542f04:     	ldp	x3, x1, [sp, #0x50]
101542f08:     	ldr	x2, [sp, #0x48]
101542f0c:     	bl	0x101534628 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation26resume_numeric_after_write>
101542f10:     	ldr	w8, [sp, #0x550]
101542f14:     	cmp	w8, #0x6
101542f18:     	b.ne	0x10154389c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34c8>
101542f1c:     	str	xzr, [x28, #0x8]
101542f20:     	str	w8, [x28]
101542f24:     	mov	w19, #0x0               ; =0
101542f28:     	sub	x0, x29, #0x90
101542f2c:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101542f30:     	ldr	x8, [sp, #0x720]
101542f34:     	mov	x9, #-0x1               ; =-1
101542f38:     	ldaddl	x9, x8, [x8]
101542f3c:     	cmp	x8, #0x1
101542f40:     	b.ne	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542f44:     	dmb	ishld
101542f48:     	add	x0, sp, #0x720
101542f4c:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101542f50:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542f54:     	str	wzr, [x28]
101542f58:     	mov	w8, #0xc                ; =12
101542f5c:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101542f60:     	add	x9, x9, #0xa70
101542f64:     	stp	x8, x9, [x28, #0x8]
101542f68:     	mov	w8, #0x2b               ; =43
101542f6c:     	str	x8, [x28, #0x18]
101542f70:     	mov	w19, #0x0               ; =0
101542f74:     	add	x0, sp, #0x550
101542f78:     	bl	0x101522dc8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
101542f7c:     	mov	w19, #0x0               ; =0
101542f80:     	b	0x1015432f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f1c>
101542f84:     	add	x8, sp, #0x550
101542f88:     	add	x0, x24, #0x3b8
101542f8c:     	bl	0x10236caa0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
101542f90:     	ldr	x8, [sp, #0x58]
101542f94:     	ldr	x8, [x8, #0x20]
101542f98:     	cmp	x8, #0x1
101542f9c:     	b.ne	0x101543328 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f54>
101542fa0:     	ldr	x8, [sp, #0x58]
101542fa4:     	ldr	w8, [x8, #0x40]
101542fa8:     	tbz	w8, #0x0, 0x101543458 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3084>
101542fac:     	ldr	x8, [sp, #0x58]
101542fb0:     	ldr	x1, [x8, #0x28]
101542fb4:     	ldr	x2, [x8, #0x48]
101542fb8:     	add	x8, sp, #0x668
101542fbc:     	add	x0, sp, #0x550
101542fc0:     	bl	0x102d50c90 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget11with_limits>
101542fc4:     	ldr	x8, [sp, #0x550]
101542fc8:     	mov	x9, #-0x1               ; =-1
101542fcc:     	ldaddl	x9, x8, [x8]
101542fd0:     	cmp	x8, #0x1
101542fd4:     	b.ne	0x101542fe4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c10>
101542fd8:     	dmb	ishld
101542fdc:     	add	x0, sp, #0x550
101542fe0:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101542fe4:     	ldr	x8, [sp, #0x660]
101542fe8:     	ldr	x9, [x8, #0x6c0]
101542fec:     	cmp	x9, #0x100, lsl #12     ; =0x100000
101542ff0:     	b.ls	0x1015434bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30e8>
101542ff4:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
101542ff8:     	ldr	q0, [x8, #0x80]
101542ffc:     	stur	q0, [x23, #0x8]
101543000:     	mov	w8, #0x6                ; =6
101543004:     	str	w8, [x23]
101543008:     	b	0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
10154300c:     	str	wzr, [x21]
101543010:     	mov	w9, #0xc                ; =12
101543014:     	strb	w9, [x21, #0x8]
101543018:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
10154301c:     	add	x8, x8, #0x67e
101543020:     	mov	w9, #0x29               ; =41
101543024:     	b	0x101542b40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x276c>
101543028:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154302c:     	add	x0, x0, #0x988
101543030:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101543034:     	add	x0, sp, #0x550
101543038:     	ldr	x1, [sp, #0x58]
10154303c:     	mov	x2, x20
101543040:     	bl	0x10153ebe8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
101543044:     	ldr	w8, [sp, #0x550]
101543048:     	tbz	w8, #0x0, 0x101543360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f8c>
10154304c:     	ldr	w21, [sp, #0x554]
101543050:     	ldr	w22, [sp, #0x558]
101543054:     	add	x0, sp, #0x550
101543058:     	ldr	x1, [sp, #0x58]
10154305c:     	mov	x2, x20
101543060:     	mov	w3, #0x1                ; =1
101543064:     	mov	w4, #0x8                ; =8
101543068:     	mov	x5, #0x0                ; =0
10154306c:     	bl	0x10152bc4c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
101543070:     	ldr	w8, [sp, #0x550]
101543074:     	cmp	w8, #0x6
101543078:     	b.ne	0x10154340c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
10154307c:     	ldr	x8, [sp, #0x558]
101543080:     	cmp	x8, #0x2
101543084:     	b.ne	0x1015430dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d08>
101543088:     	add	x0, sp, #0x550
10154308c:     	ldr	x1, [sp, #0x58]
101543090:     	mov	x2, x21
101543094:     	mov	x3, x22
101543098:     	bl	0x10154c2f0 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation15move_joined_map>
10154309c:     	ldr	w9, [sp, #0x550]
1015430a0:     	ldrb	w8, [sp, #0x554]
1015430a4:     	cmp	w9, #0x6
1015430a8:     	b.ne	0x1015435f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3220>
1015430ac:     	tbnz	w8, #0x0, 0x101543154 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d80>
1015430b0:     	ldr	x8, [sp, #0x58]
1015430b4:     	ldr	x9, [x8, #0x490]
1015430b8:     	add	x8, sp, #0x550
1015430bc:     	add	x0, x9, #0xf0
1015430c0:     	add	x3, x9, #0x2f8
1015430c4:     	mov	x1, x21
1015430c8:     	mov	x2, x22
1015430cc:     	bl	0x101637a40 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena15copy_current_to>
1015430d0:     	ldrb	w8, [sp, #0x550]
1015430d4:     	cmp	w8, #0x14
1015430d8:     	b.ne	0x10154385c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3488>
1015430dc:     	ldr	x1, [x23, #0x380]
1015430e0:     	cmp	x20, x1
1015430e4:     	b.hs	0x101544254 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e80>
1015430e8:     	ldr	x8, [x23, #0x378]
1015430ec:     	mov	w9, #0x170              ; =368
1015430f0:     	madd	x8, x20, x9, x8
1015430f4:     	ldp	x10, x9, [x8]
1015430f8:     	mov	w11, #0x11              ; =17
1015430fc:     	eor	x10, x10, x11
101543100:     	orr	x9, x10, x9
101543104:     	cbnz	x9, 0x101543154 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d80>
101543108:     	ldr	x1, [x23, #0x390]
10154310c:     	ldr	w2, [x8, #0x10]
101543110:     	cmp	x1, x2
101543114:     	b.ls	0x101544290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ebc>
101543118:     	ldr	x8, [x23, #0x388]
10154311c:     	mov	w9, #0x180              ; =384
101543120:     	umaddl	x8, w2, w9, x8
101543124:     	ldp	x8, x9, [x8]
101543128:     	mov	w10, #0x5               ; =5
10154312c:     	eor	x8, x8, x10
101543130:     	orr	x8, x8, x9
101543134:     	cbnz	x8, 0x101543154 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d80>
101543138:     	add	x0, sp, #0x550
10154313c:     	ldr	x1, [sp, #0x58]
101543140:     	mov	w3, #0x1                ; =1
101543144:     	bl	0x10153f220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
101543148:     	ldr	w8, [sp, #0x550]
10154314c:     	cmp	w8, #0x6
101543150:     	b.ne	0x101543838 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3464>
101543154:     	ldr	x8, [sp, #0x58]
101543158:     	ldr	x8, [x8, #0x490]
10154315c:     	mov	w9, #0x1                ; =1
101543160:     	strb	w9, [x8, #0x460]
101543164:     	b	0x101541904 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1530>
101543168:     	ldr	x1, [x23, #0x380]
10154316c:     	cmp	x20, x1
101543170:     	b.hs	0x101544140 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d6c>
101543174:     	ldr	x8, [x23, #0x378]
101543178:     	mov	w9, #0x170              ; =368
10154317c:     	madd	x25, x20, x9, x8
101543180:     	ldp	x9, x8, [x25]
101543184:     	cmp	x9, #0x2
101543188:     	sbcs	xzr, x8, xzr
10154318c:     	b.hs	0x10154337c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fa8>
101543190:     	ldr	x9, [x24]
101543194:     	ldr	x8, [sp, #0x58]
101543198:     	ldr	x21, [x8, #0x4d8]
10154319c:     	cmp	x9, x21
1015431a0:     	b.ne	0x101543440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x306c>
1015431a4:     	ldr	x22, [x24, #0x8]
1015431a8:     	ldr	x8, [x25, #0x128]
1015431ac:     	cmp	x22, x8
1015431b0:     	b.ne	0x101543440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x306c>
1015431b4:     	ldr	x9, [x24, #0x10]
1015431b8:     	cbnz	x9, 0x101543440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x306c>
1015431bc:     	ldr	x9, [sp, #0x58]
1015431c0:     	ldr	x9, [x9, #0x4e0]
1015431c4:     	cmp	x8, x9
1015431c8:     	b.hi	0x101543440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x306c>
1015431cc:     	ldr	x23, [x25, #0x120]
1015431d0:     	add	x0, sp, #0x550
1015431d4:     	ldr	x1, [sp, #0x58]
1015431d8:     	mov	x2, x20
1015431dc:     	mov	x3, x21
1015431e0:     	mov	x4, x22
1015431e4:     	bl	0x10152d168 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14selected_callsNtB4_10Invocation21prepared_library_call>
1015431e8:     	ldr	w8, [sp, #0x550]
1015431ec:     	cmp	w8, #0x6
1015431f0:     	b.ne	0x10154340c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
1015431f4:     	ldr	x8, [sp, #0x558]
1015431f8:     	cmp	x8, #0x2
1015431fc:     	b.ne	0x101543544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3170>
101543200:     	add	x0, sp, #0x550
101543204:     	ldr	x1, [sp, #0x58]
101543208:     	mov	x2, x20
10154320c:     	mov	x3, x21
101543210:     	mov	x4, x22
101543214:     	bl	0x1015382fc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5lines10line_callsNtNtB6_10invocation10Invocation16line_matrix_call>
101543218:     	ldr	w8, [sp, #0x550]
10154321c:     	cmp	w8, #0x6
101543220:     	b.ne	0x10154340c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
101543224:     	ldr	x8, [sp, #0x558]
101543228:     	cmp	x8, #0x2
10154322c:     	b.ne	0x101543544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3170>
101543230:     	add	x0, sp, #0x550
101543234:     	ldr	x1, [sp, #0x58]
101543238:     	mov	x2, x20
10154323c:     	mov	x3, x21
101543240:     	mov	x4, x22
101543244:     	bl	0x10153c380 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime7session7capture14captured_callsNtNtB8_10invocation10Invocation26captured_line_element_call>
101543248:     	ldr	w9, [sp, #0x550]
10154324c:     	ldrb	w8, [sp, #0x554]
101543250:     	cmp	w9, #0x6
101543254:     	b.ne	0x1015435f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3220>
101543258:     	tbnz	w8, #0x0, 0x101543154 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d80>
10154325c:     	add	x0, sp, #0x550
101543260:     	ldr	x1, [sp, #0x58]
101543264:     	mov	x2, x20
101543268:     	mov	x3, x21
10154326c:     	mov	x4, x22
101543270:     	bl	0x101548e88 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation18selected_join_call>
101543274:     	ldr	w9, [sp, #0x550]
101543278:     	ldrb	w8, [sp, #0x554]
10154327c:     	cmp	w9, #0x6
101543280:     	b.ne	0x1015435f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3220>
101543284:     	tbz	w8, #0x0, 0x101543a24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3650>
101543288:     	ldr	x8, [sp, #0x58]
10154328c:     	ldr	x9, [x8, #0x490]
101543290:     	mov	w10, #0x1               ; =1
101543294:     	strb	w10, [x9, #0x460]
101543298:     	ldr	x8, [x8, #0x290]
10154329c:     	cmp	x8, #0x4
1015432a0:     	cset	w8, eq
1015432a4:     	stp	x8, x10, [x19, #0x8]
1015432a8:     	b	0x101541908 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1534>
1015432ac:     	str	wzr, [x19]
1015432b0:     	mov	w8, #0xc                ; =12
1015432b4:     	strb	w8, [x19, #0x8]
1015432b8:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
1015432bc:     	add	x8, x8, #0x996
1015432c0:     	mov	w9, #0x1b               ; =27
1015432c4:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
1015432c8:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015432cc:     	add	x0, x0, #0x940
1015432d0:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015432d4:     	str	wzr, [x28]
1015432d8:     	adrp	x8, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015432dc:     	add	x8, x8, #0x2d9
1015432e0:     	mov	w9, #0xc                ; =12
1015432e4:     	stp	x9, x8, [x28, #0x8]
1015432e8:     	mov	w8, #0x28               ; =40
1015432ec:     	str	x8, [x28, #0x18]
1015432f0:     	sub	x0, x29, #0x90
1015432f4:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015432f8:     	ldr	x8, [sp, #0x720]
1015432fc:     	mov	x9, #-0x1               ; =-1
101543300:     	ldaddl	x9, x8, [x8]
101543304:     	cmp	x8, #0x1
101543308:     	b.ne	0x101543318 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f44>
10154330c:     	dmb	ishld
101543310:     	add	x0, sp, #0x720
101543314:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101543318:     	tbz	w19, #0x0, 0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154331c:     	add	x0, sp, #0x220
101543320:     	bl	0x101525834 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
101543324:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543328:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
10154332c:     	add	x8, x8, #0x10a
101543330:     	b	0x101543460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x308c>
101543334:     	add	x20, x22, #0x3c0
101543338:     	mov	x0, x20
10154333c:     	bl	0x101522e40 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
101543340:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101543344:     	str	x8, [x20]
101543348:     	mov	w8, #0x1                ; =1
10154334c:     	dup.2d	v0, x8
101543350:     	b	0x101540b88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b4>
101543354:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543358:     	add	x0, x0, #0x9b8
10154335c:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101543360:     	str	wzr, [x19]
101543364:     	mov	w8, #0xc                ; =12
101543368:     	str	w8, [x19, #0x8]
10154336c:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101543370:     	add	x8, x8, #0xd5
101543374:     	mov	w9, #0x21               ; =33
101543378:     	b	0x101541438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
10154337c:     	str	wzr, [x19]
101543380:     	mov	w8, #0xc                ; =12
101543384:     	strb	w8, [x19, #0x8]
101543388:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10154338c:     	add	x8, x8, #0x9eb
101543390:     	b	0x1015420b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ce0>
101543394:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543398:     	add	x0, x0, #0x958
10154339c:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015433a0:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015433a4:     	add	x0, x0, #0x970
1015433a8:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015433ac:     	add	x0, sp, #0x550
1015433b0:     	ldr	x1, [sp, #0x58]
1015433b4:     	mov	x2, x20
1015433b8:     	mov	w3, #0x12               ; =18
1015433bc:     	mov	w4, #0x8                ; =8
1015433c0:     	mov	x5, #0x0                ; =0
1015433c4:     	bl	0x10152bc4c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015433c8:     	ldr	w8, [sp, #0x550]
1015433cc:     	cmp	w8, #0x6
1015433d0:     	b.ne	0x10154340c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
1015433d4:     	ldr	x8, [sp, #0x558]
1015433d8:     	cmp	x8, #0x2
1015433dc:     	b.ne	0x101543544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3170>
1015433e0:     	mov	x0, x19
1015433e4:     	ldr	x1, [sp, #0x58]
1015433e8:     	mov	x2, x20
1015433ec:     	add	sp, sp, #0x810
1015433f0:     	ldp	x29, x30, [sp, #0x50]
1015433f4:     	ldp	x20, x19, [sp, #0x40]
1015433f8:     	ldp	x22, x21, [sp, #0x30]
1015433fc:     	ldp	x24, x23, [sp, #0x20]
101543400:     	ldp	x26, x25, [sp, #0x10]
101543404:     	ldp	x28, x27, [sp], #0x60
101543408:     	b	0x10153044c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation>
10154340c:     	ldr	w9, [sp, #0x554]
101543410:     	ldur	q0, [x27, #0x18]
101543414:     	stur	q0, [x19, #0x18]
101543418:     	ldur	q0, [x27, #0x28]
10154341c:     	stur	q0, [x19, #0x28]
101543420:     	ldur	q0, [x27, #0x38]
101543424:     	stur	q0, [x19, #0x38]
101543428:     	ldr	x10, [sp, #0x598]
10154342c:     	str	x10, [x19, #0x48]
101543430:     	ldur	q0, [x27, #0x8]
101543434:     	stp	w8, w9, [x19]
101543438:     	stur	q0, [x19, #0x8]
10154343c:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543440:     	str	wzr, [x19]
101543444:     	mov	w8, #0xc                ; =12
101543448:     	strb	w8, [x19, #0x8]
10154344c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101543450:     	add	x8, x8, #0x9c7
101543454:     	b	0x1015420b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ce0>
101543458:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
10154345c:     	add	x8, x8, #0x128
101543460:     	str	wzr, [x23]
101543464:     	mov	w9, #0xc                ; =12
101543468:     	stp	x9, x8, [x23, #0x8]
10154346c:     	mov	w8, #0x1e               ; =30
101543470:     	str	x8, [x23, #0x18]
101543474:     	ldr	x8, [sp, #0x550]
101543478:     	mov	x9, #-0x1               ; =-1
10154347c:     	ldaddl	x9, x8, [x8]
101543480:     	cmp	x8, #0x1
101543484:     	b.ne	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543488:     	dmb	ishld
10154348c:     	add	x0, sp, #0x550
101543490:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101543494:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543498:     	str	wzr, [x28]
10154349c:     	mov	w8, #0xc                ; =12
1015434a0:     	strb	w8, [x28, #0x8]
1015434a4:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
1015434a8:     	add	x8, x8, #0x67e
1015434ac:     	mov	w9, #0x29               ; =41
1015434b0:     	stp	x8, x9, [x28, #0x10]
1015434b4:     	mov	w19, #0x1               ; =1
1015434b8:     	b	0x1015432f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f1c>
1015434bc:     	str	xzr, [sp, #0x38]
1015434c0:     	add	x24, sp, #0x720
1015434c4:     	ldp	x15, x9, [sp, #0x48]
1015434c8:     	lsl	x11, x9, #2
1015434cc:     	add	x9, x15, x11
1015434d0:     	str	x9, [sp, #0x28]
1015434d4:     	ldr	x12, [x8, #0x5a0]
1015434d8:     	ldr	x13, [x8, #0x598]
1015434dc:     	mov	w8, #0xc                ; =12
1015434e0:     	mov	w9, #0x29               ; =41
1015434e4:     	mov	w14, #0x58              ; =88
1015434e8:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015434ec:     	add	x10, x10, #0x146
1015434f0:     	ldr	x16, [sp, #0x38]
1015434f4:     	cbz	x11, 0x101543584 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31b0>
1015434f8:     	ldr	w17, [x15], #0x4
1015434fc:     	cmp	x12, x17
101543500:     	b.ls	0x101543534 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3160>
101543504:     	umaddl	x17, w17, w14, x13
101543508:     	ldr	x17, [x17, #0x8]
10154350c:     	sub	x11, x11, #0x4
101543510:     	ldr	x0, [sp, #0x38]
101543514:     	adds	x0, x17, x0
101543518:     	str	x0, [sp, #0x38]
10154351c:     	b.lo	0x1015434f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x311c>
101543520:     	and	x8, x16, #0xffffffffffffff00
101543524:     	orr	x8, x8, #0xc
101543528:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
10154352c:     	add	x10, x10, #0x16f
101543530:     	mov	w9, #0x1f               ; =31
101543534:     	str	wzr, [x23]
101543538:     	stp	x8, x10, [x23, #0x8]
10154353c:     	str	x9, [x23, #0x18]
101543540:     	b	0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
101543544:     	ldur	q0, [x27, #0x8]
101543548:     	ldr	x8, [sp, #0x58]
10154354c:     	ldr	x8, [x8, #0x490]
101543550:     	mov	w9, #0x1                ; =1
101543554:     	strb	w9, [x8, #0x460]
101543558:     	stur	q0, [x19, #0x8]
10154355c:     	b	0x101541908 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1534>
101543560:     	mov	w19, #0x0               ; =0
101543564:     	str	wzr, [x28]
101543568:     	mov	w8, #0xc                ; =12
10154356c:     	strb	w8, [x28, #0x8]
101543570:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x170>
101543574:     	add	x8, x8, #0x67e
101543578:     	mov	w9, #0x29               ; =41
10154357c:     	stp	x8, x9, [x28, #0x10]
101543580:     	b	0x1015432f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f1c>
101543584:     	mov	w8, #0x48               ; =72
101543588:     	mov	x9, #0x48               ; =72
10154358c:     	madd	x8, x20, x8, x9
101543590:     	ldr	x9, [sp, #0x38]
101543594:     	umulh	x9, x9, x8
101543598:     	cmp	xzr, x9
10154359c:     	b.ne	0x101543db4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39e0>
1015435a0:     	ldr	x9, [sp, #0x38]
1015435a4:     	mul	x8, x9, x8
1015435a8:     	mov	w9, #0x580              ; =1408
1015435ac:     	mov	x10, #0x400             ; =1024
1015435b0:     	madd	x9, x20, x9, x10
1015435b4:     	adds	x8, x8, x9
1015435b8:     	str	x8, [sp, #0x30]
1015435bc:     	b.hs	0x101543dc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39f4>
1015435c0:     	mov	x8, #-0x201             ; =-513
1015435c4:     	movk	x8, #0x1fff, lsl #48
1015435c8:     	ldr	x9, [sp, #0x30]
1015435cc:     	cmp	x9, x8
1015435d0:     	b.ls	0x101543658 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3284>
1015435d4:     	str	wzr, [x23]
1015435d8:     	mov	w8, #0xc                ; =12
1015435dc:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015435e0:     	add	x9, x9, #0x1a8
1015435e4:     	stp	x8, x9, [x23, #0x8]
1015435e8:     	mov	w8, #0x17               ; =23
1015435ec:     	str	x8, [x23, #0x18]
1015435f0:     	b	0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
1015435f4:     	ldur	q0, [x27, #0x15]
1015435f8:     	stur	q0, [x19, #0x15]
1015435fc:     	ldur	q0, [x27, #0x25]
101543600:     	stur	q0, [x19, #0x25]
101543604:     	ldur	q0, [x27, #0x35]
101543608:     	stur	q0, [x19, #0x35]
10154360c:     	ldr	q0, [sp, #0x590]
101543610:     	str	q0, [x19, #0x40]
101543614:     	ldur	q0, [x27, #0x5]
101543618:     	stur	q0, [x19, #0x5]
10154361c:     	str	w9, [x19]
101543620:     	strb	w8, [x19, #0x4]
101543624:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543628:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10154362c:     	add	x3, x3, #0xb58
101543630:     	mov	x0, #0x0                ; =0
101543634:     	bl	0x103a02658 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101543638:     	b	0x1015445c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41f0>
10154363c:     	str	wzr, [x28]
101543640:     	mov	w8, #0xc                ; =12
101543644:     	strb	w8, [x28, #0x8]
101543648:     	adrp	x8, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
10154364c:     	add	x8, x8, #0x2ad
101543650:     	mov	w9, #0x2c               ; =44
101543654:     	b	0x10154357c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31a8>
101543658:     	ldr	x8, [sp, #0x58]
10154365c:     	ldr	x9, [x8, #0x490]
101543660:     	ldr	x8, [sp, #0x30]
101543664:     	lsl	x8, x8, #3
101543668:     	add	x0, sp, #0x550
10154366c:     	str	x9, [sp, #0x20]
101543670:     	add	x1, x9, #0x2f8
101543674:     	add	x4, x8, #0x1, lsl #12   ; =0x1000
101543678:     	mov	w2, #0x0                ; =0
10154367c:     	bl	0x1015293e0 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101543680:     	ldrb	w8, [sp, #0x550]
101543684:     	cmp	w8, #0xe
101543688:     	b.ne	0x1015437e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x340c>
10154368c:     	add	x8, sp, #0x550
101543690:     	add	x0, sp, #0x668
101543694:     	ldr	x1, [sp, #0x30]
101543698:     	bl	0x102d50dfc <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
10154369c:     	ldr	w8, [sp, #0x550]
1015436a0:     	cmp	w8, #0x1a
1015436a4:     	b.ne	0x101543904 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3530>
1015436a8:     	ldur	q0, [x27, #0x8]
1015436ac:     	ldur	q1, [x27, #0x18]
1015436b0:     	str	q0, [sp, #0x680]
1015436b4:     	str	q1, [sp, #0x690]
1015436b8:     	add	x8, sp, #0x550
1015436bc:     	mov	x0, x20
1015436c0:     	ldr	x1, [sp, #0x50]
1015436c4:     	ldr	x2, [sp, #0x38]
1015436c8:     	bl	0x1015d943c <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel15scheduler_nodes>
1015436cc:     	ldr	w8, [sp, #0x550]
1015436d0:     	cmp	w8, #0x6
1015436d4:     	b.ne	0x101543940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x356c>
1015436d8:     	ldr	x1, [sp, #0x558]
1015436dc:     	add	x8, sp, #0x440
1015436e0:     	add	x0, sp, #0x668
1015436e4:     	bl	0x102d50cd0 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
1015436e8:     	ldr	w8, [sp, #0x440]
1015436ec:     	cmp	w8, #0x1a
1015436f0:     	b.ne	0x1015439a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35d4>
1015436f4:     	add	x8, sp, #0x440
1015436f8:     	ldur	q0, [x8, #0x8]
1015436fc:     	ldur	q1, [x8, #0x18]
101543700:     	str	q0, [sp, #0x6a0]
101543704:     	str	q1, [sp, #0x6b0]
101543708:     	ldr	x8, [sp, #0x50]
10154370c:     	cbnz	x8, 0x101543a70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x369c>
101543710:     	mov	w8, #0x8                ; =8
101543714:     	str	xzr, [sp, #0x6c0]
101543718:     	str	x8, [sp, #0x6c8]
10154371c:     	str	xzr, [sp, #0x6d0]
101543720:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
101543724:     	ldr	q0, [x8, #0x80]
101543728:     	stur	q0, [x23, #0x8]
10154372c:     	mov	w8, #0x6                ; =6
101543730:     	str	w8, [x23]
101543734:     	add	x0, sp, #0x6c0
101543738:     	bl	0x101523b4c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
10154373c:     	add	x0, sp, #0x6a0
101543740:     	bl	0x101524b70 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101543744:     	b	0x1015439c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f0>
101543748:     	mov	w19, #0x0               ; =0
10154374c:     	ldur	q0, [x24, #0x8]
101543750:     	ldur	q1, [x24, #0x18]
101543754:     	ldur	q2, [x24, #0x28]
101543758:     	ldur	q3, [x24, #0x38]
10154375c:     	ldur	x8, [x24, #0x48]
101543760:     	stur	x8, [x27, #0x44]
101543764:     	stur	q0, [x27, #0x4]
101543768:     	stur	q1, [x27, #0x14]
10154376c:     	stur	q2, [x27, #0x24]
101543770:     	stur	q3, [x27, #0x34]
101543774:     	ldr	q0, [sp, #0x570]
101543778:     	ldr	q1, [sp, #0x580]
10154377c:     	str	q0, [sp, #0x410]
101543780:     	str	q1, [sp, #0x420]
101543784:     	ldur	q0, [x27, #0x3c]
101543788:     	stur	q0, [x26, #0xfc]
10154378c:     	ldr	q0, [sp, #0x560]
101543790:     	ldr	q1, [sp, #0x550]
101543794:     	stp	q1, q0, [sp, #0x3f0]
101543798:     	ldp	q0, q1, [sp, #0x3f0]
10154379c:     	ldur	q2, [x26, #0xfc]
1015437a0:     	stur	q2, [x26, #0xac]
1015437a4:     	ldr	q2, [sp, #0x410]
1015437a8:     	ldr	q3, [sp, #0x420]
1015437ac:     	stp	q2, q3, [sp, #0x3c0]
1015437b0:     	stp	q0, q1, [sp, #0x3a0]
1015437b4:     	ldp	q1, q0, [sp, #0x3a0]
1015437b8:     	stur	q0, [x28, #0x14]
1015437bc:     	ldp	q0, q2, [sp, #0x3c0]
1015437c0:     	stur	q0, [x28, #0x24]
1015437c4:     	stur	q2, [x28, #0x34]
1015437c8:     	ldur	q0, [x26, #0xac]
1015437cc:     	str	q0, [x28, #0x40]
1015437d0:     	stur	q1, [x28, #0x4]
1015437d4:     	mov	w8, #0x5                ; =5
1015437d8:     	str	w8, [x28]
1015437dc:     	b	0x1015432f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f1c>
1015437e0:     	ldr	q0, [sp, #0x550]
1015437e4:     	ldr	q1, [sp, #0x560]
1015437e8:     	str	q0, [sp, #0x440]
1015437ec:     	str	q1, [sp, #0x450]
1015437f0:     	ldr	q2, [sp, #0x570]
1015437f4:     	str	q2, [sp, #0x460]
1015437f8:     	ldr	x8, [sp, #0x580]
1015437fc:     	str	x8, [sp, #0x470]
101543800:     	stur	q0, [x27, #0x4]
101543804:     	stur	q1, [x27, #0x14]
101543808:     	stur	q2, [x27, #0x24]
10154380c:     	stur	x8, [x27, #0x34]
101543810:     	str	wzr, [x23]
101543814:     	ldr	q0, [sp, #0x550]
101543818:     	ldr	q1, [sp, #0x560]
10154381c:     	stur	q0, [x23, #0x4]
101543820:     	stur	q1, [x23, #0x14]
101543824:     	ldr	q0, [sp, #0x570]
101543828:     	stur	q0, [x23, #0x24]
10154382c:     	ldur	q0, [x27, #0x2c]
101543830:     	str	q0, [x23, #0x30]
101543834:     	b	0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
101543838:     	ldr	q0, [sp, #0x570]
10154383c:     	ldr	q1, [sp, #0x580]
101543840:     	stp	q0, q1, [x19, #0x20]
101543844:     	ldr	q0, [sp, #0x590]
101543848:     	str	q0, [x19, #0x40]
10154384c:     	ldr	q0, [sp, #0x560]
101543850:     	ldr	q1, [sp, #0x550]
101543854:     	stp	q1, q0, [x19]
101543858:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154385c:     	ldur	w9, [x27, #0x1]
101543860:     	stur	w9, [x19, #0x9]
101543864:     	ldr	w9, [sp, #0x554]
101543868:     	str	w9, [x19, #0xc]
10154386c:     	ldr	q0, [sp, #0x570]
101543870:     	stur	q0, [x19, #0x28]
101543874:     	ldr	x9, [sp, #0x580]
101543878:     	str	x9, [x19, #0x38]
10154387c:     	ldr	d0, [sp, #0x568]
101543880:     	ldur	q1, [x27, #0x8]
101543884:     	mov	w9, #0x2                ; =2
101543888:     	str	w9, [x19]
10154388c:     	strb	w8, [x19, #0x8]
101543890:     	str	q1, [x19, #0x10]
101543894:     	str	d0, [x19, #0x20]
101543898:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154389c:     	mov	w19, #0x0               ; =0
1015438a0:     	ldr	q0, [sp, #0x570]
1015438a4:     	ldr	q1, [sp, #0x580]
1015438a8:     	stp	q0, q1, [x28, #0x20]
1015438ac:     	ldr	q0, [sp, #0x590]
1015438b0:     	str	q0, [x28, #0x40]
1015438b4:     	ldr	q0, [sp, #0x560]
1015438b8:     	ldr	q1, [sp, #0x550]
1015438bc:     	stp	q1, q0, [x28]
1015438c0:     	b	0x1015432f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f1c>
1015438c4:     	str	wzr, [x28]
1015438c8:     	mov	w8, #0xc                ; =12
1015438cc:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015438d0:     	add	x9, x9, #0x25d
1015438d4:     	stp	x8, x9, [x28, #0x8]
1015438d8:     	mov	w8, #0x2a               ; =42
1015438dc:     	str	x8, [x28, #0x18]
1015438e0:     	b	0x101542bf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2820>
1015438e4:     	str	wzr, [x28]
1015438e8:     	mov	w8, #0xc                ; =12
1015438ec:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015438f0:     	add	x9, x9, #0x287
1015438f4:     	stp	x8, x9, [x28, #0x8]
1015438f8:     	mov	w8, #0x26               ; =38
1015438fc:     	str	x8, [x28, #0x18]
101543900:     	b	0x101542bf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2820>
101543904:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
101543908:     	ldr	q0, [x8, #0x80]
10154390c:     	stur	q0, [x23, #0x8]
101543910:     	mov	w8, #0x6                ; =6
101543914:     	str	w8, [x23]
101543918:     	add	x0, sp, #0x550
10154391c:     	bl	0x1015233cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
101543920:     	b	0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
101543924:     	str	wzr, [x21]
101543928:     	mov	w9, #0xc                ; =12
10154392c:     	str	x9, [x21, #0x8]
101543930:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101543934:     	add	x8, x8, #0xd9d
101543938:     	mov	w9, #0x1e               ; =30
10154393c:     	b	0x101542b40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x276c>
101543940:     	ldr	w9, [sp, #0x554]
101543944:     	ldr	x10, [sp, #0x558]
101543948:     	ldr	q0, [sp, #0x560]
10154394c:     	ldr	q1, [sp, #0x570]
101543950:     	stp	q0, q1, [x23, #0x10]
101543954:     	ldr	q0, [sp, #0x580]
101543958:     	ldr	q1, [sp, #0x590]
10154395c:     	stp	q0, q1, [x23, #0x30]
101543960:     	stp	w8, w9, [x23]
101543964:     	str	x10, [x23, #0x8]
101543968:     	b	0x1015439c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f0>
10154396c:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101543970:     	add	x2, x2, #0xb40
101543974:     	mov	x0, x8
101543978:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154397c:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543980:     	add	x2, x2, #0x9a0
101543984:     	mov	x0, x19
101543988:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154398c:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543990:     	add	x2, x2, #0x760
101543994:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543998:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154399c:     	add	x2, x2, #0x808
1015439a0:     	mov	x0, x19
1015439a4:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015439a8:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
1015439ac:     	ldr	q0, [x8, #0x80]
1015439b0:     	stur	q0, [x23, #0x8]
1015439b4:     	mov	w8, #0x6                ; =6
1015439b8:     	str	w8, [x23]
1015439bc:     	add	x0, sp, #0x440
1015439c0:     	bl	0x1015232f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
1015439c4:     	add	x0, sp, #0x680
1015439c8:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015439cc:     	ldr	x8, [sp, #0x668]
1015439d0:     	mov	x9, #-0x1               ; =-1
1015439d4:     	ldaddl	x9, x8, [x8]
1015439d8:     	cmp	x8, #0x1
1015439dc:     	b.ne	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015439e0:     	dmb	ishld
1015439e4:     	add	x0, sp, #0x668
1015439e8:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015439ec:     	b	0x1015406a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015439f0:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
1015439f4:     	add	x2, x2, #0x960
1015439f8:     	ldr	x0, [sp, #0x50]
1015439fc:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543a00:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101543a04:     	add	x2, x2, #0x978
101543a08:     	ldr	x0, [sp, #0x50]
101543a0c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543a10:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543a14:     	add	x2, x2, #0x820
101543a18:     	mov	x0, x1
101543a1c:     	mov	x1, x8
101543a20:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543a24:     	ldr	w5, [x25, #0x130]
101543a28:     	mov	x0, x19
101543a2c:     	ldr	x1, [sp, #0x58]
101543a30:     	mov	x2, x20
101543a34:     	mov	x3, x23
101543a38:     	mov	x4, x22
101543a3c:     	mov	x6, x21
101543a40:     	mov	x7, x22
101543a44:     	add	sp, sp, #0x810
101543a48:     	ldp	x29, x30, [sp, #0x50]
101543a4c:     	ldp	x20, x19, [sp, #0x40]
101543a50:     	ldp	x22, x21, [sp, #0x30]
101543a54:     	ldp	x24, x23, [sp, #0x20]
101543a58:     	ldp	x26, x25, [sp, #0x10]
101543a5c:     	ldp	x28, x27, [sp], #0x60
101543a60:     	b	0x10152fd34 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call>
101543a64:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543a68:     	add	x2, x2, #0x7d8
101543a6c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543a70:     	add	x0, sp, #0x550
101543a74:     	mov	x1, #0x0                ; =0
101543a78:     	mov	w2, #0x8                ; =8
101543a7c:     	ldr	x3, [sp, #0x50]
101543a80:     	mov	w4, #0x8                ; =8
101543a84:     	mov	w5, #0x68               ; =104
101543a88:     	bl	0x1039dca0c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
101543a8c:     	ldr	w8, [sp, #0x550]
101543a90:     	tbz	w8, #0x0, 0x101543ac4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36f0>
101543a94:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101543a98:     	add	x8, x8, #0xbc6
101543a9c:     	mov	w9, #0xc                ; =12
101543aa0:     	stp	x9, x8, [x23, #0x8]
101543aa4:     	mov	w8, #0x1a               ; =26
101543aa8:     	str	x8, [x23, #0x18]
101543aac:     	str	wzr, [x23]
101543ab0:     	b	0x10154373c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3368>
101543ab4:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101543ab8:     	add	x2, x2, #0x990
101543abc:     	ldr	x1, [sp, #0x28]
101543ac0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543ac4:     	str	xzr, [sp]
101543ac8:     	str	xzr, [sp, #0x18]
101543acc:     	ldr	x8, [sp, #0x558]
101543ad0:     	ldr	x9, [sp, #0x50]
101543ad4:     	str	x9, [sp, #0x6c0]
101543ad8:     	str	x8, [sp, #0x6c8]
101543adc:     	str	xzr, [sp, #0x6d0]
101543ae0:     	ldr	x8, [sp, #0x48]
101543ae4:     	ldr	w9, [x8], #0x4
101543ae8:     	str	x8, [sp, #0x48]
101543aec:     	ldr	x8, [sp, #0x660]
101543af0:     	ldr	x1, [x8, #0x5a0]
101543af4:     	str	x9, [sp, #0x38]
101543af8:     	cmp	x1, x9
101543afc:     	b.ls	0x101544590 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41bc>
101543b00:     	ldr	x8, [x8, #0x598]
101543b04:     	mov	w9, #0x58               ; =88
101543b08:     	ldr	x10, [sp, #0x38]
101543b0c:     	umaddl	x8, w10, w9, x8
101543b10:     	str	x8, [sp, #0x30]
101543b14:     	ldr	w1, [x8, #0x50]
101543b18:     	add	x8, sp, #0x550
101543b1c:     	ldr	x9, [sp, #0x20]
101543b20:     	add	x0, x9, #0xf0
101543b24:     	add	x2, x9, #0x2f8
101543b28:     	bl	0x10163723c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101543b2c:     	ldr	x8, [sp, #0x550]
101543b30:     	add	x9, sp, #0x550
101543b34:     	ldur	q0, [x9, #0x8]
101543b38:     	ldur	q1, [x9, #0x18]
101543b3c:     	stp	q0, q1, [sp, #0x3f0]
101543b40:     	ldur	q0, [x9, #0x28]
101543b44:     	str	q0, [sp, #0x410]
101543b48:     	ldur	x9, [x9, #0x38]
101543b4c:     	str	x9, [sp, #0x420]
101543b50:     	cbz	x8, 0x101543de8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a14>
101543b54:     	ldr	x9, [sp, #0x420]
101543b58:     	add	x10, sp, #0x220
101543b5c:     	stur	x9, [x10, #0x38]
101543b60:     	ldr	q0, [sp, #0x410]
101543b64:     	stur	q0, [x10, #0x28]
101543b68:     	ldp	q1, q0, [sp, #0x3f0]
101543b6c:     	stur	q0, [x10, #0x18]
101543b70:     	stur	q1, [x10, #0x8]
101543b74:     	str	x8, [sp, #0x220]
101543b78:     	ldr	x8, [sp, #0x228]
101543b7c:     	ldr	x8, [x8, #0x10]
101543b80:     	ldrb	w8, [x8, #0x10]
101543b84:     	orr	w8, w8, #0x2
101543b88:     	cmp	w8, #0x1b
101543b8c:     	b.ne	0x10154409c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cc8>
101543b90:     	add	x8, sp, #0x550
101543b94:     	add	x0, sp, #0x220
101543b98:     	bl	0x1015a469c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections12source_count>
101543b9c:     	ldr	w8, [sp, #0x550]
101543ba0:     	cmp	w8, #0x6
101543ba4:     	b.ne	0x101543e30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a5c>
101543ba8:     	ldr	x8, [sp, #0x558]
101543bac:     	str	x8, [sp, #0x50]
101543bb0:     	ldr	x8, [sp, #0x38]
101543bb4:     	cmp	x19, x8
101543bb8:     	b.ne	0x101543bc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37f4>
101543bbc:     	ldr	x8, [sp, #0x50]
101543bc0:     	cmp	x8, x28
101543bc4:     	b.ne	0x101543e5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a88>
101543bc8:     	ldr	x8, [sp, #0x18]
101543bcc:     	ldr	x9, [sp, #0x50]
101543bd0:     	adds	x8, x9, x8
101543bd4:     	str	x8, [sp, #0x18]
101543bd8:     	b.hs	0x1015441f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e1c>
101543bdc:     	ldr	x8, [sp, #0x50]
101543be0:     	cbz	x8, 0x101543e78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3aa4>
101543be4:     	ldr	x8, [sp, #0x18]
101543be8:     	cmp	x8, x20
101543bec:     	b.hi	0x101543e78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3aa4>
101543bf0:     	ldr	x8, [sp, #0x30]
101543bf4:     	ldr	x8, [x8, #0x8]
101543bf8:     	str	x8, [sp, #0x8]
101543bfc:     	cbnz	x8, 0x101543c70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x389c>
101543c00:     	str	xzr, [sp]
101543c04:     	ldr	x9, [sp, #0x8]
101543c08:     	mov	w8, #0x8                ; =8
101543c0c:     	stp	x9, x8, [sp, #0x110]
101543c10:     	str	xzr, [sp, #0x120]
101543c14:     	ldp	q0, q1, [sp, #0x220]
101543c18:     	add	x8, sp, #0x550
101543c1c:     	stur	q0, [x8, #0x18]
101543c20:     	stur	q1, [x8, #0x28]
101543c24:     	ldp	q0, q1, [sp, #0x240]
101543c28:     	stur	q0, [x8, #0x38]
101543c2c:     	stur	q1, [x8, #0x48]
101543c30:     	ldr	q0, [sp, #0x110]
101543c34:     	str	q0, [sp, #0x550]
101543c38:     	ldr	x8, [sp, #0x120]
101543c3c:     	str	x8, [sp, #0x560]
101543c40:     	ldr	x8, [sp, #0x38]
101543c44:     	str	x8, [sp, #0x5a8]
101543c48:     	ldr	x8, [sp, #0x50]
101543c4c:     	str	x8, [sp, #0x5b0]
101543c50:     	add	x0, sp, #0x6c0
101543c54:     	add	x1, sp, #0x550
101543c58:     	bl	0x101547f90 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionE8push_mutBR_>
101543c5c:     	ldr	x8, [sp, #0x48]
101543c60:     	ldr	x9, [sp, #0x28]
101543c64:     	cmp	x8, x9
101543c68:     	b.ne	0x101543ae0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x370c>
101543c6c:     	b	0x101543e90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3abc>
101543c70:     	ldr	x8, [sp, #0x30]
101543c74:     	ldr	x8, [x8]
101543c78:     	str	x8, [sp, #0x10]
101543c7c:     	add	x0, sp, #0x550
101543c80:     	mov	x1, #0x0                ; =0
101543c84:     	mov	w2, #0x8                ; =8
101543c88:     	ldr	x3, [sp, #0x8]
101543c8c:     	mov	w4, #0x8                ; =8
101543c90:     	mov	w5, #0x48               ; =72
101543c94:     	bl	0x1039dca0c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
101543c98:     	ldr	x8, [sp, #0x550]
101543c9c:     	cmp	x8, #0x1
101543ca0:     	b.eq	0x101544150 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d7c>
101543ca4:     	ldr	x8, [sp, #0x558]
101543ca8:     	ldr	x10, [sp, #0x8]
101543cac:     	and	x9, x10, #0x7fffffffffffff00
101543cb0:     	stp	x10, x8, [sp, #0x110]
101543cb4:     	str	xzr, [sp, #0x120]
101543cb8:     	lsl	x8, x10, #2
101543cbc:     	stp	x9, x8, [sp]
101543cc0:     	b	0x101543cf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3924>
101543cc4:     	ldr	x8, [x21, #0x28]
101543cc8:     	ldr	x9, [sp, #0x30]
101543ccc:     	ldr	x8, [x8, x9, lsl #3]
101543cd0:     	str	x8, [sp, #0x558]
101543cd4:     	str	w9, [sp, #0x554]
101543cd8:     	str	wzr, [sp, #0x550]
101543cdc:     	add	x0, sp, #0x110
101543ce0:     	add	x1, sp, #0x550
101543ce4:     	bl	0x101548024 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
101543ce8:     	ldr	x8, [sp, #0x8]
101543cec:     	subs	x8, x8, #0x4
101543cf0:     	str	x8, [sp, #0x8]
101543cf4:     	b.eq	0x101543c14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3840>
101543cf8:     	ldr	x8, [sp, #0x10]
101543cfc:     	ldr	w9, [x8], #0x4
101543d00:     	str	x8, [sp, #0x10]
101543d04:     	ldr	x8, [sp, #0x660]
101543d08:     	ldr	x1, [x8, #0x360]
101543d0c:     	str	x9, [sp, #0x30]
101543d10:     	cmp	x1, x9
101543d14:     	b.ls	0x1015445a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d0>
101543d18:     	ldr	x8, [x8, #0x358]
101543d1c:     	mov	w9, #0x140              ; =320
101543d20:     	ldr	x10, [sp, #0x30]
101543d24:     	umaddl	x8, w10, w9, x8
101543d28:     	ldrb	w8, [x8, #0x124]
101543d2c:     	cmp	w8, #0x7
101543d30:     	b.ne	0x101543cc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38f0>
101543d34:     	add	x8, sp, #0x440
101543d38:     	ldr	x9, [sp, #0x20]
101543d3c:     	add	x0, x9, #0xf0
101543d40:     	add	x2, x9, #0x2f8
101543d44:     	ldr	x1, [sp, #0x30]
101543d48:     	bl	0x10163723c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101543d4c:     	ldr	x8, [sp, #0x440]
101543d50:     	add	x9, sp, #0x440
101543d54:     	ldur	q0, [x9, #0x8]
101543d58:     	ldur	q1, [x9, #0x18]
101543d5c:     	stp	q0, q1, [sp, #0xa0]
101543d60:     	ldur	q0, [x9, #0x28]
101543d64:     	str	q0, [sp, #0xc0]
101543d68:     	ldur	x9, [x9, #0x38]
101543d6c:     	str	x9, [sp, #0xd0]
101543d70:     	cbz	x8, 0x101544048 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c74>
101543d74:     	ldp	q0, q1, [sp, #0xa0]
101543d78:     	add	x10, sp, #0x550
101543d7c:     	stp	q0, q1, [x10, #0x10]
101543d80:     	ldr	q0, [sp, #0xc0]
101543d84:     	stur	q0, [x10, #0x30]
101543d88:     	ldr	x9, [sp, #0xd0]
101543d8c:     	stur	x9, [x10, #0x40]
101543d90:     	str	x8, [sp, #0x558]
101543d94:     	ldr	x8, [sp, #0x30]
101543d98:     	str	w8, [sp, #0x554]
101543d9c:     	mov	w8, #0x1                ; =1
101543da0:     	str	w8, [sp, #0x550]
101543da4:     	add	x0, sp, #0x110
101543da8:     	add	x1, sp, #0x550
101543dac:     	bl	0x101548024 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
101543db0:     	b	0x101543ce8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3914>
101543db4:     	str	wzr, [x23]
101543db8:     	mov	w8, #0xc                ; =12
101543dbc:     	adrp	x9, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
101543dc0:     	add	x9, x9, #0x7d
101543dc4:     	b	0x101543dd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a04>
101543dc8:     	str	wzr, [x23]
101543dcc:     	mov	w8, #0xc                ; =12
101543dd0:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101543dd4:     	add	x9, x9, #0x18e
101543dd8:     	stp	x8, x9, [x23, #0x8]
101543ddc:     	mov	w8, #0x1a               ; =26
101543de0:     	str	x8, [x23, #0x18]
101543de4:     	b	0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
101543de8:     	ldp	q0, q1, [sp, #0x3f0]
101543dec:     	stur	q0, [x27, #0x4]
101543df0:     	stur	q1, [x27, #0x14]
101543df4:     	ldr	q0, [sp, #0x410]
101543df8:     	stur	q0, [x27, #0x24]
101543dfc:     	ldr	x8, [sp, #0x420]
101543e00:     	stur	x8, [x27, #0x34]
101543e04:     	ldr	q0, [sp, #0x550]
101543e08:     	ldr	q1, [sp, #0x560]
101543e0c:     	stur	q0, [x23, #0x4]
101543e10:     	mov	w8, #0x2                ; =2
101543e14:     	str	w8, [x23]
101543e18:     	stur	q1, [x23, #0x14]
101543e1c:     	ldr	q0, [sp, #0x570]
101543e20:     	stur	q0, [x23, #0x24]
101543e24:     	ldur	q0, [x27, #0x2c]
101543e28:     	str	q0, [x23, #0x30]
101543e2c:     	b	0x101543734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3360>
101543e30:     	ldr	w9, [sp, #0x554]
101543e34:     	ldr	x10, [sp, #0x558]
101543e38:     	ldr	q0, [sp, #0x560]
101543e3c:     	ldr	q1, [sp, #0x570]
101543e40:     	stp	q0, q1, [x23, #0x10]
101543e44:     	ldr	q0, [sp, #0x580]
101543e48:     	ldr	q1, [sp, #0x590]
101543e4c:     	stp	q0, q1, [x23, #0x30]
101543e50:     	stp	w8, w9, [x23]
101543e54:     	str	x10, [x23, #0x8]
101543e58:     	b	0x1015440b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ce4>
101543e5c:     	str	wzr, [x23]
101543e60:     	mov	w8, #0xc                ; =12
101543e64:     	strb	w8, [x23, #0x8]
101543e68:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101543e6c:     	add	x8, x8, #0xbfb
101543e70:     	mov	w9, #0x24               ; =36
101543e74:     	b	0x1015440b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ce0>
101543e78:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
101543e7c:     	ldr	q0, [x8, #0x80]
101543e80:     	stur	q0, [x23, #0x8]
101543e84:     	mov	w8, #0x6                ; =6
101543e88:     	str	w8, [x23]
101543e8c:     	b	0x1015440b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ce4>
101543e90:     	ldr	x8, [sp, #0x18]
101543e94:     	cmp	x8, #0x2
101543e98:     	b.lo	0x101543720 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x334c>
101543e9c:     	ldr	x8, [sp, #0x18]
101543ea0:     	str	x8, [sp, #0x6d8]
101543ea4:     	add	x8, x8, x8, lsl #5
101543ea8:     	lsl	x1, x8, #16
101543eac:     	add	x8, sp, #0x550
101543eb0:     	add	x0, sp, #0x668
101543eb4:     	bl	0x102d50dfc <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101543eb8:     	ldr	w8, [sp, #0x550]
101543ebc:     	cmp	w8, #0x1a
101543ec0:     	b.ne	0x1015440dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d08>
101543ec4:     	ldur	q0, [x27, #0x8]
101543ec8:     	ldur	q1, [x27, #0x18]
101543ecc:     	str	q0, [sp, #0x6e0]
101543ed0:     	str	q1, [sp, #0x6f0]
101543ed4:     	ldr	x20, [sp, #0x6d0]
101543ed8:     	cbnz	x20, 0x101544210 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e3c>
101543edc:     	mov	x8, #0x0                ; =0
101543ee0:     	mov	w9, #0x8                ; =8
101543ee4:     	str	x20, [sp, #0x708]
101543ee8:     	str	x9, [sp, #0x710]
101543eec:     	str	xzr, [sp, #0x718]
101543ef0:     	ldr	x1, [sp, #0x6c8]
101543ef4:     	mov	w9, #0x68               ; =104
101543ef8:     	madd	x2, x8, x9, x1
101543efc:     	mov	w19, #0x1               ; =1
101543f00:     	add	x0, sp, #0x708
101543f04:     	mov	w28, #0x1               ; =1
101543f08:     	bl	0x101498ab4 <__RINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENCNvMs0_B2f_NtB2h_10Invocation12run_parallels9_0EEB2p_>
101543f0c:     	ldr	x2, [sp, #0x710]
101543f10:     	ldr	x3, [sp, #0x718]
101543f14:     	add	x0, sp, #0x550
101543f18:     	ldr	x1, [sp, #0x58]
101543f1c:     	bl	0x101539ddc <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel9admissionNtB6_10Invocation18parallel_admission>
101543f20:     	ldr	w8, [sp, #0x550]
101543f24:     	cmp	w8, #0x6
101543f28:     	b.ne	0x1015440fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d28>
101543f2c:     	ldr	x8, [sp, #0x558]
101543f30:     	ldr	q0, [sp, #0x560]
101543f34:     	str	q0, [sp, #0x740]
101543f38:     	ldr	x9, [sp, #0x570]
101543f3c:     	str	x9, [sp, #0x750]
101543f40:     	cbz	x8, 0x101544174 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3da0>
101543f44:     	ldr	q0, [sp, #0x740]
101543f48:     	stur	q0, [x24, #0x8]
101543f4c:     	ldr	x9, [sp, #0x750]
101543f50:     	str	x8, [sp, #0x720]
101543f54:     	str	x9, [sp, #0x738]
101543f58:     	ldr	x0, [sp, #0x660]
101543f5c:     	add	x8, sp, #0x550
101543f60:     	add	x1, sp, #0x668
101543f64:     	ldr	x2, [sp, #0x18]
101543f68:     	bl	0x1015d951c <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel17worker_setup_fits>
101543f6c:     	ldr	w9, [sp, #0x550]
101543f70:     	ldrb	w8, [sp, #0x554]
101543f74:     	cmp	w9, #0x6
101543f78:     	b.ne	0x1015441a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3dd0>
101543f7c:     	tbz	w8, #0x0, 0x1015441d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e04>
101543f80:     	ldr	x8, [sp, #0x660]
101543f84:     	ldr	x1, [x8, #0x3a0]
101543f88:     	ldr	w0, [x22, #0x30]
101543f8c:     	cmp	x1, x0
101543f90:     	b.ls	0x1015445b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41e4>
101543f94:     	ldr	x8, [x8, #0x398]
101543f98:     	mov	w9, #0x540              ; =1344
101543f9c:     	umaddl	x8, w0, w9, x8
101543fa0:     	ldr	w9, [x8, #0x520]
101543fa4:     	ldr	q0, [x8, #0x510]
101543fa8:     	stur	q0, [x29, #-0x100]
101543fac:     	stur	w9, [x29, #-0xf0]
101543fb0:     	add	x8, sp, #0x550
101543fb4:     	ldr	x9, [sp, #0x20]
101543fb8:     	add	x0, x9, #0x3b8
101543fbc:     	bl	0x10236cbc4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101543fc0:     	ldr	x8, [sp, #0x550]
101543fc4:     	cmp	x8, #0x1
101543fc8:     	b.ne	0x101544264 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e90>
101543fcc:     	ldr	x1, [sp, #0x558]
101543fd0:     	ldr	x2, [sp, #0x560]
101543fd4:     	add	x19, sp, #0x550
101543fd8:     	add	x8, sp, #0x550
101543fdc:     	ldr	x9, [sp, #0x20]
101543fe0:     	add	x0, x9, #0x3b8
101543fe4:     	add	x3, sp, #0x668
101543fe8:     	bl	0x10236ef4c <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget32reserve_worker_group_with_memory>
101543fec:     	ldrb	w8, [sp, #0x588]
101543ff0:     	cmp	w8, #0x2
101543ff4:     	b.ne	0x1015442a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ed0>
101543ff8:     	ldr	w8, [sp, #0x550]
101543ffc:     	cmp	w8, #0x1a
101544000:     	b.ne	0x101544454 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4080>
101544004:     	ldur	w9, [x29, #-0x100]
101544008:     	ldurb	w8, [x29, #-0xfc]
10154400c:     	add	x12, sp, #0x720
101544010:     	ldur	w10, [x12, #0x45]
101544014:     	str	w10, [sp, #0x110]
101544018:     	ldur	w11, [x29, #-0xf8]
10154401c:     	add	x10, sp, #0x110
101544020:     	stur	w11, [x10, #0x3]
101544024:     	mov	w10, #0x4               ; =4
101544028:     	ldur	d0, [x12, #0x4c]
10154402c:     	b	0x101544460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x408c>
101544030:     	mov	w24, #0x1               ; =1
101544034:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101544038:     	add	x2, x2, #0x7f0
10154403c:     	mov	x0, x20
101544040:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101544044:     	b	0x1015445c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41f0>
101544048:     	ldp	q0, q1, [sp, #0xa0]
10154404c:     	add	x8, sp, #0x440
101544050:     	stur	q0, [x8, #0x4]
101544054:     	stur	q1, [x8, #0x14]
101544058:     	ldr	q0, [sp, #0xc0]
10154405c:     	stur	q0, [x8, #0x24]
101544060:     	ldr	x9, [sp, #0xd0]
101544064:     	stur	x9, [x8, #0x34]
101544068:     	ldr	q0, [sp, #0x440]
10154406c:     	ldr	q1, [sp, #0x450]
101544070:     	stur	q0, [x23, #0x4]
101544074:     	mov	w9, #0x2                ; =2
101544078:     	str	w9, [x23]
10154407c:     	stur	q1, [x23, #0x14]
101544080:     	ldr	q0, [sp, #0x460]
101544084:     	stur	q0, [x23, #0x24]
101544088:     	ldur	q0, [x8, #0x2c]
10154408c:     	str	q0, [x23, #0x30]
101544090:     	add	x0, sp, #0x110
101544094:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101544098:     	b	0x1015440b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ce4>
10154409c:     	str	wzr, [x23]
1015440a0:     	mov	w8, #0xc                ; =12
1015440a4:     	strb	w8, [x23, #0x8]
1015440a8:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
1015440ac:     	add	x8, x8, #0xc1f
1015440b0:     	mov	w9, #0x30               ; =48
1015440b4:     	stp	x8, x9, [x23, #0x10]
1015440b8:     	add	x0, sp, #0x220
1015440bc:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015440c0:     	b	0x101543734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3360>
1015440c4:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
1015440c8:     	add	x2, x2, #0x9a8
1015440cc:     	mov	x0, x1
1015440d0:     	ldr	x1, [sp, #0x28]
1015440d4:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015440d8:     	b	0x1015445c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41f0>
1015440dc:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
1015440e0:     	ldr	q0, [x8, #0x80]
1015440e4:     	stur	q0, [x23, #0x8]
1015440e8:     	mov	w8, #0x6                ; =6
1015440ec:     	str	w8, [x23]
1015440f0:     	add	x0, sp, #0x550
1015440f4:     	bl	0x1015233cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
1015440f8:     	b	0x101543734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3360>
1015440fc:     	ldr	w9, [sp, #0x554]
101544100:     	ldr	x10, [sp, #0x558]
101544104:     	ldr	q0, [sp, #0x560]
101544108:     	str	q0, [sp, #0x740]
10154410c:     	ldur	q1, [x27, #0x28]
101544110:     	stur	q1, [x23, #0x28]
101544114:     	ldur	q1, [x27, #0x38]
101544118:     	ldr	x11, [sp, #0x570]
10154411c:     	ldr	x12, [sp, #0x598]
101544120:     	str	x11, [sp, #0x750]
101544124:     	stur	q1, [x23, #0x38]
101544128:     	str	x12, [x23, #0x48]
10154412c:     	str	q0, [x23, #0x10]
101544130:     	str	x11, [x23, #0x20]
101544134:     	stp	w8, w9, [x23]
101544138:     	str	x10, [x23, #0x8]
10154413c:     	b	0x101544188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3db4>
101544140:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101544144:     	add	x2, x2, #0x730
101544148:     	mov	x0, x20
10154414c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101544150:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101544154:     	add	x8, x8, #0xbe0
101544158:     	ldr	x9, [sp]
10154415c:     	orr	x9, x9, #0xc
101544160:     	stp	x9, x8, [x23, #0x8]
101544164:     	mov	w8, #0x1b               ; =27
101544168:     	str	x8, [x23, #0x18]
10154416c:     	str	wzr, [x23]
101544170:     	b	0x1015440b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ce4>
101544174:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
101544178:     	ldr	q0, [x8, #0x80]
10154417c:     	stur	q0, [x23, #0x8]
101544180:     	mov	w8, #0x6                ; =6
101544184:     	str	w8, [x23]
101544188:     	ldr	x8, [sp, #0x708]
10154418c:     	cbz	x8, 0x101544b78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a4>
101544190:     	ldr	x0, [sp, #0x710]
101544194:     	lsl	x1, x8, #3
101544198:     	mov	w2, #0x8                ; =8
10154419c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015441a0:     	b	0x101544b78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a4>
1015441a4:     	ldur	q0, [x27, #0x15]
1015441a8:     	stur	q0, [x23, #0x15]
1015441ac:     	ldur	q0, [x27, #0x25]
1015441b0:     	stur	q0, [x23, #0x25]
1015441b4:     	ldur	q0, [x27, #0x35]
1015441b8:     	stur	q0, [x23, #0x35]
1015441bc:     	ldr	q0, [sp, #0x590]
1015441c0:     	str	q0, [x23, #0x40]
1015441c4:     	ldur	q0, [x27, #0x5]
1015441c8:     	stur	q0, [x23, #0x5]
1015441cc:     	str	w9, [x23]
1015441d0:     	strb	w8, [x23, #0x4]
1015441d4:     	b	0x101544b50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x477c>
1015441d8:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x283>
1015441dc:     	ldr	q0, [x8, #0x80]
1015441e0:     	stur	q0, [x23, #0x8]
1015441e4:     	mov	w8, #0x6                ; =6
1015441e8:     	str	w8, [x23]
1015441ec:     	b	0x101544b50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x477c>
1015441f0:     	str	wzr, [x23]
1015441f4:     	mov	w8, #0xc                ; =12
1015441f8:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015441fc:     	add	x9, x9, #0x1bf
101544200:     	stp	x8, x9, [x23, #0x8]
101544204:     	mov	w8, #0x1c               ; =28
101544208:     	str	x8, [x23, #0x18]
10154420c:     	b	0x1015440b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ce4>
101544210:     	add	x0, sp, #0x550
101544214:     	mov	x1, #0x0                ; =0
101544218:     	mov	w2, #0x8                ; =8
10154421c:     	mov	x3, x20
101544220:     	mov	w4, #0x8                ; =8
101544224:     	mov	w5, #0x8                ; =8
101544228:     	bl	0x1039dca0c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
10154422c:     	ldr	w8, [sp, #0x550]
101544230:     	tbz	w8, #0x0, 0x101544284 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3eb0>
101544234:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101544238:     	add	x8, x8, #0xc4f
10154423c:     	mov	w9, #0xc                ; =12
101544240:     	stp	x9, x8, [x23, #0x8]
101544244:     	mov	w8, #0x27               ; =39
101544248:     	str	x8, [x23, #0x18]
10154424c:     	str	wzr, [x23]
101544250:     	b	0x101544b78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a4>
101544254:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101544258:     	add	x2, x2, #0x700
10154425c:     	mov	x0, x20
101544260:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101544264:     	str	wzr, [x23]
101544268:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
10154426c:     	add	x8, x8, #0x21e
101544270:     	mov	w9, #0xc                ; =12
101544274:     	stp	x9, x8, [x23, #0x8]
101544278:     	mov	w8, #0x27               ; =39
10154427c:     	str	x8, [x23, #0x18]
101544280:     	b	0x101544b50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x477c>
101544284:     	ldr	x9, [sp, #0x558]
101544288:     	ldr	x8, [sp, #0x6d0]
10154428c:     	b	0x101543ee4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b10>
101544290:     	adrp	x8, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101544294:     	add	x8, x8, #0x718
101544298:     	mov	x0, x2
10154429c:     	mov	x2, x8
1015442a0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015442a4:     	ldrb	w8, [sp, #0x550]
1015442a8:     	ldr	w9, [sp, #0x554]
1015442ac:     	add	x12, sp, #0x720
1015442b0:     	stur	w9, [x12, #0xb3]
1015442b4:     	ldur	w9, [x27, #0x1]
1015442b8:     	stur	w9, [x29, #-0x90]
1015442bc:     	ldr	q0, [sp, #0x560]
1015442c0:     	ldr	q1, [sp, #0x570]
1015442c4:     	str	q0, [sp, #0x440]
1015442c8:     	str	q1, [sp, #0x450]
1015442cc:     	ldr	x10, [sp, #0x580]
1015442d0:     	ldr	x9, [sp, #0x588]
1015442d4:     	sub	x11, x29, #0xe0
1015442d8:     	str	x10, [sp, #0x460]
1015442dc:     	ldr	d0, [sp, #0x558]
1015442e0:     	ldur	w10, [x12, #0xb3]
1015442e4:     	stur	w10, [x12, #0x73]
1015442e8:     	ldur	w10, [x29, #-0x90]
1015442ec:     	stur	w10, [x29, #-0xd0]
1015442f0:     	ldr	q1, [sp, #0x440]
1015442f4:     	ldr	q2, [sp, #0x450]
1015442f8:     	ldr	x10, [sp, #0x460]
1015442fc:     	str	x10, [sp, #0x240]
101544300:     	stp	q1, q2, [sp, #0x220]
101544304:     	add	x20, sp, #0x720
101544308:     	ldur	w10, [x12, #0x73]
10154430c:     	str	w10, [sp, #0x334]
101544310:     	ldur	w10, [x29, #-0xd0]
101544314:     	stur	w10, [x26, #0x1]
101544318:     	ldp	q1, q2, [sp, #0x220]
10154431c:     	ldr	x10, [sp, #0x240]
101544320:     	stp	q1, q2, [sp, #0x340]
101544324:     	strb	w8, [sp, #0x330]
101544328:     	str	d0, [sp, #0x338]
10154432c:     	str	x10, [sp, #0x360]
101544330:     	str	x9, [sp, #0x368]
101544334:     	ldr	x8, [sp, #0x58]
101544338:     	add	x9, x8, #0x4e8
10154433c:     	ldr	q0, [x9]
101544340:     	stur	q0, [x27, #0xa8]
101544344:     	ldr	x9, [x8, #0x4f8]
101544348:     	ldp	q0, q1, [x8, #0x80]
10154434c:     	str	q0, [sp, #0x5d0]
101544350:     	str	q1, [sp, #0x5e0]
101544354:     	ldr	x10, [x8, #0xa0]
101544358:     	str	x9, [sp, #0x608]
10154435c:     	str	x10, [sp, #0x5f0]
101544360:     	ldp	q0, q1, [x8, #0x40]
101544364:     	str	q0, [sp, #0x590]
101544368:     	str	q1, [sp, #0x5a0]
10154436c:     	ldp	q1, q0, [x8, #0x60]
101544370:     	str	q0, [sp, #0x5c0]
101544374:     	str	q1, [sp, #0x5b0]
101544378:     	ldp	q0, q1, [x8]
10154437c:     	str	q0, [sp, #0x550]
101544380:     	str	q1, [sp, #0x560]
101544384:     	ldp	q1, q0, [x8, #0x20]
101544388:     	str	q0, [sp, #0x580]
10154438c:     	str	q1, [sp, #0x570]
101544390:     	ldr	x8, [sp, #0x40]
101544394:     	stp	x8, xzr, [x29, #-0xe8]
101544398:     	stur	xzr, [x29, #-0xd8]
10154439c:     	add	x8, sp, #0x6d8
1015443a0:     	add	x9, sp, #0x6c0
1015443a4:     	str	x8, [sp, #0x440]
1015443a8:     	str	x9, [sp, #0x448]
1015443ac:     	add	x8, sp, #0x330
1015443b0:     	add	x9, sp, #0x668
1015443b4:     	str	x8, [sp, #0x450]
1015443b8:     	str	x9, [sp, #0x458]
1015443bc:     	sub	x8, x29, #0x100
1015443c0:     	str	x11, [sp, #0x468]
1015443c4:     	add	x9, sp, #0x660
1015443c8:     	str	x8, [sp, #0x460]
1015443cc:     	str	x9, [sp, #0x470]
1015443d0:     	sub	x8, x29, #0xe8
1015443d4:     	add	x9, sp, #0x550
1015443d8:     	str	x8, [sp, #0x478]
1015443dc:     	str	x9, [sp, #0x480]
1015443e0:     	adrp	x1, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015443e4:     	add	x1, x1, #0x7c0
1015443e8:     	add	x8, sp, #0x110
1015443ec:     	add	x0, sp, #0x440
1015443f0:     	bl	0x1015fec54 <__RINvNtNtCsgirOGyZpP7g_3std6thread6scoped5scopeNCNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallelNtBS_10Invocation12run_parallelsc_0INtNtCsgDHHaSskbIF_4core6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIB2P_NtBQ_7ReceiptNtBU_27NativeProgramExecutionErrorEEB4f_EEB10_>
1015443f4:     	ldp	q0, q1, [sp, #0x330]
1015443f8:     	str	q0, [sp, #0x440]
1015443fc:     	str	q1, [sp, #0x450]
101544400:     	ldp	q0, q1, [sp, #0x350]
101544404:     	str	q0, [sp, #0x460]
101544408:     	str	q1, [sp, #0x470]
10154440c:     	mov	w19, #0x1               ; =1
101544410:     	add	x8, sp, #0x220
101544414:     	add	x0, sp, #0x440
101544418:     	bl	0x102370640 <__RNvMs4_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_15NativeWorkGroup29finish_with_credit_statistics>
10154441c:     	ldr	w8, [sp, #0x220]
101544420:     	tbz	w8, #0x0, 0x1015444dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4108>
101544424:     	ldr	x8, [sp, #0x238]
101544428:     	ldr	q0, [sp, #0x240]
10154442c:     	str	q0, [x23, #0x30]
101544430:     	ldur	w10, [x29, #-0x100]
101544434:     	ldur	q0, [x25, #0x8]
101544438:     	mov	w11, #0x4               ; =4
10154443c:     	stp	w11, w10, [x23]
101544440:     	ldur	q1, [x20, #0x44]
101544444:     	stur	q1, [x23, #0x8]
101544448:     	stur	q0, [x23, #0x18]
10154444c:     	mov	w9, #0x28               ; =40
101544450:     	b	0x101544614 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4240>
101544454:     	mov	w10, #0x0               ; =0
101544458:     	ldr	d0, [sp, #0x550]
10154445c:     	mov	w8, #0xd                ; =13
101544460:     	add	x11, sp, #0x110
101544464:     	ldur	w11, [x11, #0x3]
101544468:     	add	x13, sp, #0x720
10154446c:     	stur	w11, [x13, #0xb3]
101544470:     	ldr	w11, [sp, #0x110]
101544474:     	stur	w11, [x29, #-0x90]
101544478:     	ldur	q1, [x19, #0x8]
10154447c:     	ldur	q2, [x19, #0x18]
101544480:     	str	q1, [sp, #0x440]
101544484:     	str	q2, [sp, #0x450]
101544488:     	ldur	x11, [x19, #0x28]
10154448c:     	str	x11, [sp, #0x460]
101544490:     	ldur	w12, [x13, #0xb3]
101544494:     	stur	w12, [x13, #0x73]
101544498:     	ldur	w12, [x29, #-0x90]
10154449c:     	stur	w12, [x29, #-0xd0]
1015444a0:     	str	x11, [sp, #0x240]
1015444a4:     	stp	q1, q2, [sp, #0x220]
1015444a8:     	stur	w12, [x23, #0x9]
1015444ac:     	ldur	w11, [x13, #0x73]
1015444b0:     	str	w11, [x23, #0xc]
1015444b4:     	ldp	q1, q2, [sp, #0x220]
1015444b8:     	stur	q1, [x23, #0x18]
1015444bc:     	stur	q2, [x23, #0x28]
1015444c0:     	ldr	x11, [sp, #0x240]
1015444c4:     	str	x11, [x23, #0x38]
1015444c8:     	stp	w10, w9, [x23]
1015444cc:     	strb	w8, [x23, #0x8]
1015444d0:     	mov	w19, #0x1               ; =1
1015444d4:     	str	d0, [x23, #0x10]
1015444d8:     	b	0x101544b50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x477c>
1015444dc:     	ldr	x8, [sp, #0x238]
1015444e0:     	ldr	x9, [sp, #0x20]
1015444e4:     	ldr	x9, [x9, #0x418]
1015444e8:     	adds	x9, x9, x8
1015444ec:     	b.hs	0x1015445c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41f4>
1015444f0:     	ldr	x10, [sp, #0x240]
1015444f4:     	ldr	x8, [sp, #0x248]
1015444f8:     	ldr	x11, [sp, #0x20]
1015444fc:     	str	x9, [x11, #0x418]
101544500:     	ldr	x9, [x11, #0x420]
101544504:     	adds	x9, x9, x10
101544508:     	b.hs	0x1015445dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4208>
10154450c:     	ldr	x10, [sp, #0x20]
101544510:     	str	x9, [x10, #0x420]
101544514:     	ldr	x9, [x10, #0x428]
101544518:     	adds	x8, x9, x8
10154451c:     	b.hs	0x1015445f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4224>
101544520:     	ldr	x9, [sp, #0x20]
101544524:     	str	x8, [x9, #0x428]
101544528:     	ldr	q0, [sp, #0x6e0]
10154452c:     	ldr	q1, [sp, #0x6f0]
101544530:     	str	q0, [sp, #0x440]
101544534:     	str	q1, [sp, #0x450]
101544538:     	mov	w19, #0x0               ; =0
10154453c:     	add	x0, sp, #0x440
101544540:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544544:     	ldr	w8, [sp, #0x110]
101544548:     	cmp	w8, #0x6
10154454c:     	b.ne	0x101544624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4250>
101544550:     	mov	x9, #0x0                ; =0
101544554:     	add	x8, sp, #0x110
101544558:     	ldur	q0, [x8, #0x8]
10154455c:     	stur	q0, [x29, #-0xd0]
101544560:     	ldr	x8, [sp, #0x128]
101544564:     	stur	x8, [x29, #-0xc0]
101544568:     	ldur	x20, [x29, #-0xc8]
10154456c:     	mov	w10, #0xc8              ; =200
101544570:     	mul	x10, x8, x10
101544574:     	add	x21, x20, x10
101544578:     	cmp	x10, x9
10154457c:     	b.eq	0x101544648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4274>
101544580:     	ldr	x11, [x20, x9]
101544584:     	add	x9, x9, #0xc8
101544588:     	cbz	x11, 0x101544578 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41a4>
10154458c:     	b	0x1015446a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42d0>
101544590:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101544594:     	add	x2, x2, #0x778
101544598:     	ldr	x0, [sp, #0x38]
10154459c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015445a0:     	b	0x1015445c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41f0>
1015445a4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015445a8:     	add	x2, x2, #0x790
1015445ac:     	ldr	x0, [sp, #0x30]
1015445b0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015445b4:     	b	0x1015445c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41f0>
1015445b8:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015445bc:     	add	x2, x2, #0x7a8
1015445c0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015445c4:     	brk	#0x1
1015445c8:     	str	wzr, [x23]
1015445cc:     	mov	w9, #0xc                ; =12
1015445d0:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015445d4:     	add	x10, x10, #0x245
1015445d8:     	b	0x1015445ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4218>
1015445dc:     	str	wzr, [x23]
1015445e0:     	mov	w9, #0xc                ; =12
1015445e4:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015445e8:     	add	x10, x10, #0x26e
1015445ec:     	stp	x9, x10, [x23, #0x8]
1015445f0:     	mov	w8, #0x29               ; =41
1015445f4:     	b	0x101544610 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x423c>
1015445f8:     	str	wzr, [x23]
1015445fc:     	mov	w9, #0xc                ; =12
101544600:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101544604:     	add	x10, x10, #0x297
101544608:     	stp	x9, x10, [x23, #0x8]
10154460c:     	mov	w8, #0x2b               ; =43
101544610:     	mov	w9, #0x18               ; =24
101544614:     	str	x8, [x23, x9]
101544618:     	add	x0, sp, #0x110
10154461c:     	bl	0x101523134 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
101544620:     	b	0x101544b50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x477c>
101544624:     	ldp	q0, q1, [sp, #0x140]
101544628:     	stp	q0, q1, [x23, #0x30]
10154462c:     	add	x9, sp, #0x110
101544630:     	ldur	q0, [x9, #0x4]
101544634:     	stur	q0, [x23, #0x4]
101544638:     	ldp	q1, q0, [sp, #0x120]
10154463c:     	stp	q1, q0, [x23, #0x10]
101544640:     	str	w8, [x23]
101544644:     	b	0x101544b4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4778>
101544648:     	ldr	x9, [sp, #0x20]
10154464c:     	ldr	x9, [x9, #0x440]
101544650:     	cmn	x9, #0x1
101544654:     	b.eq	0x1015448a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44d4>
101544658:     	add	x9, x9, #0x1
10154465c:     	ldr	x10, [sp, #0x20]
101544660:     	str	x9, [x10, #0x440]
101544664:     	ldr	x9, [x10, #0x438]
101544668:     	ldr	x10, [sp, #0x6d0]
10154466c:     	adds	x9, x10, x9
101544670:     	b.hs	0x1015448a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44d4>
101544674:     	ldp	x10, x11, [sp, #0x18]
101544678:     	str	x9, [x11, #0x438]
10154467c:     	ldr	x9, [x11, #0x448]
101544680:     	adds	x9, x9, x10
101544684:     	b.hs	0x1015448b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44e0>
101544688:     	ldr	x11, [sp, #0x20]
10154468c:     	str	x9, [x11, #0x448]
101544690:     	ldr	x9, [x11, #0x450]
101544694:     	ldur	x10, [x29, #-0xd8]
101544698:     	cmp	x10, x9
10154469c:     	csel	x9, x10, x9, hi
1015446a0:     	str	x9, [x11, #0x450]
1015446a4:     	mov	w9, #0xc8               ; =200
1015446a8:     	mul	x10, x8, x9
1015446ac:     	add	x11, x20, #0x60
1015446b0:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446b4:     	add	x8, x8, #0x2df
1015446b8:     	mov	w9, #0x17               ; =23
1015446bc:     	adrp	x12, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446c0:     	add	x12, x12, #0x2f6
1015446c4:     	adrp	x13, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446c8:     	add	x13, x13, #0x30e
1015446cc:     	adrp	x14, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446d0:     	add	x14, x14, #0x326
1015446d4:     	adrp	x15, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446d8:     	add	x15, x15, #0x345
1015446dc:     	adrp	x16, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446e0:     	add	x16, x16, #0x36b
1015446e4:     	adrp	x17, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446e8:     	add	x17, x17, #0x38a
1015446ec:     	adrp	x1, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446f0:     	add	x1, x1, #0x3a6
1015446f4:     	adrp	x2, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015446f8:     	add	x2, x2, #0x3ca
1015446fc:     	adrp	x3, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101544700:     	add	x3, x3, #0x3ee
101544704:     	adrp	x4, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101544708:     	add	x4, x4, #0x40d
10154470c:     	adrp	x0, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101544710:     	add	x0, x0, #0x42a
101544714:     	adrp	x5, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101544718:     	add	x5, x5, #0x452
10154471c:     	b	0x101544728 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4354>
101544720:     	sub	x10, x10, #0xc8
101544724:     	add	x11, x11, #0xc8
101544728:     	cbz	x10, 0x1015448c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44f0>
10154472c:     	ldur	x6, [x11, #-0x60]
101544730:     	cmp	x6, #0x1
101544734:     	b.eq	0x101544720 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x434c>
101544738:     	ldr	x6, [sp, #0x20]
10154473c:     	ldr	x6, [x6, #0x330]
101544740:     	ldur	x7, [x11, #-0x18]
101544744:     	adds	x6, x7, x6
101544748:     	b.hs	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
10154474c:     	ldr	x7, [sp, #0x20]
101544750:     	str	x6, [x7, #0x330]
101544754:     	ldr	x6, [x7, #0x3c8]
101544758:     	ldur	x7, [x11, #-0x10]
10154475c:     	adds	x6, x7, x6
101544760:     	b.hs	0x101544a70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x469c>
101544764:     	ldr	x7, [sp, #0x20]
101544768:     	str	x6, [x7, #0x3c8]
10154476c:     	ldr	x6, [x7, #0x3d0]
101544770:     	ldur	x7, [x11, #-0x8]
101544774:     	adds	x6, x7, x6
101544778:     	b.hs	0x101544a7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46a8>
10154477c:     	ldr	x7, [sp, #0x20]
101544780:     	str	x6, [x7, #0x3d0]
101544784:     	ldr	x6, [x7, #0x3d8]
101544788:     	ldr	x7, [x11]
10154478c:     	adds	x6, x7, x6
101544790:     	b.hs	0x101544a88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46b4>
101544794:     	ldr	x7, [sp, #0x20]
101544798:     	str	x6, [x7, #0x3d8]
10154479c:     	ldr	x6, [x7, #0x3e0]
1015447a0:     	ldr	x7, [x11, #0x8]
1015447a4:     	adds	x6, x7, x6
1015447a8:     	b.hs	0x101544a94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46c0>
1015447ac:     	ldr	x7, [sp, #0x20]
1015447b0:     	str	x6, [x7, #0x3e0]
1015447b4:     	ldr	x6, [x7, #0x3e8]
1015447b8:     	ldr	x7, [x11, #0x10]
1015447bc:     	adds	x6, x7, x6
1015447c0:     	b.hs	0x101544aa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46cc>
1015447c4:     	ldr	x7, [sp, #0x20]
1015447c8:     	str	x6, [x7, #0x3e8]
1015447cc:     	ldr	x6, [x7, #0x3f0]
1015447d0:     	ldr	x7, [x11, #0x18]
1015447d4:     	adds	x6, x7, x6
1015447d8:     	b.hs	0x101544aac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
1015447dc:     	ldr	x7, [sp, #0x20]
1015447e0:     	str	x6, [x7, #0x3f0]
1015447e4:     	ldr	x6, [x7, #0x3f8]
1015447e8:     	ldr	x7, [x11, #0x20]
1015447ec:     	adds	x6, x7, x6
1015447f0:     	b.hs	0x101544ab8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46e4>
1015447f4:     	ldr	x7, [sp, #0x20]
1015447f8:     	str	x6, [x7, #0x3f8]
1015447fc:     	ldr	x6, [x7, #0x400]
101544800:     	ldr	x7, [x11, #0x28]
101544804:     	adds	x6, x7, x6
101544808:     	b.hs	0x101544ac4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46f0>
10154480c:     	ldr	x7, [sp, #0x20]
101544810:     	str	x6, [x7, #0x400]
101544814:     	ldr	x6, [x7, #0x408]
101544818:     	ldr	x7, [x11, #0x30]
10154481c:     	adds	x6, x7, x6
101544820:     	b.hs	0x101544ad0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46fc>
101544824:     	ldr	x7, [sp, #0x20]
101544828:     	str	x6, [x7, #0x408]
10154482c:     	ldr	x6, [x7, #0x410]
101544830:     	ldr	x7, [x11, #0x38]
101544834:     	adds	x6, x7, x6
101544838:     	b.hs	0x101544adc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4708>
10154483c:     	ldr	x7, [sp, #0x20]
101544840:     	str	x6, [x7, #0x410]
101544844:     	ldr	x6, [x7, #0x418]
101544848:     	ldr	x7, [x11, #0x40]
10154484c:     	adds	x6, x7, x6
101544850:     	b.hs	0x101544ae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4714>
101544854:     	ldr	x7, [sp, #0x20]
101544858:     	str	x6, [x7, #0x418]
10154485c:     	ldr	x6, [x7, #0x420]
101544860:     	ldr	x7, [x11, #0x48]
101544864:     	adds	x6, x7, x6
101544868:     	b.hs	0x101544ae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4714>
10154486c:     	ldr	x7, [sp, #0x20]
101544870:     	str	x6, [x7, #0x420]
101544874:     	ldr	x6, [x7, #0x428]
101544878:     	ldr	x7, [x11, #0x50]
10154487c:     	adds	x6, x7, x6
101544880:     	b.hs	0x101544ae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4714>
101544884:     	ldr	x7, [sp, #0x20]
101544888:     	str	x6, [x7, #0x428]
10154488c:     	ldr	x6, [x7, #0x430]
101544890:     	ldr	x7, [x11, #0x58]
101544894:     	adds	x6, x7, x6
101544898:     	b.hs	0x101544af4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4720>
10154489c:     	ldr	x7, [sp, #0x20]
1015448a0:     	str	x6, [x7, #0x430]
1015448a4:     	b	0x101544720 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x434c>
1015448a8:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015448ac:     	add	x8, x8, #0x2c2
1015448b0:     	b	0x101544ae0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x470c>
1015448b4:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015448b8:     	add	x8, x8, #0x1bf
1015448bc:     	mov	w9, #0x1c               ; =28
1015448c0:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
1015448c4:     	stp	xzr, xzr, [x29, #-0xa0]
1015448c8:     	mov	w8, #0x8                ; =8
1015448cc:     	stp	xzr, x8, [x29, #-0xb0]
1015448d0:     	ldr	x1, [sp, #0x6d0]
1015448d4:     	sub	x0, x29, #0xb0
1015448d8:     	bl	0x1014debc0 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE17try_reserve_exactB1h_>
1015448dc:     	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1015448e0:     	cmp	x0, x8
1015448e4:     	b.ne	0x101544b10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x473c>
1015448e8:     	ldur	x8, [x29, #-0xb0]
1015448ec:     	ldr	x9, [sp, #0x6d0]
1015448f0:     	cmp	x8, x9
1015448f4:     	b.ne	0x101544b20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x474c>
1015448f8:     	ldr	x9, [sp, #0x6c8]
1015448fc:     	ldr	x10, [sp, #0x6c0]
101544900:     	mov	w11, #0x68              ; =104
101544904:     	madd	x22, x8, x11, x9
101544908:     	stp	x9, x9, [x29, #-0x90]
10154490c:     	stp	x10, x22, [x29, #-0x80]
101544910:     	cbz	x8, 0x1015449c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x45f0>
101544914:     	add	x24, sp, #0x440
101544918:     	add	x19, x9, #0x68
10154491c:     	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
101544920:     	mov	x26, x19
101544924:     	ldr	x8, [x26, #-0x68]!
101544928:     	cmp	x8, x25
10154492c:     	b.eq	0x1015449c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x45ec>
101544930:     	str	x8, [sp, #0x440]
101544934:     	ldur	q0, [x26, #0x58]
101544938:     	stur	q0, [x24, #0x58]
10154493c:     	ldur	q0, [x26, #0x28]
101544940:     	stur	q0, [x24, #0x28]
101544944:     	ldur	q0, [x26, #0x38]
101544948:     	stur	q0, [x24, #0x38]
10154494c:     	ldur	q0, [x26, #0x48]
101544950:     	stur	q0, [x24, #0x48]
101544954:     	ldur	q0, [x26, #0x8]
101544958:     	stur	q0, [x24, #0x8]
10154495c:     	ldur	q0, [x26, #0x18]
101544960:     	stur	q0, [x24, #0x18]
101544964:     	ldr	x8, [sp, #0x498]
101544968:     	ldr	x9, [sp, #0x4a0]
10154496c:     	ldur	q0, [x26, #0x18]
101544970:     	str	q0, [sp, #0x220]
101544974:     	ldur	q0, [x26, #0x28]
101544978:     	str	q0, [sp, #0x230]
10154497c:     	ldur	q0, [x26, #0x38]
101544980:     	str	q0, [sp, #0x240]
101544984:     	ldur	q0, [x26, #0x48]
101544988:     	str	q0, [sp, #0x250]
10154498c:     	str	x8, [sp, #0x260]
101544990:     	str	xzr, [sp, #0x268]
101544994:     	str	x9, [sp, #0x270]
101544998:     	sub	x0, x29, #0xb0
10154499c:     	add	x1, sp, #0x220
1015449a0:     	bl	0x1014deb24 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE13push_back_mutB1h_>
1015449a4:     	add	x0, sp, #0x440
1015449a8:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015449ac:     	add	x19, x26, #0xd0
1015449b0:     	add	x8, x26, #0x68
1015449b4:     	cmp	x8, x22
1015449b8:     	b.ne	0x101544920 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x454c>
1015449bc:     	mov	x19, x22
1015449c0:     	stur	x19, [x29, #-0x88]
1015449c4:     	sub	x0, x29, #0x90
1015449c8:     	bl	0x1015da164 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
1015449cc:     	ldur	x24, [x29, #-0xd0]
1015449d0:     	ldr	q0, [sp, #0x680]
1015449d4:     	ldr	q1, [sp, #0x690]
1015449d8:     	str	q0, [sp, #0x440]
1015449dc:     	str	q1, [sp, #0x450]
1015449e0:     	ldr	q0, [sp, #0x6a0]
1015449e4:     	ldr	q1, [sp, #0x6b0]
1015449e8:     	stp	q0, q1, [sp, #0x220]
1015449ec:     	ldr	x8, [sp, #0x58]
1015449f0:     	add	x0, x8, #0x3c0
1015449f4:     	bl	0x101522e40 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
1015449f8:     	ldp	q0, q1, [x29, #-0xb0]
1015449fc:     	ldr	x8, [sp, #0x58]
101544a00:     	stp	q0, q1, [x8, #0x3c0]
101544a04:     	ldr	q0, [sp, #0x440]
101544a08:     	ldr	q1, [sp, #0x450]
101544a0c:     	str	q0, [x8, #0x400]
101544a10:     	str	q1, [x8, #0x410]
101544a14:     	ldp	q0, q1, [sp, #0x220]
101544a18:     	str	q0, [x8, #0x420]
101544a1c:     	str	x20, [x8, #0x3e0]
101544a20:     	str	x20, [x8, #0x3e8]
101544a24:     	str	x24, [x8, #0x3f0]
101544a28:     	str	x21, [x8, #0x3f8]
101544a2c:     	str	q1, [x8, #0x430]
101544a30:     	mov	w8, #0x1                ; =1
101544a34:     	dup.2d	v0, x8
101544a38:     	stur	q0, [x23, #0x8]
101544a3c:     	mov	w8, #0x6                ; =6
101544a40:     	str	w8, [x23]
101544a44:     	mov	w19, #0x0               ; =0
101544a48:     	mov	w28, #0x0               ; =0
101544a4c:     	add	x0, sp, #0x720
101544a50:     	bl	0x101524b70 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101544a54:     	ldr	x8, [sp, #0x708]
101544a58:     	cbz	x8, 0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
101544a5c:     	ldr	x0, [sp, #0x710]
101544a60:     	lsl	x1, x8, #3
101544a64:     	mov	w2, #0x8                ; =8
101544a68:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101544a6c:     	b	0x1015439cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
101544a70:     	mov	x8, x12
101544a74:     	mov	w9, #0x18               ; =24
101544a78:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544a7c:     	mov	x8, x13
101544a80:     	mov	w9, #0x18               ; =24
101544a84:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544a88:     	mov	x8, x14
101544a8c:     	mov	w9, #0x1f               ; =31
101544a90:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544a94:     	mov	x8, x15
101544a98:     	mov	w9, #0x26               ; =38
101544a9c:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544aa0:     	mov	x8, x16
101544aa4:     	mov	w9, #0x1f               ; =31
101544aa8:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544aac:     	mov	x8, x17
101544ab0:     	mov	w9, #0x1c               ; =28
101544ab4:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544ab8:     	mov	x8, x1
101544abc:     	mov	w9, #0x24               ; =36
101544ac0:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544ac4:     	mov	x8, x2
101544ac8:     	mov	w9, #0x24               ; =36
101544acc:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544ad0:     	mov	x8, x3
101544ad4:     	mov	w9, #0x1f               ; =31
101544ad8:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544adc:     	mov	x8, x4
101544ae0:     	mov	w9, #0x1d               ; =29
101544ae4:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544ae8:     	mov	x8, x0
101544aec:     	mov	w9, #0x28               ; =40
101544af0:     	b	0x101544afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4728>
101544af4:     	mov	x8, x5
101544af8:     	mov	w9, #0x21               ; =33
101544afc:     	str	wzr, [x23]
101544b00:     	mov	w10, #0xc               ; =12
101544b04:     	stp	x10, x8, [x23, #0x8]
101544b08:     	str	x9, [x23, #0x18]
101544b0c:     	b	0x101544b44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4770>
101544b10:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101544b14:     	add	x8, x8, #0x1db
101544b18:     	mov	w9, #0x21               ; =33
101544b1c:     	b	0x101544b2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4758>
101544b20:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101544b24:     	add	x8, x8, #0xc76
101544b28:     	mov	w9, #0x30               ; =48
101544b2c:     	str	wzr, [x23]
101544b30:     	mov	w10, #0xc               ; =12
101544b34:     	strb	w10, [x23, #0x8]
101544b38:     	stp	x8, x9, [x23, #0x10]
101544b3c:     	sub	x0, x29, #0xb0
101544b40:     	bl	0x1015244b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
101544b44:     	sub	x0, x29, #0xd0
101544b48:     	bl	0x1015239ac <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
101544b4c:     	mov	w19, #0x0               ; =0
101544b50:     	mov	w28, #0x1               ; =1
101544b54:     	add	x0, sp, #0x720
101544b58:     	bl	0x101524b70 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101544b5c:     	ldr	x8, [sp, #0x708]
101544b60:     	cbz	x8, 0x101544b74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
101544b64:     	ldr	x0, [sp, #0x710]
101544b68:     	lsl	x1, x8, #3
101544b6c:     	mov	w2, #0x8                ; =8
101544b70:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101544b74:     	tbz	w19, #0x0, 0x101543734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3360>
101544b78:     	add	x0, sp, #0x6e0
101544b7c:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544b80:     	b	0x101543734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3360>
101544b84:     	b	0x101544cd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4904>
101544b88:     	mov	x22, x0
101544b8c:     	mov	x23, x28
101544b90:     	b	0x101544c84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48b0>
101544b94:     	mov	x22, x0
101544b98:     	mov	w19, #0x0               ; =0
101544b9c:     	b	0x101544c74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48a0>
101544ba0:     	mov	x22, x0
101544ba4:     	mov	w28, #0x1               ; =1
101544ba8:     	b	0x101544c30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x485c>
101544bac:     	mov	x22, x0
101544bb0:     	mov	w19, #0x0               ; =0
101544bb4:     	mov	w28, #0x0               ; =0
101544bb8:     	mov	w23, #0x0               ; =0
101544bbc:     	ldp	q0, q1, [x29, #-0xb0]
101544bc0:     	ldr	x8, [sp, #0x58]
101544bc4:     	stp	q0, q1, [x8, #0x3c0]
101544bc8:     	ldr	q0, [sp, #0x440]
101544bcc:     	ldr	q1, [sp, #0x450]
101544bd0:     	str	q0, [x8, #0x400]
101544bd4:     	str	q1, [x8, #0x410]
101544bd8:     	ldp	q0, q1, [sp, #0x220]
101544bdc:     	str	q0, [x8, #0x420]
101544be0:     	str	x20, [x8, #0x3e0]
101544be4:     	str	x20, [x8, #0x3e8]
101544be8:     	str	x24, [x8, #0x3f0]
101544bec:     	str	x21, [x8, #0x3f8]
101544bf0:     	str	q1, [x8, #0x430]
101544bf4:     	b	0x101544c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48a8>
101544bf8:     	mov	x22, x0
101544bfc:     	b	0x101544c24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4850>
101544c00:     	mov	x22, x0
101544c04:     	stur	x19, [x29, #-0x88]
101544c08:     	b	0x101544c1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4848>
101544c0c:     	mov	x22, x0
101544c10:     	stur	x19, [x29, #-0x88]
101544c14:     	add	x0, sp, #0x440
101544c18:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101544c1c:     	sub	x0, x29, #0x90
101544c20:     	bl	0x1015da164 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
101544c24:     	sub	x0, x29, #0xb0
101544c28:     	bl	0x1015244b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
101544c2c:     	mov	w28, #0x0               ; =0
101544c30:     	sub	x0, x29, #0xd0
101544c34:     	bl	0x1015239ac <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
101544c38:     	mov	w19, #0x0               ; =0
101544c3c:     	b	0x101544c78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48a4>
101544c40:     	mov	x22, x0
101544c44:     	b	0x101544c70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x489c>
101544c48:     	mov	x22, x0
101544c4c:     	b	0x101544c70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x489c>
101544c50:     	b	0x101544cb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48e0>
101544c54:     	mov	x22, x0
101544c58:     	add	x0, sp, #0x110
101544c5c:     	bl	0x101523134 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
101544c60:     	b	0x101544c74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48a0>
101544c64:     	mov	x22, x0
101544c68:     	add	x0, sp, #0x330
101544c6c:     	bl	0x101525614 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers15NativeWorkGroupECs7fdMCt8k5K6_8mech_gpu>
101544c70:     	mov	w19, #0x1               ; =1
101544c74:     	mov	w28, #0x1               ; =1
101544c78:     	mov	w23, #0x1               ; =1
101544c7c:     	add	x0, sp, #0x720
101544c80:     	bl	0x101524b70 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101544c84:     	ldr	x8, [sp, #0x708]
101544c88:     	cbz	x8, 0x101544c9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48c8>
101544c8c:     	ldr	x0, [sp, #0x710]
101544c90:     	lsl	x1, x8, #3
101544c94:     	mov	w2, #0x8                ; =8
101544c98:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101544c9c:     	tbz	w19, #0x0, 0x101544ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48d4>
101544ca0:     	add	x0, sp, #0x6e0
101544ca4:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544ca8:     	tbnz	w28, #0x0, 0x101544ce0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x490c>
101544cac:     	b	0x101544ce8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4914>
101544cb0:     	b	0x101544cc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48f4>
101544cb4:     	mov	x22, x0
101544cb8:     	add	x0, sp, #0x110
101544cbc:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101544cc0:     	b	0x101544ccc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48f8>
101544cc4:     	b	0x101544cd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4904>
101544cc8:     	mov	x22, x0
101544ccc:     	add	x0, sp, #0x220
101544cd0:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544cd4:     	b	0x101544cdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4908>
101544cd8:     	mov	x22, x0
101544cdc:     	mov	w23, #0x1               ; =1
101544ce0:     	add	x0, sp, #0x6c0
101544ce4:     	bl	0x101523b4c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
101544ce8:     	tbnz	w23, #0x0, 0x101544cf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4920>
101544cec:     	b	0x101544d30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x495c>
101544cf0:     	mov	x22, x0
101544cf4:     	add	x0, sp, #0x6a0
101544cf8:     	bl	0x101524b70 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101544cfc:     	b	0x101544d04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4930>
101544d00:     	mov	x22, x0
101544d04:     	add	x0, sp, #0x680
101544d08:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544d0c:     	b	0x101544d30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x495c>
101544d10:     	mov	x22, x0
101544d14:     	add	x1, sp, #0x550
101544d18:     	mov	x0, x20
101544d1c:     	mov	w2, #0x108              ; =264
101544d20:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
101544d24:     	mov	w19, #0x0               ; =0
101544d28:     	b	0x101544db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49dc>
101544d2c:     	mov	x22, x0
101544d30:     	ldr	x8, [sp, #0x668]
101544d34:     	mov	x9, #-0x1               ; =-1
101544d38:     	ldaddl	x9, x8, [x8]
101544d3c:     	cmp	x8, #0x1
101544d40:     	b.ne	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544d44:     	dmb	ishld
101544d48:     	add	x0, sp, #0x668
101544d4c:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101544d50:     	b	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544d54:     	mov	x22, x0
101544d58:     	ldr	x8, [sp, #0x550]
101544d5c:     	mov	x9, #-0x1               ; =-1
101544d60:     	ldaddl	x9, x8, [x8]
101544d64:     	cmp	x8, #0x1
101544d68:     	b.ne	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544d6c:     	dmb	ishld
101544d70:     	add	x0, sp, #0x550
101544d74:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101544d78:     	b	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544d7c:     	bl	0x103a0248c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101544d80:     	mov	x22, x0
101544d84:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101544d88:     	str	x8, [x20]
101544d8c:     	b	0x101544dc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49f0>
101544d90:     	mov	x22, x0
101544d94:     	tbnz	w19, #0x0, 0x101544e10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a3c>
101544d98:     	b	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544d9c:     	mov	x22, x0
101544da0:     	add	x0, sp, #0x440
101544da4:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544da8:     	b	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544dac:     	mov	x22, x0
101544db0:     	sub	x0, x29, #0x90
101544db4:     	bl	0x101524be8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544db8:     	b	0x101544dec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a18>
101544dbc:     	mov	x22, x0
101544dc0:     	mov	x23, x24
101544dc4:     	cbz	w23, 0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544dc8:     	ldr	x8, [sp, #0x550]
101544dcc:     	cbz	x8, 0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544dd0:     	add	x0, sp, #0x550
101544dd4:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544dd8:     	b	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544ddc:     	bl	0x103a0248c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101544de0:     	mov	x22, x0
101544de4:     	b	0x101544e10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a3c>
101544de8:     	mov	x22, x0
101544dec:     	ldr	x8, [sp, #0x720]
101544df0:     	mov	x9, #-0x1               ; =-1
101544df4:     	ldaddl	x9, x8, [x8]
101544df8:     	cmp	x8, #0x1
101544dfc:     	b.ne	0x101544e0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a38>
101544e00:     	dmb	ishld
101544e04:     	add	x0, sp, #0x720
101544e08:     	bl	0x102e16a54 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101544e0c:     	tbz	w19, #0x0, 0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544e10:     	add	x0, sp, #0x220
101544e14:     	bl	0x101525834 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
101544e18:     	b	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544e1c:     	mov	x22, x0
101544e20:     	add	x0, sp, #0x60
101544e24:     	bl	0x101524e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544e28:     	b	0x101544e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
101544e2c:     	bl	0x103a0248c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101544e30:     	mov	w8, #0x2                ; =2
101544e34:     	str	x8, [x20, #0x220]
101544e38:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
101544e3c:     	mov	w8, #0x2                ; =2
101544e40:     	str	x8, [x20, #0x220]
101544e44:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
101544e48:     	mov	x22, x0
101544e4c:     	ldr	w8, [sp, #0x550]
101544e50:     	cmp	w8, #0x6
101544e54:     	b.ne	0x101544e60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a8c>
101544e58:     	mov	x0, x22
101544e5c:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
101544e60:     	add	x0, sp, #0x550
101544e64:     	bl	0x101525710 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101544e68:     	mov	x0, x22
101544e6c:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
