
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010153f5b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>:
10153f5b8:     	stp	x28, x27, [sp, #-0x60]!
10153f5bc:     	stp	x26, x25, [sp, #0x10]
10153f5c0:     	stp	x24, x23, [sp, #0x20]
10153f5c4:     	stp	x22, x21, [sp, #0x30]
10153f5c8:     	stp	x20, x19, [sp, #0x40]
10153f5cc:     	stp	x29, x30, [sp, #0x50]
10153f5d0:     	add	x29, sp, #0x50
10153f5d4:     	sub	sp, sp, #0x2f0
10153f5d8:     	mov	x19, x8
10153f5dc:     	ldr	x8, [x0, #0x238]
10153f5e0:     	ldr	w9, [x0, #0x268]
10153f5e4:     	cmp	x8, #0x3
10153f5e8:     	ccmp	w9, #0x0, #0x4, ne
10153f5ec:     	b.ne	0x10153f620 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x68>
10153f5f0:     	ldr	x8, [x0, #0xc0]
10153f5f4:     	cmp	x8, #0x2
10153f5f8:     	b.ne	0x10153f63c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84>
10153f5fc:     	ldr	x8, [x0, #0xa8]
10153f600:     	cbz	x8, 0x10153f678 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc0>
10153f604:     	str	wzr, [x19]
10153f608:     	mov	w8, #0xc                ; =12
10153f60c:     	strb	w8, [x19, #0x8]
10153f610:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f614:     	add	x8, x8, #0x75a
10153f618:     	mov	w9, #0x2a               ; =42
10153f61c:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f620:     	str	wzr, [x19]
10153f624:     	mov	w8, #0xc                ; =12
10153f628:     	strb	w8, [x19, #0x8]
10153f62c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f630:     	add	x8, x8, #0x8e2
10153f634:     	mov	w9, #0x24               ; =36
10153f638:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f63c:     	str	wzr, [x19]
10153f640:     	mov	w8, #0xc                ; =12
10153f644:     	strb	w8, [x19, #0x8]
10153f648:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f64c:     	add	x8, x8, #0x726
10153f650:     	mov	w9, #0x34               ; =52
10153f654:     	stp	x8, x9, [x19, #0x10]
10153f658:     	add	sp, sp, #0x2f0
10153f65c:     	ldp	x29, x30, [sp, #0x50]
10153f660:     	ldp	x20, x19, [sp, #0x40]
10153f664:     	ldp	x22, x21, [sp, #0x30]
10153f668:     	ldp	x24, x23, [sp, #0x20]
10153f66c:     	ldp	x26, x25, [sp, #0x10]
10153f670:     	ldp	x28, x27, [sp], #0x60
10153f674:     	ret
10153f678:     	mov	x20, x1
10153f67c:     	ldrb	w8, [x0, #0x510]
10153f680:     	tbz	w8, #0x0, 0x10153f6bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
10153f684:     	ldr	x8, [x0, #0x4a0]
10153f688:     	ldr	w9, [x8, #0x300]
10153f68c:     	cmp	w9, #0x1
10153f690:     	b.ne	0x10153f6bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
10153f694:     	ldr	w8, [x8, #0x304]
10153f698:     	cmp	x20, x8
10153f69c:     	b.ne	0x10153f6bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
10153f6a0:     	str	wzr, [x19]
10153f6a4:     	mov	w8, #0xc                ; =12
10153f6a8:     	strb	w8, [x19, #0x8]
10153f6ac:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f6b0:     	add	x8, x8, #0x8aa
10153f6b4:     	mov	w9, #0x38               ; =56
10153f6b8:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f6bc:     	ldr	x24, [x0, #0x490]
10153f6c0:     	ldr	w8, [x24, #0x2f0]
10153f6c4:     	tbz	w8, #0x0, 0x10153f6ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
10153f6c8:     	ldr	w1, [x24, #0x2f4]
10153f6cc:     	mov	x21, x0
10153f6d0:     	bl	0x10153f02c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
10153f6d4:     	mov	x8, x0
10153f6d8:     	mov	x0, x21
10153f6dc:     	ldr	x24, [x21, #0x490]
10153f6e0:     	tbz	w8, #0x0, 0x10153f6ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
10153f6e4:     	ldrb	w8, [x24, #0x460]
10153f6e8:     	tbz	w8, #0x0, 0x10153f7e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x230>
10153f6ec:     	ldr	x21, [x0, #0x4a0]
10153f6f0:     	ldr	w9, [x24, #0xb8]
10153f6f4:     	ldr	w8, [x24, #0x2f0]
10153f6f8:     	cmp	w9, #0x1
10153f6fc:     	b.ne	0x10153f734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x17c>
10153f700:     	tbz	w8, #0x0, 0x10153f718 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x160>
10153f704:     	ldp	w22, w8, [x24, #0xbc]
10153f708:     	ldr	w9, [x24, #0x2f4]
10153f70c:     	cmp	x20, x8
10153f710:     	ccmp	w9, w22, #0x0, eq
10153f714:     	b.eq	0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f718:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f71c:     	add	x8, x8, #0x678
10153f720:     	mov	w9, #0x26               ; =38
10153f724:     	str	wzr, [x19]
10153f728:     	mov	w10, #0xc               ; =12
10153f72c:     	str	w10, [x19, #0x8]
10153f730:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f734:     	ldr	w22, [x24, #0x2f4]
10153f738:     	tbz	w8, #0x0, 0x10153f7c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x210>
10153f73c:     	ldr	x8, [x21, #0x590]
10153f740:     	cmp	x8, x22
10153f744:     	b.ls	0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f748:     	ldr	x8, [x21, #0x588]
10153f74c:     	add	x8, x8, x22, lsl #4
10153f750:     	ldr	x9, [x8]
10153f754:     	cmp	x9, #0x1
10153f758:     	b.ne	0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f75c:     	ldr	x8, [x8, #0x8]
10153f760:     	ldr	x1, [x21, #0x580]
10153f764:     	cmp	x8, x1
10153f768:     	b.hs	0x1015402a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcec>
10153f76c:     	ldr	x9, [x21, #0x578]
10153f770:     	mov	w10, #0x38              ; =56
10153f774:     	madd	x8, x8, x10, x9
10153f778:     	ldr	x9, [x8]
10153f77c:     	cmp	x9, #0x1
10153f780:     	b.ne	0x10153f804 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x24c>
10153f784:     	ldr	x9, [x24, #0x10]
10153f788:     	cmp	x9, #0x2
10153f78c:     	b.eq	0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f790:     	ldr	x9, [x8, #0x8]
10153f794:     	ldr	x10, [x24, #0x40]
10153f798:     	cmp	x9, x10
10153f79c:     	b.hs	0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f7a0:     	ldr	x10, [x24, #0x38]
10153f7a4:     	mov	w11, #0x3c8             ; =968
10153f7a8:     	madd	x9, x9, x11, x10
10153f7ac:     	ldr	x9, [x9, #0x290]
10153f7b0:     	cbz	x9, 0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f7b4:     	ldr	x9, [x8, #0x18]
10153f7b8:     	cbz	x9, 0x101540290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153f7bc:     	ldr	x9, [x8, #0x10]
10153f7c0:     	ldr	w9, [x9]
10153f7c4:     	b	0x10153f828 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x270>
10153f7c8:     	mov	w25, #0x0               ; =0
10153f7cc:     	mov	w23, #0x0               ; =0
10153f7d0:     	add	x27, sp, #0x130
10153f7d4:     	mov	x28, x0
10153f7d8:     	ldr	x26, [x28, #0xf8]!
10153f7dc:     	cmp	x26, #0x2
10153f7e0:     	b.eq	0x10153f864 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
10153f7e4:     	b	0x10153f97c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
10153f7e8:     	str	wzr, [x19]
10153f7ec:     	mov	w8, #0xc                ; =12
10153f7f0:     	strb	w8, [x19, #0x8]
10153f7f4:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f7f8:     	add	x8, x8, #0x784
10153f7fc:     	mov	w9, #0x25               ; =37
10153f800:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f804:     	ldr	x9, [x8, #0x18]
10153f808:     	cbz	x9, 0x101540290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153f80c:     	ldr	w9, [x24, #0x340]
10153f810:     	tbz	w9, #0x0, 0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f814:     	ldr	x9, [x8, #0x10]
10153f818:     	ldr	w9, [x9]
10153f81c:     	ldr	w10, [x24, #0x344]
10153f820:     	cmp	w10, w9
10153f824:     	b.ne	0x10153f848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f828:     	cmp	w22, w9
10153f82c:     	b.ne	0x10153f934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x37c>
10153f830:     	lsr	x9, x20, #32
10153f834:     	cbz	x9, 0x10153f944 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x38c>
10153f838:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f83c:     	add	x8, x8, #0x6c8
10153f840:     	mov	w9, #0x1a               ; =26
10153f844:     	b	0x10153f724 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
10153f848:     	mov	w25, #0x1               ; =1
10153f84c:     	mov	w23, #0x1               ; =1
10153f850:     	add	x27, sp, #0x130
10153f854:     	mov	x28, x0
10153f858:     	ldr	x26, [x28, #0xf8]!
10153f85c:     	cmp	x26, #0x2
10153f860:     	b.ne	0x10153f97c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
10153f864:     	cbz	w23, 0x10153f918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x360>
10153f868:     	mov	w2, w22
10153f86c:     	ldr	x8, [x21, #0x188]
10153f870:     	cmp	x8, x2
10153f874:     	b.ls	0x10153fe20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
10153f878:     	ldr	x8, [x21, #0x180]
10153f87c:     	ldr	x8, [x8, x2, lsl #3]
10153f880:     	cbz	x8, 0x10153fe20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
10153f884:     	sub	x8, x8, #0x1
10153f888:     	and	x9, x8, #0x3
10153f88c:     	cmp	x9, #0x2
10153f890:     	b.ne	0x10153fe20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
10153f894:     	lsr	x8, x8, #2
10153f898:     	ldr	x1, [x21, #0x160]
10153f89c:     	cmp	x8, x1
10153f8a0:     	b.hs	0x1015402b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcfc>
10153f8a4:     	ldr	x9, [x21, #0x158]
10153f8a8:     	mov	w10, #0x48              ; =72
10153f8ac:     	madd	x9, x8, x10, x9
10153f8b0:     	ldr	w10, [x9, #0x40]
10153f8b4:     	cmp	x20, x10
10153f8b8:     	b.ne	0x10153f908 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
10153f8bc:     	ldr	w10, [x24, #0x2e8]
10153f8c0:     	cmp	w10, #0x1
10153f8c4:     	b.ne	0x10153f908 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
10153f8c8:     	ldr	w10, [x9, #0x30]
10153f8cc:     	ldr	w11, [x24, #0x2ec]
10153f8d0:     	cmp	w11, w10
10153f8d4:     	b.ne	0x10153f908 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
10153f8d8:     	ldr	w9, [x9, #0x34]
10153f8dc:     	mov	w10, #0x1               ; =1
10153f8e0:     	orr	x9, x10, x9, lsl #1
10153f8e4:     	ldr	x1, [x0, #0x4c0]
10153f8e8:     	cmp	x9, x1
10153f8ec:     	b.hs	0x101540304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd4c>
10153f8f0:     	ldr	x10, [x0, #0x4b8]
10153f8f4:     	ldr	x9, [x10, x9, lsl #3]
10153f8f8:     	ldr	x10, [x0, #0xc0]
10153f8fc:     	cmp	x9, #0x0
10153f900:     	ccmp	x10, #0x2, #0x0, eq
10153f904:     	b.eq	0x10153fe08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x850>
10153f908:     	adrp	x8, 0x107551000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x3170>
10153f90c:     	add	x8, x8, #0x340
10153f910:     	mov	w9, #0x35               ; =53
10153f914:     	b	0x10153fe40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x888>
10153f918:     	ldrb	w8, [x24, #0x338]
10153f91c:     	cmp	w8, #0x1
10153f920:     	b.ne	0x10153f92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x374>
10153f924:     	ldr	x8, [x0, #0x4c8]
10153f928:     	cbnz	x8, 0x10153fe34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x87c>
10153f92c:     	str	x20, [sp, #0x20]
10153f930:     	b	0x10153fad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x520>
10153f934:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153f938:     	add	x8, x8, #0x6e2
10153f93c:     	mov	w9, #0x1a               ; =26
10153f940:     	b	0x10153f724 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
10153f944:     	mov	x25, x0
10153f948:     	mov	x0, x8
10153f94c:     	mov	x1, x20
10153f950:     	bl	0x101517e70 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB2_5Group11predecessor>
10153f954:     	tbz	w0, #0x0, 0x10153fdf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x840>
10153f958:     	mov	x22, x1
10153f95c:     	mov	w23, #0x1               ; =1
10153f960:     	mov	x0, x25
10153f964:     	mov	w25, #0x1               ; =1
10153f968:     	add	x27, sp, #0x130
10153f96c:     	mov	x28, x0
10153f970:     	ldr	x26, [x28, #0xf8]!
10153f974:     	cmp	x26, #0x2
10153f978:     	b.eq	0x10153f864 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
10153f97c:     	cbz	w23, 0x10153fa9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
10153f980:     	mov	w2, w22
10153f984:     	str	w23, [sp, #0x1c]
10153f988:     	ldr	x1, [x21, #0x380]
10153f98c:     	cmp	x1, x2
10153f990:     	b.ls	0x10154026c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcb4>
10153f994:     	mov	x23, x25
10153f998:     	ldr	x8, [x21, #0x378]
10153f99c:     	mov	w9, #0x170              ; =368
10153f9a0:     	umaddl	x8, w2, w9, x8
10153f9a4:     	ldp	x10, x9, [x8]
10153f9a8:     	mov	w11, #0x11              ; =17
10153f9ac:     	eor	x10, x10, x11
10153f9b0:     	orr	x9, x10, x9
10153f9b4:     	cbnz	x9, 0x10153fa80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4c8>
10153f9b8:     	ldr	x1, [x21, #0x390]
10153f9bc:     	ldr	w25, [x8, #0x10]
10153f9c0:     	cmp	x1, x25
10153f9c4:     	b.ls	0x101540280 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcc8>
10153f9c8:     	ldr	x8, [x21, #0x388]
10153f9cc:     	mov	w9, #0x180              ; =384
10153f9d0:     	umaddl	x27, w25, w9, x8
10153f9d4:     	ldp	x9, x8, [x27]
10153f9d8:     	mov	w10, #0x5               ; =5
10153f9dc:     	eor	x9, x9, x10
10153f9e0:     	orr	x8, x9, x8
10153f9e4:     	cbnz	x8, 0x10153fa80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4c8>
10153f9e8:     	ldr	x8, [x21, #0x558]
10153f9ec:     	cmp	x8, x2
10153f9f0:     	b.ls	0x10153fa0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x454>
10153f9f4:     	ldr	x8, [x21, #0x550]
10153f9f8:     	mov	w9, #0x28               ; =40
10153f9fc:     	umull	x9, w2, w9
10153fa00:     	ldr	w8, [x8, x9]
10153fa04:     	cmp	w8, #0x5
10153fa08:     	b.ne	0x10153fa50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x498>
10153fa0c:     	str	x0, [sp, #0x10]
10153fa10:     	mov	x0, x24
10153fa14:     	mov	x1, x21
10153fa18:     	bl	0x101550134 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
10153fa1c:     	mov	x8, x0
10153fa20:     	ldr	x0, [sp, #0x10]
10153fa24:     	tbnz	w8, #0x0, 0x10153fa50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x498>
10153fa28:     	ldr	x1, [x21, #0x360]
10153fa2c:     	ldr	w8, [x27, #0x30]
10153fa30:     	cmp	x1, x8
10153fa34:     	b.ls	0x1015402c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd0c>
10153fa38:     	ldr	x9, [x21, #0x358]
10153fa3c:     	mov	w10, #0x140             ; =320
10153fa40:     	umaddl	x8, w8, w10, x9
10153fa44:     	ldrb	w8, [x8, #0x124]
10153fa48:     	cmp	w8, #0x7
10153fa4c:     	b.eq	0x10153fa80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4c8>
10153fa50:     	mov	x1, x0
10153fa54:     	add	x0, sp, #0x188
10153fa58:     	mov	x21, x1
10153fa5c:     	mov	x2, x25
10153fa60:     	mov	w3, #0x1                ; =1
10153fa64:     	bl	0x10153f220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
10153fa68:     	ldr	w8, [sp, #0x188]
10153fa6c:     	cmp	w8, #0x6
10153fa70:     	b.ne	0x10153fc38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
10153fa74:     	mov	x0, x21
10153fa78:     	ldr	x26, [x21, #0xf8]
10153fa7c:     	ldr	x21, [x21, #0x4a0]
10153fa80:     	str	x20, [sp, #0x20]
10153fa84:     	cmp	x26, #0x2
10153fa88:     	add	x27, sp, #0x130
10153fa8c:     	mov	x25, x23
10153fa90:     	ldr	w23, [sp, #0x1c]
10153fa94:     	b.ne	0x10153faa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e8>
10153fa98:     	b	0x10153fad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x520>
10153fa9c:     	str	x20, [sp, #0x20]
10153faa0:     	ldr	x9, [x21, #0x5a0]
10153faa4:     	ldr	x8, [x0, #0x1c0]
10153faa8:     	cmp	x8, x9
10153faac:     	b.hs	0x10153fbfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x644>
10153fab0:     	ldr	x9, [x21, #0x598]
10153fab4:     	mov	w10, #0x58              ; =88
10153fab8:     	madd	x8, x8, x10, x9
10153fabc:     	mov	x24, x0
10153fac0:     	mov	x0, x8
10153fac4:     	mov	x1, x20
10153fac8:     	bl	0x1015182c4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare8parallelNtB2_6Region8contains>
10153facc:     	mov	x8, x0
10153fad0:     	mov	x0, x24
10153fad4:     	tbz	w8, #0x0, 0x10153fbfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x644>
10153fad8:     	ldr	x8, [x21, #0x380]
10153fadc:     	cmp	x20, x8
10153fae0:     	b.hs	0x10153fc18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x660>
10153fae4:     	ldr	x24, [x21, #0x378]
10153fae8:     	mov	x1, x0
10153faec:     	add	x0, sp, #0x188
10153faf0:     	mov	x21, x1
10153faf4:     	mov	x2, x20
10153faf8:     	bl	0x10154b16c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation31validate_selected_join_boundary>
10153fafc:     	ldr	w8, [sp, #0x188]
10153fb00:     	cmp	w8, #0x6
10153fb04:     	b.ne	0x101540028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153fb08:     	mov	w8, #0x170              ; =368
10153fb0c:     	madd	x24, x20, x8, x24
10153fb10:     	mov	x8, x21
10153fb14:     	ldr	x9, [x21, #0x490]
10153fb18:     	ldr	x10, [x9, #0x1e0]
10153fb1c:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
10153fb20:     	cmp	x10, x11
10153fb24:     	b.eq	0x10153fb50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x598>
10153fb28:     	ldr	x1, [x9, #0x2d0]
10153fb2c:     	ldr	x2, [x9, #0x2e0]
10153fb30:     	ldp	x3, x4, [x24]
10153fb34:     	ldrb	w5, [x24, #0x10]
10153fb38:     	add	x0, sp, #0x188
10153fb3c:     	bl	0x101545548 <__RNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections11string_spanNtB7_5State22validate_span_boundary>
10153fb40:     	ldr	w8, [sp, #0x188]
10153fb44:     	cmp	w8, #0x6
10153fb48:     	b.ne	0x101540028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153fb4c:     	mov	x8, x21
10153fb50:     	mov	x26, x23
10153fb54:     	ldr	x9, [x8, #0x4a0]
10153fb58:     	mov	x23, x25
10153fb5c:     	mov	x25, x8
10153fb60:     	add	x0, x9, #0x578
10153fb64:     	mov	x1, x20
10153fb68:     	bl	0x1015480b8 <__RNvMs_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB4_6Layout5group>
10153fb6c:     	ldr	x8, [x25, #0x490]
10153fb70:     	add	x9, x8, #0x3b8
10153fb74:     	add	x10, x8, #0x2f8
10153fb78:     	stp	x8, x9, [sp, #0x188]
10153fb7c:     	stp	x10, x28, [sp, #0x198]
10153fb80:     	add	x8, sp, #0x20
10153fb84:     	str	x8, [sp, #0x1a8]
10153fb88:     	add	x1, sp, #0x188
10153fb8c:     	bl	0x101521c2c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>
10153fb90:     	cbz	x0, 0x10153fbac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x5f4>
10153fb94:     	ldr	x8, [x0, #0x18]
10153fb98:     	cbz	x8, 0x101540290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153fb9c:     	ldr	x8, [x0, #0x10]
10153fba0:     	ldr	w8, [x8]
10153fba4:     	cmp	x20, x8
10153fba8:     	b.ne	0x10153fcc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x70c>
10153fbac:     	mov	x8, x21
10153fbb0:     	ldr	x9, [x21, #0xf8]
10153fbb4:     	cmp	x9, #0x2
10153fbb8:     	csinc	w9, w23, wzr, ne
10153fbbc:     	tbz	w9, #0x0, 0x10153fc5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x6a4>
10153fbc0:     	ldr	x9, [x8, #0x498]
10153fbc4:     	ldr	x10, [x8, #0x490]
10153fbc8:     	add	x11, x10, #0x2e8
10153fbcc:     	ldr	x10, [x8, #0x4a0]
10153fbd0:     	ldr	x12, [x8, #0x4b8]
10153fbd4:     	ldr	x8, [x8, #0x4c0]
10153fbd8:     	stp	x11, x10, [sp, #0x1c0]
10153fbdc:     	stp	x12, x8, [sp, #0x1d0]
10153fbe0:     	mov	w8, #0x13               ; =19
10153fbe4:     	strb	w8, [sp, #0x188]
10153fbe8:     	cbz	x0, 0x10153fd00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x748>
10153fbec:     	mov	x25, x0
10153fbf0:     	ldr	x4, [x0, #0x30]
10153fbf4:     	mov	w3, #0x1                ; =1
10153fbf8:     	b	0x10153fd08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x750>
10153fbfc:     	str	wzr, [x19]
10153fc00:     	mov	w8, #0xc                ; =12
10153fc04:     	strb	w8, [x19, #0x8]
10153fc08:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153fc0c:     	add	x8, x8, #0x7a9
10153fc10:     	mov	w9, #0x2f               ; =47
10153fc14:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fc18:     	str	wzr, [x19]
10153fc1c:     	mov	w8, #0xc                ; =12
10153fc20:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
10153fc24:     	add	x9, x9, #0x79
10153fc28:     	stp	x8, x9, [x19, #0x8]
10153fc2c:     	mov	w8, #0x25               ; =37
10153fc30:     	str	x8, [x19, #0x18]
10153fc34:     	b	0x10153f658 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153fc38:     	add	x8, sp, #0x130
10153fc3c:     	ldur	q0, [x8, #0x68]
10153fc40:     	ldur	q1, [x8, #0x78]
10153fc44:     	ldur	q2, [x8, #0x88]
10153fc48:     	stp	q1, q2, [x19, #0x20]
10153fc4c:     	ldur	q1, [x8, #0x98]
10153fc50:     	str	q1, [x19, #0x40]
10153fc54:     	ldur	q1, [x8, #0x58]
10153fc58:     	b	0x101540044 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa8c>
10153fc5c:     	ldr	x9, [x8, #0x4a0]
10153fc60:     	ldr	x11, [x9, #0x5a0]
10153fc64:     	ldr	x10, [x8, #0x1c0]
10153fc68:     	cmp	x10, x11
10153fc6c:     	b.hs	0x10153fce0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x728>
10153fc70:     	cbnz	x0, 0x10153fdd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x818>
10153fc74:     	ldr	x11, [x9, #0x598]
10153fc78:     	mov	w12, #0x58              ; =88
10153fc7c:     	madd	x10, x10, x12, x11
10153fc80:     	ldr	w3, [x10, #0x38]
10153fc84:     	cmp	x20, x3
10153fc88:     	b.ne	0x10153fdd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x818>
10153fc8c:     	mov	x25, x0
10153fc90:     	ldr	x10, [x8, #0x490]
10153fc94:     	add	x10, x10, #0x2e8
10153fc98:     	ldr	x11, [x8, #0x4b8]
10153fc9c:     	ldr	x8, [x8, #0x4c0]
10153fca0:     	stp	x10, x9, [sp, #0x1c0]
10153fca4:     	stp	x11, x8, [sp, #0x1d0]
10153fca8:     	mov	w8, #0x13               ; =19
10153fcac:     	strb	w8, [sp, #0x188]
10153fcb0:     	add	x0, sp, #0x28
10153fcb4:     	add	x1, sp, #0x188
10153fcb8:     	mov	x2, x20
10153fcbc:     	bl	0x10154766c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE20visit_outlined_entryB9_>
10153fcc0:     	b	0x10153fd28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x770>
10153fcc4:     	str	wzr, [x19]
10153fcc8:     	mov	w8, #0xc                ; =12
10153fccc:     	strb	w8, [x19, #0x8]
10153fcd0:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153fcd4:     	add	x8, x8, #0x87f
10153fcd8:     	mov	w9, #0x2b               ; =43
10153fcdc:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fce0:     	str	wzr, [x19]
10153fce4:     	mov	w8, #0xc                ; =12
10153fce8:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
10153fcec:     	add	x9, x9, #0x9e
10153fcf0:     	stp	x8, x9, [x19, #0x8]
10153fcf4:     	mov	w8, #0x1a               ; =26
10153fcf8:     	str	x8, [x19, #0x18]
10153fcfc:     	b	0x10153f658 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153fd00:     	mov	x25, x0
10153fd04:     	mov	x3, #0x0                ; =0
10153fd08:     	mov	x5, x26
10153fd0c:     	ldr	w7, [x10, #0x3f0]
10153fd10:     	str	x9, [sp]
10153fd14:     	add	x0, sp, #0x28
10153fd18:     	add	x1, sp, #0x188
10153fd1c:     	mov	x2, x20
10153fd20:     	mov	x6, x22
10153fd24:     	bl	0x101546dec <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>
10153fd28:     	ldrb	w8, [sp, #0x28]
10153fd2c:     	cmp	w8, #0x13
10153fd30:     	b.ne	0x10153fd70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x7b8>
10153fd34:     	add	x0, sp, #0x188
10153fd38:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
10153fd3c:     	add	x0, sp, #0x188
10153fd40:     	mov	x1, x21
10153fd44:     	mov	x2, x20
10153fd48:     	bl	0x101548d60 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation12continuationNtB6_10Invocation23arm_parent_continuation>
10153fd4c:     	ldr	w8, [sp, #0x188]
10153fd50:     	cmp	w8, #0x6
10153fd54:     	b.ne	0x101540028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153fd58:     	cbz	x25, 0x10153fdec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x834>
10153fd5c:     	ldr	x8, [x25]
10153fd60:     	mov	x0, x21
10153fd64:     	cbz	x8, 0x10153fe50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x898>
10153fd68:     	mov	w8, #0x0                ; =0
10153fd6c:     	b	0x10153fe64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8ac>
10153fd70:     	ldur	q0, [sp, #0x28]
10153fd74:     	ldur	q1, [sp, #0x38]
10153fd78:     	stp	q0, q1, [sp, #0x130]
10153fd7c:     	ldur	q2, [sp, #0x48]
10153fd80:     	str	q2, [sp, #0x150]
10153fd84:     	ldr	x8, [sp, #0x58]
10153fd88:     	str	x8, [sp, #0x160]
10153fd8c:     	stur	q0, [sp, #0x2c]
10153fd90:     	stur	q1, [sp, #0x3c]
10153fd94:     	stur	q2, [sp, #0x4c]
10153fd98:     	stur	x8, [sp, #0x5c]
10153fd9c:     	mov	w8, #0x1                ; =1
10153fda0:     	str	w8, [x19]
10153fda4:     	ldur	q0, [sp, #0x28]
10153fda8:     	ldur	q1, [sp, #0x38]
10153fdac:     	stur	q0, [x19, #0x4]
10153fdb0:     	stur	q1, [x19, #0x14]
10153fdb4:     	ldur	q0, [sp, #0x48]
10153fdb8:     	stur	q0, [x19, #0x24]
10153fdbc:     	ldur	q0, [sp, #0x54]
10153fdc0:     	str	q0, [x19, #0x30]
10153fdc4:     	add	x0, sp, #0x188
10153fdc8:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
10153fdcc:     	b	0x10153f658 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153fdd0:     	str	wzr, [x19]
10153fdd4:     	mov	w8, #0xc                ; =12
10153fdd8:     	strb	w8, [x19, #0x8]
10153fddc:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153fde0:     	add	x8, x8, #0x7d8
10153fde4:     	mov	w9, #0x26               ; =38
10153fde8:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fdec:     	mov	w8, #0x0                ; =0
10153fdf0:     	mov	x0, x21
10153fdf4:     	b	0x10153fe64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8ac>
10153fdf8:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153fdfc:     	add	x8, x8, #0x69e
10153fe00:     	mov	w9, #0x2a               ; =42
10153fe04:     	b	0x10153f724 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
10153fe08:     	ldr	x9, [x0, #0x4c8]
10153fe0c:     	str	xzr, [x0, #0x4c8]
10153fe10:     	cbz	x9, 0x101540094 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xadc>
10153fe14:     	sub	x9, x9, #0x1
10153fe18:     	cmp	x9, x8
10153fe1c:     	b.ne	0x1015400a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaec>
10153fe20:     	ldrb	w8, [x24, #0x338]
10153fe24:     	cmp	w8, #0x1
10153fe28:     	b.ne	0x10153f984 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
10153fe2c:     	ldr	x8, [x0, #0x4c8]
10153fe30:     	cbz	x8, 0x10153f984 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
10153fe34:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
10153fe38:     	add	x8, x8, #0x7fe
10153fe3c:     	mov	w9, #0x29               ; =41
10153fe40:     	str	wzr, [x19]
10153fe44:     	mov	w10, #0xc               ; =12
10153fe48:     	str	x10, [x19, #0x8]
10153fe4c:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fe50:     	ldr	x8, [x25, #0x18]
10153fe54:     	cbz	x8, 0x101540290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153fe58:     	ldr	x8, [x25, #0x10]
10153fe5c:     	ldr	w9, [x8]
10153fe60:     	mov	w8, #0x1                ; =1
10153fe64:     	ldr	x10, [x0, #0x490]
10153fe68:     	str	w8, [x10, #0x340]
10153fe6c:     	str	w9, [x10, #0x344]
10153fe70:     	ldr	x8, [x0, #0x490]
10153fe74:     	str	wzr, [x8, #0xb8]
10153fe78:     	ldr	x22, [x0, #0x4a0]
10153fe7c:     	mov	x1, x20
10153fe80:     	bl	0x101535574 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
10153fe84:     	cbz	x0, 0x10153feb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x900>
10153fe88:     	ldrb	w8, [x0]
10153fe8c:     	cmp	w8, #0x6
10153fe90:     	b.ne	0x10153feb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x900>
10153fe94:     	ldr	x9, [x21, #0x490]
10153fe98:     	add	x8, sp, #0x188
10153fe9c:     	add	x0, x9, #0x3b8
10153fea0:     	mov	w1, #0x20               ; =32
10153fea4:     	mov	w2, #0x20               ; =32
10153fea8:     	bl	0x10236d8e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>
10153feac:     	ldrb	w8, [sp, #0x188]
10153feb0:     	cmp	w8, #0x8
10153feb4:     	b.ne	0x10154004c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa94>
10153feb8:     	ldr	x1, [x22, #0x458]
10153febc:     	cmp	x20, x1
10153fec0:     	b.hs	0x1015402d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd1c>
10153fec4:     	ldr	x8, [x22, #0x450]
10153fec8:     	add	x10, x8, x20, lsl #6
10153fecc:     	ldr	w8, [x10, #0x18]
10153fed0:     	cmp	w8, #0x4
10153fed4:     	mov	x9, x21
10153fed8:     	b.ne	0x10153ff30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x978>
10153fedc:     	ldr	x8, [x9, #0x220]
10153fee0:     	cmp	x8, #0x2
10153fee4:     	b.eq	0x10153ff30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x978>
10153fee8:     	ldr	x8, [x22, #0x208]
10153feec:     	ldr	x0, [x9, #0x1d8]
10153fef0:     	cmp	x0, x8
10153fef4:     	b.hs	0x101540340 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd88>
10153fef8:     	ldr	w8, [x10, #0x1c]
10153fefc:     	ldr	x10, [x22, #0x200]
10153ff00:     	mov	w11, #0x70              ; =112
10153ff04:     	madd	x10, x0, x11, x10
10153ff08:     	ldr	w10, [x10, #0x40]
10153ff0c:     	cmp	w10, w8
10153ff10:     	b.ne	0x10153ff30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x978>
10153ff14:     	add	x0, x9, #0x1d8
10153ff18:     	bl	0x101526bb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
10153ff1c:     	mov	w8, #0x2                ; =2
10153ff20:     	mov	x9, x21
10153ff24:     	str	x8, [x21, #0x220]
10153ff28:     	ldr	x1, [x22, #0x458]
10153ff2c:     	add	x27, sp, #0x130
10153ff30:     	cmp	x20, x1
10153ff34:     	b.hs	0x1015402e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd2c>
10153ff38:     	ldr	x8, [x22, #0x450]
10153ff3c:     	add	x8, x8, x20, lsl #6
10153ff40:     	ldr	w10, [x8, #0x18]
10153ff44:     	cmp	w10, #0x4
10153ff48:     	b.ne	0x10153ffa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9e8>
10153ff4c:     	ldr	w2, [x8, #0x1c]
10153ff50:     	ldr	x8, [x22, #0x390]
10153ff54:     	cmp	x8, x2
10153ff58:     	b.ls	0x101540314 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd5c>
10153ff5c:     	ldr	x8, [x22, #0x388]
10153ff60:     	mov	w10, #0x180             ; =384
10153ff64:     	umaddl	x8, w2, w10, x8
10153ff68:     	ldp	x8, x10, [x8]
10153ff6c:     	mov	w11, #0x5               ; =5
10153ff70:     	eor	x8, x8, x11
10153ff74:     	orr	x8, x8, x10
10153ff78:     	cbnz	x8, 0x10153ffa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9e8>
10153ff7c:     	mov	x1, x9
10153ff80:     	add	x0, sp, #0x188
10153ff84:     	mov	w3, #0x2                ; =2
10153ff88:     	bl	0x10153f220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
10153ff8c:     	ldr	w8, [sp, #0x188]
10153ff90:     	cmp	w8, #0x6
10153ff94:     	b.ne	0x101540028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153ff98:     	ldr	x1, [x22, #0x458]
10153ff9c:     	mov	x9, x21
10153ffa0:     	cmp	x20, x1
10153ffa4:     	b.hs	0x1015402f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd3c>
10153ffa8:     	ldr	x8, [x22, #0x450]
10153ffac:     	add	x8, x8, x20, lsl #6
10153ffb0:     	ldr	w10, [x8, #0x18]
10153ffb4:     	cmp	w10, #0x4
10153ffb8:     	b.ne	0x101540198 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbe0>
10153ffbc:     	ldr	w2, [x8, #0x1c]
10153ffc0:     	ldr	x1, [x22, #0x390]
10153ffc4:     	cmp	x1, x2
10153ffc8:     	b.ls	0x10154032c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd74>
10153ffcc:     	ldr	x8, [x22, #0x388]
10153ffd0:     	mov	w10, #0x180             ; =384
10153ffd4:     	umaddl	x8, w2, w10, x8
10153ffd8:     	ldp	x8, x10, [x8]
10153ffdc:     	cmp	x8, #0x3
10153ffe0:     	sbcs	xzr, x10, xzr
10153ffe4:     	b.hs	0x101540198 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbe0>
10153ffe8:     	ldr	x12, [x9, #0x490]
10153ffec:     	ldr	x8, [x12, #0x1e0]
10153fff0:     	ldr	d0, [x12, #0x1e8]
10153fff4:     	ldrb	w9, [x12, #0x1f0]
10153fff8:     	ldp	x10, x11, [x12, #0x1f8]
10153fffc:     	mov	x13, #-0x8000000000000000 ; =-9223372036854775808
101540000:     	str	x13, [x12, #0x1e0]
101540004:     	cmp	x8, x13
101540008:     	b.ne	0x1015400b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xafc>
10154000c:     	str	wzr, [x19]
101540010:     	mov	w8, #0xc                ; =12
101540014:     	strb	w8, [x19, #0x8]
101540018:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
10154001c:     	add	x8, x8, #0xb8
101540020:     	mov	w9, #0x1d               ; =29
101540024:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101540028:     	ldur	q0, [x27, #0x68]
10154002c:     	ldur	q1, [x27, #0x78]
101540030:     	ldur	q2, [x27, #0x88]
101540034:     	stp	q1, q2, [x19, #0x20]
101540038:     	ldur	q1, [x27, #0x98]
10154003c:     	str	q1, [x19, #0x40]
101540040:     	ldur	q1, [x27, #0x58]
101540044:     	stp	q1, q0, [x19]
101540048:     	b	0x10153f658 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10154004c:     	ldur	q0, [x27, #0x58]
101540050:     	ldur	q1, [x27, #0x68]
101540054:     	stp	q0, q1, [x29, #-0xb0]
101540058:     	ldr	x8, [sp, #0x1a8]
10154005c:     	stur	x8, [x29, #-0x90]
101540060:     	add	x9, x24, #0x148
101540064:     	ldr	w10, [x24, #0x158]
101540068:     	stur	w10, [x29, #-0x70]
10154006c:     	ldr	q2, [x9]
101540070:     	stur	q2, [x29, #-0x80]
101540074:     	mov	w9, #0x4                ; =4
101540078:     	str	w9, [x19]
10154007c:     	stur	q2, [x19, #0x4]
101540080:     	str	w10, [x19, #0x14]
101540084:     	stur	q0, [x19, #0x18]
101540088:     	stur	q1, [x19, #0x28]
10154008c:     	str	x8, [x19, #0x38]
101540090:     	b	0x10153f658 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101540094:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
101540098:     	add	x8, x8, #0xf2a
10154009c:     	mov	w9, #0x2c               ; =44
1015400a0:     	b	0x10153fe40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x888>
1015400a4:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0xf83>
1015400a8:     	add	x8, x8, #0xf56
1015400ac:     	mov	w9, #0x31               ; =49
1015400b0:     	b	0x10153fe40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x888>
1015400b4:     	add	x13, sp, #0x28
1015400b8:     	add	x14, x12, #0x238
1015400bc:     	add	x15, x12, #0x208
1015400c0:     	ldp	q1, q2, [x15]
1015400c4:     	stp	q1, q2, [sp, #0x50]
1015400c8:     	ldr	q4, [x15, #0x20]
1015400cc:     	ldp	q1, q2, [x14, #0x90]
1015400d0:     	stur	q2, [x13, #0xf8]
1015400d4:     	ldr	q2, [x14, #0x80]
1015400d8:     	stur	q1, [x13, #0xe8]
1015400dc:     	stur	q2, [x13, #0xd8]
1015400e0:     	ldp	q2, q1, [x14, #0x60]
1015400e4:     	stur	q1, [x13, #0xc8]
1015400e8:     	stur	q2, [x13, #0xb8]
1015400ec:     	ldp	q2, q1, [x14, #0x40]
1015400f0:     	stur	q1, [x13, #0xa8]
1015400f4:     	stur	q2, [x13, #0x98]
1015400f8:     	ldp	q2, q1, [x14, #0x20]
1015400fc:     	stur	q1, [x13, #0x88]
101540100:     	ldp	q1, q3, [x14]
101540104:     	stp	q4, q1, [sp, #0x70]
101540108:     	stur	q3, [sp, #0x90]
10154010c:     	add	x14, x12, #0x1f1
101540110:     	ldr	w12, [x12, #0x1f4]
101540114:     	str	w12, [sp, #0x3c]
101540118:     	ldr	w12, [x14]
10154011c:     	stur	w12, [sp, #0x39]
101540120:     	stur	q2, [x13, #0x78]
101540124:     	str	x8, [sp, #0x28]
101540128:     	str	d0, [sp, #0x30]
10154012c:     	strb	w9, [sp, #0x38]
101540130:     	stp	x10, x11, [sp, #0x40]
101540134:     	str	x21, [sp, #0x188]
101540138:     	add	x8, sp, #0x130
10154013c:     	add	x0, sp, #0x28
101540140:     	add	x1, sp, #0x188
101540144:     	bl	0x101590190 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections8lifetimeNtB4_5State14release_source>
101540148:     	add	x0, sp, #0x188
10154014c:     	add	x1, sp, #0x28
101540150:     	mov	w2, #0x108              ; =264
101540154:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
101540158:     	ldr	x8, [x21, #0x490]
10154015c:     	ldr	x9, [x8, #0x1e0]
101540160:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101540164:     	cmp	x9, x10
101540168:     	b.eq	0x101540178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbc0>
10154016c:     	add	x0, x8, #0x1e0
101540170:     	bl	0x101525a00 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101540174:     	ldr	x8, [x21, #0x490]
101540178:     	add	x0, x8, #0x1e0
10154017c:     	add	x1, sp, #0x188
101540180:     	mov	w2, #0x108              ; =264
101540184:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
101540188:     	ldr	w8, [sp, #0x130]
10154018c:     	cmp	w8, #0x6
101540190:     	b.ne	0x10154023c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc84>
101540194:     	mov	x9, x21
101540198:     	ldr	x20, [x9, #0x490]
10154019c:     	ldrb	w8, [x20, #0x338]
1015401a0:     	tbz	w8, #0x0, 0x101540210 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc58>
1015401a4:     	ldr	x8, [x20, #0x1e0]
1015401a8:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015401ac:     	cmp	x8, x9
1015401b0:     	b.eq	0x1015401c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc08>
1015401b4:     	add	x0, x20, #0x1e0
1015401b8:     	bl	0x101587460 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collectionsNtB2_5State11is_complete>
1015401bc:     	tbz	w0, #0x0, 0x101540220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc68>
1015401c0:     	ldr	x8, [x20, #0x10]
1015401c4:     	cmp	x8, #0x2
1015401c8:     	b.eq	0x1015401ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc34>
1015401cc:     	ldr	x8, [x20, #0xa8]
1015401d0:     	cbz	x8, 0x1015401ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc34>
1015401d4:     	str	wzr, [x19]
1015401d8:     	mov	w8, #0xc                ; =12
1015401dc:     	strb	w8, [x19, #0x8]
1015401e0:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
1015401e4:     	add	x8, x8, #0x827
1015401e8:     	b	0x101540234 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc7c>
1015401ec:     	ldr	x8, [x21, #0x4c8]
1015401f0:     	cbz	x8, 0x101540210 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc58>
1015401f4:     	str	wzr, [x19]
1015401f8:     	mov	w8, #0xc                ; =12
1015401fc:     	strb	w8, [x19, #0x8]
101540200:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540204:     	add	x8, x8, #0x7fe
101540208:     	mov	w9, #0x29               ; =41
10154020c:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101540210:     	strb	wzr, [x20, #0x460]
101540214:     	mov	w8, #0x6                ; =6
101540218:     	str	w8, [x19]
10154021c:     	b	0x10153f658 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101540220:     	str	wzr, [x19]
101540224:     	mov	w8, #0xc                ; =12
101540228:     	strb	w8, [x19, #0x8]
10154022c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x1170>
101540230:     	add	x8, x8, #0x853
101540234:     	mov	w9, #0x2c               ; =44
101540238:     	b	0x10153f654 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10154023c:     	add	x9, sp, #0x130
101540240:     	ldur	q0, [x9, #0x14]
101540244:     	stur	q0, [x19, #0x14]
101540248:     	ldur	q0, [x9, #0x24]
10154024c:     	stur	q0, [x19, #0x24]
101540250:     	ldur	q0, [x9, #0x34]
101540254:     	stur	q0, [x19, #0x34]
101540258:     	ldr	q0, [sp, #0x170]
10154025c:     	str	q0, [x19, #0x40]
101540260:     	ldur	q0, [x9, #0x4]
101540264:     	stur	q0, [x19, #0x4]
101540268:     	b	0x101540218 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc60>
10154026c:     	adrp	x8, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540270:     	add	x8, x8, #0x640
101540274:     	mov	x0, x2
101540278:     	mov	x2, x8
10154027c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540280:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540284:     	add	x2, x2, #0x658
101540288:     	mov	x0, x25
10154028c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540290:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101540294:     	add	x2, x2, #0x260
101540298:     	mov	x0, #0x0                ; =0
10154029c:     	mov	x1, #0x0                ; =0
1015402a0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015402a4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015402a8:     	add	x2, x2, #0xb48
1015402ac:     	mov	x0, x8
1015402b0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015402b4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015402b8:     	add	x2, x2, #0xc68
1015402bc:     	mov	x0, x8
1015402c0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015402c4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015402c8:     	add	x2, x2, #0x670
1015402cc:     	mov	x0, x8
1015402d0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015402d4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015402d8:     	add	x2, x2, #0x688
1015402dc:     	mov	x0, x20
1015402e0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015402e4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015402e8:     	add	x2, x2, #0x6a0
1015402ec:     	mov	x0, x20
1015402f0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015402f4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015402f8:     	add	x2, x2, #0x6d0
1015402fc:     	mov	x0, x20
101540300:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540304:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540308:     	add	x2, x2, #0xc80
10154030c:     	mov	x0, x9
101540310:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540314:     	adrp	x9, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540318:     	add	x9, x9, #0x6b8
10154031c:     	mov	x0, x2
101540320:     	mov	x1, x8
101540324:     	mov	x2, x9
101540328:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154032c:     	adrp	x8, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540330:     	add	x8, x8, #0x6e8
101540334:     	mov	x0, x2
101540338:     	mov	x2, x8
10154033c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540340:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101540344:     	add	x2, x2, #0x278
101540348:     	mov	x1, x8
10154034c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540350:     	mov	x19, x0
101540354:     	ldr	x8, [x21, #0x490]
101540358:     	add	x0, x8, #0x1e0
10154035c:     	add	x1, sp, #0x188
101540360:     	mov	w2, #0x108              ; =264
101540364:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
101540368:     	ldr	w8, [sp, #0x130]
10154036c:     	cmp	w8, #0x6
101540370:     	b.eq	0x1015403a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xdec>
101540374:     	add	x0, sp, #0x130
101540378:     	bl	0x101525710 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10154037c:     	mov	x0, x19
101540380:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
101540384:     	mov	x19, x0
101540388:     	add	x0, sp, #0x28
10154038c:     	bl	0x101525a00 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101540390:     	b	0x1015403a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xdec>
101540394:     	bl	0x103a0248c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101540398:     	mov	x19, x0
10154039c:     	mov	w8, #0x2                ; =2
1015403a0:     	str	x8, [x21, #0x220]
1015403a4:     	mov	x0, x19
1015403a8:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
1015403ac:     	mov	x19, x0
1015403b0:     	add	x0, sp, #0x188
1015403b4:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
1015403b8:     	mov	x0, x19
1015403bc:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
1015403c0:     	mov	x19, x0
1015403c4:     	add	x0, sp, #0x188
1015403c8:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
1015403cc:     	mov	x0, x19
1015403d0:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
