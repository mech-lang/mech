
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101527d88 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>:
101527d88:     	ldp	x9, x8, [x0]
101527d8c:     	cmp	x9, x8
101527d90:     	b.eq	0x101527e08 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x80>
101527d94:     	ldp	x12, x11, [x1]
101527d98:     	mov	w13, #0x18              ; =24
101527d9c:     	ldr	x14, [x1, #0x28]
101527da0:     	b	0x101527dac <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x24>
101527da4:     	cmp	x9, x8
101527da8:     	b.eq	0x101527df4 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x6c>
101527dac:     	mov	x10, x9
101527db0:     	ldr	w15, [x9], #0x4
101527db4:     	cmp	x11, x15
101527db8:     	b.ls	0x101527da4 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
101527dbc:     	umaddl	x15, w15, w13, x12
101527dc0:     	ldr	x16, [x15]
101527dc4:     	cmp	x16, #0x1
101527dc8:     	b.ne	0x101527da4 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
101527dcc:     	ldp	x16, x15, [x15, #0x8]
101527dd0:     	add	x15, x15, x16
101527dd4:     	cmp	x15, x16
101527dd8:     	ccmp	x15, x14, #0x2, hs
101527ddc:     	b.hi	0x101527da4 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
101527de0:     	mov	w8, #0x1                ; =1
101527de4:     	add	x9, x10, #0x4
101527de8:     	str	x9, [x0]
101527dec:     	mov	x0, x8
101527df0:     	ret
101527df4:     	mov	w8, #0x0                ; =0
101527df8:     	add	x9, x10, #0x4
101527dfc:     	str	x9, [x0]
101527e00:     	mov	x0, x8
101527e04:     	ret
101527e08:     	mov	w0, #0x0                ; =0
101527e0c:     	ret
