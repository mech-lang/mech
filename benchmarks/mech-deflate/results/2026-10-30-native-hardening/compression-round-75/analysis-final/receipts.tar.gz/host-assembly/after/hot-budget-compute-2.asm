
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102373d1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
102373d1c:     	stp	x28, x27, [sp, #-0x60]!
102373d20:     	stp	x26, x25, [sp, #0x10]
102373d24:     	stp	x24, x23, [sp, #0x20]
102373d28:     	stp	x22, x21, [sp, #0x30]
102373d2c:     	stp	x20, x19, [sp, #0x40]
102373d30:     	stp	x29, x30, [sp, #0x50]
102373d34:     	add	x29, sp, #0x50
102373d38:     	sub	sp, sp, #0x1a0
102373d3c:     	ldr	x9, [x0, #0xd0]
102373d40:     	adds	x13, x9, x1
102373d44:     	b.hs	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373d48:     	ldr	x21, [x0, #0xc8]
102373d4c:     	ldr	x26, [x0, #0xe8]
102373d50:     	ldr	x28, [x0, #0xf8]
102373d54:     	ldr	x25, [x0, #0x108]
102373d58:     	ldp	x22, x23, [x0, #0x118]
102373d5c:     	ldr	x9, [x0]
102373d60:     	cmp	x9, #0x1
102373d64:     	b.ne	0x102373dd0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
102373d68:     	cmp	x23, #0x10, lsl #12     ; =0x10000
102373d6c:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373d70:     	mov	w9, #0x1000000          ; =16777216
102373d74:     	cmp	x26, x9
102373d78:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373d7c:     	mov	w9, #0x1000000          ; =16777216
102373d80:     	cmp	x13, x9
102373d84:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373d88:     	mov	w9, #0x1000000          ; =16777216
102373d8c:     	cmp	x28, x9
102373d90:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373d94:     	mov	w9, #0x1000000          ; =16777216
102373d98:     	cmp	x25, x9
102373d9c:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373da0:     	cmp	x22, #0x10, lsl #12     ; =0x10000
102373da4:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373da8:     	cmp	x21, #0x10, lsl #12     ; =0x10000
102373dac:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373db0:     	ldr	x9, [x0, #0x8]
102373db4:     	cmp	x13, x9
102373db8:     	b.hi	0x102373dc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373dbc:     	ldr	x9, [x0, #0x10]
102373dc0:     	cmp	x21, x9
102373dc4:     	b.ls	0x102373f08 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102373dc8:     	mov	w9, #0x2                ; =2
102373dcc:     	b	0x102373f10 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f4>
102373dd0:     	ldp	x24, x2, [x0, #0xd8]
102373dd4:     	ldr	x20, [x0, #0xf0]
102373dd8:     	ldr	x9, [x0, #0x100]
102373ddc:     	ldr	x1, [x0, #0x110]
102373de0:     	ldr	x15, [x0, #0x128]
102373de4:     	ldr	x27, [x0, #0x18]
102373de8:     	cmp	x27, #0x2
102373dec:     	b.ne	0x102373e60 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x144>
102373df0:     	mov	x19, x0
102373df4:     	mov	x27, x8
102373df8:     	stp	x21, x13, [x29, #-0xf0]
102373dfc:     	mov	x21, x13
102373e00:     	stp	x24, x2, [x29, #-0xe0]
102373e04:     	stp	x26, x20, [x29, #-0xd0]
102373e08:     	stp	x28, x9, [x29, #-0xc0]
102373e0c:     	stp	x25, x1, [x29, #-0xb0]
102373e10:     	stp	x22, x23, [x29, #-0xa0]
102373e14:     	stur	x15, [x29, #-0x90]
102373e18:     	sub	x8, x29, #0x88
102373e1c:     	sub	x0, x29, #0xf0
102373e20:     	bl	0x102381028 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102373e24:     	ldurb	w8, [x29, #-0x88]
102373e28:     	cmp	w8, #0x8
102373e2c:     	b.ne	0x102373edc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1c0>
102373e30:     	add	x0, sp, #0xd0
102373e34:     	sub	x1, x29, #0xf0
102373e38:     	bl	0x10236f414 <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
102373e3c:     	mov	x8, x27
102373e40:     	ldrb	w9, [sp, #0xd0]
102373e44:     	cmp	w9, #0x8
102373e48:     	b.eq	0x102373f00 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e4>
102373e4c:     	ldp	q0, q1, [sp, #0xd0]
102373e50:     	stp	q0, q1, [x8]
102373e54:     	ldr	x9, [sp, #0xf0]
102373e58:     	str	x9, [x8, #0x20]
102373e5c:     	b	0x102373f14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102373e60:     	str	x9, [sp, #0xc0]
102373e64:     	ldr	x10, [x0, #0x20]
102373e68:     	ldp	x11, x9, [x0, #0x38]
102373e6c:     	stp	x9, x10, [sp, #0xb0]
102373e70:     	ldp	x10, x9, [x0, #0x48]
102373e74:     	stp	x9, x11, [sp, #0xa0]
102373e78:     	ldr	x9, [x0, #0x58]
102373e7c:     	stp	x9, x10, [sp, #0x90]
102373e80:     	ldp	x10, x9, [x0, #0x60]
102373e84:     	str	x9, [sp, #0x88]
102373e88:     	ldp	x11, x9, [x0, #0x70]
102373e8c:     	stp	x0, x9, [sp, #0x78]
102373e90:     	ldp	x6, x12, [x0, #0x80]
102373e94:     	ldp	x4, x7, [x0, #0x90]
102373e98:     	ldr	x3, [x0, #0xa0]
102373e9c:     	ldp	w5, w14, [x0, #0xb8]
102373ea0:     	ldr	x9, [x0, #0xc0]
102373ea4:     	str	x9, [sp, #0xc8]
102373ea8:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
102373eac:     	add	x0, x0, #0x550
102373eb0:     	ldr	x9, [x0]
102373eb4:     	blr	x9
102373eb8:     	mov	x19, x0
102373ebc:     	ldrb	w9, [x0, #0x48]
102373ec0:     	cmp	w9, #0x1
102373ec4:     	b.eq	0x102373f90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x274>
102373ec8:     	cmp	w9, #0x2
102373ecc:     	b.ne	0x102373f34 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x218>
102373ed0:     	adrp	x0, 0x108032000 <_anon.b751fc49bcc701379c8af7be5d8e914b.25>
102373ed4:     	add	x0, x0, #0x610
102373ed8:     	bl	0x103a01cf4 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102373edc:     	sub	x8, x29, #0x88
102373ee0:     	ldp	q0, q1, [x8]
102373ee4:     	stp	q0, q1, [sp, #0xd0]
102373ee8:     	ldur	x8, [x29, #-0x68]
102373eec:     	str	x8, [sp, #0xf0]
102373ef0:     	mov	x8, x27
102373ef4:     	ldrb	w9, [sp, #0xd0]
102373ef8:     	cmp	w9, #0x8
102373efc:     	b.ne	0x102373e4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x130>
102373f00:     	mov	x0, x19
102373f04:     	mov	x13, x21
102373f08:     	str	x13, [x0, #0xd0]
102373f0c:     	mov	w9, #0x8                ; =8
102373f10:     	strb	w9, [x8]
102373f14:     	add	sp, sp, #0x1a0
102373f18:     	ldp	x29, x30, [sp, #0x50]
102373f1c:     	ldp	x20, x19, [sp, #0x40]
102373f20:     	ldp	x22, x21, [sp, #0x30]
102373f24:     	ldp	x24, x23, [sp, #0x20]
102373f28:     	ldp	x26, x25, [sp, #0x10]
102373f2c:     	ldp	x28, x27, [sp], #0x60
102373f30:     	ret
102373f34:     	stp	x1, x15, [sp, #0x10]
102373f38:     	adrp	x1, 0x102362000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTmmENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1h_11collections5btree3mapINtB24_8BTreeMapmmEINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtB31_8adapters12GenericShuntINtNtB3W_3map3MapINtNtB3W_9enumerate9EnumerateINtNtB3W_6filter6FilterIB4H_INtNtB8_4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine16source_semantics8frontend11PendingNodeEENCNvMs0_NtB5V_11applicationNtB5V_15SemanticBuilder19counted_applications7_0EENCB78_s8_0EINtNtBa_6result6ResultNtNtBa_7convert10InfallibleNtB5V_19SourceSemanticErrorEEE0E0EB5Z_+0x180>
102373f3c:     	add	x1, x1, #0xd08
102373f40:     	mov	x0, x19
102373f44:     	str	x8, [sp, #0x20]
102373f48:     	stp	x6, x13, [sp, #0x50]
102373f4c:     	stp	x14, x7, [sp, #0x30]
102373f50:     	str	x2, [sp, #0x8]
102373f54:     	stp	x3, x4, [sp, #0x40]
102373f58:     	str	w5, [sp, #0x2c]
102373f5c:     	stp	x12, x11, [sp, #0x60]
102373f60:     	str	x10, [sp, #0x70]
102373f64:     	bl	0x102e6e6cc <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102373f68:     	ldp	x11, x10, [sp, #0x68]
102373f6c:     	ldp	x13, x12, [sp, #0x58]
102373f70:     	ldp	x7, x3, [sp, #0x38]
102373f74:     	ldp	x4, x6, [sp, #0x48]
102373f78:     	ldr	w5, [sp, #0x2c]
102373f7c:     	ldp	x2, x1, [sp, #0x8]
102373f80:     	ldp	x15, x8, [sp, #0x18]
102373f84:     	ldr	x14, [sp, #0x30]
102373f88:     	mov	w9, #0x1                ; =1
102373f8c:     	strb	w9, [x19, #0x48]
102373f90:     	str	x10, [sp, #0x70]
102373f94:     	ldr	x9, [x19]
102373f98:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102373f9c:     	cmp	x9, x10
102373fa0:     	b.hs	0x1023741b0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x494>
102373fa4:     	add	x10, x9, #0x1
102373fa8:     	str	x10, [x19]
102373fac:     	ldr	x10, [x19, #0x8]
102373fb0:     	cbz	x10, 0x102374058 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x33c>
102373fb4:     	stp	x12, x11, [sp, #0x60]
102373fb8:     	ldr	x11, [x10, #0x10]
102373fbc:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
102373fc0:     	cmp	x11, x12
102373fc4:     	b.hs	0x1023741bc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x4a0>
102373fc8:     	ldr	x10, [x10, #0x58]
102373fcc:     	str	x9, [x19]
102373fd0:     	ldr	x9, [sp, #0xc8]
102373fd4:     	cmp	x10, x9
102373fd8:     	b.ne	0x10237405c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x340>
102373fdc:     	stp	x7, x3, [sp, #0x38]
102373fe0:     	stp	x4, x6, [sp, #0x48]
102373fe4:     	str	w5, [sp, #0x2c]
102373fe8:     	str	x14, [sp, #0x30]
102373fec:     	mov	x19, x8
102373ff0:     	stp	x21, x13, [x29, #-0xf0]
102373ff4:     	str	x13, [sp, #0x58]
102373ff8:     	stp	x24, x2, [x29, #-0xe0]
102373ffc:     	mov	x24, x2
102374000:     	stp	x26, x20, [x29, #-0xd0]
102374004:     	ldr	x8, [sp, #0xc0]
102374008:     	stp	x28, x8, [x29, #-0xc0]
10237400c:     	stp	x25, x1, [x29, #-0xb0]
102374010:     	mov	x26, x1
102374014:     	stp	x22, x23, [x29, #-0xa0]
102374018:     	mov	x20, x15
10237401c:     	stur	x15, [x29, #-0x90]
102374020:     	sub	x8, x29, #0x88
102374024:     	sub	x0, x29, #0xf0
102374028:     	bl	0x102381028 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
10237402c:     	ldurb	w8, [x29, #-0x88]
102374030:     	cmp	w8, #0x8
102374034:     	b.ne	0x102374064 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102374038:     	cmp	x27, #0x1
10237403c:     	mov	x8, x19
102374040:     	ldr	x11, [sp, #0xb8]
102374044:     	b.ne	0x10237407c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102374048:     	cmp	x23, x11
10237404c:     	b.ls	0x10237407c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102374050:     	mov	w9, #0x0                ; =0
102374054:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102374058:     	str	x9, [x19]
10237405c:     	strb	wzr, [x8]
102374060:     	b	0x102373f14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102374064:     	sub	x8, x29, #0x88
102374068:     	ldp	q0, q1, [x8]
10237406c:     	stp	q0, q1, [x19]
102374070:     	ldur	x8, [x29, #-0x68]
102374074:     	str	x8, [x19, #0x20]
102374078:     	b	0x102373f14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10237407c:     	ldp	x9, x11, [sp, #0xa8]
102374080:     	cmp	x9, #0x1
102374084:     	b.ne	0x10237409c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102374088:     	cmp	x28, x11
10237408c:     	b.ls	0x10237409c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102374090:     	mov	w9, #0x2                ; =2
102374094:     	mov	x23, x28
102374098:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10237409c:     	ldp	x9, x11, [sp, #0x98]
1023740a0:     	cmp	x9, #0x1
1023740a4:     	b.ne	0x1023740bc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
1023740a8:     	cmp	x25, x11
1023740ac:     	b.ls	0x1023740bc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
1023740b0:     	mov	w9, #0x3                ; =3
1023740b4:     	mov	x23, x25
1023740b8:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
1023740bc:     	ldr	x9, [sp, #0x90]
1023740c0:     	cmp	x9, #0x1
1023740c4:     	ldr	x11, [sp, #0x70]
1023740c8:     	b.ne	0x1023740e0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
1023740cc:     	cmp	x22, x11
1023740d0:     	b.ls	0x1023740e0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
1023740d4:     	mov	w9, #0x4                ; =4
1023740d8:     	mov	x23, x22
1023740dc:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
1023740e0:     	ldr	x9, [sp, #0x88]
1023740e4:     	cmp	x9, #0x1
1023740e8:     	ldr	x11, [sp, #0x68]
1023740ec:     	b.ne	0x102374104 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
1023740f0:     	cmp	x21, x11
1023740f4:     	b.ls	0x102374104 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
1023740f8:     	mov	w9, #0x5                ; =5
1023740fc:     	mov	x23, x21
102374100:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102374104:     	ldr	x9, [sp, #0x80]
102374108:     	cmp	x9, #0x1
10237410c:     	ldp	x11, x13, [sp, #0x50]
102374110:     	b.ne	0x102374128 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
102374114:     	cmp	x13, x11
102374118:     	b.ls	0x102374128 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
10237411c:     	mov	w9, #0x6                ; =6
102374120:     	mov	x23, x13
102374124:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102374128:     	ldr	x9, [sp, #0x60]
10237412c:     	cmp	x9, #0x1
102374130:     	ldr	x11, [sp, #0x48]
102374134:     	b.ne	0x10237414c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102374138:     	cmp	x24, x11
10237413c:     	b.ls	0x10237414c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102374140:     	mov	w9, #0x7                ; =7
102374144:     	mov	x23, x24
102374148:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10237414c:     	ldp	x9, x11, [sp, #0x38]
102374150:     	cmp	x9, #0x1
102374154:     	b.ne	0x102374170 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102374158:     	mov	x24, x26
10237415c:     	cmp	x26, x11
102374160:     	b.ls	0x102374170 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102374164:     	mov	w9, #0x8                ; =8
102374168:     	mov	x23, x24
10237416c:     	b	0x102374194 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102374170:     	ldr	w9, [sp, #0x2c]
102374174:     	cmp	w9, #0x1
102374178:     	ldr	x0, [sp, #0x78]
10237417c:     	ldr	x11, [sp, #0x30]
102374180:     	b.ne	0x102373f08 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102374184:     	cmp	w11, w20
102374188:     	b.hs	0x102373f08 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10237418c:     	mov	w23, w20
102374190:     	mov	w9, #0xa                ; =10
102374194:     	mov	w10, #0x6               ; =6
102374198:     	strb	w10, [x8]
10237419c:     	strb	w9, [x8, #0x1]
1023741a0:     	mov	w9, #0x1                ; =1
1023741a4:     	strb	w9, [x8, #0x2]
1023741a8:     	stp	x23, x11, [x8, #0x8]
1023741ac:     	b	0x102373f14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
1023741b0:     	adrp	x0, 0x108033000 <_anon.b751fc49bcc701379c8af7be5d8e914b.242+0x8>
1023741b4:     	add	x0, x0, #0xac0
1023741b8:     	bl	0x103a023a8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1023741bc:     	adrp	x0, 0x108033000 <_anon.b751fc49bcc701379c8af7be5d8e914b.242+0x8>
1023741c0:     	add	x0, x0, #0xad8
1023741c4:     	bl	0x103a023a8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1023741c8:     	brk	#0x1
1023741cc:     	ldr	x8, [x19]
1023741d0:     	sub	x8, x8, #0x1
1023741d4:     	str	x8, [x19]
1023741d8:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
