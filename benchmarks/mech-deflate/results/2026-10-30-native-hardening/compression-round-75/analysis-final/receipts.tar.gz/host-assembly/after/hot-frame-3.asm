
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152841c <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>:
10152841c:     	stp	x20, x19, [sp, #-0x20]!
101528420:     	stp	x29, x30, [sp, #0x10]
101528424:     	add	x29, sp, #0x10
101528428:     	mov	x19, x4
10152842c:     	cmp	x3, x2
101528430:     	b.hs	0x101528480 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_+0x64>
101528434:     	mov	w8, #0x170              ; =368
101528438:     	madd	x8, x3, x8, x1
10152843c:     	add	x9, x8, #0x148
101528440:     	ldr	q0, [x9]
101528444:     	stur	q0, [x0, #0x4]
101528448:     	ldp	q0, q1, [x19]
10152844c:     	stur	q0, [x0, #0x18]
101528450:     	ldr	w8, [x8, #0x158]
101528454:     	str	w8, [x0, #0x14]
101528458:     	stur	q1, [x0, #0x28]
10152845c:     	ldr	q0, [x19, #0x20]
101528460:     	stur	q0, [x0, #0x38]
101528464:     	ldr	x8, [x19, #0x30]
101528468:     	str	x8, [x0, #0x48]
10152846c:     	mov	w8, #0x3                ; =3
101528470:     	str	w8, [x0]
101528474:     	ldp	x29, x30, [sp, #0x10]
101528478:     	ldp	x20, x19, [sp], #0x20
10152847c:     	ret
101528480:     	adrp	x8, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
101528484:     	add	x8, x8, #0xfd8
101528488:     	mov	x0, x3
10152848c:     	mov	x1, x2
101528490:     	mov	x2, x8
101528494:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101528498:     	brk	#0x1
10152849c:     	mov	x20, x0
1015284a0:     	mov	x0, x19
1015284a4:     	bl	0x1015258a4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015284a8:     	mov	x0, x20
1015284ac:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
