
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010236d3d4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
10236d3d4:     	sub	sp, sp, #0x80
10236d3d8:     	stp	x22, x21, [sp, #0x50]
10236d3dc:     	stp	x20, x19, [sp, #0x60]
10236d3e0:     	stp	x29, x30, [sp, #0x70]
10236d3e4:     	add	x29, sp, #0x70
10236d3e8:     	mov	x19, x8
10236d3ec:     	ldr	x20, [x0]
10236d3f0:     	ldr	x8, [x20, #0x10]
10236d3f4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10236d3f8:     	cmp	x8, x9
10236d3fc:     	b.hs	0x10236d45c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x88>
10236d400:     	ldr	x8, [x20, #0x38]
10236d404:     	adds	x8, x8, x1
10236d408:     	b.hs	0x10236d468 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
10236d40c:     	cmp	x8, x2
10236d410:     	b.ls	0x10236d42c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x58>
10236d414:     	mov	w9, #0x606              ; =1542
10236d418:     	strh	w9, [x19]
10236d41c:     	mov	w9, #0x1                ; =1
10236d420:     	strb	w9, [x19, #0x2]
10236d424:     	stp	x8, x2, [x19, #0x8]
10236d428:     	b	0x10236d5e4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x210>
10236d42c:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
10236d430:     	add	x0, x0, #0x550
10236d434:     	ldr	x8, [x0]
10236d438:     	blr	x8
10236d43c:     	ldrb	w8, [x0, #0x48]
10236d440:     	cmp	w8, #0x1
10236d444:     	b.eq	0x10236d498 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xc4>
10236d448:     	cmp	w8, #0x2
10236d44c:     	b.ne	0x10236d470 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x9c>
10236d450:     	adrp	x0, 0x108032000 <_anon.b751fc49bcc701379c8af7be5d8e914b.25>
10236d454:     	add	x0, x0, #0x610
10236d458:     	bl	0x103a01cf4 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10236d45c:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
10236d460:     	add	x0, x0, #0x130
10236d464:     	bl	0x103a023a8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236d468:     	mov	x8, #-0x1               ; =-1
10236d46c:     	b	0x10236d414 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x40>
10236d470:     	adrp	x8, 0x102362000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTmmENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1h_11collections5btree3mapINtB24_8BTreeMapmmEINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtB31_8adapters12GenericShuntINtNtB3W_3map3MapINtNtB3W_9enumerate9EnumerateINtNtB3W_6filter6FilterIB4H_INtNtB8_4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine16source_semantics8frontend11PendingNodeEENCNvMs0_NtB5V_11applicationNtB5V_15SemanticBuilder19counted_applications7_0EENCB78_s8_0EINtNtBa_6result6ResultNtNtBa_7convert10InfallibleNtB5V_19SourceSemanticErrorEEE0E0EB5Z_+0x180>
10236d474:     	add	x8, x8, #0xd08
10236d478:     	str	x0, [sp, #0x8]
10236d47c:     	mov	x21, x1
10236d480:     	mov	x1, x8
10236d484:     	bl	0x102e6e6cc <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10236d488:     	ldr	x0, [sp, #0x8]
10236d48c:     	mov	x1, x21
10236d490:     	mov	w8, #0x1                ; =1
10236d494:     	strb	w8, [x0, #0x48]
10236d498:     	ldr	x8, [x0, #0x20]
10236d49c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10236d4a0:     	cmp	x8, x9
10236d4a4:     	b.hs	0x10236d604 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
10236d4a8:     	ldr	x8, [x0, #0x28]
10236d4ac:     	cmp	x8, #0x0
10236d4b0:     	ccmp	x8, x20, #0x4, ne
10236d4b4:     	b.ne	0x10236d530 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x15c>
10236d4b8:     	ldr	x8, [x20, #0x10]
10236d4bc:     	cbnz	x8, 0x10236d610 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x23c>
10236d4c0:     	mov	x8, #-0x1               ; =-1
10236d4c4:     	str	x8, [x20, #0x10]
10236d4c8:     	ldr	w8, [x0, #0x30]
10236d4cc:     	ldp	x9, x10, [x0, #0x38]
10236d4d0:     	ldp	x11, x12, [x20, #0x60]
10236d4d4:     	cmp	x9, x11
10236d4d8:     	csel	x9, x9, x11, lo
10236d4dc:     	cmp	x10, x12
10236d4e0:     	csel	x10, x10, x12, lo
10236d4e4:     	tst	w8, #0x1
10236d4e8:     	csel	x9, x9, x11, ne
10236d4ec:     	csel	x13, x10, x12, ne
10236d4f0:     	ldr	x8, [x20, #0x38]
10236d4f4:     	adds	x21, x8, x1
10236d4f8:     	b.hs	0x10236d5f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x224>
10236d4fc:     	ldr	x8, [x20, #0x48]
10236d500:     	adds	x10, x8, x21
10236d504:     	b.hs	0x10236d5f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x224>
10236d508:     	ldr	x22, [x20, #0x40]
10236d50c:     	ldr	x8, [x20, #0x50]
10236d510:     	adds	x14, x8, x22
10236d514:     	b.hs	0x10236d5f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x224>
10236d518:     	cmp	x10, x9
10236d51c:     	b.ls	0x10236d538 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x164>
10236d520:     	mov	w12, #0x6               ; =6
10236d524:     	mov	w11, #0x1               ; =1
10236d528:     	mov	w8, #0x6                ; =6
10236d52c:     	b	0x10236d5b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1dc>
10236d530:     	mov	w8, #0x0                ; =0
10236d534:     	b	0x10236d5bc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1e8>
10236d538:     	cmp	x14, x13
10236d53c:     	b.ls	0x10236d558 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x184>
10236d540:     	mov	w8, #0x6                ; =6
10236d544:     	mov	w12, #0x5               ; =5
10236d548:     	mov	w11, #0x1               ; =1
10236d54c:     	mov	x9, x13
10236d550:     	mov	x10, x14
10236d554:     	b	0x10236d5b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1dc>
10236d558:     	ldr	x8, [x20, #0x70]
10236d55c:     	cbz	x8, 0x10236d580 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1ac>
10236d560:     	add	x0, sp, #0x28
10236d564:     	mov	x2, x1
10236d568:     	mov	x1, x8
10236d56c:     	mov	x3, #0x0                ; =0
10236d570:     	bl	0x10236e80c <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
10236d574:     	ldrb	w8, [sp, #0x28]
10236d578:     	cmp	w8, #0x8
10236d57c:     	b.ne	0x10236d58c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1b8>
10236d580:     	stp	x21, x22, [x20, #0x38]
10236d584:     	mov	w8, #0x8                ; =8
10236d588:     	b	0x10236d5b0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1dc>
10236d58c:     	ldrb	w12, [sp, #0x29]
10236d590:     	ldrb	w11, [sp, #0x2a]
10236d594:     	ldur	w9, [sp, #0x2b]
10236d598:     	str	w9, [sp, #0x20]
10236d59c:     	ldrb	w9, [sp, #0x2f]
10236d5a0:     	strb	w9, [sp, #0x24]
10236d5a4:     	ldp	x10, x9, [sp, #0x30]
10236d5a8:     	ldur	q0, [sp, #0x40]
10236d5ac:     	str	q0, [sp, #0x10]
10236d5b0:     	ldr	x13, [x20, #0x10]
10236d5b4:     	add	x13, x13, #0x1
10236d5b8:     	str	x13, [x20, #0x10]
10236d5bc:     	strb	w8, [x19]
10236d5c0:     	strb	w12, [x19, #0x1]
10236d5c4:     	strb	w11, [x19, #0x2]
10236d5c8:     	ldr	w8, [sp, #0x20]
10236d5cc:     	stur	w8, [x19, #0x3]
10236d5d0:     	ldrb	w8, [sp, #0x24]
10236d5d4:     	strb	w8, [x19, #0x7]
10236d5d8:     	stp	x10, x9, [x19, #0x8]
10236d5dc:     	ldr	q0, [sp, #0x10]
10236d5e0:     	stur	q0, [x19, #0x18]
10236d5e4:     	ldp	x29, x30, [sp, #0x70]
10236d5e8:     	ldp	x20, x19, [sp, #0x60]
10236d5ec:     	ldp	x22, x21, [sp, #0x50]
10236d5f0:     	add	sp, sp, #0x80
10236d5f4:     	ret
10236d5f8:     	mov	w8, #0x2                ; =2
10236d5fc:     	mov	w11, #0x1               ; =1
10236d600:     	b	0x10236d588 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1b4>
10236d604:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
10236d608:     	add	x0, x0, #0xe8
10236d60c:     	bl	0x103a023a8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236d610:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
10236d614:     	add	x0, x0, #0x100
10236d618:     	bl	0x103a02378 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10236d61c:     	ldr	x8, [x20, #0x10]
10236d620:     	add	x8, x8, #0x1
10236d624:     	str	x8, [x20, #0x10]
10236d628:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
