
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101621610 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>:
101621610:     	sub	sp, sp, #0x110
101621614:     	stp	x28, x27, [sp, #0xb0]
101621618:     	stp	x26, x25, [sp, #0xc0]
10162161c:     	stp	x24, x23, [sp, #0xd0]
101621620:     	stp	x22, x21, [sp, #0xe0]
101621624:     	stp	x20, x19, [sp, #0xf0]
101621628:     	stp	x29, x30, [sp, #0x100]
10162162c:     	add	x29, sp, #0x100
101621630:     	stp	x6, x0, [sp, #0x8]
101621634:     	mov	x22, x3
101621638:     	mov	x25, x1
10162163c:     	mov	x19, #0x0               ; =0
101621640:     	mov	x26, #0x0               ; =0
101621644:     	mov	x23, #0x0               ; =0
101621648:     	mov	x24, #0x0               ; =0
10162164c:     	ldp	x27, x9, [x4]
101621650:     	ldr	x10, [x4, #0x30]
101621654:     	ldp	x8, x11, [x4, #0x10]
101621658:     	stp	x11, x5, [sp, #0x38]
10162165c:     	str	x8, [sp, #0x20]
101621660:     	ldp	x8, x11, [x4, #0x20]
101621664:     	stp	x11, x10, [sp, #0x28]
101621668:     	str	x8, [sp, #0x18]
10162166c:     	lsl	x8, x2, #7
101621670:     	sub	x28, x8, x2, lsl #3
101621674:     	str	x9, [sp]
101621678:     	add	x21, x9, #0x1
10162167c:     	cmp	x28, x19
101621680:     	b.eq	0x101621838 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x228>
101621684:     	subs	x21, x21, #0x1
101621688:     	b.eq	0x1016218d0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2c0>
10162168c:     	ldrb	w8, [x27]
101621690:     	cmp	w8, #0x3
101621694:     	b.ne	0x10162176c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x15c>
101621698:     	ldr	x0, [x27, #0x8]
10162169c:     	ldr	x8, [sp, #0x38]
1016216a0:     	cmp	x0, x8
1016216a4:     	b.hs	0x1016218e4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2d4>
1016216a8:     	ldr	x8, [sp, #0x28]
1016216ac:     	cmp	x0, x8
1016216b0:     	b.hs	0x1016218f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2e4>
1016216b4:     	ldp	x9, x8, [sp, #0x18]
1016216b8:     	add	x20, x8, x0, lsl #6
1016216bc:     	ldr	x8, [x20]
1016216c0:     	ldr	x10, [x9, x0, lsl #3]
1016216c4:     	cbz	x8, 0x1016217a0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x190>
1016216c8:     	cbnz	x10, 0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016216cc:     	ldr	w9, [x20, #0x38]
1016216d0:     	add	x8, x25, x19
1016216d4:     	ldr	w10, [x8, #0x70]
1016216d8:     	cmp	w9, w10
1016216dc:     	b.ne	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016216e0:     	ldp	q0, q1, [x20, #0x10]
1016216e4:     	stp	q0, q1, [sp, #0x60]
1016216e8:     	ldp	x9, x10, [sp, #0x60]
1016216ec:     	ldp	x11, x12, [x8, #0x50]
1016216f0:     	ldp	x13, x14, [sp, #0x70]
1016216f4:     	ldp	x15, x8, [x8, #0x60]
1016216f8:     	cmp	x9, x11
1016216fc:     	ccmp	x10, x12, #0x0, eq
101621700:     	ccmp	x13, x15, #0x0, eq
101621704:     	ccmp	x14, x8, #0x0, eq
101621708:     	b.ne	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
10162170c:     	mov	x0, x20
101621710:     	ldr	x1, [sp, #0x40]
101621714:     	bl	0x102e10eec <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
101621718:     	cmp	x0, #0x1
10162171c:     	b.ne	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621720:     	add	x8, sp, #0x60
101621724:     	mov	x0, x20
101621728:     	mov	x1, x22
10162172c:     	bl	0x102e0efd0 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
101621730:     	ldrb	w8, [sp, #0x60]
101621734:     	cmp	w8, #0x16
101621738:     	b.ne	0x101621870 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x260>
10162173c:     	add	x8, sp, #0x60
101621740:     	add	x0, x25, x19
101621744:     	mov	x1, x20
101621748:     	mov	x2, x22
10162174c:     	bl	0x10236914c <__RNvMNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget15frame_footprintNtB2_28PreparedNativeFrameFootprint5value>
101621750:     	ldr	w8, [sp, #0x60]
101621754:     	tbz	w8, #0x0, 0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621758:     	ldp	x9, x8, [sp, #0x70]
10162175c:     	ldr	x10, [sp, #0x80]
101621760:     	adds	x26, x9, x26
101621764:     	b.lo	0x101621814 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x204>
101621768:     	b	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
10162176c:     	ldp	q0, q1, [x27]
101621770:     	stp	q0, q1, [sp, #0x60]
101621774:     	ldr	x8, [sp, #0x30]
101621778:     	ldr	x8, [x8]
10162177c:     	ldr	x1, [x8]
101621780:     	add	x0, sp, #0x48
101621784:     	add	x2, sp, #0x60
101621788:     	bl	0x1016360f8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
10162178c:     	ldr	x8, [sp, #0x48]
101621790:     	cmp	x8, #0x1
101621794:     	b.ne	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621798:     	ldp	x20, x10, [sp, #0x50]
10162179c:     	cbnz	x20, 0x1016216c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0xb8>
1016217a0:     	ldrb	w8, [x25, x19]
1016217a4:     	tbnz	w8, #0x0, 0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016217a8:     	add	x8, x25, x19
1016217ac:     	ldrb	w11, [x8, #0x1]
1016217b0:     	ldp	x9, x8, [x8, #0x10]
1016217b4:     	cmp	w11, #0x3
1016217b8:     	b.gt	0x1016217d4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1c4>
1016217bc:     	sub	w11, w11, #0x1
1016217c0:     	cmp	w11, #0x3
1016217c4:     	b.lo	0x101621804 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1016217c8:     	cmp	x10, #0x2
1016217cc:     	b.lo	0x101621804 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1016217d0:     	b	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016217d4:     	cmp	w11, #0x4
1016217d8:     	b.eq	0x1016217f0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1e0>
1016217dc:     	cmp	w11, #0x5
1016217e0:     	b.ne	0x1016217fc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1ec>
1016217e4:     	cmp	x10, #0x10, lsl #12     ; =0x10000
1016217e8:     	b.lo	0x101621804 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1016217ec:     	b	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016217f0:     	cmp	x10, #0xff
1016217f4:     	b.ls	0x101621804 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1016217f8:     	b	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016217fc:     	lsr	x10, x10, #32
101621800:     	cbnz	x10, 0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621804:     	add	x10, x25, x19
101621808:     	ldr	x10, [x10, #0x20]
10162180c:     	adds	x26, x9, x26
101621810:     	b.hs	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621814:     	adds	x23, x10, x23
101621818:     	cset	w9, hs
10162181c:     	adds	x24, x8, x24
101621820:     	cset	w8, hs
101621824:     	tbnz	w9, #0x0, 0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621828:     	add	x27, x27, #0x20
10162182c:     	add	x19, x19, #0x78
101621830:     	tbz	w8, #0x0, 0x10162167c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x6c>
101621834:     	b	0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621838:     	add	x8, sp, #0x60
10162183c:     	ldr	x0, [sp, #0x8]
101621840:     	mov	x1, x23
101621844:     	mov	x2, x24
101621848:     	bl	0x102375d5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter29try_charge_borrowed_footprint>
10162184c:     	ldrb	w9, [sp, #0x60]
101621850:     	ldrb	w8, [sp, #0x61]
101621854:     	cmp	w9, #0x8
101621858:     	b.ne	0x1016218a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x298>
10162185c:     	tbz	w8, #0x0, 0x101621878 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621860:     	mov	w8, #0x1                ; =1
101621864:     	ldr	x9, [sp, #0x10]
101621868:     	stp	x8, x26, [x9, #0x8]
10162186c:     	b	0x101621880 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x270>
101621870:     	add	x0, sp, #0x60
101621874:     	bl	0x101632cbc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
101621878:     	ldr	x9, [sp, #0x10]
10162187c:     	str	xzr, [x9, #0x8]
101621880:     	mov	w8, #0x8                ; =8
101621884:     	strb	w8, [x9]
101621888:     	ldp	x29, x30, [sp, #0x100]
10162188c:     	ldp	x20, x19, [sp, #0xf0]
101621890:     	ldp	x22, x21, [sp, #0xe0]
101621894:     	ldp	x24, x23, [sp, #0xd0]
101621898:     	ldp	x26, x25, [sp, #0xc0]
10162189c:     	ldp	x28, x27, [sp, #0xb0]
1016218a0:     	add	sp, sp, #0x110
1016218a4:     	ret
1016218a8:     	ldur	q0, [sp, #0x62]
1016218ac:     	ldr	x11, [sp, #0x10]
1016218b0:     	stur	q0, [x11, #0x2]
1016218b4:     	ldur	q0, [sp, #0x72]
1016218b8:     	stur	q0, [x11, #0x12]
1016218bc:     	ldr	x10, [sp, #0x80]
1016218c0:     	str	x10, [x11, #0x20]
1016218c4:     	strb	w9, [x11]
1016218c8:     	strb	w8, [x11, #0x1]
1016218cc:     	b	0x101621888 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x278>
1016218d0:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016218d4:     	add	x2, x2, #0xc0
1016218d8:     	ldr	x0, [sp]
1016218dc:     	mov	x1, x0
1016218e0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016218e4:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016218e8:     	add	x2, x2, #0xd8
1016218ec:     	ldr	x1, [sp, #0x38]
1016218f0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016218f4:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016218f8:     	add	x2, x2, #0xf0
1016218fc:     	ldr	x1, [sp, #0x28]
101621900:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
