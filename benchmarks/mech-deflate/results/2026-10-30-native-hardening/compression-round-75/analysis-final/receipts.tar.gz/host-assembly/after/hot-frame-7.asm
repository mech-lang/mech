
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101620f74 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_>:
101620f74:     	sub	sp, sp, #0x150
101620f78:     	stp	x28, x27, [sp, #0xf0]
101620f7c:     	stp	x26, x25, [sp, #0x100]
101620f80:     	stp	x24, x23, [sp, #0x110]
101620f84:     	stp	x22, x21, [sp, #0x120]
101620f88:     	stp	x20, x19, [sp, #0x130]
101620f8c:     	stp	x29, x30, [sp, #0x140]
101620f90:     	add	x29, sp, #0x140
101620f94:     	mov	x21, x4
101620f98:     	mov	x25, x2
101620f9c:     	mov	x24, x1
101620fa0:     	str	x0, [sp, #0x38]
101620fa4:     	ldr	x8, [x1, #0x8]
101620fa8:     	stp	x1, x3, [sp, #0x48]
101620fac:     	cbz	x8, 0x101621140 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1cc>
101620fb0:     	ldr	x23, [x24]
101620fb4:     	lsl	x20, x8, #2
101620fb8:     	add	x10, x25, #0x10
101620fbc:     	ldp	x26, x8, [x21]
101620fc0:     	ldp	x9, x11, [x21, #0x28]
101620fc4:     	stp	x11, x9, [sp, #0x20]
101620fc8:     	ldp	x9, x11, [x21, #0x10]
101620fcc:     	str	x11, [sp, #0x30]
101620fd0:     	stp	x10, x9, [sp, #0x10]
101620fd4:     	str	x8, [sp, #0x8]
101620fd8:     	add	x27, x8, #0x1
101620fdc:     	mov	w8, #0x2c               ; =44
101620fe0:     	ldr	w24, [x23], #0x4
101620fe4:     	cmp	x3, x24
101620fe8:     	b.ls	0x10162149c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
101620fec:     	strb	w8, [sp, #0x90]
101620ff0:     	add	x0, sp, #0x90
101620ff4:     	bl	0x101633220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101620ff8:     	sub	x27, x27, #0x1
101620ffc:     	cbz	x27, 0x101621520 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5ac>
101621000:     	ldrb	w8, [x26]
101621004:     	cmp	w8, #0x3
101621008:     	b.ne	0x10162103c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0xc8>
10162100c:     	ldr	x0, [x26, #0x8]
101621010:     	ldr	x8, [sp, #0x30]
101621014:     	cmp	x0, x8
101621018:     	b.hs	0x101621564 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5f0>
10162101c:     	ldr	x8, [sp, #0x28]
101621020:     	cmp	x0, x8
101621024:     	b.hs	0x101621574 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x600>
101621028:     	lsl	x8, x0, #6
10162102c:     	ldr	x9, [sp, #0x18]
101621030:     	ldr	x8, [x9, x8]
101621034:     	cbnz	x8, 0x101621074 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x100>
101621038:     	b	0x10162107c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x108>
10162103c:     	ldp	q0, q1, [x26]
101621040:     	stp	q0, q1, [sp, #0x90]
101621044:     	ldr	x8, [sp, #0x20]
101621048:     	ldr	x8, [x8]
10162104c:     	ldr	x1, [x8]
101621050:     	add	x0, sp, #0x68
101621054:     	add	x2, sp, #0x90
101621058:     	bl	0x1016360f8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
10162105c:     	ldr	x8, [sp, #0x68]
101621060:     	cmp	x8, #0x1
101621064:     	b.ne	0x10162107c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x108>
101621068:     	ldr	x8, [sp, #0x70]
10162106c:     	cbz	x8, 0x10162107c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x108>
101621070:     	ldr	x8, [x8]
101621074:     	ldp	x22, x19, [x8, #0x10]
101621078:     	b	0x101621084 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x110>
10162107c:     	mov	x19, #0x0               ; =0
101621080:     	mov	w22, #0x8               ; =8
101621084:     	mov	x1, x28
101621088:     	lsl	x28, x19, #3
10162108c:     	lsr	x8, x19, #61
101621090:     	cmp	x8, #0x0
101621094:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
101621098:     	ccmp	x28, x8, #0x2, eq
10162109c:     	b.hi	0x10162116c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1f8>
1016210a0:     	str	x25, [sp, #0x40]
1016210a4:     	cbz	x28, 0x1016210dc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x168>
1016210a8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1016210ac:     	mov	x0, x28
1016210b0:     	mov	w1, #0x8                ; =8
1016210b4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1016210b8:     	cbz	x0, 0x101621584 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x610>
1016210bc:     	mov	x25, x0
1016210c0:     	cbz	x19, 0x1016210d4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x160>
1016210c4:     	mov	x0, x25
1016210c8:     	mov	x1, x22
1016210cc:     	mov	x2, x28
1016210d0:     	bl	0x103a03a5c <dyld_stub_binder+0x103a03a5c>
1016210d4:     	mov	x28, x25
1016210d8:     	b	0x1016210e4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x170>
1016210dc:     	mov	w28, #0x8               ; =8
1016210e0:     	mov	w25, #0x8               ; =8
1016210e4:     	ldr	x8, [sp, #0x10]
1016210e8:     	add	x0, x8, x24, lsl #7
1016210ec:     	add	x8, sp, #0x90
1016210f0:     	mov	x1, x25
1016210f4:     	mov	x2, x19
1016210f8:     	bl	0x102da87f8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
1016210fc:     	ldr	x8, [sp, #0x90]
101621100:     	cmp	x8, #0x1e
101621104:     	ldp	x24, x3, [sp, #0x48]
101621108:     	b.ne	0x10162147c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x508>
10162110c:     	ldr	x8, [sp, #0xa0]
101621110:     	cbz	x8, 0x10162112c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1b8>
101621114:     	ldr	x0, [sp, #0x98]
101621118:     	lsl	x1, x8, #3
10162111c:     	mov	w2, #0x8                ; =8
101621120:     	mov	x19, x3
101621124:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101621128:     	mov	x3, x19
10162112c:     	add	x26, x26, #0x20
101621130:     	sub	x20, x20, #0x4
101621134:     	ldr	x25, [sp, #0x40]
101621138:     	mov	w8, #0x2c               ; =44
10162113c:     	cbnz	x20, 0x101620fe0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x6c>
101621140:     	ldr	x26, [x24, #0x30]
101621144:     	lsl	x19, x26, #3
101621148:     	lsr	x8, x26, #61
10162114c:     	cmp	x8, #0x0
101621150:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
101621154:     	ccmp	x19, x8, #0x2, eq
101621158:     	b.ls	0x101621174 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x200>
10162115c:     	mov	x22, #0x0               ; =0
101621160:     	mov	x0, x22
101621164:     	mov	x1, x19
101621168:     	bl	0x103a02254 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10162116c:     	mov	x0, #0x0                ; =0
101621170:     	bl	0x103a02254 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
101621174:     	str	x25, [sp, #0x40]
101621178:     	cbz	x19, 0x1016211b0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x23c>
10162117c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101621180:     	mov	w22, #0x8               ; =8
101621184:     	mov	x0, x19
101621188:     	mov	w1, #0x8                ; =8
10162118c:     	bl	0x1000096b8 <__RNvCsfBzVIH1HIC6_7___rustc19___rust_alloc_zeroed>
101621190:     	str	x0, [sp, #0x30]
101621194:     	cbz	x0, 0x101621160 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1ec>
101621198:     	ldp	x25, x8, [x24, #0x10]
10162119c:     	lsl	x9, x8, #6
1016211a0:     	sub	x9, x9, x8, lsl #3
1016211a4:     	stp	x26, x9, [sp, #0x10]
1016211a8:     	cbnz	x8, 0x1016211cc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x258>
1016211ac:     	b	0x1016212d8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x364>
1016211b0:     	mov	w8, #0x8                ; =8
1016211b4:     	str	x8, [sp, #0x30]
1016211b8:     	ldp	x25, x8, [x24, #0x10]
1016211bc:     	lsl	x9, x8, #6
1016211c0:     	sub	x9, x9, x8, lsl #3
1016211c4:     	stp	xzr, x9, [sp, #0x10]
1016211c8:     	cbz	x8, 0x1016212d8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x364>
1016211cc:     	ldp	x19, x27, [x21]
1016211d0:     	add	x28, x25, #0x18
1016211d4:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016211d8:     	add	x8, x8, #0xc0
1016211dc:     	str	x8, [sp, #0x8]
1016211e0:     	ldp	x8, x9, [x21, #0x28]
1016211e4:     	stp	x9, x8, [sp, #0x20]
1016211e8:     	ldr	x20, [sp, #0x18]
1016211ec:     	ldp	x23, x22, [x21, #0x10]
1016211f0:     	b	0x101621208 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x294>
1016211f4:     	ldr	x8, [sp, #0x30]
1016211f8:     	str	x1, [x8, x0, lsl #3]
1016211fc:     	add	x28, x28, #0x38
101621200:     	subs	x20, x20, #0x38
101621204:     	b.eq	0x1016212d8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x364>
101621208:     	ldr	x0, [x28, #0x18]
10162120c:     	cmp	x0, x27
101621210:     	b.hs	0x101621554 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5e0>
101621214:     	add	x8, x19, x0, lsl #5
101621218:     	ldrb	w9, [x8]
10162121c:     	cmp	w9, #0x3
101621220:     	b.ne	0x10162124c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x2d8>
101621224:     	ldr	x0, [x8, #0x8]
101621228:     	cmp	x0, x22
10162122c:     	b.hs	0x101621534 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5c0>
101621230:     	ldr	x8, [sp, #0x28]
101621234:     	cmp	x0, x8
101621238:     	b.hs	0x101621544 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5d0>
10162123c:     	lsl	x8, x0, #6
101621240:     	ldr	x24, [x23, x8]
101621244:     	cbnz	x24, 0x101621280 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x30c>
101621248:     	b	0x101621438 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
10162124c:     	ldp	q0, q1, [x8]
101621250:     	stp	q0, q1, [sp, #0x90]
101621254:     	ldr	x8, [sp, #0x20]
101621258:     	ldr	x8, [x8]
10162125c:     	ldr	x1, [x8]
101621260:     	add	x0, sp, #0x68
101621264:     	add	x2, sp, #0x90
101621268:     	bl	0x1016360f8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
10162126c:     	ldp	x9, x8, [sp, #0x68]
101621270:     	cmp	x9, #0x1
101621274:     	ccmp	x8, #0x0, #0x4, eq
101621278:     	b.eq	0x101621438 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
10162127c:     	ldr	x24, [x8]
101621280:     	mov	w8, #0x2c               ; =44
101621284:     	strb	w8, [sp, #0x90]
101621288:     	add	x0, sp, #0x90
10162128c:     	bl	0x101633220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101621290:     	add	x8, sp, #0x90
101621294:     	add	x0, x24, #0x10
101621298:     	mov	x1, x28
10162129c:     	bl	0x102e2cc58 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1016212a0:     	ldp	x8, x1, [sp, #0x90]
1016212a4:     	cmp	x8, #0x1e
1016212a8:     	b.ne	0x10162141c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4a8>
1016212ac:     	ldur	w8, [x28, #-0x18]
1016212b0:     	cmp	w8, #0x2
1016212b4:     	b.ne	0x1016211fc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x288>
1016212b8:     	ldur	w0, [x28, #-0x14]
1016212bc:     	cmp	x26, x0
1016212c0:     	b.hi	0x1016211f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x280>
1016212c4:     	adrp	x2, 0x107f0f000 <_anon.797b2294c71d6bb404c294e7e4131068.123+0x2a0>
1016212c8:     	add	x2, x2, #0xf10
1016212cc:     	mov	x1, x26
1016212d0:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016212d4:     	b	0x1016215cc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x658>
1016212d8:     	ldp	x9, x8, [sp, #0x48]
1016212dc:     	ldr	w19, [x9, #0x38]
1016212e0:     	cmp	x8, x19
1016212e4:     	b.ls	0x101621438 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
1016212e8:     	mov	w24, #0x2c              ; =44
1016212ec:     	strb	w24, [sp, #0x90]
1016212f0:     	add	x0, sp, #0x90
1016212f4:     	bl	0x101633220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1016212f8:     	ldr	x8, [sp, #0x40]
1016212fc:     	add	x9, x8, x19, lsl #7
101621300:     	add	x8, sp, #0x68
101621304:     	add	x0, x9, #0x10
101621308:     	ldr	x1, [sp, #0x30]
10162130c:     	mov	x2, x26
101621310:     	bl	0x102da87f8 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
101621314:     	ldr	x8, [sp, #0x68]
101621318:     	cmp	x8, #0x1e
10162131c:     	b.ne	0x101621460 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4ec>
101621320:     	ldp	x8, x20, [sp, #0x70]
101621324:     	str	x8, [sp, #0x30]
101621328:     	stp	x8, x20, [sp, #0x58]
10162132c:     	ldp	x26, x23, [x21]
101621330:     	ldp	x28, x9, [x21, #0x28]
101621334:     	ldp	x21, x27, [x21, #0x10]
101621338:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
10162133c:     	add	x8, x8, #0xc0
101621340:     	stp	x8, x9, [sp, #0x48]
101621344:     	ldr	x22, [sp, #0x18]
101621348:     	cbz	x22, 0x1016214c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x554>
10162134c:     	ldr	x0, [x25, #0x30]
101621350:     	cmp	x0, x23
101621354:     	b.hs	0x101621590 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x61c>
101621358:     	add	x8, x26, x0, lsl #5
10162135c:     	ldrb	w9, [x8]
101621360:     	cmp	w9, #0x3
101621364:     	b.ne	0x10162138c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x418>
101621368:     	ldr	x0, [x8, #0x8]
10162136c:     	cmp	x0, x27
101621370:     	b.hs	0x101621598 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x624>
101621374:     	cmp	x0, x28
101621378:     	b.hs	0x1016215ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x638>
10162137c:     	lsl	x8, x0, #6
101621380:     	ldr	x19, [x21, x8]
101621384:     	cbnz	x19, 0x1016213c4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x450>
101621388:     	b	0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
10162138c:     	ldp	q0, q1, [x8]
101621390:     	stp	q0, q1, [sp, #0x90]
101621394:     	ldr	x8, [sp, #0x50]
101621398:     	ldr	x8, [x8]
10162139c:     	ldr	x1, [x8]
1016213a0:     	sub	x0, x29, #0x70
1016213a4:     	add	x2, sp, #0x90
1016213a8:     	bl	0x1016360f8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1016213ac:     	ldur	x8, [x29, #-0x70]
1016213b0:     	cmp	x8, #0x1
1016213b4:     	b.ne	0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
1016213b8:     	ldur	x8, [x29, #-0x68]
1016213bc:     	cbz	x8, 0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
1016213c0:     	ldr	x19, [x8]
1016213c4:     	strb	w24, [sp, #0x90]
1016213c8:     	add	x0, sp, #0x90
1016213cc:     	bl	0x101633220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1016213d0:     	add	x8, sp, #0x68
1016213d4:     	add	x0, x19, #0x10
1016213d8:     	add	x1, x25, #0x18
1016213dc:     	bl	0x102e2cc58 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1016213e0:     	ldp	x8, x19, [sp, #0x68]
1016213e4:     	cmp	x8, #0x1e
1016213e8:     	b.ne	0x1016214d0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x55c>
1016213ec:     	add	x8, sp, #0x90
1016213f0:     	add	x0, sp, #0x58
1016213f4:     	mov	x1, x25
1016213f8:     	bl	0x102e2cc58 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1016213fc:     	ldp	x8, x1, [sp, #0x90]
101621400:     	cmp	x8, #0x1e
101621404:     	b.ne	0x1016214ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x578>
101621408:     	add	x25, x25, #0x38
10162140c:     	sub	x22, x22, #0x38
101621410:     	cmp	x1, x19
101621414:     	b.eq	0x101621348 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x3d4>
101621418:     	b	0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
10162141c:     	and	x8, x8, #0x1e
101621420:     	cmp	x8, #0x14
101621424:     	b.ne	0x101621438 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
101621428:     	cbz	x1, 0x101621438 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
10162142c:     	ldr	x0, [sp, #0xa0]
101621430:     	mov	w2, #0x1                ; =1
101621434:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101621438:     	mov	w8, #0x2c               ; =44
10162143c:     	ldr	x9, [sp, #0x38]
101621440:     	strb	w8, [x9]
101621444:     	ldr	x8, [sp, #0x10]
101621448:     	cbz	x8, 0x1016214a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x534>
10162144c:     	lsl	x1, x8, #3
101621450:     	ldr	x0, [sp, #0x30]
101621454:     	mov	w2, #0x8                ; =8
101621458:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10162145c:     	b	0x1016214a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x534>
101621460:     	and	x8, x8, #0x1e
101621464:     	cmp	x8, #0x14
101621468:     	b.ne	0x10162149c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
10162146c:     	ldr	x1, [sp, #0x70]
101621470:     	cbz	x1, 0x10162149c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
101621474:     	ldr	x0, [sp, #0x78]
101621478:     	b	0x101621494 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x520>
10162147c:     	and	x8, x8, #0x1e
101621480:     	cmp	x8, #0x14
101621484:     	b.ne	0x10162149c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
101621488:     	ldr	x1, [sp, #0x98]
10162148c:     	cbz	x1, 0x10162149c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
101621490:     	ldr	x0, [sp, #0xa0]
101621494:     	mov	w2, #0x1                ; =1
101621498:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10162149c:     	mov	w8, #0x2c               ; =44
1016214a0:     	ldr	x9, [sp, #0x38]
1016214a4:     	strb	w8, [x9]
1016214a8:     	ldp	x29, x30, [sp, #0x140]
1016214ac:     	ldp	x20, x19, [sp, #0x130]
1016214b0:     	ldp	x22, x21, [sp, #0x120]
1016214b4:     	ldp	x24, x23, [sp, #0x110]
1016214b8:     	ldp	x26, x25, [sp, #0x100]
1016214bc:     	ldp	x28, x27, [sp, #0xf0]
1016214c0:     	add	sp, sp, #0x150
1016214c4:     	ret
1016214c8:     	mov	w8, #0x2e               ; =46
1016214cc:     	b	0x10162150c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x598>
1016214d0:     	and	x8, x8, #0x1e
1016214d4:     	cmp	x8, #0x14
1016214d8:     	b.ne	0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
1016214dc:     	cbz	x19, 0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
1016214e0:     	ldr	x0, [sp, #0x78]
1016214e4:     	mov	x1, x19
1016214e8:     	b	0x101621500 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x58c>
1016214ec:     	and	x8, x8, #0x1e
1016214f0:     	cmp	x8, #0x14
1016214f4:     	b.ne	0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
1016214f8:     	cbz	x1, 0x101621508 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
1016214fc:     	ldr	x0, [sp, #0xa0]
101621500:     	mov	w2, #0x1                ; =1
101621504:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101621508:     	mov	w8, #0x2c               ; =44
10162150c:     	ldr	x9, [sp, #0x38]
101621510:     	strb	w8, [x9]
101621514:     	cbz	x20, 0x1016214a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x534>
101621518:     	lsl	x1, x20, #3
10162151c:     	b	0x101621450 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4dc>
101621520:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101621524:     	add	x2, x2, #0xc0
101621528:     	ldr	x0, [sp, #0x8]
10162152c:     	mov	x1, x0
101621530:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621534:     	mov	x27, x22
101621538:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
10162153c:     	add	x8, x8, #0xd8
101621540:     	b	0x101621550 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5dc>
101621544:     	ldr	x27, [sp, #0x28]
101621548:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
10162154c:     	add	x8, x8, #0xf0
101621550:     	str	x8, [sp, #0x8]
101621554:     	mov	x1, x27
101621558:     	ldr	x2, [sp, #0x8]
10162155c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621560:     	b	0x1016215cc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x658>
101621564:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101621568:     	add	x2, x2, #0xd8
10162156c:     	ldr	x1, [sp, #0x30]
101621570:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621574:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101621578:     	add	x2, x2, #0xf0
10162157c:     	ldr	x1, [sp, #0x28]
101621580:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621584:     	mov	x1, x28
101621588:     	mov	w0, #0x8                ; =8
10162158c:     	bl	0x103a02254 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
101621590:     	str	x20, [sp, #0x10]
101621594:     	b	0x1016215c0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x64c>
101621598:     	str	x20, [sp, #0x10]
10162159c:     	mov	x23, x27
1016215a0:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016215a4:     	add	x8, x8, #0xd8
1016215a8:     	b	0x1016215bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x648>
1016215ac:     	str	x20, [sp, #0x10]
1016215b0:     	mov	x23, x28
1016215b4:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016215b8:     	add	x8, x8, #0xf0
1016215bc:     	str	x8, [sp, #0x48]
1016215c0:     	mov	x1, x23
1016215c4:     	ldr	x2, [sp, #0x48]
1016215c8:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016215cc:     	brk	#0x1
1016215d0:     	b	0x1016215e8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x674>
1016215d4:     	mov	x19, x0
1016215d8:     	str	x20, [sp, #0x10]
1016215dc:     	cbnz	x20, 0x1016215f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x680>
1016215e0:     	b	0x101621608 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x694>
1016215e4:     	b	0x1016215e8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x674>
1016215e8:     	mov	x19, x0
1016215ec:     	ldr	x8, [sp, #0x10]
1016215f0:     	cbz	x8, 0x101621608 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x694>
1016215f4:     	ldr	x8, [sp, #0x10]
1016215f8:     	lsl	x1, x8, #3
1016215fc:     	ldr	x0, [sp, #0x30]
101621600:     	mov	w2, #0x8                ; =8
101621604:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101621608:     	mov	x0, x19
10162160c:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
