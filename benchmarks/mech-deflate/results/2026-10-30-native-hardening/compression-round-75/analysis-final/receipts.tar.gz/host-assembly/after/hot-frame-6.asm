
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101620cd8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_>:
101620cd8:     	sub	sp, sp, #0xd0
101620cdc:     	stp	x28, x27, [sp, #0x70]
101620ce0:     	stp	x26, x25, [sp, #0x80]
101620ce4:     	stp	x24, x23, [sp, #0x90]
101620ce8:     	stp	x22, x21, [sp, #0xa0]
101620cec:     	stp	x20, x19, [sp, #0xb0]
101620cf0:     	stp	x29, x30, [sp, #0xc0]
101620cf4:     	add	x29, sp, #0xc0
101620cf8:     	ldrb	w8, [x0, #0x3c]
101620cfc:     	cmp	w8, #0x1
101620d00:     	b.ne	0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620d04:     	ldp	x21, x24, [x0, #0x10]
101620d08:     	ldp	x9, x8, [x0, #0x20]
101620d0c:     	stp	x9, x8, [sp]
101620d10:     	ldp	x27, x19, [x1]
101620d14:     	ldp	x8, x9, [x1, #0x28]
101620d18:     	stp	x9, x8, [sp, #0x18]
101620d1c:     	ldp	x8, x9, [x1, #0x10]
101620d20:     	str	x9, [sp, #0x28]
101620d24:     	str	x8, [sp, #0x10]
101620d28:     	add	x26, x21, #0x8
101620d2c:     	lsl	x8, x24, #6
101620d30:     	sub	x20, x8, x24, lsl #3
101620d34:     	mov	x23, x21
101620d38:     	b	0x101620d70 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x98>
101620d3c:     	add	x8, sp, #0x30
101620d40:     	add	x0, x9, #0x10
101620d44:     	add	x1, x25, #0x18
101620d48:     	bl	0x102e2cc58 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
101620d4c:     	ldr	x8, [sp, #0x30]
101620d50:     	cmp	x8, #0x1e
101620d54:     	b.ne	0x101620efc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x224>
101620d58:     	ldr	x8, [sp, #0x38]
101620d5c:     	add	x23, x23, #0x38
101620d60:     	add	x26, x26, #0x38
101620d64:     	sub	x20, x20, #0x38
101620d68:     	cmp	x8, x28
101620d6c:     	b.ne	0x101620f20 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620d70:     	cmp	x20, #0x0
101620d74:     	cset	w22, eq
101620d78:     	cbz	x20, 0x101620f20 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620d7c:     	ldr	x0, [x23, #0x30]
101620d80:     	cmp	x0, x19
101620d84:     	b.hs	0x101620f44 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x26c>
101620d88:     	add	x8, x27, x0, lsl #5
101620d8c:     	ldrb	w9, [x8]
101620d90:     	cmp	w9, #0x3
101620d94:     	b.ne	0x101620dc8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0xf0>
101620d98:     	ldr	x0, [x8, #0x8]
101620d9c:     	ldr	x8, [sp, #0x28]
101620da0:     	cmp	x0, x8
101620da4:     	b.hs	0x101620f54 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x27c>
101620da8:     	ldr	x8, [sp, #0x20]
101620dac:     	cmp	x0, x8
101620db0:     	b.hs	0x101620f64 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x28c>
101620db4:     	lsl	x8, x0, #6
101620db8:     	ldr	x9, [sp, #0x10]
101620dbc:     	ldr	x9, [x9, x8]
101620dc0:     	cbnz	x9, 0x101620e00 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x128>
101620dc4:     	b	0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620dc8:     	ldp	q0, q1, [x8]
101620dcc:     	stp	q0, q1, [sp, #0x30]
101620dd0:     	ldr	x8, [sp, #0x18]
101620dd4:     	ldr	x8, [x8]
101620dd8:     	ldr	x1, [x8]
101620ddc:     	add	x0, sp, #0x58
101620de0:     	add	x2, sp, #0x30
101620de4:     	bl	0x1016360f8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101620de8:     	ldr	x8, [sp, #0x58]
101620dec:     	cmp	x8, #0x1
101620df0:     	b.ne	0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620df4:     	ldr	x8, [sp, #0x60]
101620df8:     	cbz	x8, 0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620dfc:     	ldr	x9, [x8]
101620e00:     	add	x8, sp, #0x30
101620e04:     	add	x0, x9, #0x10
101620e08:     	add	x1, x23, #0x18
101620e0c:     	bl	0x102e2cc58 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
101620e10:     	ldr	x8, [sp, #0x30]
101620e14:     	cmp	x8, #0x1e
101620e18:     	b.ne	0x101620efc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x224>
101620e1c:     	ldr	x28, [sp, #0x38]
101620e20:     	ldr	w8, [x23]
101620e24:     	cmp	w8, #0x2
101620e28:     	b.eq	0x101620e4c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x174>
101620e2c:     	cmp	w8, #0x1
101620e30:     	b.ne	0x101620f20 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620e34:     	ldr	x8, [x26], #0x38
101620e38:     	add	x23, x23, #0x38
101620e3c:     	sub	x20, x20, #0x38
101620e40:     	cmp	x8, x28
101620e44:     	b.eq	0x101620d70 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x98>
101620e48:     	b	0x101620f20 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620e4c:     	ldur	w8, [x26, #-0x4]
101620e50:     	ldr	x9, [sp, #0x8]
101620e54:     	cmp	x9, x8
101620e58:     	b.ls	0x101620f20 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620e5c:     	ldr	x9, [sp]
101620e60:     	ldr	x8, [x9, x8, lsl #3]
101620e64:     	cmp	x8, x24
101620e68:     	b.hs	0x101620f20 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620e6c:     	mov	w9, #0x38               ; =56
101620e70:     	madd	x25, x8, x9, x21
101620e74:     	ldr	x0, [x25, #0x30]
101620e78:     	cmp	x0, x19
101620e7c:     	b.hs	0x101620f44 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x26c>
101620e80:     	add	x8, x27, x0, lsl #5
101620e84:     	ldrb	w9, [x8]
101620e88:     	cmp	w9, #0x3
101620e8c:     	b.ne	0x101620ec0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x1e8>
101620e90:     	ldr	x0, [x8, #0x8]
101620e94:     	ldr	x8, [sp, #0x28]
101620e98:     	cmp	x0, x8
101620e9c:     	b.hs	0x101620f54 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x27c>
101620ea0:     	ldr	x8, [sp, #0x20]
101620ea4:     	cmp	x0, x8
101620ea8:     	b.hs	0x101620f64 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x28c>
101620eac:     	lsl	x8, x0, #6
101620eb0:     	ldr	x9, [sp, #0x10]
101620eb4:     	ldr	x9, [x9, x8]
101620eb8:     	cbnz	x9, 0x101620d3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x64>
101620ebc:     	b	0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620ec0:     	ldp	q0, q1, [x8]
101620ec4:     	stp	q0, q1, [sp, #0x30]
101620ec8:     	ldr	x8, [sp, #0x18]
101620ecc:     	ldr	x8, [x8]
101620ed0:     	ldr	x1, [x8]
101620ed4:     	add	x0, sp, #0x58
101620ed8:     	add	x2, sp, #0x30
101620edc:     	bl	0x1016360f8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101620ee0:     	ldr	x8, [sp, #0x58]
101620ee4:     	cmp	x8, #0x1
101620ee8:     	b.ne	0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620eec:     	ldr	x8, [sp, #0x60]
101620ef0:     	cbz	x8, 0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620ef4:     	ldr	x9, [x8]
101620ef8:     	b	0x101620d3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x64>
101620efc:     	and	x8, x8, #0x1e
101620f00:     	cmp	x8, #0x14
101620f04:     	b.ne	0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620f08:     	ldr	x1, [sp, #0x38]
101620f0c:     	cbz	x1, 0x101620f1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620f10:     	ldr	x0, [sp, #0x40]
101620f14:     	mov	w2, #0x1                ; =1
101620f18:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101620f1c:     	mov	w22, #0x0               ; =0
101620f20:     	mov	x0, x22
101620f24:     	ldp	x29, x30, [sp, #0xc0]
101620f28:     	ldp	x20, x19, [sp, #0xb0]
101620f2c:     	ldp	x22, x21, [sp, #0xa0]
101620f30:     	ldp	x24, x23, [sp, #0x90]
101620f34:     	ldp	x26, x25, [sp, #0x80]
101620f38:     	ldp	x28, x27, [sp, #0x70]
101620f3c:     	add	sp, sp, #0xd0
101620f40:     	ret
101620f44:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101620f48:     	add	x2, x2, #0xc0
101620f4c:     	mov	x1, x19
101620f50:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101620f54:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101620f58:     	add	x2, x2, #0xd8
101620f5c:     	ldr	x1, [sp, #0x28]
101620f60:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101620f64:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101620f68:     	add	x2, x2, #0xf0
101620f6c:     	ldr	x1, [sp, #0x20]
101620f70:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
