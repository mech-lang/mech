
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015284b0 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>:
1015284b0:     	stp	x20, x19, [sp, #-0x20]!
1015284b4:     	stp	x29, x30, [sp, #0x10]
1015284b8:     	add	x29, sp, #0x10
1015284bc:     	mov	x19, x4
1015284c0:     	cmp	x3, x2
1015284c4:     	b.hs	0x101528514 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_+0x64>
1015284c8:     	mov	w8, #0x170              ; =368
1015284cc:     	madd	x8, x3, x8, x1
1015284d0:     	add	x9, x8, #0x148
1015284d4:     	ldr	q0, [x9]
1015284d8:     	stur	q0, [x0, #0x4]
1015284dc:     	ldp	q0, q1, [x19]
1015284e0:     	stur	q0, [x0, #0x18]
1015284e4:     	ldr	w8, [x8, #0x158]
1015284e8:     	str	w8, [x0, #0x14]
1015284ec:     	stur	q1, [x0, #0x28]
1015284f0:     	ldr	q0, [x19, #0x20]
1015284f4:     	stur	q0, [x0, #0x38]
1015284f8:     	ldr	x8, [x19, #0x30]
1015284fc:     	str	x8, [x0, #0x48]
101528500:     	mov	w8, #0x3                ; =3
101528504:     	str	w8, [x0]
101528508:     	ldp	x29, x30, [sp, #0x10]
10152850c:     	ldp	x20, x19, [sp], #0x20
101528510:     	ret
101528514:     	adrp	x8, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
101528518:     	add	x8, x8, #0xff0
10152851c:     	mov	x0, x3
101528520:     	mov	x1, x2
101528524:     	mov	x2, x8
101528528:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152852c:     	brk	#0x1
101528530:     	mov	x20, x0
101528534:     	mov	x0, x19
101528538:     	bl	0x1015258a4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10152853c:     	mov	x0, x20
101528540:     	bl	0x103a03870 <dyld_stub_binder+0x103a03870>
