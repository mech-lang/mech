
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010150da44 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>:
10150da44:     	sub	sp, sp, #0x1d0
10150da48:     	stp	x28, x27, [sp, #0x170]
10150da4c:     	stp	x26, x25, [sp, #0x180]
10150da50:     	stp	x24, x23, [sp, #0x190]
10150da54:     	stp	x22, x21, [sp, #0x1a0]
10150da58:     	stp	x20, x19, [sp, #0x1b0]
10150da5c:     	stp	x29, x30, [sp, #0x1c0]
10150da60:     	add	x29, sp, #0x1c0
10150da64:     	mov	x25, x6
10150da68:     	mov	x26, x4
10150da6c:     	mov	x23, x3
10150da70:     	mov	x22, x2
10150da74:     	mov	x24, x1
10150da78:     	mov	x20, x0
10150da7c:     	mov	x19, x8
10150da80:     	ldr	x21, [x29, #0x10]
10150da84:     	stp	x5, x6, [sp]
10150da88:     	str	x7, [sp, #0x10]
10150da8c:     	add	x27, sp, #0x80
10150da90:     	ldr	w0, [x0, #0x110]
10150da94:     	add	x8, sp, #0xc8
10150da98:     	mov	x1, x21
10150da9c:     	bl	0x10254e808 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
10150daa0:     	ldrb	w8, [sp, #0xc8]
10150daa4:     	cmp	w8, #0x29
10150daa8:     	b.ne	0x10150dafc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb8>
10150daac:     	ldr	x28, [x20, #0x1d8]
10150dab0:     	cbz	x28, 0x10150db1c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xd8>
10150dab4:     	mov	w27, #0x2c              ; =44
10150dab8:     	strb	w27, [sp, #0xc8]
10150dabc:     	add	x0, sp, #0xc8
10150dac0:     	bl	0x10150e600 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10150dac4:     	cmp	x22, x26
10150dac8:     	b.ne	0x10150daf4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb0>
10150dacc:     	ldr	x8, [x20, #0x78]
10150dad0:     	cmp	x22, x8
10150dad4:     	b.ne	0x10150daf4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb0>
10150dad8:     	cmp	x25, #0x0
10150dadc:     	cset	w8, ne
10150dae0:     	ldr	x9, [x20, #0x10]
10150dae4:     	cmp	x9, #0xb
10150dae8:     	cset	w9, eq
10150daec:     	eor	w8, w8, w9
10150daf0:     	tbz	w8, #0x0, 0x10150db44 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x100>
10150daf4:     	strb	w27, [x19]
10150daf8:     	b	0x10150db24 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10150dafc:     	ldur	q0, [x27, #0x48]
10150db00:     	ldur	q1, [x27, #0x58]
10150db04:     	stp	q0, q1, [x19]
10150db08:     	ldur	q0, [x27, #0x68]
10150db0c:     	str	q0, [x19, #0x20]
10150db10:     	ldr	x8, [sp, #0xf8]
10150db14:     	str	x8, [x19, #0x30]
10150db18:     	b	0x10150db24 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10150db1c:     	mov	w8, #0x2c               ; =44
10150db20:     	strb	w8, [x19]
10150db24:     	ldp	x29, x30, [sp, #0x1c0]
10150db28:     	ldp	x20, x19, [sp, #0x1b0]
10150db2c:     	ldp	x22, x21, [sp, #0x1a0]
10150db30:     	ldp	x24, x23, [sp, #0x190]
10150db34:     	ldp	x26, x25, [sp, #0x180]
10150db38:     	ldp	x28, x27, [sp, #0x170]
10150db3c:     	add	sp, sp, #0x1d0
10150db40:     	ret
10150db44:     	ldp	x8, x9, [x28, #0x10]
10150db48:     	stp	x8, x9, [sp, #0x18]
10150db4c:     	stp	x24, x22, [sp, #0x28]
10150db50:     	stp	x23, x22, [sp, #0x38]
10150db54:     	mov	x10, sp
10150db58:     	str	x10, [sp, #0x48]
10150db5c:     	ldr	x10, [x21, #0x60]
10150db60:     	cmp	x10, #0x1
10150db64:     	b.ne	0x10150dc74 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x230>
10150db68:     	ldr	w10, [x21, #0x50]
10150db6c:     	add	x22, sp, #0x80
10150db70:     	tbz	w10, #0x0, 0x10150dc80 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x23c>
10150db74:     	ldp	x11, x10, [x29, #0x18]
10150db78:     	ldr	x12, [x21, #0x68]
10150db7c:     	ldr	x13, [x21, #0x58]
10150db80:     	ldp	x14, x15, [x28, #0x20]
10150db84:     	add	x16, x28, #0x50
10150db88:     	add	x17, x28, #0x30
10150db8c:     	add	x0, x28, #0x38
10150db90:     	add	x1, x28, #0x40
10150db94:     	add	x2, x28, #0x48
10150db98:     	stp	x12, x13, [sp, #0xb8]
10150db9c:     	add	x12, sp, #0xb8
10150dba0:     	stp	x11, x12, [sp, #0xc8]
10150dba4:     	add	x12, sp, #0xc0
10150dba8:     	stp	x12, x11, [sp, #0xd8]
10150dbac:     	stp	x21, x10, [sp, #0xe8]
10150dbb0:     	stp	x8, x9, [sp, #0xf8]
10150dbb4:     	stp	x14, x15, [sp, #0x108]
10150dbb8:     	stp	x16, x28, [sp, #0x118]
10150dbbc:     	stp	x17, x0, [sp, #0x128]
10150dbc0:     	stp	x1, x2, [sp, #0x138]
10150dbc4:     	add	x8, sp, #0x8
10150dbc8:     	stp	x8, x20, [sp, #0x148]
10150dbcc:     	add	x8, sp, #0x18
10150dbd0:     	str	x8, [sp, #0x158]
10150dbd4:     	adrp	x0, 0x107f0d000 <_anon.7cbaf8f659a3b31eba05fca1d81c56df.677+0x10>
10150dbd8:     	add	x0, x0, #0xfb8
10150dbdc:     	add	x8, sp, #0x80
10150dbe0:     	add	x1, sp, #0xc8
10150dbe4:     	bl	0x1016273f8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
10150dbe8:     	ldrb	w8, [sp, #0x80]
10150dbec:     	cmp	w8, #0x2f
10150dbf0:     	b.ne	0x10150dc3c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1f8>
10150dbf4:     	ldur	q0, [x22, #0x8]
10150dbf8:     	stur	q0, [sp, #0x57]
10150dbfc:     	ldur	q1, [x22, #0x18]
10150dc00:     	stur	q1, [sp, #0x67]
10150dc04:     	ldr	x8, [sp, #0xa8]
10150dc08:     	stur	x8, [sp, #0x77]
10150dc0c:     	stur	q0, [x22, #0x4f]
10150dc10:     	stur	q1, [x22, #0x5f]
10150dc14:     	stur	x8, [x22, #0x6f]
10150dc18:     	mov	w8, #0x29               ; =41
10150dc1c:     	strb	w8, [x19]
10150dc20:     	ldur	q0, [x22, #0x48]
10150dc24:     	stur	q0, [x19, #0x1]
10150dc28:     	ldur	q0, [x22, #0x58]
10150dc2c:     	stur	q0, [x19, #0x11]
10150dc30:     	ldur	q0, [x22, #0x67]
10150dc34:     	str	q0, [x19, #0x20]
10150dc38:     	b	0x10150db24 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10150dc3c:     	ldr	q0, [sp, #0xa0]
10150dc40:     	stur	q0, [sp, #0x6f]
10150dc44:     	ldur	q0, [x22, #0x11]
10150dc48:     	ldur	q1, [x22, #0x1]
10150dc4c:     	stp	q1, q0, [sp, #0x50]
10150dc50:     	ldr	x9, [sp, #0xb0]
10150dc54:     	strb	w8, [x19]
10150dc58:     	stur	q1, [x19, #0x1]
10150dc5c:     	ldr	q0, [sp, #0x60]
10150dc60:     	stur	q0, [x19, #0x11]
10150dc64:     	ldur	q0, [sp, #0x6f]
10150dc68:     	str	q0, [x19, #0x20]
10150dc6c:     	str	x9, [x19, #0x30]
10150dc70:     	b	0x10150db24 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10150dc74:     	adrp	x0, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
10150dc78:     	add	x0, x0, #0x1c0
10150dc7c:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10150dc80:     	adrp	x0, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
10150dc84:     	add	x0, x0, #0x1d8
10150dc88:     	bl	0x103a02408 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
