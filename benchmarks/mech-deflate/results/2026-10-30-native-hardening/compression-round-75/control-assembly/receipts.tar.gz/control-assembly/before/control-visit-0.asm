
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010157b25c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>:
10157b25c:     	sub	sp, sp, #0xd0
10157b260:     	stp	x28, x27, [sp, #0x70]
10157b264:     	stp	x26, x25, [sp, #0x80]
10157b268:     	stp	x24, x23, [sp, #0x90]
10157b26c:     	stp	x22, x21, [sp, #0xa0]
10157b270:     	stp	x20, x19, [sp, #0xb0]
10157b274:     	stp	x29, x30, [sp, #0xc0]
10157b278:     	add	x29, sp, #0xc0
10157b27c:     	ldr	x21, [x1, #0x38]
10157b280:     	ldrb	w8, [x21, #0x50]
10157b284:     	tbz	w8, #0x0, 0x10157b2bc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x60>
10157b288:     	mov	w8, #0xf                ; =15
10157b28c:     	strb	w8, [x0]
10157b290:     	ldr	d0, [x21, #0x8]
10157b294:     	str	d0, [x0, #0x8]
10157b298:     	str	x2, [x0, #0x10]
10157b29c:     	ldp	x29, x30, [sp, #0xc0]
10157b2a0:     	ldp	x20, x19, [sp, #0xb0]
10157b2a4:     	ldp	x22, x21, [sp, #0xa0]
10157b2a8:     	ldp	x24, x23, [sp, #0x90]
10157b2ac:     	ldp	x26, x25, [sp, #0x80]
10157b2b0:     	ldp	x28, x27, [sp, #0x70]
10157b2b4:     	add	sp, sp, #0xd0
10157b2b8:     	ret
10157b2bc:     	cmp	w5, #0x1
10157b2c0:     	b.ne	0x10157b33c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xe0>
10157b2c4:     	ldr	x25, [x1, #0x40]
10157b2c8:     	ldr	x8, [x25, #0x458]
10157b2cc:     	mov	w9, w6
10157b2d0:     	cmp	x8, x9
10157b2d4:     	b.ls	0x10157b938 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6dc>
10157b2d8:     	ldr	x10, [x25, #0x450]
10157b2dc:     	add	x11, x10, x9, lsl #6
10157b2e0:     	ldr	w9, [x11, #0x18]
10157b2e4:     	cmp	w9, #0x2
10157b2e8:     	b.ne	0x10157b394 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x138>
10157b2ec:     	ldr	w9, [x11, #0x1c]
10157b2f0:     	ldr	x10, [x25, #0x390]
10157b2f4:     	cmp	x10, x9
10157b2f8:     	b.ls	0x10157b94c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6f0>
10157b2fc:     	ldr	x10, [x25, #0x388]
10157b300:     	mov	w12, #0x180             ; =384
10157b304:     	umaddl	x10, w9, w12, x10
10157b308:     	ldp	x10, x12, [x10]
10157b30c:     	mov	w13, #0x5               ; =5
10157b310:     	eor	x10, x10, x13
10157b314:     	orr	x10, x10, x12
10157b318:     	cbnz	x10, 0x10157b3e4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x188>
10157b31c:     	ldr	w9, [x11]
10157b320:     	lsr	x10, x2, #32
10157b324:     	cbnz	x10, 0x10157b490 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x234>
10157b328:     	cbz	w9, 0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b32c:     	ldr	w9, [x11, #0x4]
10157b330:     	cmp	w9, w2
10157b334:     	b.ne	0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b338:     	b	0x10157b354 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
10157b33c:     	lsr	x8, x2, #32
10157b340:     	cbnz	x8, 0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b344:     	cmp	w7, w2
10157b348:     	b.ne	0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b34c:     	ldr	x25, [x1, #0x40]
10157b350:     	ldr	x8, [x25, #0x458]
10157b354:     	mov	w9, w2
10157b358:     	cmp	x8, x9
10157b35c:     	b.ls	0x10157b3cc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x170>
10157b360:     	ldr	x8, [x25, #0x450]
10157b364:     	add	x8, x8, x9, lsl #6
10157b368:     	ldr	x9, [x8, #0x20]
10157b36c:     	tst	w3, #0x1
10157b370:     	csel	x20, x4, x9, ne
10157b374:     	cmp	x20, x9
10157b378:     	b.hs	0x10157b428 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x1cc>
10157b37c:     	mov	w8, #0xc                ; =12
10157b380:     	strb	w8, [x0]
10157b384:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b388:     	add	x8, x8, #0x341
10157b38c:     	mov	w9, #0x24               ; =36
10157b390:     	b	0x10157b4b0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x254>
10157b394:     	lsr	x9, x2, #32
10157b398:     	cbnz	x9, 0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b39c:     	ldr	w9, [x11]
10157b3a0:     	tbz	w9, #0x0, 0x10157b3b0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x154>
10157b3a4:     	ldr	w9, [x11, #0x4]
10157b3a8:     	cmp	w9, w2
10157b3ac:     	b.eq	0x10157b354 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
10157b3b0:     	ldr	w9, [x11, #0x8]
10157b3b4:     	cmp	w9, #0x1
10157b3b8:     	b.ne	0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b3bc:     	ldr	w9, [x11, #0xc]
10157b3c0:     	cmp	w9, w2
10157b3c4:     	b.ne	0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b3c8:     	b	0x10157b354 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
10157b3cc:     	mov	w8, #0xc                ; =12
10157b3d0:     	strb	w8, [x0]
10157b3d4:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b3d8:     	add	x8, x8, #0x216
10157b3dc:     	mov	w9, #0x22               ; =34
10157b3e0:     	b	0x10157b4b0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x254>
10157b3e4:     	lsl	x9, x9, #1
10157b3e8:     	ldr	x10, [x1, #0x50]
10157b3ec:     	cmp	x9, x10
10157b3f0:     	b.hs	0x10157b960 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x704>
10157b3f4:     	ldr	x10, [x1, #0x48]
10157b3f8:     	ldr	x9, [x10, x9, lsl #3]
10157b3fc:     	cmp	x9, #0x0
10157b400:     	cset	w9, eq
10157b404:     	add	x9, x11, w9, uxtw #3
10157b408:     	ldr	w10, [x9]
10157b40c:     	lsr	x11, x2, #32
10157b410:     	cbnz	x11, 0x10157b498 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x23c>
10157b414:     	tbz	w10, #0x0, 0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b418:     	ldr	w9, [x9, #0x4]
10157b41c:     	cmp	w9, w2
10157b420:     	b.ne	0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b424:     	b	0x10157b354 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
10157b428:     	mov	x26, x1
10157b42c:     	stp	x2, x0, [sp, #0x10]
10157b430:     	ldp	w28, w10, [x8, #0x10]
10157b434:     	ldp	w19, w27, [x8, #0x18]
10157b438:     	ldrb	w9, [x8, #0x3c]
10157b43c:     	stp	w10, w9, [sp, #0x8]
10157b440:     	ldur	q0, [x8, #0x28]
10157b444:     	str	q0, [sp, #0x20]
10157b448:     	ldr	w24, [x8, #0x38]
10157b44c:     	str	w24, [sp, #0x30]
10157b450:     	ldr	w23, [sp, #0x20]
10157b454:     	cmp	w23, #0x2
10157b458:     	cset	w22, ne
10157b45c:     	mov	x0, x21
10157b460:     	ldr	x8, [x0, #0x28]!
10157b464:     	cbz	x8, 0x10157b4b8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x25c>
10157b468:     	ldr	x2, [x21, #0x20]
10157b46c:     	add	x8, sp, #0x48
10157b470:     	mov	x1, x20
10157b474:     	bl	0x1023640c0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
10157b478:     	ldrb	w8, [sp, #0x48]
10157b47c:     	cmp	w8, #0x8
10157b480:     	b.ne	0x10157b4d8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x27c>
10157b484:     	ldp	x12, x10, [sp, #0x10]
10157b488:     	mov	x11, x26
10157b48c:     	b	0x10157b578 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x31c>
10157b490:     	tbnz	w9, #0x0, 0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b494:     	b	0x10157b49c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x240>
10157b498:     	tbnz	w10, #0x0, 0x10157b288 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10157b49c:     	mov	w8, #0xc                ; =12
10157b4a0:     	strb	w8, [x0]
10157b4a4:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b4a8:     	add	x8, x8, #0x1fb
10157b4ac:     	mov	w9, #0x1b               ; =27
10157b4b0:     	stp	x8, x9, [x0, #0x8]
10157b4b4:     	b	0x10157b29c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
10157b4b8:     	bl	0x102363b50 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
10157b4bc:     	tbz	w0, #0x0, 0x10157b514 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2b8>
10157b4c0:     	mov	x9, #0x0                ; =0
10157b4c4:     	mov	w10, #0x0               ; =0
10157b4c8:     	mov	w11, #0x7               ; =7
10157b4cc:     	add	x12, sp, #0x38
10157b4d0:     	mov	x23, x22
10157b4d4:     	b	0x10157b50c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2b0>
10157b4d8:     	ldp	x9, x8, [sp, #0x48]
10157b4dc:     	ldr	x13, [sp, #0x58]
10157b4e0:     	and	x10, x9, #0xffff
10157b4e4:     	cmp	x10, #0x606
10157b4e8:     	b.eq	0x10157b52c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2d0>
10157b4ec:     	lsr	x10, x13, #32
10157b4f0:     	ldr	x11, [sp, #0x60]
10157b4f4:     	str	x11, [sp, #0x38]
10157b4f8:     	ldp	w11, w15, [sp, #0x68]
10157b4fc:     	str	w11, [sp, #0x40]
10157b500:     	mov	w11, #0x7               ; =7
10157b504:     	add	x12, sp, #0x38
10157b508:     	mov	x23, x13
10157b50c:     	ldr	x14, [sp, #0x18]
10157b510:     	b	0x10157b548 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2ec>
10157b514:     	ldp	x8, x13, [x21, #0x18]
10157b518:     	adds	x8, x8, x20
10157b51c:     	b.hs	0x10157b918 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6bc>
10157b520:     	cmp	x8, x13
10157b524:     	ldr	x12, [sp, #0x10]
10157b528:     	b.ls	0x10157b56c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x310>
10157b52c:     	ldr	x14, [sp, #0x18]
10157b530:     	mov	x9, x8
10157b534:     	ldr	w10, [sp, #0x24]
10157b538:     	add	x8, sp, #0x20
10157b53c:     	orr	x12, x8, #0x8
10157b540:     	mov	w11, #0xe               ; =14
10157b544:     	mov	x8, x13
10157b548:     	ldr	x13, [x12]
10157b54c:     	str	x13, [x14, #0x20]
10157b550:     	ldr	w12, [x12, #0x8]
10157b554:     	strb	w11, [x14]
10157b558:     	stp	x9, x8, [x14, #0x8]
10157b55c:     	stp	w23, w10, [x14, #0x18]
10157b560:     	stp	w12, w15, [x14, #0x28]
10157b564:     	stp	w22, w24, [x14, #0x30]
10157b568:     	b	0x10157b29c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
10157b56c:     	mov	x11, x26
10157b570:     	str	x8, [x21, #0x18]
10157b574:     	ldr	x10, [sp, #0x18]
10157b578:     	cmp	w19, #0x1
10157b57c:     	b.le	0x10157b60c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x3b0>
10157b580:     	cmp	w19, #0x2
10157b584:     	b.eq	0x10157b630 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x3d4>
10157b588:     	cmp	w19, #0x3
10157b58c:     	b.ne	0x10157b680 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x424>
10157b590:     	ldr	x0, [x25, #0x388]
10157b594:     	ldr	x1, [x25, #0x390]
10157b598:     	mov	x2, x27
10157b59c:     	bl	0x10158141c <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
10157b5a0:     	ldr	x10, [sp, #0x18]
10157b5a4:     	ldr	w8, [x21]
10157b5a8:     	tbz	w8, #0x0, 0x10157b77c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x520>
10157b5ac:     	ldr	w8, [x21, #0x4]
10157b5b0:     	cmp	w8, w27
10157b5b4:     	b.ne	0x10157b77c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x520>
10157b5b8:     	mov	w8, #0x1                ; =1
10157b5bc:     	bfi	x8, x27, #1, #32
10157b5c0:     	ldr	x1, [x26, #0x50]
10157b5c4:     	cmp	x8, x1
10157b5c8:     	b.hs	0x10157b988 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
10157b5cc:     	ldr	x9, [x26, #0x48]
10157b5d0:     	ldr	x8, [x9, x8, lsl #3]
10157b5d4:     	cmp	x8, #0x1
10157b5d8:     	b.ne	0x10157b77c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x520>
10157b5dc:     	cmp	x0, #0x2
10157b5e0:     	ldr	x12, [sp, #0x10]
10157b5e4:     	mov	x11, x26
10157b5e8:     	b.eq	0x10157b830 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5d4>
10157b5ec:     	lsl	x8, x27, #1
10157b5f0:     	ldr	x11, [x9, x8, lsl #3]
10157b5f4:     	cbz	x11, 0x10157b77c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x520>
10157b5f8:     	sub	x11, x11, #0x1
10157b5fc:     	str	x11, [x9, x8, lsl #3]
10157b600:     	ldr	x12, [sp, #0x10]
10157b604:     	mov	x11, x26
10157b608:     	b	0x10157b830 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5d4>
10157b60c:     	cbnz	w19, 0x10157b6f4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x498>
10157b610:     	ldr	w8, [x21]
10157b614:     	tbz	w8, #0x0, 0x10157b794 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x538>
10157b618:     	tbz	w28, #0x0, 0x10157b798 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x53c>
10157b61c:     	ldr	w8, [x21, #0x4]
10157b620:     	ldr	w9, [sp, #0x8]
10157b624:     	cmp	w8, w9
10157b628:     	b.ne	0x10157b798 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x53c>
10157b62c:     	b	0x10157b830 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5d4>
10157b630:     	ldr	w8, [x21]
10157b634:     	tbz	w8, #0x0, 0x10157b668 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40c>
10157b638:     	ldr	w8, [x21, #0x4]
10157b63c:     	cmp	w8, w27
10157b640:     	b.ne	0x10157b668 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40c>
10157b644:     	mov	w8, #0x1                ; =1
10157b648:     	orr	x0, x8, x27, lsl #1
10157b64c:     	ldr	x1, [x11, #0x50]
10157b650:     	cmp	x0, x1
10157b654:     	b.hs	0x10157b998 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x73c>
10157b658:     	ldr	x8, [x11, #0x48]
10157b65c:     	ldr	x8, [x8, x0, lsl #3]
10157b660:     	cmp	x8, #0x1
10157b664:     	b.eq	0x10157b830 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5d4>
10157b668:     	mov	w8, #0xc                ; =12
10157b66c:     	strb	w8, [x10]
10157b670:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b674:     	add	x8, x8, #0x297
10157b678:     	mov	w9, #0x26               ; =38
10157b67c:     	b	0x10157b884 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x628>
10157b680:     	ldr	w8, [x21]
10157b684:     	tbz	w8, #0x0, 0x10157b764 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x508>
10157b688:     	ldr	w8, [x21, #0x4]
10157b68c:     	cmp	w8, w27
10157b690:     	b.ne	0x10157b764 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x508>
10157b694:     	lsl	x0, x27, #1
10157b698:     	ldr	x1, [x11, #0x50]
10157b69c:     	cmp	x0, x1
10157b6a0:     	b.hs	0x10157b9a4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x748>
10157b6a4:     	ldr	x8, [x11, #0x48]
10157b6a8:     	ldr	x9, [x8, x0, lsl #3]
10157b6ac:     	cbnz	x9, 0x10157b764 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x508>
10157b6b0:     	orr	x0, x0, #0x1
10157b6b4:     	cmp	x0, x1
10157b6b8:     	b.hs	0x10157b9b0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x754>
10157b6bc:     	ldr	x9, [x8, x0, lsl #3]
10157b6c0:     	cmp	x9, #0x1
10157b6c4:     	b.ne	0x10157b764 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x508>
10157b6c8:     	str	xzr, [x8, x0, lsl #3]
10157b6cc:     	ldr	x0, [x25, #0x388]
10157b6d0:     	ldr	x1, [x25, #0x390]
10157b6d4:     	mov	x2, x27
10157b6d8:     	bl	0x10158141c <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
10157b6dc:     	cbz	x0, 0x10157b8b8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x65c>
10157b6e0:     	cmp	x0, #0x2
10157b6e4:     	b.ne	0x10157b8c4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x668>
10157b6e8:     	add	x9, x1, #0x14
10157b6ec:     	mov	w8, #0x18               ; =24
10157b6f0:     	b	0x10157b8cc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x670>
10157b6f4:     	ldr	x0, [x25, #0x388]
10157b6f8:     	ldr	x1, [x25, #0x390]
10157b6fc:     	mov	x2, x27
10157b700:     	bl	0x10158141c <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
10157b704:     	mov	w8, #0x4                ; =4
10157b708:     	add	x9, x1, #0x140
10157b70c:     	mov	w10, #0x144             ; =324
10157b710:     	add	x11, x1, #0x14
10157b714:     	mov	w12, #0x18              ; =24
10157b718:     	cmp	x0, #0x1
10157b71c:     	csel	x10, x10, x12, eq
10157b720:     	csel	x9, x9, x11, eq
10157b724:     	cmp	x0, #0x0
10157b728:     	csel	x8, x8, x10, eq
10157b72c:     	csel	x9, x1, x9, eq
10157b730:     	ldr	w9, [x9]
10157b734:     	ldr	w10, [x21]
10157b738:     	cmp	w10, #0x1
10157b73c:     	ldr	x10, [sp, #0x18]
10157b740:     	mov	x11, x26
10157b744:     	b.ne	0x10157b7b0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x554>
10157b748:     	ldr	x12, [sp, #0x10]
10157b74c:     	tbz	w9, #0x0, 0x10157b7d8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x57c>
10157b750:     	ldr	w8, [x1, x8]
10157b754:     	ldr	w9, [x21, #0x4]
10157b758:     	cmp	w9, w8
10157b75c:     	b.eq	0x10157b7b8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x55c>
10157b760:     	b	0x10157b7d8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x57c>
10157b764:     	mov	w8, #0xc                ; =12
10157b768:     	strb	w8, [x10]
10157b76c:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b770:     	add	x8, x8, #0x31e
10157b774:     	mov	w9, #0x23               ; =35
10157b778:     	b	0x10157b884 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x628>
10157b77c:     	mov	w8, #0xc                ; =12
10157b780:     	strb	w8, [x10]
10157b784:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b788:     	add	x8, x8, #0x2bd
10157b78c:     	mov	w9, #0x23               ; =35
10157b790:     	b	0x10157b884 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x628>
10157b794:     	tbz	w28, #0x0, 0x10157b830 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5d4>
10157b798:     	mov	w8, #0xc                ; =12
10157b79c:     	strb	w8, [x10]
10157b7a0:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b7a4:     	add	x8, x8, #0x238
10157b7a8:     	mov	w9, #0x2a               ; =42
10157b7ac:     	b	0x10157b884 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x628>
10157b7b0:     	ldr	x12, [sp, #0x10]
10157b7b4:     	tbnz	w9, #0x0, 0x10157b7d8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x57c>
10157b7b8:     	mov	w8, #0x1                ; =1
10157b7bc:     	bfi	x8, x27, #1, #32
10157b7c0:     	ldr	x9, [x11, #0x50]
10157b7c4:     	cmp	x8, x9
10157b7c8:     	b.hs	0x10157b974 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x718>
10157b7cc:     	ldr	x9, [x11, #0x48]
10157b7d0:     	ldr	x13, [x9, x8, lsl #3]
10157b7d4:     	cbz	x13, 0x10157b7f0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x594>
10157b7d8:     	mov	w8, #0xc                ; =12
10157b7dc:     	strb	w8, [x10]
10157b7e0:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b7e4:     	add	x8, x8, #0x262
10157b7e8:     	mov	w9, #0x35               ; =53
10157b7ec:     	b	0x10157b884 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x628>
10157b7f0:     	lsl	x13, x27, #1
10157b7f4:     	cmp	x0, #0x2
10157b7f8:     	b.eq	0x10157b810 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5b4>
10157b7fc:     	cmp	x0, #0x1
10157b800:     	b.ne	0x10157b818 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5bc>
10157b804:     	mov	x14, #0x0               ; =0
10157b808:     	mov	w15, #0x2               ; =2
10157b80c:     	b	0x10157b820 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5c4>
10157b810:     	mov	x14, #0x0               ; =0
10157b814:     	b	0x10157b81c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5c0>
10157b818:     	ldr	x14, [x1, #0x8]
10157b81c:     	mov	w15, #0x1               ; =1
10157b820:     	str	x14, [x9, x13, lsl #3]
10157b824:     	str	x15, [x9, x8, lsl #3]
10157b828:     	mov	w8, #0x1                ; =1
10157b82c:     	stp	w8, w27, [x21]
10157b830:     	ldr	w19, [sp, #0xc]
10157b834:     	tbz	w19, #0x0, 0x10157b88c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x630>
10157b838:     	ldr	w8, [x21]
10157b83c:     	cbnz	w8, 0x10157b870 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x614>
10157b840:     	ldp	x8, x9, [x11, #0x48]
10157b844:     	and	x10, x9, #0xffffffffffffffe
10157b848:     	add	x11, x8, x10, lsl #3
10157b84c:     	and	x9, x9, #0x1
10157b850:     	stp	x8, x10, [sp, #0x48]
10157b854:     	stp	x11, x9, [sp, #0x58]
10157b858:     	mov	w8, #0x2                ; =2
10157b85c:     	str	x8, [sp, #0x68]
10157b860:     	add	x0, sp, #0x48
10157b864:     	bl	0x101577a6c <__RINvYINtNtNtCsgDHHaSskbIF_4core5slice4iter11ChunksExactyENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBT_3any5checkRSyNCNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB2d_11ControlViewNtNtB2f_13iteration_abi25NativeIterationDescriptorE16visit_from_entrys0_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB2h_>
10157b868:     	ldp	x12, x10, [sp, #0x10]
10157b86c:     	tbz	w0, #0x0, 0x10157b88c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x630>
10157b870:     	mov	w8, #0xc                ; =12
10157b874:     	strb	w8, [x10]
10157b878:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b87c:     	add	x8, x8, #0x2e0
10157b880:     	mov	w9, #0x20               ; =32
10157b884:     	stp	x8, x9, [x10, #0x8]
10157b888:     	b	0x10157b29c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
10157b88c:     	mov	w8, #0x1                ; =1
10157b890:     	stp	w8, w12, [x21, #0x8]
10157b894:     	strb	w19, [x21, #0x50]
10157b898:     	ldr	x8, [x21, #0x48]
10157b89c:     	cmn	x8, #0x1
10157b8a0:     	b.eq	0x10157b920 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6c4>
10157b8a4:     	add	x8, x8, #0x1
10157b8a8:     	str	x8, [x21, #0x48]
10157b8ac:     	mov	w8, #0x13               ; =19
10157b8b0:     	strb	w8, [x10]
10157b8b4:     	b	0x10157b29c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
10157b8b8:     	mov	w8, #0x4                ; =4
10157b8bc:     	mov	x9, x1
10157b8c0:     	b	0x10157b8cc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x670>
10157b8c4:     	add	x9, x1, #0x140
10157b8c8:     	mov	w8, #0x144              ; =324
10157b8cc:     	ldp	x12, x10, [sp, #0x10]
10157b8d0:     	ldr	w8, [x1, x8]
10157b8d4:     	ldr	w9, [x9]
10157b8d8:     	stp	w9, w8, [x21]
10157b8dc:     	cmp	w9, #0x1
10157b8e0:     	mov	x11, x26
10157b8e4:     	b.ne	0x10157b8fc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6a0>
10157b8e8:     	cbz	w28, 0x10157b900 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6a4>
10157b8ec:     	ldr	w9, [sp, #0x8]
10157b8f0:     	cmp	w8, w9
10157b8f4:     	b.eq	0x10157b830 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5d4>
10157b8f8:     	b	0x10157b900 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6a4>
10157b8fc:     	cbz	w28, 0x10157b830 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5d4>
10157b900:     	mov	w8, #0xc                ; =12
10157b904:     	strb	w8, [x10]
10157b908:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x83>
10157b90c:     	add	x8, x8, #0x300
10157b910:     	mov	w9, #0x1e               ; =30
10157b914:     	b	0x10157b884 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x628>
10157b918:     	mov	x8, #-0x1               ; =-1
10157b91c:     	b	0x10157b52c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2d0>
10157b920:     	mov	w8, #0xc                ; =12
10157b924:     	strb	w8, [x10]
10157b928:     	adrp	x8, 0x107553000 <_anon.4e4cf234dac9fe76f818f23bf1907424.813+0x6d6>
10157b92c:     	add	x8, x8, #0xa27
10157b930:     	mov	w9, #0x1d               ; =29
10157b934:     	b	0x10157b884 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x628>
10157b938:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b93c:     	add	x2, x2, #0x610
10157b940:     	mov	x0, x9
10157b944:     	mov	x1, x8
10157b948:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10157b94c:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b950:     	add	x2, x2, #0x9a0
10157b954:     	mov	x0, x9
10157b958:     	mov	x1, x10
10157b95c:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10157b960:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b964:     	add	x2, x2, #0x628
10157b968:     	mov	x0, x9
10157b96c:     	mov	x1, x10
10157b970:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10157b974:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b978:     	add	x2, x2, #0x640
10157b97c:     	mov	x0, x8
10157b980:     	mov	x1, x9
10157b984:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10157b988:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b98c:     	add	x2, x2, #0x670
10157b990:     	mov	x0, x8
10157b994:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10157b998:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b99c:     	add	x2, x2, #0x658
10157b9a0:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10157b9a4:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b9a8:     	add	x2, x2, #0x688
10157b9ac:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10157b9b0:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10157b9b4:     	add	x2, x2, #0x6a0
10157b9b8:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
