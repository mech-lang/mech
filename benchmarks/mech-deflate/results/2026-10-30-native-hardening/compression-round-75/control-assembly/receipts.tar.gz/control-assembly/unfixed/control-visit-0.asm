
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/unfixed/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101546cd4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>:
101546cd4:     	sub	sp, sp, #0xc0
101546cd8:     	stp	x28, x27, [sp, #0x60]
101546cdc:     	stp	x26, x25, [sp, #0x70]
101546ce0:     	stp	x24, x23, [sp, #0x80]
101546ce4:     	stp	x22, x21, [sp, #0x90]
101546ce8:     	stp	x20, x19, [sp, #0xa0]
101546cec:     	stp	x29, x30, [sp, #0xb0]
101546cf0:     	add	x29, sp, #0xb0
101546cf4:     	ldr	x20, [x1, #0x38]
101546cf8:     	ldrb	w8, [x20, #0x50]
101546cfc:     	tbz	w8, #0x0, 0x101546d34 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x60>
101546d00:     	mov	w8, #0xf                ; =15
101546d04:     	strb	w8, [x0]
101546d08:     	ldr	d0, [x20, #0x8]
101546d0c:     	str	d0, [x0, #0x8]
101546d10:     	str	x2, [x0, #0x10]
101546d14:     	ldp	x29, x30, [sp, #0xb0]
101546d18:     	ldp	x20, x19, [sp, #0xa0]
101546d1c:     	ldp	x22, x21, [sp, #0x90]
101546d20:     	ldp	x24, x23, [sp, #0x80]
101546d24:     	ldp	x26, x25, [sp, #0x70]
101546d28:     	ldp	x28, x27, [sp, #0x60]
101546d2c:     	add	sp, sp, #0xc0
101546d30:     	ret
101546d34:     	cmp	w5, #0x1
101546d38:     	b.ne	0x101546db4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xe0>
101546d3c:     	ldr	x24, [x1, #0x40]
101546d40:     	ldr	x8, [x24, #0x458]
101546d44:     	mov	w9, w6
101546d48:     	cmp	x8, x9
101546d4c:     	b.ls	0x1015472f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x624>
101546d50:     	ldr	x10, [x24, #0x450]
101546d54:     	add	x11, x10, x9, lsl #6
101546d58:     	ldr	w9, [x11, #0x18]
101546d5c:     	cmp	w9, #0x2
101546d60:     	b.ne	0x101546e0c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x138>
101546d64:     	ldr	w9, [x11, #0x1c]
101546d68:     	ldr	x10, [x24, #0x390]
101546d6c:     	cmp	x10, x9
101546d70:     	b.ls	0x10154730c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x638>
101546d74:     	ldr	x10, [x24, #0x388]
101546d78:     	mov	w12, #0x180             ; =384
101546d7c:     	umaddl	x10, w9, w12, x10
101546d80:     	ldp	x10, x12, [x10]
101546d84:     	mov	w13, #0x5               ; =5
101546d88:     	eor	x10, x10, x13
101546d8c:     	orr	x10, x10, x12
101546d90:     	cbnz	x10, 0x101546e5c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x188>
101546d94:     	ldr	w9, [x11]
101546d98:     	lsr	x10, x2, #32
101546d9c:     	cbnz	x10, 0x101546f88 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2b4>
101546da0:     	cbz	w9, 0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546da4:     	ldr	w9, [x11, #0x4]
101546da8:     	cmp	w9, w2
101546dac:     	b.ne	0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546db0:     	b	0x101546dcc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546db4:     	lsr	x8, x2, #32
101546db8:     	cbnz	x8, 0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546dbc:     	cmp	w7, w2
101546dc0:     	b.ne	0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546dc4:     	ldr	x24, [x1, #0x40]
101546dc8:     	ldr	x8, [x24, #0x458]
101546dcc:     	mov	w9, w2
101546dd0:     	cmp	x8, x9
101546dd4:     	b.ls	0x101546e44 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x170>
101546dd8:     	ldr	x8, [x24, #0x450]
101546ddc:     	add	x9, x8, x9, lsl #6
101546de0:     	ldr	x10, [x9, #0x20]
101546de4:     	tst	w3, #0x1
101546de8:     	csel	x8, x4, x10, ne
101546dec:     	cmp	x8, x10
101546df0:     	b.hs	0x101546ea0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x1cc>
101546df4:     	mov	w8, #0xc                ; =12
101546df8:     	strb	w8, [x0]
101546dfc:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x25f0>
101546e00:     	add	x8, x8, #0x3
101546e04:     	mov	w9, #0x24               ; =36
101546e08:     	b	0x101546fa8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2d4>
101546e0c:     	lsr	x9, x2, #32
101546e10:     	cbnz	x9, 0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546e14:     	ldr	w9, [x11]
101546e18:     	tbz	w9, #0x0, 0x101546e28 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x154>
101546e1c:     	ldr	w9, [x11, #0x4]
101546e20:     	cmp	w9, w2
101546e24:     	b.eq	0x101546dcc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546e28:     	ldr	w9, [x11, #0x8]
101546e2c:     	cmp	w9, #0x1
101546e30:     	b.ne	0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546e34:     	ldr	w9, [x11, #0xc]
101546e38:     	cmp	w9, w2
101546e3c:     	b.ne	0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546e40:     	b	0x101546dcc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546e44:     	mov	w8, #0xc                ; =12
101546e48:     	strb	w8, [x0]
101546e4c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101546e50:     	add	x8, x8, #0xed8
101546e54:     	mov	w9, #0x22               ; =34
101546e58:     	b	0x101546fa8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2d4>
101546e5c:     	lsl	x9, x9, #1
101546e60:     	ldr	x10, [x1, #0x50]
101546e64:     	cmp	x9, x10
101546e68:     	b.hs	0x101547320 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x64c>
101546e6c:     	ldr	x10, [x1, #0x48]
101546e70:     	ldr	x9, [x10, x9, lsl #3]
101546e74:     	cmp	x9, #0x0
101546e78:     	cset	w9, eq
101546e7c:     	add	x9, x11, w9, uxtw #3
101546e80:     	ldr	w10, [x9]
101546e84:     	lsr	x11, x2, #32
101546e88:     	cbnz	x11, 0x101546f90 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2bc>
101546e8c:     	tbz	w10, #0x0, 0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546e90:     	ldr	w9, [x9, #0x4]
101546e94:     	cmp	w9, w2
101546e98:     	b.ne	0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546e9c:     	b	0x101546dcc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546ea0:     	mov	x25, x1
101546ea4:     	mov	x23, x2
101546ea8:     	mov	x21, x0
101546eac:     	ldr	x4, [x29, #0x10]
101546eb0:     	ldp	w27, w26, [x9, #0x10]
101546eb4:     	ldp	w28, w19, [x9, #0x18]
101546eb8:     	ldrb	w22, [x9, #0x3c]
101546ebc:     	ldur	q0, [x9, #0x28]
101546ec0:     	str	q0, [sp, #0x40]
101546ec4:     	ldr	w9, [x9, #0x38]
101546ec8:     	str	w9, [sp, #0x50]
101546ecc:     	add	x0, sp, #0x8
101546ed0:     	add	x1, x20, #0x10
101546ed4:     	add	x3, sp, #0x40
101546ed8:     	mov	x2, x8
101546edc:     	bl	0x10154fe64 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge>
101546ee0:     	ldrb	w8, [sp, #0x8]
101546ee4:     	cmp	w8, #0x13
101546ee8:     	b.ne	0x101546fb0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2dc>
101546eec:     	cmp	w28, #0x1
101546ef0:     	mov	x10, x21
101546ef4:     	mov	x11, x25
101546ef8:     	b.le	0x101546fd0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2fc>
101546efc:     	cmp	w28, #0x2
101546f00:     	b.eq	0x101546ff4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x320>
101546f04:     	cmp	w28, #0x3
101546f08:     	b.ne	0x101547048 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x374>
101546f0c:     	ldr	x0, [x24, #0x388]
101546f10:     	ldr	x1, [x24, #0x390]
101546f14:     	mov	x2, x19
101546f18:     	bl	0x1015571d0 <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
101546f1c:     	mov	x10, x21
101546f20:     	ldr	w8, [x20]
101546f24:     	tbz	w8, #0x0, 0x101547144 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x470>
101546f28:     	ldr	w8, [x20, #0x4]
101546f2c:     	cmp	w8, w19
101546f30:     	b.ne	0x101547144 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x470>
101546f34:     	mov	w8, #0x1                ; =1
101546f38:     	bfi	x8, x19, #1, #32
101546f3c:     	ldr	x1, [x25, #0x50]
101546f40:     	cmp	x8, x1
101546f44:     	b.hs	0x101547348 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x674>
101546f48:     	ldr	x9, [x25, #0x48]
101546f4c:     	ldr	x8, [x9, x8, lsl #3]
101546f50:     	cmp	x8, #0x1
101546f54:     	b.ne	0x101547144 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x470>
101546f58:     	cmp	x0, #0x2
101546f5c:     	mov	x12, x23
101546f60:     	mov	x11, x25
101546f64:     	b.eq	0x1015471f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x524>
101546f68:     	lsl	x8, x19, #1
101546f6c:     	ldr	x11, [x9, x8, lsl #3]
101546f70:     	cbz	x11, 0x101547144 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x470>
101546f74:     	sub	x11, x11, #0x1
101546f78:     	str	x11, [x9, x8, lsl #3]
101546f7c:     	mov	x12, x23
101546f80:     	mov	x11, x25
101546f84:     	b	0x1015471f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x524>
101546f88:     	tbnz	w9, #0x0, 0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546f8c:     	b	0x101546f94 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c0>
101546f90:     	tbnz	w10, #0x0, 0x101546d00 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546f94:     	mov	w8, #0xc                ; =12
101546f98:     	strb	w8, [x0]
101546f9c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101546fa0:     	add	x8, x8, #0xebd
101546fa4:     	mov	w9, #0x1b               ; =27
101546fa8:     	stp	x8, x9, [x0, #0x8]
101546fac:     	b	0x101546d14 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
101546fb0:     	ldur	q0, [sp, #0x8]
101546fb4:     	ldur	q1, [sp, #0x18]
101546fb8:     	stp	q0, q1, [x21]
101546fbc:     	ldur	q0, [sp, #0x28]
101546fc0:     	str	q0, [x21, #0x20]
101546fc4:     	ldr	x8, [sp, #0x38]
101546fc8:     	str	x8, [x21, #0x30]
101546fcc:     	b	0x101546d14 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
101546fd0:     	cbnz	w28, 0x1015470bc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x3e8>
101546fd4:     	ldr	w8, [x20]
101546fd8:     	mov	x12, x23
101546fdc:     	tbz	w8, #0x0, 0x10154715c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x488>
101546fe0:     	tbz	w27, #0x0, 0x101547160 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x48c>
101546fe4:     	ldr	w8, [x20, #0x4]
101546fe8:     	cmp	w8, w26
101546fec:     	b.ne	0x101547160 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x48c>
101546ff0:     	b	0x1015471f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x524>
101546ff4:     	ldr	w8, [x20]
101546ff8:     	tbz	w8, #0x0, 0x101547030 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x35c>
101546ffc:     	ldr	w8, [x20, #0x4]
101547000:     	cmp	w8, w19
101547004:     	b.ne	0x101547030 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x35c>
101547008:     	mov	w8, #0x1                ; =1
10154700c:     	orr	x0, x8, x19, lsl #1
101547010:     	ldr	x1, [x11, #0x50]
101547014:     	cmp	x0, x1
101547018:     	b.hs	0x101547358 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x684>
10154701c:     	mov	x12, x23
101547020:     	ldr	x8, [x11, #0x48]
101547024:     	ldr	x8, [x8, x0, lsl #3]
101547028:     	cmp	x8, #0x1
10154702c:     	b.eq	0x1015471f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x524>
101547030:     	mov	w8, #0xc                ; =12
101547034:     	strb	w8, [x10]
101547038:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10154703c:     	add	x8, x8, #0xf59
101547040:     	mov	w9, #0x26               ; =38
101547044:     	b	0x10154724c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x578>
101547048:     	ldr	w8, [x20]
10154704c:     	tbz	w8, #0x0, 0x10154712c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x458>
101547050:     	ldr	w8, [x20, #0x4]
101547054:     	cmp	w8, w19
101547058:     	b.ne	0x10154712c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x458>
10154705c:     	lsl	x0, x19, #1
101547060:     	ldr	x1, [x11, #0x50]
101547064:     	cmp	x0, x1
101547068:     	b.hs	0x101547364 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x690>
10154706c:     	ldr	x8, [x11, #0x48]
101547070:     	ldr	x9, [x8, x0, lsl #3]
101547074:     	cbnz	x9, 0x10154712c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x458>
101547078:     	orr	x0, x0, #0x1
10154707c:     	cmp	x0, x1
101547080:     	b.hs	0x101547370 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x69c>
101547084:     	ldr	x9, [x8, x0, lsl #3]
101547088:     	cmp	x9, #0x1
10154708c:     	b.ne	0x10154712c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x458>
101547090:     	str	xzr, [x8, x0, lsl #3]
101547094:     	ldr	x0, [x24, #0x388]
101547098:     	ldr	x1, [x24, #0x390]
10154709c:     	mov	x2, x19
1015470a0:     	bl	0x1015571d0 <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
1015470a4:     	cbz	x0, 0x101547280 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5ac>
1015470a8:     	cmp	x0, #0x2
1015470ac:     	b.ne	0x10154728c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5b8>
1015470b0:     	add	x9, x1, #0x14
1015470b4:     	mov	w8, #0x18               ; =24
1015470b8:     	b	0x101547294 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5c0>
1015470bc:     	ldr	x0, [x24, #0x388]
1015470c0:     	ldr	x1, [x24, #0x390]
1015470c4:     	mov	x2, x19
1015470c8:     	bl	0x1015571d0 <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
1015470cc:     	mov	w8, #0x4                ; =4
1015470d0:     	add	x9, x1, #0x140
1015470d4:     	mov	w10, #0x144             ; =324
1015470d8:     	add	x11, x1, #0x14
1015470dc:     	mov	w12, #0x18              ; =24
1015470e0:     	cmp	x0, #0x1
1015470e4:     	csel	x10, x10, x12, eq
1015470e8:     	csel	x9, x9, x11, eq
1015470ec:     	cmp	x0, #0x0
1015470f0:     	csel	x8, x8, x10, eq
1015470f4:     	csel	x9, x1, x9, eq
1015470f8:     	ldr	w9, [x9]
1015470fc:     	ldr	w10, [x20]
101547100:     	cmp	w10, #0x1
101547104:     	mov	x10, x21
101547108:     	mov	x11, x25
10154710c:     	b.ne	0x101547178 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4a4>
101547110:     	tbz	w9, #0x0, 0x1015471a0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4cc>
101547114:     	mov	x12, x23
101547118:     	ldr	w8, [x1, x8]
10154711c:     	ldr	w9, [x20, #0x4]
101547120:     	cmp	w9, w8
101547124:     	b.eq	0x101547180 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4ac>
101547128:     	b	0x1015471a0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4cc>
10154712c:     	mov	w8, #0xc                ; =12
101547130:     	strb	w8, [x10]
101547134:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101547138:     	add	x8, x8, #0xfe0
10154713c:     	mov	w9, #0x23               ; =35
101547140:     	b	0x10154724c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x578>
101547144:     	mov	w8, #0xc                ; =12
101547148:     	strb	w8, [x10]
10154714c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101547150:     	add	x8, x8, #0xf7f
101547154:     	mov	w9, #0x23               ; =35
101547158:     	b	0x10154724c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x578>
10154715c:     	tbz	w27, #0x0, 0x1015471f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x524>
101547160:     	mov	w8, #0xc                ; =12
101547164:     	strb	w8, [x10]
101547168:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10154716c:     	add	x8, x8, #0xefa
101547170:     	mov	w9, #0x2a               ; =42
101547174:     	b	0x10154724c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x578>
101547178:     	mov	x12, x23
10154717c:     	tbnz	w9, #0x0, 0x1015471a0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4cc>
101547180:     	mov	w8, #0x1                ; =1
101547184:     	bfi	x8, x19, #1, #32
101547188:     	ldr	x9, [x11, #0x50]
10154718c:     	cmp	x8, x9
101547190:     	b.hs	0x101547334 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x660>
101547194:     	ldr	x9, [x11, #0x48]
101547198:     	ldr	x13, [x9, x8, lsl #3]
10154719c:     	cbz	x13, 0x1015471b8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4e4>
1015471a0:     	mov	w8, #0xc                ; =12
1015471a4:     	strb	w8, [x10]
1015471a8:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015471ac:     	add	x8, x8, #0xf24
1015471b0:     	mov	w9, #0x35               ; =53
1015471b4:     	b	0x10154724c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x578>
1015471b8:     	lsl	x13, x19, #1
1015471bc:     	cmp	x0, #0x2
1015471c0:     	b.eq	0x1015471d8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x504>
1015471c4:     	cmp	x0, #0x1
1015471c8:     	b.ne	0x1015471e0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x50c>
1015471cc:     	mov	x14, #0x0               ; =0
1015471d0:     	mov	w15, #0x2               ; =2
1015471d4:     	b	0x1015471e8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x514>
1015471d8:     	mov	x14, #0x0               ; =0
1015471dc:     	b	0x1015471e4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x510>
1015471e0:     	ldr	x14, [x1, #0x8]
1015471e4:     	mov	w15, #0x1               ; =1
1015471e8:     	str	x14, [x9, x13, lsl #3]
1015471ec:     	str	x15, [x9, x8, lsl #3]
1015471f0:     	mov	w8, #0x1                ; =1
1015471f4:     	stp	w8, w19, [x20]
1015471f8:     	tbz	w22, #0x0, 0x101547254 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x580>
1015471fc:     	ldr	w8, [x20]
101547200:     	cbnz	w8, 0x101547238 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x564>
101547204:     	ldp	x8, x9, [x11, #0x48]
101547208:     	and	x10, x9, #0xffffffffffffffe
10154720c:     	add	x11, x8, x10, lsl #3
101547210:     	and	x9, x9, #0x1
101547214:     	stp	x8, x10, [sp, #0x8]
101547218:     	stp	x11, x9, [sp, #0x18]
10154721c:     	mov	w8, #0x2                ; =2
101547220:     	str	x8, [sp, #0x28]
101547224:     	add	x0, sp, #0x8
101547228:     	bl	0x101527de0 <__RINvYINtNtNtCsgDHHaSskbIF_4core5slice4iter11ChunksExactyENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBT_3any5checkRSyNCNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB2d_11ControlViewNtNtB2f_13iteration_abi25NativeIterationDescriptorE16visit_from_entrys0_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB2h_>
10154722c:     	mov	x12, x23
101547230:     	mov	x10, x21
101547234:     	tbz	w0, #0x0, 0x101547254 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x580>
101547238:     	mov	w8, #0xc                ; =12
10154723c:     	strb	w8, [x10]
101547240:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101547244:     	add	x8, x8, #0xfa2
101547248:     	mov	w9, #0x20               ; =32
10154724c:     	stp	x8, x9, [x10, #0x8]
101547250:     	b	0x101546d14 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
101547254:     	mov	w8, #0x1                ; =1
101547258:     	stp	w8, w12, [x20, #0x8]
10154725c:     	strb	w22, [x20, #0x50]
101547260:     	ldr	x8, [x20, #0x48]
101547264:     	cmn	x8, #0x1
101547268:     	b.eq	0x1015472e0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x60c>
10154726c:     	add	x8, x8, #0x1
101547270:     	str	x8, [x20, #0x48]
101547274:     	mov	w8, #0x13               ; =19
101547278:     	strb	w8, [x10]
10154727c:     	b	0x101546d14 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
101547280:     	mov	w8, #0x4                ; =4
101547284:     	mov	x9, x1
101547288:     	b	0x101547294 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5c0>
10154728c:     	add	x9, x1, #0x140
101547290:     	mov	w8, #0x144              ; =324
101547294:     	mov	x10, x21
101547298:     	mov	x12, x23
10154729c:     	mov	x11, x25
1015472a0:     	ldr	w8, [x1, x8]
1015472a4:     	ldr	w9, [x9]
1015472a8:     	stp	w9, w8, [x20]
1015472ac:     	cmp	w9, #0x1
1015472b0:     	b.ne	0x1015472c4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5f0>
1015472b4:     	cbz	w27, 0x1015472c8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5f4>
1015472b8:     	cmp	w8, w26
1015472bc:     	b.eq	0x1015471f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x524>
1015472c0:     	b	0x1015472c8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5f4>
1015472c4:     	cbz	w27, 0x1015471f8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x524>
1015472c8:     	mov	w8, #0xc                ; =12
1015472cc:     	strb	w8, [x10]
1015472d0:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015472d4:     	add	x8, x8, #0xfc2
1015472d8:     	mov	w9, #0x1e               ; =30
1015472dc:     	b	0x10154724c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x578>
1015472e0:     	mov	w8, #0xc                ; =12
1015472e4:     	strb	w8, [x10]
1015472e8:     	adrp	x8, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
1015472ec:     	add	x8, x8, #0xc3e
1015472f0:     	mov	w9, #0x1d               ; =29
1015472f4:     	b	0x10154724c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x578>
1015472f8:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015472fc:     	add	x2, x2, #0x9d0
101547300:     	mov	x0, x9
101547304:     	mov	x1, x8
101547308:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154730c:     	adrp	x2, 0x107f0a000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.888+0x3e0>
101547310:     	add	x2, x2, #0x280
101547314:     	mov	x0, x9
101547318:     	mov	x1, x10
10154731c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547320:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547324:     	add	x2, x2, #0x9e8
101547328:     	mov	x0, x9
10154732c:     	mov	x1, x10
101547330:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547334:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547338:     	add	x2, x2, #0xa00
10154733c:     	mov	x0, x8
101547340:     	mov	x1, x9
101547344:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547348:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154734c:     	add	x2, x2, #0xa30
101547350:     	mov	x0, x8
101547354:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547358:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154735c:     	add	x2, x2, #0xa18
101547360:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547364:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547368:     	add	x2, x2, #0xa48
10154736c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547370:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547374:     	add	x2, x2, #0xa60
101547378:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
