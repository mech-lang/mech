
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101546dec <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>:
101546dec:     	sub	sp, sp, #0x120
101546df0:     	stp	x28, x27, [sp, #0xc0]
101546df4:     	stp	x26, x25, [sp, #0xd0]
101546df8:     	stp	x24, x23, [sp, #0xe0]
101546dfc:     	stp	x22, x21, [sp, #0xf0]
101546e00:     	stp	x20, x19, [sp, #0x100]
101546e04:     	stp	x29, x30, [sp, #0x110]
101546e08:     	add	x29, sp, #0x110
101546e0c:     	ldr	x23, [x1, #0x38]
101546e10:     	ldrb	w8, [x23, #0x50]
101546e14:     	tbz	w8, #0x0, 0x101546e4c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x60>
101546e18:     	mov	w8, #0xf                ; =15
101546e1c:     	strb	w8, [x0]
101546e20:     	ldr	d0, [x23, #0x8]
101546e24:     	str	d0, [x0, #0x8]
101546e28:     	str	x2, [x0, #0x10]
101546e2c:     	ldp	x29, x30, [sp, #0x110]
101546e30:     	ldp	x20, x19, [sp, #0x100]
101546e34:     	ldp	x22, x21, [sp, #0xf0]
101546e38:     	ldp	x24, x23, [sp, #0xe0]
101546e3c:     	ldp	x26, x25, [sp, #0xd0]
101546e40:     	ldp	x28, x27, [sp, #0xc0]
101546e44:     	add	sp, sp, #0x120
101546e48:     	ret
101546e4c:     	cmp	w5, #0x1
101546e50:     	b.ne	0x101546ecc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xe0>
101546e54:     	ldr	x27, [x1, #0x40]
101546e58:     	ldr	x8, [x27, #0x458]
101546e5c:     	mov	w9, w6
101546e60:     	cmp	x8, x9
101546e64:     	b.ls	0x1015475e8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x7fc>
101546e68:     	ldr	x10, [x27, #0x450]
101546e6c:     	add	x11, x10, x9, lsl #6
101546e70:     	ldr	w9, [x11, #0x18]
101546e74:     	cmp	w9, #0x2
101546e78:     	b.ne	0x101546f24 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x138>
101546e7c:     	ldr	w9, [x11, #0x1c]
101546e80:     	ldr	x10, [x27, #0x390]
101546e84:     	cmp	x10, x9
101546e88:     	b.ls	0x1015475fc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x810>
101546e8c:     	ldr	x10, [x27, #0x388]
101546e90:     	mov	w12, #0x180             ; =384
101546e94:     	umaddl	x10, w9, w12, x10
101546e98:     	ldp	x10, x12, [x10]
101546e9c:     	mov	w13, #0x5               ; =5
101546ea0:     	eor	x10, x10, x13
101546ea4:     	orr	x10, x10, x12
101546ea8:     	cbnz	x10, 0x101546f74 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x188>
101546eac:     	ldr	w9, [x11]
101546eb0:     	lsr	x10, x2, #32
101546eb4:     	cbnz	x10, 0x101547030 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x244>
101546eb8:     	cbz	w9, 0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546ebc:     	ldr	w9, [x11, #0x4]
101546ec0:     	cmp	w9, w2
101546ec4:     	b.ne	0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546ec8:     	b	0x101546ee4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546ecc:     	lsr	x8, x2, #32
101546ed0:     	cbnz	x8, 0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546ed4:     	cmp	w7, w2
101546ed8:     	b.ne	0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546edc:     	ldr	x27, [x1, #0x40]
101546ee0:     	ldr	x8, [x27, #0x458]
101546ee4:     	mov	w9, w2
101546ee8:     	cmp	x8, x9
101546eec:     	b.ls	0x101546f5c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x170>
101546ef0:     	ldr	x8, [x27, #0x450]
101546ef4:     	add	x8, x8, x9, lsl #6
101546ef8:     	ldr	x9, [x8, #0x20]
101546efc:     	tst	w3, #0x1
101546f00:     	csel	x22, x4, x9, ne
101546f04:     	cmp	x22, x9
101546f08:     	b.hs	0x101546fb8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x1cc>
101546f0c:     	mov	w8, #0xc                ; =12
101546f10:     	strb	w8, [x0]
101546f14:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101546f18:     	add	x8, x8, #0x483
101546f1c:     	mov	w9, #0x24               ; =36
101546f20:     	b	0x101547050 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x264>
101546f24:     	lsr	x9, x2, #32
101546f28:     	cbnz	x9, 0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546f2c:     	ldr	w9, [x11]
101546f30:     	tbz	w9, #0x0, 0x101546f40 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x154>
101546f34:     	ldr	w9, [x11, #0x4]
101546f38:     	cmp	w9, w2
101546f3c:     	b.eq	0x101546ee4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546f40:     	ldr	w9, [x11, #0x8]
101546f44:     	cmp	w9, #0x1
101546f48:     	b.ne	0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546f4c:     	ldr	w9, [x11, #0xc]
101546f50:     	cmp	w9, w2
101546f54:     	b.ne	0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546f58:     	b	0x101546ee4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546f5c:     	mov	w8, #0xc                ; =12
101546f60:     	strb	w8, [x0]
101546f64:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101546f68:     	add	x8, x8, #0x358
101546f6c:     	mov	w9, #0x22               ; =34
101546f70:     	b	0x101547050 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x264>
101546f74:     	lsl	x9, x9, #1
101546f78:     	ldr	x10, [x1, #0x50]
101546f7c:     	cmp	x9, x10
101546f80:     	b.hs	0x101547610 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x824>
101546f84:     	ldr	x10, [x1, #0x48]
101546f88:     	ldr	x9, [x10, x9, lsl #3]
101546f8c:     	cmp	x9, #0x0
101546f90:     	cset	w9, eq
101546f94:     	add	x9, x11, w9, uxtw #3
101546f98:     	ldr	w10, [x9]
101546f9c:     	lsr	x11, x2, #32
101546fa0:     	cbnz	x11, 0x101547038 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x24c>
101546fa4:     	tbz	w10, #0x0, 0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546fa8:     	ldr	w9, [x9, #0x4]
101546fac:     	cmp	w9, w2
101546fb0:     	b.ne	0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101546fb4:     	b	0x101546ee4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0xf8>
101546fb8:     	ldr	x9, [x29, #0x10]
101546fbc:     	ldr	w19, [x8, #0x28]
101546fc0:     	ldp	w11, w10, [x8, #0x10]
101546fc4:     	str	w10, [sp, #0x4]
101546fc8:     	ldp	w25, w26, [x8, #0x18]
101546fcc:     	ldrb	w10, [x8, #0x3c]
101546fd0:     	stp	w10, w11, [sp, #0x8]
101546fd4:     	ldur	x10, [x8, #0x2c]
101546fd8:     	str	x10, [sp, #0x20]
101546fdc:     	ldp	w8, w20, [x8, #0x34]
101546fe0:     	str	w8, [sp, #0x28]
101546fe4:     	cmp	w19, #0x2
101546fe8:     	cset	w21, ne
101546fec:     	mov	x24, x0
101546ff0:     	str	x2, [sp, #0x10]
101546ff4:     	mov	x28, x1
101546ff8:     	cbz	x9, 0x101547058 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x26c>
101546ffc:     	mov	x0, x23
101547000:     	ldr	x8, [x0, #0x28]!
101547004:     	cbz	x8, 0x101547084 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x298>
101547008:     	ldr	x3, [x23, #0x20]
10154700c:     	sub	x8, x29, #0x80
101547010:     	mov	x1, x9
101547014:     	mov	x2, x22
101547018:     	bl	0x102372d60 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped>
10154701c:     	ldurb	w10, [x29, #-0x80]
101547020:     	cmp	w10, #0x8
101547024:     	b.ne	0x1015470a4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2b8>
101547028:     	mov	w13, #0xe               ; =14
10154702c:     	b	0x101547128 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x33c>
101547030:     	tbnz	w9, #0x0, 0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
101547034:     	b	0x10154703c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x250>
101547038:     	tbnz	w10, #0x0, 0x101546e18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2c>
10154703c:     	mov	w8, #0xc                ; =12
101547040:     	strb	w8, [x0]
101547044:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101547048:     	add	x8, x8, #0x33d
10154704c:     	mov	w9, #0x1b               ; =27
101547050:     	stp	x8, x9, [x0, #0x8]
101547054:     	b	0x101546e2c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
101547058:     	add	x0, sp, #0x30
10154705c:     	add	x1, x23, #0x10
101547060:     	mov	x2, x21
101547064:     	mov	x3, x20
101547068:     	mov	x4, x22
10154706c:     	bl	0x1015293e0 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101547070:     	mov	x11, x28
101547074:     	ldr	x12, [sp, #0x10]
101547078:     	mov	x10, x24
10154707c:     	ldrb	w13, [sp, #0x30]
101547080:     	b	0x101547138 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x34c>
101547084:     	bl	0x10236cb38 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
101547088:     	tbz	w0, #0x0, 0x1015470cc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2e0>
10154708c:     	stp	w21, w20, [sp, #0x60]
101547090:     	strb	wzr, [sp, #0x38]
101547094:     	mov	w8, #0x7                ; =7
101547098:     	strb	w8, [sp, #0x30]
10154709c:     	mov	x10, x24
1015470a0:     	b	0x1015471d4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x3e8>
1015470a4:     	ldurb	w11, [x29, #-0x7f]
1015470a8:     	ldp	x9, x8, [x29, #-0x78]
1015470ac:     	cmp	w10, #0x6
1015470b0:     	b.ne	0x1015470fc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x310>
1015470b4:     	cmp	w11, #0x6
1015470b8:     	b.ne	0x1015470fc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x310>
1015470bc:     	stp	w21, w20, [sp, #0x48]
1015470c0:     	mov	w13, #0x6               ; =6
1015470c4:     	stp	x9, x8, [sp, #0x38]
1015470c8:     	b	0x101547128 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x33c>
1015470cc:     	ldp	x9, x8, [x23, #0x18]
1015470d0:     	adds	x9, x9, x22
1015470d4:     	b.hs	0x1015475b8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x7cc>
1015470d8:     	cmp	x9, x8
1015470dc:     	mov	x10, x24
1015470e0:     	ldr	x12, [sp, #0x10]
1015470e4:     	b.ls	0x101547378 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x58c>
1015470e8:     	mov	w11, #0x6               ; =6
1015470ec:     	strb	w11, [sp, #0x30]
1015470f0:     	stp	x9, x8, [sp, #0x38]
1015470f4:     	stp	w21, w20, [sp, #0x48]
1015470f8:     	b	0x1015471d4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x3e8>
1015470fc:     	stp	w21, w20, [sp, #0x60]
101547100:     	strb	w10, [sp, #0x38]
101547104:     	strb	w11, [sp, #0x39]
101547108:     	ldur	w10, [x29, #-0x7e]
10154710c:     	stur	w10, [sp, #0x3a]
101547110:     	ldurh	w10, [x29, #-0x7a]
101547114:     	strh	w10, [sp, #0x3e]
101547118:     	stp	x9, x8, [sp, #0x40]
10154711c:     	ldur	q0, [x29, #-0x68]
101547120:     	mov	w13, #0x7               ; =7
101547124:     	str	q0, [sp, #0x50]
101547128:     	mov	x10, x24
10154712c:     	ldr	x12, [sp, #0x10]
101547130:     	mov	x11, x28
101547134:     	strb	w13, [sp, #0x30]
101547138:     	cmp	w13, #0xe
10154713c:     	b.ne	0x1015471d4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x3e8>
101547140:     	cmp	w25, #0x1
101547144:     	b.le	0x101547388 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x59c>
101547148:     	cmp	w25, #0x2
10154714c:     	b.eq	0x101547284 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x498>
101547150:     	cmp	w25, #0x3
101547154:     	b.ne	0x1015472d4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4e8>
101547158:     	ldr	x0, [x27, #0x388]
10154715c:     	ldr	x1, [x27, #0x390]
101547160:     	mov	x2, x26
101547164:     	bl	0x10155735c <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
101547168:     	mov	x10, x24
10154716c:     	ldr	w8, [x23]
101547170:     	tbz	w8, #0x0, 0x101547360 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x574>
101547174:     	ldr	w8, [x23, #0x4]
101547178:     	cmp	w8, w26
10154717c:     	b.ne	0x101547360 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x574>
101547180:     	mov	w8, #0x1                ; =1
101547184:     	bfi	x8, x26, #1, #32
101547188:     	ldr	x1, [x28, #0x50]
10154718c:     	cmp	x8, x1
101547190:     	b.hs	0x101547638 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x84c>
101547194:     	ldr	x9, [x28, #0x48]
101547198:     	ldr	x8, [x9, x8, lsl #3]
10154719c:     	cmp	x8, #0x1
1015471a0:     	b.ne	0x101547360 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x574>
1015471a4:     	cmp	x0, #0x2
1015471a8:     	ldr	x12, [sp, #0x10]
1015471ac:     	mov	x11, x28
1015471b0:     	b.eq	0x1015474c0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6d4>
1015471b4:     	lsl	x8, x26, #1
1015471b8:     	ldr	x11, [x9, x8, lsl #3]
1015471bc:     	cbz	x11, 0x101547360 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x574>
1015471c0:     	sub	x11, x11, #0x1
1015471c4:     	str	x11, [x9, x8, lsl #3]
1015471c8:     	ldr	x12, [sp, #0x10]
1015471cc:     	mov	x11, x28
1015471d0:     	b	0x1015474c0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6d4>
1015471d4:     	ldrb	w8, [sp, #0x30]
1015471d8:     	ldur	q0, [sp, #0x38]
1015471dc:     	cmp	w8, #0x6
1015471e0:     	b.ne	0x101547210 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x424>
1015471e4:     	ldr	x8, [sp, #0x20]
1015471e8:     	str	x8, [sp, #0x78]
1015471ec:     	ldr	w8, [sp, #0x28]
1015471f0:     	str	w8, [sp, #0x80]
1015471f4:     	add	x0, sp, #0x30
1015471f8:     	str	q0, [sp, #0x10]
1015471fc:     	bl	0x1015249cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7runtime20NativeExecutionErrorEBM_>
101547200:     	ldr	q0, [sp, #0x10]
101547204:     	mov	x10, x24
101547208:     	mov	w8, #0xe                ; =14
10154720c:     	b	0x101547244 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x458>
101547210:     	ldur	w9, [sp, #0x31]
101547214:     	str	w9, [sp, #0x88]
101547218:     	ldr	w19, [sp, #0x48]
10154721c:     	ldr	w9, [sp, #0x34]
101547220:     	stur	w9, [sp, #0x8b]
101547224:     	ldur	x9, [sp, #0x4c]
101547228:     	str	x9, [sp, #0x78]
10154722c:     	ldp	w9, w20, [sp, #0x54]
101547230:     	str	w9, [sp, #0x80]
101547234:     	ldur	x9, [sp, #0x5c]
101547238:     	str	x9, [sp, #0x68]
10154723c:     	ldr	w9, [sp, #0x64]
101547240:     	str	w9, [sp, #0x70]
101547244:     	strb	w8, [x10]
101547248:     	ldr	w8, [sp, #0x88]
10154724c:     	stur	w8, [x10, #0x1]
101547250:     	ldur	w8, [sp, #0x8b]
101547254:     	str	w8, [x10, #0x4]
101547258:     	stur	q0, [x10, #0x8]
10154725c:     	str	w19, [x10, #0x18]
101547260:     	ldr	x8, [sp, #0x78]
101547264:     	stur	x8, [x10, #0x1c]
101547268:     	ldr	w8, [sp, #0x80]
10154726c:     	stp	w8, w20, [x10, #0x24]
101547270:     	ldr	x8, [sp, #0x68]
101547274:     	stur	x8, [x10, #0x2c]
101547278:     	ldr	w8, [sp, #0x70]
10154727c:     	str	w8, [x10, #0x34]
101547280:     	b	0x101546e2c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
101547284:     	ldr	w8, [x23]
101547288:     	tbz	w8, #0x0, 0x1015472bc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4d0>
10154728c:     	ldr	w8, [x23, #0x4]
101547290:     	cmp	w8, w26
101547294:     	b.ne	0x1015472bc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x4d0>
101547298:     	mov	w8, #0x1                ; =1
10154729c:     	orr	x0, x8, x26, lsl #1
1015472a0:     	ldr	x1, [x11, #0x50]
1015472a4:     	cmp	x0, x1
1015472a8:     	b.hs	0x101547648 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x85c>
1015472ac:     	ldr	x8, [x11, #0x48]
1015472b0:     	ldr	x8, [x8, x0, lsl #3]
1015472b4:     	cmp	x8, #0x1
1015472b8:     	b.eq	0x1015474c0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6d4>
1015472bc:     	mov	w8, #0xc                ; =12
1015472c0:     	strb	w8, [x10]
1015472c4:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
1015472c8:     	add	x8, x8, #0x3d9
1015472cc:     	mov	w9, #0x26               ; =38
1015472d0:     	b	0x101547518 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
1015472d4:     	ldr	w8, [x23]
1015472d8:     	tbz	w8, #0x0, 0x101547348 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x55c>
1015472dc:     	ldr	w8, [x23, #0x4]
1015472e0:     	cmp	w8, w26
1015472e4:     	b.ne	0x101547348 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x55c>
1015472e8:     	lsl	x0, x26, #1
1015472ec:     	ldr	x1, [x11, #0x50]
1015472f0:     	cmp	x0, x1
1015472f4:     	b.hs	0x101547654 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x868>
1015472f8:     	ldr	x8, [x11, #0x48]
1015472fc:     	ldr	x9, [x8, x0, lsl #3]
101547300:     	cbnz	x9, 0x101547348 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x55c>
101547304:     	orr	x0, x0, #0x1
101547308:     	cmp	x0, x1
10154730c:     	b.hs	0x101547660 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x874>
101547310:     	ldr	x9, [x8, x0, lsl #3]
101547314:     	cmp	x9, #0x1
101547318:     	b.ne	0x101547348 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x55c>
10154731c:     	str	xzr, [x8, x0, lsl #3]
101547320:     	ldr	x0, [x27, #0x388]
101547324:     	ldr	x1, [x27, #0x390]
101547328:     	mov	x2, x26
10154732c:     	bl	0x10155735c <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
101547330:     	cbz	x0, 0x10154754c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x760>
101547334:     	cmp	x0, #0x2
101547338:     	b.ne	0x101547558 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x76c>
10154733c:     	add	x9, x1, #0x14
101547340:     	mov	w8, #0x18               ; =24
101547344:     	b	0x101547560 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x774>
101547348:     	mov	w8, #0xc                ; =12
10154734c:     	strb	w8, [x10]
101547350:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101547354:     	add	x8, x8, #0x460
101547358:     	mov	w9, #0x23               ; =35
10154735c:     	b	0x101547518 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
101547360:     	mov	w8, #0xc                ; =12
101547364:     	strb	w8, [x10]
101547368:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
10154736c:     	add	x8, x8, #0x3ff
101547370:     	mov	w9, #0x23               ; =35
101547374:     	b	0x101547518 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
101547378:     	mov	x11, x28
10154737c:     	str	x9, [x23, #0x18]
101547380:     	cmp	w25, #0x1
101547384:     	b.gt	0x101547148 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x35c>
101547388:     	cbnz	w25, 0x1015473b0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x5c4>
10154738c:     	ldr	w8, [x23]
101547390:     	tbz	w8, #0x0, 0x101547420 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x634>
101547394:     	ldr	w8, [sp, #0xc]
101547398:     	tbz	w8, #0x0, 0x101547428 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x63c>
10154739c:     	ldr	w8, [x23, #0x4]
1015473a0:     	ldr	w9, [sp, #0x4]
1015473a4:     	cmp	w8, w9
1015473a8:     	b.ne	0x101547428 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x63c>
1015473ac:     	b	0x1015474c0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6d4>
1015473b0:     	ldr	x0, [x27, #0x388]
1015473b4:     	ldr	x1, [x27, #0x390]
1015473b8:     	mov	x2, x26
1015473bc:     	bl	0x10155735c <__RNvXs0_NtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program5imageNtB5_23NativeProgramDescriptorNtNtB9_17iteration_runtime9VisitPlan9iteration>
1015473c0:     	mov	w8, #0x4                ; =4
1015473c4:     	add	x9, x1, #0x140
1015473c8:     	mov	w10, #0x144             ; =324
1015473cc:     	add	x11, x1, #0x14
1015473d0:     	mov	w12, #0x18              ; =24
1015473d4:     	cmp	x0, #0x1
1015473d8:     	csel	x10, x10, x12, eq
1015473dc:     	csel	x9, x9, x11, eq
1015473e0:     	cmp	x0, #0x0
1015473e4:     	csel	x8, x8, x10, eq
1015473e8:     	csel	x9, x1, x9, eq
1015473ec:     	ldr	w9, [x9]
1015473f0:     	ldr	w10, [x23]
1015473f4:     	cmp	w10, #0x1
1015473f8:     	mov	x10, x24
1015473fc:     	mov	x11, x28
101547400:     	b.ne	0x101547440 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x654>
101547404:     	ldr	x12, [sp, #0x10]
101547408:     	tbz	w9, #0x0, 0x101547468 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x67c>
10154740c:     	ldr	w8, [x1, x8]
101547410:     	ldr	w9, [x23, #0x4]
101547414:     	cmp	w9, w8
101547418:     	b.eq	0x101547448 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x65c>
10154741c:     	b	0x101547468 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x67c>
101547420:     	ldr	w8, [sp, #0xc]
101547424:     	tbz	w8, #0x0, 0x1015474c0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6d4>
101547428:     	mov	w8, #0xc                ; =12
10154742c:     	strb	w8, [x10]
101547430:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101547434:     	add	x8, x8, #0x37a
101547438:     	mov	w9, #0x2a               ; =42
10154743c:     	b	0x101547518 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
101547440:     	ldr	x12, [sp, #0x10]
101547444:     	tbnz	w9, #0x0, 0x101547468 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x67c>
101547448:     	mov	w8, #0x1                ; =1
10154744c:     	bfi	x8, x26, #1, #32
101547450:     	ldr	x9, [x11, #0x50]
101547454:     	cmp	x8, x9
101547458:     	b.hs	0x101547624 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x838>
10154745c:     	ldr	x9, [x11, #0x48]
101547460:     	ldr	x13, [x9, x8, lsl #3]
101547464:     	cbz	x13, 0x101547480 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x694>
101547468:     	mov	w8, #0xc                ; =12
10154746c:     	strb	w8, [x10]
101547470:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101547474:     	add	x8, x8, #0x3a4
101547478:     	mov	w9, #0x35               ; =53
10154747c:     	b	0x101547518 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
101547480:     	lsl	x13, x26, #1
101547484:     	cmp	x0, #0x2
101547488:     	b.eq	0x1015474a0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6b4>
10154748c:     	cmp	x0, #0x1
101547490:     	b.ne	0x1015474a8 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6bc>
101547494:     	mov	x14, #0x0               ; =0
101547498:     	mov	w15, #0x2               ; =2
10154749c:     	b	0x1015474b0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6c4>
1015474a0:     	mov	x14, #0x0               ; =0
1015474a4:     	b	0x1015474ac <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6c0>
1015474a8:     	ldr	x14, [x1, #0x8]
1015474ac:     	mov	w15, #0x1               ; =1
1015474b0:     	str	x14, [x9, x13, lsl #3]
1015474b4:     	str	x15, [x9, x8, lsl #3]
1015474b8:     	mov	w8, #0x1                ; =1
1015474bc:     	stp	w8, w26, [x23]
1015474c0:     	ldr	w19, [sp, #0x8]
1015474c4:     	tbz	w19, #0x0, 0x101547520 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x734>
1015474c8:     	ldr	w8, [x23]
1015474cc:     	cbnz	w8, 0x101547504 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x718>
1015474d0:     	ldp	x8, x9, [x11, #0x48]
1015474d4:     	and	x10, x9, #0xffffffffffffffe
1015474d8:     	add	x11, x8, x10, lsl #3
1015474dc:     	and	x9, x9, #0x1
1015474e0:     	stp	x8, x10, [sp, #0x30]
1015474e4:     	stp	x11, x9, [sp, #0x40]
1015474e8:     	mov	w8, #0x2                ; =2
1015474ec:     	str	x8, [sp, #0x50]
1015474f0:     	add	x0, sp, #0x30
1015474f4:     	bl	0x101527e98 <__RINvYINtNtNtCsgDHHaSskbIF_4core5slice4iter11ChunksExactyENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBT_3any5checkRSyNCNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB2d_11ControlViewNtNtB2f_13iteration_abi25NativeIterationDescriptorE16visit_from_entrys0_0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB2h_>
1015474f8:     	ldr	x12, [sp, #0x10]
1015474fc:     	mov	x10, x24
101547500:     	tbz	w0, #0x0, 0x101547520 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x734>
101547504:     	mov	w8, #0xc                ; =12
101547508:     	strb	w8, [x10]
10154750c:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
101547510:     	add	x8, x8, #0x422
101547514:     	mov	w9, #0x20               ; =32
101547518:     	stp	x8, x9, [x10, #0x8]
10154751c:     	b	0x101546e2c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
101547520:     	mov	w8, #0x1                ; =1
101547524:     	stp	w8, w12, [x23, #0x8]
101547528:     	strb	w19, [x23, #0x50]
10154752c:     	ldr	x8, [x23, #0x48]
101547530:     	cmn	x8, #0x1
101547534:     	b.eq	0x1015475d0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x7e4>
101547538:     	add	x8, x8, #0x1
10154753c:     	str	x8, [x23, #0x48]
101547540:     	mov	w8, #0x13               ; =19
101547544:     	strb	w8, [x10]
101547548:     	b	0x101546e2c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x40>
10154754c:     	mov	w8, #0x4                ; =4
101547550:     	mov	x9, x1
101547554:     	b	0x101547560 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x774>
101547558:     	add	x9, x1, #0x140
10154755c:     	mov	w8, #0x144              ; =324
101547560:     	ldr	x12, [sp, #0x10]
101547564:     	ldr	w8, [x1, x8]
101547568:     	ldr	w9, [x9]
10154756c:     	stp	w9, w8, [x23]
101547570:     	cmp	w9, #0x1
101547574:     	mov	x10, x24
101547578:     	mov	x11, x28
10154757c:     	b.ne	0x101547598 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x7ac>
101547580:     	ldr	w9, [sp, #0xc]
101547584:     	cbz	w9, 0x1015475a0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x7b4>
101547588:     	ldr	w9, [sp, #0x4]
10154758c:     	cmp	w8, w9
101547590:     	b.eq	0x1015474c0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6d4>
101547594:     	b	0x1015475a0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x7b4>
101547598:     	ldr	w8, [sp, #0xc]
10154759c:     	cbz	w8, 0x1015474c0 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x6d4>
1015475a0:     	mov	w8, #0xc                ; =12
1015475a4:     	strb	w8, [x10]
1015475a8:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x2170>
1015475ac:     	add	x8, x8, #0x442
1015475b0:     	mov	w9, #0x1e               ; =30
1015475b4:     	b	0x101547518 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
1015475b8:     	mov	w9, #0x6                ; =6
1015475bc:     	strb	w9, [sp, #0x30]
1015475c0:     	mov	x9, #-0x1               ; =-1
1015475c4:     	stp	x9, x8, [sp, #0x38]
1015475c8:     	stp	w21, w20, [sp, #0x48]
1015475cc:     	b	0x10154709c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x2b0>
1015475d0:     	mov	w8, #0xc                ; =12
1015475d4:     	strb	w8, [x10]
1015475d8:     	adrp	x8, 0x10754c000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.344+0x50d>
1015475dc:     	add	x8, x8, #0xbe
1015475e0:     	mov	w9, #0x1d               ; =29
1015475e4:     	b	0x101547518 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_+0x72c>
1015475e8:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015475ec:     	add	x2, x2, #0x9d0
1015475f0:     	mov	x0, x9
1015475f4:     	mov	x1, x8
1015475f8:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015475fc:     	adrp	x2, 0x107f0a000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.888+0x3e0>
101547600:     	add	x2, x2, #0x280
101547604:     	mov	x0, x9
101547608:     	mov	x1, x10
10154760c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547610:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547614:     	add	x2, x2, #0x9e8
101547618:     	mov	x0, x9
10154761c:     	mov	x1, x10
101547620:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547624:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547628:     	add	x2, x2, #0xa00
10154762c:     	mov	x0, x8
101547630:     	mov	x1, x9
101547634:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547638:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154763c:     	add	x2, x2, #0xa30
101547640:     	mov	x0, x8
101547644:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547648:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154764c:     	add	x2, x2, #0xa18
101547650:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547654:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547658:     	add	x2, x2, #0xa48
10154765c:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101547660:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101547664:     	add	x2, x2, #0xa60
101547668:     	bl	0x103a024a4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
