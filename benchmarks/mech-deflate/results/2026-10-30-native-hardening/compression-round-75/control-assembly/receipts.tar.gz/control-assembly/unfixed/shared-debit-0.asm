
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/unfixed/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102381918 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits>:
102381918:     	sub	sp, sp, #0x90
10238191c:     	stp	x26, x25, [sp, #0x40]
102381920:     	stp	x24, x23, [sp, #0x50]
102381924:     	stp	x22, x21, [sp, #0x60]
102381928:     	stp	x20, x19, [sp, #0x70]
10238192c:     	stp	x29, x30, [sp, #0x80]
102381930:     	add	x29, sp, #0x80
102381934:     	ldr	w8, [x4]
102381938:     	ldp	x9, x10, [x4, #0x8]
10238193c:     	ldp	x11, x12, [x1, #0x48]
102381940:     	cmp	x9, x11
102381944:     	csel	x9, x9, x11, lo
102381948:     	cmp	x10, x12
10238194c:     	csel	x10, x10, x12, lo
102381950:     	cmp	w8, #0x0
102381954:     	csel	x8, x9, x11, ne
102381958:     	csel	x12, x10, x12, ne
10238195c:     	ldr	x9, [x1, #0x20]
102381960:     	adds	x24, x9, x2
102381964:     	b.hs	0x102381ad4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x1bc>
102381968:     	ldr	x9, [x1, #0x28]
10238196c:     	adds	x25, x9, x3
102381970:     	b.hs	0x102381ad4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x1bc>
102381974:     	ldr	x9, [x1, #0x30]
102381978:     	adds	x9, x9, x24
10238197c:     	b.hs	0x102381ad4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x1bc>
102381980:     	ldr	x10, [x1, #0x38]
102381984:     	adds	x13, x10, x25
102381988:     	b.hs	0x102381ad4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x1bc>
10238198c:     	cmp	x9, x8
102381990:     	b.ls	0x1023819a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x88>
102381994:     	mov	w11, #0x6               ; =6
102381998:     	mov	w10, #0x6               ; =6
10238199c:     	b	0x1023819b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0xa0>
1023819a0:     	cmp	x13, x12
1023819a4:     	b.ls	0x1023819e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0xd0>
1023819a8:     	mov	w10, #0x6               ; =6
1023819ac:     	mov	w11, #0x5               ; =5
1023819b0:     	mov	x8, x12
1023819b4:     	mov	x9, x13
1023819b8:     	strb	w10, [x0]
1023819bc:     	strb	w11, [x0, #0x1]
1023819c0:     	mov	w10, #0x1               ; =1
1023819c4:     	strb	w10, [x0, #0x2]
1023819c8:     	stp	x9, x8, [x0, #0x8]
1023819cc:     	ldp	x29, x30, [sp, #0x80]
1023819d0:     	ldp	x20, x19, [sp, #0x70]
1023819d4:     	ldp	x22, x21, [sp, #0x60]
1023819d8:     	ldp	x24, x23, [sp, #0x50]
1023819dc:     	ldp	x26, x25, [sp, #0x40]
1023819e0:     	add	sp, sp, #0x90
1023819e4:     	ret
1023819e8:     	ldr	x8, [x1, #0x58]
1023819ec:     	cbz	x8, 0x102381a64 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x14c>
1023819f0:     	mov	x26, x1
1023819f4:     	mov	x23, x0
1023819f8:     	add	x0, x8, #0x10
1023819fc:     	mov	x21, x3
102381a00:     	mov	x22, x2
102381a04:     	bl	0x102394044 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers11lock_escrow>
102381a08:     	mov	x19, x0
102381a0c:     	mov	x20, x1
102381a10:     	add	x0, sp, #0x18
102381a14:     	add	x1, x19, #0x10
102381a18:     	mov	x2, x22
102381a1c:     	mov	x3, x21
102381a20:     	bl	0x10236dbd8 <__RNvMs0_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers7creditsNtB7_6Escrow11direct_next>
102381a24:     	ldrb	w21, [sp, #0x18]
102381a28:     	cmp	w21, #0x8
102381a2c:     	b.ne	0x102381a74 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x15c>
102381a30:     	add	x8, x19, #0x478
102381a34:     	ldur	q0, [sp, #0x20]
102381a38:     	str	q0, [x8]
102381a3c:     	tbnz	w20, #0x0, 0x102381a54 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x13c>
102381a40:     	adrp	x8, 0x10806f000 <__mi_heap_main+0xb28>
102381a44:     	add	x8, x8, #0xc28
102381a48:     	ldr	x8, [x8]
102381a4c:     	tst	x8, #0x7fffffffffffffff
102381a50:     	b.ne	0x102381adc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x1c4>
102381a54:     	ldr	x0, [x19]
102381a58:     	bl	0x102e5e2e4 <__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock>
102381a5c:     	mov	x0, x23
102381a60:     	mov	x1, x26
102381a64:     	stp	x24, x25, [x1, #0x20]
102381a68:     	mov	w8, #0x8                ; =8
102381a6c:     	strb	w8, [x0]
102381a70:     	b	0x1023819cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0xb4>
102381a74:     	ldur	w8, [sp, #0x19]
102381a78:     	str	w8, [sp, #0x10]
102381a7c:     	ldr	w8, [sp, #0x1c]
102381a80:     	stur	w8, [sp, #0x13]
102381a84:     	ldp	x22, x24, [sp, #0x20]
102381a88:     	ldur	q0, [sp, #0x30]
102381a8c:     	str	q0, [sp]
102381a90:     	tbnz	w20, #0x0, 0x102381aa8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x190>
102381a94:     	adrp	x8, 0x10806f000 <__mi_heap_main+0xb28>
102381a98:     	add	x8, x8, #0xc28
102381a9c:     	ldr	x8, [x8]
102381aa0:     	tst	x8, #0x7fffffffffffffff
102381aa4:     	b.ne	0x102381af0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x1d8>
102381aa8:     	ldr	x0, [x19]
102381aac:     	bl	0x102e5e2e4 <__RNvMNtNtNtNtNtCsgirOGyZpP7g_3std3sys3pal4unix4sync5mutexNtB2_5Mutex6unlock>
102381ab0:     	strb	w21, [x23]
102381ab4:     	ldr	w8, [sp, #0x10]
102381ab8:     	stur	w8, [x23, #0x1]
102381abc:     	ldur	w8, [sp, #0x13]
102381ac0:     	str	w8, [x23, #0x4]
102381ac4:     	stp	x22, x24, [x23, #0x8]
102381ac8:     	ldr	q0, [sp]
102381acc:     	stur	q0, [x23, #0x18]
102381ad0:     	b	0x1023819cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0xb4>
102381ad4:     	mov	w10, #0x2               ; =2
102381ad8:     	b	0x1023819b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0xa0>
102381adc:     	bl	0x103a019e0 <__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path>
102381ae0:     	tbnz	w0, #0x0, 0x102381a54 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x13c>
102381ae4:     	mov	w8, #0x1                ; =1
102381ae8:     	strb	w8, [x19, #0x8]
102381aec:     	b	0x102381a54 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x13c>
102381af0:     	bl	0x103a019e0 <__RNvNtNtCsgirOGyZpP7g_3std9panicking11panic_count17is_zero_slow_path>
102381af4:     	tbnz	w0, #0x0, 0x102381aa8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x190>
102381af8:     	mov	w8, #0x1                ; =1
102381afc:     	strb	w8, [x19, #0x8]
102381b00:     	b	0x102381aa8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits+0x190>
102381b04:     	mov	x21, x0
102381b08:     	and	w1, w20, #0x1
102381b0c:     	mov	x0, x19
102381b10:     	bl	0x1023444e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtNtCsgirOGyZpP7g_3std4sync6poison5mutex10MutexGuardINtNtB4_6option6OptionINtNtCsgKscDXrlV49_5alloc4sync3ArcNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEEEEB2B_>
102381b14:     	mov	x0, x21
102381b18:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
102381b1c:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
