
/private/tmp/mech-scoped-work-context-round75-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010157ea00 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge>:
10157ea00:     	sub	sp, sp, #0xa0
10157ea04:     	stp	x26, x25, [sp, #0x50]
10157ea08:     	stp	x24, x23, [sp, #0x60]
10157ea0c:     	stp	x22, x21, [sp, #0x70]
10157ea10:     	stp	x20, x19, [sp, #0x80]
10157ea14:     	stp	x29, x30, [sp, #0x90]
10157ea18:     	add	x29, sp, #0x90
10157ea1c:     	mov	x20, x3
10157ea20:     	mov	x19, x0
10157ea24:     	ldr	w23, [x3]
10157ea28:     	cmp	w23, #0x2
10157ea2c:     	cset	w21, ne
10157ea30:     	ldr	w22, [x3, #0x10]
10157ea34:     	mov	x0, x1
10157ea38:     	ldr	x8, [x0, #0x18]!
10157ea3c:     	cbz	x8, 0x10157ea88 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x88>
10157ea40:     	ldr	x9, [x1, #0x10]
10157ea44:     	add	x8, sp, #0x28
10157ea48:     	mov	x1, x2
10157ea4c:     	mov	x2, x9
10157ea50:     	bl	0x1023640c0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
10157ea54:     	ldrb	w8, [sp, #0x28]
10157ea58:     	cmp	w8, #0x8
10157ea5c:     	b.eq	0x10157eb3c <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x13c>
10157ea60:     	ldp	x14, x8, [sp, #0x28]
10157ea64:     	ldr	x9, [sp, #0x38]
10157ea68:     	and	x10, x14, #0xffff
10157ea6c:     	cmp	x10, #0x606
10157ea70:     	cset	w11, eq
10157ea74:     	b.ne	0x10157eae0 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xe0>
10157ea78:     	mov	x10, x22
10157ea7c:     	mov	x13, x21
10157ea80:     	tbz	w11, #0x0, 0x10157ead4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xd4>
10157ea84:     	b	0x10157eb04 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x104>
10157ea88:     	mov	x24, x2
10157ea8c:     	mov	x25, x1
10157ea90:     	bl	0x102363b50 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
10157ea94:     	tbz	w0, #0x0, 0x10157eab0 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xb0>
10157ea98:     	mov	w11, #0x0               ; =0
10157ea9c:     	mov	x8, #0x0                ; =0
10157eaa0:     	mov	w10, #0x0               ; =0
10157eaa4:     	mov	x13, x21
10157eaa8:     	tbz	w11, #0x0, 0x10157ead4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xd4>
10157eaac:     	b	0x10157eb04 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x104>
10157eab0:     	ldp	x8, x9, [x25, #0x8]
10157eab4:     	adds	x8, x8, x24
10157eab8:     	b.hs	0x10157eb60 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x160>
10157eabc:     	cmp	x8, x9
10157eac0:     	b.ls	0x10157eb38 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x138>
10157eac4:     	mov	w11, #0x1               ; =1
10157eac8:     	mov	x13, x21
10157eacc:     	mov	x10, x22
10157ead0:     	tbnz	w11, #0x0, 0x10157eb04 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x104>
10157ead4:     	mov	w11, #0x7               ; =7
10157ead8:     	add	x14, sp, #0x8
10157eadc:     	b	0x10157eb14 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x114>
10157eae0:     	lsr	x10, x9, #32
10157eae4:     	ldr	x12, [sp, #0x40]
10157eae8:     	str	x12, [sp, #0x8]
10157eaec:     	ldp	w13, w12, [sp, #0x48]
10157eaf0:     	str	w13, [sp, #0x10]
10157eaf4:     	mov	x13, x9
10157eaf8:     	mov	x9, x8
10157eafc:     	mov	x8, x14
10157eb00:     	tbz	w11, #0x0, 0x10157ead4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xd4>
10157eb04:     	ldr	w10, [x20, #0x4]
10157eb08:     	add	x14, x20, #0x8
10157eb0c:     	mov	w11, #0xe               ; =14
10157eb10:     	mov	x13, x23
10157eb14:     	ldr	w15, [x14, #0x8]
10157eb18:     	ldr	x14, [x14]
10157eb1c:     	strb	w11, [x19]
10157eb20:     	stp	x8, x9, [x19, #0x8]
10157eb24:     	stp	w13, w10, [x19, #0x18]
10157eb28:     	str	x14, [x19, #0x20]
10157eb2c:     	stp	w15, w12, [x19, #0x28]
10157eb30:     	stp	w21, w22, [x19, #0x30]
10157eb34:     	b	0x10157eb44 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x144>
10157eb38:     	str	x8, [x25, #0x8]
10157eb3c:     	mov	w8, #0x13               ; =19
10157eb40:     	strb	w8, [x19]
10157eb44:     	ldp	x29, x30, [sp, #0x90]
10157eb48:     	ldp	x20, x19, [sp, #0x80]
10157eb4c:     	ldp	x22, x21, [sp, #0x70]
10157eb50:     	ldp	x24, x23, [sp, #0x60]
10157eb54:     	ldp	x26, x25, [sp, #0x50]
10157eb58:     	add	sp, sp, #0xa0
10157eb5c:     	ret
10157eb60:     	mov	x8, #-0x1               ; =-1
10157eb64:     	mov	w11, #0x1               ; =1
10157eb68:     	mov	x13, x21
10157eb6c:     	mov	x10, x22
10157eb70:     	tbz	w11, #0x0, 0x10157ead4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xd4>
10157eb74:     	b	0x10157eb04 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x104>
