"""Restore only the measured rejected source scope, then verify and execute the accepted controls."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');base='9d640ebb55cd61d204b61b29a002930ff2efbb24';trial='33caedc032e26f67ac016cdc23f3f4152592d921';c=json.loads((r/'configuration.json').read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True)
assert not git('status','--porcelain').strip()
assert not git('diff',trial,'HEAD','--','src','hosts/gpu/src','.github').strip(),'Unexpected source changes since the measured trial'
paths=c['production_files']+c['test_files']+['.github/workflows/ci-full.yml']
original=set(git('ls-tree','-r','--name-only',base).splitlines())
p=r/'restored';p.mkdir()
(p/'rejected-source.patch').write_text(git('diff',base,'HEAD','--',*paths))
for relative in paths:
 target=w/relative
 if relative in original:target.write_bytes(subprocess.check_output(['git','show',base+':'+relative],cwd=w))
 else:target.unlink()
assert not git('diff',base,'--','src','hosts/gpu/src','.github').strip(),'Restoration is not exact'
subprocess.run(['git','add','--',*paths],cwd=w,check=True)
subprocess.run(['git','-c','gc.auto=0','commit','-m','Restore the accepted native runtime after scoped budget trials regress'],cwd=w,check=True)
head=git('rev-parse','HEAD').strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def tree(root):return {str(f.relative_to(root)):sha(f) for f in root.rglob('*') if f.is_file() and not {'target','.git'}.intersection(f.relative_to(root).parts)}
current=tree(w/'src/engine');staged=tree(r/'engine-parent/source/src/engine');assert current==staged
build=json.loads((r/'engine-parent/retained-rust-build.json').read_text());reuse=json.loads((r/'engine-parent/reuse-proof.json').read_text());binary=Path(build['command'][-1]);assert binary.is_file();assert sha(binary)==reuse['binary_sha256']
for row in build['libraries'].values():assert sha(Path(row['path']))==row['sha256']
proof={'restored_head':head,'accepted_checkpoint':base,'rejected_build_source':trial,'source_paths':paths,'all_engine_gpu_ci_source_identical_to_accepted':True,'engine_complete_tree_sha256':hashlib.sha256(json.dumps(current,sort_keys=True).encode()).hexdigest(),'engine_files':len(current),'unit_binary':str(binary),'unit_binary_sha256':sha(binary),'original_reuse_proof':reuse,'scope':'Production source is exactly the accepted checkpoint. The five new scoped-context controls and API are preserved in experiment receipts, not retained as an unused production API. Fresh test processes use the unchanged, whole-tree/library-proven accepted Rust unit binary; no recompilation is claimed.'}
(p/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
rows=[]
for label,cmd,count in [('budget',[str(binary),'resident::budget::','--nocapture','--test-threads=1'],108),('planner',[str(binary),'memory_planner::','--nocapture','--test-threads=1'],22),('memory-runtime',['python3','scripts/check-memory-runtime.py'],None),('format',['cargo','fmt','--all','--check'],None),('whitespace',['git','diff','--check'],None)]:
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'restored_source':head,'source_proof':'restored/source-proof.json','scope':'Actual execution after exact production restoration; accepted Rust test binary reused with whole-tree and library proofs.'}
 if count is not None:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;row['expected_tests']=count
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
 subprocess.run(['python3',str(r/'archive.py'),'restored-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/'source-proof.json'),str(p/'rejected-source.patch'),str(r/'restore-production.py')],check=True)
 print(label,q.returncode,row.get('executed_tests'),flush=True);q.check_returncode()
 if count is not None:assert row['executed_tests']==count
assert not git('diff',base,'HEAD','--','src','hosts/gpu/src','.github').strip()
d=json.loads((r/'decision.json').read_text());d['restoration_source']=head;d['source_disposition']='All Engine/GPU production, test and CI source changed by R74/R75 is restored exactly to accepted checkpoint '+base+' in '+head+'. The new API and five tests remain available in the committed experimental source receipts; no unused runtime API or scoped CI step is retained.';(r/'decision.json').write_text(json.dumps(d,indent=2)+'\n')
print('RESTORED_ACCEPTED_RUNTIME',head,flush=True)
