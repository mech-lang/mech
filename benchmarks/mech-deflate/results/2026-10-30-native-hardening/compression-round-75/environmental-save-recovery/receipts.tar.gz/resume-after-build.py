"""Resume only the failed Git save; the successful fresh Rust build is not repeated."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'engine-after';phase='after';c=json.loads((r/'configuration.json').read_text());build=json.loads((p/'build.json').read_text());assert build['exit']==0
cmd=build['command'];env=build['environment'];libs=build['libraries'];head=build['test_source_head'];source_pins=build['production_source_sha256'];source_files=list(source_pins)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=p/'source/src/engine';live=w/'src/engine'
def tree(root):return {str(f.relative_to(root)):sha(f) for f in root.rglob('*') if f.is_file() and 'target' not in f.relative_to(root).parts and '.git' not in f.relative_to(root).parts}
a=tree(stage);b=tree(live);assert a==b,'Staged Engine tree changed after successful Rust compilation'
for row in libs.values():assert sha(Path(row['path']))==row['sha256']
for path,digest in source_pins.items():assert sha(p/'source'/path)==digest
proof={'successful_build_exit':build['exit'],'binary_sha256':sha(Path(cmd[-1])),'complete_engine_tree_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest(),'verified_files':len(a),'source_head':head,'scope':'Fresh successful candidate Rust build was completed before a Git receipt write was denied. Verify unchanged complete Engine tree and all linked libraries, commit the existing build archive, then run every required unit selection. No new build is claimed.'}
(p/'resume-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
f=r/'failed-save';f.mkdir()
for name in ['after-driver.stdout','after-driver.stderr']:shutil.copy2(r/name,f/name)
prior=json.loads((r/'prior-failures.json').read_text()) if (r/'prior-failures.json').exists() else []
prior.append({'classification':'environmental receipt publication denial; compiler build succeeded','receipt':'failed-save/after-driver.stderr','disposition':'Git worktree metadata was read-only under the initial execution permissions. Commit the unchanged produced archive with authorized permissions, verify the full staged source and linked dependencies, and resume existing test binary without recompiling. No tests had executed or failed in this attempt.'})
(r/'prior-failures.json').write_text(json.dumps(prior,indent=2)+'\n')
q=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-75/engine-after-build'
subprocess.run(['git','add',str(q)],cwd=w,check=True)
subprocess.run(['git','-c','gc.auto=0','commit','-m','Record completed scoped-context unit build after receipt save denial'],cwd=w,check=True)
subprocess.run(['python3',str(r/'archive.py'),'environmental-save-recovery',str(f),str(p/'resume-proof.json'),str(r/'prior-failures.json'),str(r/'resume-after-build.py')],check=True)
s=(r/'engine-focused.py').read_text();start=s.index('def run(label,');end=s.index("if phase=='parent':run('build'",start)
exec(compile(s[start:end],str(r/'engine-focused.py'),'exec'))
exec(compile(s[s.index('listed=subprocess.check_output'):],str(r/'engine-focused.py'),'exec'))
print('RESUMED_FRESH_BUILD_TESTS_COMPLETE',flush=True)
