"""Restore exact accepted R76 source and verify its unchanged cached unit inputs."""
from pathlib import Path
import hashlib,json,subprocess,time,re
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');c=json.loads((r/'configuration.json').read_text());base=c['baseline_checkpoint'];p=r/'restored';p.mkdir();path='src/engine/src/resident/budget.rs'
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True)
assert not git('status','--porcelain').strip();scope=json.loads((r/'source-scope.json').read_text());patch=subprocess.check_output(['git','diff',base,'--','src','hosts/gpu/src'],cwd=w);assert hashlib.sha256(patch).hexdigest()==scope['complete_source_diff_sha256'];(p/'rejected-source.patch').write_bytes(patch)
(w/path).write_bytes(subprocess.check_output(['git','show',base+':'+path],cwd=w));assert not git('diff',base,'--','src','hosts/gpu/src','.github').strip()
subprocess.run(['git','add','--',path],cwd=w,check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Restore R76 after exact failure return shows no measured gain'],cwd=w,check=True);head=git('rev-parse','HEAD').strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def tree(root):return {str(f.relative_to(root)):sha(f) for f in root.rglob('*') if f.is_file() and not {'target','.git'}.intersection(f.relative_to(root).parts)}
a=tree(w/'src/engine');b=tree(r/'engine-parent/source/src/engine');assert a==b
build=json.loads((r/'engine-parent/retained-rust-build.json').read_text());reuse=json.loads((r/'engine-parent/reuse-proof.json').read_text());binary=Path(build['command'][-1]);assert sha(binary)==reuse['binary_sha256']
for pin in build['libraries'].values():assert sha(Path(pin['path']))==pin['sha256']
proof={'restored_head':head,'accepted_checkpoint':base,'all_engine_gpu_ci_source_identical_to_accepted':True,'engine_complete_tree_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest(),'engine_files':len(a),'unit_binary':str(binary),'unit_binary_sha256':sha(binary),'original_reuse_proof':reuse,'scope':'Exact R76 source restored. Fresh post-restoration test executions use its same qualified candidate unit binary after complete staged-source/library hash proofs. No fresh restored compilation or broad qualification is claimed.'};(p/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for label,cmd,count in [('budget',[str(binary),'resident::budget::','--nocapture','--test-threads=1'],108),('planner',[str(binary),'memory_planner::','--nocapture','--test-threads=1'],22),('memory-runtime',['python3','scripts/check-memory-runtime.py'],None),('format',['cargo','fmt','--all','--check'],None),('whitespace',['git','diff','--check'],None)]:
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'restored_source':head,'source_proof':'restored/source-proof.json','scope':'Actual post-restoration execution; accepted R76 unit binary reused after full-source/library proofs.'}
 if count is not None:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;row['expected_tests']=count
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'restored-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/'source-proof.json'),str(p/'rejected-source.patch'),str(r/'restore-production.py')],check=True)
 print(label,q.returncode,row.get('executed_tests'),flush=True);q.check_returncode()
 if count is not None:assert row['executed_tests']==count
assert not git('diff',base,'HEAD','--','src','hosts/gpu/src','.github').strip();(r/'restoration.json').write_text(json.dumps(proof,indent=2)+'\n');print('R77_RESTORED_SOURCE',head,flush=True)
