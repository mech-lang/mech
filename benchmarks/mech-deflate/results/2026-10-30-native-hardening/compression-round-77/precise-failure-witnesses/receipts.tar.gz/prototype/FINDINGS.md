# R77 precise failure return

Compare the accepted cold helper returning Result<(), ResidentKernelError> with a helper returning only ResidentKernelError and an explicit Err wrapper at its caller. Each plain/RefCell control executes40 equivalent outcomes and unchanged-denial cases using all public error variants and the actual retained public type layouts. They are code-generation/semantic controls, not compressor timing or proof of actual hot-path elimination. Actual linked code and matched full-call measurements determine acceptance. The accepted R76 gain remains the baseline.
