use mech_core::{MemoryBudgetDimension, ResidentKernelError as Error, ResidentResourcePhase};
pub type Worker = fn(u64) -> Result<(), Error>;
#[inline(always)]
fn charge_account(account: &mut u64, worker: Option<Worker>, arg: u64) -> Result<(), Error> {
    let next = account.checked_add(1).ok_or(Error::Arithmetic)?;
    if next > 100 { return Err(Error::ResourceLimit { phase: ResidentResourcePhase::Admission, dimension: MemoryBudgetDimension::ComputeWork, required: next, limit: 100 }); }
    if let Some(worker) = worker { worker(arg)?; }
    *account = next; Ok(())
}
#[cold]
#[inline(never)]
fn forward_result(error: Error) -> Result<(), Error> { Err(error) }
#[cold]
#[inline(never)]
fn forward_error(error: Error) -> Error { error }
use std::cell::RefCell;
#[unsafe(no_mangle)]
#[inline(never)]
pub fn baseline_debit(account: &RefCell<u64>, worker: Option<Worker>, arg: u64) -> Result<(), Error> {
let mut active = account.borrow_mut();
match charge_account(&mut active, worker, arg) {
Ok(()) => { drop(active); Ok(()) },
Err(error) => { drop(active); forward_result(error) },
}
}
#[unsafe(no_mangle)]
#[inline(never)]
pub fn candidate_debit(account: &RefCell<u64>, worker: Option<Worker>, arg: u64) -> Result<(), Error> {
let mut active = account.borrow_mut();
match charge_account(&mut active, worker, arg) {
Ok(()) => { drop(active); Ok(()) },
Err(error) => { drop(active); Err(forward_error(error)) },
}
}
fn worker(arg: u64) -> Result<(), Error> {
    match arg {
        0 => Ok(()), 1 => Err(Error::InvalidInput),
        2 | 3 => Err(Error::ResourceLimit { phase: ResidentResourcePhase::Admission, dimension: if arg == 2 { MemoryBudgetDimension::ComputeWork } else { MemoryBudgetDimension::ComparisonWork }, required: 7, limit: 6 }),
        4 => Err(Error::Arithmetic),
        5 => Err(Error::ProviderStatus { operation: "opaque".into(), status: "rejected".into(), code: 7 }),
        6 => Err(Error::IndexOutOfRange { index: 7, upper_bound: 6 }),
        7 => Err(Error::InvalidShape), 8 => Err(Error::InvalidOutput), _ => Err(Error::IncompleteOutput),
    }
}
fn main() {
let mut cases = 0;
for initial in [0, u64::MAX] { for arg in 0..10 { for selected in [None, Some(worker as Worker)] {
let a = RefCell::new(initial); let b = RefCell::new(initial); let baseline = baseline_debit(&a, selected, arg); let candidate = candidate_debit(&b, selected, arg); assert_eq!(baseline, candidate); assert_eq!(*a.borrow(), *b.borrow()); if candidate.is_err() { assert_eq!(*b.borrow(), initial); }
cases += 1;
}}}
println!("EQUIVALENT cases={cases} resident_error={} resident_result={} native_error={} iteration_error={}", std::mem::size_of::<Error>(), std::mem::size_of::<Result<(), Error>>(), std::mem::size_of::<mech_gpu::native_artifact::NativeExecutionError>(),std::mem::size_of::<mech_gpu::native_artifact::NativeIterationExecutionError>());
}
