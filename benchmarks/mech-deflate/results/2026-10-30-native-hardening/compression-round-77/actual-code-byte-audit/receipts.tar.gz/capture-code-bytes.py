"""Capture bounded actual routine bytes and whole text hashes after timing ends."""
from pathlib import Path
import ast,hashlib,json,struct,subprocess,sys,time
r=Path(__file__).resolve().parent;assert 'R77_DIAGNOSTIC_CHECKPOINT' in (r/'main-driver.stdout').read_text();p=r/'machine-bytes';p.mkdir()
module=ast.parse((r/'success-tail.py').read_text());function=next(x for x in module.body if isinstance(x,ast.FunctionDef) and x.name=='sections');exec(compile(ast.Module(body=[function],type_ignores=[]),str(r/'success-tail.py'),'exec'))
for label in ['before','after']:
 at=time.monotonic();worker=r/'linked-primary'/label/'worker';blob=worker.read_bytes();audit=json.loads((r/'host-assembly'/label/'audit.json').read_text());digest=hashlib.sha256(blob).hexdigest();assert digest==audit['worker_sha256'];section=sections(blob)['__text'];text=blob[section['offset']:section['offset']+section['size']];regions={}
 for needle in ['ordinary-budget','cold-debit-error']:
  region=next(x for x in audit['regions'] if x['needle']==needle);start=section['offset']+region['start']-section['address'];stop=start+region['stop']-region['start'];assert section['offset']<=start<stop<=section['offset']+section['size'];raw=blob[start:stop];regions[needle]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'hex':raw.hex()}
 row={'command':[sys.executable,str(Path(__file__))],'label':label,'exit':0,'seconds':time.monotonic()-at,'worker_sha256':digest,'text':{**section,'sha256':hashlib.sha256(text).hexdigest()},'regions':regions,'scope':'Actual Mach-O extraction after all performance cohorts. Full text retained as a digest; selected routine bytes are archived and rehashed during standalone replay.'};(p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,row['text']['sha256'],flush=True)
subprocess.run([sys.executable,str(r/'success-tail.py'),str(r),str(r/'success-tail.json')],check=True)
