
/private/tmp/mech-exact-debit-failure-round77-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101560be0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>:
101560be0:     	sub	sp, sp, #0x110
101560be4:     	stp	x28, x27, [sp, #0xb0]
101560be8:     	stp	x26, x25, [sp, #0xc0]
101560bec:     	stp	x24, x23, [sp, #0xd0]
101560bf0:     	stp	x22, x21, [sp, #0xe0]
101560bf4:     	stp	x20, x19, [sp, #0xf0]
101560bf8:     	stp	x29, x30, [sp, #0x100]
101560bfc:     	add	x29, sp, #0x100
101560c00:     	stp	x6, x0, [sp, #0x8]
101560c04:     	mov	x22, x3
101560c08:     	mov	x25, x1
101560c0c:     	mov	x19, #0x0               ; =0
101560c10:     	mov	x26, #0x0               ; =0
101560c14:     	mov	x23, #0x0               ; =0
101560c18:     	mov	x24, #0x0               ; =0
101560c1c:     	ldp	x27, x9, [x4]
101560c20:     	ldr	x10, [x4, #0x30]
101560c24:     	ldp	x8, x11, [x4, #0x10]
101560c28:     	stp	x11, x5, [sp, #0x38]
101560c2c:     	str	x8, [sp, #0x20]
101560c30:     	ldp	x8, x11, [x4, #0x20]
101560c34:     	stp	x11, x10, [sp, #0x28]
101560c38:     	str	x8, [sp, #0x18]
101560c3c:     	lsl	x8, x2, #7
101560c40:     	sub	x28, x8, x2, lsl #3
101560c44:     	str	x9, [sp]
101560c48:     	add	x21, x9, #0x1
101560c4c:     	cmp	x28, x19
101560c50:     	b.eq	0x101560e08 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x228>
101560c54:     	subs	x21, x21, #0x1
101560c58:     	b.eq	0x101560ea0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2c0>
101560c5c:     	ldrb	w8, [x27]
101560c60:     	cmp	w8, #0x3
101560c64:     	b.ne	0x101560d3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x15c>
101560c68:     	ldr	x0, [x27, #0x8]
101560c6c:     	ldr	x8, [sp, #0x38]
101560c70:     	cmp	x0, x8
101560c74:     	b.hs	0x101560eb4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2d4>
101560c78:     	ldr	x8, [sp, #0x28]
101560c7c:     	cmp	x0, x8
101560c80:     	b.hs	0x101560ec4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2e4>
101560c84:     	ldp	x9, x8, [sp, #0x18]
101560c88:     	add	x20, x8, x0, lsl #6
101560c8c:     	ldr	x8, [x20]
101560c90:     	ldr	x10, [x9, x0, lsl #3]
101560c94:     	cbz	x8, 0x101560d70 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x190>
101560c98:     	cbnz	x10, 0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560c9c:     	ldr	w9, [x20, #0x38]
101560ca0:     	add	x8, x25, x19
101560ca4:     	ldr	w10, [x8, #0x70]
101560ca8:     	cmp	w9, w10
101560cac:     	b.ne	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560cb0:     	ldp	q0, q1, [x20, #0x10]
101560cb4:     	stp	q0, q1, [sp, #0x60]
101560cb8:     	ldp	x9, x10, [sp, #0x60]
101560cbc:     	ldp	x11, x12, [x8, #0x50]
101560cc0:     	ldp	x13, x14, [sp, #0x70]
101560cc4:     	ldp	x15, x8, [x8, #0x60]
101560cc8:     	cmp	x9, x11
101560ccc:     	ccmp	x10, x12, #0x0, eq
101560cd0:     	ccmp	x13, x15, #0x0, eq
101560cd4:     	ccmp	x14, x8, #0x0, eq
101560cd8:     	b.ne	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560cdc:     	mov	x0, x20
101560ce0:     	ldr	x1, [sp, #0x40]
101560ce4:     	bl	0x102e15114 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
101560ce8:     	cmp	x0, #0x1
101560cec:     	b.ne	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560cf0:     	add	x8, sp, #0x60
101560cf4:     	mov	x0, x20
101560cf8:     	mov	x1, x22
101560cfc:     	bl	0x102e131f8 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
101560d00:     	ldrb	w8, [sp, #0x60]
101560d04:     	cmp	w8, #0x16
101560d08:     	b.ne	0x101560e40 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x260>
101560d0c:     	add	x8, sp, #0x60
101560d10:     	add	x0, x25, x19
101560d14:     	mov	x1, x20
101560d18:     	mov	x2, x22
101560d1c:     	bl	0x102361c3c <__RNvMNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget15frame_footprintNtB2_28PreparedNativeFrameFootprint5value>
101560d20:     	ldr	w8, [sp, #0x60]
101560d24:     	tbz	w8, #0x0, 0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560d28:     	ldp	x9, x8, [sp, #0x70]
101560d2c:     	ldr	x10, [sp, #0x80]
101560d30:     	adds	x26, x9, x26
101560d34:     	b.lo	0x101560de4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x204>
101560d38:     	b	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560d3c:     	ldp	q0, q1, [x27]
101560d40:     	stp	q0, q1, [sp, #0x60]
101560d44:     	ldr	x8, [sp, #0x30]
101560d48:     	ldr	x8, [x8]
101560d4c:     	ldr	x1, [x8]
101560d50:     	add	x0, sp, #0x48
101560d54:     	add	x2, sp, #0x60
101560d58:     	bl	0x10157a570 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101560d5c:     	ldr	x8, [sp, #0x48]
101560d60:     	cmp	x8, #0x1
101560d64:     	b.ne	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560d68:     	ldp	x20, x10, [sp, #0x50]
101560d6c:     	cbnz	x20, 0x101560c98 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0xb8>
101560d70:     	ldrb	w8, [x25, x19]
101560d74:     	tbnz	w8, #0x0, 0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560d78:     	add	x8, x25, x19
101560d7c:     	ldrb	w11, [x8, #0x1]
101560d80:     	ldp	x9, x8, [x8, #0x10]
101560d84:     	cmp	w11, #0x3
101560d88:     	b.gt	0x101560da4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1c4>
101560d8c:     	sub	w11, w11, #0x1
101560d90:     	cmp	w11, #0x3
101560d94:     	b.lo	0x101560dd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101560d98:     	cmp	x10, #0x2
101560d9c:     	b.lo	0x101560dd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101560da0:     	b	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560da4:     	cmp	w11, #0x4
101560da8:     	b.eq	0x101560dc0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1e0>
101560dac:     	cmp	w11, #0x5
101560db0:     	b.ne	0x101560dcc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1ec>
101560db4:     	cmp	x10, #0x10, lsl #12     ; =0x10000
101560db8:     	b.lo	0x101560dd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101560dbc:     	b	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560dc0:     	cmp	x10, #0xff
101560dc4:     	b.ls	0x101560dd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101560dc8:     	b	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560dcc:     	lsr	x10, x10, #32
101560dd0:     	cbnz	x10, 0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560dd4:     	add	x10, x25, x19
101560dd8:     	ldr	x10, [x10, #0x20]
101560ddc:     	adds	x26, x9, x26
101560de0:     	b.hs	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560de4:     	adds	x23, x10, x23
101560de8:     	cset	w9, hs
101560dec:     	adds	x24, x8, x24
101560df0:     	cset	w8, hs
101560df4:     	tbnz	w9, #0x0, 0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560df8:     	add	x27, x27, #0x20
101560dfc:     	add	x19, x19, #0x78
101560e00:     	tbz	w8, #0x0, 0x101560c4c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x6c>
101560e04:     	b	0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560e08:     	add	x8, sp, #0x60
101560e0c:     	ldr	x0, [sp, #0x8]
101560e10:     	mov	x1, x23
101560e14:     	mov	x2, x24
101560e18:     	bl	0x10236b840 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter29try_charge_borrowed_footprint>
101560e1c:     	ldrb	w9, [sp, #0x60]
101560e20:     	ldrb	w8, [sp, #0x61]
101560e24:     	cmp	w9, #0x8
101560e28:     	b.ne	0x101560e78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x298>
101560e2c:     	tbz	w8, #0x0, 0x101560e48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101560e30:     	mov	w8, #0x1                ; =1
101560e34:     	ldr	x9, [sp, #0x10]
101560e38:     	stp	x8, x26, [x9, #0x8]
101560e3c:     	b	0x101560e50 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x270>
101560e40:     	add	x0, sp, #0x60
101560e44:     	bl	0x101572e40 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
101560e48:     	ldr	x9, [sp, #0x10]
101560e4c:     	str	xzr, [x9, #0x8]
101560e50:     	mov	w8, #0x8                ; =8
101560e54:     	strb	w8, [x9]
101560e58:     	ldp	x29, x30, [sp, #0x100]
101560e5c:     	ldp	x20, x19, [sp, #0xf0]
101560e60:     	ldp	x22, x21, [sp, #0xe0]
101560e64:     	ldp	x24, x23, [sp, #0xd0]
101560e68:     	ldp	x26, x25, [sp, #0xc0]
101560e6c:     	ldp	x28, x27, [sp, #0xb0]
101560e70:     	add	sp, sp, #0x110
101560e74:     	ret
101560e78:     	ldur	q0, [sp, #0x62]
101560e7c:     	ldr	x11, [sp, #0x10]
101560e80:     	stur	q0, [x11, #0x2]
101560e84:     	ldur	q0, [sp, #0x72]
101560e88:     	stur	q0, [x11, #0x12]
101560e8c:     	ldr	x10, [sp, #0x80]
101560e90:     	str	x10, [x11, #0x20]
101560e94:     	strb	w9, [x11]
101560e98:     	strb	w8, [x11, #0x1]
101560e9c:     	b	0x101560e58 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x278>
101560ea0:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
101560ea4:     	add	x2, x2, #0x430
101560ea8:     	ldr	x0, [sp]
101560eac:     	mov	x1, x0
101560eb0:     	bl	0x103a05dd4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101560eb4:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
101560eb8:     	add	x2, x2, #0x448
101560ebc:     	ldr	x1, [sp, #0x38]
101560ec0:     	bl	0x103a05dd4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101560ec4:     	adrp	x2, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
101560ec8:     	add	x2, x2, #0x460
101560ecc:     	ldr	x1, [sp, #0x28]
101560ed0:     	bl	0x103a05dd4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
