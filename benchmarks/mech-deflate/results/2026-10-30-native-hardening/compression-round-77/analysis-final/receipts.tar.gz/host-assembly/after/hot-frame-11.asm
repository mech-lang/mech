
/private/tmp/mech-exact-debit-failure-round77-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001016123cc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>:
1016123cc:     	sub	sp, sp, #0x1d0
1016123d0:     	stp	x28, x27, [sp, #0x170]
1016123d4:     	stp	x26, x25, [sp, #0x180]
1016123d8:     	stp	x24, x23, [sp, #0x190]
1016123dc:     	stp	x22, x21, [sp, #0x1a0]
1016123e0:     	stp	x20, x19, [sp, #0x1b0]
1016123e4:     	stp	x29, x30, [sp, #0x1c0]
1016123e8:     	add	x29, sp, #0x1c0
1016123ec:     	mov	x25, x6
1016123f0:     	mov	x26, x4
1016123f4:     	mov	x23, x3
1016123f8:     	mov	x22, x2
1016123fc:     	mov	x24, x1
101612400:     	mov	x20, x0
101612404:     	mov	x19, x8
101612408:     	ldr	x21, [x29, #0x10]
10161240c:     	stp	x5, x6, [sp]
101612410:     	str	x7, [sp, #0x10]
101612414:     	add	x27, sp, #0x80
101612418:     	ldr	w0, [x0, #0x110]
10161241c:     	add	x8, sp, #0xc8
101612420:     	mov	x1, x21
101612424:     	bl	0x10280a5fc <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
101612428:     	ldrb	w8, [sp, #0xc8]
10161242c:     	cmp	w8, #0x29
101612430:     	b.ne	0x101612484 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb8>
101612434:     	ldr	x28, [x20, #0x1d8]
101612438:     	cbz	x28, 0x1016124a4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xd8>
10161243c:     	mov	w27, #0x2c              ; =44
101612440:     	strb	w27, [sp, #0xc8]
101612444:     	add	x0, sp, #0xc8
101612448:     	bl	0x1016181c4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10161244c:     	cmp	x22, x26
101612450:     	b.ne	0x10161247c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb0>
101612454:     	ldr	x8, [x20, #0x78]
101612458:     	cmp	x22, x8
10161245c:     	b.ne	0x10161247c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb0>
101612460:     	cmp	x25, #0x0
101612464:     	cset	w8, ne
101612468:     	ldr	x9, [x20, #0x10]
10161246c:     	cmp	x9, #0xb
101612470:     	cset	w9, eq
101612474:     	eor	w8, w8, w9
101612478:     	tbz	w8, #0x0, 0x1016124cc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x100>
10161247c:     	strb	w27, [x19]
101612480:     	b	0x1016124ac <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
101612484:     	ldur	q0, [x27, #0x48]
101612488:     	ldur	q1, [x27, #0x58]
10161248c:     	stp	q0, q1, [x19]
101612490:     	ldur	q0, [x27, #0x68]
101612494:     	str	q0, [x19, #0x20]
101612498:     	ldr	x8, [sp, #0xf8]
10161249c:     	str	x8, [x19, #0x30]
1016124a0:     	b	0x1016124ac <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
1016124a4:     	mov	w8, #0x2c               ; =44
1016124a8:     	strb	w8, [x19]
1016124ac:     	ldp	x29, x30, [sp, #0x1c0]
1016124b0:     	ldp	x20, x19, [sp, #0x1b0]
1016124b4:     	ldp	x22, x21, [sp, #0x1a0]
1016124b8:     	ldp	x24, x23, [sp, #0x190]
1016124bc:     	ldp	x26, x25, [sp, #0x180]
1016124c0:     	ldp	x28, x27, [sp, #0x170]
1016124c4:     	add	sp, sp, #0x1d0
1016124c8:     	ret
1016124cc:     	ldp	x8, x9, [x28, #0x10]
1016124d0:     	stp	x8, x9, [sp, #0x18]
1016124d4:     	stp	x24, x22, [sp, #0x28]
1016124d8:     	stp	x23, x22, [sp, #0x38]
1016124dc:     	mov	x10, sp
1016124e0:     	str	x10, [sp, #0x48]
1016124e4:     	ldr	x10, [x21, #0x60]
1016124e8:     	cmp	x10, #0x1
1016124ec:     	b.ne	0x1016125fc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x230>
1016124f0:     	ldr	w10, [x21, #0x50]
1016124f4:     	add	x22, sp, #0x80
1016124f8:     	tbz	w10, #0x0, 0x101612608 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x23c>
1016124fc:     	ldp	x11, x10, [x29, #0x18]
101612500:     	ldr	x12, [x21, #0x68]
101612504:     	ldr	x13, [x21, #0x58]
101612508:     	ldp	x14, x15, [x28, #0x20]
10161250c:     	add	x16, x28, #0x50
101612510:     	add	x17, x28, #0x30
101612514:     	add	x0, x28, #0x38
101612518:     	add	x1, x28, #0x40
10161251c:     	add	x2, x28, #0x48
101612520:     	stp	x12, x13, [sp, #0xb8]
101612524:     	add	x12, sp, #0xb8
101612528:     	stp	x11, x12, [sp, #0xc8]
10161252c:     	add	x12, sp, #0xc0
101612530:     	stp	x12, x11, [sp, #0xd8]
101612534:     	stp	x21, x10, [sp, #0xe8]
101612538:     	stp	x8, x9, [sp, #0xf8]
10161253c:     	stp	x14, x15, [sp, #0x108]
101612540:     	stp	x16, x28, [sp, #0x118]
101612544:     	stp	x17, x0, [sp, #0x128]
101612548:     	stp	x1, x2, [sp, #0x138]
10161254c:     	add	x8, sp, #0x8
101612550:     	stp	x8, x20, [sp, #0x148]
101612554:     	add	x8, sp, #0x18
101612558:     	str	x8, [sp, #0x158]
10161255c:     	adrp	x0, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
101612560:     	add	x0, x0, #0x860
101612564:     	add	x8, sp, #0x80
101612568:     	add	x1, sp, #0xc8
10161256c:     	bl	0x1015669b0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
101612570:     	ldrb	w8, [sp, #0x80]
101612574:     	cmp	w8, #0x2f
101612578:     	b.ne	0x1016125c4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1f8>
10161257c:     	ldur	q0, [x22, #0x8]
101612580:     	stur	q0, [sp, #0x57]
101612584:     	ldur	q1, [x22, #0x18]
101612588:     	stur	q1, [sp, #0x67]
10161258c:     	ldr	x8, [sp, #0xa8]
101612590:     	stur	x8, [sp, #0x77]
101612594:     	stur	q0, [x22, #0x4f]
101612598:     	stur	q1, [x22, #0x5f]
10161259c:     	stur	x8, [x22, #0x6f]
1016125a0:     	mov	w8, #0x29               ; =41
1016125a4:     	strb	w8, [x19]
1016125a8:     	ldur	q0, [x22, #0x48]
1016125ac:     	stur	q0, [x19, #0x1]
1016125b0:     	ldur	q0, [x22, #0x58]
1016125b4:     	stur	q0, [x19, #0x11]
1016125b8:     	ldur	q0, [x22, #0x67]
1016125bc:     	str	q0, [x19, #0x20]
1016125c0:     	b	0x1016124ac <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
1016125c4:     	ldr	q0, [sp, #0xa0]
1016125c8:     	stur	q0, [sp, #0x6f]
1016125cc:     	ldur	q0, [x22, #0x11]
1016125d0:     	ldur	q1, [x22, #0x1]
1016125d4:     	stp	q1, q0, [sp, #0x50]
1016125d8:     	ldr	x9, [sp, #0xb0]
1016125dc:     	strb	w8, [x19]
1016125e0:     	stur	q1, [x19, #0x1]
1016125e4:     	ldr	q0, [sp, #0x60]
1016125e8:     	stur	q0, [x19, #0x11]
1016125ec:     	ldur	q0, [sp, #0x6f]
1016125f0:     	str	q0, [x19, #0x20]
1016125f4:     	str	x9, [x19, #0x30]
1016125f8:     	b	0x1016124ac <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
1016125fc:     	adrp	x0, 0x107f13000 <_anon.51f82601ca37a528a7940c4871978f11.291+0x58>
101612600:     	add	x0, x0, #0x6c8
101612604:     	bl	0x103a05d38 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101612608:     	adrp	x0, 0x107f13000 <_anon.51f82601ca37a528a7940c4871978f11.291+0x58>
10161260c:     	add	x0, x0, #0x6e0
101612610:     	bl	0x103a05d38 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
