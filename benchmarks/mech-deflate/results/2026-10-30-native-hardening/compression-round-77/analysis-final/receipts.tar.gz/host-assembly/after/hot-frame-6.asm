
/private/tmp/mech-exact-debit-failure-round77-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101567654 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>:
101567654:     	stp	x28, x27, [sp, #-0x60]!
101567658:     	stp	x26, x25, [sp, #0x10]
10156765c:     	stp	x24, x23, [sp, #0x20]
101567660:     	stp	x22, x21, [sp, #0x30]
101567664:     	stp	x20, x19, [sp, #0x40]
101567668:     	stp	x29, x30, [sp, #0x50]
10156766c:     	add	x29, sp, #0x50
101567670:     	sub	sp, sp, #0x610
101567674:     	str	xzr, [sp]
101567678:     	mov	x23, x1
10156767c:     	mov	x20, x8
101567680:     	ldr	x8, [x0]
101567684:     	mov	x0, #0x0                ; =0
101567688:     	blr	x8
10156768c:     	cbz	x0, 0x101568138 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xae4>
101567690:     	mov	x19, x0
101567694:     	mov	x8, x0
101567698:     	ldr	x9, [x8, #0x20]!
10156769c:     	cbnz	x9, 0x1015680c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa70>
1015676a0:     	ldp	x0, x21, [x23]
1015676a4:     	ldp	x28, x24, [x23, #0x10]
1015676a8:     	ldp	x26, x22, [x23, #0x20]
1015676ac:     	ldp	x27, x16, [x23, #0x38]
1015676b0:     	ldp	x17, x14, [x23, #0x48]
1015676b4:     	ldp	x9, x25, [x23, #0x58]
1015676b8:     	str	x9, [sp, #0x70]
1015676bc:     	ldp	x9, x11, [x23, #0x68]
1015676c0:     	str	x9, [sp, #0x60]
1015676c4:     	ldp	x12, x1, [x23, #0x78]
1015676c8:     	ldp	x13, x15, [x23, #0x88]
1015676cc:     	mov	x9, #-0x1               ; =-1
1015676d0:     	str	x9, [x19, #0x20]
1015676d4:     	ldr	x10, [x19, #0x28]
1015676d8:     	ldr	x9, [x0]
1015676dc:     	cbz	x10, 0x1015676f8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
1015676e0:     	cmp	x10, x9
1015676e4:     	b.eq	0x1015676f8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
1015676e8:     	mov	x9, #0x0                ; =0
1015676ec:     	str	xzr, [x8]
1015676f0:     	mov	w26, #0x2f              ; =47
1015676f4:     	b	0x101567b1c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4c8>
1015676f8:     	ldr	x10, [x9]
1015676fc:     	adds	x10, x10, #0x1
101567700:     	str	x10, [x9]
101567704:     	b.hs	0x101568170 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
101567708:     	str	x11, [sp, #0x10]
10156770c:     	ldp	x11, x10, [x19, #0x20]
101567710:     	add	x11, x11, #0x1
101567714:     	stp	x11, x9, [x19, #0x20]
101567718:     	stp	x8, x10, [sp, #0x88]
10156771c:     	ldr	x23, [x0]
101567720:     	ldr	x8, [x23]
101567724:     	adds	x8, x8, #0x1
101567728:     	str	x8, [x23]
10156772c:     	b.hs	0x101568170 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
101567730:     	stp	xzr, xzr, [sp, #0xd8]
101567734:     	str	x23, [sp, #0xd0]
101567738:     	ldr	x8, [x19]
10156773c:     	cbnz	x8, 0x101568108 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xab4>
101567740:     	stp	x13, x1, [sp, #0x38]
101567744:     	stp	x17, x14, [sp, #0x18]
101567748:     	stp	x16, x15, [sp, #0x28]
10156774c:     	str	x12, [sp, #0x8]
101567750:     	ldur	q0, [x19, #0x8]
101567754:     	ldr	x8, [x19, #0x18]
101567758:     	str	x8, [sp, #0xb0]
10156775c:     	stur	q0, [sp, #0xa0]
101567760:     	ldr	q0, [sp, #0xd0]
101567764:     	ldr	x8, [sp, #0xe0]
101567768:     	str	x8, [x19, #0x18]
10156776c:     	stur	q0, [x19, #0x8]
101567770:     	str	x19, [sp, #0x98]
101567774:     	bl	0x102364620 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101567778:     	ldp	x12, x9, [x19, #0x30]
10156777c:     	ldr	x11, [x19, #0x40]
101567780:     	ldr	x8, [x21]
101567784:     	adds	x8, x0, x8
101567788:     	csinv	x8, x8, xzr, lo
10156778c:     	cmp	x9, x8
101567790:     	stp	x11, x9, [sp, #0x48]
101567794:     	csel	x9, x9, x8, lo
101567798:     	ldr	x10, [x28]
10156779c:     	adds	x10, x1, x10
1015677a0:     	csinv	x10, x10, xzr, lo
1015677a4:     	cmp	x11, x10
1015677a8:     	csel	x11, x11, x10, lo
1015677ac:     	str	x12, [sp, #0x58]
1015677b0:     	tst	w12, #0x1
1015677b4:     	csel	x8, x9, x8, ne
1015677b8:     	csel	x9, x11, x10, ne
1015677bc:     	mov	w10, #0x1               ; =1
1015677c0:     	stp	x10, x8, [x19, #0x30]
1015677c4:     	str	x9, [x19, #0x40]
1015677c8:     	add	x8, sp, #0xb8
1015677cc:     	mov	x0, x24
1015677d0:     	bl	0x102363ab8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015677d4:     	add	x23, sp, #0x320
1015677d8:     	add	x28, sp, #0x230
1015677dc:     	ldp	q0, q1, [x26, #0x80]
1015677e0:     	stp	q0, q1, [x28, #0x80]
1015677e4:     	ldr	x8, [x26, #0xa0]
1015677e8:     	str	x8, [sp, #0x2d0]
1015677ec:     	ldp	q0, q1, [x26, #0x40]
1015677f0:     	stp	q0, q1, [x28, #0x40]
1015677f4:     	ldp	q1, q0, [x26, #0x60]
1015677f8:     	stp	q1, q0, [x28, #0x60]
1015677fc:     	ldp	q0, q1, [x26]
101567800:     	stp	q0, q1, [x28]
101567804:     	ldp	q1, q0, [x26, #0x20]
101567808:     	stp	q1, q0, [x28, #0x20]
10156780c:     	ldr	q0, [x22, #0x30]
101567810:     	str	q0, [x28, #0x120]
101567814:     	ldr	q0, [x22, #0x40]
101567818:     	str	q0, [x28, #0x130]
10156781c:     	ldr	q0, [x22, #0x50]
101567820:     	str	q0, [x28, #0x140]
101567824:     	ldr	x8, [x22, #0x60]
101567828:     	str	x8, [sp, #0x380]
10156782c:     	ldr	q0, [x22]
101567830:     	str	q0, [x28, #0xf0]
101567834:     	ldr	q0, [x22, #0x10]
101567838:     	str	q0, [x28, #0x100]
10156783c:     	ldr	q0, [x22, #0x20]
101567840:     	str	q0, [x28, #0x110]
101567844:     	ldr	q0, [x26, #0x70]
101567848:     	str	q0, [x23, #0x1a0]
10156784c:     	ldr	q0, [x26, #0x80]
101567850:     	str	q0, [x23, #0x1b0]
101567854:     	ldr	q0, [x26, #0x90]
101567858:     	str	q0, [x23, #0x1c0]
10156785c:     	ldr	x8, [x26, #0xa0]
101567860:     	str	x8, [sp, #0x4f0]
101567864:     	ldr	q0, [x26, #0x30]
101567868:     	str	q0, [x23, #0x160]
10156786c:     	ldr	q0, [x26, #0x40]
101567870:     	str	q0, [x23, #0x170]
101567874:     	ldr	q0, [x26, #0x50]
101567878:     	str	q0, [x23, #0x180]
10156787c:     	ldr	q0, [x26, #0x60]
101567880:     	str	q0, [x23, #0x190]
101567884:     	ldr	q0, [x26]
101567888:     	str	q0, [x23, #0x130]
10156788c:     	ldr	q0, [x26, #0x10]
101567890:     	str	q0, [x23, #0x140]
101567894:     	ldr	q0, [x26, #0x20]
101567898:     	str	q0, [x23, #0x150]
10156789c:     	add	x8, sp, #0xd0
1015678a0:     	add	x1, sp, #0x450
1015678a4:     	add	x2, sp, #0x320
1015678a8:     	mov	x0, x24
1015678ac:     	bl	0x102363074 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext3new>
1015678b0:     	ldr	x25, [x25]
1015678b4:     	lsr	x8, x25, #61
1015678b8:     	cbnz	x8, 0x101568118 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xac4>
1015678bc:     	lsl	x26, x25, #3
1015678c0:     	mov	w8, #0x2c               ; =44
1015678c4:     	strb	w8, [sp, #0x450]
1015678c8:     	add	x0, sp, #0x450
1015678cc:     	bl	0x101573cb0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015678d0:     	add	x8, sp, #0x320
1015678d4:     	add	x0, sp, #0xd0
1015678d8:     	mov	x1, x26
1015678dc:     	mov	x2, #0x0                ; =0
1015678e0:     	bl	0x102363340 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
1015678e4:     	ldrb	w8, [sp, #0x320]
1015678e8:     	cmp	w8, #0x8
1015678ec:     	b.ne	0x1015679d0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x37c>
1015678f0:     	add	x8, sp, #0x450
1015678f4:     	add	x0, sp, #0xd0
1015678f8:     	add	x2, x27, #0x8
1015678fc:     	mov	x1, x25
101567900:     	bl	0x102362e0c <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext14check_capacity>
101567904:     	add	x21, sp, #0x450
101567908:     	ldrb	w8, [sp, #0x450]
10156790c:     	cmp	w8, #0x8
101567910:     	b.ne	0x1015679e8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x394>
101567914:     	add	x8, sp, #0x450
101567918:     	add	x0, sp, #0xb8
10156791c:     	mov	x1, x25
101567920:     	bl	0x102d55024 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101567924:     	ldr	w25, [sp, #0x450]
101567928:     	cmp	w25, #0x1a
10156792c:     	b.ne	0x101567b60 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x50c>
101567930:     	ldur	q0, [x21, #0x8]
101567934:     	ldur	q1, [x21, #0x18]
101567938:     	stp	q0, q1, [x28, #0xb0]
10156793c:     	add	x8, sp, #0x450
101567940:     	add	x0, sp, #0xb8
101567944:     	add	x1, x27, #0x8
101567948:     	bl	0x102d54ef8 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
10156794c:     	ldr	w25, [sp, #0x450]
101567950:     	cmp	w25, #0x1a
101567954:     	ldr	x8, [sp, #0x40]
101567958:     	b.ne	0x101567b84 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x530>
10156795c:     	ldur	q0, [x21, #0x8]
101567960:     	ldur	q1, [x21, #0x18]
101567964:     	stp	q0, q1, [x28, #0xd0]
101567968:     	ldr	x1, [x8]
10156796c:     	cbz	x1, 0x101567994 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x340>
101567970:     	ldr	x2, [x8, #0x8]
101567974:     	add	x8, sp, #0x450
101567978:     	add	x3, sp, #0xb8
10156797c:     	add	x4, sp, #0xd0
101567980:     	ldr	x0, [sp, #0x38]
101567984:     	bl	0x1027f7ae0 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB6_25NativePreparedLibraryCall23admit_composed_selector>
101567988:     	ldrb	w26, [sp, #0x450]
10156798c:     	cmp	w26, #0x2e
101567990:     	b.ne	0x101567f80 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x92c>
101567994:     	add	x8, sp, #0x450
101567998:     	add	x1, sp, #0x230
10156799c:     	mov	x0, x24
1015679a0:     	bl	0x10236a704 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter21for_native_projection>
1015679a4:     	ldr	x9, [sp, #0x450]
1015679a8:     	ldr	x8, [sp, #0x458]
1015679ac:     	ldp	q2, q3, [x21, #0x10]
1015679b0:     	cmp	x9, #0x2
1015679b4:     	b.ne	0x101567ba8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x554>
1015679b8:     	stp	q3, q2, [sp, #0x60]
1015679bc:     	and	w25, w8, #0xff
1015679c0:     	lsr	w21, w8, #8
1015679c4:     	lsr	x22, x8, #32
1015679c8:     	mov	w26, #0x29              ; =41
1015679cc:     	b	0x101567fc8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015679d0:     	ldr	w22, [sp, #0x324]
1015679d4:     	ldr	w8, [sp, #0x320]
1015679d8:     	ldur	q0, [x23, #0x18]
1015679dc:     	str	q0, [sp, #0x60]
1015679e0:     	ldur	q0, [x23, #0x8]
1015679e4:     	b	0x1015679fc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3a8>
1015679e8:     	ldr	w22, [sp, #0x454]
1015679ec:     	ldr	w8, [sp, #0x450]
1015679f0:     	ldur	q0, [x21, #0x18]
1015679f4:     	str	q0, [sp, #0x60]
1015679f8:     	ldur	q0, [x21, #0x8]
1015679fc:     	str	q0, [sp, #0x70]
101567a00:     	and	w25, w8, #0xff
101567a04:     	lsr	w21, w8, #8
101567a08:     	mov	w26, #0x29              ; =41
101567a0c:     	ldr	w8, [sp, #0x200]
101567a10:     	cmp	w8, #0x1a
101567a14:     	b.eq	0x101567a68 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101567a18:     	cmp	w8, #0xa
101567a1c:     	b.eq	0x101567a38 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3e4>
101567a20:     	cmp	w8, #0x13
101567a24:     	b.ne	0x101567a68 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101567a28:     	ldr	x1, [sp, #0x210]
101567a2c:     	mov	w8, #0x10               ; =16
101567a30:     	cbnz	x1, 0x101567a50 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3fc>
101567a34:     	b	0x101567a68 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101567a38:     	ldr	x1, [sp, #0x218]
101567a3c:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101567a40:     	cmp	x1, x8
101567a44:     	b.eq	0x101567a68 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101567a48:     	mov	w8, #0x18               ; =24
101567a4c:     	cbz	x1, 0x101567a68 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101567a50:     	add	x9, sp, #0xd0
101567a54:     	add	x9, x9, #0x130
101567a58:     	add	x8, x9, x8
101567a5c:     	ldr	x0, [x8, #0x8]
101567a60:     	mov	w2, #0x1                ; =1
101567a64:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101567a68:     	ldr	x8, [sp, #0xb8]
101567a6c:     	mov	x9, #-0x1               ; =-1
101567a70:     	ldaddl	x9, x8, [x8]
101567a74:     	cmp	x8, #0x1
101567a78:     	b.ne	0x101567a88 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
101567a7c:     	dmb	ishld
101567a80:     	add	x0, sp, #0xb8
101567a84:     	bl	0x102e1ac7c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101567a88:     	add	x27, sp, #0x98
101567a8c:     	ldur	w8, [x29, #-0xe0]
101567a90:     	str	w8, [sp, #0xd0]
101567a94:     	ldurh	w8, [x29, #-0xdc]
101567a98:     	strh	w8, [sp, #0xd4]
101567a9c:     	ldp	x8, x9, [sp, #0x50]
101567aa0:     	stp	x9, x8, [x19, #0x30]
101567aa4:     	ldr	x8, [sp, #0x48]
101567aa8:     	str	x8, [x19, #0x40]
101567aac:     	add	x0, sp, #0x98
101567ab0:     	bl	0x1023a6e6c <__RNvXs_NvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBa_23NativeLibraryWorkBudget16with_call_limitsNtB4_10ScopeGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101567ab4:     	ldr	x8, [sp, #0xa0]
101567ab8:     	cbz	x8, 0x101567ad4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
101567abc:     	ldr	x9, [x8]
101567ac0:     	subs	x9, x9, #0x1
101567ac4:     	str	x9, [x8]
101567ac8:     	b.ne	0x101567ad4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
101567acc:     	add	x0, x27, #0x8
101567ad0:     	bl	0x1023672ac <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101567ad4:     	add	x19, sp, #0x88
101567ad8:     	add	x0, sp, #0x88
101567adc:     	bl	0x10238c458 <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101567ae0:     	and	x27, x21, #0xffffff
101567ae4:     	mov	w21, w22
101567ae8:     	ldr	x8, [sp, #0x90]
101567aec:     	cbz	x8, 0x101567b08 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
101567af0:     	ldr	x9, [x8]
101567af4:     	subs	x9, x9, #0x1
101567af8:     	str	x9, [x8]
101567afc:     	b.ne	0x101567b08 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
101567b00:     	add	x0, x19, #0x8
101567b04:     	bl	0x1023672ac <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101567b08:     	lsl	x8, x27, #8
101567b0c:     	orr	x8, x8, x21, lsl #32
101567b10:     	mov	w9, w25
101567b14:     	orr	x9, x8, x9
101567b18:     	ldp	q1, q0, [sp, #0x60]
101567b1c:     	ldr	w8, [sp, #0xd0]
101567b20:     	stur	w8, [x20, #0x2]
101567b24:     	ldrh	w8, [sp, #0xd4]
101567b28:     	strh	w8, [x20, #0x6]
101567b2c:     	strb	w26, [x20]
101567b30:     	strb	w23, [x20, #0x1]
101567b34:     	str	x9, [x20, #0x8]
101567b38:     	stp	q0, q1, [x20, #0x10]
101567b3c:     	str	x24, [x20, #0x30]
101567b40:     	add	sp, sp, #0x610
101567b44:     	ldp	x29, x30, [sp, #0x50]
101567b48:     	ldp	x20, x19, [sp, #0x40]
101567b4c:     	ldp	x22, x21, [sp, #0x30]
101567b50:     	ldp	x24, x23, [sp, #0x20]
101567b54:     	ldp	x26, x25, [sp, #0x10]
101567b58:     	ldp	x28, x27, [sp], #0x60
101567b5c:     	ret
101567b60:     	add	x8, sp, #0x450
101567b64:     	mov	w21, #0x0               ; =0
101567b68:     	ldr	w22, [sp, #0x454]
101567b6c:     	ldur	q1, [x8, #0x18]
101567b70:     	ldur	q0, [x8, #0x8]
101567b74:     	stp	q1, q0, [sp, #0x60]
101567b78:     	mov	w26, #0x2b              ; =43
101567b7c:     	ldr	x24, [sp, #0x478]
101567b80:     	b	0x101567a0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101567b84:     	add	x8, sp, #0x450
101567b88:     	mov	w21, #0x0               ; =0
101567b8c:     	ldr	w22, [sp, #0x454]
101567b90:     	ldur	q1, [x8, #0x18]
101567b94:     	ldur	q0, [x8, #0x8]
101567b98:     	stp	q1, q0, [sp, #0x60]
101567b9c:     	mov	w26, #0x2b              ; =43
101567ba0:     	ldr	x24, [sp, #0x478]
101567ba4:     	b	0x101567ff0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x99c>
101567ba8:     	ldp	q0, q1, [x21, #0xf0]
101567bac:     	stp	q0, q1, [x28, #0x1e0]
101567bb0:     	ldp	q0, q1, [x21, #0x110]
101567bb4:     	stp	q0, q1, [x28, #0x200]
101567bb8:     	ldp	q0, q1, [x21, #0xb0]
101567bbc:     	stp	q0, q1, [x28, #0x1a0]
101567bc0:     	ldp	q0, q1, [x21, #0xd0]
101567bc4:     	stp	q0, q1, [x28, #0x1c0]
101567bc8:     	ldp	q0, q1, [x21, #0x70]
101567bcc:     	stp	q0, q1, [x28, #0x160]
101567bd0:     	ldp	q0, q1, [x21, #0x90]
101567bd4:     	stp	q0, q1, [x28, #0x180]
101567bd8:     	ldp	q0, q1, [x21, #0x30]
101567bdc:     	stp	q0, q1, [x28, #0x120]
101567be0:     	ldp	q0, q1, [x21, #0x50]
101567be4:     	stp	q0, q1, [x28, #0x140]
101567be8:     	stp	q2, q3, [x28, #0x100]
101567bec:     	str	x8, [sp, #0x328]
101567bf0:     	str	x9, [sp, #0x320]
101567bf4:     	ldr	x10, [sp, #0x70]
101567bf8:     	ldr	x1, [x10]
101567bfc:     	cbz	x1, 0x101567c64 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
101567c00:     	ldp	x9, x8, [sp, #0x30]
101567c04:     	ldr	x8, [x8, #0x190]
101567c08:     	ldr	q0, [x9]
101567c0c:     	str	q0, [x21]
101567c10:     	ldr	q0, [x9, #0x10]
101567c14:     	str	q0, [x21, #0x10]
101567c18:     	ldr	q0, [x9, #0x20]
101567c1c:     	str	q0, [x21, #0x20]
101567c20:     	ldr	x9, [x9, #0x30]
101567c24:     	str	x9, [sp, #0x480]
101567c28:     	ldr	x2, [x10, #0x8]
101567c2c:     	sub	x0, x29, #0xe0
101567c30:     	add	x3, x8, #0x10
101567c34:     	add	x4, sp, #0x450
101567c38:     	add	x5, sp, #0xb8
101567c3c:     	add	x6, sp, #0x320
101567c40:     	bl	0x101560be0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>
101567c44:     	ldurb	w25, [x29, #-0xe0]
101567c48:     	cmp	w25, #0x8
101567c4c:     	b.ne	0x101567ec8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x874>
101567c50:     	ldur	x8, [x29, #-0xd8]
101567c54:     	cbz	x8, 0x101567c64 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
101567c58:     	ldur	x22, [x29, #-0xd0]
101567c5c:     	ldr	x11, [sp, #0x30]
101567c60:     	b	0x101567ef8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
101567c64:     	ldr	x11, [sp, #0x30]
101567c68:     	ldr	x8, [sp, #0x18]
101567c6c:     	cbz	x8, 0x101567ef4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a0>
101567c70:     	mov	x21, #0x0               ; =0
101567c74:     	mov	x22, #0x0               ; =0
101567c78:     	mov	x24, #0x0               ; =0
101567c7c:     	adrp	x9, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
101567c80:     	add	x9, x9, #0x430
101567c84:     	str	x9, [sp, #0x40]
101567c88:     	lsl	x28, x8, #2
101567c8c:     	mov	w27, #0x2c              ; =44
101567c90:     	ldr	x1, [x11, #0x8]
101567c94:     	cmp	x24, x1
101567c98:     	b.hs	0x101568164 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb10>
101567c9c:     	ldr	x8, [x11]
101567ca0:     	add	x8, x8, x21
101567ca4:     	ldrb	w9, [x8]
101567ca8:     	cmp	w9, #0x3
101567cac:     	str	x22, [sp, #0x70]
101567cb0:     	b.ne	0x101567cf4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6a0>
101567cb4:     	ldr	x8, [x8, #0x8]
101567cb8:     	ldr	x1, [x11, #0x18]
101567cbc:     	cmp	x8, x1
101567cc0:     	b.hs	0x101568144 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xaf0>
101567cc4:     	ldr	x1, [x11, #0x28]
101567cc8:     	cmp	x8, x1
101567ccc:     	b.hs	0x101568154 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb00>
101567cd0:     	ldr	x9, [x11, #0x10]
101567cd4:     	add	x9, x9, x8, lsl #6
101567cd8:     	ldr	x10, [x9]
101567cdc:     	cmp	x10, #0x0
101567ce0:     	csel	x26, xzr, x9, eq
101567ce4:     	ldr	x9, [x11, #0x20]
101567ce8:     	ldr	x25, [x9, x8, lsl #3]
101567cec:     	strb	w27, [sp, #0x450]
101567cf0:     	b	0x101567d34 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6e0>
101567cf4:     	ldr	q0, [x8]
101567cf8:     	add	x9, sp, #0x450
101567cfc:     	str	q0, [x9]
101567d00:     	ldr	q0, [x8, #0x10]
101567d04:     	str	q0, [x9, #0x10]
101567d08:     	ldr	x8, [x11, #0x30]
101567d0c:     	ldr	x8, [x8]
101567d10:     	ldr	x1, [x8]
101567d14:     	sub	x0, x29, #0xe0
101567d18:     	add	x2, sp, #0x450
101567d1c:     	bl	0x10157a570 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101567d20:     	ldur	x8, [x29, #-0xe0]
101567d24:     	strb	w27, [sp, #0x450]
101567d28:     	cmp	x8, #0x1
101567d2c:     	b.ne	0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567d30:     	ldp	x26, x25, [x29, #-0xd8]
101567d34:     	add	x0, sp, #0x450
101567d38:     	bl	0x101573cb0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101567d3c:     	ldr	x8, [sp, #0x38]
101567d40:     	ldr	x23, [x8, #0x190]
101567d44:     	ldr	x8, [sp, #0x28]
101567d48:     	ldr	w22, [x8, x24, lsl #2]
101567d4c:     	ldr	x8, [x23, #0x28]
101567d50:     	cmp	x8, x22
101567d54:     	b.ls	0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567d58:     	ldr	x8, [x23, #0x20]
101567d5c:     	mov	w9, #0x2c               ; =44
101567d60:     	add	x27, x8, x22, lsl #7
101567d64:     	strb	w9, [sp, #0x450]
101567d68:     	add	x0, sp, #0x450
101567d6c:     	bl	0x101573cb0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101567d70:     	cbz	x26, 0x101567e18 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x7c4>
101567d74:     	cbnz	x25, 0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567d78:     	ldr	w8, [x26, #0x38]
101567d7c:     	cmp	w8, w22
101567d80:     	b.ne	0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567d84:     	ldp	q1, q0, [x26, #0x10]
101567d88:     	add	x8, sp, #0x450
101567d8c:     	stp	q1, q0, [x8, #0x130]
101567d90:     	ldur	q0, [x27, #0x70]
101567d94:     	str	q0, [x8]
101567d98:     	ldur	q0, [x27, #0x80]
101567d9c:     	str	q0, [x8, #0x10]
101567da0:     	ldp	x8, x9, [x29, #-0xe0]
101567da4:     	ldr	x10, [sp, #0x450]
101567da8:     	ldr	x11, [sp, #0x458]
101567dac:     	ldp	x12, x13, [x29, #-0xd0]
101567db0:     	ldr	x14, [sp, #0x460]
101567db4:     	ldr	x15, [sp, #0x468]
101567db8:     	cmp	x8, x10
101567dbc:     	ccmp	x9, x11, #0x0, eq
101567dc0:     	ccmp	x12, x14, #0x0, eq
101567dc4:     	ccmp	x13, x15, #0x0, eq
101567dc8:     	b.ne	0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567dcc:     	add	x1, sp, #0xb8
101567dd0:     	mov	x0, x26
101567dd4:     	bl	0x102e15114 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
101567dd8:     	mov	w27, #0x2c              ; =44
101567ddc:     	cmp	x0, #0x1
101567de0:     	b.ne	0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567de4:     	sub	x8, x29, #0xb8
101567de8:     	add	x1, x23, #0x10
101567dec:     	mov	x0, x26
101567df0:     	bl	0x102e131f8 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
101567df4:     	ldurb	w8, [x29, #-0xb8]
101567df8:     	cmp	w8, #0x16
101567dfc:     	b.ne	0x101568124 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad0>
101567e00:     	add	x8, sp, #0x450
101567e04:     	add	x0, sp, #0x320
101567e08:     	add	x2, x23, #0x10
101567e0c:     	mov	x1, x26
101567e10:     	bl	0x10237b26c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget42measure_borrowed_canonical_value_footprint>
101567e14:     	b	0x101567e88 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x834>
101567e18:     	ldur	x8, [x27, #0x58]
101567e1c:     	cbnz	x8, 0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567e20:     	ldurh	w1, [x27, #0x12]
101567e24:     	ldurb	w0, [x27, #0x10]
101567e28:     	bl	0x1015780a4 <__RNvMNtCs1qJAwyMG1lC_11mech_engine13native_scalarNtB2_16NativeScalarKind16from_schema_body>
101567e2c:     	and	w26, w0, #0xff
101567e30:     	mov	w22, #0x2c              ; =44
101567e34:     	strb	w22, [sp, #0x450]
101567e38:     	cmp	w26, #0x7
101567e3c:     	b.eq	0x10156812c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad8>
101567e40:     	add	x0, sp, #0x450
101567e44:     	bl	0x101573cb0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101567e48:     	sub	x0, x29, #0x70
101567e4c:     	mov	x1, x26
101567e50:     	mov	x2, x25
101567e54:     	bl	0x101578114 <__RNvMNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact2irNtB2_17NativeScalarValue9from_bits>
101567e58:     	strb	w22, [sp, #0x450]
101567e5c:     	ldurb	w8, [x29, #-0x70]
101567e60:     	cmp	w8, #0x7
101567e64:     	b.eq	0x10156812c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad8>
101567e68:     	add	x0, sp, #0x450
101567e6c:     	bl	0x101573cb0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101567e70:     	add	x8, sp, #0x450
101567e74:     	add	x0, sp, #0x320
101567e78:     	add	x1, x27, #0x10
101567e7c:     	sub	x2, x29, #0x70
101567e80:     	bl	0x10237a774 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget37measure_native_scalar_frame_footprint>
101567e84:     	mov	w27, #0x2c              ; =44
101567e88:     	ldrb	w25, [sp, #0x450]
101567e8c:     	cmp	w25, #0x8
101567e90:     	b.ne	0x1015680e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa90>
101567e94:     	ldr	x8, [sp, #0x460]
101567e98:     	ldr	x22, [sp, #0x70]
101567e9c:     	adds	x22, x8, x22
101567ea0:     	b.hs	0x101567fb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101567ea4:     	strb	w27, [sp, #0x450]
101567ea8:     	add	x0, sp, #0x450
101567eac:     	bl	0x101573cb0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101567eb0:     	add	x21, x21, #0x20
101567eb4:     	add	x24, x24, #0x1
101567eb8:     	subs	x28, x28, #0x4
101567ebc:     	ldr	x11, [sp, #0x30]
101567ec0:     	b.ne	0x101567c90 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x63c>
101567ec4:     	b	0x101567ef8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
101567ec8:     	sub	x8, x29, #0xe0
101567ecc:     	ldurb	w9, [x29, #-0xdd]
101567ed0:     	ldurh	w10, [x8, #0x1]
101567ed4:     	orr	w21, w10, w9, lsl #16
101567ed8:     	ldur	w22, [x29, #-0xdc]
101567edc:     	ldur	q0, [x8, #0x18]
101567ee0:     	str	q0, [sp, #0x60]
101567ee4:     	ldur	q0, [x8, #0x8]
101567ee8:     	str	q0, [sp, #0x70]
101567eec:     	mov	w26, #0x29              ; =41
101567ef0:     	b	0x101567fc8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
101567ef4:     	mov	x22, #0x0               ; =0
101567ef8:     	ldr	x0, [sp, #0x20]
101567efc:     	mov	x1, x11
101567f00:     	bl	0x1014afe2c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_>
101567f04:     	add	x21, sp, #0x450
101567f08:     	tbnz	w0, #0x0, 0x101567f30 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8dc>
101567f0c:     	ldp	x2, x8, [sp, #0x30]
101567f10:     	ldr	x9, [x8, #0x190]
101567f14:     	add	x8, sp, #0x450
101567f18:     	add	x1, x9, #0x10
101567f1c:     	ldr	x0, [sp, #0x20]
101567f20:     	bl	0x1014b00c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_>
101567f24:     	ldrb	w26, [sp, #0x450]
101567f28:     	cmp	w26, #0x2e
101567f2c:     	b.ne	0x101567f80 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x92c>
101567f30:     	ldr	x8, [sp, #0x60]
101567f34:     	ldr	x8, [x8]
101567f38:     	subs	x8, x22, x8
101567f3c:     	ldr	x11, [sp, #0x38]
101567f40:     	add	x12, sp, #0x450
101567f44:     	b.lo	0x101567f60 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x90c>
101567f48:     	ldr	x9, [sp, #0x10]
101567f4c:     	ldr	x9, [x9]
101567f50:     	mov	w10, #0x2c              ; =44
101567f54:     	strb	w10, [sp, #0x450]
101567f58:     	adds	x22, x9, x8
101567f5c:     	b.lo	0x10156801c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x9c8>
101567f60:     	mov	w21, #0x0               ; =0
101567f64:     	mov	w25, #0x0               ; =0
101567f68:     	mov	w22, #0x0               ; =0
101567f6c:     	ldur	w8, [x12, #0x2]
101567f70:     	stur	w8, [x29, #-0xe0]
101567f74:     	ldrh	w8, [sp, #0x456]
101567f78:     	sturh	w8, [x29, #-0xdc]
101567f7c:     	b	0x101567fc4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
101567f80:     	ldrb	w23, [sp, #0x451]
101567f84:     	ldur	w8, [x21, #0x2]
101567f88:     	stur	w8, [x29, #-0xe0]
101567f8c:     	ldrh	w8, [sp, #0x456]
101567f90:     	sturh	w8, [x29, #-0xdc]
101567f94:     	ldr	w22, [sp, #0x45c]
101567f98:     	ldr	w8, [sp, #0x458]
101567f9c:     	and	w25, w8, #0xff
101567fa0:     	add	x9, sp, #0x450
101567fa4:     	lsr	w21, w8, #8
101567fa8:     	ldp	q0, q1, [x9, #0x10]
101567fac:     	stp	q1, q0, [sp, #0x60]
101567fb0:     	ldr	x24, [sp, #0x480]
101567fb4:     	b	0x101567fc8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
101567fb8:     	mov	w21, #0x0               ; =0
101567fbc:     	mov	w25, #0x0               ; =0
101567fc0:     	mov	w22, #0x0               ; =0
101567fc4:     	mov	w26, #0x2c              ; =44
101567fc8:     	add	x0, sp, #0x300
101567fcc:     	bl	0x102d5a4b0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_22ManagedNodeReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101567fd0:     	ldr	x8, [sp, #0x300]
101567fd4:     	mov	x9, #-0x1               ; =-1
101567fd8:     	ldaddl	x9, x8, [x8]
101567fdc:     	cmp	x8, #0x1
101567fe0:     	b.ne	0x101567ff0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x99c>
101567fe4:     	dmb	ishld
101567fe8:     	add	x0, sp, #0x300
101567fec:     	bl	0x102e1ac7c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101567ff0:     	add	x0, sp, #0x2e0
101567ff4:     	bl	0x102d5a780 <__RNvXs6_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101567ff8:     	ldr	x8, [sp, #0x2e0]
101567ffc:     	mov	x9, #-0x1               ; =-1
101568000:     	ldaddl	x9, x8, [x8]
101568004:     	cmp	x8, #0x1
101568008:     	b.ne	0x101567a0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
10156800c:     	dmb	ishld
101568010:     	add	x0, sp, #0x2e0
101568014:     	bl	0x102e1ac7c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101568018:     	b	0x101567a0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
10156801c:     	add	x0, sp, #0x450
101568020:     	mov	x21, x11
101568024:     	bl	0x101573cb0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101568028:     	ldr	w8, [x21, #0x110]
10156802c:     	ldr	x9, [sp, #0x8]
101568030:     	ldr	x9, [x9]
101568034:     	movi.2d	v0, #0000000000000000
101568038:     	add	x21, sp, #0x450
10156803c:     	stp	q0, q0, [x21, #0x20]
101568040:     	str	q0, [x21, #0x40]
101568044:     	str	xzr, [sp, #0x4a0]
101568048:     	str	x9, [sp, #0x4a8]
10156804c:     	str	wzr, [sp, #0x4b0]
101568050:     	stp	q0, q0, [x21]
101568054:     	mov	w9, #0x3                ; =3
101568058:     	orr	x1, x9, x8, lsl #32
10156805c:     	sub	x0, x29, #0xe0
101568060:     	add	x2, sp, #0x450
101568064:     	add	x4, sp, #0x230
101568068:     	mov	x3, x22
10156806c:     	bl	0x101576168 <__RINvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget30visit_memory_budget_violationsNtB2_21MemoryBudgetViolationNcNtINtNtNtCsgDHHaSskbIF_4core3ops12control_flow11ControlFlowB1k_E5Break0ECs7fdMCt8k5K6_8mech_gpu>
101568070:     	ldurb	w8, [x29, #-0xe0]
101568074:     	cmp	w8, #0x8
101568078:     	b.ne	0x1015680d0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa7c>
10156807c:     	add	x0, sp, #0x300
101568080:     	bl	0x101571c08 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101568084:     	add	x0, sp, #0x2e0
101568088:     	bl	0x101571c80 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156808c:     	ldr	w8, [sp, #0x200]
101568090:     	cmp	w8, #0x1a
101568094:     	b.eq	0x1015680a4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa50>
101568098:     	add	x8, sp, #0xd0
10156809c:     	add	x0, x8, #0x130
1015680a0:     	bl	0x101571bb8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
1015680a4:     	mov	w25, #0x0               ; =0
1015680a8:     	ldr	x8, [sp, #0xb8]
1015680ac:     	mov	x9, #-0x1               ; =-1
1015680b0:     	ldaddl	x9, x8, [x8]
1015680b4:     	mov	w26, #0x2e              ; =46
1015680b8:     	cmp	x8, #0x1
1015680bc:     	b.eq	0x101567a7c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x428>
1015680c0:     	b	0x101567a88 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
1015680c4:     	adrp	x0, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
1015680c8:     	add	x0, x0, #0x3a0
1015680cc:     	bl	0x103a05ca8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1015680d0:     	ldp	q0, q1, [x21, #0x130]
1015680d4:     	stp	q1, q0, [sp, #0x60]
1015680d8:     	mov	w26, #0x2a              ; =42
1015680dc:     	mov	w25, #0x12              ; =18
1015680e0:     	b	0x101567fc8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015680e4:     	ldrb	w8, [sp, #0x453]
1015680e8:     	add	x10, sp, #0x450
1015680ec:     	ldurh	w9, [x10, #0x1]
1015680f0:     	orr	w21, w9, w8, lsl #16
1015680f4:     	ldr	w22, [sp, #0x454]
1015680f8:     	ldur	q0, [x10, #0x18]
1015680fc:     	str	q0, [sp, #0x60]
101568100:     	ldur	q0, [x10, #0x8]
101568104:     	b	0x101567ee8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x894>
101568108:     	adrp	x0, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10156810c:     	add	x0, x0, #0x388
101568110:     	bl	0x103a05ca8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
101568114:     	b	0x101568170 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
101568118:     	mov	w25, #0x0               ; =0
10156811c:     	mov	w26, #0x2c              ; =44
101568120:     	b	0x101567a0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101568124:     	sub	x0, x29, #0xb8
101568128:     	bl	0x101572e40 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
10156812c:     	mov	w25, #0x0               ; =0
101568130:     	mov	w26, #0x2c              ; =44
101568134:     	b	0x101567fc8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
101568138:     	adrp	x0, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10156813c:     	add	x0, x0, #0x298
101568140:     	bl	0x103a05624 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
101568144:     	mov	x24, x8
101568148:     	adrp	x8, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10156814c:     	add	x8, x8, #0x448
101568150:     	b	0x101568160 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb0c>
101568154:     	mov	x24, x8
101568158:     	adrp	x8, 0x107f0d000 <_anon.10b4a09706de946c017a9e673c90ab39.300+0x2e0>
10156815c:     	add	x8, x8, #0x460
101568160:     	str	x8, [sp, #0x40]
101568164:     	mov	x0, x24
101568168:     	ldr	x2, [sp, #0x40]
10156816c:     	bl	0x103a05dd4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101568170:     	brk	#0x1
101568174:     	mov	x20, x0
101568178:     	ldr	x8, [sp, #0x300]
10156817c:     	mov	x9, #-0x1               ; =-1
101568180:     	ldaddl	x9, x8, [x8]
101568184:     	cmp	x8, #0x1
101568188:     	b.ne	0x1015681e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
10156818c:     	dmb	ishld
101568190:     	add	x0, sp, #0x300
101568194:     	bl	0x102e1ac7c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101568198:     	b	0x1015681e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
10156819c:     	bl	0x103a05dbc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015681a0:     	b	0x1015681d8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb84>
1015681a4:     	mov	x20, x0
1015681a8:     	ldr	x8, [sp, #0x2e0]
1015681ac:     	mov	x9, #-0x1               ; =-1
1015681b0:     	ldaddl	x9, x8, [x8]
1015681b4:     	cmp	x8, #0x1
1015681b8:     	b.ne	0x10156826c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015681bc:     	dmb	ishld
1015681c0:     	add	x0, sp, #0x2e0
1015681c4:     	bl	0x102e1ac7c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015681c8:     	b	0x10156826c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015681cc:     	bl	0x103a05dbc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015681d0:     	mov	x20, x0
1015681d4:     	b	0x1015681e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
1015681d8:     	mov	x20, x0
1015681dc:     	add	x0, sp, #0x300
1015681e0:     	bl	0x101571c08 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015681e4:     	add	x0, sp, #0x2e0
1015681e8:     	bl	0x101571c80 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015681ec:     	b	0x10156826c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015681f0:     	mov	x20, x0
1015681f4:     	b	0x1015682e0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015681f8:     	mov	x20, x0
1015681fc:     	ldr	x8, [sp, #0x90]
101568200:     	cbz	x8, 0x1015682e8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
101568204:     	ldr	x9, [x8]
101568208:     	subs	x9, x9, #0x1
10156820c:     	str	x9, [x8]
101568210:     	b.ne	0x1015682e8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
101568214:     	add	x0, x19, #0x8
101568218:     	bl	0x1023672ac <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
10156821c:     	b	0x1015682e8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
101568220:     	bl	0x103a05dbc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101568224:     	mov	x20, x0
101568228:     	ldr	x8, [sp, #0xa0]
10156822c:     	cbz	x8, 0x1015682e0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
101568230:     	ldr	x9, [x8]
101568234:     	subs	x9, x9, #0x1
101568238:     	str	x9, [x8]
10156823c:     	b.ne	0x1015682e0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
101568240:     	add	x0, x27, #0x8
101568244:     	bl	0x1023672ac <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101568248:     	b	0x1015682e0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
10156824c:     	bl	0x103a05dbc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101568250:     	mov	x20, x0
101568254:     	b	0x101568284 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc30>
101568258:     	mov	x20, x0
10156825c:     	b	0x1015682b4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc60>
101568260:     	mov	x20, x0
101568264:     	b	0x1015682a4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc50>
101568268:     	mov	x20, x0
10156826c:     	ldr	w8, [sp, #0x200]
101568270:     	cmp	w8, #0x1a
101568274:     	b.eq	0x101568284 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc30>
101568278:     	add	x8, sp, #0xd0
10156827c:     	add	x0, x8, #0x130
101568280:     	bl	0x101571bb8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
101568284:     	ldr	x8, [sp, #0xb8]
101568288:     	mov	x9, #-0x1               ; =-1
10156828c:     	ldaddl	x9, x8, [x8]
101568290:     	cmp	x8, #0x1
101568294:     	b.ne	0x1015682a4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc50>
101568298:     	dmb	ishld
10156829c:     	add	x0, sp, #0xb8
1015682a0:     	bl	0x102e1ac7c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015682a4:     	ldp	x8, x9, [sp, #0x50]
1015682a8:     	stp	x9, x8, [x19, #0x30]
1015682ac:     	ldr	x8, [sp, #0x48]
1015682b0:     	str	x8, [x19, #0x40]
1015682b4:     	add	x0, sp, #0x98
1015682b8:     	bl	0x101576078 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits10ScopeGuardECs7fdMCt8k5K6_8mech_gpu>
1015682bc:     	b	0x1015682e0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015682c0:     	bl	0x103a05dbc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015682c4:     	mov	x20, x0
1015682c8:     	ldr	x8, [x23]
1015682cc:     	subs	x8, x8, #0x1
1015682d0:     	str	x8, [x23]
1015682d4:     	b.ne	0x1015682e0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015682d8:     	add	x0, sp, #0xd0
1015682dc:     	bl	0x1023672ac <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1015682e0:     	add	x0, sp, #0x88
1015682e4:     	bl	0x1015760f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits12AccountGuardECs7fdMCt8k5K6_8mech_gpu>
1015682e8:     	mov	x0, x20
1015682ec:     	bl	0x103a071a0 <dyld_stub_binder+0x103a071a0>
1015682f0:     	bl	0x103a05dbc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015682f4:     	bl	0x103a05dbc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
