"""Root runs only after R76 finishes; capture accepted baseline without old timings."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
r=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-cold-budget-errors-round76-20261031');w=Path('/private/tmp/mech-deflate-linear-stack');c=json.loads((r/'configuration.json').read_text())
assert not c['initialized'],'Never relabel an initialized baseline'
assert len(sys.argv)==2,'Supply the accepted complete R76 checkpoint SHA'
checkpoint=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=w,text=True).strip()
assert json.loads((old/'decision.json').read_text())['status']=='retained','R76 acceptance is pending or rejected'
assert json.loads((old/'validation.json').read_text())['all_required_checks_pass'],'R76 qualification is incomplete'
release=json.loads((old/'final-release.json').read_text());binding=json.loads((old/'linked-primary/after/binding.json').read_text())
assert release['source_head']==binding['compiler_source']
for name,pin in binding['pins'].items():
 p=old/'linked-primary/after'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256'] and p.stat().st_size==pin['bytes']
assert hashlib.sha256((old/'linked-primary/after/worker').read_bytes()).hexdigest()==binding['worker_sha256']
(r/'variants/before').symlink_to(old/'variants/after',target_is_directory=True);before=r/'linked-primary/before';before.mkdir()
for p in (old/'linked-primary/after').iterdir():
 q=before/p.name
 if p.name in {'object.o','descriptor.json','metadata.json','worker'}:q.symlink_to(p)
 else:shutil.copy2(p,q)
for target,source in [('binding.json','linked-primary/after/binding.json'),('metadata.json','linked-primary/after/metadata.json'),('final-libraries.json','final-libraries.json'),('final-release.json','final-release.json'),('auxiliary-dependencies.json','auxiliary-dependencies.json'),('binary-audit.json','binary-audit.json')]:shutil.copy2(old/source,r/'baseline'/target)
for label in ['before','after']:
 (r/('sites-'+label)).mkdir(exist_ok=True)
 for name in ['allocation_sites.c','allocation_profile.rs','allocation_profile.h','usage.c','usage.h','sites.o','probe-pin.json']:shutil.copy2(old/'sites-after'/name,r/('sites-'+label)/name)
# Only a small census counter is read after the cohort boundary; no measurements run.
accepted=json.loads((old/'analysis/scorecard.json').read_text());counter={key:accepted['allocation']['after'][key]['median'] for key in ['allocation_requests','requested_bytes','reallocations']};target=json.loads((r/'allocation-target.json').read_text())
target.update(baseline_requests=counter['allocation_requests'],baseline_requested_bytes=counter['requested_bytes'],baseline_reallocations=counter['reallocations'])
(r/'allocation-target.json').write_text(json.dumps(target,indent=2)+'\n')
c.update(initialized=True,baseline_checkpoint=checkpoint,baseline_build_source=release['source_head']);(r/'configuration.json').write_text(json.dumps(c,indent=2)+'\n')
provenance={'round':76,'accepted_checkpoint':checkpoint,'measured_build_source':release['source_head'],'source_note':'Accepted R76 cold-error transport implementation and its actual qualified compiler graph. Checkpoint is the completed published review packet, not a relabeling of its earlier actual release source.','binary_note':'Fresh R76 emission matched the maintained Object/descriptor/metadata byte-for-byte. R77 emits and verifies its own candidate artifacts.','receipt_scope':'Historical baseline pins only; no R76 timing or test result is relabeled as fresh R77 evidence.'}
(r/'baseline/provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'accepted_checkpoint':checkpoint,'baseline_build_source':release['source_head'],'baseline_allocation_counter':target},indent=2))
