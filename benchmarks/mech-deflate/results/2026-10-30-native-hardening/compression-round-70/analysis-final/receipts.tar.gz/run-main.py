"""Execute only after both unit builds finish; all timing and diagnostics serialized."""
from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
for phase in ['parent','after']:
 d=json.loads((r/('engine-'+phase)/'full-planner.json').read_text());assert d['exit']==0 and d['executed_tests']==22
for name,args in [('linked-build.py',['after']),('run-primary.py',[]),('counters.py',[]),('sites.py',['before']),('sites.py',['after']),('profile-isolated.py',[]),('profile-reference.py',[]),('units.py',[]),('qualify-all.py',[]),('type-architecture.py',[]),('instruction-windows.py',[]),('host-assembly.py',[])]:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name),*args],check=True);print('DONE',name,flush=True)
(r/'DIAGNOSTIC_RUN_ALLOWED').write_text('All primary, scalar and frame control timing cohorts and compiler builds completed.\n')
subprocess.run(['python3',str(r/'diagnostic-counts.py')],check=True)
