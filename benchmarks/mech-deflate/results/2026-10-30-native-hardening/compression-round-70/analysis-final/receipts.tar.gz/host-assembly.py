"""Audit actual linked host call-port functions after all timing cohorts finish."""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;p=r/'host-assembly';p.mkdir()
for label in ['before','after']:
 worker=r/'linked-primary'/label/'worker';binding=json.loads((worker.parent/'binding.json').read_text());assert hashlib.sha256(worker.read_bytes()).hexdigest()==binding['worker_sha256']
 command=[sys.executable,str(r/'findings-packet/audit-observed-plan.py'),str(worker),str(p/label)];q=subprocess.run(command,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 (p/(label+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'compiler_source':binding['compiler_source'],'worker_sha256':binding['worker_sha256'],'audit_producer_sha256':hashlib.sha256((r/'findings-packet/audit-observed-plan.py').read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual linked host functions, after all measurements. Static counts do not establish dynamic counts.'},indent=2)+'\n')
 q.check_returncode();print(q.stdout,flush=True)
