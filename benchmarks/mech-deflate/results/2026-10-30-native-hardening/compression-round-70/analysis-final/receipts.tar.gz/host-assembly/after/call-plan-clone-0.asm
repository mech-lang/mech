
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010293ee6c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
10293ee6c:     	stp	x28, x27, [sp, #-0x60]!
10293ee70:     	stp	x26, x25, [sp, #0x10]
10293ee74:     	stp	x24, x23, [sp, #0x20]
10293ee78:     	stp	x22, x21, [sp, #0x30]
10293ee7c:     	stp	x20, x19, [sp, #0x40]
10293ee80:     	stp	x29, x30, [sp, #0x50]
10293ee84:     	add	x29, sp, #0x50
10293ee88:     	sub	sp, sp, #0x1e0
10293ee8c:     	mov	x24, x1
10293ee90:     	mov	x28, x0
10293ee94:     	add	x0, sp, #0xf8
10293ee98:     	add	x1, x1, #0x208
10293ee9c:     	bl	0x102940998 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
10293eea0:     	add	x0, x24, #0x2a8
10293eea4:     	bl	0x10275abb4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10293eea8:     	mov	x23, x0
10293eeac:     	mov	x27, x1
10293eeb0:     	stp	x0, x1, [x29, #-0x98]
10293eeb4:     	add	x0, x24, #0x2b8
10293eeb8:     	bl	0x10275abb4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10293eebc:     	mov	x19, x0
10293eec0:     	mov	x20, x1
10293eec4:     	stp	x0, x1, [x29, #-0x88]
10293eec8:     	add	x0, x24, #0x2c8
10293eecc:     	bl	0x10275af80 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10293eed0:     	mov	x25, x0
10293eed4:     	stp	x20, x19, [sp, #0xe0]
10293eed8:     	stp	x0, x1, [x29, #-0x78]
10293eedc:     	str	x1, [sp, #0xd8]
10293eee0:     	add	x0, x24, #0x2d8
10293eee4:     	bl	0x10275af80 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10293eee8:     	mov	x19, x0
10293eeec:     	mov	x22, x1
10293eef0:     	mov	x26, #0x0               ; =0
10293eef4:     	stp	x0, x1, [x29, #-0x68]
10293eef8:     	ldr	x21, [x24, #0x2f0]
10293eefc:     	lsl	x20, x21, #6
10293ef00:     	lsr	x8, x21, #58
10293ef04:     	cbnz	x8, 0x10293ef74 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
10293ef08:     	str	x27, [sp, #0xb8]
10293ef0c:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
10293ef10:     	cmp	x20, x8
10293ef14:     	b.hi	0x10293ef74 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
10293ef18:     	str	x23, [sp, #0xb0]
10293ef1c:     	cbz	x20, 0x10293ef84 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x118>
10293ef20:     	ldr	x27, [x24, #0x2e8]
10293ef24:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293ef28:     	mov	w26, #0x8               ; =8
10293ef2c:     	mov	x0, x20
10293ef30:     	mov	w1, #0x8                ; =8
10293ef34:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293ef38:     	str	x0, [sp, #0xc8]
10293ef3c:     	cbz	x0, 0x10293ef74 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
10293ef40:     	mov	x23, x28
10293ef44:     	cbz	x21, 0x10293ef58 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xec>
10293ef48:     	ldr	x0, [sp, #0xc8]
10293ef4c:     	mov	x1, x27
10293ef50:     	mov	x2, x20
10293ef54:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293ef58:     	mov	x26, #0x0               ; =0
10293ef5c:     	ldr	x8, [x24, #0x300]
10293ef60:     	lsl	x28, x8, #6
10293ef64:     	str	x8, [sp, #0xc0]
10293ef68:     	lsr	x8, x8, #58
10293ef6c:     	cbz	x8, 0x10293efa8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x13c>
10293ef70:     	b	0x10293eff4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
10293ef74:     	mov	x0, x26
10293ef78:     	mov	x1, x20
10293ef7c:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293ef80:     	b	0x10293f350 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
10293ef84:     	mov	x23, x28
10293ef88:     	mov	w8, #0x8                ; =8
10293ef8c:     	str	x8, [sp, #0xc8]
10293ef90:     	mov	x26, #0x0               ; =0
10293ef94:     	ldr	x8, [x24, #0x300]
10293ef98:     	lsl	x28, x8, #6
10293ef9c:     	str	x8, [sp, #0xc0]
10293efa0:     	lsr	x8, x8, #58
10293efa4:     	cbnz	x8, 0x10293eff4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
10293efa8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
10293efac:     	cmp	x28, x8
10293efb0:     	b.hi	0x10293eff4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
10293efb4:     	stp	x23, x28, [sp, #0x98]
10293efb8:     	cbz	x28, 0x10293f004 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x198>
10293efbc:     	ldr	x27, [x24, #0x2f8]
10293efc0:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293efc4:     	mov	w26, #0x8               ; =8
10293efc8:     	mov	x0, x28
10293efcc:     	mov	w1, #0x8                ; =8
10293efd0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293efd4:     	str	x0, [sp, #0xa8]
10293efd8:     	cbz	x0, 0x10293eff4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
10293efdc:     	ldr	x8, [sp, #0xc0]
10293efe0:     	cbz	x8, 0x10293f00c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
10293efe4:     	ldp	x2, x0, [sp, #0xa0]
10293efe8:     	mov	x1, x27
10293efec:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293eff0:     	b	0x10293f00c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
10293eff4:     	mov	x0, x26
10293eff8:     	mov	x1, x28
10293effc:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293f000:     	b	0x10293f350 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
10293f004:     	mov	w8, #0x8                ; =8
10293f008:     	str	x8, [sp, #0xa8]
10293f00c:     	ldr	x23, [x24, #0x310]
10293f010:     	add	x8, x23, x23, lsl #1
10293f014:     	lsl	x28, x8, #4
10293f018:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
10293f01c:     	movk	x8, #0x2aa, lsl #48
10293f020:     	cmp	x23, x8
10293f024:     	str	x28, [sp, #0xf0]
10293f028:     	b.ls	0x10293f040 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1d4>
10293f02c:     	mov	x26, #0x0               ; =0
10293f030:     	mov	x0, x26
10293f034:     	ldr	x1, [sp, #0xf0]
10293f038:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293f03c:     	b	0x10293f350 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
10293f040:     	str	x23, [sp, #0x90]
10293f044:     	cbz	x28, 0x10293f0ac <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x240>
10293f048:     	ldr	x27, [x24, #0x308]
10293f04c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293f050:     	mov	w26, #0x8               ; =8
10293f054:     	mov	x0, x28
10293f058:     	mov	w1, #0x8                ; =8
10293f05c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293f060:     	str	x0, [sp, #0xd0]
10293f064:     	cbz	x0, 0x10293f030 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1c4>
10293f068:     	cbz	x23, 0x10293f0b4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x248>
10293f06c:     	mov	x8, #0x0                ; =0
10293f070:     	mov	x9, x23
10293f074:     	ldr	x10, [sp, #0xf0]
10293f078:     	cmp	x10, x8
10293f07c:     	b.eq	0x10293f0b4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x248>
10293f080:     	add	x10, x27, x8
10293f084:     	ldr	x11, [sp, #0xd0]
10293f088:     	add	x11, x11, x8
10293f08c:     	ldp	q0, q1, [x10]
10293f090:     	ldr	q2, [x10, #0x20]
10293f094:     	stp	q1, q2, [x11, #0x10]
10293f098:     	str	q0, [x11]
10293f09c:     	add	x8, x8, #0x30
10293f0a0:     	subs	x9, x9, #0x1
10293f0a4:     	b.ne	0x10293f074 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x208>
10293f0a8:     	b	0x10293f0b4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x248>
10293f0ac:     	mov	w8, #0x8                ; =8
10293f0b0:     	str	x8, [sp, #0xd0]
10293f0b4:     	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
10293f0b8:     	movk	x10, #0xaaa, lsl #48
10293f0bc:     	ldr	x23, [x24, #0x320]
10293f0c0:     	add	x8, x23, x23, lsl #1
10293f0c4:     	lsl	x28, x8, #2
10293f0c8:     	cmp	x23, x10
10293f0cc:     	str	x28, [sp, #0x88]
10293f0d0:     	b.ls	0x10293f0e8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x27c>
10293f0d4:     	mov	x27, #0x0               ; =0
10293f0d8:     	mov	x0, x27
10293f0dc:     	ldr	x1, [sp, #0x88]
10293f0e0:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293f0e4:     	b	0x10293f350 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
10293f0e8:     	cbz	x28, 0x10293f14c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2e0>
10293f0ec:     	ldr	x26, [x24, #0x318]
10293f0f0:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293f0f4:     	mov	w27, #0x4               ; =4
10293f0f8:     	mov	x0, x28
10293f0fc:     	mov	w1, #0x4                ; =4
10293f100:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293f104:     	str	x0, [sp, #0x80]
10293f108:     	cbz	x0, 0x10293f0d8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x26c>
10293f10c:     	cbz	x23, 0x10293f11c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b0>
10293f110:     	ldp	x0, x2, [sp, #0x80]
10293f114:     	mov	x1, x26
10293f118:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293f11c:     	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
10293f120:     	movk	x10, #0xaaa, lsl #48
10293f124:     	ldr	x9, [x24, #0x330]
10293f128:     	add	x8, x9, x9, lsl #1
10293f12c:     	lsl	x28, x8, #2
10293f130:     	cmp	x9, x10
10293f134:     	b.ls	0x10293f168 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2fc>
10293f138:     	mov	x27, #0x0               ; =0
10293f13c:     	mov	x0, x27
10293f140:     	mov	x1, x28
10293f144:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293f148:     	b	0x10293f350 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
10293f14c:     	mov	w8, #0x4                ; =4
10293f150:     	str	x8, [sp, #0x80]
10293f154:     	ldr	x9, [x24, #0x330]
10293f158:     	add	x8, x9, x9, lsl #1
10293f15c:     	lsl	x28, x8, #2
10293f160:     	cmp	x9, x10
10293f164:     	b.hi	0x10293f138 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2cc>
10293f168:     	str	x9, [sp, #0x78]
10293f16c:     	str	x28, [sp, #0x60]
10293f170:     	cbz	x28, 0x10293f1b0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x344>
10293f174:     	ldr	x26, [x24, #0x328]
10293f178:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293f17c:     	mov	w27, #0x4               ; =4
10293f180:     	mov	x0, x28
10293f184:     	mov	w1, #0x4                ; =4
10293f188:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293f18c:     	str	x0, [sp, #0x68]
10293f190:     	cbz	x0, 0x10293f13c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2d0>
10293f194:     	ldr	x8, [sp, #0x78]
10293f198:     	cbz	x8, 0x10293f1b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x34c>
10293f19c:     	ldr	x0, [sp, #0x68]
10293f1a0:     	mov	x1, x26
10293f1a4:     	mov	x2, x28
10293f1a8:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293f1ac:     	b	0x10293f1b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x34c>
10293f1b0:     	mov	w8, #0x4                ; =4
10293f1b4:     	str	x8, [sp, #0x68]
10293f1b8:     	add	x0, x24, #0x338
10293f1bc:     	bl	0x10275aabc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10293f1c0:     	str	x0, [sp, #0x50]
10293f1c4:     	str	x1, [sp, #0x70]
10293f1c8:     	mov	x26, #0x0               ; =0
10293f1cc:     	ldr	x8, [x24, #0x350]
10293f1d0:     	lsl	x28, x8, #2
10293f1d4:     	str	x8, [sp, #0x58]
10293f1d8:     	lsr	x8, x8, #62
10293f1dc:     	cbnz	x8, 0x10293f22c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3c0>
10293f1e0:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
10293f1e4:     	cmp	x28, x8
10293f1e8:     	b.hi	0x10293f22c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3c0>
10293f1ec:     	str	x28, [sp, #0x40]
10293f1f0:     	cbz	x28, 0x10293f23c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3d0>
10293f1f4:     	ldr	x27, [x24, #0x348]
10293f1f8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293f1fc:     	mov	w26, #0x2               ; =2
10293f200:     	mov	x0, x28
10293f204:     	mov	w1, #0x2                ; =2
10293f208:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293f20c:     	str	x0, [sp, #0x48]
10293f210:     	cbz	x0, 0x10293f22c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3c0>
10293f214:     	ldr	x8, [sp, #0x58]
10293f218:     	cbz	x8, 0x10293f244 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3d8>
10293f21c:     	ldp	x2, x0, [sp, #0x40]
10293f220:     	mov	x1, x27
10293f224:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293f228:     	b	0x10293f244 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3d8>
10293f22c:     	mov	x0, x26
10293f230:     	mov	x1, x28
10293f234:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293f238:     	b	0x10293f350 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
10293f23c:     	mov	w8, #0x2                ; =2
10293f240:     	str	x8, [sp, #0x48]
10293f244:     	ldr	x26, [x24, #0x360]
10293f248:     	add	x8, x26, x26, lsl #1
10293f24c:     	lsl	x28, x8, #2
10293f250:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
10293f254:     	movk	x8, #0xaaa, lsl #48
10293f258:     	cmp	x26, x8
10293f25c:     	b.ls	0x10293f274 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x408>
10293f260:     	mov	x27, #0x0               ; =0
10293f264:     	mov	x0, x27
10293f268:     	mov	x1, x28
10293f26c:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293f270:     	b	0x10293f350 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
10293f274:     	str	x28, [sp, #0x30]
10293f278:     	cbz	x28, 0x10293f2b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x44c>
10293f27c:     	ldr	x8, [x24, #0x358]
10293f280:     	str	x8, [sp, #0x28]
10293f284:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293f288:     	mov	w27, #0x4               ; =4
10293f28c:     	mov	x0, x28
10293f290:     	mov	w1, #0x4                ; =4
10293f294:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293f298:     	str	x0, [sp, #0x38]
10293f29c:     	cbz	x0, 0x10293f264 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3f8>
10293f2a0:     	cbz	x26, 0x10293f2c0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x454>
10293f2a4:     	ldr	x0, [sp, #0x38]
10293f2a8:     	ldr	x1, [sp, #0x28]
10293f2ac:     	mov	x2, x28
10293f2b0:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293f2b4:     	b	0x10293f2c0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x454>
10293f2b8:     	mov	w8, #0x4                ; =4
10293f2bc:     	str	x8, [sp, #0x38]
10293f2c0:     	mov	x27, #0x0               ; =0
10293f2c4:     	ldr	x28, [x24, #0x370]
10293f2c8:     	lsl	x2, x28, #2
10293f2cc:     	lsr	x8, x28, #62
10293f2d0:     	cbnz	x8, 0x10293f344 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d8>
10293f2d4:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
10293f2d8:     	cmp	x2, x8
10293f2dc:     	b.hi	0x10293f344 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d8>
10293f2e0:     	ldrh	w9, [x24, #0x3e4]
10293f2e4:     	ldr	w11, [x24, #0x3e0]
10293f2e8:     	cbz	x2, 0x10293f354 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e8>
10293f2ec:     	stp	x11, x9, [sp, #0x10]
10293f2f0:     	ldr	x8, [x24, #0x368]
10293f2f4:     	str	x8, [sp, #0x8]
10293f2f8:     	str	x28, [sp, #0x20]
10293f2fc:     	mov	x28, x2
10293f300:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10293f304:     	mov	w27, #0x2               ; =2
10293f308:     	mov	x0, x28
10293f30c:     	mov	w1, #0x2                ; =2
10293f310:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10293f314:     	mov	x2, x28
10293f318:     	ldr	x28, [sp, #0x20]
10293f31c:     	cbz	x0, 0x10293f344 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d8>
10293f320:     	ldr	x10, [sp, #0xb8]
10293f324:     	str	x0, [sp, #0x28]
10293f328:     	cbz	x28, 0x10293f33c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
10293f32c:     	ldr	x1, [sp, #0x8]
10293f330:     	mov	x20, x10
10293f334:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293f338:     	mov	x10, x20
10293f33c:     	ldp	x11, x9, [sp, #0x10]
10293f340:     	b	0x10293f360 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4f4>
10293f344:     	mov	x0, x27
10293f348:     	mov	x1, x2
10293f34c:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10293f350:     	brk	#0x1
10293f354:     	mov	w8, #0x2                ; =2
10293f358:     	str	x8, [sp, #0x28]
10293f35c:     	ldr	x10, [sp, #0xb8]
10293f360:     	add	x8, sp, #0x59
10293f364:     	ldur	q0, [x8, #0xff]
10293f368:     	add	x8, sp, #0x69
10293f36c:     	ldur	q1, [x8, #0xff]
10293f370:     	orr	x8, x11, x9, lsl #32
10293f374:     	add	x20, x24, #0x378
10293f378:     	ldr	x27, [sp, #0x98]
10293f37c:     	add	x9, x27, #0x208
10293f380:     	stp	q0, q1, [x9, #0x60]
10293f384:     	add	x11, sp, #0x79
10293f388:     	ldur	q0, [x11, #0xff]
10293f38c:     	add	x11, sp, #0x89
10293f390:     	ldur	q1, [x11, #0xff]
10293f394:     	stp	q0, q1, [x9, #0x80]
10293f398:     	add	x11, sp, #0x19
10293f39c:     	ldur	q0, [x11, #0xff]
10293f3a0:     	add	x11, sp, #0x29
10293f3a4:     	ldur	q1, [x11, #0xff]
10293f3a8:     	stp	q0, q1, [x9, #0x20]
10293f3ac:     	add	x11, sp, #0x39
10293f3b0:     	ldur	q0, [x11, #0xff]
10293f3b4:     	add	x11, sp, #0x49
10293f3b8:     	ldur	q1, [x11, #0xff]
10293f3bc:     	stp	q0, q1, [x9, #0x40]
10293f3c0:     	ldur	q0, [sp, #0xf8]
10293f3c4:     	add	x11, sp, #0x9
10293f3c8:     	ldur	q1, [x11, #0xff]
10293f3cc:     	stp	q0, q1, [x9]
10293f3d0:     	ldr	x9, [sp, #0xb0]
10293f3d4:     	str	x9, [x27, #0x2a8]
10293f3d8:     	str	x10, [x27, #0x2b0]
10293f3dc:     	ldp	x9, x10, [sp, #0xe0]
10293f3e0:     	str	x10, [x27, #0x2b8]
10293f3e4:     	str	x9, [x27, #0x2c0]
10293f3e8:     	str	x25, [x27, #0x2c8]
10293f3ec:     	ldr	x9, [sp, #0xd8]
10293f3f0:     	str	x9, [x27, #0x2d0]
10293f3f4:     	str	x19, [x27, #0x2d8]
10293f3f8:     	str	x22, [x27, #0x2e0]
10293f3fc:     	ldr	x9, [sp, #0xc8]
10293f400:     	str	x9, [x27, #0x2e8]
10293f404:     	str	x21, [x27, #0x2f0]
10293f408:     	ldr	x9, [sp, #0xa8]
10293f40c:     	str	x9, [x27, #0x2f8]
10293f410:     	ldr	x9, [sp, #0xc0]
10293f414:     	str	x9, [x27, #0x300]
10293f418:     	ldr	x9, [sp, #0xd0]
10293f41c:     	str	x9, [x27, #0x308]
10293f420:     	ldr	x9, [sp, #0x90]
10293f424:     	str	x9, [x27, #0x310]
10293f428:     	ldr	x9, [sp, #0x80]
10293f42c:     	str	x9, [x27, #0x318]
10293f430:     	str	x23, [x27, #0x320]
10293f434:     	ldr	x9, [sp, #0x68]
10293f438:     	str	x9, [x27, #0x328]
10293f43c:     	ldr	x9, [sp, #0x78]
10293f440:     	str	x9, [x27, #0x330]
10293f444:     	ldr	x9, [sp, #0x50]
10293f448:     	str	x9, [x27, #0x338]
10293f44c:     	ldr	x9, [sp, #0x70]
10293f450:     	str	x9, [x27, #0x340]
10293f454:     	ldr	x9, [sp, #0x48]
10293f458:     	str	x9, [x27, #0x348]
10293f45c:     	ldr	x9, [sp, #0x58]
10293f460:     	str	x9, [x27, #0x350]
10293f464:     	ldr	x9, [sp, #0x38]
10293f468:     	str	x9, [x27, #0x358]
10293f46c:     	str	x26, [x27, #0x360]
10293f470:     	lsr	x9, x8, #32
10293f474:     	strh	w9, [x27, #0x3e4]
10293f478:     	str	w8, [x27, #0x3e0]
10293f47c:     	mov	x0, x27
10293f480:     	mov	x1, x24
10293f484:     	mov	w2, #0x208              ; =520
10293f488:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10293f48c:     	add	x8, x27, #0x378
10293f490:     	ldp	q0, q1, [x20, #0x40]
10293f494:     	stp	q0, q1, [x8, #0x40]
10293f498:     	ldr	x9, [x24, #0x3d8]
10293f49c:     	str	x9, [x27, #0x3d8]
10293f4a0:     	ldp	q0, q1, [x20]
10293f4a4:     	stp	q0, q1, [x8]
10293f4a8:     	ldp	q1, q0, [x20, #0x20]
10293f4ac:     	stp	q1, q0, [x8, #0x20]
10293f4b0:     	ldr	x8, [sp, #0x28]
10293f4b4:     	str	x8, [x27, #0x368]
10293f4b8:     	str	x28, [x27, #0x370]
10293f4bc:     	add	sp, sp, #0x1e0
10293f4c0:     	ldp	x29, x30, [sp, #0x50]
10293f4c4:     	ldp	x20, x19, [sp, #0x40]
10293f4c8:     	ldp	x22, x21, [sp, #0x30]
10293f4cc:     	ldp	x24, x23, [sp, #0x20]
10293f4d0:     	ldp	x26, x25, [sp, #0x10]
10293f4d4:     	ldp	x28, x27, [sp], #0x60
10293f4d8:     	ret
10293f4dc:     	mov	x19, x0
10293f4e0:     	b	0x10293f560 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6f4>
10293f4e4:     	mov	x19, x0
10293f4e8:     	b	0x10293f5f8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x78c>
10293f4ec:     	mov	x19, x0
10293f4f0:     	b	0x10293f600 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x794>
10293f4f4:     	mov	x19, x0
10293f4f8:     	b	0x10293f608 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x79c>
10293f4fc:     	mov	x19, x0
10293f500:     	b	0x10293f610 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7a4>
10293f504:     	mov	x19, x0
10293f508:     	ldr	x28, [sp, #0x70]
10293f50c:     	cbz	x26, 0x10293f528 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6bc>
10293f510:     	ldp	x1, x0, [sp, #0x30]
10293f514:     	mov	w2, #0x4                ; =4
10293f518:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f51c:     	b	0x10293f528 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6bc>
10293f520:     	mov	x19, x0
10293f524:     	ldr	x28, [sp, #0x70]
10293f528:     	ldr	x8, [sp, #0x58]
10293f52c:     	cbz	x8, 0x10293f548 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6dc>
10293f530:     	ldp	x1, x0, [sp, #0x40]
10293f534:     	mov	w2, #0x2                ; =2
10293f538:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f53c:     	b	0x10293f548 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6dc>
10293f540:     	mov	x19, x0
10293f544:     	ldr	x28, [sp, #0x70]
10293f548:     	cbz	x28, 0x10293f560 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6f4>
10293f54c:     	add	x8, x28, x28, lsl #1
10293f550:     	lsl	x1, x8, #5
10293f554:     	ldr	x0, [sp, #0x50]
10293f558:     	mov	w2, #0x8                ; =8
10293f55c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f560:     	ldr	x1, [sp, #0x60]
10293f564:     	ldr	x8, [sp, #0x78]
10293f568:     	cbz	x8, 0x10293f580 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x714>
10293f56c:     	ldr	x0, [sp, #0x68]
10293f570:     	mov	w2, #0x4                ; =4
10293f574:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f578:     	b	0x10293f580 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x714>
10293f57c:     	mov	x19, x0
10293f580:     	cbz	x23, 0x10293f598 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x72c>
10293f584:     	ldp	x0, x1, [sp, #0x80]
10293f588:     	mov	w2, #0x4                ; =4
10293f58c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f590:     	b	0x10293f598 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x72c>
10293f594:     	mov	x19, x0
10293f598:     	ldr	x8, [sp, #0x90]
10293f59c:     	cbz	x8, 0x10293f5b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74c>
10293f5a0:     	ldr	x0, [sp, #0xd0]
10293f5a4:     	ldr	x1, [sp, #0xf0]
10293f5a8:     	mov	w2, #0x8                ; =8
10293f5ac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f5b0:     	b	0x10293f5b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74c>
10293f5b4:     	mov	x19, x0
10293f5b8:     	ldr	x8, [sp, #0xc0]
10293f5bc:     	cbz	x8, 0x10293f5d4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x768>
10293f5c0:     	ldp	x1, x0, [sp, #0xa0]
10293f5c4:     	mov	w2, #0x8                ; =8
10293f5c8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f5cc:     	b	0x10293f5d4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x768>
10293f5d0:     	mov	x19, x0
10293f5d4:     	cbz	x21, 0x10293f5f0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x784>
10293f5d8:     	ldr	x0, [sp, #0xc8]
10293f5dc:     	mov	x1, x20
10293f5e0:     	mov	w2, #0x8                ; =8
10293f5e4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10293f5e8:     	b	0x10293f5f0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x784>
10293f5ec:     	mov	x19, x0
10293f5f0:     	sub	x0, x29, #0x68
10293f5f4:     	bl	0x1028e9748 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
10293f5f8:     	sub	x0, x29, #0x78
10293f5fc:     	bl	0x1028e9748 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
10293f600:     	sub	x0, x29, #0x88
10293f604:     	bl	0x1028e9644 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
10293f608:     	sub	x0, x29, #0x98
10293f60c:     	bl	0x1028e9644 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
10293f610:     	add	x0, sp, #0xf8
10293f614:     	bl	0x1028f08cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization9BoundCallECs1qJAwyMG1lC_11mech_engine>
10293f618:     	mov	x0, x19
10293f61c:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
10293f620:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
