
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a070d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand>:
102a070d0:     	stp	x28, x27, [sp, #-0x60]!
102a070d4:     	stp	x26, x25, [sp, #0x10]
102a070d8:     	stp	x24, x23, [sp, #0x20]
102a070dc:     	stp	x22, x21, [sp, #0x30]
102a070e0:     	stp	x20, x19, [sp, #0x40]
102a070e4:     	stp	x29, x30, [sp, #0x50]
102a070e8:     	add	x29, sp, #0x50
102a070ec:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
102a070f0:     	str	xzr, [sp]
102a070f4:     	sub	sp, sp, #0x510
102a070f8:     	str	xzr, [sp]
102a070fc:     	mov	x21, x1
102a07100:     	mov	x19, x0
102a07104:     	mov	x20, x8
102a07108:     	add	x23, sp, #0x1, lsl #12  ; =0x1000
102a0710c:     	add	x23, x23, #0x60
102a07110:     	ldr	x8, [x0, #0x1c8]
102a07114:     	cmp	x8, #0x2
102a07118:     	b.eq	0x102a07170 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa0>
102a0711c:     	mov	x22, x2
102a07120:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07124:     	add	x0, x0, #0x110
102a07128:     	add	x1, x19, #0x1c8
102a0712c:     	bl	0x102a21be0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102a07130:     	mov	x0, sp
102a07134:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a07138:     	add	x1, x1, #0x110
102a0713c:     	mov	w2, #0x3e8              ; =1000
102a07140:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a07144:     	ldr	x8, [sp, #0x2c0]
102a07148:     	cmp	x8, #0x1
102a0714c:     	b.ne	0x102a07168 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x98>
102a07150:     	ldr	x10, [x21, #0x20]
102a07154:     	ldr	x11, [x21, #0x58]
102a07158:     	ldr	x12, [x22]
102a0715c:     	cbnz	x10, 0x102a074f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x428>
102a07160:     	cbnz	x11, 0x102a074f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x428>
102a07164:     	cbnz	x12, 0x102a074f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x428>
102a07168:     	mov	x0, sp
102a0716c:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a07170:     	ldr	x8, [x19, #0xd8]
102a07174:     	ldr	x9, [x21, #0x20]
102a07178:     	adds	x3, x9, x8
102a0717c:     	b.hs	0x102a07e1c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd4c>
102a07180:     	ldr	x8, [x19, #0xe0]
102a07184:     	ldr	x9, [x21, #0x28]
102a07188:     	adds	x8, x9, x8
102a0718c:     	b.hs	0x102a07e28 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd58>
102a07190:     	ldr	x9, [x19, #0xe8]
102a07194:     	ldr	x10, [x21, #0x30]
102a07198:     	adds	x9, x10, x9
102a0719c:     	b.hs	0x102a07e34 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd64>
102a071a0:     	ldr	x10, [x19, #0xf0]
102a071a4:     	ldr	x11, [x21, #0x38]
102a071a8:     	adds	x10, x11, x10
102a071ac:     	b.hs	0x102a07e44 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd74>
102a071b0:     	ldr	x11, [x19, #0xf8]
102a071b4:     	ldr	x12, [x21, #0x40]
102a071b8:     	adds	x11, x12, x11
102a071bc:     	b.hs	0x102a07e54 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd84>
102a071c0:     	ldr	x12, [x19, #0x100]
102a071c4:     	ldr	x13, [x21, #0x48]
102a071c8:     	adds	x12, x13, x12
102a071cc:     	b.hs	0x102a07e64 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd94>
102a071d0:     	ldr	x13, [x19, #0x108]
102a071d4:     	ldr	x14, [x21, #0x50]
102a071d8:     	adds	x13, x14, x13
102a071dc:     	b.hs	0x102a07e74 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xda4>
102a071e0:     	ldr	x14, [x19, #0x110]
102a071e4:     	ldr	x15, [x21, #0x58]
102a071e8:     	adds	x14, x15, x14
102a071ec:     	b.hs	0x102a07e84 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xdb4>
102a071f0:     	ldr	w15, [x19, #0x118]
102a071f4:     	ldr	w16, [x21, #0x60]
102a071f8:     	adds	w15, w16, w15
102a071fc:     	b.hs	0x102a07e94 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xdc4>
102a07200:     	ldr	x16, [x19, #0xb8]
102a07204:     	ldr	x17, [x21]
102a07208:     	adds	x16, x17, x16
102a0720c:     	b.hs	0x102a07ea4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xdd4>
102a07210:     	ldr	x17, [x19, #0xc0]
102a07214:     	ldr	x0, [x21, #0x8]
102a07218:     	adds	x17, x0, x17
102a0721c:     	b.hs	0x102a07eb4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xde4>
102a07220:     	ldr	x0, [x19, #0xc8]
102a07224:     	ldr	x1, [x21, #0x10]
102a07228:     	adds	x0, x1, x0
102a0722c:     	b.hs	0x102a07ec4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xdf4>
102a07230:     	ldr	x1, [x19, #0xd0]
102a07234:     	ldr	x2, [x21, #0x18]
102a07238:     	adds	x1, x2, x1
102a0723c:     	b.hs	0x102a07ed4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe04>
102a07240:     	ldr	x2, [x19, #0x5f0]
102a07244:     	ldr	x4, [x19, #0x5f8]
102a07248:     	ldr	x5, [x19, #0x600]
102a0724c:     	ldr	x6, [x19, #0x608]
102a07250:     	ldr	x7, [x19, #0x610]
102a07254:     	ldr	x21, [x19, #0x618]
102a07258:     	ldr	x22, [x19, #0x620]
102a0725c:     	ldr	x24, [x19, #0x628]
102a07260:     	ldr	x25, [x19, #0x630]
102a07264:     	ldr	x26, [x19, #0x638]
102a07268:     	ldr	x27, [x19, #0x640]
102a0726c:     	ldr	x28, [x19, #0x648]
102a07270:     	ldr	w30, [x19, #0x650]
102a07274:     	cmp	x3, x7
102a07278:     	csel	x7, x3, x7, hi
102a0727c:     	cmp	x8, x21
102a07280:     	csel	x8, x8, x21, hi
102a07284:     	cmp	x9, x22
102a07288:     	csel	x9, x9, x22, hi
102a0728c:     	cmp	x10, x24
102a07290:     	csel	x10, x10, x24, hi
102a07294:     	cmp	x11, x25
102a07298:     	csel	x11, x11, x25, hi
102a0729c:     	cmp	x12, x26
102a072a0:     	csel	x12, x12, x26, hi
102a072a4:     	cmp	x13, x27
102a072a8:     	csel	x13, x13, x27, hi
102a072ac:     	cmp	x14, x28
102a072b0:     	csel	x14, x14, x28, hi
102a072b4:     	cmp	w15, w30
102a072b8:     	csel	w15, w15, w30, hi
102a072bc:     	cmp	x16, x2
102a072c0:     	csel	x16, x16, x2, hi
102a072c4:     	cmp	x17, x4
102a072c8:     	csel	x17, x17, x4, hi
102a072cc:     	cmp	x0, x5
102a072d0:     	csel	x0, x0, x5, hi
102a072d4:     	cmp	x1, x6
102a072d8:     	csel	x1, x1, x6, hi
102a072dc:     	str	x16, [x19, #0x5f0]
102a072e0:     	str	x17, [x19, #0x5f8]
102a072e4:     	str	x0, [x19, #0x600]
102a072e8:     	str	x1, [x19, #0x608]
102a072ec:     	str	x7, [x19, #0x610]
102a072f0:     	str	x8, [x19, #0x618]
102a072f4:     	str	x9, [x19, #0x620]
102a072f8:     	str	x10, [x19, #0x628]
102a072fc:     	str	x11, [x19, #0x630]
102a07300:     	str	x12, [x19, #0x638]
102a07304:     	str	x13, [x19, #0x640]
102a07308:     	str	x14, [x19, #0x648]
102a0730c:     	str	w15, [x19, #0x650]
102a07310:     	ldr	x8, [x19, #0x658]
102a07314:     	cmp	x3, x8
102a07318:     	csel	x8, x3, x8, hi
102a0731c:     	str	x8, [x19, #0x658]
102a07320:     	ldr	x1, [x19, #0x5b0]
102a07324:     	ldr	x2, [x19, #0x5b8]
102a07328:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a0732c:     	add	x0, x0, #0x110
102a07330:     	mov	x4, x3
102a07334:     	bl	0x102a087d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn28grow_transaction_stage_total>
102a07338:     	ldrb	w8, [x23, #0xb0]
102a0733c:     	cmp	w8, #0x16
102a07340:     	b.ne	0x102a073ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x2dc>
102a07344:     	ldr	x1, [x19, #0x5b0]
102a07348:     	ldr	x2, [x19, #0x5b8]
102a0734c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07350:     	add	x0, x0, #0x110
102a07354:     	bl	0x102a08d9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program17place_allocations>
102a07358:     	ldrb	w8, [x23, #0xb0]
102a0735c:     	cmp	w8, #0x16
102a07360:     	b.ne	0x102a073c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x2f8>
102a07364:     	ldr	x22, [sp, #0x1118]
102a07368:     	ldr	x24, [sp, #0x1120]
102a0736c:     	ldr	x25, [x19, #0x5c8]
102a07370:     	cbz	x25, 0x102a07410 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x340>
102a07374:     	ldr	x21, [x19, #0x5c0]
102a07378:     	add	x26, x21, #0x10
102a0737c:     	mov	x27, x25
102a07380:     	b	0x102a07390 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x2c0>
102a07384:     	add	x26, x26, #0x30
102a07388:     	subs	x27, x27, #0x1
102a0738c:     	b.eq	0x102a073fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x32c>
102a07390:     	ldr	x8, [x26]
102a07394:     	cbz	x8, 0x102a07384 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x2b4>
102a07398:     	ldur	x0, [x26, #-0x8]
102a0739c:     	lsl	x1, x8, #2
102a073a0:     	mov	w2, #0x4                ; =4
102a073a4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a073a8:     	b	0x102a07384 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x2b4>
102a073ac:     	ldr	q0, [sp, #0x1110]
102a073b0:     	ldr	q1, [sp, #0x1120]
102a073b4:     	stur	q0, [x20, #0x8]
102a073b8:     	stur	q1, [x20, #0x18]
102a073bc:     	ldr	q0, [sp, #0x1130]
102a073c0:     	stur	q0, [x20, #0x28]
102a073c4:     	b	0x102a075cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x4fc>
102a073c8:     	ldur	w9, [x23, #0xb1]
102a073cc:     	stur	w9, [x20, #0x9]
102a073d0:     	ldr	w9, [sp, #0x1114]
102a073d4:     	str	w9, [x20, #0xc]
102a073d8:     	ldr	x9, [sp, #0x1118]
102a073dc:     	ldr	x10, [sp, #0x1120]
102a073e0:     	ldur	q0, [x23, #0xc8]
102a073e4:     	str	q0, [x20, #0x20]
102a073e8:     	ldr	x11, [sp, #0x1138]
102a073ec:     	str	x11, [x20, #0x30]
102a073f0:     	strb	w8, [x20, #0x8]
102a073f4:     	stp	x9, x10, [x20, #0x10]
102a073f8:     	b	0x102a075cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x4fc>
102a073fc:     	add	x8, x25, x25, lsl #1
102a07400:     	lsl	x1, x8, #4
102a07404:     	mov	x0, x21
102a07408:     	mov	w2, #0x8                ; =8
102a0740c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a07410:     	str	x22, [x19, #0x5c0]
102a07414:     	str	x24, [x19, #0x5c8]
102a07418:     	ldr	x8, [x19, #0x1c8]
102a0741c:     	cmp	x8, #0x2
102a07420:     	b.eq	0x102a07458 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x388>
102a07424:     	add	x0, x19, #0x5b0
102a07428:     	bl	0x102766ba0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a0742c:     	mov	x21, x0
102a07430:     	mov	x22, x1
102a07434:     	ldr	x8, [x19, #0x508]
102a07438:     	cbz	x8, 0x102a07450 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x380>
102a0743c:     	ldr	x0, [x19, #0x500]
102a07440:     	add	x8, x8, x8, lsl #1
102a07444:     	lsl	x1, x8, #5
102a07448:     	mov	w2, #0x8                ; =8
102a0744c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a07450:     	str	x21, [x19, #0x500]
102a07454:     	str	x22, [x19, #0x508]
102a07458:     	ldr	x21, [x19, #0x620]
102a0745c:     	ldr	x1, [x19, #0x5b0]
102a07460:     	ldr	x2, [x19, #0x5b8]
102a07464:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07468:     	add	x0, x0, #0x110
102a0746c:     	bl	0x102a04504 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn17turn_storage_peak>
102a07470:     	ldrb	w8, [x23, #0xb0]
102a07474:     	cmp	w8, #0x16
102a07478:     	b.ne	0x102a075a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x4d0>
102a0747c:     	mov	x9, #0x0                ; =0
102a07480:     	add	x8, x19, #0x5f0
102a07484:     	ldr	x10, [sp, #0x1118]
102a07488:     	cmp	x10, x21
102a0748c:     	csel	x10, x10, x21, hi
102a07490:     	str	x10, [x19, #0x620]
102a07494:     	ldr	x10, [x19, #0x5b0]
102a07498:     	ldr	x11, [x19, #0x5b8]
102a0749c:     	add	x11, x11, x11, lsl #1
102a074a0:     	lsl	x11, x11, #5
102a074a4:     	cmp	x11, x9
102a074a8:     	b.eq	0x102a07714 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x644>
102a074ac:     	add	x12, x10, x9
102a074b0:     	ldr	w12, [x12, #0x8]
102a074b4:     	add	x9, x9, #0x60
102a074b8:     	cmp	w12, #0x2
102a074bc:     	b.ne	0x102a074a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x3d4>
102a074c0:     	add	x12, x10, x9
102a074c4:     	ldur	x3, [x12, #-0x40]
102a074c8:     	subs	x11, x11, x9
102a074cc:     	b.eq	0x102a07718 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x648>
102a074d0:     	mov	x13, #-0x5555555555555556 ; =-6148914691236517206
102a074d4:     	movk	x13, #0xaaab
102a074d8:     	umulh	x14, x11, x13
102a074dc:     	lsr	x11, x14, #6
102a074e0:     	sub	x13, x11, #0x1
102a074e4:     	ubfx	x11, x14, #6, #3
102a074e8:     	cmp	x13, #0x7
102a074ec:     	b.hs	0x102a07c68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb98>
102a074f0:     	mov	x12, #0x0               ; =0
102a074f4:     	b	0x102a07dac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcdc>
102a074f8:     	mov	x25, x19
102a074fc:     	ldr	x8, [x25, #0x88]!
102a07500:     	ldr	w9, [x25, #0x5f0]
102a07504:     	movi.2d	v0, #0000000000000000
102a07508:     	cbz	x8, 0x102a07604 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x534>
102a0750c:     	ldr	x13, [x19, #0x90]
102a07510:     	mov	x14, x8
102a07514:     	ldrh	w17, [x14, #0x2ca]
102a07518:     	add	x16, x14, #0x50
102a0751c:     	add	x0, x14, #0xe
102a07520:     	lsl	x1, x17, #3
102a07524:     	mov	x15, #-0x1              ; =-1
102a07528:     	b	0x102a07558 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x488>
102a0752c:     	ldrh	w2, [x0]
102a07530:     	cmp	wzr, w2
102a07534:     	cset	w2, hi
102a07538:     	csinv	w2, w2, wzr, hs
102a0753c:     	add	x0, x0, #0x8
102a07540:     	add	x16, x16, #0x38
102a07544:     	add	x15, x15, #0x1
102a07548:     	sub	x1, x1, #0x8
102a0754c:     	and	w2, w2, #0xff
102a07550:     	cmp	w2, #0x1
102a07554:     	b.ne	0x102a07580 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x4b0>
102a07558:     	cbz	x1, 0x102a07588 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x4b8>
102a0755c:     	ldur	w2, [x0, #-0x6]
102a07560:     	cmp	w9, w2
102a07564:     	cset	w2, hi
102a07568:     	csinv	w2, w2, wzr, hs
102a0756c:     	b.ne	0x102a0753c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x46c>
102a07570:     	ldurb	w2, [x0, #-0x2]
102a07574:     	cbnz	w2, 0x102a0752c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x45c>
102a07578:     	mov	w2, #0x1                ; =1
102a0757c:     	b	0x102a0753c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x46c>
102a07580:     	cbz	w2, 0x102a07600 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x530>
102a07584:     	b	0x102a0758c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x4bc>
102a07588:     	mov	x15, x17
102a0758c:     	cbz	x13, 0x102a07604 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x534>
102a07590:     	add	x14, x14, x15, lsl #3
102a07594:     	ldr	x14, [x14, #0x2d0]
102a07598:     	sub	x13, x13, #0x1
102a0759c:     	b	0x102a07514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x444>
102a075a0:     	ldur	w9, [x23, #0xb1]
102a075a4:     	stur	w9, [x20, #0x9]
102a075a8:     	ldr	w9, [sp, #0x1114]
102a075ac:     	str	w9, [x20, #0xc]
102a075b0:     	ldr	x9, [sp, #0x1118]
102a075b4:     	ldr	q0, [sp, #0x1120]
102a075b8:     	ldr	q1, [sp, #0x1130]
102a075bc:     	stur	q0, [x20, #0x18]
102a075c0:     	stur	q1, [x20, #0x28]
102a075c4:     	strb	w8, [x20, #0x8]
102a075c8:     	str	x9, [x20, #0x10]
102a075cc:     	mov	w8, #0x2                ; =2
102a075d0:     	str	x8, [x20]
102a075d4:     	mov	x0, x19
102a075d8:     	bl	0x1029cf1e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEBM_>
102a075dc:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
102a075e0:     	add	sp, sp, #0x510
102a075e4:     	ldp	x29, x30, [sp, #0x50]
102a075e8:     	ldp	x20, x19, [sp, #0x40]
102a075ec:     	ldp	x22, x21, [sp, #0x30]
102a075f0:     	ldp	x24, x23, [sp, #0x20]
102a075f4:     	ldp	x26, x25, [sp, #0x10]
102a075f8:     	ldp	x28, x27, [sp], #0x60
102a075fc:     	ret
102a07600:     	ldr	q0, [x16]
102a07604:     	ldr	x13, [sp, #0x2b8]
102a07608:     	ldr	x13, [x13, #0x198]
102a0760c:     	cmp	x12, #0x1
102a07610:     	b.ne	0x102a07620 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x550>
102a07614:     	ldp	x10, x14, [x22, #0x10]
102a07618:     	adds	x10, x14, x10
102a0761c:     	b.hs	0x102a08058 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf88>
102a07620:     	ldr	x14, [x22, #0x8]
102a07624:     	tst	w12, #0x1
102a07628:     	add	x12, x21, #0x50
102a0762c:     	add	x15, x22, #0x28
102a07630:     	csel	x12, x15, x12, ne
102a07634:     	ldr	x12, [x12]
102a07638:     	add	x24, sp, #0x3e8
102a0763c:     	csel	x11, x14, x11, ne
102a07640:     	subs	x14, x10, x13
102a07644:     	str	x11, [sp, #0x3e8]
102a07648:     	str	x13, [sp, #0x3f0]
102a0764c:     	csel	x11, xzr, x14, lo
102a07650:     	str	x11, [sp, #0x3f8]
102a07654:     	str	x10, [sp, #0x400]
102a07658:     	str	x12, [sp, #0x408]
102a0765c:     	stur	q0, [x24, #0x28]
102a07660:     	cbz	x8, 0x102a077f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x720>
102a07664:     	ldr	x10, [x19, #0x90]
102a07668:     	ldrh	w13, [x8, #0x2ca]
102a0766c:     	add	x12, x8, #0x28
102a07670:     	add	x14, x8, #0xe
102a07674:     	lsl	x15, x13, #3
102a07678:     	mov	x11, #-0x1              ; =-1
102a0767c:     	b	0x102a076ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x5dc>
102a07680:     	ldrh	w16, [x14]
102a07684:     	cmp	wzr, w16
102a07688:     	cset	w16, hi
102a0768c:     	csinv	w16, w16, wzr, hs
102a07690:     	add	x14, x14, #0x8
102a07694:     	add	x12, x12, #0x38
102a07698:     	add	x11, x11, #0x1
102a0769c:     	sub	x15, x15, #0x8
102a076a0:     	and	w16, w16, #0xff
102a076a4:     	cmp	w16, #0x1
102a076a8:     	b.ne	0x102a076d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x608>
102a076ac:     	cbz	x15, 0x102a076e0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x610>
102a076b0:     	ldur	w17, [x14, #-0x6]
102a076b4:     	cmp	w9, w17
102a076b8:     	cset	w16, hi
102a076bc:     	csinv	w16, w16, wzr, hs
102a076c0:     	cmp	w17, w9
102a076c4:     	b.ne	0x102a07690 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x5c0>
102a076c8:     	ldurb	w16, [x14, #-0x2]
102a076cc:     	cbnz	w16, 0x102a07680 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x5b0>
102a076d0:     	mov	w16, #0x1               ; =1
102a076d4:     	b	0x102a07690 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x5c0>
102a076d8:     	cbz	w16, 0x102a076f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x628>
102a076dc:     	b	0x102a076e4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x614>
102a076e0:     	mov	x11, x13
102a076e4:     	cbz	x10, 0x102a077f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x720>
102a076e8:     	add	x8, x8, x11, lsl #3
102a076ec:     	ldr	x8, [x8, #0x2d0]
102a076f0:     	sub	x10, x10, #0x1
102a076f4:     	b	0x102a07668 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x598>
102a076f8:     	ldp	q0, q1, [x24]
102a076fc:     	ldr	q2, [x24, #0x20]
102a07700:     	ldr	x8, [sp, #0x418]
102a07704:     	str	x8, [x12, #0x30]
102a07708:     	stp	q1, q2, [x12, #0x10]
102a0770c:     	str	q0, [x12]
102a07710:     	b	0x102a0781c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x74c>
102a07714:     	mov	x3, #0x0                ; =0
102a07718:     	str	x3, [x19, #0x660]
102a0771c:     	ldr	w9, [x19, #0x678]
102a07720:     	ldp	q0, q1, [x8, #0x40]
102a07724:     	str	q0, [sp, #0xcb0]
102a07728:     	str	q1, [sp, #0xcc0]
102a0772c:     	ldr	x10, [x8, #0x60]
102a07730:     	str	x10, [sp, #0xcd0]
102a07734:     	ldp	q0, q1, [x8]
102a07738:     	str	q0, [sp, #0xc70]
102a0773c:     	str	q1, [sp, #0xc80]
102a07740:     	ldp	q1, q0, [x8, #0x20]
102a07744:     	str	q0, [sp, #0xca0]
102a07748:     	str	q1, [sp, #0xc90]
102a0774c:     	ldr	x2, [x19, #0x658]
102a07750:     	ldp	q0, q1, [x19, #0x1a0]
102a07754:     	str	q0, [sp, #0x1190]
102a07758:     	str	q1, [sp, #0x11a0]
102a0775c:     	ldr	x8, [x19, #0x1c0]
102a07760:     	str	x8, [sp, #0x11b0]
102a07764:     	ldp	q0, q1, [x19, #0x160]
102a07768:     	str	q0, [sp, #0x1150]
102a0776c:     	str	q1, [sp, #0x1160]
102a07770:     	ldp	q1, q0, [x19, #0x180]
102a07774:     	str	q0, [sp, #0x1180]
102a07778:     	str	q1, [sp, #0x1170]
102a0777c:     	ldp	q0, q1, [x19, #0x120]
102a07780:     	str	q0, [sp, #0x1110]
102a07784:     	str	q1, [sp, #0x1120]
102a07788:     	ldp	q1, q0, [x19, #0x140]
102a0778c:     	mov	w8, #0x3                ; =3
102a07790:     	orr	x0, x8, x9, lsl #32
102a07794:     	str	q0, [sp, #0x1140]
102a07798:     	str	q1, [sp, #0x1130]
102a0779c:     	add	x1, sp, #0xc70
102a077a0:     	add	x4, sp, #0x1, lsl #12   ; =0x1000
102a077a4:     	add	x4, x4, #0x110
102a077a8:     	bl	0x102d1b8a4 <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget27evaluate_call_memory_budget>
102a077ac:     	cmp	x1, #0x2
102a077b0:     	b.hs	0x102a07ef8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe28>
102a077b4:     	mov	x25, x1
102a077b8:     	mov	x23, x0
102a077bc:     	ldr	x8, [x19, #0x5e8]
102a077c0:     	cbz	x8, 0x102a077d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x704>
102a077c4:     	ldr	x0, [x19, #0x5e0]
102a077c8:     	lsl	x1, x8, #5
102a077cc:     	mov	w2, #0x8                ; =8
102a077d0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a077d4:     	str	x23, [x19, #0x5e0]
102a077d8:     	str	x25, [x19, #0x5e8]
102a077dc:     	mov	x0, x20
102a077e0:     	mov	x1, x19
102a077e4:     	mov	w2, #0x680              ; =1664
102a077e8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a077ec:     	b	0x102a075dc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x50c>
102a077f0:     	orr	x9, x9, #0x100000000
102a077f4:     	str	x8, [sp, #0x1110]
102a077f8:     	str	xzr, [sp, #0x1118]
102a077fc:     	str	x11, [sp, #0x1120]
102a07800:     	str	x25, [sp, #0x1128]
102a07804:     	str	x9, [sp, #0x1130]
102a07808:     	add	x8, sp, #0xc70
102a0780c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07810:     	add	x0, x0, #0x110
102a07814:     	add	x1, sp, #0x3e8
102a07818:     	bl	0x102a023bc <__RNvMs6_NtNtNtNtCsgKscDXrlV49_5alloc11collections5btree3map5entryINtB5_11VacantEntryTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB1o_18operation_contract10validation13PortDirectiontENtNtNtB1o_11memory_plan5model22CurrentMemoryFootprintE12insert_entryCs1qJAwyMG1lC_11mech_engine>
102a0781c:     	add	x22, x25, #0x5f0
102a07820:     	ldp	x8, x9, [x19, #0x88]
102a07824:     	ldr	x10, [x19, #0x98]
102a07828:     	cmp	x8, #0x0
102a0782c:     	csel	x10, x10, xzr, ne
102a07830:     	cset	w11, ne
102a07834:     	str	x11, [sp, #0x1110]
102a07838:     	str	xzr, [sp, #0x1118]
102a0783c:     	str	x8, [sp, #0x1120]
102a07840:     	str	x9, [sp, #0x1128]
102a07844:     	str	x11, [sp, #0x1130]
102a07848:     	str	xzr, [sp, #0x1138]
102a0784c:     	str	x8, [sp, #0x1140]
102a07850:     	str	x9, [sp, #0x1148]
102a07854:     	str	x10, [sp, #0x1150]
102a07858:     	str	x22, [sp, #0x1158]
102a0785c:     	add	x25, sp, #0x420
102a07860:     	add	x8, sp, #0x420
102a07864:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07868:     	add	x0, x0, #0x110
102a0786c:     	bl	0x1025941e8 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_>
102a07870:     	ldr	x8, [sp, #0x2c0]
102a07874:     	add	x9, x19, #0xa0
102a07878:     	str	x8, [sp, #0x470]
102a0787c:     	str	x22, [sp, #0x450]
102a07880:     	str	x9, [sp, #0x458]
102a07884:     	str	xzr, [sp, #0x468]
102a07888:     	str	x25, [sp, #0x460]
102a0788c:     	add	x8, sp, #0x438
102a07890:     	add	x0, sp, #0x450
102a07894:     	bl	0x1027d607c <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_>
102a07898:     	ldr	x22, [sp, #0x440]
102a0789c:     	ldr	x4, [sp, #0x448]
102a078a0:     	ldp	q0, q1, [sp, #0x80]
102a078a4:     	str	q0, [sp, #0x10e0]
102a078a8:     	str	q1, [sp, #0x10f0]
102a078ac:     	ldr	x8, [sp, #0xa0]
102a078b0:     	str	x8, [sp, #0x1100]
102a078b4:     	ldp	q0, q1, [sp, #0x40]
102a078b8:     	str	q0, [sp, #0x10a0]
102a078bc:     	str	q1, [sp, #0x10b0]
102a078c0:     	ldp	q1, q0, [sp, #0x60]
102a078c4:     	str	q0, [sp, #0x10d0]
102a078c8:     	str	q1, [sp, #0x10c0]
102a078cc:     	ldp	q0, q1, [sp]
102a078d0:     	str	q0, [sp, #0x1060]
102a078d4:     	str	q1, [sp, #0x1070]
102a078d8:     	ldp	q1, q0, [sp, #0x20]
102a078dc:     	str	q0, [sp, #0x1090]
102a078e0:     	str	q1, [sp, #0x1080]
102a078e4:     	str	xzr, [sp]
102a078e8:     	str	xzr, [sp, #0x10]
102a078ec:     	str	xzr, [sp, #0x20]
102a078f0:     	str	xzr, [sp, #0x30]
102a078f4:     	str	xzr, [sp, #0x40]
102a078f8:     	str	xzr, [sp, #0x50]
102a078fc:     	str	xzr, [sp, #0x60]
102a07900:     	str	xzr, [sp, #0x70]
102a07904:     	str	xzr, [sp, #0x80]
102a07908:     	str	xzr, [sp, #0x90]
102a0790c:     	mov	x9, sp
102a07910:     	str	wzr, [sp, #0xa0]
102a07914:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a07918:     	add	x8, x8, #0x110
102a0791c:     	mov	x0, sp
102a07920:     	add	x1, x9, #0x208
102a07924:     	add	x2, sp, #0x420
102a07928:     	mov	x3, x22
102a0792c:     	bl	0x102d73608 <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6derive27resolve_current_call_memory>
102a07930:     	ldr	q0, [sp, #0x10e0]
102a07934:     	ldr	q1, [sp, #0x10f0]
102a07938:     	stp	q0, q1, [sp, #0x80]
102a0793c:     	ldr	x8, [sp, #0x1100]
102a07940:     	str	x8, [sp, #0xa0]
102a07944:     	ldr	q0, [sp, #0x10a0]
102a07948:     	ldr	q1, [sp, #0x10b0]
102a0794c:     	stp	q0, q1, [sp, #0x40]
102a07950:     	ldr	q0, [sp, #0x10d0]
102a07954:     	ldr	q1, [sp, #0x10c0]
102a07958:     	stp	q1, q0, [sp, #0x60]
102a0795c:     	ldr	q0, [sp, #0x1060]
102a07960:     	ldr	q1, [sp, #0x1070]
102a07964:     	stp	q0, q1, [sp]
102a07968:     	ldr	q0, [sp, #0x1090]
102a0796c:     	ldr	q1, [sp, #0x1080]
102a07970:     	stp	q1, q0, [sp, #0x20]
102a07974:     	ldr	x8, [sp, #0x1110]
102a07978:     	cmp	x8, #0x2
102a0797c:     	b.ne	0x102a0799c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x8cc>
102a07980:     	ldur	q0, [x23, #0xb8]
102a07984:     	ldur	q1, [x23, #0xc8]
102a07988:     	str	q0, [sp, #0xc40]
102a0798c:     	str	q1, [sp, #0xc50]
102a07990:     	ldur	q0, [x23, #0xd8]
102a07994:     	str	q0, [sp, #0xc60]
102a07998:     	b	0x102a079fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x92c>
102a0799c:     	mov	x26, sp
102a079a0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a079a4:     	add	x8, x8, #0x110
102a079a8:     	add	x0, sp, #0xc70
102a079ac:     	add	x1, x8, #0x38
102a079b0:     	mov	w2, #0x3b0              ; =944
102a079b4:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a079b8:     	ldr	x25, [sp]
102a079bc:     	add	x0, sp, #0xc70
102a079c0:     	add	x1, x26, #0x38
102a079c4:     	mov	w2, #0x1d0              ; =464
102a079c8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a079cc:     	ldur	q0, [x23, #0x8]
102a079d0:     	ldur	q1, [x23, #0x18]
102a079d4:     	str	q0, [sp, #0xc40]
102a079d8:     	str	q1, [sp, #0xc50]
102a079dc:     	ldur	q0, [x23, #0x28]
102a079e0:     	str	q0, [sp, #0xc60]
102a079e4:     	add	x0, sp, #0x890
102a079e8:     	add	x1, sp, #0xc70
102a079ec:     	mov	w2, #0x3b0              ; =944
102a079f0:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a079f4:     	cmp	x25, #0x2
102a079f8:     	b.ne	0x102a07a58 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x988>
102a079fc:     	ldr	q0, [sp, #0xc40]
102a07a00:     	ldr	q1, [sp, #0xc50]
102a07a04:     	str	q0, [sp, #0x860]
102a07a08:     	str	q1, [sp, #0x870]
102a07a0c:     	ldr	q2, [sp, #0xc60]
102a07a10:     	str	q2, [sp, #0x880]
102a07a14:     	stur	q0, [x20, #0x8]
102a07a18:     	stur	q1, [x20, #0x18]
102a07a1c:     	stur	q2, [x20, #0x28]
102a07a20:     	mov	w8, #0x2                ; =2
102a07a24:     	str	x8, [x20]
102a07a28:     	ldr	x8, [sp, #0x438]
102a07a2c:     	cbz	x8, 0x102a07a44 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x974>
102a07a30:     	lsl	x9, x8, #6
102a07a34:     	sub	x1, x9, x8, lsl #3
102a07a38:     	mov	x0, x22
102a07a3c:     	mov	w2, #0x8                ; =8
102a07a40:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a07a44:     	add	x0, sp, #0x420
102a07a48:     	bl	0x1025ba820 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a07a4c:     	mov	x0, sp
102a07a50:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a07a54:     	b	0x102a075d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x504>
102a07a58:     	ldr	q0, [sp, #0xc40]
102a07a5c:     	ldr	q1, [sp, #0xc50]
102a07a60:     	str	q0, [sp, #0x860]
102a07a64:     	str	q1, [sp, #0x870]
102a07a68:     	ldr	q0, [sp, #0xc60]
102a07a6c:     	str	q0, [sp, #0x880]
102a07a70:     	add	x8, sp, #0x478
102a07a74:     	add	x0, x8, #0x38
102a07a78:     	add	x1, sp, #0x890
102a07a7c:     	mov	w2, #0x3b0              ; =944
102a07a80:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a07a84:     	ldr	q0, [sp, #0x860]
102a07a88:     	ldr	q1, [sp, #0x870]
102a07a8c:     	stur	q0, [x24, #0x98]
102a07a90:     	stur	q1, [x24, #0xa8]
102a07a94:     	ldr	q0, [sp, #0x880]
102a07a98:     	stur	q0, [x24, #0xb8]
102a07a9c:     	str	x25, [sp, #0x478]
102a07aa0:     	ldr	x1, [x19, #0x5b0]
102a07aa4:     	ldr	x2, [x19, #0x5b8]
102a07aa8:     	ldr	w5, [x19, #0x678]
102a07aac:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07ab0:     	add	x0, x0, #0x110
102a07ab4:     	mov	x3, sp
102a07ab8:     	add	x4, sp, #0x478
102a07abc:     	mov	x6, x19
102a07ac0:     	bl	0x102a069a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn24refresh_turn_allocations>
102a07ac4:     	ldrb	w8, [x23, #0xb0]
102a07ac8:     	cmp	w8, #0x16
102a07acc:     	b.ne	0x102a07df0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd20>
102a07ad0:     	ldr	x8, [sp, #0x810]
102a07ad4:     	ldr	x9, [x19, #0xd8]
102a07ad8:     	adds	x8, x9, x8
102a07adc:     	b.hs	0x102a08070 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfa0>
102a07ae0:     	ldr	x9, [x19, #0xe0]
102a07ae4:     	ldr	x10, [sp, #0x818]
102a07ae8:     	adds	x9, x10, x9
102a07aec:     	b.hs	0x102a08080 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfb0>
102a07af0:     	ldr	x10, [sp, #0x820]
102a07af4:     	ldr	x11, [x19, #0xe8]
102a07af8:     	adds	x10, x11, x10
102a07afc:     	b.hs	0x102a08090 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfc0>
102a07b00:     	ldr	x11, [sp, #0x828]
102a07b04:     	ldr	x12, [x19, #0xf0]
102a07b08:     	adds	x11, x12, x11
102a07b0c:     	b.hs	0x102a080a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfd0>
102a07b10:     	ldr	x12, [sp, #0x830]
102a07b14:     	ldr	x13, [x19, #0xf8]
102a07b18:     	adds	x12, x13, x12
102a07b1c:     	b.hs	0x102a080b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfe0>
102a07b20:     	ldr	x13, [sp, #0x838]
102a07b24:     	ldr	x14, [x19, #0x100]
102a07b28:     	adds	x13, x14, x13
102a07b2c:     	b.hs	0x102a080c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xff0>
102a07b30:     	ldr	x14, [sp, #0x840]
102a07b34:     	ldr	x15, [x19, #0x108]
102a07b38:     	adds	x14, x15, x14
102a07b3c:     	b.hs	0x102a080d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1000>
102a07b40:     	ldr	x15, [sp, #0x848]
102a07b44:     	ldr	x16, [x19, #0x110]
102a07b48:     	adds	x15, x16, x15
102a07b4c:     	b.hs	0x102a080e0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1010>
102a07b50:     	ldr	w16, [sp, #0x850]
102a07b54:     	ldr	w17, [x19, #0x118]
102a07b58:     	adds	w16, w17, w16
102a07b5c:     	b.hs	0x102a080f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1020>
102a07b60:     	ldr	x17, [sp, #0x7f0]
102a07b64:     	ldr	x0, [x19, #0xb8]
102a07b68:     	adds	x17, x0, x17
102a07b6c:     	b.hs	0x102a08100 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1030>
102a07b70:     	ldr	x0, [sp, #0x7f8]
102a07b74:     	ldr	x1, [x19, #0xc0]
102a07b78:     	adds	x0, x1, x0
102a07b7c:     	b.hs	0x102a08110 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1040>
102a07b80:     	ldr	x1, [sp, #0x800]
102a07b84:     	ldr	x2, [x19, #0xc8]
102a07b88:     	adds	x1, x2, x1
102a07b8c:     	b.hs	0x102a08120 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1050>
102a07b90:     	ldr	x2, [sp, #0x808]
102a07b94:     	ldr	x3, [x19, #0xd0]
102a07b98:     	adds	x2, x3, x2
102a07b9c:     	b.hs	0x102a08130 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1060>
102a07ba0:     	str	x17, [x19, #0x5f0]
102a07ba4:     	str	x0, [x19, #0x5f8]
102a07ba8:     	str	x1, [x19, #0x600]
102a07bac:     	str	x2, [x19, #0x608]
102a07bb0:     	str	x8, [x19, #0x610]
102a07bb4:     	str	x9, [x19, #0x618]
102a07bb8:     	str	x10, [x19, #0x620]
102a07bbc:     	str	x11, [x19, #0x628]
102a07bc0:     	str	x12, [x19, #0x630]
102a07bc4:     	str	x13, [x19, #0x638]
102a07bc8:     	str	x14, [x19, #0x640]
102a07bcc:     	str	x15, [x19, #0x648]
102a07bd0:     	str	w16, [x19, #0x650]
102a07bd4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07bd8:     	add	x0, x0, #0x110
102a07bdc:     	add	x1, sp, #0x478
102a07be0:     	mov	w2, #0x3e8              ; =1000
102a07be4:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a07be8:     	ldr	x3, [x19, #0x5b0]
102a07bec:     	ldr	x4, [x19, #0x5b8]
102a07bf0:     	add	x0, sp, #0xc70
102a07bf4:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a07bf8:     	add	x1, x1, #0x110
102a07bfc:     	mov	x2, sp
102a07c00:     	bl	0x102a04250 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15scope_turn_call>
102a07c04:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a07c08:     	add	x0, x0, #0x110
102a07c0c:     	add	x1, sp, #0xc70
102a07c10:     	mov	w2, #0x3e8              ; =1000
102a07c14:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a07c18:     	ldr	x8, [x19, #0x1c8]
102a07c1c:     	cmp	x8, #0x2
102a07c20:     	b.eq	0x102a07c2c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb5c>
102a07c24:     	add	x0, x19, #0x1c8
102a07c28:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a07c2c:     	add	x0, x19, #0x1c8
102a07c30:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a07c34:     	add	x1, x1, #0x110
102a07c38:     	mov	w2, #0x3e8              ; =1000
102a07c3c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a07c40:     	ldr	x8, [sp, #0x438]
102a07c44:     	cbz	x8, 0x102a07c5c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb8c>
102a07c48:     	lsl	x9, x8, #6
102a07c4c:     	sub	x1, x9, x8, lsl #3
102a07c50:     	mov	x0, x22
102a07c54:     	mov	w2, #0x8                ; =8
102a07c58:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a07c5c:     	add	x0, sp, #0x420
102a07c60:     	bl	0x1025ba820 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a07c64:     	b	0x102a07168 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x98>
102a07c68:     	mov	x13, #0x0               ; =0
102a07c6c:     	lsr	x14, x14, #9
102a07c70:     	neg	x14, x14, lsl #3
102a07c74:     	b	0x102a07c88 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbb8>
102a07c78:     	add	x12, x12, #0x300
102a07c7c:     	sub	x13, x13, #0x8
102a07c80:     	cmp	x14, x13
102a07c84:     	b.eq	0x102a07da4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcd4>
102a07c88:     	ldr	w15, [x12, #0x8]
102a07c8c:     	cmp	w15, #0x2
102a07c90:     	b.eq	0x102a07cec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc1c>
102a07c94:     	ldr	w15, [x12, #0x68]
102a07c98:     	cmp	w15, #0x2
102a07c9c:     	b.eq	0x102a07d04 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc34>
102a07ca0:     	ldr	w15, [x12, #0xc8]
102a07ca4:     	cmp	w15, #0x2
102a07ca8:     	b.eq	0x102a07d1c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc4c>
102a07cac:     	ldr	w15, [x12, #0x128]
102a07cb0:     	cmp	w15, #0x2
102a07cb4:     	b.eq	0x102a07d34 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc64>
102a07cb8:     	ldr	w15, [x12, #0x188]
102a07cbc:     	cmp	w15, #0x2
102a07cc0:     	b.eq	0x102a07d4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc7c>
102a07cc4:     	ldr	w15, [x12, #0x1e8]
102a07cc8:     	cmp	w15, #0x2
102a07ccc:     	b.eq	0x102a07d64 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc94>
102a07cd0:     	ldr	w15, [x12, #0x248]
102a07cd4:     	cmp	w15, #0x2
102a07cd8:     	b.eq	0x102a07d7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcac>
102a07cdc:     	ldr	w15, [x12, #0x2a8]
102a07ce0:     	cmp	w15, #0x2
102a07ce4:     	b.ne	0x102a07c78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xba8>
102a07ce8:     	b	0x102a07d94 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcc4>
102a07cec:     	ldr	x15, [x12, #0x20]
102a07cf0:     	cmp	x3, x15
102a07cf4:     	csel	x3, x3, x15, hi
102a07cf8:     	ldr	w15, [x12, #0x68]
102a07cfc:     	cmp	w15, #0x2
102a07d00:     	b.ne	0x102a07ca0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbd0>
102a07d04:     	ldr	x15, [x12, #0x80]
102a07d08:     	cmp	x3, x15
102a07d0c:     	csel	x3, x3, x15, hi
102a07d10:     	ldr	w15, [x12, #0xc8]
102a07d14:     	cmp	w15, #0x2
102a07d18:     	b.ne	0x102a07cac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbdc>
102a07d1c:     	ldr	x15, [x12, #0xe0]
102a07d20:     	cmp	x3, x15
102a07d24:     	csel	x3, x3, x15, hi
102a07d28:     	ldr	w15, [x12, #0x128]
102a07d2c:     	cmp	w15, #0x2
102a07d30:     	b.ne	0x102a07cb8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbe8>
102a07d34:     	ldr	x15, [x12, #0x140]
102a07d38:     	cmp	x3, x15
102a07d3c:     	csel	x3, x3, x15, hi
102a07d40:     	ldr	w15, [x12, #0x188]
102a07d44:     	cmp	w15, #0x2
102a07d48:     	b.ne	0x102a07cc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbf4>
102a07d4c:     	ldr	x15, [x12, #0x1a0]
102a07d50:     	cmp	x3, x15
102a07d54:     	csel	x3, x3, x15, hi
102a07d58:     	ldr	w15, [x12, #0x1e8]
102a07d5c:     	cmp	w15, #0x2
102a07d60:     	b.ne	0x102a07cd0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc00>
102a07d64:     	ldr	x15, [x12, #0x200]
102a07d68:     	cmp	x3, x15
102a07d6c:     	csel	x3, x3, x15, hi
102a07d70:     	ldr	w15, [x12, #0x248]
102a07d74:     	cmp	w15, #0x2
102a07d78:     	b.ne	0x102a07cdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc0c>
102a07d7c:     	ldr	x15, [x12, #0x260]
102a07d80:     	cmp	x3, x15
102a07d84:     	csel	x3, x3, x15, hi
102a07d88:     	ldr	w15, [x12, #0x2a8]
102a07d8c:     	cmp	w15, #0x2
102a07d90:     	b.ne	0x102a07c78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xba8>
102a07d94:     	ldr	x15, [x12, #0x2c0]
102a07d98:     	cmp	x3, x15
102a07d9c:     	csel	x3, x3, x15, hi
102a07da0:     	b	0x102a07c78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xba8>
102a07da4:     	cbz	x11, 0x102a07718 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x648>
102a07da8:     	neg	x12, x13
102a07dac:     	add	x12, x12, x12, lsl #1
102a07db0:     	lsl	x12, x12, #5
102a07db4:     	add	x11, x11, x11, lsl #1
102a07db8:     	lsl	x11, x11, #5
102a07dbc:     	b	0x102a07dcc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcfc>
102a07dc0:     	add	x12, x12, #0x60
102a07dc4:     	subs	x11, x11, #0x60
102a07dc8:     	b.eq	0x102a07718 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x648>
102a07dcc:     	add	x13, x10, x12
102a07dd0:     	add	x13, x13, x9
102a07dd4:     	ldr	w14, [x13, #0x8]
102a07dd8:     	cmp	w14, #0x2
102a07ddc:     	b.ne	0x102a07dc0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcf0>
102a07de0:     	ldr	x13, [x13, #0x20]
102a07de4:     	cmp	x3, x13
102a07de8:     	csel	x3, x3, x13, hi
102a07dec:     	b	0x102a07dc0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcf0>
102a07df0:     	ldr	q0, [sp, #0x1110]
102a07df4:     	ldr	q1, [sp, #0x1120]
102a07df8:     	stur	q0, [x20, #0x8]
102a07dfc:     	stur	q1, [x20, #0x18]
102a07e00:     	ldr	q0, [sp, #0x1130]
102a07e04:     	stur	q0, [x20, #0x28]
102a07e08:     	mov	w8, #0x2                ; =2
102a07e0c:     	str	x8, [x20]
102a07e10:     	add	x0, sp, #0x478
102a07e14:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a07e18:     	b	0x102a07a28 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x958>
102a07e1c:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a07e20:     	add	x8, x8, #0x540
102a07e24:     	b	0x102a07e9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xdcc>
102a07e28:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a07e2c:     	add	x8, x8, #0x550
102a07e30:     	b	0x102a07e9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xdcc>
102a07e34:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07e38:     	add	x8, x8, #0x39d
102a07e3c:     	mov	w9, #0xf                ; =15
102a07e40:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07e44:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07e48:     	add	x8, x8, #0x3ac
102a07e4c:     	mov	w9, #0x16               ; =22
102a07e50:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07e54:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07e58:     	add	x8, x8, #0x3c2
102a07e5c:     	mov	w9, #0xc                ; =12
102a07e60:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07e64:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07e68:     	add	x8, x8, #0x3ce
102a07e6c:     	mov	w9, #0xe                ; =14
102a07e70:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07e74:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07e78:     	add	x8, x8, #0x3dc
102a07e7c:     	mov	w9, #0xe                ; =14
102a07e80:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07e84:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07e88:     	add	x8, x8, #0x3ea
102a07e8c:     	mov	w9, #0xf                ; =15
102a07e90:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07e94:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a07e98:     	add	x8, x8, #0x560
102a07e9c:     	mov	w9, #0x10               ; =16
102a07ea0:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07ea4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07ea8:     	add	x8, x8, #0x3f9
102a07eac:     	mov	w9, #0xf                ; =15
102a07eb0:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07eb4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07eb8:     	add	x8, x8, #0x408
102a07ebc:     	mov	w9, #0xc                ; =12
102a07ec0:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07ec4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07ec8:     	add	x8, x8, #0x414
102a07ecc:     	mov	w9, #0x15               ; =21
102a07ed0:     	b	0x102a07ee0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe10>
102a07ed4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a07ed8:     	add	x8, x8, #0x429
102a07edc:     	mov	w9, #0x13               ; =19
102a07ee0:     	stp	x8, x9, [x20, #0x10]
102a07ee4:     	str	x3, [x20, #0x28]
102a07ee8:     	adrp	x8, 0x10756c000 <_anon.f4dd5b1d90de3892b2d6ca5f465b553c.811+0xf33>
102a07eec:     	ldr	q0, [x8, #0xbc0]
102a07ef0:     	str	q0, [x20]
102a07ef4:     	b	0x102a075d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x504>
102a07ef8:     	mov	x21, x0
102a07efc:     	mov	x22, x1
102a07f00:     	cmp	x1, #0x15
102a07f04:     	b.hs	0x102a0816c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x109c>
102a07f08:     	sub	x3, x29, #0x61
102a07f0c:     	mov	x0, x21
102a07f10:     	mov	x1, x22
102a07f14:     	mov	w2, #0x1                ; =1
102a07f18:     	bl	0x1029085e0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYB1m_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
102a07f1c:     	mov	x24, #0x0               ; =0
102a07f20:     	mov	x23, #0x0               ; =0
102a07f24:     	sub	x25, x22, #0x1
102a07f28:     	mov	x8, x21
102a07f2c:     	b	0x102a07f40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe70>
102a07f30:     	add	x23, x23, #0x20
102a07f34:     	add	x24, x24, #0x1
102a07f38:     	cmp	x25, x24
102a07f3c:     	b.eq	0x102a0804c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf7c>
102a07f40:     	add	x9, x8, x23
102a07f44:     	ldr	x10, [x9, #0x28]
102a07f48:     	ldr	x11, [x9, #0x8]
102a07f4c:     	cmp	x10, x11
102a07f50:     	b.ne	0x102a07f30 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe60>
102a07f54:     	ldr	x10, [x9, #0x30]
102a07f58:     	ldr	x11, [x9, #0x10]
102a07f5c:     	cmp	x10, x11
102a07f60:     	b.ne	0x102a07f30 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe60>
102a07f64:     	add	x0, x9, #0x20
102a07f68:     	add	x1, x21, x23
102a07f6c:     	bl	0x1027cc294 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
102a07f70:     	mov	x8, x21
102a07f74:     	cbz	w0, 0x102a07f30 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe60>
102a07f78:     	add	x9, x8, x23
102a07f7c:     	ldrb	w10, [x9, #0x38]
102a07f80:     	ldrb	w11, [x9, #0x18]
102a07f84:     	cmp	w10, w11
102a07f88:     	b.ne	0x102a07f30 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe60>
102a07f8c:     	add	x8, x24, #0x2
102a07f90:     	add	x25, x24, #0x1
102a07f94:     	cmp	x8, x22
102a07f98:     	b.hs	0x102a0800c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf3c>
102a07f9c:     	add	x23, x9, #0x40
102a07fa0:     	sub	x8, x22, x24
102a07fa4:     	sub	x24, x8, #0x2
102a07fa8:     	add	x8, x21, x25, lsl #5
102a07fac:     	ldr	x9, [x23, #0x8]
102a07fb0:     	ldur	x10, [x8, #-0x18]
102a07fb4:     	cmp	x9, x10
102a07fb8:     	b.ne	0x102a07ff4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf24>
102a07fbc:     	ldr	x9, [x23, #0x10]
102a07fc0:     	ldur	x10, [x8, #-0x10]
102a07fc4:     	cmp	x9, x10
102a07fc8:     	b.ne	0x102a07ff4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf24>
102a07fcc:     	sub	x1, x8, #0x20
102a07fd0:     	mov	x0, x23
102a07fd4:     	mov	x26, x8
102a07fd8:     	bl	0x1027cc294 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
102a07fdc:     	mov	x8, x26
102a07fe0:     	cbz	w0, 0x102a07ff4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf24>
102a07fe4:     	ldrb	w9, [x23, #0x18]
102a07fe8:     	ldurb	w10, [x8, #-0x8]
102a07fec:     	cmp	w9, w10
102a07ff0:     	b.eq	0x102a08000 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf30>
102a07ff4:     	ldp	q0, q1, [x23]
102a07ff8:     	stp	q0, q1, [x8]
102a07ffc:     	add	x25, x25, #0x1
102a08000:     	add	x23, x23, #0x20
102a08004:     	subs	x24, x24, #0x1
102a08008:     	b.ne	0x102a07fa8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xed8>
102a0800c:     	cmp	x22, x25
102a08010:     	b.ls	0x102a0814c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x107c>
102a08014:     	lsl	x22, x22, #5
102a08018:     	cbz	x25, 0x102a08154 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1084>
102a0801c:     	lsl	x24, x25, #5
102a08020:     	mov	x0, x21
102a08024:     	mov	x1, x22
102a08028:     	mov	w2, #0x8                ; =8
102a0802c:     	mov	x3, x24
102a08030:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
102a08034:     	mov	x23, x0
102a08038:     	cbnz	x0, 0x102a077bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x6ec>
102a0803c:     	mov	w0, #0x8                ; =8
102a08040:     	mov	x1, x24
102a08044:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a08048:     	brk	#0x1
102a0804c:     	mov	x25, x22
102a08050:     	mov	x23, x8
102a08054:     	b	0x102a077bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x6ec>
102a08058:     	mov	w8, #0x7                ; =7
102a0805c:     	strb	w8, [x20, #0x8]
102a08060:     	str	x10, [x20, #0x10]
102a08064:     	mov	w8, #0x2                ; =2
102a08068:     	str	x8, [x20]
102a0806c:     	b	0x102a07a4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x97c>
102a08070:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a08074:     	add	x8, x8, #0x540
102a08078:     	mov	w9, #0x10               ; =16
102a0807c:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a08080:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a08084:     	add	x8, x8, #0x550
102a08088:     	mov	w9, #0x10               ; =16
102a0808c:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a08090:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a08094:     	add	x8, x8, #0x39d
102a08098:     	mov	w9, #0xf                ; =15
102a0809c:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a080a0:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a080a4:     	add	x8, x8, #0x3ac
102a080a8:     	mov	w9, #0x16               ; =22
102a080ac:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a080b0:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a080b4:     	add	x8, x8, #0x3c2
102a080b8:     	mov	w9, #0xc                ; =12
102a080bc:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a080c0:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a080c4:     	add	x8, x8, #0x3ce
102a080c8:     	mov	w9, #0xe                ; =14
102a080cc:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a080d0:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a080d4:     	add	x8, x8, #0x3dc
102a080d8:     	mov	w9, #0xe                ; =14
102a080dc:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a080e0:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a080e4:     	add	x8, x8, #0x3ea
102a080e8:     	mov	w9, #0xf                ; =15
102a080ec:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a080f0:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a080f4:     	add	x8, x8, #0x560
102a080f8:     	mov	w9, #0x10               ; =16
102a080fc:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a08100:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a08104:     	add	x8, x8, #0x3f9
102a08108:     	mov	w9, #0xf                ; =15
102a0810c:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a08110:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a08114:     	add	x8, x8, #0x408
102a08118:     	mov	w9, #0xc                ; =12
102a0811c:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a08120:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a08124:     	add	x8, x8, #0x414
102a08128:     	mov	w9, #0x15               ; =21
102a0812c:     	b	0x102a0813c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x106c>
102a08130:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a08134:     	add	x8, x8, #0x429
102a08138:     	mov	w9, #0x13               ; =19
102a0813c:     	mov	w10, #0x6               ; =6
102a08140:     	stp	x10, x8, [x20, #0x8]
102a08144:     	str	x9, [x20, #0x18]
102a08148:     	b	0x102a07e08 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd38>
102a0814c:     	mov	x23, x21
102a08150:     	b	0x102a077bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x6ec>
102a08154:     	mov	w23, #0x8               ; =8
102a08158:     	mov	x0, x21
102a0815c:     	mov	x1, x22
102a08160:     	mov	w2, #0x8                ; =8
102a08164:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a08168:     	b	0x102a077bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x6ec>
102a0816c:     	sub	x2, x29, #0x61
102a08170:     	mov	x0, x21
102a08174:     	mov	x1, x22
102a08178:     	bl	0x102dc92cc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EEB15_>
102a0817c:     	b	0x102a07f1c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe4c>
102a08180:     	mov	x20, x0
102a08184:     	mov	x0, x21
102a08188:     	mov	x1, x22
102a0818c:     	b	0x102a0819c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x10cc>
102a08190:     	mov	x20, x0
102a08194:     	lsl	x1, x22, #5
102a08198:     	mov	x0, x21
102a0819c:     	mov	w2, #0x8                ; =8
102a081a0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a081a4:     	b	0x102a08210 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1140>
102a081a8:     	mov	x20, x0
102a081ac:     	add	x0, x19, #0x1c8
102a081b0:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a081b4:     	add	x1, x1, #0x110
102a081b8:     	mov	w2, #0x3e8              ; =1000
102a081bc:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a081c0:     	b	0x102a081d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1104>
102a081c4:     	b	0x102a081d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1100>
102a081c8:     	mov	x20, x0
102a081cc:     	b	0x102a081f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1120>
102a081d0:     	mov	x20, x0
102a081d4:     	ldr	x8, [sp, #0x438]
102a081d8:     	cbz	x8, 0x102a081f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1120>
102a081dc:     	lsl	x9, x8, #6
102a081e0:     	sub	x1, x9, x8, lsl #3
102a081e4:     	mov	x0, x22
102a081e8:     	mov	w2, #0x8                ; =8
102a081ec:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a081f0:     	add	x0, sp, #0x420
102a081f4:     	bl	0x1025ba820 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a081f8:     	b	0x102a08200 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1130>
102a081fc:     	mov	x20, x0
102a08200:     	mov	x0, sp
102a08204:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a08208:     	b	0x102a08210 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1140>
102a0820c:     	mov	x20, x0
102a08210:     	mov	x0, x19
102a08214:     	bl	0x1029cf1e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEBM_>
102a08218:     	mov	x0, x20
102a0821c:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102a08220:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
