
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001029921d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>:
1029921d8:     	sub	sp, sp, #0xb0
1029921dc:     	stp	x28, x27, [sp, #0x50]
1029921e0:     	stp	x26, x25, [sp, #0x60]
1029921e4:     	stp	x24, x23, [sp, #0x70]
1029921e8:     	stp	x22, x21, [sp, #0x80]
1029921ec:     	stp	x20, x19, [sp, #0x90]
1029921f0:     	stp	x29, x30, [sp, #0xa0]
1029921f4:     	add	x29, sp, #0xa0
1029921f8:     	stp	x6, x3, [sp]
1029921fc:     	mov	x21, x2
102992200:     	mov	x27, x1
102992204:     	mov	x22, x0
102992208:     	cmp	x1, #0x21
10299220c:     	b.hs	0x102992228 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x50>
102992210:     	mov	x0, x22
102992214:     	mov	x1, x27
102992218:     	mov	x2, x21
10299221c:     	ldp	x4, x3, [sp]
102992220:     	bl	0x10290f3f4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_>
102992224:     	b	0x1029925ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3d4>
102992228:     	mov	x25, x5
10299222c:     	mov	x23, x4
102992230:     	mov	w28, #0xff              ; =255
102992234:     	mov	x24, x27
102992238:     	cbz	w23, 0x102992594 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3bc>
10299223c:     	lsr	x3, x24, #3
102992240:     	add	x1, x22, x3, lsl #8
102992244:     	mov	w8, #0x1c0              ; =448
102992248:     	madd	x2, x3, x8, x22
10299224c:     	cmp	x24, #0x40
102992250:     	b.hs	0x1029922dc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x104>
102992254:     	ldrb	w12, [x22]
102992258:     	ldrh	w13, [x22, #0x2]
10299225c:     	ldrb	w8, [x2]
102992260:     	ldrh	w9, [x2, #0x2]
102992264:     	cmp	w13, w9
102992268:     	cset	w14, lo
10299226c:     	subs	w10, w12, w8
102992270:     	bics	wzr, w28, w10
102992274:     	cset	w15, eq
102992278:     	ldrb	w10, [x1]
10299227c:     	ldrh	w11, [x1, #0x2]
102992280:     	cmp	w12, w8
102992284:     	csel	w14, w14, w15, eq
102992288:     	cmp	w13, w11
10299228c:     	cset	w13, lo
102992290:     	subs	w15, w12, w10
102992294:     	bics	wzr, w28, w15
102992298:     	cset	w15, eq
10299229c:     	cmp	w12, w10
1029922a0:     	csel	w12, w13, w15, eq
1029922a4:     	mov	x26, x22
1029922a8:     	cmp	w12, w14
1029922ac:     	b.ne	0x1029922e8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x110>
1029922b0:     	cmp	w11, w9
1029922b4:     	cset	w9, lo
1029922b8:     	subs	w11, w10, w8
1029922bc:     	cmn	w11, #0x1
1029922c0:     	cset	w11, eq
1029922c4:     	cmp	w10, w8
1029922c8:     	csel	w8, w9, w11, eq
1029922cc:     	eor	w8, w12, w8
1029922d0:     	cmp	w8, #0x0
1029922d4:     	csel	x26, x2, x1, ne
1029922d8:     	b	0x1029922e8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x110>
1029922dc:     	mov	x0, x22
1029922e0:     	bl	0x1029807ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_>
1029922e4:     	mov	x26, x0
1029922e8:     	sub	w23, w23, #0x1
1029922ec:     	sub	x8, x26, x22
1029922f0:     	lsr	x20, x8, #6
1029922f4:     	ldp	q0, q1, [x26]
1029922f8:     	stp	q0, q1, [sp, #0x10]
1029922fc:     	ldp	q0, q1, [x26, #0x20]
102992300:     	stp	q0, q1, [sp, #0x30]
102992304:     	add	x19, x21, x24, lsl #6
102992308:     	cbz	x25, 0x102992340 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x168>
10299230c:     	ldrb	w8, [x25]
102992310:     	ldrh	w9, [x25, #0x2]
102992314:     	ldrb	w10, [x26]
102992318:     	ldrh	w11, [x26, #0x2]
10299231c:     	cmp	w9, w11
102992320:     	cset	w9, lo
102992324:     	subs	w11, w8, w10
102992328:     	bics	wzr, w28, w11
10299232c:     	cset	w11, eq
102992330:     	cmp	w8, w10
102992334:     	csel	w8, w9, w11, eq
102992338:     	cmp	w8, #0x1
10299233c:     	b.ne	0x102992478 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2a0>
102992340:     	ldr	x8, [sp, #0x8]
102992344:     	cmp	x8, x24
102992348:     	b.lo	0x1029925d4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3fc>
10299234c:     	mov	x27, #0x0               ; =0
102992350:     	mov	x8, x22
102992354:     	mov	x9, x19
102992358:     	mov	x10, x20
10299235c:     	add	x11, x22, x20, lsl #6
102992360:     	cmp	x22, x11
102992364:     	b.hs	0x1029923c4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x1ec>
102992368:     	ldrb	w12, [x8]
10299236c:     	ldrh	w13, [x8, #0x2]
102992370:     	ldrb	w14, [x26]
102992374:     	ldrh	w15, [x26, #0x2]
102992378:     	cmp	w13, w15
10299237c:     	cset	w13, lo
102992380:     	subs	w15, w12, w14
102992384:     	bics	wzr, w28, w15
102992388:     	cset	w15, eq
10299238c:     	cmp	w12, w14
102992390:     	csel	w12, w13, w15, eq
102992394:     	sub	x9, x9, #0x40
102992398:     	cmp	w12, #0x0
10299239c:     	csel	x13, x21, x9, ne
1029923a0:     	add	x13, x13, x27, lsl #6
1029923a4:     	ldp	q0, q1, [x8]
1029923a8:     	ldp	q2, q3, [x8, #0x20]
1029923ac:     	stp	q2, q3, [x13, #0x20]
1029923b0:     	stp	q0, q1, [x13]
1029923b4:     	add	x27, x27, x12
1029923b8:     	add	x8, x8, #0x40
1029923bc:     	cmp	x8, x11
1029923c0:     	b.lo	0x102992368 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x190>
1029923c4:     	cmp	x10, x24
1029923c8:     	b.eq	0x1029923fc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x224>
1029923cc:     	sub	x9, x9, #0x40
1029923d0:     	add	x10, x9, x27, lsl #6
1029923d4:     	ldp	q0, q1, [x8]
1029923d8:     	stp	q0, q1, [x10]
1029923dc:     	ldp	q0, q1, [x8, #0x20]
1029923e0:     	stp	q0, q1, [x10, #0x20]
1029923e4:     	add	x8, x8, #0x40
1029923e8:     	mov	x10, x24
1029923ec:     	add	x11, x22, x24, lsl #6
1029923f0:     	cmp	x8, x11
1029923f4:     	b.lo	0x102992368 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x190>
1029923f8:     	b	0x1029923c4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x1ec>
1029923fc:     	lsl	x2, x27, #6
102992400:     	mov	x0, x22
102992404:     	mov	x1, x21
102992408:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
10299240c:     	add	x0, x22, x27, lsl #6
102992410:     	subs	x1, x24, x27
102992414:     	b.eq	0x102992448 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x270>
102992418:     	sub	x8, x21, #0x40
10299241c:     	add	x8, x8, x24, lsl #6
102992420:     	mov	x9, x1
102992424:     	mov	x10, x0
102992428:     	ldp	q0, q1, [x8]
10299242c:     	stp	q0, q1, [x10]
102992430:     	ldp	q0, q1, [x8, #0x20]
102992434:     	stp	q0, q1, [x10, #0x20]
102992438:     	add	x10, x10, #0x40
10299243c:     	sub	x8, x8, #0x40
102992440:     	subs	x9, x9, #0x1
102992444:     	b.ne	0x102992428 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x250>
102992448:     	cbz	x27, 0x102992478 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2a0>
10299244c:     	cmp	x24, x27
102992450:     	b.lo	0x1029925d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x400>
102992454:     	add	x5, sp, #0x10
102992458:     	mov	x2, x21
10299245c:     	ldp	x6, x3, [sp]
102992460:     	mov	x4, x23
102992464:     	bl	0x1029921d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>
102992468:     	mov	x24, x27
10299246c:     	cmp	x27, #0x21
102992470:     	b.hs	0x102992238 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x60>
102992474:     	b	0x102992210 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x38>
102992478:     	ldr	x8, [sp, #0x8]
10299247c:     	cmp	x8, x24
102992480:     	b.lo	0x1029925d4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3fc>
102992484:     	mov	x25, #0x0               ; =0
102992488:     	mov	x8, x22
10299248c:     	add	x9, x22, x20, lsl #6
102992490:     	cmp	x22, x9
102992494:     	b.hs	0x1029924f4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x31c>
102992498:     	ldrb	w10, [x8]
10299249c:     	ldrh	w11, [x8, #0x2]
1029924a0:     	ldrb	w12, [x26]
1029924a4:     	ldrh	w13, [x26, #0x2]
1029924a8:     	cmp	w13, w11
1029924ac:     	cset	w11, hs
1029924b0:     	subs	w13, w12, w10
1029924b4:     	bics	wzr, w28, w13
1029924b8:     	cset	w13, ne
1029924bc:     	cmp	w12, w10
1029924c0:     	csel	w10, w11, w13, eq
1029924c4:     	sub	x19, x19, #0x40
1029924c8:     	cmp	w10, #0x0
1029924cc:     	csel	x11, x21, x19, ne
1029924d0:     	add	x11, x11, x25, lsl #6
1029924d4:     	ldp	q0, q1, [x8]
1029924d8:     	ldp	q2, q3, [x8, #0x20]
1029924dc:     	stp	q2, q3, [x11, #0x20]
1029924e0:     	stp	q0, q1, [x11]
1029924e4:     	add	x25, x25, x10
1029924e8:     	add	x8, x8, #0x40
1029924ec:     	cmp	x8, x9
1029924f0:     	b.lo	0x102992498 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2c0>
1029924f4:     	cmp	x20, x24
1029924f8:     	b.eq	0x102992530 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x358>
1029924fc:     	sub	x19, x19, #0x40
102992500:     	add	x9, x21, x25, lsl #6
102992504:     	ldp	q0, q1, [x8]
102992508:     	ldp	q2, q3, [x8, #0x20]
10299250c:     	stp	q2, q3, [x9, #0x20]
102992510:     	stp	q0, q1, [x9]
102992514:     	add	x25, x25, #0x1
102992518:     	add	x8, x8, #0x40
10299251c:     	mov	x20, x24
102992520:     	add	x9, x22, x24, lsl #6
102992524:     	cmp	x8, x9
102992528:     	b.lo	0x102992498 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2c0>
10299252c:     	b	0x1029924f4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x31c>
102992530:     	lsl	x2, x25, #6
102992534:     	mov	x0, x22
102992538:     	mov	x1, x21
10299253c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102992540:     	subs	x27, x24, x25
102992544:     	b.eq	0x1029925cc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3f4>
102992548:     	add	x22, x22, x25, lsl #6
10299254c:     	sub	x8, x21, #0x40
102992550:     	add	x8, x8, x24, lsl #6
102992554:     	mov	x9, x27
102992558:     	mov	x10, x22
10299255c:     	ldp	q0, q1, [x8]
102992560:     	stp	q0, q1, [x10]
102992564:     	ldp	q0, q1, [x8, #0x20]
102992568:     	stp	q0, q1, [x10, #0x20]
10299256c:     	add	x10, x10, #0x40
102992570:     	sub	x8, x8, #0x40
102992574:     	subs	x9, x9, #0x1
102992578:     	b.ne	0x10299255c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x384>
10299257c:     	cmp	x24, x25
102992580:     	b.lo	0x1029925f0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x418>
102992584:     	mov	x25, #0x0               ; =0
102992588:     	cmp	x27, #0x21
10299258c:     	b.hs	0x102992234 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x5c>
102992590:     	b	0x102992210 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x38>
102992594:     	mov	x0, x22
102992598:     	mov	x1, x24
10299259c:     	mov	x2, x21
1029925a0:     	ldp	x5, x3, [sp]
1029925a4:     	mov	w4, #0x1                ; =1
1029925a8:     	bl	0x1029eb438 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_>
1029925ac:     	ldp	x29, x30, [sp, #0xa0]
1029925b0:     	ldp	x20, x19, [sp, #0x90]
1029925b4:     	ldp	x22, x21, [sp, #0x80]
1029925b8:     	ldp	x24, x23, [sp, #0x70]
1029925bc:     	ldp	x26, x25, [sp, #0x60]
1029925c0:     	ldp	x28, x27, [sp, #0x50]
1029925c4:     	add	sp, sp, #0xb0
1029925c8:     	ret
1029925cc:     	add	x22, x22, x24, lsl #6
1029925d0:     	b	0x102992210 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x38>
1029925d4:     	brk	#0x1
1029925d8:     	adrp	x0, 0x1076e0000 <_anon.5245c210884fd18e01c7938c721b2e18.935+0x96c>
1029925dc:     	add	x0, x0, #0xdbe
1029925e0:     	adrp	x2, 0x108050000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.71+0x18>
1029925e4:     	add	x2, x2, #0x200
1029925e8:     	mov	w1, #0x13               ; =19
1029925ec:     	bl	0x103a06884 <__RNvNtCsgDHHaSskbIF_4core9panicking9panic_fmt>
1029925f0:     	adrp	x3, 0x108050000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.71+0x18>
1029925f4:     	add	x3, x3, #0x218
1029925f8:     	mov	x0, x25
1029925fc:     	mov	x1, x24
102992600:     	mov	x2, x24
102992604:     	bl	0x103a068c8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
