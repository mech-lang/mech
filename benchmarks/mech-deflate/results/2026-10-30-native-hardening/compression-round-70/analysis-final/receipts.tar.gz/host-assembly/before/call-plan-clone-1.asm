
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d9648c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d9648c:     	sub	sp, sp, #0x1f0
102d96490:     	stp	x28, x27, [sp, #0x190]
102d96494:     	stp	x26, x25, [sp, #0x1a0]
102d96498:     	stp	x24, x23, [sp, #0x1b0]
102d9649c:     	stp	x22, x21, [sp, #0x1c0]
102d964a0:     	stp	x20, x19, [sp, #0x1d0]
102d964a4:     	stp	x29, x30, [sp, #0x1e0]
102d964a8:     	add	x29, sp, #0x1e0
102d964ac:     	mov	x20, x1
102d964b0:     	mov	x26, x0
102d964b4:     	add	x0, sp, #0xe8
102d964b8:     	add	x1, x1, #0x208
102d964bc:     	bl	0x102d97ca0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d964c0:     	add	x0, x20, #0x2a8
102d964c4:     	bl	0x102dd917c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d964c8:     	mov	x21, x0
102d964cc:     	mov	x24, x1
102d964d0:     	add	x0, x20, #0x2b8
102d964d4:     	bl	0x102dd917c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d964d8:     	mov	x19, x0
102d964dc:     	mov	x23, x1
102d964e0:     	add	x0, x20, #0x2c8
102d964e4:     	bl	0x102dd9548 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d964e8:     	str	x0, [sp, #0xe0]
102d964ec:     	stp	x19, x1, [sp, #0xd0]
102d964f0:     	add	x0, x20, #0x2d8
102d964f4:     	bl	0x102dd9548 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d964f8:     	stp	x0, x1, [sp, #0xc0]
102d964fc:     	mov	x19, #0x0               ; =0
102d96500:     	ldr	x22, [x20, #0x2f0]
102d96504:     	lsl	x28, x22, #6
102d96508:     	lsr	x8, x22, #58
102d9650c:     	cbnz	x8, 0x102d96570 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe4>
102d96510:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102d96514:     	cmp	x28, x8
102d96518:     	b.hi	0x102d96570 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe4>
102d9651c:     	stp	x23, x21, [sp, #0xb0]
102d96520:     	cbz	x28, 0x102d96580 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xf4>
102d96524:     	ldr	x27, [x20, #0x2e8]
102d96528:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d9652c:     	mov	w19, #0x8               ; =8
102d96530:     	mov	x0, x28
102d96534:     	mov	w1, #0x8                ; =8
102d96538:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d9653c:     	str	x0, [sp, #0xa0]
102d96540:     	cbz	x0, 0x102d96570 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe4>
102d96544:     	cbz	x22, 0x102d96558 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcc>
102d96548:     	ldr	x0, [sp, #0xa0]
102d9654c:     	mov	x1, x27
102d96550:     	mov	x2, x28
102d96554:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d96558:     	mov	x19, #0x0               ; =0
102d9655c:     	ldr	x23, [x20, #0x300]
102d96560:     	lsl	x27, x23, #6
102d96564:     	lsr	x8, x23, #58
102d96568:     	cbz	x8, 0x102d9659c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102d9656c:     	b	0x102d965e4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x158>
102d96570:     	mov	x0, x19
102d96574:     	mov	x1, x28
102d96578:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d9657c:     	b	0x102d9695c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102d96580:     	mov	w8, #0x8                ; =8
102d96584:     	str	x8, [sp, #0xa0]
102d96588:     	mov	x19, #0x0               ; =0
102d9658c:     	ldr	x23, [x20, #0x300]
102d96590:     	lsl	x27, x23, #6
102d96594:     	lsr	x8, x23, #58
102d96598:     	cbnz	x8, 0x102d965e4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x158>
102d9659c:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102d965a0:     	cmp	x27, x8
102d965a4:     	b.hi	0x102d965e4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x158>
102d965a8:     	cbz	x27, 0x102d965f4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x168>
102d965ac:     	ldr	x21, [x20, #0x2f8]
102d965b0:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d965b4:     	mov	w19, #0x8               ; =8
102d965b8:     	mov	x0, x27
102d965bc:     	mov	w1, #0x8                ; =8
102d965c0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d965c4:     	str	x0, [sp, #0x98]
102d965c8:     	cbz	x0, 0x102d965e4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x158>
102d965cc:     	cbz	x23, 0x102d965fc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x170>
102d965d0:     	ldr	x0, [sp, #0x98]
102d965d4:     	mov	x1, x21
102d965d8:     	mov	x2, x27
102d965dc:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d965e0:     	b	0x102d965fc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x170>
102d965e4:     	mov	x0, x19
102d965e8:     	mov	x1, x27
102d965ec:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d965f0:     	b	0x102d9695c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102d965f4:     	mov	w8, #0x8                ; =8
102d965f8:     	str	x8, [sp, #0x98]
102d965fc:     	ldr	x9, [x20, #0x310]
102d96600:     	add	x8, x9, x9, lsl #1
102d96604:     	lsl	x19, x8, #4
102d96608:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
102d9660c:     	movk	x8, #0x2aa, lsl #48
102d96610:     	cmp	x9, x8
102d96614:     	b.ls	0x102d96630 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a4>
102d96618:     	mov	x25, x24
102d9661c:     	mov	x21, #0x0               ; =0
102d96620:     	mov	x0, x21
102d96624:     	mov	x1, x19
102d96628:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d9662c:     	b	0x102d9695c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102d96630:     	str	x9, [sp, #0x90]
102d96634:     	cbz	x19, 0x102d966a8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x21c>
102d96638:     	str	x26, [sp, #0x80]
102d9663c:     	mov	x25, x24
102d96640:     	ldr	x24, [x20, #0x308]
102d96644:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d96648:     	mov	w21, #0x8               ; =8
102d9664c:     	mov	x0, x19
102d96650:     	mov	w1, #0x8                ; =8
102d96654:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d96658:     	str	x0, [sp, #0xa8]
102d9665c:     	cbz	x0, 0x102d96620 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
102d96660:     	ldr	x9, [sp, #0x90]
102d96664:     	cbz	x9, 0x102d9669c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x210>
102d96668:     	mov	x8, #0x0                ; =0
102d9666c:     	cmp	x19, x8
102d96670:     	b.eq	0x102d9669c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x210>
102d96674:     	add	x10, x24, x8
102d96678:     	ldr	x11, [sp, #0xa8]
102d9667c:     	add	x11, x11, x8
102d96680:     	ldp	q0, q1, [x10]
102d96684:     	ldr	q2, [x10, #0x20]
102d96688:     	stp	q1, q2, [x11, #0x10]
102d9668c:     	str	q0, [x11]
102d96690:     	add	x8, x8, #0x30
102d96694:     	subs	x9, x9, #0x1
102d96698:     	b.ne	0x102d9666c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1e0>
102d9669c:     	mov	x24, x25
102d966a0:     	ldr	x26, [sp, #0x80]
102d966a4:     	b	0x102d966b0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x224>
102d966a8:     	mov	w8, #0x8                ; =8
102d966ac:     	str	x8, [sp, #0xa8]
102d966b0:     	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
102d966b4:     	movk	x10, #0xaaa, lsl #48
102d966b8:     	ldr	x9, [x20, #0x320]
102d966bc:     	add	x8, x9, x9, lsl #1
102d966c0:     	lsl	x1, x8, #2
102d966c4:     	str	x9, [sp, #0x88]
102d966c8:     	cmp	x9, x10
102d966cc:     	b.ls	0x102d966e0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x254>
102d966d0:     	mov	x21, #0x0               ; =0
102d966d4:     	mov	x0, x21
102d966d8:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d966dc:     	b	0x102d9695c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102d966e0:     	str	x1, [sp, #0x70]
102d966e4:     	cbz	x1, 0x102d96730 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2a4>
102d966e8:     	mov	x25, x1
102d966ec:     	ldr	x8, [x20, #0x318]
102d966f0:     	str	x8, [sp, #0x80]
102d966f4:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d966f8:     	mov	w21, #0x4               ; =4
102d966fc:     	mov	x0, x25
102d96700:     	mov	w1, #0x4                ; =4
102d96704:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d96708:     	str	x0, [sp, #0x78]
102d9670c:     	mov	x1, x25
102d96710:     	cbz	x0, 0x102d966d4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x248>
102d96714:     	ldr	x8, [sp, #0x88]
102d96718:     	mov	x21, x26
102d9671c:     	cbz	x8, 0x102d9673c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b0>
102d96720:     	ldp	x0, x1, [sp, #0x78]
102d96724:     	ldr	x2, [sp, #0x70]
102d96728:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d9672c:     	b	0x102d9673c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b0>
102d96730:     	mov	w8, #0x4                ; =4
102d96734:     	str	x8, [sp, #0x78]
102d96738:     	mov	x21, x26
102d9673c:     	ldr	x26, [x20, #0x330]
102d96740:     	add	x8, x26, x26, lsl #1
102d96744:     	lsl	x25, x8, #2
102d96748:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
102d9674c:     	movk	x8, #0xaaa, lsl #48
102d96750:     	cmp	x26, x8
102d96754:     	b.ls	0x102d9676c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2e0>
102d96758:     	mov	x21, #0x0               ; =0
102d9675c:     	mov	x0, x21
102d96760:     	mov	x1, x25
102d96764:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d96768:     	b	0x102d9695c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102d9676c:     	str	x21, [sp, #0x80]
102d96770:     	str	x25, [sp, #0x58]
102d96774:     	cbz	x25, 0x102d967b0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x324>
102d96778:     	ldr	x8, [x20, #0x328]
102d9677c:     	str	x8, [sp, #0x68]
102d96780:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d96784:     	mov	w21, #0x4               ; =4
102d96788:     	mov	x0, x25
102d9678c:     	mov	w1, #0x4                ; =4
102d96790:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d96794:     	str	x0, [sp, #0x60]
102d96798:     	cbz	x0, 0x102d9675c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2d0>
102d9679c:     	cbz	x26, 0x102d967b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x32c>
102d967a0:     	ldp	x0, x1, [sp, #0x60]
102d967a4:     	mov	x2, x25
102d967a8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d967ac:     	b	0x102d967b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x32c>
102d967b0:     	mov	w8, #0x4                ; =4
102d967b4:     	str	x8, [sp, #0x60]
102d967b8:     	add	x0, x20, #0x338
102d967bc:     	bl	0x102dd9084 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d967c0:     	str	x0, [sp, #0x48]
102d967c4:     	str	x1, [sp, #0x68]
102d967c8:     	mov	x9, #0x0                ; =0
102d967cc:     	ldr	x8, [x20, #0x350]
102d967d0:     	lsl	x25, x8, #2
102d967d4:     	str	x8, [sp, #0x50]
102d967d8:     	lsr	x8, x8, #62
102d967dc:     	cbnz	x8, 0x102d96830 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3a4>
102d967e0:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
102d967e4:     	cmp	x25, x8
102d967e8:     	b.hi	0x102d96830 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3a4>
102d967ec:     	str	x25, [sp, #0x30]
102d967f0:     	cbz	x25, 0x102d96840 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3b4>
102d967f4:     	ldr	x21, [x20, #0x348]
102d967f8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d967fc:     	mov	x0, x25
102d96800:     	mov	w1, #0x2                ; =2
102d96804:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d96808:     	mov	w9, #0x2                ; =2
102d9680c:     	str	x0, [sp, #0x40]
102d96810:     	cbz	x0, 0x102d96830 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3a4>
102d96814:     	ldr	x8, [sp, #0x50]
102d96818:     	cbz	x8, 0x102d96848 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3bc>
102d9681c:     	ldr	x0, [sp, #0x40]
102d96820:     	mov	x1, x21
102d96824:     	ldr	x2, [sp, #0x30]
102d96828:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d9682c:     	b	0x102d96848 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3bc>
102d96830:     	mov	x0, x9
102d96834:     	mov	x1, x25
102d96838:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d9683c:     	b	0x102d9695c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102d96840:     	mov	w8, #0x2                ; =2
102d96844:     	str	x8, [sp, #0x40]
102d96848:     	ldr	x9, [x20, #0x360]
102d9684c:     	add	x8, x9, x9, lsl #1
102d96850:     	lsl	x25, x8, #2
102d96854:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
102d96858:     	movk	x8, #0xaaa, lsl #48
102d9685c:     	str	x9, [sp, #0x28]
102d96860:     	cmp	x9, x8
102d96864:     	str	x25, [sp, #0x38]
102d96868:     	b.ls	0x102d96880 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3f4>
102d9686c:     	mov	x21, #0x0               ; =0
102d96870:     	mov	x0, x21
102d96874:     	ldr	x1, [sp, #0x38]
102d96878:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d9687c:     	b	0x102d9695c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102d96880:     	cbz	x25, 0x102d968c0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x434>
102d96884:     	ldr	x8, [x20, #0x358]
102d96888:     	str	x8, [sp, #0x18]
102d9688c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d96890:     	mov	w21, #0x4               ; =4
102d96894:     	mov	x0, x25
102d96898:     	mov	w1, #0x4                ; =4
102d9689c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d968a0:     	str	x0, [sp, #0x20]
102d968a4:     	cbz	x0, 0x102d96870 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3e4>
102d968a8:     	ldr	x25, [sp, #0x28]
102d968ac:     	cbz	x25, 0x102d968cc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x440>
102d968b0:     	ldp	x1, x0, [sp, #0x18]
102d968b4:     	ldr	x2, [sp, #0x38]
102d968b8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d968bc:     	b	0x102d968cc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x440>
102d968c0:     	mov	w8, #0x4                ; =4
102d968c4:     	str	x8, [sp, #0x20]
102d968c8:     	ldr	x25, [sp, #0x28]
102d968cc:     	mov	x9, #0x0                ; =0
102d968d0:     	ldr	x21, [x20, #0x370]
102d968d4:     	lsl	x2, x21, #2
102d968d8:     	lsr	x8, x21, #62
102d968dc:     	cbnz	x8, 0x102d96950 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4c4>
102d968e0:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
102d968e4:     	cmp	x2, x8
102d968e8:     	b.hi	0x102d96950 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4c4>
102d968ec:     	ldrh	w9, [x20, #0x3e4]
102d968f0:     	ldr	w10, [x20, #0x3e0]
102d968f4:     	cbz	x2, 0x102d96960 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d4>
102d968f8:     	stp	x10, x9, [sp, #0x8]
102d968fc:     	ldr	x8, [x20, #0x368]
102d96900:     	str	x8, [sp]
102d96904:     	str	x21, [sp, #0x18]
102d96908:     	mov	x21, x2
102d9690c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d96910:     	mov	x0, x21
102d96914:     	mov	w1, #0x2                ; =2
102d96918:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d9691c:     	mov	w9, #0x2                ; =2
102d96920:     	mov	x2, x21
102d96924:     	ldr	x21, [sp, #0x18]
102d96928:     	cbz	x0, 0x102d96950 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4c4>
102d9692c:     	mov	x28, x25
102d96930:     	ldr	x25, [sp, #0x80]
102d96934:     	ldr	x27, [sp, #0x68]
102d96938:     	str	x0, [sp, #0x28]
102d9693c:     	cbz	x21, 0x102d96948 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4bc>
102d96940:     	ldr	x1, [sp]
102d96944:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d96948:     	ldp	x10, x9, [sp, #0x8]
102d9694c:     	b	0x102d96974 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e8>
102d96950:     	mov	x0, x9
102d96954:     	mov	x1, x2
102d96958:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d9695c:     	brk	#0x1
102d96960:     	mov	x28, x25
102d96964:     	mov	w8, #0x2                ; =2
102d96968:     	str	x8, [sp, #0x28]
102d9696c:     	ldr	x25, [sp, #0x80]
102d96970:     	ldr	x27, [sp, #0x68]
102d96974:     	add	x8, sp, #0x49
102d96978:     	ldur	q0, [x8, #0xff]
102d9697c:     	add	x8, sp, #0x59
102d96980:     	ldur	q1, [x8, #0xff]
102d96984:     	orr	x8, x10, x9, lsl #32
102d96988:     	add	x19, x20, #0x378
102d9698c:     	add	x9, x25, #0x208
102d96990:     	stp	q0, q1, [x9, #0x60]
102d96994:     	add	x10, sp, #0x69
102d96998:     	ldur	q0, [x10, #0xff]
102d9699c:     	add	x10, sp, #0x79
102d969a0:     	ldur	q1, [x10, #0xff]
102d969a4:     	stp	q0, q1, [x9, #0x80]
102d969a8:     	add	x10, sp, #0x9
102d969ac:     	ldur	q0, [x10, #0xff]
102d969b0:     	add	x10, sp, #0x19
102d969b4:     	ldur	q1, [x10, #0xff]
102d969b8:     	stp	q0, q1, [x9, #0x20]
102d969bc:     	add	x10, sp, #0x29
102d969c0:     	ldur	q0, [x10, #0xff]
102d969c4:     	add	x10, sp, #0x39
102d969c8:     	ldur	q1, [x10, #0xff]
102d969cc:     	stp	q0, q1, [x9, #0x40]
102d969d0:     	ldur	q0, [sp, #0xe8]
102d969d4:     	ldur	q1, [sp, #0xf8]
102d969d8:     	stp	q0, q1, [x9]
102d969dc:     	ldr	x9, [sp, #0xb8]
102d969e0:     	str	x9, [x25, #0x2a8]
102d969e4:     	str	x24, [x25, #0x2b0]
102d969e8:     	ldr	x9, [sp, #0xd0]
102d969ec:     	str	x9, [x25, #0x2b8]
102d969f0:     	ldr	x9, [sp, #0xb0]
102d969f4:     	str	x9, [x25, #0x2c0]
102d969f8:     	ldp	x9, x10, [sp, #0xd8]
102d969fc:     	str	x10, [x25, #0x2c8]
102d96a00:     	str	x9, [x25, #0x2d0]
102d96a04:     	ldp	x10, x9, [sp, #0xc0]
102d96a08:     	str	x10, [x25, #0x2d8]
102d96a0c:     	str	x9, [x25, #0x2e0]
102d96a10:     	ldp	x9, x10, [sp, #0x98]
102d96a14:     	str	x10, [x25, #0x2e8]
102d96a18:     	str	x22, [x25, #0x2f0]
102d96a1c:     	str	x9, [x25, #0x2f8]
102d96a20:     	str	x23, [x25, #0x300]
102d96a24:     	ldr	x9, [sp, #0xa8]
102d96a28:     	str	x9, [x25, #0x308]
102d96a2c:     	ldr	x9, [sp, #0x90]
102d96a30:     	str	x9, [x25, #0x310]
102d96a34:     	ldr	x9, [sp, #0x78]
102d96a38:     	str	x9, [x25, #0x318]
102d96a3c:     	ldr	x9, [sp, #0x88]
102d96a40:     	str	x9, [x25, #0x320]
102d96a44:     	ldr	x9, [sp, #0x60]
102d96a48:     	str	x9, [x25, #0x328]
102d96a4c:     	str	x26, [x25, #0x330]
102d96a50:     	ldp	x9, x10, [sp, #0x40]
102d96a54:     	str	x10, [x25, #0x338]
102d96a58:     	str	x27, [x25, #0x340]
102d96a5c:     	str	x9, [x25, #0x348]
102d96a60:     	ldr	x9, [sp, #0x50]
102d96a64:     	str	x9, [x25, #0x350]
102d96a68:     	ldr	x9, [sp, #0x20]
102d96a6c:     	str	x9, [x25, #0x358]
102d96a70:     	str	x28, [x25, #0x360]
102d96a74:     	lsr	x9, x8, #32
102d96a78:     	strh	w9, [x25, #0x3e4]
102d96a7c:     	str	w8, [x25, #0x3e0]
102d96a80:     	mov	x0, x25
102d96a84:     	mov	x1, x20
102d96a88:     	mov	w2, #0x208              ; =520
102d96a8c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d96a90:     	add	x8, x25, #0x378
102d96a94:     	ldp	q0, q1, [x19, #0x40]
102d96a98:     	stp	q0, q1, [x8, #0x40]
102d96a9c:     	ldr	x9, [x20, #0x3d8]
102d96aa0:     	str	x9, [x25, #0x3d8]
102d96aa4:     	ldp	q0, q1, [x19]
102d96aa8:     	stp	q0, q1, [x8]
102d96aac:     	ldp	q1, q0, [x19, #0x20]
102d96ab0:     	stp	q1, q0, [x8, #0x20]
102d96ab4:     	ldr	x8, [sp, #0x28]
102d96ab8:     	str	x8, [x25, #0x368]
102d96abc:     	str	x21, [x25, #0x370]
102d96ac0:     	ldp	x29, x30, [sp, #0x1e0]
102d96ac4:     	ldp	x20, x19, [sp, #0x1d0]
102d96ac8:     	ldp	x22, x21, [sp, #0x1c0]
102d96acc:     	ldp	x24, x23, [sp, #0x1b0]
102d96ad0:     	ldp	x26, x25, [sp, #0x1a0]
102d96ad4:     	ldp	x28, x27, [sp, #0x190]
102d96ad8:     	add	sp, sp, #0x1f0
102d96adc:     	ret
102d96ae0:     	mov	x20, x0
102d96ae4:     	ldr	x21, [sp, #0x90]
102d96ae8:     	b	0x102d96b78 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6ec>
102d96aec:     	mov	x20, x0
102d96af0:     	ldp	x19, x22, [sp, #0xd0]
102d96af4:     	b	0x102d96c20 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x794>
102d96af8:     	mov	x20, x0
102d96afc:     	b	0x102d96c2c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7a0>
102d96b00:     	mov	x20, x0
102d96b04:     	b	0x102d96c38 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7ac>
102d96b08:     	mov	x20, x0
102d96b0c:     	b	0x102d96c44 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7b8>
102d96b10:     	mov	x20, x0
102d96b14:     	ldr	x21, [sp, #0x90]
102d96b18:     	cbz	x25, 0x102d96b38 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6ac>
102d96b1c:     	ldr	x0, [sp, #0x20]
102d96b20:     	ldr	x1, [sp, #0x38]
102d96b24:     	mov	w2, #0x4                ; =4
102d96b28:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96b2c:     	b	0x102d96b38 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6ac>
102d96b30:     	mov	x20, x0
102d96b34:     	ldr	x21, [sp, #0x90]
102d96b38:     	ldr	x8, [sp, #0x50]
102d96b3c:     	cbz	x8, 0x102d96b5c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d0>
102d96b40:     	ldr	x0, [sp, #0x40]
102d96b44:     	ldr	x1, [sp, #0x30]
102d96b48:     	mov	w2, #0x2                ; =2
102d96b4c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96b50:     	b	0x102d96b5c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d0>
102d96b54:     	mov	x20, x0
102d96b58:     	ldr	x21, [sp, #0x90]
102d96b5c:     	ldr	x8, [sp, #0x68]
102d96b60:     	cbz	x8, 0x102d96b78 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6ec>
102d96b64:     	add	x8, x8, x8, lsl #1
102d96b68:     	lsl	x1, x8, #5
102d96b6c:     	ldr	x0, [sp, #0x48]
102d96b70:     	mov	w2, #0x8                ; =8
102d96b74:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96b78:     	ldr	x1, [sp, #0x58]
102d96b7c:     	cbz	x26, 0x102d96b98 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x70c>
102d96b80:     	ldr	x0, [sp, #0x60]
102d96b84:     	mov	w2, #0x4                ; =4
102d96b88:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96b8c:     	b	0x102d96b98 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x70c>
102d96b90:     	mov	x20, x0
102d96b94:     	ldr	x21, [sp, #0x90]
102d96b98:     	ldr	x8, [sp, #0x88]
102d96b9c:     	cbz	x8, 0x102d96bb8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x72c>
102d96ba0:     	ldp	x1, x0, [sp, #0x70]
102d96ba4:     	mov	w2, #0x4                ; =4
102d96ba8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96bac:     	b	0x102d96bb8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x72c>
102d96bb0:     	mov	x20, x0
102d96bb4:     	ldr	x21, [sp, #0x90]
102d96bb8:     	cbz	x21, 0x102d96bd8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74c>
102d96bbc:     	ldr	x0, [sp, #0xa8]
102d96bc0:     	mov	x1, x19
102d96bc4:     	mov	w2, #0x8                ; =8
102d96bc8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96bcc:     	b	0x102d96bd8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74c>
102d96bd0:     	mov	x20, x0
102d96bd4:     	mov	x24, x25
102d96bd8:     	cbz	x23, 0x102d96bf4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x768>
102d96bdc:     	ldr	x0, [sp, #0x98]
102d96be0:     	mov	x1, x27
102d96be4:     	mov	w2, #0x8                ; =8
102d96be8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96bec:     	b	0x102d96bf4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x768>
102d96bf0:     	mov	x20, x0
102d96bf4:     	ldp	x23, x21, [sp, #0xb0]
102d96bf8:     	cbz	x22, 0x102d96c14 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x788>
102d96bfc:     	ldr	x0, [sp, #0xa0]
102d96c00:     	mov	x1, x28
102d96c04:     	mov	w2, #0x8                ; =8
102d96c08:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d96c0c:     	b	0x102d96c14 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x788>
102d96c10:     	mov	x20, x0
102d96c14:     	ldp	x19, x22, [sp, #0xd0]
102d96c18:     	ldp	x0, x1, [sp, #0xc0]
102d96c1c:     	bl	0x102d7f710 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEEB1m_>
102d96c20:     	ldr	x0, [sp, #0xe0]
102d96c24:     	mov	x1, x22
102d96c28:     	bl	0x102d7f710 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEEB1m_>
102d96c2c:     	mov	x0, x19
102d96c30:     	mov	x1, x23
102d96c34:     	bl	0x102d7f60c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEEB1m_>
102d96c38:     	mov	x0, x21
102d96c3c:     	mov	x1, x24
102d96c40:     	bl	0x102d7f60c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEEB1m_>
102d96c44:     	add	x0, sp, #0xe8
102d96c48:     	bl	0x102d82404 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization9BoundCallEBM_>
102d96c4c:     	mov	x0, x20
102d96c50:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102d96c54:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
