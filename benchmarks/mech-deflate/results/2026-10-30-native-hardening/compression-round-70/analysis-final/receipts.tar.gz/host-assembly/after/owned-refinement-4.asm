
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001025eba98 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_>:
1025eba98:     	sub	sp, sp, #0x70
1025eba9c:     	stp	x24, x23, [sp, #0x30]
1025ebaa0:     	stp	x22, x21, [sp, #0x40]
1025ebaa4:     	stp	x20, x19, [sp, #0x50]
1025ebaa8:     	stp	x29, x30, [sp, #0x60]
1025ebaac:     	add	x29, sp, #0x60
1025ebab0:     	mov	x19, x8
1025ebab4:     	mov	x21, #0x0               ; =0
1025ebab8:     	ldp	x8, x9, [x0, #0x18]
1025ebabc:     	subs	x8, x9, x8
1025ebac0:     	csel	x22, xzr, x8, lo
1025ebac4:     	lsl	x8, x22, #6
1025ebac8:     	sub	x20, x8, x22, lsl #3
1025ebacc:     	mov	x8, #0x9249             ; =37449
1025ebad0:     	movk	x8, #0x4924, lsl #16
1025ebad4:     	movk	x8, #0x2492, lsl #32
1025ebad8:     	movk	x8, #0x249, lsl #48
1025ebadc:     	cmp	x22, x8
1025ebae0:     	b.ls	0x1025ebaf0 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x58>
1025ebae4:     	mov	x0, x21
1025ebae8:     	mov	x1, x20
1025ebaec:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1025ebaf0:     	cbz	x20, 0x1025ebb1c <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x84>
1025ebaf4:     	mov	x23, x0
1025ebaf8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1025ebafc:     	mov	w21, #0x8               ; =8
1025ebb00:     	mov	x0, x20
1025ebb04:     	mov	w1, #0x8                ; =8
1025ebb08:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1025ebb0c:     	mov	x8, x0
1025ebb10:     	cbz	x0, 0x1025ebae4 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x4c>
1025ebb14:     	mov	x0, x23
1025ebb18:     	b	0x1025ebb24 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x8c>
1025ebb1c:     	mov	x22, #0x0               ; =0
1025ebb20:     	mov	w8, #0x8                ; =8
1025ebb24:     	stp	x22, x8, [sp]
1025ebb28:     	mov	x9, sp
1025ebb2c:     	add	x9, x9, #0x10
1025ebb30:     	stp	xzr, x9, [sp, #0x10]
1025ebb34:     	stp	xzr, x8, [sp, #0x20]
1025ebb38:     	add	x1, sp, #0x18
1025ebb3c:     	bl	0x10271b8e4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_>
1025ebb40:     	ldr	q0, [sp]
1025ebb44:     	str	q0, [x19]
1025ebb48:     	ldr	x8, [sp, #0x10]
1025ebb4c:     	str	x8, [x19, #0x10]
1025ebb50:     	ldp	x29, x30, [sp, #0x60]
1025ebb54:     	ldp	x20, x19, [sp, #0x50]
1025ebb58:     	ldp	x22, x21, [sp, #0x40]
1025ebb5c:     	ldp	x24, x23, [sp, #0x30]
1025ebb60:     	add	sp, sp, #0x70
1025ebb64:     	ret
1025ebb68:     	mov	x19, x0
1025ebb6c:     	ldr	x8, [sp]
1025ebb70:     	cbz	x8, 0x1025ebb88 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0xf0>
1025ebb74:     	ldr	x0, [sp, #0x8]
1025ebb78:     	lsl	x9, x8, #6
1025ebb7c:     	sub	x1, x9, x8, lsl #3
1025ebb80:     	mov	w2, #0x8                ; =8
1025ebb84:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1025ebb88:     	mov	x0, x19
1025ebb8c:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
