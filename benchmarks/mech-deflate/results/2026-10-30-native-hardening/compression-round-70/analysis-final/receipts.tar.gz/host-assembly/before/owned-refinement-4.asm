
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027d607c <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_>:
1027d607c:     	sub	sp, sp, #0x70
1027d6080:     	stp	x24, x23, [sp, #0x30]
1027d6084:     	stp	x22, x21, [sp, #0x40]
1027d6088:     	stp	x20, x19, [sp, #0x50]
1027d608c:     	stp	x29, x30, [sp, #0x60]
1027d6090:     	add	x29, sp, #0x60
1027d6094:     	mov	x19, x8
1027d6098:     	mov	x21, #0x0               ; =0
1027d609c:     	ldp	x8, x9, [x0, #0x18]
1027d60a0:     	subs	x8, x9, x8
1027d60a4:     	csel	x22, xzr, x8, lo
1027d60a8:     	lsl	x8, x22, #6
1027d60ac:     	sub	x20, x8, x22, lsl #3
1027d60b0:     	mov	x8, #0x9249             ; =37449
1027d60b4:     	movk	x8, #0x4924, lsl #16
1027d60b8:     	movk	x8, #0x2492, lsl #32
1027d60bc:     	movk	x8, #0x249, lsl #48
1027d60c0:     	cmp	x22, x8
1027d60c4:     	b.ls	0x1027d60d4 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x58>
1027d60c8:     	mov	x0, x21
1027d60cc:     	mov	x1, x20
1027d60d0:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027d60d4:     	cbz	x20, 0x1027d6100 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x84>
1027d60d8:     	mov	x23, x0
1027d60dc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027d60e0:     	mov	w21, #0x8               ; =8
1027d60e4:     	mov	x0, x20
1027d60e8:     	mov	w1, #0x8                ; =8
1027d60ec:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027d60f0:     	mov	x8, x0
1027d60f4:     	cbz	x0, 0x1027d60c8 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x4c>
1027d60f8:     	mov	x0, x23
1027d60fc:     	b	0x1027d6108 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0x8c>
1027d6100:     	mov	x22, #0x0               ; =0
1027d6104:     	mov	w8, #0x8                ; =8
1027d6108:     	stp	x22, x8, [sp]
1027d610c:     	mov	x9, sp
1027d6110:     	add	x9, x9, #0x10
1027d6114:     	stp	xzr, x9, [sp, #0x10]
1027d6118:     	stp	xzr, x8, [sp, #0x20]
1027d611c:     	add	x1, sp, #0x18
1027d6120:     	bl	0x102727ab4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_>
1027d6124:     	ldr	q0, [sp]
1027d6128:     	str	q0, [x19]
1027d612c:     	ldr	x8, [sp, #0x10]
1027d6130:     	str	x8, [x19, #0x10]
1027d6134:     	ldp	x29, x30, [sp, #0x60]
1027d6138:     	ldp	x20, x19, [sp, #0x50]
1027d613c:     	ldp	x22, x21, [sp, #0x40]
1027d6140:     	ldp	x24, x23, [sp, #0x30]
1027d6144:     	add	sp, sp, #0x70
1027d6148:     	ret
1027d614c:     	mov	x19, x0
1027d6150:     	ldr	x8, [sp]
1027d6154:     	cbz	x8, 0x1027d616c <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_+0xf0>
1027d6158:     	ldr	x0, [sp, #0x8]
1027d615c:     	lsl	x9, x8, #6
1027d6160:     	sub	x1, x9, x8, lsl #3
1027d6164:     	mov	w2, #0x8                ; =8
1027d6168:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027d616c:     	mov	x0, x19
1027d6170:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
