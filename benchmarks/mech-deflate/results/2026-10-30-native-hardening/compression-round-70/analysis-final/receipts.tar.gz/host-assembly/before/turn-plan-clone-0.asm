
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001029c4060 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
1029c4060:     	stp	d9, d8, [sp, #-0x70]!
1029c4064:     	stp	x28, x27, [sp, #0x10]
1029c4068:     	stp	x26, x25, [sp, #0x20]
1029c406c:     	stp	x24, x23, [sp, #0x30]
1029c4070:     	stp	x22, x21, [sp, #0x40]
1029c4074:     	stp	x20, x19, [sp, #0x50]
1029c4078:     	stp	x29, x30, [sp, #0x60]
1029c407c:     	add	x29, sp, #0x60
1029c4080:     	sub	sp, sp, #0x970
1029c4084:     	str	xzr, [sp]
1029c4088:     	mov	x20, x1
1029c408c:     	mov	x23, x0
1029c4090:     	ldr	w19, [x1, #0x678]
1029c4094:     	ldr	x8, [x1, #0x80]
1029c4098:     	cbz	x8, 0x1029c40ec <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8c>
1029c409c:     	ldr	x1, [x20, #0x70]
1029c40a0:     	cbz	x1, 0x1029c4a70 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa10>
1029c40a4:     	ldr	x2, [x20, #0x78]
1029c40a8:     	add	x0, sp, #0x8a0
1029c40ac:     	bl	0x10258d774 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model16RegionAccessPlanNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1029c40b0:     	ldr	x8, [x20, #0x98]
1029c40b4:     	cbz	x8, 0x1029c40fc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9c>
1029c40b8:     	ldr	x1, [x20, #0x88]
1029c40bc:     	cbz	x1, 0x1029c4a7c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa1c>
1029c40c0:     	ldr	x2, [x20, #0x90]
1029c40c4:     	add	x0, sp, #0x5f8
1029c40c8:     	bl	0x10258d40c <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB2d_18operation_contract10validation13PortDirectiontENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1029c40cc:     	ldr	x8, [x20, #0xb0]
1029c40d0:     	cbz	x8, 0x1029c410c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xac>
1029c40d4:     	ldr	x1, [x20, #0xa0]
1029c40d8:     	cbz	x1, 0x1029c4a8c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa2c>
1029c40dc:     	ldr	x2, [x20, #0xa8]
1029c40e0:     	add	x0, sp, #0x210
1029c40e4:     	bl	0x10258dab8 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1029c40e8:     	b	0x1029c4114 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xb4>
1029c40ec:     	str	xzr, [sp, #0x8a0]
1029c40f0:     	str	xzr, [sp, #0x8b0]
1029c40f4:     	ldr	x8, [x20, #0x98]
1029c40f8:     	cbnz	x8, 0x1029c40b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x58>
1029c40fc:     	str	xzr, [sp, #0x5f8]
1029c4100:     	str	xzr, [sp, #0x608]
1029c4104:     	ldr	x8, [x20, #0xb0]
1029c4108:     	cbnz	x8, 0x1029c40d4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74>
1029c410c:     	str	xzr, [sp, #0x210]
1029c4110:     	str	xzr, [sp, #0x220]
1029c4114:     	add	x8, x20, #0xb8
1029c4118:     	ldr	q0, [x8, #0x50]
1029c411c:     	add	x8, sp, #0xf0
1029c4120:     	add	x8, x8, #0xb8
1029c4124:     	str	q0, [x8, #0x50]
1029c4128:     	add	x12, sp, #0x5f8
1029c412c:     	add	x8, sp, #0xf0
1029c4130:     	ldur	q0, [x20, #0xe8]
1029c4134:     	stur	q0, [x8, #0xe8]
1029c4138:     	ldur	q0, [x20, #0xf8]
1029c413c:     	stur	q0, [x8, #0xf8]
1029c4140:     	ldr	x9, [x20, #0x118]
1029c4144:     	ldur	q0, [x20, #0xb8]
1029c4148:     	stur	q0, [x8, #0xb8]
1029c414c:     	ldur	q0, [x20, #0xc8]
1029c4150:     	stur	q0, [x8, #0xc8]
1029c4154:     	ldur	q0, [x20, #0xd8]
1029c4158:     	stur	q0, [x8, #0xd8]
1029c415c:     	ldr	q0, [sp, #0x8a0]
1029c4160:     	ldr	x10, [sp, #0x8b0]
1029c4164:     	ldr	x11, [sp, #0x608]
1029c4168:     	str	x10, [sp, #0x170]
1029c416c:     	str	x11, [sp, #0x188]
1029c4170:     	ldr	q1, [x12]
1029c4174:     	stur	q1, [x8, #0x88]
1029c4178:     	ldr	x8, [sp, #0x220]
1029c417c:     	str	x9, [sp, #0x208]
1029c4180:     	str	x8, [sp, #0x1a0]
1029c4184:     	ldr	q1, [sp, #0x210]
1029c4188:     	str	q1, [sp, #0x190]
1029c418c:     	ldp	q2, q1, [x20]
1029c4190:     	stp	q2, q1, [sp, #0xf0]
1029c4194:     	ldr	q1, [x20, #0x60]
1029c4198:     	stp	q1, q0, [sp, #0x150]
1029c419c:     	ldp	q1, q0, [x20, #0x40]
1029c41a0:     	stp	q1, q0, [sp, #0x130]
1029c41a4:     	ldp	q0, q1, [x20, #0x20]
1029c41a8:     	stp	q0, q1, [sp, #0x110]
1029c41ac:     	ldr	x8, [x20, #0x1c8]
1029c41b0:     	cmp	x8, #0x2
1029c41b4:     	b.ne	0x1029c420c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1ac>
1029c41b8:     	str	x8, [sp, #0x210]
1029c41bc:     	add	x0, x20, #0x5b0
1029c41c0:     	bl	0x102766ba0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c41c4:     	str	x0, [sp, #0xd8]
1029c41c8:     	mov	x22, x1
1029c41cc:     	add	x0, x20, #0x5c0
1029c41d0:     	bl	0x102767314 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c41d4:     	str	x1, [sp, #0xe8]
1029c41d8:     	mov	x24, x0
1029c41dc:     	ldr	x25, [x20, #0x5d8]
1029c41e0:     	add	x8, x25, x25, lsl #1
1029c41e4:     	lsl	x27, x8, #2
1029c41e8:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1029c41ec:     	movk	x8, #0xaaa, lsl #48
1029c41f0:     	cmp	x25, x8
1029c41f4:     	b.ls	0x1029c4248 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1e8>
1029c41f8:     	mov	x26, #0x0               ; =0
1029c41fc:     	mov	x0, x26
1029c4200:     	mov	x1, x27
1029c4204:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4208:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c420c:     	str	w19, [sp, #0xe4]
1029c4210:     	ldr	x19, [x20, #0x440]
1029c4214:     	add	x0, x20, #0x430
1029c4218:     	bl	0x102e82834 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1029c421c:     	mov	x22, x0
1029c4220:     	mov	x21, x1
1029c4224:     	ldr	x28, [x20, #0x410]
1029c4228:     	lsl	x24, x28, #1
1029c422c:     	orr	x8, x24, x28
1029c4230:     	tbz	x8, #0x3f, 0x1029c429c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x23c>
1029c4234:     	mov	x26, #0x0               ; =0
1029c4238:     	mov	x0, x26
1029c423c:     	mov	x1, x24
1029c4240:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4244:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c4248:     	str	w19, [sp, #0xe4]
1029c424c:     	cbz	x27, 0x1029c42f8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
1029c4250:     	ldr	x21, [x20, #0x5d0]
1029c4254:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c4258:     	mov	w26, #0x4               ; =4
1029c425c:     	mov	x0, x27
1029c4260:     	mov	w1, #0x4                ; =4
1029c4264:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c4268:     	str	x0, [sp, #0xc8]
1029c426c:     	cbz	x0, 0x1029c41fc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x19c>
1029c4270:     	cbz	x25, 0x1029c4284 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x224>
1029c4274:     	ldr	x0, [sp, #0xc8]
1029c4278:     	mov	x1, x21
1029c427c:     	mov	x2, x27
1029c4280:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c4284:     	mov	x21, #0x0               ; =0
1029c4288:     	ldr	x19, [x20, #0x5e8]
1029c428c:     	lsl	x28, x19, #5
1029c4290:     	lsr	x8, x19, #59
1029c4294:     	cbz	x8, 0x1029c4314 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
1029c4298:     	b	0x1029c4388 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1029c429c:     	str	x23, [sp, #0xd0]
1029c42a0:     	ldrb	w27, [x20, #0x400]
1029c42a4:     	cbz	x24, 0x1029c4398 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x338>
1029c42a8:     	ldr	x25, [x20, #0x408]
1029c42ac:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c42b0:     	mov	w26, #0x1               ; =1
1029c42b4:     	mov	x0, x24
1029c42b8:     	mov	w1, #0x1                ; =1
1029c42bc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c42c0:     	cbz	x0, 0x1029c4238 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1d8>
1029c42c4:     	mov	x23, x0
1029c42c8:     	cbz	x28, 0x1029c42dc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x27c>
1029c42cc:     	mov	x0, x23
1029c42d0:     	mov	x1, x25
1029c42d4:     	mov	x2, x24
1029c42d8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c42dc:     	cbz	w27, 0x1029c43a0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x340>
1029c42e0:     	ldrb	w8, [x20, #0x401]
1029c42e4:     	str	w8, [sp, #0xe8]
1029c42e8:     	ldrb	w27, [x20, #0x402]
1029c42ec:     	mov	w25, #0x1               ; =1
1029c42f0:     	ldr	w26, [x20, #0x404]
1029c42f4:     	b	0x1029c43a4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x344>
1029c42f8:     	mov	w8, #0x4                ; =4
1029c42fc:     	str	x8, [sp, #0xc8]
1029c4300:     	mov	x21, #0x0               ; =0
1029c4304:     	ldr	x19, [x20, #0x5e8]
1029c4308:     	lsl	x28, x19, #5
1029c430c:     	lsr	x8, x19, #59
1029c4310:     	cbnz	x8, 0x1029c4388 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1029c4314:     	str	x23, [sp, #0xd0]
1029c4318:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1029c431c:     	cmp	x28, x8
1029c4320:     	b.hi	0x1029c4388 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1029c4324:     	ldr	x9, [x20, #0x658]
1029c4328:     	ldr	x8, [x20, #0x660]
1029c432c:     	stp	x8, x9, [sp, #0xb8]
1029c4330:     	cbz	x28, 0x1029c45b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x558>
1029c4334:     	ldr	x23, [x20, #0x5e0]
1029c4338:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c433c:     	mov	w21, #0x8               ; =8
1029c4340:     	mov	x0, x28
1029c4344:     	mov	w1, #0x8                ; =8
1029c4348:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c434c:     	cbz	x0, 0x1029c4388 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1029c4350:     	mov	x26, x0
1029c4354:     	cbz	x19, 0x1029c45bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x55c>
1029c4358:     	mov	x8, #0x0                ; =0
1029c435c:     	mov	x9, x19
1029c4360:     	cmp	x28, x8
1029c4364:     	b.eq	0x1029c45bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x55c>
1029c4368:     	add	x10, x23, x8
1029c436c:     	add	x11, x26, x8
1029c4370:     	ldp	q0, q1, [x10]
1029c4374:     	stp	q0, q1, [x11]
1029c4378:     	add	x8, x8, #0x20
1029c437c:     	subs	x9, x9, #0x1
1029c4380:     	b.ne	0x1029c4360 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x300>
1029c4384:     	b	0x1029c45bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x55c>
1029c4388:     	mov	x0, x21
1029c438c:     	mov	x1, x28
1029c4390:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4394:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c4398:     	mov	w23, #0x1               ; =1
1029c439c:     	cbnz	w27, 0x1029c42e0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x280>
1029c43a0:     	mov	w25, #0x0               ; =0
1029c43a4:     	add	x0, x20, #0x418
1029c43a8:     	bl	0x10276787c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c43ac:     	ldrb	w8, [x20, #0x428]
1029c43b0:     	sub	w9, w8, #0x3
1029c43b4:     	mov	w10, #0x2               ; =2
1029c43b8:     	cmp	w8, #0x2
1029c43bc:     	csel	w9, w9, w10, hi
1029c43c0:     	and	w9, w9, #0xff
1029c43c4:     	cmp	w9, #0x1
1029c43c8:     	b.gt	0x1029c43d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x378>
1029c43cc:     	cbnz	w9, 0x1029c43e4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x384>
1029c43d0:     	mov	w8, #0x3                ; =3
1029c43d4:     	b	0x1029c43e8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x388>
1029c43d8:     	cmp	w9, #0x2
1029c43dc:     	ldrb	w9, [x20, #0x429]
1029c43e0:     	b	0x1029c43e8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x388>
1029c43e4:     	mov	w8, #0x4                ; =4
1029c43e8:     	str	x19, [sp, #0x250]
1029c43ec:     	str	x22, [sp, #0x240]
1029c43f0:     	str	x21, [sp, #0x248]
1029c43f4:     	strb	w25, [sp, #0x210]
1029c43f8:     	ldr	w10, [sp, #0xe8]
1029c43fc:     	strb	w10, [sp, #0x211]
1029c4400:     	strb	w27, [sp, #0x212]
1029c4404:     	str	w26, [sp, #0x214]
1029c4408:     	str	x23, [sp, #0x218]
1029c440c:     	str	x28, [sp, #0x220]
1029c4410:     	str	x0, [sp, #0x228]
1029c4414:     	str	x1, [sp, #0x230]
1029c4418:     	strb	w8, [sp, #0x238]
1029c441c:     	strb	w9, [sp, #0x239]
1029c4420:     	ldr	d8, [x20, #0x3f8]
1029c4424:     	add	x0, x20, #0x448
1029c4428:     	bl	0x1027674b4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c442c:     	mov	x22, x0
1029c4430:     	mov	x21, x1
1029c4434:     	add	x0, x20, #0x458
1029c4438:     	bl	0x1027674b4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c443c:     	mov	x24, x0
1029c4440:     	mov	x23, x1
1029c4444:     	add	x8, x20, #0x3d0
1029c4448:     	ldr	x9, [x20, #0x3d0]
1029c444c:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1029c4450:     	cmp	x9, x10
1029c4454:     	b.ne	0x1029c4474 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x414>
1029c4458:     	ldr	q0, [x8]
1029c445c:     	stur	q0, [x29, #-0x90]
1029c4460:     	ldr	x8, [x8, #0x10]
1029c4464:     	stur	x8, [x29, #-0x80]
1029c4468:     	ldr	x25, [x20, #0x3e8]
1029c446c:     	ldr	x26, [x20, #0x3f0]
1029c4470:     	b	0x1029c44a4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x444>
1029c4474:     	add	x0, x20, #0x3e8
1029c4478:     	bl	0x10276179c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c447c:     	mov	x25, x0
1029c4480:     	mov	x26, x1
1029c4484:     	add	x8, sp, #0x5f8
1029c4488:     	add	x0, x20, #0x3d0
1029c448c:     	bl	0x102e823b0 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1029c4490:     	add	x8, sp, #0x5f8
1029c4494:     	ldr	q0, [x8]
1029c4498:     	stur	q0, [x29, #-0x90]
1029c449c:     	ldr	x8, [sp, #0x608]
1029c44a0:     	stur	x8, [x29, #-0x80]
1029c44a4:     	ldrb	w8, [x20, #0x468]
1029c44a8:     	ldp	q0, q1, [sp, #0x230]
1029c44ac:     	str	q0, [sp, #0x8f0]
1029c44b0:     	str	q1, [sp, #0x900]
1029c44b4:     	ldr	x9, [sp, #0x250]
1029c44b8:     	ldp	q1, q0, [sp, #0x210]
1029c44bc:     	str	q0, [sp, #0x8e0]
1029c44c0:     	str	q1, [sp, #0x8d0]
1029c44c4:     	str	d8, [sp, #0x8c8]
1029c44c8:     	str	x9, [sp, #0x910]
1029c44cc:     	str	x22, [sp, #0x918]
1029c44d0:     	str	x21, [sp, #0x920]
1029c44d4:     	str	x24, [sp, #0x928]
1029c44d8:     	str	x23, [sp, #0x930]
1029c44dc:     	ldur	q0, [x29, #-0x90]
1029c44e0:     	ldur	x9, [x29, #-0x80]
1029c44e4:     	str	q0, [sp, #0x8a0]
1029c44e8:     	str	x9, [sp, #0x8b0]
1029c44ec:     	str	x25, [sp, #0x8b8]
1029c44f0:     	str	x26, [sp, #0x8c0]
1029c44f4:     	strb	w8, [sp, #0x938]
1029c44f8:     	add	x0, x20, #0x470
1029c44fc:     	bl	0x102766c98 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c4500:     	mov	x26, x0
1029c4504:     	mov	x24, x1
1029c4508:     	add	x0, x20, #0x480
1029c450c:     	bl	0x102766c98 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c4510:     	mov	x28, x0
1029c4514:     	mov	x27, x1
1029c4518:     	add	x0, x20, #0x490
1029c451c:     	bl	0x102767064 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c4520:     	str	x0, [sp, #0xd8]
1029c4524:     	str	x1, [sp, #0xe8]
1029c4528:     	add	x0, x20, #0x4a0
1029c452c:     	bl	0x102767064 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c4530:     	stp	x0, x1, [sp, #0xc0]
1029c4534:     	mov	x22, #0x0               ; =0
1029c4538:     	ldr	x25, [x20, #0x4b8]
1029c453c:     	lsl	x21, x25, #6
1029c4540:     	lsr	x8, x25, #58
1029c4544:     	cbnz	x8, 0x1029c45a8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x548>
1029c4548:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1029c454c:     	cmp	x21, x8
1029c4550:     	b.hi	0x1029c45a8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x548>
1029c4554:     	stp	x26, x24, [sp, #0xb0]
1029c4558:     	cbz	x21, 0x1029c46bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x65c>
1029c455c:     	ldr	x23, [x20, #0x4b0]
1029c4560:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c4564:     	mov	w22, #0x8               ; =8
1029c4568:     	mov	x0, x21
1029c456c:     	mov	w1, #0x8                ; =8
1029c4570:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c4574:     	str	x0, [sp, #0xa0]
1029c4578:     	cbz	x0, 0x1029c45a8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x548>
1029c457c:     	cbz	x25, 0x1029c4590 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x530>
1029c4580:     	ldr	x0, [sp, #0xa0]
1029c4584:     	mov	x1, x23
1029c4588:     	mov	x2, x21
1029c458c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c4590:     	mov	x23, #0x0               ; =0
1029c4594:     	ldr	x26, [x20, #0x4c8]
1029c4598:     	lsl	x22, x26, #6
1029c459c:     	lsr	x8, x26, #58
1029c45a0:     	cbz	x8, 0x1029c46d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x678>
1029c45a4:     	b	0x1029c4720 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1029c45a8:     	mov	x0, x22
1029c45ac:     	mov	x1, x21
1029c45b0:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c45b4:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c45b8:     	mov	w26, #0x8               ; =8
1029c45bc:     	ldr	x21, [x20, #0x668]
1029c45c0:     	ldr	x27, [x20, #0x670]
1029c45c4:     	ldr	x23, [sp, #0xd0]
1029c45c8:     	ldr	w8, [sp, #0xe4]
1029c45cc:     	str	w8, [x23, #0x678]
1029c45d0:     	add	x1, sp, #0xf0
1029c45d4:     	mov	x0, x23
1029c45d8:     	mov	w2, #0x120              ; =288
1029c45dc:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c45e0:     	add	x0, x23, #0x1c8
1029c45e4:     	add	x1, sp, #0x210
1029c45e8:     	mov	w2, #0x3e8              ; =1000
1029c45ec:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c45f0:     	ldr	x8, [sp, #0xd8]
1029c45f4:     	str	x8, [x23, #0x5b0]
1029c45f8:     	str	x22, [x23, #0x5b8]
1029c45fc:     	str	x24, [x23, #0x5c0]
1029c4600:     	ldr	x8, [sp, #0xe8]
1029c4604:     	str	x8, [x23, #0x5c8]
1029c4608:     	ldr	x8, [sp, #0xc8]
1029c460c:     	str	x8, [x23, #0x5d0]
1029c4610:     	str	x25, [x23, #0x5d8]
1029c4614:     	ldr	q0, [x20, #0x620]
1029c4618:     	str	q0, [x23, #0x620]
1029c461c:     	ldr	q0, [x20, #0x630]
1029c4620:     	str	q0, [x23, #0x630]
1029c4624:     	ldr	q0, [x20, #0x640]
1029c4628:     	str	q0, [x23, #0x640]
1029c462c:     	ldr	x8, [x20, #0x650]
1029c4630:     	str	x8, [x23, #0x650]
1029c4634:     	ldr	q0, [x20, #0x5f0]
1029c4638:     	str	q0, [x23, #0x5f0]
1029c463c:     	ldr	q0, [x20, #0x600]
1029c4640:     	str	q0, [x23, #0x600]
1029c4644:     	ldr	q0, [x20, #0x610]
1029c4648:     	str	q0, [x23, #0x610]
1029c464c:     	ldp	x8, x9, [sp, #0xb8]
1029c4650:     	str	x9, [x23, #0x658]
1029c4654:     	str	x8, [x23, #0x660]
1029c4658:     	ldp	q1, q0, [x20, #0x120]
1029c465c:     	stp	q1, q0, [x23, #0x120]
1029c4660:     	ldp	q1, q0, [x20, #0x160]
1029c4664:     	stp	q1, q0, [x23, #0x160]
1029c4668:     	ldp	q0, q1, [x20, #0x140]
1029c466c:     	stp	q0, q1, [x23, #0x140]
1029c4670:     	ldr	x8, [x20, #0x1c0]
1029c4674:     	str	x8, [x23, #0x1c0]
1029c4678:     	ldp	q1, q0, [x20, #0x1a0]
1029c467c:     	stp	q1, q0, [x23, #0x1a0]
1029c4680:     	ldp	q0, q1, [x20, #0x180]
1029c4684:     	stp	q0, q1, [x23, #0x180]
1029c4688:     	str	x26, [x23, #0x5e0]
1029c468c:     	str	x19, [x23, #0x5e8]
1029c4690:     	str	x21, [x23, #0x668]
1029c4694:     	str	x27, [x23, #0x670]
1029c4698:     	add	sp, sp, #0x970
1029c469c:     	ldp	x29, x30, [sp, #0x60]
1029c46a0:     	ldp	x20, x19, [sp, #0x50]
1029c46a4:     	ldp	x22, x21, [sp, #0x40]
1029c46a8:     	ldp	x24, x23, [sp, #0x30]
1029c46ac:     	ldp	x26, x25, [sp, #0x20]
1029c46b0:     	ldp	x28, x27, [sp, #0x10]
1029c46b4:     	ldp	d9, d8, [sp], #0x70
1029c46b8:     	ret
1029c46bc:     	mov	w8, #0x8                ; =8
1029c46c0:     	str	x8, [sp, #0xa0]
1029c46c4:     	mov	x23, #0x0               ; =0
1029c46c8:     	ldr	x26, [x20, #0x4c8]
1029c46cc:     	lsl	x22, x26, #6
1029c46d0:     	lsr	x8, x26, #58
1029c46d4:     	cbnz	x8, 0x1029c4720 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1029c46d8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1029c46dc:     	cmp	x22, x8
1029c46e0:     	b.hi	0x1029c4720 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1029c46e4:     	cbz	x22, 0x1029c4730 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d0>
1029c46e8:     	ldr	x24, [x20, #0x4c0]
1029c46ec:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c46f0:     	mov	w23, #0x8               ; =8
1029c46f4:     	mov	x0, x22
1029c46f8:     	mov	w1, #0x8                ; =8
1029c46fc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c4700:     	str	x0, [sp, #0x98]
1029c4704:     	cbz	x0, 0x1029c4720 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1029c4708:     	cbz	x26, 0x1029c4738 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d8>
1029c470c:     	ldr	x0, [sp, #0x98]
1029c4710:     	mov	x1, x24
1029c4714:     	mov	x2, x22
1029c4718:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c471c:     	b	0x1029c4738 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d8>
1029c4720:     	mov	x0, x23
1029c4724:     	mov	x1, x22
1029c4728:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c472c:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c4730:     	mov	w8, #0x8                ; =8
1029c4734:     	str	x8, [sp, #0x98]
1029c4738:     	ldr	x9, [x20, #0x4d8]
1029c473c:     	add	x8, x9, x9, lsl #1
1029c4740:     	lsl	x23, x8, #4
1029c4744:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1029c4748:     	movk	x8, #0x2aa, lsl #48
1029c474c:     	str	x9, [sp, #0x90]
1029c4750:     	cmp	x9, x8
1029c4754:     	b.ls	0x1029c476c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x70c>
1029c4758:     	mov	x24, #0x0               ; =0
1029c475c:     	mov	x0, x24
1029c4760:     	mov	x1, x23
1029c4764:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4768:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c476c:     	cbz	x23, 0x1029c47d0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x770>
1029c4770:     	ldr	x19, [x20, #0x4d0]
1029c4774:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c4778:     	mov	w24, #0x8               ; =8
1029c477c:     	mov	x0, x23
1029c4780:     	mov	w1, #0x8                ; =8
1029c4784:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c4788:     	str	x0, [sp, #0xa8]
1029c478c:     	cbz	x0, 0x1029c475c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6fc>
1029c4790:     	ldr	x9, [sp, #0x90]
1029c4794:     	cbz	x9, 0x1029c47d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x778>
1029c4798:     	mov	x8, #0x0                ; =0
1029c479c:     	cmp	x23, x8
1029c47a0:     	b.eq	0x1029c47d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x778>
1029c47a4:     	add	x10, x19, x8
1029c47a8:     	ldr	x11, [sp, #0xa8]
1029c47ac:     	add	x11, x11, x8
1029c47b0:     	ldp	q0, q1, [x10]
1029c47b4:     	ldr	q2, [x10, #0x20]
1029c47b8:     	stp	q1, q2, [x11, #0x10]
1029c47bc:     	str	q0, [x11]
1029c47c0:     	add	x8, x8, #0x30
1029c47c4:     	subs	x9, x9, #0x1
1029c47c8:     	b.ne	0x1029c479c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x73c>
1029c47cc:     	b	0x1029c47d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x778>
1029c47d0:     	mov	w8, #0x8                ; =8
1029c47d4:     	str	x8, [sp, #0xa8]
1029c47d8:     	mov	x24, #-0x5555555555555556 ; =-6148914691236517206
1029c47dc:     	movk	x24, #0xaaa, lsl #48
1029c47e0:     	ldr	x9, [x20, #0x4e8]
1029c47e4:     	add	x8, x9, x9, lsl #1
1029c47e8:     	lsl	x19, x8, #2
1029c47ec:     	str	x9, [sp, #0x88]
1029c47f0:     	cmp	x9, x24
1029c47f4:     	b.ls	0x1029c480c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7ac>
1029c47f8:     	mov	x24, #0x0               ; =0
1029c47fc:     	mov	x0, x24
1029c4800:     	mov	x1, x19
1029c4804:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4808:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c480c:     	str	x19, [sp, #0x78]
1029c4810:     	cbz	x19, 0x1029c4858 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7f8>
1029c4814:     	ldr	x8, [x20, #0x4e0]
1029c4818:     	str	x8, [sp, #0x70]
1029c481c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c4820:     	mov	w24, #0x4               ; =4
1029c4824:     	mov	x0, x19
1029c4828:     	mov	w1, #0x4                ; =4
1029c482c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c4830:     	str	x0, [sp, #0x80]
1029c4834:     	cbz	x0, 0x1029c47fc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x79c>
1029c4838:     	ldr	x8, [sp, #0x88]
1029c483c:     	mov	x24, #-0x5555555555555556 ; =-6148914691236517206
1029c4840:     	movk	x24, #0xaaa, lsl #48
1029c4844:     	cbz	x8, 0x1029c4860 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x800>
1029c4848:     	ldp	x2, x0, [sp, #0x78]
1029c484c:     	ldr	x1, [sp, #0x70]
1029c4850:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c4854:     	b	0x1029c4860 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x800>
1029c4858:     	mov	w8, #0x4                ; =4
1029c485c:     	str	x8, [sp, #0x80]
1029c4860:     	ldr	x9, [x20, #0x4f8]
1029c4864:     	add	x8, x9, x9, lsl #1
1029c4868:     	lsl	x19, x8, #2
1029c486c:     	cmp	x9, x24
1029c4870:     	b.ls	0x1029c4888 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x828>
1029c4874:     	mov	x24, #0x0               ; =0
1029c4878:     	mov	x0, x24
1029c487c:     	mov	x1, x19
1029c4880:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4884:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c4888:     	str	x9, [sp, #0x70]
1029c488c:     	str	x19, [sp, #0x58]
1029c4890:     	cbz	x19, 0x1029c48d0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x870>
1029c4894:     	ldr	x8, [x20, #0x4f0]
1029c4898:     	str	x8, [sp, #0x68]
1029c489c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c48a0:     	mov	w24, #0x4               ; =4
1029c48a4:     	mov	x0, x19
1029c48a8:     	mov	w1, #0x4                ; =4
1029c48ac:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c48b0:     	str	x0, [sp, #0x60]
1029c48b4:     	cbz	x0, 0x1029c4878 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x818>
1029c48b8:     	ldr	x8, [sp, #0x70]
1029c48bc:     	cbz	x8, 0x1029c48d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x878>
1029c48c0:     	ldp	x0, x1, [sp, #0x60]
1029c48c4:     	ldr	x2, [sp, #0x58]
1029c48c8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c48cc:     	b	0x1029c48d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x878>
1029c48d0:     	mov	w8, #0x4                ; =4
1029c48d4:     	str	x8, [sp, #0x60]
1029c48d8:     	add	x0, x20, #0x500
1029c48dc:     	bl	0x102766ba0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1029c48e0:     	str	x0, [sp, #0x48]
1029c48e4:     	str	x1, [sp, #0x68]
1029c48e8:     	mov	x9, #0x0                ; =0
1029c48ec:     	ldr	x8, [x20, #0x518]
1029c48f0:     	lsl	x19, x8, #2
1029c48f4:     	str	x8, [sp, #0x50]
1029c48f8:     	lsr	x8, x8, #62
1029c48fc:     	cbnz	x8, 0x1029c4950 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8f0>
1029c4900:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
1029c4904:     	cmp	x19, x8
1029c4908:     	b.hi	0x1029c4950 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8f0>
1029c490c:     	str	x19, [sp, #0x30]
1029c4910:     	cbz	x19, 0x1029c4960 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x900>
1029c4914:     	ldr	x24, [x20, #0x510]
1029c4918:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c491c:     	mov	x0, x19
1029c4920:     	mov	w1, #0x2                ; =2
1029c4924:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c4928:     	mov	w9, #0x2                ; =2
1029c492c:     	str	x0, [sp, #0x38]
1029c4930:     	cbz	x0, 0x1029c4950 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8f0>
1029c4934:     	ldr	x8, [sp, #0x50]
1029c4938:     	cbz	x8, 0x1029c4968 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x908>
1029c493c:     	ldr	x0, [sp, #0x38]
1029c4940:     	mov	x1, x24
1029c4944:     	mov	x2, x19
1029c4948:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c494c:     	b	0x1029c4968 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x908>
1029c4950:     	mov	x0, x9
1029c4954:     	mov	x1, x19
1029c4958:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c495c:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c4960:     	mov	w8, #0x2                ; =2
1029c4964:     	str	x8, [sp, #0x38]
1029c4968:     	ldr	x19, [x20, #0x528]
1029c496c:     	add	x8, x19, x19, lsl #1
1029c4970:     	lsl	x9, x8, #2
1029c4974:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1029c4978:     	movk	x8, #0xaaa, lsl #48
1029c497c:     	cmp	x19, x8
1029c4980:     	str	x9, [sp, #0x40]
1029c4984:     	b.ls	0x1029c499c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x93c>
1029c4988:     	mov	x24, #0x0               ; =0
1029c498c:     	mov	x0, x24
1029c4990:     	ldr	x1, [sp, #0x40]
1029c4994:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4998:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c499c:     	str	x19, [sp, #0x20]
1029c49a0:     	cbz	x9, 0x1029c49e0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x980>
1029c49a4:     	ldr	x8, [x20, #0x520]
1029c49a8:     	str	x8, [sp, #0x18]
1029c49ac:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c49b0:     	mov	w24, #0x4               ; =4
1029c49b4:     	ldr	x0, [sp, #0x40]
1029c49b8:     	mov	w1, #0x4                ; =4
1029c49bc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c49c0:     	str	x0, [sp, #0x28]
1029c49c4:     	cbz	x0, 0x1029c498c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x92c>
1029c49c8:     	cbz	x19, 0x1029c49e8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x988>
1029c49cc:     	ldr	x0, [sp, #0x28]
1029c49d0:     	ldr	x1, [sp, #0x18]
1029c49d4:     	ldr	x2, [sp, #0x40]
1029c49d8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c49dc:     	b	0x1029c49e8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x988>
1029c49e0:     	mov	w8, #0x4                ; =4
1029c49e4:     	str	x8, [sp, #0x28]
1029c49e8:     	mov	x9, #0x0                ; =0
1029c49ec:     	ldr	x19, [x20, #0x538]
1029c49f0:     	lsl	x24, x19, #2
1029c49f4:     	lsr	x8, x19, #62
1029c49f8:     	cbnz	x8, 0x1029c4a54 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9f4>
1029c49fc:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
1029c4a00:     	cmp	x24, x8
1029c4a04:     	b.hi	0x1029c4a54 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9f4>
1029c4a08:     	ldrh	w8, [x20, #0x5ac]
1029c4a0c:     	ldr	w9, [x20, #0x5a8]
1029c4a10:     	cbz	x24, 0x1029c4a64 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa04>
1029c4a14:     	stp	x9, x8, [sp, #0x10]
1029c4a18:     	ldr	x8, [x20, #0x530]
1029c4a1c:     	str	x8, [sp, #0x8]
1029c4a20:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029c4a24:     	mov	x0, x24
1029c4a28:     	mov	w1, #0x2                ; =2
1029c4a2c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029c4a30:     	mov	w9, #0x2                ; =2
1029c4a34:     	cbz	x0, 0x1029c4a54 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9f4>
1029c4a38:     	ldr	x23, [sp, #0xd0]
1029c4a3c:     	cbz	x19, 0x1029c4a9c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa3c>
1029c4a40:     	mov	x22, x0
1029c4a44:     	ldr	x1, [sp, #0x8]
1029c4a48:     	mov	x2, x24
1029c4a4c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c4a50:     	b	0x1029c4aa0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa40>
1029c4a54:     	mov	x0, x9
1029c4a58:     	mov	x1, x24
1029c4a5c:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029c4a60:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c4a64:     	mov	w22, #0x2               ; =2
1029c4a68:     	ldr	x23, [sp, #0xd0]
1029c4a6c:     	b	0x1029c4aa4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa44>
1029c4a70:     	adrp	x0, 0x10803a000 <_anon.ca450c5141039434e7dc58a745d07839.2+0x20>
1029c4a74:     	add	x0, x0, #0xcf0
1029c4a78:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1029c4a7c:     	adrp	x0, 0x10803a000 <_anon.ca450c5141039434e7dc58a745d07839.2+0x20>
1029c4a80:     	add	x0, x0, #0xcf0
1029c4a84:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1029c4a88:     	b	0x1029c4a98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1029c4a8c:     	adrp	x0, 0x10803a000 <_anon.ca450c5141039434e7dc58a745d07839.2+0x20>
1029c4a90:     	add	x0, x0, #0xcf0
1029c4a94:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1029c4a98:     	brk	#0x1
1029c4a9c:     	mov	x22, x0
1029c4aa0:     	ldp	x9, x8, [sp, #0x10]
1029c4aa4:     	ldr	q0, [sp, #0x900]
1029c4aa8:     	ldr	q1, [sp, #0x910]
1029c4aac:     	orr	x21, x9, x8, lsl #32
1029c4ab0:     	add	x8, sp, #0x5f8
1029c4ab4:     	add	x8, x8, #0x208
1029c4ab8:     	stp	q0, q1, [x8, #0x60]
1029c4abc:     	ldr	q0, [sp, #0x920]
1029c4ac0:     	ldr	q1, [sp, #0x930]
1029c4ac4:     	stp	q0, q1, [x8, #0x80]
1029c4ac8:     	ldr	q0, [sp, #0x8c0]
1029c4acc:     	ldr	q1, [sp, #0x8d0]
1029c4ad0:     	stp	q0, q1, [x8, #0x20]
1029c4ad4:     	ldr	q0, [sp, #0x8e0]
1029c4ad8:     	ldr	q1, [sp, #0x8f0]
1029c4adc:     	stp	q0, q1, [x8, #0x40]
1029c4ae0:     	ldr	q0, [sp, #0x8a0]
1029c4ae4:     	ldr	q1, [sp, #0x8b0]
1029c4ae8:     	stp	q0, q1, [x8]
1029c4aec:     	add	x0, sp, #0x5f8
1029c4af0:     	add	x1, x20, #0x1c8
1029c4af4:     	mov	w2, #0x208              ; =520
1029c4af8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c4afc:     	add	x8, sp, #0x210
1029c4b00:     	ldr	q0, [x20, #0x570]
1029c4b04:     	add	x8, x8, #0x378
1029c4b08:     	ldr	q1, [x20, #0x580]
1029c4b0c:     	ldr	q2, [x20, #0x590]
1029c4b10:     	stp	q1, q2, [x8, #0x40]
1029c4b14:     	ldr	q1, [x20, #0x540]
1029c4b18:     	ldr	q2, [x20, #0x550]
1029c4b1c:     	stp	q1, q2, [x8]
1029c4b20:     	ldr	q1, [x20, #0x560]
1029c4b24:     	stp	q1, q0, [x8, #0x20]
1029c4b28:     	ldr	x8, [x20, #0x5a0]
1029c4b2c:     	str	x8, [sp, #0x5e8]
1029c4b30:     	add	x0, sp, #0x210
1029c4b34:     	add	x1, sp, #0x5f8
1029c4b38:     	mov	w2, #0x2a8              ; =680
1029c4b3c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029c4b40:     	ldp	x9, x8, [sp, #0xb0]
1029c4b44:     	str	x9, [sp, #0x4b8]
1029c4b48:     	str	x8, [sp, #0x4c0]
1029c4b4c:     	str	x28, [sp, #0x4c8]
1029c4b50:     	str	x27, [sp, #0x4d0]
1029c4b54:     	ldr	x8, [sp, #0xd8]
1029c4b58:     	str	x8, [sp, #0x4d8]
1029c4b5c:     	ldr	x8, [sp, #0xe8]
1029c4b60:     	str	x8, [sp, #0x4e0]
1029c4b64:     	ldp	x9, x8, [sp, #0xc0]
1029c4b68:     	str	x9, [sp, #0x4e8]
1029c4b6c:     	str	x8, [sp, #0x4f0]
1029c4b70:     	ldp	x8, x9, [sp, #0x98]
1029c4b74:     	str	x9, [sp, #0x4f8]
1029c4b78:     	str	x25, [sp, #0x500]
1029c4b7c:     	str	x8, [sp, #0x508]
1029c4b80:     	str	x26, [sp, #0x510]
1029c4b84:     	ldr	x8, [sp, #0xa8]
1029c4b88:     	str	x8, [sp, #0x518]
1029c4b8c:     	ldr	x8, [sp, #0x90]
1029c4b90:     	str	x8, [sp, #0x520]
1029c4b94:     	ldp	x9, x8, [sp, #0x80]
1029c4b98:     	str	x9, [sp, #0x528]
1029c4b9c:     	str	x8, [sp, #0x530]
1029c4ba0:     	ldr	x8, [sp, #0x60]
1029c4ba4:     	str	x8, [sp, #0x538]
1029c4ba8:     	ldr	x8, [sp, #0x70]
1029c4bac:     	str	x8, [sp, #0x540]
1029c4bb0:     	ldr	x8, [sp, #0x48]
1029c4bb4:     	str	x8, [sp, #0x548]
1029c4bb8:     	ldr	x8, [sp, #0x68]
1029c4bbc:     	str	x8, [sp, #0x550]
1029c4bc0:     	ldr	x8, [sp, #0x38]
1029c4bc4:     	str	x8, [sp, #0x558]
1029c4bc8:     	ldr	x8, [sp, #0x50]
1029c4bcc:     	str	x8, [sp, #0x560]
1029c4bd0:     	ldp	x8, x9, [sp, #0x20]
1029c4bd4:     	str	x9, [sp, #0x568]
1029c4bd8:     	str	x8, [sp, #0x570]
1029c4bdc:     	str	x22, [sp, #0x578]
1029c4be0:     	str	x19, [sp, #0x580]
1029c4be4:     	lsr	x8, x21, #32
1029c4be8:     	strh	w8, [sp, #0x5f4]
1029c4bec:     	str	w21, [sp, #0x5f0]
1029c4bf0:     	ldr	w19, [sp, #0xe4]
1029c4bf4:     	b	0x1029c41bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x15c>
1029c4bf8:     	mov	x19, x0
1029c4bfc:     	ldr	x20, [sp, #0x90]
1029c4c00:     	b	0x1029c4d3c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcdc>
1029c4c04:     	mov	x19, x0
1029c4c08:     	mov	x0, x25
1029c4c0c:     	mov	x1, x26
1029c4c10:     	bl	0x102972dd4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECs1qJAwyMG1lC_11mech_engine>
1029c4c14:     	b	0x1029c4c1c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbbc>
1029c4c18:     	mov	x19, x0
1029c4c1c:     	mov	x0, x24
1029c4c20:     	mov	x1, x23
1029c4c24:     	bl	0x102973630 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
1029c4c28:     	b	0x1029c4c58 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbf8>
1029c4c2c:     	mov	x19, x0
1029c4c30:     	ldr	x20, [sp, #0xe8]
1029c4c34:     	ldr	x23, [sp, #0xd8]
1029c4c38:     	b	0x1029c4de4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd84>
1029c4c3c:     	mov	x19, x0
1029c4c40:     	b	0x1029c4df0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd90>
1029c4c44:     	mov	x19, x0
1029c4c48:     	b	0x1029c4dfc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd9c>
1029c4c4c:     	mov	x19, x0
1029c4c50:     	b	0x1029c4e08 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xda8>
1029c4c54:     	mov	x19, x0
1029c4c58:     	mov	x0, x22
1029c4c5c:     	mov	x1, x21
1029c4c60:     	bl	0x102973630 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
1029c4c64:     	b	0x1029c4c70 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc10>
1029c4c68:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1029c4c6c:     	mov	x19, x0
1029c4c70:     	add	x0, sp, #0x210
1029c4c74:     	bl	0x102976d28 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorECs1qJAwyMG1lC_11mech_engine>
1029c4c78:     	b	0x1029c4e8c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1029c4c7c:     	mov	x19, x0
1029c4c80:     	cbz	x28, 0x1029c4e38 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdd8>
1029c4c84:     	mov	x0, x23
1029c4c88:     	mov	x1, x24
1029c4c8c:     	mov	w2, #0x1                ; =1
1029c4c90:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4c94:     	b	0x1029c4e38 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdd8>
1029c4c98:     	mov	x19, x0
1029c4c9c:     	b	0x1029c4e8c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1029c4ca0:     	mov	x19, x0
1029c4ca4:     	b	0x1029c4e60 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe00>
1029c4ca8:     	mov	x19, x0
1029c4cac:     	b	0x1029c4e78 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe18>
1029c4cb0:     	mov	x19, x0
1029c4cb4:     	add	x0, sp, #0x5f8
1029c4cb8:     	bl	0x1025b9da0 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1029c4cbc:     	b	0x1029c4cc4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc64>
1029c4cc0:     	mov	x19, x0
1029c4cc4:     	add	x0, sp, #0x8a0
1029c4cc8:     	bl	0x1025ba670 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model16RegionAccessPlanENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1029c4ccc:     	b	0x1029c4e94 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe34>
1029c4cd0:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1029c4cd4:     	mov	x19, x0
1029c4cd8:     	ldr	x20, [sp, #0x90]
1029c4cdc:     	ldr	x8, [sp, #0x20]
1029c4ce0:     	cbz	x8, 0x1029c4d00 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xca0>
1029c4ce4:     	ldr	x0, [sp, #0x28]
1029c4ce8:     	ldr	x1, [sp, #0x40]
1029c4cec:     	mov	w2, #0x4                ; =4
1029c4cf0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4cf4:     	b	0x1029c4d00 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xca0>
1029c4cf8:     	mov	x19, x0
1029c4cfc:     	ldr	x20, [sp, #0x90]
1029c4d00:     	ldr	x8, [sp, #0x50]
1029c4d04:     	cbz	x8, 0x1029c4d20 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcc0>
1029c4d08:     	ldp	x1, x0, [sp, #0x30]
1029c4d0c:     	mov	w2, #0x2                ; =2
1029c4d10:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4d14:     	b	0x1029c4d20 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcc0>
1029c4d18:     	mov	x19, x0
1029c4d1c:     	ldr	x20, [sp, #0x90]
1029c4d20:     	ldr	x8, [sp, #0x68]
1029c4d24:     	cbz	x8, 0x1029c4d3c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcdc>
1029c4d28:     	add	x8, x8, x8, lsl #1
1029c4d2c:     	lsl	x1, x8, #5
1029c4d30:     	ldr	x0, [sp, #0x48]
1029c4d34:     	mov	w2, #0x8                ; =8
1029c4d38:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4d3c:     	ldr	x8, [sp, #0x70]
1029c4d40:     	cbz	x8, 0x1029c4d5c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcfc>
1029c4d44:     	ldp	x1, x0, [sp, #0x58]
1029c4d48:     	mov	w2, #0x4                ; =4
1029c4d4c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4d50:     	b	0x1029c4d5c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcfc>
1029c4d54:     	mov	x19, x0
1029c4d58:     	ldr	x20, [sp, #0x90]
1029c4d5c:     	ldr	x8, [sp, #0x88]
1029c4d60:     	cbz	x8, 0x1029c4d7c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd1c>
1029c4d64:     	ldp	x1, x0, [sp, #0x78]
1029c4d68:     	mov	w2, #0x4                ; =4
1029c4d6c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4d70:     	b	0x1029c4d7c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd1c>
1029c4d74:     	mov	x19, x0
1029c4d78:     	ldr	x20, [sp, #0x90]
1029c4d7c:     	cbz	x20, 0x1029c4d98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd38>
1029c4d80:     	ldr	x0, [sp, #0xa8]
1029c4d84:     	mov	x1, x23
1029c4d88:     	mov	w2, #0x8                ; =8
1029c4d8c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4d90:     	b	0x1029c4d98 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd38>
1029c4d94:     	mov	x19, x0
1029c4d98:     	cbz	x26, 0x1029c4db4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd54>
1029c4d9c:     	ldr	x0, [sp, #0x98]
1029c4da0:     	mov	x1, x22
1029c4da4:     	mov	w2, #0x8                ; =8
1029c4da8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4dac:     	b	0x1029c4db4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd54>
1029c4db0:     	mov	x19, x0
1029c4db4:     	ldp	x26, x24, [sp, #0xb0]
1029c4db8:     	cbz	x25, 0x1029c4dd4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd74>
1029c4dbc:     	ldr	x0, [sp, #0xa0]
1029c4dc0:     	mov	x1, x21
1029c4dc4:     	mov	w2, #0x8                ; =8
1029c4dc8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4dcc:     	b	0x1029c4dd4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd74>
1029c4dd0:     	mov	x19, x0
1029c4dd4:     	ldr	x20, [sp, #0xe8]
1029c4dd8:     	ldr	x23, [sp, #0xd8]
1029c4ddc:     	ldp	x0, x1, [sp, #0xc0]
1029c4de0:     	bl	0x102973528 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
1029c4de4:     	mov	x0, x23
1029c4de8:     	mov	x1, x20
1029c4dec:     	bl	0x102973528 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
1029c4df0:     	mov	x0, x28
1029c4df4:     	mov	x1, x27
1029c4df8:     	bl	0x102973424 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
1029c4dfc:     	mov	x0, x26
1029c4e00:     	mov	x1, x24
1029c4e04:     	bl	0x102973424 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
1029c4e08:     	add	x0, sp, #0x8a0
1029c4e0c:     	bl	0x102976d60 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization9BoundCallECs1qJAwyMG1lC_11mech_engine>
1029c4e10:     	b	0x1029c4e8c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1029c4e14:     	mov	x19, x0
1029c4e18:     	cbz	x25, 0x1029c4e54 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdf4>
1029c4e1c:     	ldr	x0, [sp, #0xc8]
1029c4e20:     	mov	x1, x27
1029c4e24:     	mov	w2, #0x4                ; =4
1029c4e28:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4e2c:     	b	0x1029c4e54 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdf4>
1029c4e30:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1029c4e34:     	mov	x19, x0
1029c4e38:     	cbz	x21, 0x1029c4e8c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1029c4e3c:     	mov	x0, x22
1029c4e40:     	mov	x1, x21
1029c4e44:     	mov	w2, #0x1                ; =1
1029c4e48:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4e4c:     	b	0x1029c4e8c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1029c4e50:     	mov	x19, x0
1029c4e54:     	mov	x0, x24
1029c4e58:     	ldr	x1, [sp, #0xe8]
1029c4e5c:     	bl	0x1029735bc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
1029c4e60:     	cbz	x22, 0x1029c4e78 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe18>
1029c4e64:     	add	x8, x22, x22, lsl #1
1029c4e68:     	lsl	x1, x8, #5
1029c4e6c:     	ldr	x0, [sp, #0xd8]
1029c4e70:     	mov	w2, #0x8                ; =8
1029c4e74:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029c4e78:     	ldr	x8, [sp, #0x210]
1029c4e7c:     	cmp	x8, #0x2
1029c4e80:     	b.eq	0x1029c4e8c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1029c4e84:     	add	x0, sp, #0x210
1029c4e88:     	bl	0x102975acc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1029c4e8c:     	add	x0, sp, #0xf0
1029c4e90:     	bl	0x10297513c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15TurnMemoryFactsEBM_>
1029c4e94:     	mov	x0, x19
1029c4e98:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
1029c4e9c:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
