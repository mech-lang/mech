
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027b47d4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_>:
1027b47d4:     	sub	sp, sp, #0x150
1027b47d8:     	stp	x28, x27, [sp, #0xf0]
1027b47dc:     	stp	x26, x25, [sp, #0x100]
1027b47e0:     	stp	x24, x23, [sp, #0x110]
1027b47e4:     	stp	x22, x21, [sp, #0x120]
1027b47e8:     	stp	x20, x19, [sp, #0x130]
1027b47ec:     	stp	x29, x30, [sp, #0x140]
1027b47f0:     	add	x29, sp, #0x140
1027b47f4:     	mov	x21, x0
1027b47f8:     	mov	x19, x8
1027b47fc:     	bl	0x1025c1ecc <__RNvXsk_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB5_4IterTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB18_18operation_contract10validation13PortDirectiontENtNtNtB18_11memory_plan5model22CurrentMemoryFootprintENtNtNtNtCsgDHHaSskbIF_4core4iter6traits8iterator8Iterator4nextCs1qJAwyMG1lC_11mech_engine>
1027b4800:     	cbz	x0, 0x1027b4850 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x7c>
1027b4804:     	add	x24, sp, #0x60
1027b4808:     	sub	x23, x29, #0x9c
1027b480c:     	ldr	x8, [x21, #0x48]
1027b4810:     	ldr	w9, [x0]
1027b4814:     	ldrb	w20, [x0, #0x4]
1027b4818:     	ldrh	w22, [x0, #0x6]
1027b481c:     	ldr	w8, [x8]
1027b4820:     	ldp	q0, q1, [x1]
1027b4824:     	stur	q0, [x23, #0x4]
1027b4828:     	stur	q1, [x23, #0x14]
1027b482c:     	ldr	q0, [x1, #0x20]
1027b4830:     	stur	q0, [x23, #0x24]
1027b4834:     	ldr	x10, [x1, #0x30]
1027b4838:     	stur	x10, [x23, #0x34]
1027b483c:     	cmp	w9, w8
1027b4840:     	b.eq	0x1027b4860 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x8c>
1027b4844:     	mov	x0, x21
1027b4848:     	bl	0x1025c1ecc <__RNvXsk_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB5_4IterTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB18_18operation_contract10validation13PortDirectiontENtNtNtB18_11memory_plan5model22CurrentMemoryFootprintENtNtNtNtCsgDHHaSskbIF_4core4iter6traits8iterator8Iterator4nextCs1qJAwyMG1lC_11mech_engine>
1027b484c:     	cbnz	x0, 0x1027b480c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x38>
1027b4850:     	mov	w8, #0x8                ; =8
1027b4854:     	stp	xzr, x8, [x19]
1027b4858:     	str	xzr, [x19, #0x10]
1027b485c:     	b	0x1027b4a58 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x284>
1027b4860:     	ldur	q0, [x24, #0x44]
1027b4864:     	ldur	q1, [x24, #0x54]
1027b4868:     	stp	q0, q1, [sp, #0x20]
1027b486c:     	ldur	q0, [x24, #0x64]
1027b4870:     	str	q0, [sp, #0x40]
1027b4874:     	ldur	q0, [x24, #0x70]
1027b4878:     	stur	q0, [sp, #0x4c]
1027b487c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027b4880:     	mov	w0, #0x100              ; =256
1027b4884:     	mov	w1, #0x8                ; =8
1027b4888:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027b488c:     	cbz	x0, 0x1027b4a98 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2c4>
1027b4890:     	ldp	q0, q1, [sp, #0x20]
1027b4894:     	stur	q0, [x0, #0x4]
1027b4898:     	strb	w20, [x0]
1027b489c:     	strh	w22, [x0, #0x2]
1027b48a0:     	stur	q1, [x0, #0x14]
1027b48a4:     	ldr	q0, [sp, #0x40]
1027b48a8:     	stur	q0, [x0, #0x24]
1027b48ac:     	ldur	q0, [sp, #0x4c]
1027b48b0:     	str	q0, [x0, #0x30]
1027b48b4:     	mov	w8, #0x4                ; =4
1027b48b8:     	stp	x8, x0, [sp, #0x8]
1027b48bc:     	mov	w8, #0x1                ; =1
1027b48c0:     	str	x8, [sp, #0x18]
1027b48c4:     	ldr	x23, [x21, #0x40]
1027b48c8:     	cbz	x23, 0x1027b4a48 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x274>
1027b48cc:     	ldp	x9, x26, [x21]
1027b48d0:     	ldp	x8, x27, [x21, #0x10]
1027b48d4:     	sub	x24, x29, #0x9c
1027b48d8:     	mov	w20, #0x1               ; =1
1027b48dc:     	mov	w25, #0x38              ; =56
1027b48e0:     	ldr	x21, [x21, #0x48]
1027b48e4:     	tbz	w9, #0x0, 0x1027b4a88 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2b4>
1027b48e8:     	cbz	x26, 0x1027b4904 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x130>
1027b48ec:     	ldrh	w9, [x26, #0x2ca]
1027b48f0:     	cmp	x27, x9
1027b48f4:     	b.hs	0x1027b4928 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x154>
1027b48f8:     	mov	x9, x26
1027b48fc:     	mov	x10, x27
1027b4900:     	b	0x1027b4948 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x174>
1027b4904:     	mov	x26, x8
1027b4908:     	cbz	x27, 0x1027b4918 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x144>
1027b490c:     	ldr	x26, [x26, #0x2d0]
1027b4910:     	subs	x27, x27, #0x1
1027b4914:     	b.ne	0x1027b490c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x138>
1027b4918:     	mov	x8, #0x0                ; =0
1027b491c:     	ldrh	w9, [x26, #0x2ca]
1027b4920:     	cmp	x27, x9
1027b4924:     	b.lo	0x1027b48f8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x124>
1027b4928:     	ldr	x9, [x26]
1027b492c:     	cbz	x9, 0x1027b4a78 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2a4>
1027b4930:     	add	x8, x8, #0x1
1027b4934:     	ldrh	w10, [x26, #0x2c8]
1027b4938:     	ldrh	w11, [x9, #0x2ca]
1027b493c:     	mov	x26, x9
1027b4940:     	cmp	w10, w11
1027b4944:     	b.hs	0x1027b4928 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x154>
1027b4948:     	add	x11, x9, x10, lsl #3
1027b494c:     	cbz	x8, 0x1027b496c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x198>
1027b4950:     	add	x12, x11, #0x2d8
1027b4954:     	ldr	x26, [x12]
1027b4958:     	add	x12, x26, #0x2d0
1027b495c:     	subs	x8, x8, #0x1
1027b4960:     	b.ne	0x1027b4954 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x180>
1027b4964:     	mov	x27, #0x0               ; =0
1027b4968:     	b	0x1027b4974 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x1a0>
1027b496c:     	add	x27, x10, #0x1
1027b4970:     	mov	x26, x9
1027b4974:     	sub	x23, x23, #0x1
1027b4978:     	ldr	w8, [x11, #0x8]
1027b497c:     	ldrb	w28, [x11, #0xc]
1027b4980:     	madd	x9, x10, x25, x9
1027b4984:     	ldrh	w22, [x11, #0xe]
1027b4988:     	ldr	w10, [x21]
1027b498c:     	ldp	q1, q0, [x9, #0x70]
1027b4990:     	ldr	x11, [x9, #0x90]
1027b4994:     	ldr	q2, [x9, #0x60]
1027b4998:     	stur	q2, [x24, #0x4]
1027b499c:     	stur	x11, [x24, #0x34]
1027b49a0:     	stur	q0, [x24, #0x24]
1027b49a4:     	stur	q1, [x24, #0x14]
1027b49a8:     	cmp	w8, w10
1027b49ac:     	b.eq	0x1027b49c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x1ec>
1027b49b0:     	mov	x8, #0x0                ; =0
1027b49b4:     	mov	w9, #0x1                ; =1
1027b49b8:     	cbnz	x23, 0x1027b48e4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x110>
1027b49bc:     	b	0x1027b4a48 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x274>
1027b49c0:     	add	x8, sp, #0x60
1027b49c4:     	ldur	q0, [x8, #0x44]
1027b49c8:     	ldur	q1, [x8, #0x54]
1027b49cc:     	stp	q0, q1, [sp, #0x60]
1027b49d0:     	ldur	q0, [x8, #0x64]
1027b49d4:     	str	q0, [sp, #0x80]
1027b49d8:     	ldur	q0, [x8, #0x70]
1027b49dc:     	stur	q0, [x8, #0x2c]
1027b49e0:     	ldr	x8, [sp, #0x8]
1027b49e4:     	cmp	x20, x8
1027b49e8:     	b.ne	0x1027b4a08 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x234>
1027b49ec:     	add	x0, sp, #0x8
1027b49f0:     	mov	x1, x20
1027b49f4:     	mov	w2, #0x1                ; =1
1027b49f8:     	mov	w3, #0x8                ; =8
1027b49fc:     	mov	w4, #0x40               ; =64
1027b4a00:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027b4a04:     	ldr	x0, [sp, #0x10]
1027b4a08:     	mov	x8, #0x0                ; =0
1027b4a0c:     	add	x9, x0, x20, lsl #6
1027b4a10:     	strb	w28, [x9]
1027b4a14:     	strh	w22, [x9, #0x2]
1027b4a18:     	ldp	q2, q0, [sp, #0x70]
1027b4a1c:     	add	x10, sp, #0x60
1027b4a20:     	ldur	q1, [x10, #0x2c]
1027b4a24:     	ldr	q3, [sp, #0x60]
1027b4a28:     	stur	q3, [x9, #0x4]
1027b4a2c:     	str	q1, [x9, #0x30]
1027b4a30:     	stur	q0, [x9, #0x24]
1027b4a34:     	stur	q2, [x9, #0x14]
1027b4a38:     	add	x20, x20, #0x1
1027b4a3c:     	str	x20, [sp, #0x18]
1027b4a40:     	mov	w9, #0x1                ; =1
1027b4a44:     	cbnz	x23, 0x1027b48e4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x110>
1027b4a48:     	ldur	q0, [sp, #0x8]
1027b4a4c:     	str	q0, [x19]
1027b4a50:     	ldr	x8, [sp, #0x18]
1027b4a54:     	str	x8, [x19, #0x10]
1027b4a58:     	ldp	x29, x30, [sp, #0x140]
1027b4a5c:     	ldp	x20, x19, [sp, #0x130]
1027b4a60:     	ldp	x22, x21, [sp, #0x120]
1027b4a64:     	ldp	x24, x23, [sp, #0x110]
1027b4a68:     	ldp	x26, x25, [sp, #0x100]
1027b4a6c:     	ldp	x28, x27, [sp, #0xf0]
1027b4a70:     	add	sp, sp, #0x150
1027b4a74:     	ret
1027b4a78:     	adrp	x0, 0x10803a000 <_anon.ca450c5141039434e7dc58a745d07839.2+0x20>
1027b4a7c:     	add	x0, x0, #0x7f0
1027b4a80:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1027b4a84:     	b	0x1027b4a94 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2c0>
1027b4a88:     	adrp	x0, 0x10803b000 <_anon.ca450c5141039434e7dc58a745d07839.499+0x310>
1027b4a8c:     	add	x0, x0, #0x510
1027b4a90:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1027b4a94:     	brk	#0x1
1027b4a98:     	mov	w0, #0x8                ; =8
1027b4a9c:     	mov	w1, #0x100              ; =256
1027b4aa0:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027b4aa4:     	b	0x1027b4aa8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2d4>
1027b4aa8:     	mov	x19, x0
1027b4aac:     	ldr	x8, [sp, #0x8]
1027b4ab0:     	cbz	x8, 0x1027b4ac4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2f0>
1027b4ab4:     	ldr	x0, [sp, #0x10]
1027b4ab8:     	lsl	x1, x8, #6
1027b4abc:     	mov	w2, #0x8                ; =8
1027b4ac0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027b4ac4:     	mov	x0, x19
1027b4ac8:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
1027b4acc:     	brk	#0x1
