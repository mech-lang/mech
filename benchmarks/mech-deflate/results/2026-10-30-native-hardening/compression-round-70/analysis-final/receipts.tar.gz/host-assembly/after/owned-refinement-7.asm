
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102923d70 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand>:
102923d70:     	stp	x28, x27, [sp, #-0x60]!
102923d74:     	stp	x26, x25, [sp, #0x10]
102923d78:     	stp	x24, x23, [sp, #0x20]
102923d7c:     	stp	x22, x21, [sp, #0x30]
102923d80:     	stp	x20, x19, [sp, #0x40]
102923d84:     	stp	x29, x30, [sp, #0x50]
102923d88:     	add	x29, sp, #0x50
102923d8c:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
102923d90:     	str	xzr, [sp]
102923d94:     	sub	sp, sp, #0x130
102923d98:     	mov	x21, x1
102923d9c:     	mov	x19, x0
102923da0:     	mov	x20, x8
102923da4:     	add	x23, sp, #0xc80
102923da8:     	add	x24, sp, #0x480
102923dac:     	ldr	x8, [x0, #0x1c8]
102923db0:     	cmp	x8, #0x2
102923db4:     	b.eq	0x1029243b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x644>
102923db8:     	ldr	x8, [x19, #0x488]
102923dbc:     	cmp	x8, #0x1
102923dc0:     	b.ne	0x1029243b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x644>
102923dc4:     	ldr	x10, [x21, #0x20]
102923dc8:     	ldr	x11, [x21, #0x58]
102923dcc:     	ldr	x12, [x2]
102923dd0:     	cmp	x10, #0x0
102923dd4:     	ccmp	x11, #0x0, #0x0, eq
102923dd8:     	ccmp	x12, #0x0, #0x0, eq
102923ddc:     	b.eq	0x1029243b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x644>
102923de0:     	mov	x22, x19
102923de4:     	ldr	x8, [x22, #0x88]!
102923de8:     	ldr	w9, [x22, #0x5f0]
102923dec:     	movi.2d	v0, #0000000000000000
102923df0:     	cbz	x8, 0x102923e8c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x11c>
102923df4:     	ldr	x13, [x19, #0x90]
102923df8:     	mov	x14, x8
102923dfc:     	ldrh	w17, [x14, #0x2ca]
102923e00:     	add	x16, x14, #0x50
102923e04:     	add	x0, x14, #0xe
102923e08:     	lsl	x1, x17, #3
102923e0c:     	mov	x15, #-0x1              ; =-1
102923e10:     	b	0x102923e34 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc4>
102923e14:     	mov	w3, #0x1                ; =1
102923e18:     	add	x0, x0, #0x8
102923e1c:     	add	x16, x16, #0x38
102923e20:     	add	x15, x15, #0x1
102923e24:     	sub	x1, x1, #0x8
102923e28:     	and	w3, w3, #0xff
102923e2c:     	cmp	w3, #0x1
102923e30:     	b.ne	0x102923e68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf8>
102923e34:     	cbz	x1, 0x102923e70 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x100>
102923e38:     	ldur	w3, [x0, #-0x6]
102923e3c:     	cmp	w9, w3
102923e40:     	cset	w3, hi
102923e44:     	csinv	w3, w3, wzr, hs
102923e48:     	b.ne	0x102923e18 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa8>
102923e4c:     	ldurb	w3, [x0, #-0x2]
102923e50:     	cbz	w3, 0x102923e14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa4>
102923e54:     	ldrh	w3, [x0]
102923e58:     	cmp	wzr, w3
102923e5c:     	cset	w3, hi
102923e60:     	csinv	w3, w3, wzr, hs
102923e64:     	b	0x102923e18 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa8>
102923e68:     	cbz	w3, 0x102923e88 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x118>
102923e6c:     	b	0x102923e74 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x104>
102923e70:     	mov	x15, x17
102923e74:     	cbz	x13, 0x102923e8c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x11c>
102923e78:     	add	x14, x14, x15, lsl #3
102923e7c:     	ldr	x14, [x14, #0x2d0]
102923e80:     	sub	x13, x13, #0x1
102923e84:     	b	0x102923dfc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x8c>
102923e88:     	ldr	q0, [x16]
102923e8c:     	ldr	x13, [x19, #0x480]
102923e90:     	ldr	x13, [x13, #0x198]
102923e94:     	cmp	x12, #0x1
102923e98:     	b.ne	0x102923ea8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x138>
102923e9c:     	ldp	x10, x14, [x2, #0x10]
102923ea0:     	adds	x10, x14, x10
102923ea4:     	b.hs	0x102924c34 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xec4>
102923ea8:     	ldr	x14, [x2, #0x8]
102923eac:     	tst	w12, #0x1
102923eb0:     	add	x12, x21, #0x50
102923eb4:     	add	x15, x2, #0x28
102923eb8:     	csel	x12, x15, x12, ne
102923ebc:     	ldr	x12, [x12]
102923ec0:     	csel	x11, x14, x11, ne
102923ec4:     	subs	x14, x10, x13
102923ec8:     	csel	x14, xzr, x14, lo
102923ecc:     	stp	x11, x13, [sp, #0x8]
102923ed0:     	stp	x14, x10, [sp, #0x18]
102923ed4:     	str	x12, [sp, #0x28]
102923ed8:     	stur	q0, [sp, #0x30]
102923edc:     	cbz	x8, 0x102923f94 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x224>
102923ee0:     	ldr	x10, [x19, #0x90]
102923ee4:     	ldrh	w13, [x8, #0x2ca]
102923ee8:     	add	x12, x8, #0x28
102923eec:     	add	x14, x8, #0xe
102923ef0:     	lsl	x15, x13, #3
102923ef4:     	mov	x11, #-0x1              ; =-1
102923ef8:     	b	0x102923f28 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1b8>
102923efc:     	ldrh	w16, [x14]
102923f00:     	cmp	wzr, w16
102923f04:     	cset	w16, hi
102923f08:     	csinv	w16, w16, wzr, hs
102923f0c:     	add	x14, x14, #0x8
102923f10:     	add	x12, x12, #0x38
102923f14:     	add	x11, x11, #0x1
102923f18:     	sub	x15, x15, #0x8
102923f1c:     	and	w16, w16, #0xff
102923f20:     	cmp	w16, #0x1
102923f24:     	b.ne	0x102923f54 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1e4>
102923f28:     	cbz	x15, 0x102923f5c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1ec>
102923f2c:     	ldur	w17, [x14, #-0x6]
102923f30:     	cmp	w9, w17
102923f34:     	cset	w16, hi
102923f38:     	csinv	w16, w16, wzr, hs
102923f3c:     	cmp	w17, w9
102923f40:     	b.ne	0x102923f0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x19c>
102923f44:     	ldurb	w16, [x14, #-0x2]
102923f48:     	cbnz	w16, 0x102923efc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x18c>
102923f4c:     	mov	w16, #0x1               ; =1
102923f50:     	b	0x102923f0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x19c>
102923f54:     	cbz	w16, 0x102923f74 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x204>
102923f58:     	b	0x102923f60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1f0>
102923f5c:     	mov	x11, x13
102923f60:     	cbz	x10, 0x102923f94 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x224>
102923f64:     	add	x8, x8, x11, lsl #3
102923f68:     	ldr	x8, [x8, #0x2d0]
102923f6c:     	sub	x10, x10, #0x1
102923f70:     	b	0x102923ee4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x174>
102923f74:     	ldur	q0, [sp, #0x8]
102923f78:     	ldur	q1, [sp, #0x18]
102923f7c:     	ldur	q2, [sp, #0x28]
102923f80:     	ldr	x8, [sp, #0x38]
102923f84:     	str	x8, [x12, #0x30]
102923f88:     	stp	q1, q2, [x12, #0x10]
102923f8c:     	str	q0, [x12]
102923f90:     	b	0x102923fbc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x24c>
102923f94:     	orr	x9, x9, #0x100000000
102923f98:     	str	x8, [sp, #0xd30]
102923f9c:     	str	xzr, [sp, #0xd38]
102923fa0:     	str	x11, [sp, #0xd40]
102923fa4:     	str	x22, [sp, #0xd48]
102923fa8:     	str	x9, [sp, #0xd50]
102923fac:     	add	x8, sp, #0x890
102923fb0:     	add	x0, sp, #0xd30
102923fb4:     	add	x1, sp, #0x8
102923fb8:     	bl	0x10291f264 <__RNvMs6_NtNtNtNtCsgKscDXrlV49_5alloc11collections5btree3map5entryINtB5_11VacantEntryTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB1o_18operation_contract10validation13PortDirectiontENtNtNtB1o_11memory_plan5model22CurrentMemoryFootprintE12insert_entryCs1qJAwyMG1lC_11mech_engine>
102923fbc:     	add	x22, x22, #0x5f0
102923fc0:     	ldp	x8, x9, [x19, #0x88]
102923fc4:     	ldr	x10, [x19, #0x98]
102923fc8:     	cmp	x8, #0x0
102923fcc:     	csel	x10, x10, xzr, ne
102923fd0:     	cset	w11, ne
102923fd4:     	str	x11, [sp, #0xd30]
102923fd8:     	str	xzr, [sp, #0xd38]
102923fdc:     	str	x8, [sp, #0xd40]
102923fe0:     	str	x9, [sp, #0xd48]
102923fe4:     	str	x11, [sp, #0xd50]
102923fe8:     	str	xzr, [sp, #0xd58]
102923fec:     	str	x8, [sp, #0xd60]
102923ff0:     	str	x9, [sp, #0xd68]
102923ff4:     	str	x10, [sp, #0xd70]
102923ff8:     	str	x22, [sp, #0xd78]
102923ffc:     	add	x25, sp, #0x40
102924000:     	add	x8, sp, #0x40
102924004:     	add	x0, sp, #0xd30
102924008:     	bl	0x102553cec <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_>
10292400c:     	ldr	x8, [x19, #0x488]
102924010:     	add	x9, x19, #0xa0
102924014:     	stp	xzr, x8, [sp, #0x88]
102924018:     	stp	x22, x9, [sp, #0x70]
10292401c:     	str	x25, [sp, #0x80]
102924020:     	add	x8, sp, #0x58
102924024:     	add	x0, sp, #0x70
102924028:     	bl	0x1025eba98 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0EE9from_iterB48_>
10292402c:     	add	x25, x19, #0x1c8
102924030:     	ldp	q1, q0, [x25, #0x60]
102924034:     	str	q0, [x24, #0x870]
102924038:     	ldp	q0, q2, [x25, #0x80]
10292403c:     	str	q0, [x24, #0x880]
102924040:     	str	q2, [x24, #0x890]
102924044:     	ldp	q2, q0, [x25, #0x20]
102924048:     	str	q0, [x24, #0x830]
10292404c:     	ldp	q0, q3, [x25, #0x40]
102924050:     	str	q0, [x24, #0x840]
102924054:     	str	q3, [x24, #0x850]
102924058:     	str	q1, [x24, #0x860]
10292405c:     	ldp	q0, q1, [x25]
102924060:     	str	q0, [x24, #0x800]
102924064:     	str	q1, [x24, #0x810]
102924068:     	ldp	x22, x4, [sp, #0x60]
10292406c:     	ldr	x8, [x25, #0xa0]
102924070:     	str	x8, [sp, #0xd20]
102924074:     	str	q2, [x24, #0x820]
102924078:     	str	xzr, [x19, #0x1c8]
10292407c:     	str	xzr, [x19, #0x1d8]
102924080:     	str	xzr, [x19, #0x1e8]
102924084:     	str	xzr, [x19, #0x1f8]
102924088:     	str	xzr, [x19, #0x208]
10292408c:     	str	xzr, [x19, #0x218]
102924090:     	str	xzr, [x19, #0x228]
102924094:     	str	xzr, [x19, #0x238]
102924098:     	str	xzr, [x19, #0x248]
10292409c:     	str	xzr, [x19, #0x258]
1029240a0:     	str	wzr, [x19, #0x268]
1029240a4:     	add	x8, sp, #0xd30
1029240a8:     	add	x0, x19, #0x1c8
1029240ac:     	add	x1, x19, #0x3d0
1029240b0:     	add	x2, sp, #0x40
1029240b4:     	mov	x3, x22
1029240b8:     	bl	0x102d72c20 <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6derive27resolve_current_call_memory>
1029240bc:     	ldr	q0, [x24, #0x870]
1029240c0:     	ldr	q1, [x24, #0x880]
1029240c4:     	ldr	q2, [x24, #0x890]
1029240c8:     	stp	q1, q2, [x25, #0x80]
1029240cc:     	ldr	x8, [sp, #0xd20]
1029240d0:     	str	x8, [x25, #0xa0]
1029240d4:     	ldr	q1, [x24, #0x830]
1029240d8:     	ldr	q2, [x24, #0x840]
1029240dc:     	ldr	q3, [x24, #0x850]
1029240e0:     	stp	q2, q3, [x25, #0x40]
1029240e4:     	ldr	q2, [x24, #0x860]
1029240e8:     	stp	q2, q0, [x25, #0x60]
1029240ec:     	ldr	q0, [x24, #0x800]
1029240f0:     	ldr	q2, [x24, #0x810]
1029240f4:     	stp	q0, q2, [x25]
1029240f8:     	ldr	q0, [x24, #0x820]
1029240fc:     	stp	q0, q1, [x25, #0x20]
102924100:     	ldr	x8, [sp, #0xd30]
102924104:     	cmp	x8, #0x2
102924108:     	b.ne	0x102924124 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x3b4>
10292410c:     	ldur	q0, [x23, #0xb8]
102924110:     	ldur	q1, [x23, #0xc8]
102924114:     	stp	q0, q1, [x24, #0x3e0]
102924118:     	ldur	q0, [x23, #0xd8]
10292411c:     	str	q0, [x24, #0x400]
102924120:     	b	0x102924178 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x408>
102924124:     	add	x8, sp, #0xd30
102924128:     	add	x0, sp, #0x890
10292412c:     	add	x1, x8, #0x38
102924130:     	mov	w2, #0x3b0              ; =944
102924134:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
102924138:     	ldr	x26, [x19, #0x1c8]
10292413c:     	add	x0, sp, #0x890
102924140:     	add	x1, x19, #0x200
102924144:     	mov	w2, #0x1d0              ; =464
102924148:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10292414c:     	ldur	q0, [x23, #0x8]
102924150:     	ldur	q1, [x23, #0x18]
102924154:     	stp	q0, q1, [x24, #0x3e0]
102924158:     	ldur	q0, [x23, #0x28]
10292415c:     	str	q0, [x24, #0x400]
102924160:     	add	x0, sp, #0x4b0
102924164:     	add	x1, sp, #0x890
102924168:     	mov	w2, #0x3b0              ; =944
10292416c:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
102924170:     	cmp	x26, #0x2
102924174:     	b.ne	0x1029241c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x454>
102924178:     	ldp	q0, q1, [x24, #0x3e0]
10292417c:     	stp	q0, q1, [x24]
102924180:     	ldr	q2, [x24, #0x400]
102924184:     	str	q2, [x24, #0x20]
102924188:     	stur	q0, [x20, #0x8]
10292418c:     	stur	q1, [x20, #0x18]
102924190:     	stur	q2, [x20, #0x28]
102924194:     	mov	w8, #0x2                ; =2
102924198:     	str	x8, [x20]
10292419c:     	ldr	x8, [sp, #0x58]
1029241a0:     	cbz	x8, 0x1029241b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x448>
1029241a4:     	lsl	x9, x8, #6
1029241a8:     	sub	x1, x9, x8, lsl #3
1029241ac:     	mov	x0, x22
1029241b0:     	mov	w2, #0x8                ; =8
1029241b4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029241b8:     	add	x0, sp, #0x40
1029241bc:     	bl	0x10257a2ac <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1029241c0:     	b	0x102924760 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x9f0>
1029241c4:     	add	x27, sp, #0x98
1029241c8:     	ldp	q0, q1, [x24, #0x3e0]
1029241cc:     	stp	q0, q1, [x24]
1029241d0:     	ldr	q0, [x24, #0x400]
1029241d4:     	str	q0, [x24, #0x20]
1029241d8:     	add	x8, sp, #0x98
1029241dc:     	add	x0, x8, #0x38
1029241e0:     	add	x1, sp, #0x4b0
1029241e4:     	mov	w2, #0x3b0              ; =944
1029241e8:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1029241ec:     	ldp	q0, q1, [x24]
1029241f0:     	stur	q0, [x27, #0x8]
1029241f4:     	stur	q1, [x27, #0x18]
1029241f8:     	ldr	q0, [x24, #0x20]
1029241fc:     	stur	q0, [x27, #0x28]
102924200:     	str	x26, [sp, #0x98]
102924204:     	ldr	x1, [x19, #0x5b0]
102924208:     	ldr	x2, [x19, #0x5b8]
10292420c:     	ldr	w5, [x19, #0x678]
102924210:     	add	x0, sp, #0xd30
102924214:     	add	x3, x19, #0x1c8
102924218:     	add	x4, sp, #0x98
10292421c:     	mov	x6, x19
102924220:     	bl	0x102923640 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn24refresh_turn_allocations>
102924224:     	ldrb	w8, [sp, #0xd30]
102924228:     	cmp	w8, #0x16
10292422c:     	b.ne	0x1029249d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc68>
102924230:     	ldr	x8, [sp, #0x430]
102924234:     	ldr	x9, [x19, #0xd8]
102924238:     	adds	x8, x9, x8
10292423c:     	b.hs	0x102924c40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xed0>
102924240:     	ldr	x9, [x19, #0xe0]
102924244:     	ldr	x10, [sp, #0x438]
102924248:     	adds	x9, x10, x9
10292424c:     	b.hs	0x102924c50 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xee0>
102924250:     	ldr	x10, [sp, #0x440]
102924254:     	ldr	x11, [x19, #0xe8]
102924258:     	adds	x10, x11, x10
10292425c:     	b.hs	0x102924c60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xef0>
102924260:     	ldr	x11, [sp, #0x448]
102924264:     	ldr	x12, [x19, #0xf0]
102924268:     	adds	x11, x12, x11
10292426c:     	b.hs	0x102924c70 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf00>
102924270:     	ldr	x12, [sp, #0x450]
102924274:     	ldr	x13, [x19, #0xf8]
102924278:     	adds	x12, x13, x12
10292427c:     	b.hs	0x102924c80 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf10>
102924280:     	ldr	x13, [sp, #0x458]
102924284:     	ldr	x14, [x19, #0x100]
102924288:     	adds	x13, x14, x13
10292428c:     	b.hs	0x102924c90 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf20>
102924290:     	ldr	x14, [sp, #0x460]
102924294:     	ldr	x15, [x19, #0x108]
102924298:     	adds	x14, x15, x14
10292429c:     	b.hs	0x102924ca0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf30>
1029242a0:     	ldr	x15, [sp, #0x468]
1029242a4:     	ldr	x16, [x19, #0x110]
1029242a8:     	adds	x15, x16, x15
1029242ac:     	b.hs	0x102924cb0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf40>
1029242b0:     	ldr	w16, [sp, #0x470]
1029242b4:     	ldr	w17, [x19, #0x118]
1029242b8:     	adds	w16, w17, w16
1029242bc:     	b.hs	0x102924cc0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf50>
1029242c0:     	ldr	x17, [sp, #0x410]
1029242c4:     	ldr	x0, [x19, #0xb8]
1029242c8:     	adds	x17, x0, x17
1029242cc:     	b.hs	0x102924cd0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf60>
1029242d0:     	ldr	x0, [sp, #0x418]
1029242d4:     	ldr	x1, [x19, #0xc0]
1029242d8:     	adds	x0, x1, x0
1029242dc:     	b.hs	0x102924ce0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf70>
1029242e0:     	ldr	x1, [sp, #0x420]
1029242e4:     	ldr	x2, [x19, #0xc8]
1029242e8:     	adds	x1, x2, x1
1029242ec:     	b.hs	0x102924cf0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf80>
1029242f0:     	ldr	x2, [sp, #0x428]
1029242f4:     	ldr	x3, [x19, #0xd0]
1029242f8:     	adds	x2, x3, x2
1029242fc:     	b.hs	0x102924d00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf90>
102924300:     	str	x17, [x19, #0x5f0]
102924304:     	str	x0, [x19, #0x5f8]
102924308:     	str	x1, [x19, #0x600]
10292430c:     	str	x2, [x19, #0x608]
102924310:     	str	x8, [x19, #0x610]
102924314:     	str	x9, [x19, #0x618]
102924318:     	str	x10, [x19, #0x620]
10292431c:     	str	x11, [x19, #0x628]
102924320:     	str	x12, [x19, #0x630]
102924324:     	str	x13, [x19, #0x638]
102924328:     	str	x14, [x19, #0x640]
10292432c:     	str	x15, [x19, #0x648]
102924330:     	str	w16, [x19, #0x650]
102924334:     	add	x0, sp, #0xd30
102924338:     	add	x1, sp, #0x98
10292433c:     	mov	w2, #0x3e8              ; =1000
102924340:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
102924344:     	ldr	x3, [x19, #0x5b0]
102924348:     	ldr	x4, [x19, #0x5b8]
10292434c:     	add	x0, sp, #0x890
102924350:     	add	x1, sp, #0xd30
102924354:     	add	x2, x19, #0x1c8
102924358:     	bl	0x102920ef0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15scope_turn_call>
10292435c:     	add	x0, sp, #0xd30
102924360:     	add	x1, sp, #0x890
102924364:     	mov	w2, #0x3e8              ; =1000
102924368:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10292436c:     	ldr	x8, [x25]
102924370:     	cmp	x8, #0x2
102924374:     	b.eq	0x102924380 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x610>
102924378:     	add	x0, x19, #0x1c8
10292437c:     	bl	0x1028ef6f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102924380:     	add	x0, x19, #0x1c8
102924384:     	add	x1, sp, #0xd30
102924388:     	mov	w2, #0x3e8              ; =1000
10292438c:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
102924390:     	ldr	x8, [sp, #0x58]
102924394:     	cbz	x8, 0x1029243ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x63c>
102924398:     	lsl	x9, x8, #6
10292439c:     	sub	x1, x9, x8, lsl #3
1029243a0:     	mov	x0, x22
1029243a4:     	mov	w2, #0x8                ; =8
1029243a8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029243ac:     	add	x0, sp, #0x40
1029243b0:     	bl	0x10257a2ac <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1029243b4:     	ldr	x8, [x19, #0xd8]
1029243b8:     	ldr	x9, [x21, #0x20]
1029243bc:     	adds	x3, x9, x8
1029243c0:     	b.hs	0x102924a00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc90>
1029243c4:     	ldr	x8, [x19, #0xe0]
1029243c8:     	ldr	x9, [x21, #0x28]
1029243cc:     	adds	x8, x9, x8
1029243d0:     	b.hs	0x102924a0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc9c>
1029243d4:     	ldr	x9, [x19, #0xe8]
1029243d8:     	ldr	x10, [x21, #0x30]
1029243dc:     	adds	x9, x10, x9
1029243e0:     	b.hs	0x102924a18 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xca8>
1029243e4:     	ldr	x10, [x19, #0xf0]
1029243e8:     	ldr	x11, [x21, #0x38]
1029243ec:     	adds	x10, x11, x10
1029243f0:     	b.hs	0x102924a28 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcb8>
1029243f4:     	ldr	x11, [x19, #0xf8]
1029243f8:     	ldr	x12, [x21, #0x40]
1029243fc:     	adds	x11, x12, x11
102924400:     	b.hs	0x102924a38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcc8>
102924404:     	ldr	x12, [x19, #0x100]
102924408:     	ldr	x13, [x21, #0x48]
10292440c:     	adds	x12, x13, x12
102924410:     	b.hs	0x102924a48 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcd8>
102924414:     	ldr	x13, [x19, #0x108]
102924418:     	ldr	x14, [x21, #0x50]
10292441c:     	adds	x13, x14, x13
102924420:     	b.hs	0x102924a58 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xce8>
102924424:     	ldr	x14, [x19, #0x110]
102924428:     	ldr	x15, [x21, #0x58]
10292442c:     	adds	x14, x15, x14
102924430:     	b.hs	0x102924a68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xcf8>
102924434:     	ldr	w15, [x19, #0x118]
102924438:     	ldr	w16, [x21, #0x60]
10292443c:     	adds	w15, w16, w15
102924440:     	b.hs	0x102924a78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd08>
102924444:     	ldr	x16, [x19, #0xb8]
102924448:     	ldr	x17, [x21]
10292444c:     	adds	x16, x17, x16
102924450:     	b.hs	0x102924a88 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd18>
102924454:     	ldr	x17, [x19, #0xc0]
102924458:     	ldr	x0, [x21, #0x8]
10292445c:     	adds	x17, x0, x17
102924460:     	b.hs	0x102924a98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd28>
102924464:     	ldr	x0, [x19, #0xc8]
102924468:     	ldr	x1, [x21, #0x10]
10292446c:     	adds	x0, x1, x0
102924470:     	b.hs	0x102924aa8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd38>
102924474:     	ldr	x1, [x19, #0xd0]
102924478:     	ldr	x2, [x21, #0x18]
10292447c:     	adds	x1, x2, x1
102924480:     	b.hs	0x102924ab8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd48>
102924484:     	ldr	x2, [x19, #0x5f0]
102924488:     	ldr	x4, [x19, #0x5f8]
10292448c:     	ldr	x5, [x19, #0x600]
102924490:     	ldr	x6, [x19, #0x608]
102924494:     	ldr	x7, [x19, #0x610]
102924498:     	ldr	x21, [x19, #0x618]
10292449c:     	ldr	x22, [x19, #0x620]
1029244a0:     	ldr	x25, [x19, #0x628]
1029244a4:     	ldr	x26, [x19, #0x630]
1029244a8:     	ldr	x27, [x19, #0x638]
1029244ac:     	ldr	x28, [x19, #0x640]
1029244b0:     	ldr	x30, [x19, #0x648]
1029244b4:     	ldr	w23, [x19, #0x650]
1029244b8:     	cmp	x3, x7
1029244bc:     	csel	x7, x3, x7, hi
1029244c0:     	cmp	x8, x21
1029244c4:     	csel	x8, x8, x21, hi
1029244c8:     	cmp	x9, x22
1029244cc:     	csel	x9, x9, x22, hi
1029244d0:     	cmp	x10, x25
1029244d4:     	csel	x10, x10, x25, hi
1029244d8:     	cmp	x11, x26
1029244dc:     	csel	x11, x11, x26, hi
1029244e0:     	cmp	x12, x27
1029244e4:     	csel	x12, x12, x27, hi
1029244e8:     	cmp	x13, x28
1029244ec:     	csel	x13, x13, x28, hi
1029244f0:     	cmp	x14, x30
1029244f4:     	csel	x14, x14, x30, hi
1029244f8:     	cmp	w15, w23
1029244fc:     	csel	w15, w15, w23, hi
102924500:     	add	x23, sp, #0xc80
102924504:     	cmp	x16, x2
102924508:     	csel	x16, x16, x2, hi
10292450c:     	cmp	x17, x4
102924510:     	csel	x17, x17, x4, hi
102924514:     	cmp	x0, x5
102924518:     	csel	x0, x0, x5, hi
10292451c:     	cmp	x1, x6
102924520:     	csel	x1, x1, x6, hi
102924524:     	str	x16, [x19, #0x5f0]
102924528:     	str	x17, [x19, #0x5f8]
10292452c:     	str	x0, [x19, #0x600]
102924530:     	str	x1, [x19, #0x608]
102924534:     	str	x7, [x19, #0x610]
102924538:     	str	x8, [x19, #0x618]
10292453c:     	str	x9, [x19, #0x620]
102924540:     	str	x10, [x19, #0x628]
102924544:     	str	x11, [x19, #0x630]
102924548:     	str	x12, [x19, #0x638]
10292454c:     	str	x13, [x19, #0x640]
102924550:     	str	x14, [x19, #0x648]
102924554:     	str	w15, [x19, #0x650]
102924558:     	ldr	x8, [x19, #0x658]
10292455c:     	cmp	x3, x8
102924560:     	csel	x8, x3, x8, hi
102924564:     	str	x8, [x19, #0x658]
102924568:     	ldr	x1, [x19, #0x5b0]
10292456c:     	ldr	x2, [x19, #0x5b8]
102924570:     	add	x0, sp, #0xd30
102924574:     	mov	x4, x3
102924578:     	bl	0x10292538c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn28grow_transaction_stage_total>
10292457c:     	ldrb	w8, [sp, #0xd30]
102924580:     	cmp	w8, #0x16
102924584:     	b.ne	0x1029245ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x87c>
102924588:     	ldr	x1, [x19, #0x5b0]
10292458c:     	ldr	x2, [x19, #0x5b8]
102924590:     	add	x0, sp, #0xd30
102924594:     	bl	0x102925958 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program17place_allocations>
102924598:     	ldrb	w8, [sp, #0xd30]
10292459c:     	cmp	w8, #0x16
1029245a0:     	b.ne	0x102924604 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x894>
1029245a4:     	ldr	x22, [sp, #0xd38]
1029245a8:     	ldr	x25, [sp, #0xd40]
1029245ac:     	ldr	x26, [x19, #0x5c8]
1029245b0:     	cbz	x26, 0x10292464c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x8dc>
1029245b4:     	ldr	x21, [x19, #0x5c0]
1029245b8:     	add	x27, x21, #0x10
1029245bc:     	mov	x28, x26
1029245c0:     	b	0x1029245d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x860>
1029245c4:     	add	x27, x27, #0x30
1029245c8:     	subs	x28, x28, #0x1
1029245cc:     	b.eq	0x102924638 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x8c8>
1029245d0:     	ldr	x8, [x27]
1029245d4:     	cbz	x8, 0x1029245c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x854>
1029245d8:     	ldur	x0, [x27, #-0x8]
1029245dc:     	lsl	x1, x8, #2
1029245e0:     	mov	w2, #0x4                ; =4
1029245e4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029245e8:     	b	0x1029245c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x854>
1029245ec:     	ldp	q0, q1, [x23, #0xb0]
1029245f0:     	stur	q0, [x20, #0x8]
1029245f4:     	stur	q1, [x20, #0x18]
1029245f8:     	ldr	q0, [x23, #0xd0]
1029245fc:     	stur	q0, [x20, #0x28]
102924600:     	b	0x102924758 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x9e8>
102924604:     	ldur	w9, [x23, #0xb1]
102924608:     	stur	w9, [x20, #0x9]
10292460c:     	ldr	w9, [sp, #0xd34]
102924610:     	str	w9, [x20, #0xc]
102924614:     	ldr	x9, [sp, #0xd38]
102924618:     	ldr	x10, [sp, #0xd40]
10292461c:     	ldur	q0, [x23, #0xc8]
102924620:     	str	q0, [x20, #0x20]
102924624:     	ldr	x11, [sp, #0xd58]
102924628:     	str	x11, [x20, #0x30]
10292462c:     	strb	w8, [x20, #0x8]
102924630:     	stp	x9, x10, [x20, #0x10]
102924634:     	b	0x102924758 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x9e8>
102924638:     	add	x8, x26, x26, lsl #1
10292463c:     	lsl	x1, x8, #4
102924640:     	mov	x0, x21
102924644:     	mov	w2, #0x8                ; =8
102924648:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10292464c:     	str	x22, [x19, #0x5c0]
102924650:     	str	x25, [x19, #0x5c8]
102924654:     	ldr	x8, [x19, #0x1c8]
102924658:     	cmp	x8, #0x2
10292465c:     	b.eq	0x102924694 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x924>
102924660:     	add	x0, x19, #0x5b0
102924664:     	bl	0x10275aabc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102924668:     	mov	x21, x0
10292466c:     	mov	x22, x1
102924670:     	ldr	x8, [x19, #0x508]
102924674:     	cbz	x8, 0x10292468c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x91c>
102924678:     	ldr	x0, [x19, #0x500]
10292467c:     	add	x8, x8, x8, lsl #1
102924680:     	lsl	x1, x8, #5
102924684:     	mov	w2, #0x8                ; =8
102924688:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10292468c:     	str	x21, [x19, #0x500]
102924690:     	str	x22, [x19, #0x508]
102924694:     	ldr	x21, [x19, #0x620]
102924698:     	ldr	x1, [x19, #0x5b0]
10292469c:     	ldr	x2, [x19, #0x5b8]
1029246a0:     	add	x0, sp, #0xd30
1029246a4:     	bl	0x1029211a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn17turn_storage_peak>
1029246a8:     	ldrb	w8, [sp, #0xd30]
1029246ac:     	cmp	w8, #0x16
1029246b0:     	b.ne	0x102924730 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x9c0>
1029246b4:     	mov	x9, #0x0                ; =0
1029246b8:     	add	x8, x19, #0x5f0
1029246bc:     	ldr	x10, [sp, #0xd38]
1029246c0:     	cmp	x10, x21
1029246c4:     	csel	x10, x10, x21, hi
1029246c8:     	str	x10, [x19, #0x620]
1029246cc:     	ldr	x10, [x19, #0x5b0]
1029246d0:     	ldr	x11, [x19, #0x5b8]
1029246d4:     	add	x11, x11, x11, lsl #1
1029246d8:     	lsl	x11, x11, #5
1029246dc:     	cmp	x11, x9
1029246e0:     	b.eq	0x10292478c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa1c>
1029246e4:     	add	x12, x10, x9
1029246e8:     	ldr	w12, [x12, #0x8]
1029246ec:     	add	x9, x9, #0x60
1029246f0:     	cmp	w12, #0x2
1029246f4:     	b.ne	0x1029246dc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x96c>
1029246f8:     	add	x12, x10, x9
1029246fc:     	ldur	x3, [x12, #-0x40]
102924700:     	subs	x11, x11, x9
102924704:     	b.eq	0x102924790 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa20>
102924708:     	mov	x13, #-0x5555555555555556 ; =-6148914691236517206
10292470c:     	movk	x13, #0xaaab
102924710:     	umulh	x14, x11, x13
102924714:     	lsr	x11, x14, #6
102924718:     	sub	x13, x11, #0x1
10292471c:     	ubfx	x11, x14, #6, #3
102924720:     	cmp	x13, #0x7
102924724:     	b.hs	0x102924850 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xae0>
102924728:     	mov	x12, #0x0               ; =0
10292472c:     	b	0x102924994 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc24>
102924730:     	ldur	w9, [x23, #0xb1]
102924734:     	stur	w9, [x20, #0x9]
102924738:     	ldr	w9, [sp, #0xd34]
10292473c:     	str	w9, [x20, #0xc]
102924740:     	ldr	x9, [sp, #0xd38]
102924744:     	ldp	q0, q1, [x23, #0xc0]
102924748:     	stur	q0, [x20, #0x18]
10292474c:     	stur	q1, [x20, #0x28]
102924750:     	strb	w8, [x20, #0x8]
102924754:     	str	x9, [x20, #0x10]
102924758:     	mov	w8, #0x2                ; =2
10292475c:     	str	x8, [x20]
102924760:     	mov	x0, x19
102924764:     	bl	0x1028ec5a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEBM_>
102924768:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
10292476c:     	add	sp, sp, #0x130
102924770:     	ldp	x29, x30, [sp, #0x50]
102924774:     	ldp	x20, x19, [sp, #0x40]
102924778:     	ldp	x22, x21, [sp, #0x30]
10292477c:     	ldp	x24, x23, [sp, #0x20]
102924780:     	ldp	x26, x25, [sp, #0x10]
102924784:     	ldp	x28, x27, [sp], #0x60
102924788:     	ret
10292478c:     	mov	x3, #0x0                ; =0
102924790:     	ldp	q1, q0, [x8, #0x20]
102924794:     	str	q0, [x24, #0x440]
102924798:     	ldp	q0, q2, [x8, #0x40]
10292479c:     	str	q0, [x24, #0x450]
1029247a0:     	str	q2, [x24, #0x460]
1029247a4:     	ldp	q0, q2, [x8]
1029247a8:     	str	q0, [x24, #0x410]
1029247ac:     	str	x3, [x19, #0x660]
1029247b0:     	ldr	w9, [x19, #0x678]
1029247b4:     	ldr	x8, [x8, #0x60]
1029247b8:     	str	x8, [sp, #0x8f0]
1029247bc:     	str	q2, [x24, #0x420]
1029247c0:     	str	q1, [x24, #0x430]
1029247c4:     	ldr	x2, [x19, #0x658]
1029247c8:     	ldp	q0, q1, [x19, #0x1a0]
1029247cc:     	stp	q0, q1, [x23, #0x130]
1029247d0:     	ldr	x8, [x19, #0x1c0]
1029247d4:     	str	x8, [sp, #0xdd0]
1029247d8:     	ldp	q0, q1, [x19, #0x160]
1029247dc:     	stp	q0, q1, [x23, #0xf0]
1029247e0:     	ldp	q1, q0, [x19, #0x180]
1029247e4:     	stp	q1, q0, [x23, #0x110]
1029247e8:     	ldp	q0, q1, [x19, #0x120]
1029247ec:     	stp	q0, q1, [x23, #0xb0]
1029247f0:     	ldp	q1, q0, [x19, #0x140]
1029247f4:     	mov	w8, #0x3                ; =3
1029247f8:     	orr	x0, x8, x9, lsl #32
1029247fc:     	stp	q1, q0, [x23, #0xd0]
102924800:     	add	x1, sp, #0x890
102924804:     	add	x4, sp, #0xd30
102924808:     	bl	0x102d1aebc <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget27evaluate_call_memory_budget>
10292480c:     	cmp	x1, #0x2
102924810:     	b.hs	0x102924adc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd6c>
102924814:     	mov	x25, x1
102924818:     	mov	x23, x0
10292481c:     	ldr	x8, [x19, #0x5e8]
102924820:     	cbz	x8, 0x102924834 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xac4>
102924824:     	ldr	x0, [x19, #0x5e0]
102924828:     	lsl	x1, x8, #5
10292482c:     	mov	w2, #0x8                ; =8
102924830:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102924834:     	str	x23, [x19, #0x5e0]
102924838:     	str	x25, [x19, #0x5e8]
10292483c:     	mov	x0, x20
102924840:     	mov	x1, x19
102924844:     	mov	w2, #0x680              ; =1664
102924848:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10292484c:     	b	0x102924768 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x9f8>
102924850:     	mov	x13, #0x0               ; =0
102924854:     	lsr	x14, x14, #9
102924858:     	neg	x14, x14, lsl #3
10292485c:     	b	0x102924870 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb00>
102924860:     	add	x12, x12, #0x300
102924864:     	sub	x13, x13, #0x8
102924868:     	cmp	x14, x13
10292486c:     	b.eq	0x10292498c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc1c>
102924870:     	ldr	w15, [x12, #0x8]
102924874:     	cmp	w15, #0x2
102924878:     	b.eq	0x1029248d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb64>
10292487c:     	ldr	w15, [x12, #0x68]
102924880:     	cmp	w15, #0x2
102924884:     	b.eq	0x1029248ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb7c>
102924888:     	ldr	w15, [x12, #0xc8]
10292488c:     	cmp	w15, #0x2
102924890:     	b.eq	0x102924904 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb94>
102924894:     	ldr	w15, [x12, #0x128]
102924898:     	cmp	w15, #0x2
10292489c:     	b.eq	0x10292491c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbac>
1029248a0:     	ldr	w15, [x12, #0x188]
1029248a4:     	cmp	w15, #0x2
1029248a8:     	b.eq	0x102924934 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbc4>
1029248ac:     	ldr	w15, [x12, #0x1e8]
1029248b0:     	cmp	w15, #0x2
1029248b4:     	b.eq	0x10292494c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbdc>
1029248b8:     	ldr	w15, [x12, #0x248]
1029248bc:     	cmp	w15, #0x2
1029248c0:     	b.eq	0x102924964 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xbf4>
1029248c4:     	ldr	w15, [x12, #0x2a8]
1029248c8:     	cmp	w15, #0x2
1029248cc:     	b.ne	0x102924860 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xaf0>
1029248d0:     	b	0x10292497c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc0c>
1029248d4:     	ldr	x15, [x12, #0x20]
1029248d8:     	cmp	x3, x15
1029248dc:     	csel	x3, x3, x15, hi
1029248e0:     	ldr	w15, [x12, #0x68]
1029248e4:     	cmp	w15, #0x2
1029248e8:     	b.ne	0x102924888 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb18>
1029248ec:     	ldr	x15, [x12, #0x80]
1029248f0:     	cmp	x3, x15
1029248f4:     	csel	x3, x3, x15, hi
1029248f8:     	ldr	w15, [x12, #0xc8]
1029248fc:     	cmp	w15, #0x2
102924900:     	b.ne	0x102924894 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb24>
102924904:     	ldr	x15, [x12, #0xe0]
102924908:     	cmp	x3, x15
10292490c:     	csel	x3, x3, x15, hi
102924910:     	ldr	w15, [x12, #0x128]
102924914:     	cmp	w15, #0x2
102924918:     	b.ne	0x1029248a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb30>
10292491c:     	ldr	x15, [x12, #0x140]
102924920:     	cmp	x3, x15
102924924:     	csel	x3, x3, x15, hi
102924928:     	ldr	w15, [x12, #0x188]
10292492c:     	cmp	w15, #0x2
102924930:     	b.ne	0x1029248ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb3c>
102924934:     	ldr	x15, [x12, #0x1a0]
102924938:     	cmp	x3, x15
10292493c:     	csel	x3, x3, x15, hi
102924940:     	ldr	w15, [x12, #0x1e8]
102924944:     	cmp	w15, #0x2
102924948:     	b.ne	0x1029248b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb48>
10292494c:     	ldr	x15, [x12, #0x200]
102924950:     	cmp	x3, x15
102924954:     	csel	x3, x3, x15, hi
102924958:     	ldr	w15, [x12, #0x248]
10292495c:     	cmp	w15, #0x2
102924960:     	b.ne	0x1029248c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xb54>
102924964:     	ldr	x15, [x12, #0x260]
102924968:     	cmp	x3, x15
10292496c:     	csel	x3, x3, x15, hi
102924970:     	ldr	w15, [x12, #0x2a8]
102924974:     	cmp	w15, #0x2
102924978:     	b.ne	0x102924860 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xaf0>
10292497c:     	ldr	x15, [x12, #0x2c0]
102924980:     	cmp	x3, x15
102924984:     	csel	x3, x3, x15, hi
102924988:     	b	0x102924860 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xaf0>
10292498c:     	cbz	x11, 0x102924790 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa20>
102924990:     	neg	x12, x13
102924994:     	add	x12, x12, x12, lsl #1
102924998:     	lsl	x12, x12, #5
10292499c:     	add	x11, x11, x11, lsl #1
1029249a0:     	lsl	x11, x11, #5
1029249a4:     	b	0x1029249b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc44>
1029249a8:     	add	x12, x12, #0x60
1029249ac:     	subs	x11, x11, #0x60
1029249b0:     	b.eq	0x102924790 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xa20>
1029249b4:     	add	x13, x10, x12
1029249b8:     	add	x13, x13, x9
1029249bc:     	ldr	w14, [x13, #0x8]
1029249c0:     	cmp	w14, #0x2
1029249c4:     	b.ne	0x1029249a8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc38>
1029249c8:     	ldr	x13, [x13, #0x20]
1029249cc:     	cmp	x3, x13
1029249d0:     	csel	x3, x3, x13, hi
1029249d4:     	b	0x1029249a8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc38>
1029249d8:     	ldp	q0, q1, [x23, #0xb0]
1029249dc:     	stur	q0, [x20, #0x8]
1029249e0:     	stur	q1, [x20, #0x18]
1029249e4:     	ldr	q0, [x23, #0xd0]
1029249e8:     	stur	q0, [x20, #0x28]
1029249ec:     	mov	w8, #0x2                ; =2
1029249f0:     	str	x8, [x20]
1029249f4:     	add	x0, sp, #0x98
1029249f8:     	bl	0x1028ef6f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1029249fc:     	b	0x10292419c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x42c>
102924a00:     	adrp	x8, 0x107693000 <_anon.cb680a97e9a354a551d115f49642c55e.630+0xbc5>
102924a04:     	add	x8, x8, #0xc20
102924a08:     	b	0x102924a80 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd10>
102924a0c:     	adrp	x8, 0x107693000 <_anon.cb680a97e9a354a551d115f49642c55e.630+0xbc5>
102924a10:     	add	x8, x8, #0xc30
102924a14:     	b	0x102924a80 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd10>
102924a18:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a1c:     	add	x8, x8, #0xb93
102924a20:     	mov	w9, #0xf                ; =15
102924a24:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a28:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a2c:     	add	x8, x8, #0xba2
102924a30:     	mov	w9, #0x16               ; =22
102924a34:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a38:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a3c:     	add	x8, x8, #0xbb8
102924a40:     	mov	w9, #0xc                ; =12
102924a44:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a48:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a4c:     	add	x8, x8, #0xbc4
102924a50:     	mov	w9, #0xe                ; =14
102924a54:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a58:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a5c:     	add	x8, x8, #0xbd2
102924a60:     	mov	w9, #0xe                ; =14
102924a64:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a68:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a6c:     	add	x8, x8, #0xbe0
102924a70:     	mov	w9, #0xf                ; =15
102924a74:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a78:     	adrp	x8, 0x107693000 <_anon.cb680a97e9a354a551d115f49642c55e.630+0xbc5>
102924a7c:     	add	x8, x8, #0xc40
102924a80:     	mov	w9, #0x10               ; =16
102924a84:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a88:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a8c:     	add	x8, x8, #0xbef
102924a90:     	mov	w9, #0xf                ; =15
102924a94:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924a98:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924a9c:     	add	x8, x8, #0xbfe
102924aa0:     	mov	w9, #0xc                ; =12
102924aa4:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924aa8:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924aac:     	add	x8, x8, #0xc0a
102924ab0:     	mov	w9, #0x15               ; =21
102924ab4:     	b	0x102924ac4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd54>
102924ab8:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924abc:     	add	x8, x8, #0xc1f
102924ac0:     	mov	w9, #0x13               ; =19
102924ac4:     	stp	x8, x9, [x20, #0x10]
102924ac8:     	str	x3, [x20, #0x28]
102924acc:     	adrp	x8, 0x10756c000 <_anon.fca2c70188ab11a390475b30678003d9.79+0x121>
102924ad0:     	ldr	q0, [x8, #0x200]
102924ad4:     	str	q0, [x20]
102924ad8:     	b	0x102924760 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x9f0>
102924adc:     	mov	x21, x0
102924ae0:     	mov	x22, x1
102924ae4:     	cmp	x1, #0x15
102924ae8:     	b.hs	0x102924d3c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfcc>
102924aec:     	sub	x3, x29, #0x61
102924af0:     	mov	x0, x21
102924af4:     	mov	x1, x22
102924af8:     	mov	w2, #0x1                ; =1
102924afc:     	bl	0x102a6f470 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYB1m_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
102924b00:     	mov	x24, #0x0               ; =0
102924b04:     	mov	x23, #0x0               ; =0
102924b08:     	sub	x25, x22, #0x1
102924b0c:     	mov	x8, x21
102924b10:     	b	0x102924b24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xdb4>
102924b14:     	add	x23, x23, #0x20
102924b18:     	add	x24, x24, #0x1
102924b1c:     	cmp	x25, x24
102924b20:     	b.eq	0x102924c28 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xeb8>
102924b24:     	add	x9, x8, x23
102924b28:     	ldr	x10, [x9, #0x28]
102924b2c:     	ldr	x11, [x9, #0x8]
102924b30:     	cmp	x10, x11
102924b34:     	b.ne	0x102924b14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xda4>
102924b38:     	ldr	x10, [x9, #0x30]
102924b3c:     	ldr	x11, [x9, #0x10]
102924b40:     	cmp	x10, x11
102924b44:     	b.ne	0x102924b14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xda4>
102924b48:     	add	x0, x9, #0x20
102924b4c:     	add	x1, x21, x23
102924b50:     	bl	0x1025e1858 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
102924b54:     	mov	x8, x21
102924b58:     	cbz	w0, 0x102924b14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xda4>
102924b5c:     	add	x9, x8, x23
102924b60:     	ldrb	w10, [x9, #0x38]
102924b64:     	ldrb	w11, [x9, #0x18]
102924b68:     	cmp	w10, w11
102924b6c:     	b.ne	0x102924b14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xda4>
102924b70:     	add	x8, x24, #0x2
102924b74:     	add	x25, x24, #0x1
102924b78:     	cmp	x8, x22
102924b7c:     	b.hs	0x102924be8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe78>
102924b80:     	add	x23, x9, #0x40
102924b84:     	sub	x8, x22, x24
102924b88:     	sub	x24, x8, #0x2
102924b8c:     	add	x26, x21, x25, lsl #5
102924b90:     	ldr	x8, [x23, #0x8]
102924b94:     	ldur	x9, [x26, #-0x18]
102924b98:     	cmp	x8, x9
102924b9c:     	b.ne	0x102924bd0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe60>
102924ba0:     	ldr	x8, [x23, #0x10]
102924ba4:     	ldur	x9, [x26, #-0x10]
102924ba8:     	cmp	x8, x9
102924bac:     	b.ne	0x102924bd0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe60>
102924bb0:     	sub	x1, x26, #0x20
102924bb4:     	mov	x0, x23
102924bb8:     	bl	0x1025e1858 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
102924bbc:     	cbz	w0, 0x102924bd0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe60>
102924bc0:     	ldrb	w8, [x23, #0x18]
102924bc4:     	ldurb	w9, [x26, #-0x8]
102924bc8:     	cmp	w8, w9
102924bcc:     	b.eq	0x102924bdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe6c>
102924bd0:     	ldp	q0, q1, [x23]
102924bd4:     	stp	q0, q1, [x26]
102924bd8:     	add	x25, x25, #0x1
102924bdc:     	add	x23, x23, #0x20
102924be0:     	subs	x24, x24, #0x1
102924be4:     	b.ne	0x102924b8c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xe1c>
102924be8:     	cmp	x22, x25
102924bec:     	b.ls	0x102924d1c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfac>
102924bf0:     	lsl	x22, x22, #5
102924bf4:     	cbz	x25, 0x102924d24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xfb4>
102924bf8:     	lsl	x24, x25, #5
102924bfc:     	mov	x0, x21
102924c00:     	mov	x1, x22
102924c04:     	mov	w2, #0x8                ; =8
102924c08:     	mov	x3, x24
102924c0c:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
102924c10:     	mov	x23, x0
102924c14:     	cbnz	x0, 0x10292481c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xaac>
102924c18:     	mov	w0, #0x8                ; =8
102924c1c:     	mov	x1, x24
102924c20:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102924c24:     	brk	#0x1
102924c28:     	mov	x25, x22
102924c2c:     	mov	x23, x8
102924c30:     	b	0x10292481c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xaac>
102924c34:     	adrp	x8, 0x107572000 <_anon.472922d491267d330da7ec551a7da895.7+0x110>
102924c38:     	ldr	q0, [x8, #0xc60]
102924c3c:     	b	0x102924ad4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd64>
102924c40:     	adrp	x8, 0x107693000 <_anon.cb680a97e9a354a551d115f49642c55e.630+0xbc5>
102924c44:     	add	x8, x8, #0xc20
102924c48:     	mov	w9, #0x10               ; =16
102924c4c:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924c50:     	adrp	x8, 0x107693000 <_anon.cb680a97e9a354a551d115f49642c55e.630+0xbc5>
102924c54:     	add	x8, x8, #0xc30
102924c58:     	mov	w9, #0x10               ; =16
102924c5c:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924c60:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924c64:     	add	x8, x8, #0xb93
102924c68:     	mov	w9, #0xf                ; =15
102924c6c:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924c70:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924c74:     	add	x8, x8, #0xba2
102924c78:     	mov	w9, #0x16               ; =22
102924c7c:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924c80:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924c84:     	add	x8, x8, #0xbb8
102924c88:     	mov	w9, #0xc                ; =12
102924c8c:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924c90:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924c94:     	add	x8, x8, #0xbc4
102924c98:     	mov	w9, #0xe                ; =14
102924c9c:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924ca0:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924ca4:     	add	x8, x8, #0xbd2
102924ca8:     	mov	w9, #0xe                ; =14
102924cac:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924cb0:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924cb4:     	add	x8, x8, #0xbe0
102924cb8:     	mov	w9, #0xf                ; =15
102924cbc:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924cc0:     	adrp	x8, 0x107693000 <_anon.cb680a97e9a354a551d115f49642c55e.630+0xbc5>
102924cc4:     	add	x8, x8, #0xc40
102924cc8:     	mov	w9, #0x10               ; =16
102924ccc:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924cd0:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924cd4:     	add	x8, x8, #0xbef
102924cd8:     	mov	w9, #0xf                ; =15
102924cdc:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924ce0:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924ce4:     	add	x8, x8, #0xbfe
102924ce8:     	mov	w9, #0xc                ; =12
102924cec:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924cf0:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924cf4:     	add	x8, x8, #0xc0a
102924cf8:     	mov	w9, #0x15               ; =21
102924cfc:     	b	0x102924d0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xf9c>
102924d00:     	adrp	x8, 0x107695000 <_anon.756aa6a551474c34fdbe62b86ce68d9e.686+0x63>
102924d04:     	add	x8, x8, #0xc1f
102924d08:     	mov	w9, #0x13               ; =19
102924d0c:     	mov	w10, #0x6               ; =6
102924d10:     	stp	x10, x8, [x20, #0x8]
102924d14:     	str	x9, [x20, #0x18]
102924d18:     	b	0x1029249ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xc7c>
102924d1c:     	mov	x23, x21
102924d20:     	b	0x10292481c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xaac>
102924d24:     	mov	w23, #0x8               ; =8
102924d28:     	mov	x0, x21
102924d2c:     	mov	x1, x22
102924d30:     	mov	w2, #0x8                ; =8
102924d34:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102924d38:     	b	0x10292481c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xaac>
102924d3c:     	sub	x2, x29, #0x61
102924d40:     	mov	x0, x21
102924d44:     	mov	x1, x22
102924d48:     	bl	0x102dc88e4 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EEB15_>
102924d4c:     	b	0x102924b00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xd90>
102924d50:     	mov	x20, x0
102924d54:     	mov	x0, x21
102924d58:     	mov	x1, x22
102924d5c:     	b	0x102924d6c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0xffc>
102924d60:     	mov	x20, x0
102924d64:     	lsl	x1, x22, #5
102924d68:     	mov	x0, x21
102924d6c:     	mov	w2, #0x8                ; =8
102924d70:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102924d74:     	b	0x102924dcc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x105c>
102924d78:     	mov	x20, x0
102924d7c:     	add	x0, x19, #0x1c8
102924d80:     	add	x1, sp, #0xd30
102924d84:     	mov	w2, #0x3e8              ; =1000
102924d88:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
102924d8c:     	b	0x102924da0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x1030>
102924d90:     	b	0x102924d9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x102c>
102924d94:     	mov	x20, x0
102924d98:     	b	0x102924dbc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x104c>
102924d9c:     	mov	x20, x0
102924da0:     	ldr	x8, [sp, #0x58]
102924da4:     	cbz	x8, 0x102924dbc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x104c>
102924da8:     	lsl	x9, x8, #6
102924dac:     	sub	x1, x9, x8, lsl #3
102924db0:     	mov	x0, x22
102924db4:     	mov	w2, #0x8                ; =8
102924db8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102924dbc:     	add	x0, sp, #0x40
102924dc0:     	bl	0x10257a2ac <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102924dc4:     	b	0x102924dcc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demand+0x105c>
102924dc8:     	mov	x20, x0
102924dcc:     	mov	x0, x19
102924dd0:     	bl	0x1028ec5a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn14TurnMemoryPlanEBM_>
102924dd4:     	mov	x0, x20
102924dd8:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
102924ddc:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
