
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102727ab4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_>:
102727ab4:     	sub	sp, sp, #0x50
102727ab8:     	stp	x20, x19, [sp, #0x40]
102727abc:     	ldp	x10, x11, [x0, #0x18]
102727ac0:     	ldp	x8, x9, [x1]
102727ac4:     	cmp	x10, x11
102727ac8:     	b.hs	0x102727c5c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x1a8>
102727acc:     	ldr	x12, [x1, #0x10]
102727ad0:     	ldp	x13, x14, [x0]
102727ad4:     	movi.2d	v0, #0000000000000000
102727ad8:     	mov	w15, #0x38              ; =56
102727adc:     	ldr	x16, [x0, #0x10]
102727ae0:     	b	0x102727b28 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x74>
102727ae4:     	ldp	q1, q2, [x3]
102727ae8:     	ldr	q3, [x3, #0x20]
102727aec:     	ldr	x17, [x3, #0x30]
102727af0:     	str	x17, [sp, #0x30]
102727af4:     	stp	q2, q3, [sp, #0x10]
102727af8:     	str	q1, [sp]
102727afc:     	add	x10, x10, #0x1
102727b00:     	madd	x17, x9, x15, x12
102727b04:     	ldp	q1, q2, [sp]
102727b08:     	stp	q1, q2, [x17]
102727b0c:     	ldr	q1, [sp, #0x20]
102727b10:     	str	q1, [x17, #0x20]
102727b14:     	ldr	x0, [sp, #0x30]
102727b18:     	str	x0, [x17, #0x30]
102727b1c:     	add	x9, x9, #0x1
102727b20:     	cmp	x10, x11
102727b24:     	b.eq	0x102727c5c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x1a8>
102727b28:     	ldr	x17, [x14]
102727b2c:     	cbz	x17, 0x102727bb8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x104>
102727b30:     	ldr	w0, [x13]
102727b34:     	ldr	x1, [x14, #0x8]
102727b38:     	add	x6, x17, #0x8
102727b3c:     	ldrh	w4, [x17, #0x2ca]
102727b40:     	add	x3, x17, #0x28
102727b44:     	lsl	x5, x4, #3
102727b48:     	mov	x2, #-0x1               ; =-1
102727b4c:     	cbz	x5, 0x102727ba0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0xec>
102727b50:     	ldr	w7, [x6]
102727b54:     	ldrh	w19, [x6, #0x4]
102727b58:     	add	x6, x6, #0x8
102727b5c:     	and	w20, w10, #0xffff
102727b60:     	cmp	w20, w19
102727b64:     	cset	w19, hi
102727b68:     	csinv	w19, w19, wzr, hs
102727b6c:     	cmp	w0, w7
102727b70:     	cset	w7, hi
102727b74:     	csinv	w7, w7, wzr, hs
102727b78:     	csel	w7, w19, w7, eq
102727b7c:     	add	x3, x3, #0x38
102727b80:     	add	x2, x2, #0x1
102727b84:     	sub	x5, x5, #0x8
102727b88:     	and	w7, w7, #0xff
102727b8c:     	cmp	w7, #0x1
102727b90:     	b.eq	0x102727b4c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x98>
102727b94:     	cbz	w7, 0x102727ae4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x30>
102727b98:     	cbnz	x1, 0x102727ba8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0xf4>
102727b9c:     	b	0x102727bb8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x104>
102727ba0:     	mov	x2, x4
102727ba4:     	cbz	x1, 0x102727bb8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x104>
102727ba8:     	add	x17, x17, x2, lsl #3
102727bac:     	ldr	x17, [x17, #0x2d0]
102727bb0:     	sub	x1, x1, #0x1
102727bb4:     	b	0x102727b38 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x84>
102727bb8:     	ldr	x17, [x16]
102727bbc:     	cbz	x17, 0x102727c4c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x198>
102727bc0:     	ldr	x0, [x16, #0x8]
102727bc4:     	add	x5, x17, #0x270
102727bc8:     	ldrh	w3, [x17, #0x29e]
102727bcc:     	sub	x2, x17, #0x30
102727bd0:     	lsl	x4, x3, #2
102727bd4:     	mov	x1, #-0x1               ; =-1
102727bd8:     	cbz	x4, 0x102727c24 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x170>
102727bdc:     	ldrb	w6, [x5]
102727be0:     	ldrh	w7, [x5, #0x2]
102727be4:     	add	x5, x5, #0x4
102727be8:     	and	w19, w10, #0xffff
102727bec:     	cmp	w19, w7
102727bf0:     	cset	w7, hi
102727bf4:     	csinv	w7, w7, wzr, hs
102727bf8:     	cmp	w6, #0x0
102727bfc:     	csinc	w6, w7, wzr, ne
102727c00:     	add	x2, x2, #0x38
102727c04:     	add	x1, x1, #0x1
102727c08:     	sub	x4, x4, #0x4
102727c0c:     	and	w6, w6, #0xff
102727c10:     	cmp	w6, #0x1
102727c14:     	b.eq	0x102727bd8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x124>
102727c18:     	cbz	w6, 0x102727c3c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x188>
102727c1c:     	cbnz	x0, 0x102727c2c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x178>
102727c20:     	b	0x102727c4c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x198>
102727c24:     	mov	x1, x3
102727c28:     	cbz	x0, 0x102727c4c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x198>
102727c2c:     	add	x17, x17, x1, lsl #3
102727c30:     	ldr	x17, [x17, #0x2a0]
102727c34:     	sub	x0, x0, #0x1
102727c38:     	b	0x102727bc4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x110>
102727c3c:     	ldp	q1, q2, [x2]
102727c40:     	ldr	q3, [x2, #0x20]
102727c44:     	ldr	x17, [x2, #0x30]
102727c48:     	b	0x102727af0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x3c>
102727c4c:     	str	xzr, [sp, #0x30]
102727c50:     	stp	q0, q0, [sp, #0x10]
102727c54:     	str	q0, [sp]
102727c58:     	b	0x102727afc <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x48>
102727c5c:     	str	x9, [x8]
102727c60:     	ldp	x20, x19, [sp, #0x40]
102727c64:     	add	sp, sp, #0x50
102727c68:     	ret
