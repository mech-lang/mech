
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001025941e8 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_>:
1025941e8:     	sub	sp, sp, #0xd0
1025941ec:     	stp	x22, x21, [sp, #0xa0]
1025941f0:     	stp	x20, x19, [sp, #0xb0]
1025941f4:     	stp	x29, x30, [sp, #0xc0]
1025941f8:     	add	x29, sp, #0xc0
1025941fc:     	mov	x19, x8
102594200:     	ldp	q0, q1, [x0, #0x20]
102594204:     	stp	q0, q1, [sp, #0x50]
102594208:     	ldr	q0, [x0, #0x40]
10259420c:     	str	q0, [sp, #0x70]
102594210:     	ldp	q1, q0, [x0]
102594214:     	stp	q1, q0, [sp, #0x30]
102594218:     	mov	x8, sp
10259421c:     	add	x0, sp, #0x30
102594220:     	bl	0x1027b47d4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_>
102594224:     	ldr	x21, [sp, #0x10]
102594228:     	cbz	x21, 0x1025942a0 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xb8>
10259422c:     	ldr	x20, [sp, #0x8]
102594230:     	sub	x8, x29, #0x21
102594234:     	str	x8, [sp, #0x30]
102594238:     	cmp	x21, #0x1
10259423c:     	b.ne	0x1025942d4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xec>
102594240:     	ldr	x22, [sp]
102594244:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102594248:     	mov	w0, #0x2a0              ; =672
10259424c:     	mov	w1, #0x8                ; =8
102594250:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102594254:     	cbz	x0, 0x1025942f4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x10c>
102594258:     	str	xzr, [x0]
10259425c:     	strh	wzr, [x0, #0x29e]
102594260:     	stp	x0, xzr, [sp, #0x18]
102594264:     	str	xzr, [sp, #0x28]
102594268:     	add	x8, x20, x21, lsl #6
10259426c:     	mov	w9, #0x3                ; =3
102594270:     	strb	w9, [sp, #0x30]
102594274:     	stp	x20, x20, [sp, #0x70]
102594278:     	stp	x22, x8, [sp, #0x80]
10259427c:     	add	x0, sp, #0x18
102594280:     	add	x1, sp, #0x30
102594284:     	add	x2, sp, #0x28
102594288:     	bl	0x10252fab4 <__RINvMNtNtNtCsgKscDXrlV49_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBW_6marker5OwnedTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1F_11memory_plan5model22CurrentMemoryFootprintNtB1g_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterB1y_B2Q_INtNtNtB9_3vec9into_iter8IntoIterTB1y_B2Q_EEENtNtB9_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
10259428c:     	ldp	x8, x9, [sp, #0x18]
102594290:     	ldr	x10, [sp, #0x28]
102594294:     	stp	x8, x9, [x19]
102594298:     	str	x10, [x19, #0x10]
10259429c:     	b	0x1025942c0 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xd8>
1025942a0:     	str	xzr, [x19]
1025942a4:     	str	xzr, [x19, #0x10]
1025942a8:     	ldr	x8, [sp]
1025942ac:     	cbz	x8, 0x1025942c0 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xd8>
1025942b0:     	ldr	x0, [sp, #0x8]
1025942b4:     	lsl	x1, x8, #6
1025942b8:     	mov	w2, #0x8                ; =8
1025942bc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1025942c0:     	ldp	x29, x30, [sp, #0xc0]
1025942c4:     	ldp	x20, x19, [sp, #0xb0]
1025942c8:     	ldp	x22, x21, [sp, #0xa0]
1025942cc:     	add	sp, sp, #0xd0
1025942d0:     	ret
1025942d4:     	cmp	x21, #0x15
1025942d8:     	b.hs	0x102594304 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x11c>
1025942dc:     	add	x3, sp, #0x30
1025942e0:     	mov	x0, x20
1025942e4:     	mov	x1, x21
1025942e8:     	mov	w2, #0x1                ; =1
1025942ec:     	bl	0x102909138 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_>
1025942f0:     	b	0x102594240 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x58>
1025942f4:     	mov	w0, #0x8                ; =8
1025942f8:     	mov	w1, #0x2a0              ; =672
1025942fc:     	bl	0x103a064ac <__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error>
102594300:     	brk	#0x1
102594304:     	add	x2, sp, #0x30
102594308:     	mov	x0, x20
10259430c:     	mov	x1, x21
102594310:     	bl	0x102788958 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>
102594314:     	b	0x102594240 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x58>
102594318:     	ldr	x22, [sp]
10259431c:     	cbnz	x22, 0x102594328 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x140>
102594320:     	b	0x102594340 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x158>
102594324:     	cbz	x22, 0x102594340 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x158>
102594328:     	lsl	x1, x22, #6
10259432c:     	mov	x19, x0
102594330:     	mov	x0, x20
102594334:     	mov	w2, #0x8                ; =8
102594338:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10259433c:     	mov	x0, x19
102594340:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
