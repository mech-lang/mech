
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a6ffc8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_>:
102a6ffc8:     	sub	x8, x2, #0x1
102a6ffcc:     	cmp	x8, x1
102a6ffd0:     	b.hs	0x102a700dc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x114>
102a6ffd4:     	cmp	x2, x1
102a6ffd8:     	b.eq	0x102a700d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x110>
102a6ffdc:     	sub	sp, sp, #0x40
102a6ffe0:     	add	x8, x0, x1, lsl #6
102a6ffe4:     	lsl	x9, x2, #6
102a6ffe8:     	add	x10, x0, x9
102a6ffec:     	mov	w11, #0xff              ; =255
102a6fff0:     	b	0x102a70030 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x68>
102a6fff4:     	mov	x15, x0
102a6fff8:     	strb	w13, [x15]
102a6fffc:     	strb	w14, [x15, #0x1]
102a70000:     	strh	w12, [x15, #0x2]
102a70004:     	ldp	q0, q1, [sp]
102a70008:     	stur	q0, [x15, #0x4]
102a7000c:     	stur	q1, [x15, #0x14]
102a70010:     	ldr	q0, [sp, #0x20]
102a70014:     	stur	q0, [x15, #0x24]
102a70018:     	ldur	q0, [sp, #0x2c]
102a7001c:     	str	q0, [x15, #0x30]
102a70020:     	add	x10, x10, #0x40
102a70024:     	add	x9, x9, #0x40
102a70028:     	cmp	x10, x8
102a7002c:     	b.eq	0x102a700d4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x10c>
102a70030:     	ldrb	w13, [x10]
102a70034:     	ldrh	w12, [x10, #0x2]
102a70038:     	ldurb	w14, [x10, #-0x40]
102a7003c:     	ldurh	w15, [x10, #-0x3e]
102a70040:     	cmp	w12, w15
102a70044:     	cset	w15, lo
102a70048:     	subs	w16, w13, w14
102a7004c:     	bics	wzr, w11, w16
102a70050:     	cset	w16, eq
102a70054:     	cmp	w13, w14
102a70058:     	csel	w14, w15, w16, eq
102a7005c:     	cmp	w14, #0x1
102a70060:     	b.ne	0x102a70020 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x58>
102a70064:     	ldrb	w14, [x10, #0x1]
102a70068:     	ldur	q0, [x10, #0x4]
102a7006c:     	ldur	q1, [x10, #0x14]
102a70070:     	stp	q0, q1, [sp]
102a70074:     	ldur	q0, [x10, #0x24]
102a70078:     	str	q0, [sp, #0x20]
102a7007c:     	ldr	q0, [x10, #0x30]
102a70080:     	stur	q0, [sp, #0x2c]
102a70084:     	mov	x15, x9
102a70088:     	add	x16, x0, x15
102a7008c:     	ldp	q0, q1, [x16, #-0x40]
102a70090:     	stp	q0, q1, [x16]
102a70094:     	ldp	q0, q1, [x16, #-0x20]
102a70098:     	stp	q0, q1, [x16, #0x20]
102a7009c:     	subs	x15, x15, #0x40
102a700a0:     	b.eq	0x102a6fff4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x2c>
102a700a4:     	ldurb	w17, [x16, #-0x80]
102a700a8:     	ldurh	w16, [x16, #-0x7e]
102a700ac:     	cmp	w12, w16
102a700b0:     	cset	w16, lo
102a700b4:     	subs	w1, w13, w17
102a700b8:     	bics	wzr, w11, w1
102a700bc:     	cset	w1, eq
102a700c0:     	cmp	w13, w17
102a700c4:     	csel	w16, w16, w1, eq
102a700c8:     	tbnz	w16, #0x0, 0x102a70088 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0xc0>
102a700cc:     	add	x15, x0, x15
102a700d0:     	b	0x102a6fff8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x30>
102a700d4:     	add	sp, sp, #0x40
102a700d8:     	ret
102a700dc:     	brk	#0x1
