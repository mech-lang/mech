
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102788958 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>:
102788958:     	stp	x26, x25, [sp, #-0x50]!
10278895c:     	stp	x24, x23, [sp, #0x10]
102788960:     	stp	x22, x21, [sp, #0x20]
102788964:     	stp	x20, x19, [sp, #0x30]
102788968:     	stp	x29, x30, [sp, #0x40]
10278896c:     	add	x29, sp, #0x40
102788970:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
102788974:     	str	xzr, [sp]
102788978:     	mov	x19, x2
10278897c:     	sub	x8, x1, x1, lsr #1
102788980:     	mov	w9, #0xe848             ; =59464
102788984:     	movk	w9, #0x1, lsl #16
102788988:     	cmp	x1, x9
10278898c:     	csel	x9, x1, x9, lo
102788990:     	cmp	x9, x8
102788994:     	csel	x24, x9, x8, hi
102788998:     	mov	w9, #0x30               ; =48
10278899c:     	cmp	x24, #0x30
1027889a0:     	csel	x23, x24, x9, hi
1027889a4:     	cmp	x24, #0x41
1027889a8:     	b.lo	0x1027889fc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xa4>
1027889ac:     	mov	x22, #0x0               ; =0
1027889b0:     	lsl	x21, x23, #6
1027889b4:     	lsr	x8, x8, #58
1027889b8:     	cbnz	x8, 0x102788a4c <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1027889bc:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1027889c0:     	cmp	x21, x8
1027889c4:     	b.hi	0x102788a4c <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1027889c8:     	mov	x20, x1
1027889cc:     	mov	x25, x0
1027889d0:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027889d4:     	mov	w22, #0x8               ; =8
1027889d8:     	mov	x0, x21
1027889dc:     	mov	w1, #0x8                ; =8
1027889e0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027889e4:     	mov	x1, x20
1027889e8:     	mov	x20, x0
1027889ec:     	cbz	x0, 0x102788a4c <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1027889f0:     	mov	x0, x25
1027889f4:     	mov	x3, x23
1027889f8:     	b	0x102788a04 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xac>
1027889fc:     	mov	x20, sp
102788a00:     	mov	w3, #0x40               ; =64
102788a04:     	cmp	x1, #0x41
102788a08:     	cset	w4, lo
102788a0c:     	mov	x2, x20
102788a10:     	mov	x5, x19
102788a14:     	bl	0x1029eb438 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_>
102788a18:     	cmp	x24, #0x40
102788a1c:     	b.ls	0x102788a30 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xd8>
102788a20:     	lsl	x1, x23, #6
102788a24:     	mov	x0, x20
102788a28:     	mov	w2, #0x8                ; =8
102788a2c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102788a30:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
102788a34:     	ldp	x29, x30, [sp, #0x40]
102788a38:     	ldp	x20, x19, [sp, #0x30]
102788a3c:     	ldp	x22, x21, [sp, #0x20]
102788a40:     	ldp	x24, x23, [sp, #0x10]
102788a44:     	ldp	x26, x25, [sp], #0x50
102788a48:     	ret
102788a4c:     	mov	x0, x22
102788a50:     	mov	x1, x21
102788a54:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102788a58:     	mov	x19, x0
102788a5c:     	cmp	x24, #0x40
102788a60:     	b.ls	0x102788a74 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0x11c>
102788a64:     	lsl	x1, x23, #6
102788a68:     	mov	x0, x20
102788a6c:     	mov	w2, #0x8                ; =8
102788a70:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102788a74:     	mov	x0, x19
102788a78:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
