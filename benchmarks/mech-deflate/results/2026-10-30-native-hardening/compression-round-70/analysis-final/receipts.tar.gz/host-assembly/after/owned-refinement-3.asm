
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001025c9774 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_>:
1025c9774:     	sub	sp, sp, #0x150
1025c9778:     	stp	x28, x27, [sp, #0xf0]
1025c977c:     	stp	x26, x25, [sp, #0x100]
1025c9780:     	stp	x24, x23, [sp, #0x110]
1025c9784:     	stp	x22, x21, [sp, #0x120]
1025c9788:     	stp	x20, x19, [sp, #0x130]
1025c978c:     	stp	x29, x30, [sp, #0x140]
1025c9790:     	add	x29, sp, #0x140
1025c9794:     	mov	x21, x0
1025c9798:     	mov	x19, x8
1025c979c:     	bl	0x102581b24 <__RNvXsk_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB5_4IterTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB18_18operation_contract10validation13PortDirectiontENtNtNtB18_11memory_plan5model22CurrentMemoryFootprintENtNtNtNtCsgDHHaSskbIF_4core4iter6traits8iterator8Iterator4nextCs1qJAwyMG1lC_11mech_engine>
1025c97a0:     	cbz	x0, 0x1025c97f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x7c>
1025c97a4:     	add	x24, sp, #0x60
1025c97a8:     	sub	x23, x29, #0x9c
1025c97ac:     	ldr	x8, [x21, #0x48]
1025c97b0:     	ldr	w9, [x0]
1025c97b4:     	ldrb	w20, [x0, #0x4]
1025c97b8:     	ldrh	w22, [x0, #0x6]
1025c97bc:     	ldr	w8, [x8]
1025c97c0:     	ldp	q0, q1, [x1]
1025c97c4:     	stur	q0, [x23, #0x4]
1025c97c8:     	stur	q1, [x23, #0x14]
1025c97cc:     	ldr	q0, [x1, #0x20]
1025c97d0:     	stur	q0, [x23, #0x24]
1025c97d4:     	ldr	x10, [x1, #0x30]
1025c97d8:     	stur	x10, [x23, #0x34]
1025c97dc:     	cmp	w9, w8
1025c97e0:     	b.eq	0x1025c9800 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x8c>
1025c97e4:     	mov	x0, x21
1025c97e8:     	bl	0x102581b24 <__RNvXsk_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB5_4IterTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB18_18operation_contract10validation13PortDirectiontENtNtNtB18_11memory_plan5model22CurrentMemoryFootprintENtNtNtNtCsgDHHaSskbIF_4core4iter6traits8iterator8Iterator4nextCs1qJAwyMG1lC_11mech_engine>
1025c97ec:     	cbnz	x0, 0x1025c97ac <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x38>
1025c97f0:     	mov	w8, #0x8                ; =8
1025c97f4:     	stp	xzr, x8, [x19]
1025c97f8:     	str	xzr, [x19, #0x10]
1025c97fc:     	b	0x1025c99f8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x284>
1025c9800:     	ldur	q0, [x24, #0x44]
1025c9804:     	ldur	q1, [x24, #0x54]
1025c9808:     	stp	q0, q1, [sp, #0x20]
1025c980c:     	ldur	q0, [x24, #0x64]
1025c9810:     	str	q0, [sp, #0x40]
1025c9814:     	ldur	q0, [x24, #0x70]
1025c9818:     	stur	q0, [sp, #0x4c]
1025c981c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1025c9820:     	mov	w0, #0x100              ; =256
1025c9824:     	mov	w1, #0x8                ; =8
1025c9828:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1025c982c:     	cbz	x0, 0x1025c9a38 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2c4>
1025c9830:     	ldp	q0, q1, [sp, #0x20]
1025c9834:     	stur	q0, [x0, #0x4]
1025c9838:     	strb	w20, [x0]
1025c983c:     	strh	w22, [x0, #0x2]
1025c9840:     	stur	q1, [x0, #0x14]
1025c9844:     	ldr	q0, [sp, #0x40]
1025c9848:     	stur	q0, [x0, #0x24]
1025c984c:     	ldur	q0, [sp, #0x4c]
1025c9850:     	str	q0, [x0, #0x30]
1025c9854:     	mov	w8, #0x4                ; =4
1025c9858:     	stp	x8, x0, [sp, #0x8]
1025c985c:     	mov	w8, #0x1                ; =1
1025c9860:     	str	x8, [sp, #0x18]
1025c9864:     	ldr	x23, [x21, #0x40]
1025c9868:     	cbz	x23, 0x1025c99e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x274>
1025c986c:     	ldp	x9, x26, [x21]
1025c9870:     	ldp	x8, x27, [x21, #0x10]
1025c9874:     	sub	x24, x29, #0x9c
1025c9878:     	mov	w20, #0x1               ; =1
1025c987c:     	mov	w25, #0x38              ; =56
1025c9880:     	ldr	x21, [x21, #0x48]
1025c9884:     	tbz	w9, #0x0, 0x1025c9a28 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2b4>
1025c9888:     	cbz	x26, 0x1025c98a4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x130>
1025c988c:     	ldrh	w9, [x26, #0x2ca]
1025c9890:     	cmp	x27, x9
1025c9894:     	b.hs	0x1025c98c8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x154>
1025c9898:     	mov	x9, x26
1025c989c:     	mov	x10, x27
1025c98a0:     	b	0x1025c98e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x174>
1025c98a4:     	mov	x26, x8
1025c98a8:     	cbz	x27, 0x1025c98b8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x144>
1025c98ac:     	ldr	x26, [x26, #0x2d0]
1025c98b0:     	subs	x27, x27, #0x1
1025c98b4:     	b.ne	0x1025c98ac <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x138>
1025c98b8:     	mov	x8, #0x0                ; =0
1025c98bc:     	ldrh	w9, [x26, #0x2ca]
1025c98c0:     	cmp	x27, x9
1025c98c4:     	b.lo	0x1025c9898 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x124>
1025c98c8:     	ldr	x9, [x26]
1025c98cc:     	cbz	x9, 0x1025c9a18 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2a4>
1025c98d0:     	add	x8, x8, #0x1
1025c98d4:     	ldrh	w10, [x26, #0x2c8]
1025c98d8:     	ldrh	w11, [x9, #0x2ca]
1025c98dc:     	mov	x26, x9
1025c98e0:     	cmp	w10, w11
1025c98e4:     	b.hs	0x1025c98c8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x154>
1025c98e8:     	add	x11, x9, x10, lsl #3
1025c98ec:     	cbz	x8, 0x1025c990c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x198>
1025c98f0:     	add	x12, x11, #0x2d8
1025c98f4:     	ldr	x26, [x12]
1025c98f8:     	add	x12, x26, #0x2d0
1025c98fc:     	subs	x8, x8, #0x1
1025c9900:     	b.ne	0x1025c98f4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x180>
1025c9904:     	mov	x27, #0x0               ; =0
1025c9908:     	b	0x1025c9914 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x1a0>
1025c990c:     	add	x27, x10, #0x1
1025c9910:     	mov	x26, x9
1025c9914:     	sub	x23, x23, #0x1
1025c9918:     	ldr	w8, [x11, #0x8]
1025c991c:     	ldrb	w28, [x11, #0xc]
1025c9920:     	madd	x9, x10, x25, x9
1025c9924:     	ldrh	w22, [x11, #0xe]
1025c9928:     	ldr	w10, [x21]
1025c992c:     	ldp	q1, q0, [x9, #0x70]
1025c9930:     	ldr	x11, [x9, #0x90]
1025c9934:     	ldr	q2, [x9, #0x60]
1025c9938:     	stur	q2, [x24, #0x4]
1025c993c:     	stur	x11, [x24, #0x34]
1025c9940:     	stur	q0, [x24, #0x24]
1025c9944:     	stur	q1, [x24, #0x14]
1025c9948:     	cmp	w8, w10
1025c994c:     	b.eq	0x1025c9960 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x1ec>
1025c9950:     	mov	x8, #0x0                ; =0
1025c9954:     	mov	w9, #0x1                ; =1
1025c9958:     	cbnz	x23, 0x1025c9884 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x110>
1025c995c:     	b	0x1025c99e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x274>
1025c9960:     	add	x8, sp, #0x60
1025c9964:     	ldur	q0, [x8, #0x44]
1025c9968:     	ldur	q1, [x8, #0x54]
1025c996c:     	stp	q0, q1, [sp, #0x60]
1025c9970:     	ldur	q0, [x8, #0x64]
1025c9974:     	str	q0, [sp, #0x80]
1025c9978:     	ldur	q0, [x8, #0x70]
1025c997c:     	stur	q0, [x8, #0x2c]
1025c9980:     	ldr	x8, [sp, #0x8]
1025c9984:     	cmp	x20, x8
1025c9988:     	b.ne	0x1025c99a8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x234>
1025c998c:     	add	x0, sp, #0x8
1025c9990:     	mov	x1, x20
1025c9994:     	mov	w2, #0x1                ; =1
1025c9998:     	mov	w3, #0x8                ; =8
1025c999c:     	mov	w4, #0x40               ; =64
1025c99a0:     	bl	0x1039f7b44 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1025c99a4:     	ldr	x0, [sp, #0x10]
1025c99a8:     	mov	x8, #0x0                ; =0
1025c99ac:     	add	x9, x0, x20, lsl #6
1025c99b0:     	strb	w28, [x9]
1025c99b4:     	strh	w22, [x9, #0x2]
1025c99b8:     	ldp	q2, q0, [sp, #0x70]
1025c99bc:     	add	x10, sp, #0x60
1025c99c0:     	ldur	q1, [x10, #0x2c]
1025c99c4:     	ldr	q3, [sp, #0x60]
1025c99c8:     	stur	q3, [x9, #0x4]
1025c99cc:     	str	q1, [x9, #0x30]
1025c99d0:     	stur	q0, [x9, #0x24]
1025c99d4:     	stur	q2, [x9, #0x14]
1025c99d8:     	add	x20, x20, #0x1
1025c99dc:     	str	x20, [sp, #0x18]
1025c99e0:     	mov	w9, #0x1                ; =1
1025c99e4:     	cbnz	x23, 0x1025c9884 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x110>
1025c99e8:     	ldur	q0, [sp, #0x8]
1025c99ec:     	str	q0, [x19]
1025c99f0:     	ldr	x8, [sp, #0x18]
1025c99f4:     	str	x8, [x19, #0x10]
1025c99f8:     	ldp	x29, x30, [sp, #0x140]
1025c99fc:     	ldp	x20, x19, [sp, #0x130]
1025c9a00:     	ldp	x22, x21, [sp, #0x120]
1025c9a04:     	ldp	x24, x23, [sp, #0x110]
1025c9a08:     	ldp	x26, x25, [sp, #0x100]
1025c9a0c:     	ldp	x28, x27, [sp, #0xf0]
1025c9a10:     	add	sp, sp, #0x150
1025c9a14:     	ret
1025c9a18:     	adrp	x0, 0x108038000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.717+0x298>
1025c9a1c:     	add	x0, x0, #0xd58
1025c9a20:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1025c9a24:     	b	0x1025c9a34 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2c0>
1025c9a28:     	adrp	x0, 0x108039000 <_anon.129022d05b1e456d72785029f108c8c0.267+0x218>
1025c9a2c:     	add	x0, x0, #0xa78
1025c9a30:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1025c9a34:     	brk	#0x1
1025c9a38:     	mov	w0, #0x8                ; =8
1025c9a3c:     	mov	w1, #0x100              ; =256
1025c9a40:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1025c9a44:     	b	0x1025c9a48 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2d4>
1025c9a48:     	mov	x19, x0
1025c9a4c:     	ldr	x8, [sp, #0x8]
1025c9a50:     	cbz	x8, 0x1025c9a64 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2f0>
1025c9a54:     	ldr	x0, [sp, #0x10]
1025c9a58:     	lsl	x1, x8, #6
1025c9a5c:     	mov	w2, #0x8                ; =8
1025c9a60:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1025c9a64:     	mov	x0, x19
1025c9a68:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
1025c9a6c:     	brk	#0x1
