
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001025a03bc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>:
1025a03bc:     	stp	x26, x25, [sp, #-0x50]!
1025a03c0:     	stp	x24, x23, [sp, #0x10]
1025a03c4:     	stp	x22, x21, [sp, #0x20]
1025a03c8:     	stp	x20, x19, [sp, #0x30]
1025a03cc:     	stp	x29, x30, [sp, #0x40]
1025a03d0:     	add	x29, sp, #0x40
1025a03d4:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
1025a03d8:     	str	xzr, [sp]
1025a03dc:     	mov	x19, x2
1025a03e0:     	sub	x8, x1, x1, lsr #1
1025a03e4:     	mov	w9, #0xe848             ; =59464
1025a03e8:     	movk	w9, #0x1, lsl #16
1025a03ec:     	cmp	x1, x9
1025a03f0:     	csel	x9, x1, x9, lo
1025a03f4:     	cmp	x9, x8
1025a03f8:     	csel	x24, x9, x8, hi
1025a03fc:     	mov	w9, #0x30               ; =48
1025a0400:     	cmp	x24, #0x30
1025a0404:     	csel	x23, x24, x9, hi
1025a0408:     	cmp	x24, #0x41
1025a040c:     	b.lo	0x1025a0460 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xa4>
1025a0410:     	mov	x22, #0x0               ; =0
1025a0414:     	lsl	x21, x23, #6
1025a0418:     	lsr	x8, x8, #58
1025a041c:     	cbnz	x8, 0x1025a04b0 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1025a0420:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1025a0424:     	cmp	x21, x8
1025a0428:     	b.hi	0x1025a04b0 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1025a042c:     	mov	x20, x1
1025a0430:     	mov	x25, x0
1025a0434:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1025a0438:     	mov	w22, #0x8               ; =8
1025a043c:     	mov	x0, x21
1025a0440:     	mov	w1, #0x8                ; =8
1025a0444:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1025a0448:     	mov	x1, x20
1025a044c:     	mov	x20, x0
1025a0450:     	cbz	x0, 0x1025a04b0 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1025a0454:     	mov	x0, x25
1025a0458:     	mov	x3, x23
1025a045c:     	b	0x1025a0468 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xac>
1025a0460:     	mov	x20, sp
1025a0464:     	mov	w3, #0x40               ; =64
1025a0468:     	cmp	x1, #0x41
1025a046c:     	cset	w4, lo
1025a0470:     	mov	x2, x20
1025a0474:     	mov	x5, x19
1025a0478:     	bl	0x10290818c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_>
1025a047c:     	cmp	x24, #0x40
1025a0480:     	b.ls	0x1025a0494 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xd8>
1025a0484:     	lsl	x1, x23, #6
1025a0488:     	mov	x0, x20
1025a048c:     	mov	w2, #0x8                ; =8
1025a0490:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1025a0494:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
1025a0498:     	ldp	x29, x30, [sp, #0x40]
1025a049c:     	ldp	x20, x19, [sp, #0x30]
1025a04a0:     	ldp	x22, x21, [sp, #0x20]
1025a04a4:     	ldp	x24, x23, [sp, #0x10]
1025a04a8:     	ldp	x26, x25, [sp], #0x50
1025a04ac:     	ret
1025a04b0:     	mov	x0, x22
1025a04b4:     	mov	x1, x21
1025a04b8:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1025a04bc:     	mov	x19, x0
1025a04c0:     	cmp	x24, #0x40
1025a04c4:     	b.ls	0x1025a04d8 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0x11c>
1025a04c8:     	lsl	x1, x23, #6
1025a04cc:     	mov	x0, x20
1025a04d0:     	mov	w2, #0x8                ; =8
1025a04d4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1025a04d8:     	mov	x0, x19
1025a04dc:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
