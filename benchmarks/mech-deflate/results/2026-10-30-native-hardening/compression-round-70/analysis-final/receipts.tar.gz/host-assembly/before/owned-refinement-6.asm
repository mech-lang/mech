
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010290f3f4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_>:
10290f3f4:     	sub	sp, sp, #0x70
10290f3f8:     	stp	x22, x21, [sp, #0x40]
10290f3fc:     	stp	x20, x19, [sp, #0x50]
10290f400:     	stp	x29, x30, [sp, #0x60]
10290f404:     	add	x29, sp, #0x60
10290f408:     	cmp	x1, #0x2
10290f40c:     	b.lo	0x10290fabc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6c8>
10290f410:     	add	x8, x1, #0x10
10290f414:     	cmp	x3, x8
10290f418:     	b.lo	0x10290fad4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6e0>
10290f41c:     	mov	x19, x2
10290f420:     	mov	x20, x0
10290f424:     	lsr	x8, x1, #1
10290f428:     	lsl	x9, x8, #6
10290f42c:     	cmp	x1, #0x7
10290f430:     	b.ls	0x10290f738 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x344>
10290f434:     	ldrb	w11, [x20, #0xc0]
10290f438:     	ldrh	w10, [x20, #0xc2]
10290f43c:     	ldrb	w12, [x20, #0x80]
10290f440:     	ldrh	w13, [x20, #0x82]
10290f444:     	cmp	w10, w13
10290f448:     	cset	w13, lo
10290f44c:     	subs	w14, w11, w12
10290f450:     	mov	w10, #0xff              ; =255
10290f454:     	bics	wzr, w10, w14
10290f458:     	cset	w14, eq
10290f45c:     	ldrb	w15, [x20, #0x40]
10290f460:     	ldrh	w16, [x20, #0x42]
10290f464:     	ldrb	w17, [x20]
10290f468:     	ldrh	w0, [x20, #0x2]
10290f46c:     	cmp	w11, w12
10290f470:     	csel	w11, w13, w14, eq
10290f474:     	cmp	w16, w0
10290f478:     	cset	w12, lo
10290f47c:     	subs	w13, w15, w17
10290f480:     	bics	wzr, w10, w13
10290f484:     	cset	w13, eq
10290f488:     	cmp	w15, w17
10290f48c:     	csel	w14, w12, w13, eq
10290f490:     	eor	w12, w14, #0x1
10290f494:     	add	x15, x20, x12, lsl #6
10290f498:     	cmp	w11, #0x0
10290f49c:     	mov	w12, #0x80              ; =128
10290f4a0:     	mov	w13, #0xc0              ; =192
10290f4a4:     	csel	x11, x13, x12, ne
10290f4a8:     	csel	x16, x12, x13, ne
10290f4ac:     	add	x16, x20, x16
10290f4b0:     	ldrb	w17, [x16]
10290f4b4:     	ldrh	w0, [x16, #0x2]
10290f4b8:     	ldrb	w2, [x15]
10290f4bc:     	ldrh	w3, [x15, #0x2]
10290f4c0:     	cmp	w0, w3
10290f4c4:     	cset	w0, lo
10290f4c8:     	subs	w3, w17, w2
10290f4cc:     	bics	wzr, w10, w3
10290f4d0:     	cset	w3, eq
10290f4d4:     	add	x14, x20, x14, lsl #6
10290f4d8:     	add	x11, x20, x11
10290f4dc:     	ldrb	w4, [x11]
10290f4e0:     	ldrh	w5, [x11, #0x2]
10290f4e4:     	ldrb	w6, [x14]
10290f4e8:     	ldrh	w7, [x14, #0x2]
10290f4ec:     	cmp	w17, w2
10290f4f0:     	csel	w17, w0, w3, eq
10290f4f4:     	cmp	w5, w7
10290f4f8:     	cset	w0, lo
10290f4fc:     	subs	w2, w4, w6
10290f500:     	bics	wzr, w10, w2
10290f504:     	cset	w2, eq
10290f508:     	cmp	w4, w6
10290f50c:     	csel	w0, w0, w2, eq
10290f510:     	cmp	w17, #0x0
10290f514:     	csel	x2, x11, x15, ne
10290f518:     	cmp	w0, #0x0
10290f51c:     	csel	x0, x11, x14, ne
10290f520:     	csel	x14, x14, x2, ne
10290f524:     	csel	x2, x15, x11, ne
10290f528:     	cmp	w17, #0x0
10290f52c:     	csel	x11, x15, x16, ne
10290f530:     	csel	x15, x16, x2, ne
10290f534:     	ldrb	w16, [x15]
10290f538:     	ldrh	w17, [x15, #0x2]
10290f53c:     	ldrb	w2, [x14]
10290f540:     	ldrh	w3, [x14, #0x2]
10290f544:     	cmp	w17, w3
10290f548:     	cset	w17, lo
10290f54c:     	subs	w3, w16, w2
10290f550:     	bics	wzr, w10, w3
10290f554:     	cset	w3, eq
10290f558:     	cmp	w16, w2
10290f55c:     	csel	w16, w17, w3, eq
10290f560:     	cmp	w16, #0x0
10290f564:     	csel	x16, x15, x14, ne
10290f568:     	csel	x14, x14, x15, ne
10290f56c:     	ldp	q0, q1, [x0]
10290f570:     	stp	q0, q1, [x19]
10290f574:     	ldp	q0, q1, [x0, #0x20]
10290f578:     	stp	q0, q1, [x19, #0x20]
10290f57c:     	ldp	q0, q1, [x16]
10290f580:     	stp	q0, q1, [x19, #0x40]
10290f584:     	ldp	q0, q1, [x16, #0x20]
10290f588:     	stp	q0, q1, [x19, #0x60]
10290f58c:     	ldp	q0, q1, [x14]
10290f590:     	ldp	q2, q3, [x14, #0x20]
10290f594:     	add	x14, x20, x9
10290f598:     	ldrb	w15, [x14, #0xc0]
10290f59c:     	ldrh	w16, [x14, #0xc2]
10290f5a0:     	ldrb	w17, [x14, #0x80]
10290f5a4:     	ldrh	w0, [x14, #0x82]
10290f5a8:     	cmp	w16, w0
10290f5ac:     	cset	w16, lo
10290f5b0:     	subs	w0, w15, w17
10290f5b4:     	bics	wzr, w10, w0
10290f5b8:     	cset	w0, eq
10290f5bc:     	ldrb	w2, [x14, #0x40]
10290f5c0:     	ldrh	w3, [x14, #0x42]
10290f5c4:     	ldrb	w4, [x14]
10290f5c8:     	ldrh	w5, [x14, #0x2]
10290f5cc:     	cmp	w15, w17
10290f5d0:     	csel	w15, w16, w0, eq
10290f5d4:     	cmp	w3, w5
10290f5d8:     	cset	w16, lo
10290f5dc:     	subs	w17, w2, w4
10290f5e0:     	bics	wzr, w10, w17
10290f5e4:     	cset	w17, eq
10290f5e8:     	cmp	w2, w4
10290f5ec:     	csel	w16, w16, w17, eq
10290f5f0:     	eor	w17, w16, #0x1
10290f5f4:     	cmp	w15, #0x0
10290f5f8:     	csel	x15, x12, x13, ne
10290f5fc:     	add	x15, x14, x15
10290f600:     	add	x17, x14, x17, lsl #6
10290f604:     	csel	x12, x13, x12, ne
10290f608:     	ldrb	w13, [x15]
10290f60c:     	ldrh	w0, [x15, #0x2]
10290f610:     	ldrb	w2, [x17]
10290f614:     	ldrh	w3, [x17, #0x2]
10290f618:     	cmp	w0, w3
10290f61c:     	cset	w0, lo
10290f620:     	subs	w3, w13, w2
10290f624:     	bics	wzr, w10, w3
10290f628:     	cset	w3, eq
10290f62c:     	add	x16, x14, x16, lsl #6
10290f630:     	add	x12, x14, x12
10290f634:     	ldrb	w14, [x12]
10290f638:     	ldrh	w4, [x12, #0x2]
10290f63c:     	ldrb	w5, [x16]
10290f640:     	ldrh	w6, [x16, #0x2]
10290f644:     	cmp	w13, w2
10290f648:     	csel	w13, w0, w3, eq
10290f64c:     	cmp	w4, w6
10290f650:     	cset	w0, lo
10290f654:     	subs	w2, w14, w5
10290f658:     	bics	wzr, w10, w2
10290f65c:     	cset	w2, eq
10290f660:     	cmp	w14, w5
10290f664:     	csel	w14, w0, w2, eq
10290f668:     	cmp	w13, #0x0
10290f66c:     	csel	x0, x12, x17, ne
10290f670:     	cmp	w14, #0x0
10290f674:     	csel	x14, x12, x16, ne
10290f678:     	csel	x16, x16, x0, ne
10290f67c:     	csel	x0, x17, x12, ne
10290f680:     	cmp	w13, #0x0
10290f684:     	csel	x12, x17, x15, ne
10290f688:     	csel	x13, x15, x0, ne
10290f68c:     	ldrb	w15, [x13]
10290f690:     	ldrh	w17, [x13, #0x2]
10290f694:     	ldrb	w0, [x16]
10290f698:     	ldrh	w2, [x16, #0x2]
10290f69c:     	cmp	w17, w2
10290f6a0:     	cset	w17, lo
10290f6a4:     	subs	w2, w15, w0
10290f6a8:     	bics	wzr, w10, w2
10290f6ac:     	cset	w10, eq
10290f6b0:     	stp	q2, q3, [x19, #0xa0]
10290f6b4:     	stp	q0, q1, [x19, #0x80]
10290f6b8:     	ldp	q0, q1, [x11]
10290f6bc:     	stp	q0, q1, [x19, #0xc0]
10290f6c0:     	ldp	q0, q1, [x11, #0x20]
10290f6c4:     	stp	q0, q1, [x19, #0xe0]
10290f6c8:     	add	x11, x19, x9
10290f6cc:     	cmp	w15, w0
10290f6d0:     	csel	w10, w17, w10, eq
10290f6d4:     	cmp	w10, #0x0
10290f6d8:     	csel	x10, x13, x16, ne
10290f6dc:     	csel	x13, x16, x13, ne
10290f6e0:     	ldp	q0, q1, [x14]
10290f6e4:     	stp	q0, q1, [x11]
10290f6e8:     	ldp	q0, q1, [x14, #0x20]
10290f6ec:     	stp	q0, q1, [x11, #0x20]
10290f6f0:     	ldp	q0, q1, [x10]
10290f6f4:     	stp	q0, q1, [x11, #0x40]
10290f6f8:     	ldp	q0, q1, [x10, #0x20]
10290f6fc:     	stp	q0, q1, [x11, #0x60]
10290f700:     	ldp	q0, q1, [x13]
10290f704:     	ldp	q2, q3, [x13, #0x20]
10290f708:     	stp	q2, q3, [x11, #0xa0]
10290f70c:     	stp	q0, q1, [x11, #0x80]
10290f710:     	ldp	q0, q1, [x12]
10290f714:     	stp	q0, q1, [x11, #0xc0]
10290f718:     	ldp	q0, q1, [x12, #0x20]
10290f71c:     	stp	q0, q1, [x11, #0xe0]
10290f720:     	mov	w11, #0x4               ; =4
10290f724:     	sub	x12, x1, x8
10290f728:     	lsl	x13, x11, #6
10290f72c:     	cmp	x11, x8
10290f730:     	b.lo	0x10290f774 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x380>
10290f734:     	b	0x10290f880 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
10290f738:     	ldp	q0, q1, [x20]
10290f73c:     	stp	q0, q1, [x19]
10290f740:     	ldp	q0, q1, [x20, #0x20]
10290f744:     	stp	q0, q1, [x19, #0x20]
10290f748:     	add	x10, x20, x9
10290f74c:     	add	x12, x19, x9
10290f750:     	ldp	q0, q1, [x10]
10290f754:     	stp	q0, q1, [x12]
10290f758:     	ldp	q0, q1, [x10, #0x20]
10290f75c:     	mov	w11, #0x1               ; =1
10290f760:     	stp	q0, q1, [x12, #0x20]
10290f764:     	sub	x12, x1, x8
10290f768:     	lsl	x13, x11, #6
10290f76c:     	cmp	x11, x8
10290f770:     	b.hs	0x10290f880 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
10290f774:     	mov	w10, #0xff              ; =255
10290f778:     	mov	x14, x13
10290f77c:     	mov	x15, x11
10290f780:     	b	0x10290f7c0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x3cc>
10290f784:     	mov	x2, x19
10290f788:     	strb	w17, [x2]
10290f78c:     	strb	w0, [x2, #0x1]
10290f790:     	strh	w16, [x2, #0x2]
10290f794:     	ldp	q0, q1, [sp]
10290f798:     	stur	q0, [x2, #0x4]
10290f79c:     	stur	q1, [x2, #0x14]
10290f7a0:     	ldr	q0, [sp, #0x20]
10290f7a4:     	stur	q0, [x2, #0x24]
10290f7a8:     	ldur	q0, [sp, #0x2c]
10290f7ac:     	str	q0, [x2, #0x30]
10290f7b0:     	add	x15, x15, #0x1
10290f7b4:     	add	x14, x14, #0x40
10290f7b8:     	cmp	x15, x8
10290f7bc:     	b.eq	0x10290f880 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
10290f7c0:     	lsl	x16, x15, #6
10290f7c4:     	add	x2, x20, x16
10290f7c8:     	add	x0, x19, x16
10290f7cc:     	ldp	q0, q1, [x2]
10290f7d0:     	stp	q0, q1, [x0]
10290f7d4:     	ldrb	w17, [x0]
10290f7d8:     	ldrh	w16, [x0, #0x2]
10290f7dc:     	ldurb	w3, [x0, #-0x40]
10290f7e0:     	ldurh	w4, [x0, #-0x3e]
10290f7e4:     	cmp	w16, w4
10290f7e8:     	cset	w4, lo
10290f7ec:     	subs	w5, w17, w3
10290f7f0:     	bics	wzr, w10, w5
10290f7f4:     	cset	w5, eq
10290f7f8:     	ldp	q0, q1, [x2, #0x20]
10290f7fc:     	stp	q0, q1, [x0, #0x20]
10290f800:     	cmp	w17, w3
10290f804:     	csel	w3, w4, w5, eq
10290f808:     	cmp	w3, #0x1
10290f80c:     	b.ne	0x10290f7b0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x3bc>
10290f810:     	ldrb	w0, [x0, #0x1]
10290f814:     	ldur	q0, [x2, #0x4]
10290f818:     	ldur	q1, [x2, #0x14]
10290f81c:     	stp	q0, q1, [sp]
10290f820:     	ldur	q0, [x2, #0x24]
10290f824:     	str	q0, [sp, #0x20]
10290f828:     	ldr	q0, [x2, #0x30]
10290f82c:     	stur	q0, [sp, #0x2c]
10290f830:     	mov	x2, x14
10290f834:     	add	x3, x19, x2
10290f838:     	ldp	q0, q1, [x3, #-0x40]
10290f83c:     	stp	q0, q1, [x3]
10290f840:     	ldp	q0, q1, [x3, #-0x20]
10290f844:     	stp	q0, q1, [x3, #0x20]
10290f848:     	subs	x2, x2, #0x40
10290f84c:     	b.eq	0x10290f784 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x390>
10290f850:     	ldurb	w4, [x3, #-0x80]
10290f854:     	ldurh	w3, [x3, #-0x7e]
10290f858:     	cmp	w16, w3
10290f85c:     	cset	w3, lo
10290f860:     	subs	w5, w17, w4
10290f864:     	bics	wzr, w10, w5
10290f868:     	cset	w5, eq
10290f86c:     	cmp	w17, w4
10290f870:     	csel	w3, w3, w5, eq
10290f874:     	tbnz	w3, #0x0, 0x10290f834 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x440>
10290f878:     	add	x2, x19, x2
10290f87c:     	b	0x10290f788 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x394>
10290f880:     	add	x10, x19, x9
10290f884:     	cmp	x11, x12
10290f888:     	b.hs	0x10290f9ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5b8>
10290f88c:     	add	x9, x20, x9
10290f890:     	mov	w14, #0x40              ; =64
10290f894:     	mov	w15, #0xff              ; =255
10290f898:     	mov	x16, x10
10290f89c:     	b	0x10290f8e0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4ec>
10290f8a0:     	mov	x3, x10
10290f8a4:     	strb	w0, [x3]
10290f8a8:     	strb	w2, [x3, #0x1]
10290f8ac:     	strh	w17, [x3, #0x2]
10290f8b0:     	ldp	q2, q0, [sp, #0x10]
10290f8b4:     	ldur	q1, [sp, #0x2c]
10290f8b8:     	ldr	q3, [sp]
10290f8bc:     	stur	q3, [x3, #0x4]
10290f8c0:     	str	q1, [x3, #0x30]
10290f8c4:     	stur	q0, [x3, #0x24]
10290f8c8:     	stur	q2, [x3, #0x14]
10290f8cc:     	add	x11, x11, #0x1
10290f8d0:     	add	x16, x16, #0x40
10290f8d4:     	sub	x14, x14, #0x40
10290f8d8:     	cmp	x11, x12
10290f8dc:     	b.eq	0x10290f9ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5b8>
10290f8e0:     	lsl	x17, x11, #6
10290f8e4:     	add	x3, x9, x17
10290f8e8:     	add	x2, x10, x17
10290f8ec:     	ldp	q0, q1, [x3]
10290f8f0:     	stp	q0, q1, [x2]
10290f8f4:     	ldrb	w0, [x2]
10290f8f8:     	ldrh	w17, [x2, #0x2]
10290f8fc:     	ldurb	w4, [x2, #-0x40]
10290f900:     	ldurh	w5, [x2, #-0x3e]
10290f904:     	cmp	w17, w5
10290f908:     	cset	w5, lo
10290f90c:     	subs	w6, w0, w4
10290f910:     	bics	wzr, w15, w6
10290f914:     	cset	w6, eq
10290f918:     	ldp	q0, q1, [x3, #0x20]
10290f91c:     	stp	q0, q1, [x2, #0x20]
10290f920:     	cmp	w0, w4
10290f924:     	csel	w4, w5, w6, eq
10290f928:     	cmp	w4, #0x1
10290f92c:     	b.ne	0x10290f8cc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4d8>
10290f930:     	ldrb	w2, [x2, #0x1]
10290f934:     	ldur	q0, [x3, #0x4]
10290f938:     	ldur	q1, [x3, #0x14]
10290f93c:     	stp	q0, q1, [sp]
10290f940:     	ldur	q0, [x3, #0x24]
10290f944:     	str	q0, [sp, #0x20]
10290f948:     	ldr	q0, [x3, #0x30]
10290f94c:     	stur	q0, [sp, #0x2c]
10290f950:     	mov	x4, x14
10290f954:     	mov	x3, x16
10290f958:     	add	x5, x3, x13
10290f95c:     	ldp	q0, q1, [x5, #-0x40]
10290f960:     	stp	q0, q1, [x5]
10290f964:     	ldp	q0, q1, [x5, #-0x20]
10290f968:     	stp	q0, q1, [x5, #0x20]
10290f96c:     	cmp	x13, x4
10290f970:     	b.eq	0x10290f8a0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4ac>
10290f974:     	ldurb	w6, [x5, #-0x80]
10290f978:     	ldurh	w5, [x5, #-0x7e]
10290f97c:     	cmp	w17, w5
10290f980:     	cset	w5, lo
10290f984:     	subs	w7, w0, w6
10290f988:     	bics	wzr, w15, w7
10290f98c:     	cset	w7, eq
10290f990:     	cmp	w0, w6
10290f994:     	csel	w5, w5, w7, eq
10290f998:     	sub	x3, x3, #0x40
10290f99c:     	add	x4, x4, #0x40
10290f9a0:     	tbnz	w5, #0x0, 0x10290f958 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x564>
10290f9a4:     	add	x3, x3, x13
10290f9a8:     	b	0x10290f8a4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4b0>
10290f9ac:     	lsl	x21, x1, #6
10290f9b0:     	sub	x13, x21, #0x40
10290f9b4:     	add	x12, x19, x13
10290f9b8:     	sub	x14, x10, #0x40
10290f9bc:     	mov	w15, #0xff              ; =255
10290f9c0:     	mov	x11, x20
10290f9c4:     	mov	x9, x19
10290f9c8:     	ldrb	w16, [x12]
10290f9cc:     	ldrh	w17, [x12, #0x2]
10290f9d0:     	ldrb	w0, [x14]
10290f9d4:     	ldrh	w2, [x14, #0x2]
10290f9d8:     	cmp	w17, w2
10290f9dc:     	cset	w17, lo
10290f9e0:     	subs	w2, w16, w0
10290f9e4:     	bics	wzr, w15, w2
10290f9e8:     	cset	w2, eq
10290f9ec:     	ldrb	w3, [x10]
10290f9f0:     	ldrh	w4, [x10, #0x2]
10290f9f4:     	ldrb	w5, [x9]
10290f9f8:     	ldrh	w6, [x9, #0x2]
10290f9fc:     	cmp	w16, w0
10290fa00:     	csel	w16, w17, w2, eq
10290fa04:     	cmp	w4, w6
10290fa08:     	cset	w17, lo
10290fa0c:     	subs	w0, w3, w5
10290fa10:     	bics	wzr, w15, w0
10290fa14:     	cset	w0, eq
10290fa18:     	add	x2, x20, x13
10290fa1c:     	cmp	w3, w5
10290fa20:     	csel	w17, w17, w0, eq
10290fa24:     	cmp	w17, #0x0
10290fa28:     	csel	x0, x10, x9, ne
10290fa2c:     	eor	w3, w17, #0x1
10290fa30:     	ldp	q1, q0, [x0, #0x20]
10290fa34:     	stp	q1, q0, [x11, #0x20]
10290fa38:     	ldp	q1, q0, [x0]
10290fa3c:     	stp	q1, q0, [x11], #0x40
10290fa40:     	add	x10, x10, x17, lsl #6
10290fa44:     	add	x9, x9, x3, lsl #6
10290fa48:     	cmp	w16, #0x0
10290fa4c:     	csel	x17, x14, x12, ne
10290fa50:     	ldp	q1, q0, [x17, #0x20]
10290fa54:     	stp	q1, q0, [x2, #0x20]
10290fa58:     	ldp	q1, q0, [x17]
10290fa5c:     	stp	q1, q0, [x2]
10290fa60:     	add	x12, x12, x16, lsl #6
10290fa64:     	sub	x12, x12, #0x40
10290fa68:     	sbfx	x16, x16, #0, #1
10290fa6c:     	add	x14, x14, x16, lsl #6
10290fa70:     	sub	x13, x13, #0x40
10290fa74:     	sub	x8, x8, #0x1
10290fa78:     	cbnz	x8, 0x10290f9c8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5d4>
10290fa7c:     	add	x8, x14, #0x40
10290fa80:     	add	x12, x12, #0x40
10290fa84:     	tbz	w1, #0x0, 0x10290fab0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6bc>
10290fa88:     	cmp	x9, x8
10290fa8c:     	csel	x13, x9, x10, lo
10290fa90:     	cset	w14, hs
10290fa94:     	cset	w15, lo
10290fa98:     	ldp	q0, q1, [x13]
10290fa9c:     	stp	q0, q1, [x11]
10290faa0:     	ldp	q0, q1, [x13, #0x20]
10290faa4:     	stp	q0, q1, [x11, #0x20]
10290faa8:     	add	x9, x9, x15, lsl #6
10290faac:     	add	x10, x10, x14, lsl #6
10290fab0:     	cmp	x9, x8
10290fab4:     	ccmp	x10, x12, #0x0, eq
10290fab8:     	b.ne	0x10290fad0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6dc>
10290fabc:     	ldp	x29, x30, [sp, #0x60]
10290fac0:     	ldp	x20, x19, [sp, #0x50]
10290fac4:     	ldp	x22, x21, [sp, #0x40]
10290fac8:     	add	sp, sp, #0x70
10290facc:     	ret
10290fad0:     	bl	0x103a069d0 <__RNvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort22panic_on_ord_violation>
10290fad4:     	brk	#0x1
10290fad8:     	mov	x22, x0
10290fadc:     	mov	x0, x20
10290fae0:     	mov	x1, x19
10290fae4:     	mov	x2, x21
10290fae8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
10290faec:     	mov	x0, x22
10290faf0:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
