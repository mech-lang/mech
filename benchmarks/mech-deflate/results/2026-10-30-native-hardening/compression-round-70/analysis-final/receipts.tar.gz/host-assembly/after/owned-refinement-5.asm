
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010271b8e4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_>:
10271b8e4:     	sub	sp, sp, #0x50
10271b8e8:     	stp	x20, x19, [sp, #0x40]
10271b8ec:     	ldp	x10, x11, [x0, #0x18]
10271b8f0:     	ldp	x8, x9, [x1]
10271b8f4:     	cmp	x10, x11
10271b8f8:     	b.hs	0x10271ba8c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x1a8>
10271b8fc:     	ldr	x12, [x1, #0x10]
10271b900:     	ldp	x13, x14, [x0]
10271b904:     	movi.2d	v0, #0000000000000000
10271b908:     	mov	w15, #0x38              ; =56
10271b90c:     	ldr	x16, [x0, #0x10]
10271b910:     	b	0x10271b958 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x74>
10271b914:     	ldp	q1, q2, [x3]
10271b918:     	ldr	q3, [x3, #0x20]
10271b91c:     	ldr	x17, [x3, #0x30]
10271b920:     	str	x17, [sp, #0x30]
10271b924:     	stp	q2, q3, [sp, #0x10]
10271b928:     	str	q1, [sp]
10271b92c:     	add	x10, x10, #0x1
10271b930:     	madd	x17, x9, x15, x12
10271b934:     	ldp	q1, q2, [sp]
10271b938:     	stp	q1, q2, [x17]
10271b93c:     	ldr	q1, [sp, #0x20]
10271b940:     	str	q1, [x17, #0x20]
10271b944:     	ldr	x0, [sp, #0x30]
10271b948:     	str	x0, [x17, #0x30]
10271b94c:     	add	x9, x9, #0x1
10271b950:     	cmp	x10, x11
10271b954:     	b.eq	0x10271ba8c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x1a8>
10271b958:     	ldr	x17, [x14]
10271b95c:     	cbz	x17, 0x10271b9e8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x104>
10271b960:     	ldr	w0, [x13]
10271b964:     	ldr	x1, [x14, #0x8]
10271b968:     	add	x6, x17, #0x8
10271b96c:     	ldrh	w4, [x17, #0x2ca]
10271b970:     	add	x3, x17, #0x28
10271b974:     	lsl	x5, x4, #3
10271b978:     	mov	x2, #-0x1               ; =-1
10271b97c:     	cbz	x5, 0x10271b9d0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0xec>
10271b980:     	ldr	w7, [x6]
10271b984:     	ldrh	w19, [x6, #0x4]
10271b988:     	add	x6, x6, #0x8
10271b98c:     	and	w20, w10, #0xffff
10271b990:     	cmp	w20, w19
10271b994:     	cset	w19, hi
10271b998:     	csinv	w19, w19, wzr, hs
10271b99c:     	cmp	w0, w7
10271b9a0:     	cset	w7, hi
10271b9a4:     	csinv	w7, w7, wzr, hs
10271b9a8:     	csel	w7, w19, w7, eq
10271b9ac:     	add	x3, x3, #0x38
10271b9b0:     	add	x2, x2, #0x1
10271b9b4:     	sub	x5, x5, #0x8
10271b9b8:     	and	w7, w7, #0xff
10271b9bc:     	cmp	w7, #0x1
10271b9c0:     	b.eq	0x10271b97c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x98>
10271b9c4:     	cbz	w7, 0x10271b914 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x30>
10271b9c8:     	cbnz	x1, 0x10271b9d8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0xf4>
10271b9cc:     	b	0x10271b9e8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x104>
10271b9d0:     	mov	x2, x4
10271b9d4:     	cbz	x1, 0x10271b9e8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x104>
10271b9d8:     	add	x17, x17, x2, lsl #3
10271b9dc:     	ldr	x17, [x17, #0x2d0]
10271b9e0:     	sub	x1, x1, #0x1
10271b9e4:     	b	0x10271b968 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x84>
10271b9e8:     	ldr	x17, [x16]
10271b9ec:     	cbz	x17, 0x10271ba7c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x198>
10271b9f0:     	ldr	x0, [x16, #0x8]
10271b9f4:     	add	x5, x17, #0x270
10271b9f8:     	ldrh	w3, [x17, #0x29e]
10271b9fc:     	sub	x2, x17, #0x30
10271ba00:     	lsl	x4, x3, #2
10271ba04:     	mov	x1, #-0x1               ; =-1
10271ba08:     	cbz	x4, 0x10271ba54 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x170>
10271ba0c:     	ldrb	w6, [x5]
10271ba10:     	ldrh	w7, [x5, #0x2]
10271ba14:     	add	x5, x5, #0x4
10271ba18:     	and	w19, w10, #0xffff
10271ba1c:     	cmp	w19, w7
10271ba20:     	cset	w7, hi
10271ba24:     	csinv	w7, w7, wzr, hs
10271ba28:     	cmp	w6, #0x0
10271ba2c:     	csinc	w6, w7, wzr, ne
10271ba30:     	add	x2, x2, #0x38
10271ba34:     	add	x1, x1, #0x1
10271ba38:     	sub	x4, x4, #0x4
10271ba3c:     	and	w6, w6, #0xff
10271ba40:     	cmp	w6, #0x1
10271ba44:     	b.eq	0x10271ba08 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x124>
10271ba48:     	cbz	w6, 0x10271ba6c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x188>
10271ba4c:     	cbnz	x0, 0x10271ba5c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x178>
10271ba50:     	b	0x10271ba7c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x198>
10271ba54:     	mov	x1, x3
10271ba58:     	cbz	x0, 0x10271ba7c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x198>
10271ba5c:     	add	x17, x17, x1, lsl #3
10271ba60:     	ldr	x17, [x17, #0x2a0]
10271ba64:     	sub	x0, x0, #0x1
10271ba68:     	b	0x10271b9f4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x110>
10271ba6c:     	ldp	q1, q2, [x2]
10271ba70:     	ldr	q3, [x2, #0x20]
10271ba74:     	ldr	x17, [x2, #0x30]
10271ba78:     	b	0x10271b920 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x3c>
10271ba7c:     	str	xzr, [sp, #0x30]
10271ba80:     	stp	q0, q0, [sp, #0x10]
10271ba84:     	str	q0, [sp]
10271ba88:     	b	0x10271b92c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands2_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2Q_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB5d_3VecB3T_E14extend_trustedBN_E0E0EB1x_+0x48>
10271ba8c:     	str	x9, [x8]
10271ba90:     	ldp	x20, x19, [sp, #0x40]
10271ba94:     	add	sp, sp, #0x50
10271ba98:     	ret
