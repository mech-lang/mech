
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a21be0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102a21be0:     	stp	x28, x27, [sp, #-0x60]!
102a21be4:     	stp	x26, x25, [sp, #0x10]
102a21be8:     	stp	x24, x23, [sp, #0x20]
102a21bec:     	stp	x22, x21, [sp, #0x30]
102a21bf0:     	stp	x20, x19, [sp, #0x40]
102a21bf4:     	stp	x29, x30, [sp, #0x50]
102a21bf8:     	add	x29, sp, #0x50
102a21bfc:     	sub	sp, sp, #0x1e0
102a21c00:     	mov	x24, x1
102a21c04:     	mov	x28, x0
102a21c08:     	add	x0, sp, #0xf8
102a21c0c:     	add	x1, x1, #0x208
102a21c10:     	bl	0x102a236cc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102a21c14:     	add	x0, x24, #0x2a8
102a21c18:     	bl	0x102766c98 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a21c1c:     	mov	x23, x0
102a21c20:     	mov	x27, x1
102a21c24:     	stp	x0, x1, [x29, #-0x98]
102a21c28:     	add	x0, x24, #0x2b8
102a21c2c:     	bl	0x102766c98 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a21c30:     	mov	x19, x0
102a21c34:     	mov	x20, x1
102a21c38:     	stp	x0, x1, [x29, #-0x88]
102a21c3c:     	add	x0, x24, #0x2c8
102a21c40:     	bl	0x102767064 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a21c44:     	mov	x25, x0
102a21c48:     	stp	x20, x19, [sp, #0xe0]
102a21c4c:     	stp	x0, x1, [x29, #-0x78]
102a21c50:     	str	x1, [sp, #0xd8]
102a21c54:     	add	x0, x24, #0x2d8
102a21c58:     	bl	0x102767064 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a21c5c:     	mov	x19, x0
102a21c60:     	mov	x22, x1
102a21c64:     	mov	x26, #0x0               ; =0
102a21c68:     	stp	x0, x1, [x29, #-0x68]
102a21c6c:     	ldr	x21, [x24, #0x2f0]
102a21c70:     	lsl	x20, x21, #6
102a21c74:     	lsr	x8, x21, #58
102a21c78:     	cbnz	x8, 0x102a21ce8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102a21c7c:     	str	x27, [sp, #0xb8]
102a21c80:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102a21c84:     	cmp	x20, x8
102a21c88:     	b.hi	0x102a21ce8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102a21c8c:     	str	x23, [sp, #0xb0]
102a21c90:     	cbz	x20, 0x102a21cf8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x118>
102a21c94:     	ldr	x27, [x24, #0x2e8]
102a21c98:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a21c9c:     	mov	w26, #0x8               ; =8
102a21ca0:     	mov	x0, x20
102a21ca4:     	mov	w1, #0x8                ; =8
102a21ca8:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a21cac:     	str	x0, [sp, #0xc8]
102a21cb0:     	cbz	x0, 0x102a21ce8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102a21cb4:     	mov	x23, x28
102a21cb8:     	cbz	x21, 0x102a21ccc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xec>
102a21cbc:     	ldr	x0, [sp, #0xc8]
102a21cc0:     	mov	x1, x27
102a21cc4:     	mov	x2, x20
102a21cc8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a21ccc:     	mov	x26, #0x0               ; =0
102a21cd0:     	ldr	x8, [x24, #0x300]
102a21cd4:     	lsl	x28, x8, #6
102a21cd8:     	str	x8, [sp, #0xc0]
102a21cdc:     	lsr	x8, x8, #58
102a21ce0:     	cbz	x8, 0x102a21d1c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x13c>
102a21ce4:     	b	0x102a21d68 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
102a21ce8:     	mov	x0, x26
102a21cec:     	mov	x1, x20
102a21cf0:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a21cf4:     	b	0x102a220c4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
102a21cf8:     	mov	x23, x28
102a21cfc:     	mov	w8, #0x8                ; =8
102a21d00:     	str	x8, [sp, #0xc8]
102a21d04:     	mov	x26, #0x0               ; =0
102a21d08:     	ldr	x8, [x24, #0x300]
102a21d0c:     	lsl	x28, x8, #6
102a21d10:     	str	x8, [sp, #0xc0]
102a21d14:     	lsr	x8, x8, #58
102a21d18:     	cbnz	x8, 0x102a21d68 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
102a21d1c:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102a21d20:     	cmp	x28, x8
102a21d24:     	b.hi	0x102a21d68 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
102a21d28:     	stp	x23, x28, [sp, #0x98]
102a21d2c:     	cbz	x28, 0x102a21d78 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x198>
102a21d30:     	ldr	x27, [x24, #0x2f8]
102a21d34:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a21d38:     	mov	w26, #0x8               ; =8
102a21d3c:     	mov	x0, x28
102a21d40:     	mov	w1, #0x8                ; =8
102a21d44:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a21d48:     	str	x0, [sp, #0xa8]
102a21d4c:     	cbz	x0, 0x102a21d68 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x188>
102a21d50:     	ldr	x8, [sp, #0xc0]
102a21d54:     	cbz	x8, 0x102a21d80 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
102a21d58:     	ldp	x2, x0, [sp, #0xa0]
102a21d5c:     	mov	x1, x27
102a21d60:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a21d64:     	b	0x102a21d80 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
102a21d68:     	mov	x0, x26
102a21d6c:     	mov	x1, x28
102a21d70:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a21d74:     	b	0x102a220c4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
102a21d78:     	mov	w8, #0x8                ; =8
102a21d7c:     	str	x8, [sp, #0xa8]
102a21d80:     	ldr	x23, [x24, #0x310]
102a21d84:     	add	x8, x23, x23, lsl #1
102a21d88:     	lsl	x28, x8, #4
102a21d8c:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
102a21d90:     	movk	x8, #0x2aa, lsl #48
102a21d94:     	cmp	x23, x8
102a21d98:     	str	x28, [sp, #0xf0]
102a21d9c:     	b.ls	0x102a21db4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1d4>
102a21da0:     	mov	x26, #0x0               ; =0
102a21da4:     	mov	x0, x26
102a21da8:     	ldr	x1, [sp, #0xf0]
102a21dac:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a21db0:     	b	0x102a220c4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
102a21db4:     	str	x23, [sp, #0x90]
102a21db8:     	cbz	x28, 0x102a21e20 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x240>
102a21dbc:     	ldr	x27, [x24, #0x308]
102a21dc0:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a21dc4:     	mov	w26, #0x8               ; =8
102a21dc8:     	mov	x0, x28
102a21dcc:     	mov	w1, #0x8                ; =8
102a21dd0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a21dd4:     	str	x0, [sp, #0xd0]
102a21dd8:     	cbz	x0, 0x102a21da4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1c4>
102a21ddc:     	cbz	x23, 0x102a21e28 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x248>
102a21de0:     	mov	x8, #0x0                ; =0
102a21de4:     	mov	x9, x23
102a21de8:     	ldr	x10, [sp, #0xf0]
102a21dec:     	cmp	x10, x8
102a21df0:     	b.eq	0x102a21e28 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x248>
102a21df4:     	add	x10, x27, x8
102a21df8:     	ldr	x11, [sp, #0xd0]
102a21dfc:     	add	x11, x11, x8
102a21e00:     	ldp	q0, q1, [x10]
102a21e04:     	ldr	q2, [x10, #0x20]
102a21e08:     	stp	q1, q2, [x11, #0x10]
102a21e0c:     	str	q0, [x11]
102a21e10:     	add	x8, x8, #0x30
102a21e14:     	subs	x9, x9, #0x1
102a21e18:     	b.ne	0x102a21de8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x208>
102a21e1c:     	b	0x102a21e28 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x248>
102a21e20:     	mov	w8, #0x8                ; =8
102a21e24:     	str	x8, [sp, #0xd0]
102a21e28:     	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
102a21e2c:     	movk	x10, #0xaaa, lsl #48
102a21e30:     	ldr	x23, [x24, #0x320]
102a21e34:     	add	x8, x23, x23, lsl #1
102a21e38:     	lsl	x28, x8, #2
102a21e3c:     	cmp	x23, x10
102a21e40:     	str	x28, [sp, #0x88]
102a21e44:     	b.ls	0x102a21e5c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x27c>
102a21e48:     	mov	x27, #0x0               ; =0
102a21e4c:     	mov	x0, x27
102a21e50:     	ldr	x1, [sp, #0x88]
102a21e54:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a21e58:     	b	0x102a220c4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
102a21e5c:     	cbz	x28, 0x102a21ec0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2e0>
102a21e60:     	ldr	x26, [x24, #0x318]
102a21e64:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a21e68:     	mov	w27, #0x4               ; =4
102a21e6c:     	mov	x0, x28
102a21e70:     	mov	w1, #0x4                ; =4
102a21e74:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a21e78:     	str	x0, [sp, #0x80]
102a21e7c:     	cbz	x0, 0x102a21e4c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x26c>
102a21e80:     	cbz	x23, 0x102a21e90 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b0>
102a21e84:     	ldp	x0, x2, [sp, #0x80]
102a21e88:     	mov	x1, x26
102a21e8c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a21e90:     	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
102a21e94:     	movk	x10, #0xaaa, lsl #48
102a21e98:     	ldr	x9, [x24, #0x330]
102a21e9c:     	add	x8, x9, x9, lsl #1
102a21ea0:     	lsl	x28, x8, #2
102a21ea4:     	cmp	x9, x10
102a21ea8:     	b.ls	0x102a21edc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2fc>
102a21eac:     	mov	x27, #0x0               ; =0
102a21eb0:     	mov	x0, x27
102a21eb4:     	mov	x1, x28
102a21eb8:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a21ebc:     	b	0x102a220c4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
102a21ec0:     	mov	w8, #0x4                ; =4
102a21ec4:     	str	x8, [sp, #0x80]
102a21ec8:     	ldr	x9, [x24, #0x330]
102a21ecc:     	add	x8, x9, x9, lsl #1
102a21ed0:     	lsl	x28, x8, #2
102a21ed4:     	cmp	x9, x10
102a21ed8:     	b.hi	0x102a21eac <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2cc>
102a21edc:     	str	x9, [sp, #0x78]
102a21ee0:     	str	x28, [sp, #0x60]
102a21ee4:     	cbz	x28, 0x102a21f24 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x344>
102a21ee8:     	ldr	x26, [x24, #0x328]
102a21eec:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a21ef0:     	mov	w27, #0x4               ; =4
102a21ef4:     	mov	x0, x28
102a21ef8:     	mov	w1, #0x4                ; =4
102a21efc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a21f00:     	str	x0, [sp, #0x68]
102a21f04:     	cbz	x0, 0x102a21eb0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2d0>
102a21f08:     	ldr	x8, [sp, #0x78]
102a21f0c:     	cbz	x8, 0x102a21f2c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x34c>
102a21f10:     	ldr	x0, [sp, #0x68]
102a21f14:     	mov	x1, x26
102a21f18:     	mov	x2, x28
102a21f1c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a21f20:     	b	0x102a21f2c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x34c>
102a21f24:     	mov	w8, #0x4                ; =4
102a21f28:     	str	x8, [sp, #0x68]
102a21f2c:     	add	x0, x24, #0x338
102a21f30:     	bl	0x102766ba0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a21f34:     	str	x0, [sp, #0x50]
102a21f38:     	str	x1, [sp, #0x70]
102a21f3c:     	mov	x26, #0x0               ; =0
102a21f40:     	ldr	x8, [x24, #0x350]
102a21f44:     	lsl	x28, x8, #2
102a21f48:     	str	x8, [sp, #0x58]
102a21f4c:     	lsr	x8, x8, #62
102a21f50:     	cbnz	x8, 0x102a21fa0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3c0>
102a21f54:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
102a21f58:     	cmp	x28, x8
102a21f5c:     	b.hi	0x102a21fa0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3c0>
102a21f60:     	str	x28, [sp, #0x40]
102a21f64:     	cbz	x28, 0x102a21fb0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3d0>
102a21f68:     	ldr	x27, [x24, #0x348]
102a21f6c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a21f70:     	mov	w26, #0x2               ; =2
102a21f74:     	mov	x0, x28
102a21f78:     	mov	w1, #0x2                ; =2
102a21f7c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a21f80:     	str	x0, [sp, #0x48]
102a21f84:     	cbz	x0, 0x102a21fa0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3c0>
102a21f88:     	ldr	x8, [sp, #0x58]
102a21f8c:     	cbz	x8, 0x102a21fb8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3d8>
102a21f90:     	ldp	x2, x0, [sp, #0x40]
102a21f94:     	mov	x1, x27
102a21f98:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a21f9c:     	b	0x102a21fb8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3d8>
102a21fa0:     	mov	x0, x26
102a21fa4:     	mov	x1, x28
102a21fa8:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a21fac:     	b	0x102a220c4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
102a21fb0:     	mov	w8, #0x2                ; =2
102a21fb4:     	str	x8, [sp, #0x48]
102a21fb8:     	ldr	x26, [x24, #0x360]
102a21fbc:     	add	x8, x26, x26, lsl #1
102a21fc0:     	lsl	x28, x8, #2
102a21fc4:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
102a21fc8:     	movk	x8, #0xaaa, lsl #48
102a21fcc:     	cmp	x26, x8
102a21fd0:     	b.ls	0x102a21fe8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x408>
102a21fd4:     	mov	x27, #0x0               ; =0
102a21fd8:     	mov	x0, x27
102a21fdc:     	mov	x1, x28
102a21fe0:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a21fe4:     	b	0x102a220c4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e4>
102a21fe8:     	str	x28, [sp, #0x30]
102a21fec:     	cbz	x28, 0x102a2202c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x44c>
102a21ff0:     	ldr	x8, [x24, #0x358]
102a21ff4:     	str	x8, [sp, #0x28]
102a21ff8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a21ffc:     	mov	w27, #0x4               ; =4
102a22000:     	mov	x0, x28
102a22004:     	mov	w1, #0x4                ; =4
102a22008:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a2200c:     	str	x0, [sp, #0x38]
102a22010:     	cbz	x0, 0x102a21fd8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x3f8>
102a22014:     	cbz	x26, 0x102a22034 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x454>
102a22018:     	ldr	x0, [sp, #0x38]
102a2201c:     	ldr	x1, [sp, #0x28]
102a22020:     	mov	x2, x28
102a22024:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a22028:     	b	0x102a22034 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x454>
102a2202c:     	mov	w8, #0x4                ; =4
102a22030:     	str	x8, [sp, #0x38]
102a22034:     	mov	x27, #0x0               ; =0
102a22038:     	ldr	x28, [x24, #0x370]
102a2203c:     	lsl	x2, x28, #2
102a22040:     	lsr	x8, x28, #62
102a22044:     	cbnz	x8, 0x102a220b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d8>
102a22048:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
102a2204c:     	cmp	x2, x8
102a22050:     	b.hi	0x102a220b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d8>
102a22054:     	ldrh	w9, [x24, #0x3e4]
102a22058:     	ldr	w11, [x24, #0x3e0]
102a2205c:     	cbz	x2, 0x102a220c8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4e8>
102a22060:     	stp	x11, x9, [sp, #0x10]
102a22064:     	ldr	x8, [x24, #0x368]
102a22068:     	str	x8, [sp, #0x8]
102a2206c:     	str	x28, [sp, #0x20]
102a22070:     	mov	x28, x2
102a22074:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a22078:     	mov	w27, #0x2               ; =2
102a2207c:     	mov	x0, x28
102a22080:     	mov	w1, #0x2                ; =2
102a22084:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a22088:     	mov	x2, x28
102a2208c:     	ldr	x28, [sp, #0x20]
102a22090:     	cbz	x0, 0x102a220b8 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d8>
102a22094:     	ldr	x10, [sp, #0xb8]
102a22098:     	str	x0, [sp, #0x28]
102a2209c:     	cbz	x28, 0x102a220b0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4d0>
102a220a0:     	ldr	x1, [sp, #0x8]
102a220a4:     	mov	x20, x10
102a220a8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a220ac:     	mov	x10, x20
102a220b0:     	ldp	x11, x9, [sp, #0x10]
102a220b4:     	b	0x102a220d4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x4f4>
102a220b8:     	mov	x0, x27
102a220bc:     	mov	x1, x2
102a220c0:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a220c4:     	brk	#0x1
102a220c8:     	mov	w8, #0x2                ; =2
102a220cc:     	str	x8, [sp, #0x28]
102a220d0:     	ldr	x10, [sp, #0xb8]
102a220d4:     	add	x8, sp, #0x59
102a220d8:     	ldur	q0, [x8, #0xff]
102a220dc:     	add	x8, sp, #0x69
102a220e0:     	ldur	q1, [x8, #0xff]
102a220e4:     	orr	x8, x11, x9, lsl #32
102a220e8:     	add	x20, x24, #0x378
102a220ec:     	ldr	x27, [sp, #0x98]
102a220f0:     	add	x9, x27, #0x208
102a220f4:     	stp	q0, q1, [x9, #0x60]
102a220f8:     	add	x11, sp, #0x79
102a220fc:     	ldur	q0, [x11, #0xff]
102a22100:     	add	x11, sp, #0x89
102a22104:     	ldur	q1, [x11, #0xff]
102a22108:     	stp	q0, q1, [x9, #0x80]
102a2210c:     	add	x11, sp, #0x19
102a22110:     	ldur	q0, [x11, #0xff]
102a22114:     	add	x11, sp, #0x29
102a22118:     	ldur	q1, [x11, #0xff]
102a2211c:     	stp	q0, q1, [x9, #0x20]
102a22120:     	add	x11, sp, #0x39
102a22124:     	ldur	q0, [x11, #0xff]
102a22128:     	add	x11, sp, #0x49
102a2212c:     	ldur	q1, [x11, #0xff]
102a22130:     	stp	q0, q1, [x9, #0x40]
102a22134:     	ldur	q0, [sp, #0xf8]
102a22138:     	add	x11, sp, #0x9
102a2213c:     	ldur	q1, [x11, #0xff]
102a22140:     	stp	q0, q1, [x9]
102a22144:     	ldr	x9, [sp, #0xb0]
102a22148:     	str	x9, [x27, #0x2a8]
102a2214c:     	str	x10, [x27, #0x2b0]
102a22150:     	ldp	x9, x10, [sp, #0xe0]
102a22154:     	str	x10, [x27, #0x2b8]
102a22158:     	str	x9, [x27, #0x2c0]
102a2215c:     	str	x25, [x27, #0x2c8]
102a22160:     	ldr	x9, [sp, #0xd8]
102a22164:     	str	x9, [x27, #0x2d0]
102a22168:     	str	x19, [x27, #0x2d8]
102a2216c:     	str	x22, [x27, #0x2e0]
102a22170:     	ldr	x9, [sp, #0xc8]
102a22174:     	str	x9, [x27, #0x2e8]
102a22178:     	str	x21, [x27, #0x2f0]
102a2217c:     	ldr	x9, [sp, #0xa8]
102a22180:     	str	x9, [x27, #0x2f8]
102a22184:     	ldr	x9, [sp, #0xc0]
102a22188:     	str	x9, [x27, #0x300]
102a2218c:     	ldr	x9, [sp, #0xd0]
102a22190:     	str	x9, [x27, #0x308]
102a22194:     	ldr	x9, [sp, #0x90]
102a22198:     	str	x9, [x27, #0x310]
102a2219c:     	ldr	x9, [sp, #0x80]
102a221a0:     	str	x9, [x27, #0x318]
102a221a4:     	str	x23, [x27, #0x320]
102a221a8:     	ldr	x9, [sp, #0x68]
102a221ac:     	str	x9, [x27, #0x328]
102a221b0:     	ldr	x9, [sp, #0x78]
102a221b4:     	str	x9, [x27, #0x330]
102a221b8:     	ldr	x9, [sp, #0x50]
102a221bc:     	str	x9, [x27, #0x338]
102a221c0:     	ldr	x9, [sp, #0x70]
102a221c4:     	str	x9, [x27, #0x340]
102a221c8:     	ldr	x9, [sp, #0x48]
102a221cc:     	str	x9, [x27, #0x348]
102a221d0:     	ldr	x9, [sp, #0x58]
102a221d4:     	str	x9, [x27, #0x350]
102a221d8:     	ldr	x9, [sp, #0x38]
102a221dc:     	str	x9, [x27, #0x358]
102a221e0:     	str	x26, [x27, #0x360]
102a221e4:     	lsr	x9, x8, #32
102a221e8:     	strh	w9, [x27, #0x3e4]
102a221ec:     	str	w8, [x27, #0x3e0]
102a221f0:     	mov	x0, x27
102a221f4:     	mov	x1, x24
102a221f8:     	mov	w2, #0x208              ; =520
102a221fc:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a22200:     	add	x8, x27, #0x378
102a22204:     	ldp	q0, q1, [x20, #0x40]
102a22208:     	stp	q0, q1, [x8, #0x40]
102a2220c:     	ldr	x9, [x24, #0x3d8]
102a22210:     	str	x9, [x27, #0x3d8]
102a22214:     	ldp	q0, q1, [x20]
102a22218:     	stp	q0, q1, [x8]
102a2221c:     	ldp	q1, q0, [x20, #0x20]
102a22220:     	stp	q1, q0, [x8, #0x20]
102a22224:     	ldr	x8, [sp, #0x28]
102a22228:     	str	x8, [x27, #0x368]
102a2222c:     	str	x28, [x27, #0x370]
102a22230:     	add	sp, sp, #0x1e0
102a22234:     	ldp	x29, x30, [sp, #0x50]
102a22238:     	ldp	x20, x19, [sp, #0x40]
102a2223c:     	ldp	x22, x21, [sp, #0x30]
102a22240:     	ldp	x24, x23, [sp, #0x20]
102a22244:     	ldp	x26, x25, [sp, #0x10]
102a22248:     	ldp	x28, x27, [sp], #0x60
102a2224c:     	ret
102a22250:     	mov	x19, x0
102a22254:     	b	0x102a222d4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6f4>
102a22258:     	mov	x19, x0
102a2225c:     	b	0x102a2236c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x78c>
102a22260:     	mov	x19, x0
102a22264:     	b	0x102a22374 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x794>
102a22268:     	mov	x19, x0
102a2226c:     	b	0x102a2237c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x79c>
102a22270:     	mov	x19, x0
102a22274:     	b	0x102a22384 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7a4>
102a22278:     	mov	x19, x0
102a2227c:     	ldr	x28, [sp, #0x70]
102a22280:     	cbz	x26, 0x102a2229c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6bc>
102a22284:     	ldp	x1, x0, [sp, #0x30]
102a22288:     	mov	w2, #0x4                ; =4
102a2228c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a22290:     	b	0x102a2229c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6bc>
102a22294:     	mov	x19, x0
102a22298:     	ldr	x28, [sp, #0x70]
102a2229c:     	ldr	x8, [sp, #0x58]
102a222a0:     	cbz	x8, 0x102a222bc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6dc>
102a222a4:     	ldp	x1, x0, [sp, #0x40]
102a222a8:     	mov	w2, #0x2                ; =2
102a222ac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a222b0:     	b	0x102a222bc <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6dc>
102a222b4:     	mov	x19, x0
102a222b8:     	ldr	x28, [sp, #0x70]
102a222bc:     	cbz	x28, 0x102a222d4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6f4>
102a222c0:     	add	x8, x28, x28, lsl #1
102a222c4:     	lsl	x1, x8, #5
102a222c8:     	ldr	x0, [sp, #0x50]
102a222cc:     	mov	w2, #0x8                ; =8
102a222d0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a222d4:     	ldr	x1, [sp, #0x60]
102a222d8:     	ldr	x8, [sp, #0x78]
102a222dc:     	cbz	x8, 0x102a222f4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x714>
102a222e0:     	ldr	x0, [sp, #0x68]
102a222e4:     	mov	w2, #0x4                ; =4
102a222e8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a222ec:     	b	0x102a222f4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x714>
102a222f0:     	mov	x19, x0
102a222f4:     	cbz	x23, 0x102a2230c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x72c>
102a222f8:     	ldp	x0, x1, [sp, #0x80]
102a222fc:     	mov	w2, #0x4                ; =4
102a22300:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a22304:     	b	0x102a2230c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x72c>
102a22308:     	mov	x19, x0
102a2230c:     	ldr	x8, [sp, #0x90]
102a22310:     	cbz	x8, 0x102a2232c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74c>
102a22314:     	ldr	x0, [sp, #0xd0]
102a22318:     	ldr	x1, [sp, #0xf0]
102a2231c:     	mov	w2, #0x8                ; =8
102a22320:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a22324:     	b	0x102a2232c <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74c>
102a22328:     	mov	x19, x0
102a2232c:     	ldr	x8, [sp, #0xc0]
102a22330:     	cbz	x8, 0x102a22348 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x768>
102a22334:     	ldp	x1, x0, [sp, #0xa0]
102a22338:     	mov	w2, #0x8                ; =8
102a2233c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a22340:     	b	0x102a22348 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x768>
102a22344:     	mov	x19, x0
102a22348:     	cbz	x21, 0x102a22364 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x784>
102a2234c:     	ldr	x0, [sp, #0xc8]
102a22350:     	mov	x1, x20
102a22354:     	mov	w2, #0x8                ; =8
102a22358:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a2235c:     	b	0x102a22364 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x784>
102a22360:     	mov	x19, x0
102a22364:     	sub	x0, x29, #0x68
102a22368:     	bl	0x1029cc448 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
102a2236c:     	sub	x0, x29, #0x78
102a22370:     	bl	0x1029cc448 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
102a22374:     	sub	x0, x29, #0x88
102a22378:     	bl	0x1029cc344 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
102a2237c:     	sub	x0, x29, #0x98
102a22380:     	bl	0x1029cc344 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
102a22384:     	add	x0, sp, #0xf8
102a22388:     	bl	0x1029d3648 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization9BoundCallECs1qJAwyMG1lC_11mech_engine>
102a2238c:     	mov	x0, x19
102a22390:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102a22394:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
