
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102553cec <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_>:
102553cec:     	sub	sp, sp, #0xd0
102553cf0:     	stp	x22, x21, [sp, #0xa0]
102553cf4:     	stp	x20, x19, [sp, #0xb0]
102553cf8:     	stp	x29, x30, [sp, #0xc0]
102553cfc:     	add	x29, sp, #0xc0
102553d00:     	mov	x19, x8
102553d04:     	ldp	q0, q1, [x0, #0x20]
102553d08:     	stp	q0, q1, [sp, #0x50]
102553d0c:     	ldr	q0, [x0, #0x40]
102553d10:     	str	q0, [sp, #0x70]
102553d14:     	ldp	q1, q0, [x0]
102553d18:     	stp	q1, q0, [sp, #0x30]
102553d1c:     	mov	x8, sp
102553d20:     	add	x0, sp, #0x30
102553d24:     	bl	0x1025c9774 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_>
102553d28:     	ldr	x21, [sp, #0x10]
102553d2c:     	cbz	x21, 0x102553da4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xb8>
102553d30:     	ldr	x20, [sp, #0x8]
102553d34:     	sub	x8, x29, #0x21
102553d38:     	str	x8, [sp, #0x30]
102553d3c:     	cmp	x21, #0x1
102553d40:     	b.ne	0x102553dd8 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xec>
102553d44:     	ldr	x22, [sp]
102553d48:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102553d4c:     	mov	w0, #0x2a0              ; =672
102553d50:     	mov	w1, #0x8                ; =8
102553d54:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102553d58:     	cbz	x0, 0x102553df8 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x10c>
102553d5c:     	str	xzr, [x0]
102553d60:     	strh	wzr, [x0, #0x29e]
102553d64:     	stp	x0, xzr, [sp, #0x18]
102553d68:     	str	xzr, [sp, #0x28]
102553d6c:     	add	x8, x20, x21, lsl #6
102553d70:     	mov	w9, #0x3                ; =3
102553d74:     	strb	w9, [sp, #0x30]
102553d78:     	stp	x20, x20, [sp, #0x70]
102553d7c:     	stp	x22, x8, [sp, #0x80]
102553d80:     	add	x0, sp, #0x18
102553d84:     	add	x1, sp, #0x30
102553d88:     	add	x2, sp, #0x28
102553d8c:     	bl	0x1024ef4ec <__RINvMNtNtNtCsgKscDXrlV49_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBW_6marker5OwnedTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1F_11memory_plan5model22CurrentMemoryFootprintNtB1g_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterB1y_B2Q_INtNtNtB9_3vec9into_iter8IntoIterTB1y_B2Q_EEENtNtB9_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102553d90:     	ldp	x8, x9, [sp, #0x18]
102553d94:     	ldr	x10, [sp, #0x28]
102553d98:     	stp	x8, x9, [x19]
102553d9c:     	str	x10, [x19, #0x10]
102553da0:     	b	0x102553dc4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xd8>
102553da4:     	str	xzr, [x19]
102553da8:     	str	xzr, [x19, #0x10]
102553dac:     	ldr	x8, [sp]
102553db0:     	cbz	x8, 0x102553dc4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0xd8>
102553db4:     	ldr	x0, [sp, #0x8]
102553db8:     	lsl	x1, x8, #6
102553dbc:     	mov	w2, #0x8                ; =8
102553dc0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102553dc4:     	ldp	x29, x30, [sp, #0xc0]
102553dc8:     	ldp	x20, x19, [sp, #0xb0]
102553dcc:     	ldp	x22, x21, [sp, #0xa0]
102553dd0:     	add	sp, sp, #0xd0
102553dd4:     	ret
102553dd8:     	cmp	x21, #0x15
102553ddc:     	b.hs	0x102553e08 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x11c>
102553de0:     	add	x3, sp, #0x30
102553de4:     	mov	x0, x20
102553de8:     	mov	x1, x21
102553dec:     	mov	w2, #0x1                ; =1
102553df0:     	bl	0x102a6ffc8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_>
102553df4:     	b	0x102553d44 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x58>
102553df8:     	mov	w0, #0x8                ; =8
102553dfc:     	mov	w1, #0x2a0              ; =672
102553e00:     	bl	0x103a05ad8 <__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error>
102553e04:     	brk	#0x1
102553e08:     	add	x2, sp, #0x30
102553e0c:     	mov	x0, x20
102553e10:     	mov	x1, x21
102553e14:     	bl	0x1025a03bc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>
102553e18:     	b	0x102553d44 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x58>
102553e1c:     	ldr	x22, [sp]
102553e20:     	cbnz	x22, 0x102553e2c <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x140>
102553e24:     	b	0x102553e44 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x158>
102553e28:     	cbz	x22, 0x102553e44 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EEB6n_+0x158>
102553e2c:     	lsl	x1, x22, #6
102553e30:     	mov	x19, x0
102553e34:     	mov	x0, x20
102553e38:     	mov	w2, #0x8                ; =8
102553e3c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102553e40:     	mov	x0, x19
102553e44:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
