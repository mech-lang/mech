
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010235c180 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>:
10235c180:     	sub	sp, sp, #0xb0
10235c184:     	stp	x28, x27, [sp, #0x50]
10235c188:     	stp	x26, x25, [sp, #0x60]
10235c18c:     	stp	x24, x23, [sp, #0x70]
10235c190:     	stp	x22, x21, [sp, #0x80]
10235c194:     	stp	x20, x19, [sp, #0x90]
10235c198:     	stp	x29, x30, [sp, #0xa0]
10235c19c:     	add	x29, sp, #0xa0
10235c1a0:     	stp	x6, x3, [sp]
10235c1a4:     	mov	x21, x2
10235c1a8:     	mov	x27, x1
10235c1ac:     	mov	x22, x0
10235c1b0:     	cmp	x1, #0x21
10235c1b4:     	b.hs	0x10235c1d0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x50>
10235c1b8:     	mov	x0, x22
10235c1bc:     	mov	x1, x27
10235c1c0:     	mov	x2, x21
10235c1c4:     	ldp	x4, x3, [sp]
10235c1c8:     	bl	0x102a76284 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_>
10235c1cc:     	b	0x10235c554 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3d4>
10235c1d0:     	mov	x25, x5
10235c1d4:     	mov	x23, x4
10235c1d8:     	mov	w28, #0xff              ; =255
10235c1dc:     	mov	x24, x27
10235c1e0:     	cbz	w23, 0x10235c53c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3bc>
10235c1e4:     	lsr	x3, x24, #3
10235c1e8:     	add	x1, x22, x3, lsl #8
10235c1ec:     	mov	w8, #0x1c0              ; =448
10235c1f0:     	madd	x2, x3, x8, x22
10235c1f4:     	cmp	x24, #0x40
10235c1f8:     	b.hs	0x10235c284 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x104>
10235c1fc:     	ldrb	w12, [x22]
10235c200:     	ldrh	w13, [x22, #0x2]
10235c204:     	ldrb	w8, [x2]
10235c208:     	ldrh	w9, [x2, #0x2]
10235c20c:     	cmp	w13, w9
10235c210:     	cset	w14, lo
10235c214:     	subs	w10, w12, w8
10235c218:     	bics	wzr, w28, w10
10235c21c:     	cset	w15, eq
10235c220:     	ldrb	w10, [x1]
10235c224:     	ldrh	w11, [x1, #0x2]
10235c228:     	cmp	w12, w8
10235c22c:     	csel	w14, w14, w15, eq
10235c230:     	cmp	w13, w11
10235c234:     	cset	w13, lo
10235c238:     	subs	w15, w12, w10
10235c23c:     	bics	wzr, w28, w15
10235c240:     	cset	w15, eq
10235c244:     	cmp	w12, w10
10235c248:     	csel	w12, w13, w15, eq
10235c24c:     	mov	x26, x22
10235c250:     	cmp	w12, w14
10235c254:     	b.ne	0x10235c290 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x110>
10235c258:     	cmp	w11, w9
10235c25c:     	cset	w9, lo
10235c260:     	subs	w11, w10, w8
10235c264:     	cmn	w11, #0x1
10235c268:     	cset	w11, eq
10235c26c:     	cmp	w10, w8
10235c270:     	csel	w8, w9, w11, eq
10235c274:     	eor	w8, w12, w8
10235c278:     	cmp	w8, #0x0
10235c27c:     	csel	x26, x2, x1, ne
10235c280:     	b	0x10235c290 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x110>
10235c284:     	mov	x0, x22
10235c288:     	bl	0x10234a754 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_>
10235c28c:     	mov	x26, x0
10235c290:     	sub	w23, w23, #0x1
10235c294:     	sub	x8, x26, x22
10235c298:     	lsr	x20, x8, #6
10235c29c:     	ldp	q0, q1, [x26]
10235c2a0:     	stp	q0, q1, [sp, #0x10]
10235c2a4:     	ldp	q0, q1, [x26, #0x20]
10235c2a8:     	stp	q0, q1, [sp, #0x30]
10235c2ac:     	add	x19, x21, x24, lsl #6
10235c2b0:     	cbz	x25, 0x10235c2e8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x168>
10235c2b4:     	ldrb	w8, [x25]
10235c2b8:     	ldrh	w9, [x25, #0x2]
10235c2bc:     	ldrb	w10, [x26]
10235c2c0:     	ldrh	w11, [x26, #0x2]
10235c2c4:     	cmp	w9, w11
10235c2c8:     	cset	w9, lo
10235c2cc:     	subs	w11, w8, w10
10235c2d0:     	bics	wzr, w28, w11
10235c2d4:     	cset	w11, eq
10235c2d8:     	cmp	w8, w10
10235c2dc:     	csel	w8, w9, w11, eq
10235c2e0:     	cmp	w8, #0x1
10235c2e4:     	b.ne	0x10235c420 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2a0>
10235c2e8:     	ldr	x8, [sp, #0x8]
10235c2ec:     	cmp	x8, x24
10235c2f0:     	b.lo	0x10235c57c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3fc>
10235c2f4:     	mov	x27, #0x0               ; =0
10235c2f8:     	mov	x8, x22
10235c2fc:     	mov	x9, x19
10235c300:     	mov	x10, x20
10235c304:     	add	x11, x22, x20, lsl #6
10235c308:     	cmp	x22, x11
10235c30c:     	b.hs	0x10235c36c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x1ec>
10235c310:     	ldrb	w12, [x8]
10235c314:     	ldrh	w13, [x8, #0x2]
10235c318:     	ldrb	w14, [x26]
10235c31c:     	ldrh	w15, [x26, #0x2]
10235c320:     	cmp	w13, w15
10235c324:     	cset	w13, lo
10235c328:     	subs	w15, w12, w14
10235c32c:     	bics	wzr, w28, w15
10235c330:     	cset	w15, eq
10235c334:     	cmp	w12, w14
10235c338:     	csel	w12, w13, w15, eq
10235c33c:     	sub	x9, x9, #0x40
10235c340:     	cmp	w12, #0x0
10235c344:     	csel	x13, x21, x9, ne
10235c348:     	add	x13, x13, x27, lsl #6
10235c34c:     	ldp	q0, q1, [x8]
10235c350:     	ldp	q2, q3, [x8, #0x20]
10235c354:     	stp	q2, q3, [x13, #0x20]
10235c358:     	stp	q0, q1, [x13]
10235c35c:     	add	x27, x27, x12
10235c360:     	add	x8, x8, #0x40
10235c364:     	cmp	x8, x11
10235c368:     	b.lo	0x10235c310 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x190>
10235c36c:     	cmp	x10, x24
10235c370:     	b.eq	0x10235c3a4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x224>
10235c374:     	sub	x9, x9, #0x40
10235c378:     	add	x10, x9, x27, lsl #6
10235c37c:     	ldp	q0, q1, [x8]
10235c380:     	stp	q0, q1, [x10]
10235c384:     	ldp	q0, q1, [x8, #0x20]
10235c388:     	stp	q0, q1, [x10, #0x20]
10235c38c:     	add	x8, x8, #0x40
10235c390:     	mov	x10, x24
10235c394:     	add	x11, x22, x24, lsl #6
10235c398:     	cmp	x8, x11
10235c39c:     	b.lo	0x10235c310 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x190>
10235c3a0:     	b	0x10235c36c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x1ec>
10235c3a4:     	lsl	x2, x27, #6
10235c3a8:     	mov	x0, x22
10235c3ac:     	mov	x1, x21
10235c3b0:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10235c3b4:     	add	x0, x22, x27, lsl #6
10235c3b8:     	subs	x1, x24, x27
10235c3bc:     	b.eq	0x10235c3f0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x270>
10235c3c0:     	sub	x8, x21, #0x40
10235c3c4:     	add	x8, x8, x24, lsl #6
10235c3c8:     	mov	x9, x1
10235c3cc:     	mov	x10, x0
10235c3d0:     	ldp	q0, q1, [x8]
10235c3d4:     	stp	q0, q1, [x10]
10235c3d8:     	ldp	q0, q1, [x8, #0x20]
10235c3dc:     	stp	q0, q1, [x10, #0x20]
10235c3e0:     	add	x10, x10, #0x40
10235c3e4:     	sub	x8, x8, #0x40
10235c3e8:     	subs	x9, x9, #0x1
10235c3ec:     	b.ne	0x10235c3d0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x250>
10235c3f0:     	cbz	x27, 0x10235c420 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2a0>
10235c3f4:     	cmp	x24, x27
10235c3f8:     	b.lo	0x10235c580 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x400>
10235c3fc:     	add	x5, sp, #0x10
10235c400:     	mov	x2, x21
10235c404:     	ldp	x6, x3, [sp]
10235c408:     	mov	x4, x23
10235c40c:     	bl	0x10235c180 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>
10235c410:     	mov	x24, x27
10235c414:     	cmp	x27, #0x21
10235c418:     	b.hs	0x10235c1e0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x60>
10235c41c:     	b	0x10235c1b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x38>
10235c420:     	ldr	x8, [sp, #0x8]
10235c424:     	cmp	x8, x24
10235c428:     	b.lo	0x10235c57c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3fc>
10235c42c:     	mov	x25, #0x0               ; =0
10235c430:     	mov	x8, x22
10235c434:     	add	x9, x22, x20, lsl #6
10235c438:     	cmp	x22, x9
10235c43c:     	b.hs	0x10235c49c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x31c>
10235c440:     	ldrb	w10, [x8]
10235c444:     	ldrh	w11, [x8, #0x2]
10235c448:     	ldrb	w12, [x26]
10235c44c:     	ldrh	w13, [x26, #0x2]
10235c450:     	cmp	w13, w11
10235c454:     	cset	w11, hs
10235c458:     	subs	w13, w12, w10
10235c45c:     	bics	wzr, w28, w13
10235c460:     	cset	w13, ne
10235c464:     	cmp	w12, w10
10235c468:     	csel	w10, w11, w13, eq
10235c46c:     	sub	x19, x19, #0x40
10235c470:     	cmp	w10, #0x0
10235c474:     	csel	x11, x21, x19, ne
10235c478:     	add	x11, x11, x25, lsl #6
10235c47c:     	ldp	q0, q1, [x8]
10235c480:     	ldp	q2, q3, [x8, #0x20]
10235c484:     	stp	q2, q3, [x11, #0x20]
10235c488:     	stp	q0, q1, [x11]
10235c48c:     	add	x25, x25, x10
10235c490:     	add	x8, x8, #0x40
10235c494:     	cmp	x8, x9
10235c498:     	b.lo	0x10235c440 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2c0>
10235c49c:     	cmp	x20, x24
10235c4a0:     	b.eq	0x10235c4d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x358>
10235c4a4:     	sub	x19, x19, #0x40
10235c4a8:     	add	x9, x21, x25, lsl #6
10235c4ac:     	ldp	q0, q1, [x8]
10235c4b0:     	ldp	q2, q3, [x8, #0x20]
10235c4b4:     	stp	q2, q3, [x9, #0x20]
10235c4b8:     	stp	q0, q1, [x9]
10235c4bc:     	add	x25, x25, #0x1
10235c4c0:     	add	x8, x8, #0x40
10235c4c4:     	mov	x20, x24
10235c4c8:     	add	x9, x22, x24, lsl #6
10235c4cc:     	cmp	x8, x9
10235c4d0:     	b.lo	0x10235c440 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x2c0>
10235c4d4:     	b	0x10235c49c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x31c>
10235c4d8:     	lsl	x2, x25, #6
10235c4dc:     	mov	x0, x22
10235c4e0:     	mov	x1, x21
10235c4e4:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
10235c4e8:     	subs	x27, x24, x25
10235c4ec:     	b.eq	0x10235c574 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x3f4>
10235c4f0:     	add	x22, x22, x25, lsl #6
10235c4f4:     	sub	x8, x21, #0x40
10235c4f8:     	add	x8, x8, x24, lsl #6
10235c4fc:     	mov	x9, x27
10235c500:     	mov	x10, x22
10235c504:     	ldp	q0, q1, [x8]
10235c508:     	stp	q0, q1, [x10]
10235c50c:     	ldp	q0, q1, [x8, #0x20]
10235c510:     	stp	q0, q1, [x10, #0x20]
10235c514:     	add	x10, x10, #0x40
10235c518:     	sub	x8, x8, #0x40
10235c51c:     	subs	x9, x9, #0x1
10235c520:     	b.ne	0x10235c504 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x384>
10235c524:     	cmp	x24, x25
10235c528:     	b.lo	0x10235c598 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x418>
10235c52c:     	mov	x25, #0x0               ; =0
10235c530:     	cmp	x27, #0x21
10235c534:     	b.hs	0x10235c1dc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x5c>
10235c538:     	b	0x10235c1b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x38>
10235c53c:     	mov	x0, x22
10235c540:     	mov	x1, x24
10235c544:     	mov	x2, x21
10235c548:     	ldp	x5, x3, [sp]
10235c54c:     	mov	w4, #0x1                ; =1
10235c550:     	bl	0x10290818c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_>
10235c554:     	ldp	x29, x30, [sp, #0xa0]
10235c558:     	ldp	x20, x19, [sp, #0x90]
10235c55c:     	ldp	x22, x21, [sp, #0x80]
10235c560:     	ldp	x24, x23, [sp, #0x70]
10235c564:     	ldp	x26, x25, [sp, #0x60]
10235c568:     	ldp	x28, x27, [sp, #0x50]
10235c56c:     	add	sp, sp, #0xb0
10235c570:     	ret
10235c574:     	add	x22, x22, x24, lsl #6
10235c578:     	b	0x10235c1b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_+0x38>
10235c57c:     	brk	#0x1
10235c580:     	adrp	x0, 0x107579000 <_anon.bacf143378b3839dd1972d7136a97b6c.2540+0x3>
10235c584:     	add	x0, x0, #0xf9e
10235c588:     	adrp	x2, 0x108036000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.71+0x18>
10235c58c:     	add	x2, x2, #0x220
10235c590:     	mov	w1, #0x13               ; =19
10235c594:     	bl	0x103a05eb0 <__RNvNtCsgDHHaSskbIF_4core9panicking9panic_fmt>
10235c598:     	adrp	x3, 0x108036000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.71+0x18>
10235c59c:     	add	x3, x3, #0x238
10235c5a0:     	mov	x0, x25
10235c5a4:     	mov	x1, x24
10235c5a8:     	mov	x2, x24
10235c5ac:     	bl	0x103a05ef4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
