
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001029eb438 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_>:
1029eb438:     	stp	x28, x27, [sp, #-0x60]!
1029eb43c:     	stp	x26, x25, [sp, #0x10]
1029eb440:     	stp	x24, x23, [sp, #0x20]
1029eb444:     	stp	x22, x21, [sp, #0x30]
1029eb448:     	stp	x20, x19, [sp, #0x40]
1029eb44c:     	stp	x29, x30, [sp, #0x50]
1029eb450:     	add	x29, sp, #0x50
1029eb454:     	sub	sp, sp, #0x2e0
1029eb458:     	str	w4, [sp, #0x1c]
1029eb45c:     	str	x0, [sp, #0x60]
1029eb460:     	cmp	x1, #0x2
1029eb464:     	b.lo	0x1029eb9d4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x59c>
1029eb468:     	mov	x26, x5
1029eb46c:     	mov	x19, x1
1029eb470:     	mov	x8, #0x4000000000000000 ; =4611686018427387904
1029eb474:     	udiv	x9, x8, x1
1029eb478:     	mul	x10, x9, x1
1029eb47c:     	cmp	x10, x8
1029eb480:     	cinc	x8, x9, ne
1029eb484:     	str	x8, [sp, #0x28]
1029eb488:     	cmp	x1, #0x1, lsl #12       ; =0x1000
1029eb48c:     	str	x3, [sp, #0x78]
1029eb490:     	str	x2, [sp, #0x68]
1029eb494:     	b.hi	0x1029eb4b0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x78>
1029eb498:     	sub	x8, x19, x19, lsr #1
1029eb49c:     	mov	w9, #0x40               ; =64
1029eb4a0:     	cmp	x8, #0x40
1029eb4a4:     	csel	x8, x8, x9, lo
1029eb4a8:     	str	x8, [sp, #0x38]
1029eb4ac:     	b	0x1029eb4c0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x88>
1029eb4b0:     	mov	x0, x19
1029eb4b4:     	bl	0x102e8be28 <__RNvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift11sqrt_approx>
1029eb4b8:     	ldr	x3, [sp, #0x78]
1029eb4bc:     	str	x0, [sp, #0x38]
1029eb4c0:     	mov	x23, #0x0               ; =0
1029eb4c4:     	mov	x20, #0x0               ; =0
1029eb4c8:     	ldr	x8, [sp, #0x60]
1029eb4cc:     	add	x10, x8, #0x82
1029eb4d0:     	sub	x9, x8, #0x20
1029eb4d4:     	stp	x9, x10, [sp, #0x8]
1029eb4d8:     	add	x9, x8, #0x20
1029eb4dc:     	str	x9, [sp]
1029eb4e0:     	sub	x8, x8, #0x40
1029eb4e4:     	str	x8, [sp, #0x20]
1029eb4e8:     	mov	w24, #0x1               ; =1
1029eb4ec:     	str	x26, [sp, #0x50]
1029eb4f0:     	str	x19, [sp, #0x30]
1029eb4f4:     	subs	x9, x19, x23
1029eb4f8:     	b.ls	0x1029eb554 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x11c>
1029eb4fc:     	ldr	x8, [sp, #0x60]
1029eb500:     	add	x0, x8, x23, lsl #6
1029eb504:     	ldr	x8, [sp, #0x38]
1029eb508:     	cmp	x9, x8
1029eb50c:     	b.hs	0x1029eb568 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x130>
1029eb510:     	ldr	w8, [sp, #0x1c]
1029eb514:     	tbz	w8, #0x0, 0x1029eb578 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x140>
1029eb518:     	cmp	x9, #0x20
1029eb51c:     	mov	w8, #0x20               ; =32
1029eb520:     	csel	x26, x9, x8, lo
1029eb524:     	mov	x1, x26
1029eb528:     	ldr	x2, [sp, #0x68]
1029eb52c:     	ldr	x3, [sp, #0x78]
1029eb530:     	mov	w4, #0x0                ; =0
1029eb534:     	mov	x5, #0x0                ; =0
1029eb538:     	ldr	x6, [sp, #0x50]
1029eb53c:     	bl	0x1029921d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>
1029eb540:     	ldr	x3, [sp, #0x78]
1029eb544:     	mov	w8, #0x1                ; =1
1029eb548:     	orr	x11, x8, x26, lsl #1
1029eb54c:     	ldr	x26, [sp, #0x50]
1029eb550:     	b	0x1029eb710 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x2d8>
1029eb554:     	mov	w10, #0x0               ; =0
1029eb558:     	mov	w11, #0x1               ; =1
1029eb55c:     	cmp	x20, #0x2
1029eb560:     	b.hs	0x1029eb738 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x300>
1029eb564:     	b	0x1029eb97c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x544>
1029eb568:     	cmp	x9, #0x2
1029eb56c:     	b.hs	0x1029eb58c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x154>
1029eb570:     	mov	x8, x9
1029eb574:     	b	0x1029eb708 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x2d0>
1029eb578:     	ldr	x8, [sp, #0x38]
1029eb57c:     	cmp	x9, x8
1029eb580:     	csel	x8, x9, x8, lo
1029eb584:     	lsl	x11, x8, #1
1029eb588:     	b	0x1029eb710 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x2d8>
1029eb58c:     	ldrb	w11, [x0, #0x40]
1029eb590:     	ldrh	w12, [x0, #0x42]
1029eb594:     	ldrb	w8, [x0]
1029eb598:     	ldrh	w10, [x0, #0x2]
1029eb59c:     	cmp	w12, w10
1029eb5a0:     	cset	w10, lo
1029eb5a4:     	subs	w13, w11, w8
1029eb5a8:     	mov	w14, #0xff              ; =255
1029eb5ac:     	bics	wzr, w14, w13
1029eb5b0:     	cset	w13, eq
1029eb5b4:     	cmp	w11, w8
1029eb5b8:     	csel	w10, w10, w13, eq
1029eb5bc:     	tbz	w10, #0x0, 0x1029eb5d4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x19c>
1029eb5c0:     	cmp	x9, #0x2
1029eb5c4:     	b.ne	0x1029eb5e4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x1ac>
1029eb5c8:     	mov	w9, #0x1                ; =1
1029eb5cc:     	mov	w8, #0x2                ; =2
1029eb5d0:     	b	0x1029eb6a4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x26c>
1029eb5d4:     	cmp	x9, #0x2
1029eb5d8:     	b.ne	0x1029eb638 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x200>
1029eb5dc:     	mov	w8, #0x2                ; =2
1029eb5e0:     	b	0x1029eb708 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x2d0>
1029eb5e4:     	ldr	x8, [sp, #0x10]
1029eb5e8:     	add	x13, x8, x23, lsl #6
1029eb5ec:     	mov	w8, #0x2                ; =2
1029eb5f0:     	ldurb	w14, [x13, #-0x2]
1029eb5f4:     	ldrh	w15, [x13], #0x40
1029eb5f8:     	sub	w16, w14, w11
1029eb5fc:     	cmp	w15, w12
1029eb600:     	cset	w12, lo
1029eb604:     	mov	w17, #0xff              ; =255
1029eb608:     	bics	wzr, w17, w16
1029eb60c:     	cset	w16, eq
1029eb610:     	cmp	w14, w11, uxtb
1029eb614:     	csel	w11, w12, w16, eq
1029eb618:     	cmp	w11, #0x1
1029eb61c:     	b.ne	0x1029eb688 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x250>
1029eb620:     	add	x8, x8, #0x1
1029eb624:     	mov	x12, x15
1029eb628:     	mov	x11, x14
1029eb62c:     	cmp	x9, x8
1029eb630:     	b.ne	0x1029eb5f0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x1b8>
1029eb634:     	b	0x1029eb684 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x24c>
1029eb638:     	ldr	x8, [sp, #0x10]
1029eb63c:     	add	x13, x8, x23, lsl #6
1029eb640:     	mov	w8, #0x2                ; =2
1029eb644:     	ldurb	w14, [x13, #-0x2]
1029eb648:     	ldrh	w15, [x13], #0x40
1029eb64c:     	sub	w16, w14, w11
1029eb650:     	cmp	w15, w12
1029eb654:     	cset	w12, lo
1029eb658:     	mov	w17, #0xff              ; =255
1029eb65c:     	bics	wzr, w17, w16
1029eb660:     	cset	w16, eq
1029eb664:     	cmp	w14, w11, uxtb
1029eb668:     	csel	w11, w12, w16, eq
1029eb66c:     	tbnz	w11, #0x0, 0x1029eb688 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x250>
1029eb670:     	add	x8, x8, #0x1
1029eb674:     	mov	x12, x15
1029eb678:     	mov	x11, x14
1029eb67c:     	cmp	x9, x8
1029eb680:     	b.ne	0x1029eb644 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x20c>
1029eb684:     	mov	x8, x9
1029eb688:     	ldr	x11, [sp, #0x38]
1029eb68c:     	cmp	x8, x11
1029eb690:     	b.lo	0x1029eb510 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0xd8>
1029eb694:     	lsr	x9, x8, #1
1029eb698:     	cmp	x9, #0x0
1029eb69c:     	csel	w10, wzr, w10, eq
1029eb6a0:     	tbz	w10, #0x0, 0x1029eb708 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x2d0>
1029eb6a4:     	lsl	x11, x23, #6
1029eb6a8:     	add	x10, x11, x8, lsl #6
1029eb6ac:     	ldp	x12, x13, [sp]
1029eb6b0:     	add	x10, x13, x10
1029eb6b4:     	add	x11, x12, x11
1029eb6b8:     	ldur	q0, [x11, #-0x20]
1029eb6bc:     	ldur	q1, [x10, #-0x20]
1029eb6c0:     	stur	q1, [x11, #-0x20]
1029eb6c4:     	stur	q0, [x10, #-0x20]
1029eb6c8:     	ldur	q0, [x11, #-0x10]
1029eb6cc:     	ldur	q1, [x10, #-0x10]
1029eb6d0:     	stur	q1, [x11, #-0x10]
1029eb6d4:     	stur	q0, [x10, #-0x10]
1029eb6d8:     	ldr	q0, [x11]
1029eb6dc:     	ldr	q1, [x10]
1029eb6e0:     	str	q1, [x11]
1029eb6e4:     	str	q0, [x10]
1029eb6e8:     	ldr	q0, [x11, #0x10]
1029eb6ec:     	ldr	q1, [x10, #0x10]
1029eb6f0:     	str	q1, [x11, #0x10]
1029eb6f4:     	str	q0, [x10, #0x10]
1029eb6f8:     	sub	x10, x10, #0x40
1029eb6fc:     	add	x11, x11, #0x40
1029eb700:     	sub	x9, x9, #0x1
1029eb704:     	cbnz	x9, 0x1029eb6b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x280>
1029eb708:     	mov	w9, #0x1                ; =1
1029eb70c:     	orr	x11, x9, x8, lsl #1
1029eb710:     	lsl	x8, x23, #1
1029eb714:     	sub	x9, x8, x24, lsr #1
1029eb718:     	add	x8, x8, x11, lsr #1
1029eb71c:     	ldr	x10, [sp, #0x28]
1029eb720:     	mul	x9, x9, x10
1029eb724:     	mul	x8, x8, x10
1029eb728:     	eor	x8, x8, x9
1029eb72c:     	clz	x10, x8
1029eb730:     	cmp	x20, #0x2
1029eb734:     	b.lo	0x1029eb97c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x544>
1029eb738:     	lsl	x8, x23, #6
1029eb73c:     	ldr	x9, [sp, #0x60]
1029eb740:     	add	x25, x9, x8
1029eb744:     	ldr	x9, [sp, #0x20]
1029eb748:     	add	x8, x9, x8
1029eb74c:     	stp	x8, x11, [sp, #0x40]
1029eb750:     	str	x23, [sp, #0x58]
1029eb754:     	str	x10, [sp, #0x70]
1029eb758:     	b	0x1029eb788 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x350>
1029eb75c:     	sub	x2, x8, x21
1029eb760:     	mov	x0, x23
1029eb764:     	mov	x1, x21
1029eb768:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029eb76c:     	ldr	x26, [sp, #0x50]
1029eb770:     	ldp	x10, x3, [sp, #0x70]
1029eb774:     	mov	w8, #0x1                ; =1
1029eb778:     	orr	x24, x8, x19, lsl #1
1029eb77c:     	ldr	x23, [sp, #0x58]
1029eb780:     	cmp	x22, #0x1
1029eb784:     	b.ls	0x1029eb970 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x538>
1029eb788:     	sub	x22, x20, #0x1
1029eb78c:     	sub	x8, x29, #0x9a
1029eb790:     	ldrb	w8, [x8, x22]
1029eb794:     	cmp	w8, w10
1029eb798:     	b.lo	0x1029eb974 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x53c>
1029eb79c:     	mov	x20, x22
1029eb7a0:     	add	x8, sp, #0x80
1029eb7a4:     	ldr	x8, [x8, x22, lsl #3]
1029eb7a8:     	lsr	x27, x8, #1
1029eb7ac:     	lsr	x28, x24, #1
1029eb7b0:     	orr	w9, w8, w24
1029eb7b4:     	and	x9, x9, #0x1
1029eb7b8:     	add	x19, x27, x28
1029eb7bc:     	cmp	x19, x3
1029eb7c0:     	ccmp	x9, #0x0, #0x0, ls
1029eb7c4:     	b.eq	0x1029eb7e8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x3b0>
1029eb7c8:     	sub	x9, x23, x19
1029eb7cc:     	ldr	x10, [sp, #0x60]
1029eb7d0:     	add	x23, x10, x9, lsl #6
1029eb7d4:     	tbz	w8, #0x0, 0x1029eb7f8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x3c0>
1029eb7d8:     	tbz	w24, #0x0, 0x1029eb82c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x3f4>
1029eb7dc:     	ldr	x10, [sp, #0x70]
1029eb7e0:     	cbnz	x28, 0x1029eb860 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x428>
1029eb7e4:     	b	0x1029eb774 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x33c>
1029eb7e8:     	lsl	x24, x19, #1
1029eb7ec:     	cmp	x22, #0x1
1029eb7f0:     	b.hi	0x1029eb788 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x350>
1029eb7f4:     	b	0x1029eb970 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x538>
1029eb7f8:     	orr	x8, x27, #0x1
1029eb7fc:     	clz	x8, x8
1029eb800:     	lsl	w8, w8, #1
1029eb804:     	eor	w4, w8, #0x7e
1029eb808:     	mov	x0, x23
1029eb80c:     	mov	x1, x27
1029eb810:     	ldr	x2, [sp, #0x68]
1029eb814:     	ldr	x3, [sp, #0x78]
1029eb818:     	mov	x5, #0x0                ; =0
1029eb81c:     	mov	x6, x26
1029eb820:     	bl	0x1029921d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>
1029eb824:     	ldr	x3, [sp, #0x78]
1029eb828:     	tbnz	w24, #0x0, 0x1029eb7dc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x3a4>
1029eb82c:     	add	x0, x23, x27, lsl #6
1029eb830:     	orr	x8, x28, #0x1
1029eb834:     	clz	x8, x8
1029eb838:     	lsl	w8, w8, #1
1029eb83c:     	eor	w4, w8, #0x7e
1029eb840:     	mov	x1, x28
1029eb844:     	ldr	x2, [sp, #0x68]
1029eb848:     	ldr	x3, [sp, #0x78]
1029eb84c:     	mov	x5, #0x0                ; =0
1029eb850:     	mov	x6, x26
1029eb854:     	bl	0x1029921d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>
1029eb858:     	ldp	x10, x3, [sp, #0x70]
1029eb85c:     	cbz	x28, 0x1029eb774 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x33c>
1029eb860:     	cbz	x27, 0x1029eb774 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x33c>
1029eb864:     	cmp	x28, x27
1029eb868:     	csel	x8, x28, x27, lo
1029eb86c:     	cmp	x3, x8
1029eb870:     	b.lo	0x1029eb774 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x33c>
1029eb874:     	add	x26, x23, x27, lsl #6
1029eb878:     	cmp	x27, x28
1029eb87c:     	csel	x1, x26, x23, hi
1029eb880:     	lsl	x24, x8, #6
1029eb884:     	ldr	x21, [sp, #0x68]
1029eb888:     	mov	x0, x21
1029eb88c:     	mov	x2, x24
1029eb890:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029eb894:     	add	x8, x21, x24
1029eb898:     	cmp	x27, x28
1029eb89c:     	b.ls	0x1029eb90c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x4d4>
1029eb8a0:     	ldr	x9, [sp, #0x40]
1029eb8a4:     	mov	w14, #0xff              ; =255
1029eb8a8:     	ldrb	w10, [x8, #-0x40]!
1029eb8ac:     	ldrh	w11, [x8, #0x2]
1029eb8b0:     	ldrb	w12, [x26, #-0x40]!
1029eb8b4:     	ldrh	w13, [x26, #0x2]
1029eb8b8:     	cmp	w11, w13
1029eb8bc:     	cset	w11, lo
1029eb8c0:     	subs	w13, w10, w12
1029eb8c4:     	bics	wzr, w14, w13
1029eb8c8:     	cset	w13, eq
1029eb8cc:     	cmp	w10, w12
1029eb8d0:     	csel	w10, w11, w13, eq
1029eb8d4:     	cmp	w10, #0x0
1029eb8d8:     	csel	x11, x26, x8, ne
1029eb8dc:     	ldp	q0, q1, [x11, #0x20]
1029eb8e0:     	ldp	q3, q2, [x11]
1029eb8e4:     	stp	q0, q1, [x9, #0x20]
1029eb8e8:     	stp	q3, q2, [x9], #-0x40
1029eb8ec:     	eor	w11, w10, #0x1
1029eb8f0:     	add	x26, x26, x11, lsl #6
1029eb8f4:     	add	x8, x8, x10, lsl #6
1029eb8f8:     	cmp	x26, x23
1029eb8fc:     	ccmp	x8, x21, #0x4, ne
1029eb900:     	b.ne	0x1029eb8a8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x470>
1029eb904:     	mov	x23, x26
1029eb908:     	b	0x1029eb75c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x324>
1029eb90c:     	mov	w13, #0xff              ; =255
1029eb910:     	ldrb	w9, [x26]
1029eb914:     	ldrh	w10, [x26, #0x2]
1029eb918:     	ldrb	w11, [x21]
1029eb91c:     	ldrh	w12, [x21, #0x2]
1029eb920:     	cmp	w10, w12
1029eb924:     	cset	w10, lo
1029eb928:     	subs	w12, w9, w11
1029eb92c:     	bics	wzr, w13, w12
1029eb930:     	cset	w12, eq
1029eb934:     	cmp	w9, w11
1029eb938:     	csel	w9, w10, w12, eq
1029eb93c:     	eor	w10, w9, #0x1
1029eb940:     	cmp	w9, #0x0
1029eb944:     	csel	x11, x26, x21, ne
1029eb948:     	ldp	q0, q1, [x11, #0x20]
1029eb94c:     	ldp	q3, q2, [x11]
1029eb950:     	stp	q0, q1, [x23, #0x20]
1029eb954:     	stp	q3, q2, [x23], #0x40
1029eb958:     	add	x21, x21, x10, lsl #6
1029eb95c:     	add	x26, x26, x9, lsl #6
1029eb960:     	cmp	x21, x8
1029eb964:     	ccmp	x26, x25, #0x4, ne
1029eb968:     	b.ne	0x1029eb910 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x4d8>
1029eb96c:     	b	0x1029eb75c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x324>
1029eb970:     	mov	w20, #0x1               ; =1
1029eb974:     	ldr	x19, [sp, #0x30]
1029eb978:     	ldr	x11, [sp, #0x48]
1029eb97c:     	add	x8, sp, #0x80
1029eb980:     	str	x24, [x8, x20, lsl #3]
1029eb984:     	sub	x8, x29, #0x9a
1029eb988:     	strb	w10, [x8, x20]
1029eb98c:     	cmp	x19, x23
1029eb990:     	b.ls	0x1029eb9ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x574>
1029eb994:     	add	x20, x20, #0x1
1029eb998:     	add	x23, x23, x11, lsr #1
1029eb99c:     	mov	x24, x11
1029eb9a0:     	subs	x9, x19, x23
1029eb9a4:     	b.ls	0x1029eb554 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x11c>
1029eb9a8:     	b	0x1029eb4fc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0xc4>
1029eb9ac:     	tbnz	w24, #0x0, 0x1029eb9d4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7D_+0x59c>
1029eb9b0:     	orr	x8, x19, #0x1
1029eb9b4:     	clz	x8, x8
1029eb9b8:     	lsl	w8, w8, #1
1029eb9bc:     	eor	w4, w8, #0x7e
1029eb9c0:     	ldp	x0, x2, [sp, #0x60]
1029eb9c4:     	mov	x1, x19
1029eb9c8:     	mov	x5, #0x0                ; =0
1029eb9cc:     	mov	x6, x26
1029eb9d0:     	bl	0x1029921d8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB7Q_>
1029eb9d4:     	add	sp, sp, #0x2e0
1029eb9d8:     	ldp	x29, x30, [sp, #0x50]
1029eb9dc:     	ldp	x20, x19, [sp, #0x40]
1029eb9e0:     	ldp	x22, x21, [sp, #0x30]
1029eb9e4:     	ldp	x24, x23, [sp, #0x20]
1029eb9e8:     	ldp	x26, x25, [sp, #0x10]
1029eb9ec:     	ldp	x28, x27, [sp], #0x60
1029eb9f0:     	ret
