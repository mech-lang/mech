
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a76284 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_>:
102a76284:     	sub	sp, sp, #0x70
102a76288:     	stp	x22, x21, [sp, #0x40]
102a7628c:     	stp	x20, x19, [sp, #0x50]
102a76290:     	stp	x29, x30, [sp, #0x60]
102a76294:     	add	x29, sp, #0x60
102a76298:     	cmp	x1, #0x2
102a7629c:     	b.lo	0x102a7694c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6c8>
102a762a0:     	add	x8, x1, #0x10
102a762a4:     	cmp	x3, x8
102a762a8:     	b.lo	0x102a76964 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6e0>
102a762ac:     	mov	x19, x2
102a762b0:     	mov	x20, x0
102a762b4:     	lsr	x8, x1, #1
102a762b8:     	lsl	x9, x8, #6
102a762bc:     	cmp	x1, #0x7
102a762c0:     	b.ls	0x102a765c8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x344>
102a762c4:     	ldrb	w11, [x20, #0xc0]
102a762c8:     	ldrh	w10, [x20, #0xc2]
102a762cc:     	ldrb	w12, [x20, #0x80]
102a762d0:     	ldrh	w13, [x20, #0x82]
102a762d4:     	cmp	w10, w13
102a762d8:     	cset	w13, lo
102a762dc:     	subs	w14, w11, w12
102a762e0:     	mov	w10, #0xff              ; =255
102a762e4:     	bics	wzr, w10, w14
102a762e8:     	cset	w14, eq
102a762ec:     	ldrb	w15, [x20, #0x40]
102a762f0:     	ldrh	w16, [x20, #0x42]
102a762f4:     	ldrb	w17, [x20]
102a762f8:     	ldrh	w0, [x20, #0x2]
102a762fc:     	cmp	w11, w12
102a76300:     	csel	w11, w13, w14, eq
102a76304:     	cmp	w16, w0
102a76308:     	cset	w12, lo
102a7630c:     	subs	w13, w15, w17
102a76310:     	bics	wzr, w10, w13
102a76314:     	cset	w13, eq
102a76318:     	cmp	w15, w17
102a7631c:     	csel	w14, w12, w13, eq
102a76320:     	eor	w12, w14, #0x1
102a76324:     	add	x15, x20, x12, lsl #6
102a76328:     	cmp	w11, #0x0
102a7632c:     	mov	w12, #0x80              ; =128
102a76330:     	mov	w13, #0xc0              ; =192
102a76334:     	csel	x11, x13, x12, ne
102a76338:     	csel	x16, x12, x13, ne
102a7633c:     	add	x16, x20, x16
102a76340:     	ldrb	w17, [x16]
102a76344:     	ldrh	w0, [x16, #0x2]
102a76348:     	ldrb	w2, [x15]
102a7634c:     	ldrh	w3, [x15, #0x2]
102a76350:     	cmp	w0, w3
102a76354:     	cset	w0, lo
102a76358:     	subs	w3, w17, w2
102a7635c:     	bics	wzr, w10, w3
102a76360:     	cset	w3, eq
102a76364:     	add	x14, x20, x14, lsl #6
102a76368:     	add	x11, x20, x11
102a7636c:     	ldrb	w4, [x11]
102a76370:     	ldrh	w5, [x11, #0x2]
102a76374:     	ldrb	w6, [x14]
102a76378:     	ldrh	w7, [x14, #0x2]
102a7637c:     	cmp	w17, w2
102a76380:     	csel	w17, w0, w3, eq
102a76384:     	cmp	w5, w7
102a76388:     	cset	w0, lo
102a7638c:     	subs	w2, w4, w6
102a76390:     	bics	wzr, w10, w2
102a76394:     	cset	w2, eq
102a76398:     	cmp	w4, w6
102a7639c:     	csel	w0, w0, w2, eq
102a763a0:     	cmp	w17, #0x0
102a763a4:     	csel	x2, x11, x15, ne
102a763a8:     	cmp	w0, #0x0
102a763ac:     	csel	x0, x11, x14, ne
102a763b0:     	csel	x14, x14, x2, ne
102a763b4:     	csel	x2, x15, x11, ne
102a763b8:     	cmp	w17, #0x0
102a763bc:     	csel	x11, x15, x16, ne
102a763c0:     	csel	x15, x16, x2, ne
102a763c4:     	ldrb	w16, [x15]
102a763c8:     	ldrh	w17, [x15, #0x2]
102a763cc:     	ldrb	w2, [x14]
102a763d0:     	ldrh	w3, [x14, #0x2]
102a763d4:     	cmp	w17, w3
102a763d8:     	cset	w17, lo
102a763dc:     	subs	w3, w16, w2
102a763e0:     	bics	wzr, w10, w3
102a763e4:     	cset	w3, eq
102a763e8:     	cmp	w16, w2
102a763ec:     	csel	w16, w17, w3, eq
102a763f0:     	cmp	w16, #0x0
102a763f4:     	csel	x16, x15, x14, ne
102a763f8:     	csel	x14, x14, x15, ne
102a763fc:     	ldp	q0, q1, [x0]
102a76400:     	stp	q0, q1, [x19]
102a76404:     	ldp	q0, q1, [x0, #0x20]
102a76408:     	stp	q0, q1, [x19, #0x20]
102a7640c:     	ldp	q0, q1, [x16]
102a76410:     	stp	q0, q1, [x19, #0x40]
102a76414:     	ldp	q0, q1, [x16, #0x20]
102a76418:     	stp	q0, q1, [x19, #0x60]
102a7641c:     	ldp	q0, q1, [x14]
102a76420:     	ldp	q2, q3, [x14, #0x20]
102a76424:     	add	x14, x20, x9
102a76428:     	ldrb	w15, [x14, #0xc0]
102a7642c:     	ldrh	w16, [x14, #0xc2]
102a76430:     	ldrb	w17, [x14, #0x80]
102a76434:     	ldrh	w0, [x14, #0x82]
102a76438:     	cmp	w16, w0
102a7643c:     	cset	w16, lo
102a76440:     	subs	w0, w15, w17
102a76444:     	bics	wzr, w10, w0
102a76448:     	cset	w0, eq
102a7644c:     	ldrb	w2, [x14, #0x40]
102a76450:     	ldrh	w3, [x14, #0x42]
102a76454:     	ldrb	w4, [x14]
102a76458:     	ldrh	w5, [x14, #0x2]
102a7645c:     	cmp	w15, w17
102a76460:     	csel	w15, w16, w0, eq
102a76464:     	cmp	w3, w5
102a76468:     	cset	w16, lo
102a7646c:     	subs	w17, w2, w4
102a76470:     	bics	wzr, w10, w17
102a76474:     	cset	w17, eq
102a76478:     	cmp	w2, w4
102a7647c:     	csel	w16, w16, w17, eq
102a76480:     	eor	w17, w16, #0x1
102a76484:     	cmp	w15, #0x0
102a76488:     	csel	x15, x12, x13, ne
102a7648c:     	add	x15, x14, x15
102a76490:     	add	x17, x14, x17, lsl #6
102a76494:     	csel	x12, x13, x12, ne
102a76498:     	ldrb	w13, [x15]
102a7649c:     	ldrh	w0, [x15, #0x2]
102a764a0:     	ldrb	w2, [x17]
102a764a4:     	ldrh	w3, [x17, #0x2]
102a764a8:     	cmp	w0, w3
102a764ac:     	cset	w0, lo
102a764b0:     	subs	w3, w13, w2
102a764b4:     	bics	wzr, w10, w3
102a764b8:     	cset	w3, eq
102a764bc:     	add	x16, x14, x16, lsl #6
102a764c0:     	add	x12, x14, x12
102a764c4:     	ldrb	w14, [x12]
102a764c8:     	ldrh	w4, [x12, #0x2]
102a764cc:     	ldrb	w5, [x16]
102a764d0:     	ldrh	w6, [x16, #0x2]
102a764d4:     	cmp	w13, w2
102a764d8:     	csel	w13, w0, w3, eq
102a764dc:     	cmp	w4, w6
102a764e0:     	cset	w0, lo
102a764e4:     	subs	w2, w14, w5
102a764e8:     	bics	wzr, w10, w2
102a764ec:     	cset	w2, eq
102a764f0:     	cmp	w14, w5
102a764f4:     	csel	w14, w0, w2, eq
102a764f8:     	cmp	w13, #0x0
102a764fc:     	csel	x0, x12, x17, ne
102a76500:     	cmp	w14, #0x0
102a76504:     	csel	x14, x12, x16, ne
102a76508:     	csel	x16, x16, x0, ne
102a7650c:     	csel	x0, x17, x12, ne
102a76510:     	cmp	w13, #0x0
102a76514:     	csel	x12, x17, x15, ne
102a76518:     	csel	x13, x15, x0, ne
102a7651c:     	ldrb	w15, [x13]
102a76520:     	ldrh	w17, [x13, #0x2]
102a76524:     	ldrb	w0, [x16]
102a76528:     	ldrh	w2, [x16, #0x2]
102a7652c:     	cmp	w17, w2
102a76530:     	cset	w17, lo
102a76534:     	subs	w2, w15, w0
102a76538:     	bics	wzr, w10, w2
102a7653c:     	cset	w10, eq
102a76540:     	stp	q2, q3, [x19, #0xa0]
102a76544:     	stp	q0, q1, [x19, #0x80]
102a76548:     	ldp	q0, q1, [x11]
102a7654c:     	stp	q0, q1, [x19, #0xc0]
102a76550:     	ldp	q0, q1, [x11, #0x20]
102a76554:     	stp	q0, q1, [x19, #0xe0]
102a76558:     	add	x11, x19, x9
102a7655c:     	cmp	w15, w0
102a76560:     	csel	w10, w17, w10, eq
102a76564:     	cmp	w10, #0x0
102a76568:     	csel	x10, x13, x16, ne
102a7656c:     	csel	x13, x16, x13, ne
102a76570:     	ldp	q0, q1, [x14]
102a76574:     	stp	q0, q1, [x11]
102a76578:     	ldp	q0, q1, [x14, #0x20]
102a7657c:     	stp	q0, q1, [x11, #0x20]
102a76580:     	ldp	q0, q1, [x10]
102a76584:     	stp	q0, q1, [x11, #0x40]
102a76588:     	ldp	q0, q1, [x10, #0x20]
102a7658c:     	stp	q0, q1, [x11, #0x60]
102a76590:     	ldp	q0, q1, [x13]
102a76594:     	ldp	q2, q3, [x13, #0x20]
102a76598:     	stp	q2, q3, [x11, #0xa0]
102a7659c:     	stp	q0, q1, [x11, #0x80]
102a765a0:     	ldp	q0, q1, [x12]
102a765a4:     	stp	q0, q1, [x11, #0xc0]
102a765a8:     	ldp	q0, q1, [x12, #0x20]
102a765ac:     	stp	q0, q1, [x11, #0xe0]
102a765b0:     	mov	w11, #0x4               ; =4
102a765b4:     	sub	x12, x1, x8
102a765b8:     	lsl	x13, x11, #6
102a765bc:     	cmp	x11, x8
102a765c0:     	b.lo	0x102a76604 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x380>
102a765c4:     	b	0x102a76710 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
102a765c8:     	ldp	q0, q1, [x20]
102a765cc:     	stp	q0, q1, [x19]
102a765d0:     	ldp	q0, q1, [x20, #0x20]
102a765d4:     	stp	q0, q1, [x19, #0x20]
102a765d8:     	add	x10, x20, x9
102a765dc:     	add	x12, x19, x9
102a765e0:     	ldp	q0, q1, [x10]
102a765e4:     	stp	q0, q1, [x12]
102a765e8:     	ldp	q0, q1, [x10, #0x20]
102a765ec:     	mov	w11, #0x1               ; =1
102a765f0:     	stp	q0, q1, [x12, #0x20]
102a765f4:     	sub	x12, x1, x8
102a765f8:     	lsl	x13, x11, #6
102a765fc:     	cmp	x11, x8
102a76600:     	b.hs	0x102a76710 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
102a76604:     	mov	w10, #0xff              ; =255
102a76608:     	mov	x14, x13
102a7660c:     	mov	x15, x11
102a76610:     	b	0x102a76650 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x3cc>
102a76614:     	mov	x2, x19
102a76618:     	strb	w17, [x2]
102a7661c:     	strb	w0, [x2, #0x1]
102a76620:     	strh	w16, [x2, #0x2]
102a76624:     	ldp	q0, q1, [sp]
102a76628:     	stur	q0, [x2, #0x4]
102a7662c:     	stur	q1, [x2, #0x14]
102a76630:     	ldr	q0, [sp, #0x20]
102a76634:     	stur	q0, [x2, #0x24]
102a76638:     	ldur	q0, [sp, #0x2c]
102a7663c:     	str	q0, [x2, #0x30]
102a76640:     	add	x15, x15, #0x1
102a76644:     	add	x14, x14, #0x40
102a76648:     	cmp	x15, x8
102a7664c:     	b.eq	0x102a76710 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
102a76650:     	lsl	x16, x15, #6
102a76654:     	add	x2, x20, x16
102a76658:     	add	x0, x19, x16
102a7665c:     	ldp	q0, q1, [x2]
102a76660:     	stp	q0, q1, [x0]
102a76664:     	ldrb	w17, [x0]
102a76668:     	ldrh	w16, [x0, #0x2]
102a7666c:     	ldurb	w3, [x0, #-0x40]
102a76670:     	ldurh	w4, [x0, #-0x3e]
102a76674:     	cmp	w16, w4
102a76678:     	cset	w4, lo
102a7667c:     	subs	w5, w17, w3
102a76680:     	bics	wzr, w10, w5
102a76684:     	cset	w5, eq
102a76688:     	ldp	q0, q1, [x2, #0x20]
102a7668c:     	stp	q0, q1, [x0, #0x20]
102a76690:     	cmp	w17, w3
102a76694:     	csel	w3, w4, w5, eq
102a76698:     	cmp	w3, #0x1
102a7669c:     	b.ne	0x102a76640 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x3bc>
102a766a0:     	ldrb	w0, [x0, #0x1]
102a766a4:     	ldur	q0, [x2, #0x4]
102a766a8:     	ldur	q1, [x2, #0x14]
102a766ac:     	stp	q0, q1, [sp]
102a766b0:     	ldur	q0, [x2, #0x24]
102a766b4:     	str	q0, [sp, #0x20]
102a766b8:     	ldr	q0, [x2, #0x30]
102a766bc:     	stur	q0, [sp, #0x2c]
102a766c0:     	mov	x2, x14
102a766c4:     	add	x3, x19, x2
102a766c8:     	ldp	q0, q1, [x3, #-0x40]
102a766cc:     	stp	q0, q1, [x3]
102a766d0:     	ldp	q0, q1, [x3, #-0x20]
102a766d4:     	stp	q0, q1, [x3, #0x20]
102a766d8:     	subs	x2, x2, #0x40
102a766dc:     	b.eq	0x102a76614 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x390>
102a766e0:     	ldurb	w4, [x3, #-0x80]
102a766e4:     	ldurh	w3, [x3, #-0x7e]
102a766e8:     	cmp	w16, w3
102a766ec:     	cset	w3, lo
102a766f0:     	subs	w5, w17, w4
102a766f4:     	bics	wzr, w10, w5
102a766f8:     	cset	w5, eq
102a766fc:     	cmp	w17, w4
102a76700:     	csel	w3, w3, w5, eq
102a76704:     	tbnz	w3, #0x0, 0x102a766c4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x440>
102a76708:     	add	x2, x19, x2
102a7670c:     	b	0x102a76618 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x394>
102a76710:     	add	x10, x19, x9
102a76714:     	cmp	x11, x12
102a76718:     	b.hs	0x102a7683c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5b8>
102a7671c:     	add	x9, x20, x9
102a76720:     	mov	w14, #0x40              ; =64
102a76724:     	mov	w15, #0xff              ; =255
102a76728:     	mov	x16, x10
102a7672c:     	b	0x102a76770 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4ec>
102a76730:     	mov	x3, x10
102a76734:     	strb	w0, [x3]
102a76738:     	strb	w2, [x3, #0x1]
102a7673c:     	strh	w17, [x3, #0x2]
102a76740:     	ldp	q2, q0, [sp, #0x10]
102a76744:     	ldur	q1, [sp, #0x2c]
102a76748:     	ldr	q3, [sp]
102a7674c:     	stur	q3, [x3, #0x4]
102a76750:     	str	q1, [x3, #0x30]
102a76754:     	stur	q0, [x3, #0x24]
102a76758:     	stur	q2, [x3, #0x14]
102a7675c:     	add	x11, x11, #0x1
102a76760:     	add	x16, x16, #0x40
102a76764:     	sub	x14, x14, #0x40
102a76768:     	cmp	x11, x12
102a7676c:     	b.eq	0x102a7683c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5b8>
102a76770:     	lsl	x17, x11, #6
102a76774:     	add	x3, x9, x17
102a76778:     	add	x2, x10, x17
102a7677c:     	ldp	q0, q1, [x3]
102a76780:     	stp	q0, q1, [x2]
102a76784:     	ldrb	w0, [x2]
102a76788:     	ldrh	w17, [x2, #0x2]
102a7678c:     	ldurb	w4, [x2, #-0x40]
102a76790:     	ldurh	w5, [x2, #-0x3e]
102a76794:     	cmp	w17, w5
102a76798:     	cset	w5, lo
102a7679c:     	subs	w6, w0, w4
102a767a0:     	bics	wzr, w15, w6
102a767a4:     	cset	w6, eq
102a767a8:     	ldp	q0, q1, [x3, #0x20]
102a767ac:     	stp	q0, q1, [x2, #0x20]
102a767b0:     	cmp	w0, w4
102a767b4:     	csel	w4, w5, w6, eq
102a767b8:     	cmp	w4, #0x1
102a767bc:     	b.ne	0x102a7675c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4d8>
102a767c0:     	ldrb	w2, [x2, #0x1]
102a767c4:     	ldur	q0, [x3, #0x4]
102a767c8:     	ldur	q1, [x3, #0x14]
102a767cc:     	stp	q0, q1, [sp]
102a767d0:     	ldur	q0, [x3, #0x24]
102a767d4:     	str	q0, [sp, #0x20]
102a767d8:     	ldr	q0, [x3, #0x30]
102a767dc:     	stur	q0, [sp, #0x2c]
102a767e0:     	mov	x4, x14
102a767e4:     	mov	x3, x16
102a767e8:     	add	x5, x3, x13
102a767ec:     	ldp	q0, q1, [x5, #-0x40]
102a767f0:     	stp	q0, q1, [x5]
102a767f4:     	ldp	q0, q1, [x5, #-0x20]
102a767f8:     	stp	q0, q1, [x5, #0x20]
102a767fc:     	cmp	x13, x4
102a76800:     	b.eq	0x102a76730 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4ac>
102a76804:     	ldurb	w6, [x5, #-0x80]
102a76808:     	ldurh	w5, [x5, #-0x7e]
102a7680c:     	cmp	w17, w5
102a76810:     	cset	w5, lo
102a76814:     	subs	w7, w0, w6
102a76818:     	bics	wzr, w15, w7
102a7681c:     	cset	w7, eq
102a76820:     	cmp	w0, w6
102a76824:     	csel	w5, w5, w7, eq
102a76828:     	sub	x3, x3, #0x40
102a7682c:     	add	x4, x4, #0x40
102a76830:     	tbnz	w5, #0x0, 0x102a767e8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x564>
102a76834:     	add	x3, x3, x13
102a76838:     	b	0x102a76734 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4b0>
102a7683c:     	lsl	x21, x1, #6
102a76840:     	sub	x13, x21, #0x40
102a76844:     	add	x12, x19, x13
102a76848:     	sub	x14, x10, #0x40
102a7684c:     	mov	w15, #0xff              ; =255
102a76850:     	mov	x11, x20
102a76854:     	mov	x9, x19
102a76858:     	ldrb	w16, [x12]
102a7685c:     	ldrh	w17, [x12, #0x2]
102a76860:     	ldrb	w0, [x14]
102a76864:     	ldrh	w2, [x14, #0x2]
102a76868:     	cmp	w17, w2
102a7686c:     	cset	w17, lo
102a76870:     	subs	w2, w16, w0
102a76874:     	bics	wzr, w15, w2
102a76878:     	cset	w2, eq
102a7687c:     	ldrb	w3, [x10]
102a76880:     	ldrh	w4, [x10, #0x2]
102a76884:     	ldrb	w5, [x9]
102a76888:     	ldrh	w6, [x9, #0x2]
102a7688c:     	cmp	w16, w0
102a76890:     	csel	w16, w17, w2, eq
102a76894:     	cmp	w4, w6
102a76898:     	cset	w17, lo
102a7689c:     	subs	w0, w3, w5
102a768a0:     	bics	wzr, w15, w0
102a768a4:     	cset	w0, eq
102a768a8:     	add	x2, x20, x13
102a768ac:     	cmp	w3, w5
102a768b0:     	csel	w17, w17, w0, eq
102a768b4:     	cmp	w17, #0x0
102a768b8:     	csel	x0, x10, x9, ne
102a768bc:     	eor	w3, w17, #0x1
102a768c0:     	ldp	q1, q0, [x0, #0x20]
102a768c4:     	stp	q1, q0, [x11, #0x20]
102a768c8:     	ldp	q1, q0, [x0]
102a768cc:     	stp	q1, q0, [x11], #0x40
102a768d0:     	add	x10, x10, x17, lsl #6
102a768d4:     	add	x9, x9, x3, lsl #6
102a768d8:     	cmp	w16, #0x0
102a768dc:     	csel	x17, x14, x12, ne
102a768e0:     	ldp	q1, q0, [x17, #0x20]
102a768e4:     	stp	q1, q0, [x2, #0x20]
102a768e8:     	ldp	q1, q0, [x17]
102a768ec:     	stp	q1, q0, [x2]
102a768f0:     	add	x12, x12, x16, lsl #6
102a768f4:     	sub	x12, x12, #0x40
102a768f8:     	sbfx	x16, x16, #0, #1
102a768fc:     	add	x14, x14, x16, lsl #6
102a76900:     	sub	x13, x13, #0x40
102a76904:     	sub	x8, x8, #0x1
102a76908:     	cbnz	x8, 0x102a76858 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5d4>
102a7690c:     	add	x8, x14, #0x40
102a76910:     	add	x12, x12, #0x40
102a76914:     	tbz	w1, #0x0, 0x102a76940 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6bc>
102a76918:     	cmp	x9, x8
102a7691c:     	csel	x13, x9, x10, lo
102a76920:     	cset	w14, hs
102a76924:     	cset	w15, lo
102a76928:     	ldp	q0, q1, [x13]
102a7692c:     	stp	q0, q1, [x11]
102a76930:     	ldp	q0, q1, [x13, #0x20]
102a76934:     	stp	q0, q1, [x11, #0x20]
102a76938:     	add	x9, x9, x15, lsl #6
102a7693c:     	add	x10, x10, x14, lsl #6
102a76940:     	cmp	x9, x8
102a76944:     	ccmp	x10, x12, #0x0, eq
102a76948:     	b.ne	0x102a76960 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6dc>
102a7694c:     	ldp	x29, x30, [sp, #0x60]
102a76950:     	ldp	x20, x19, [sp, #0x50]
102a76954:     	ldp	x22, x21, [sp, #0x40]
102a76958:     	add	sp, sp, #0x70
102a7695c:     	ret
102a76960:     	bl	0x103a05ffc <__RNvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort22panic_on_ord_violation>
102a76964:     	brk	#0x1
102a76968:     	mov	x22, x0
102a7696c:     	mov	x0, x20
102a76970:     	mov	x1, x19
102a76974:     	mov	x2, x21
102a76978:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
102a7697c:     	mov	x0, x22
102a76980:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
