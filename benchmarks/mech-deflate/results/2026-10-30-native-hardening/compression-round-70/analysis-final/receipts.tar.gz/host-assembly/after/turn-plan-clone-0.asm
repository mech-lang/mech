
/private/tmp/mech-observed-plan-transfer-round70-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023a4980 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
1023a4980:     	stp	d9, d8, [sp, #-0x70]!
1023a4984:     	stp	x28, x27, [sp, #0x10]
1023a4988:     	stp	x26, x25, [sp, #0x20]
1023a498c:     	stp	x24, x23, [sp, #0x30]
1023a4990:     	stp	x22, x21, [sp, #0x40]
1023a4994:     	stp	x20, x19, [sp, #0x50]
1023a4998:     	stp	x29, x30, [sp, #0x60]
1023a499c:     	add	x29, sp, #0x60
1023a49a0:     	sub	sp, sp, #0x970
1023a49a4:     	str	xzr, [sp]
1023a49a8:     	mov	x20, x1
1023a49ac:     	mov	x23, x0
1023a49b0:     	ldr	w19, [x1, #0x678]
1023a49b4:     	ldr	x8, [x1, #0x80]
1023a49b8:     	cbz	x8, 0x1023a4a0c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8c>
1023a49bc:     	ldr	x1, [x20, #0x70]
1023a49c0:     	cbz	x1, 0x1023a5390 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa10>
1023a49c4:     	ldr	x2, [x20, #0x78]
1023a49c8:     	add	x0, sp, #0x8a0
1023a49cc:     	bl	0x10254d278 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model16RegionAccessPlanNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1023a49d0:     	ldr	x8, [x20, #0x98]
1023a49d4:     	cbz	x8, 0x1023a4a1c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9c>
1023a49d8:     	ldr	x1, [x20, #0x88]
1023a49dc:     	cbz	x1, 0x1023a539c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa1c>
1023a49e0:     	ldr	x2, [x20, #0x90]
1023a49e4:     	add	x0, sp, #0x5f8
1023a49e8:     	bl	0x10254cf10 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB2d_18operation_contract10validation13PortDirectiontENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1023a49ec:     	ldr	x8, [x20, #0xb0]
1023a49f0:     	cbz	x8, 0x1023a4a2c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xac>
1023a49f4:     	ldr	x1, [x20, #0xa0]
1023a49f8:     	cbz	x1, 0x1023a53ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa2c>
1023a49fc:     	ldr	x2, [x20, #0xa8]
1023a4a00:     	add	x0, sp, #0x210
1023a4a04:     	bl	0x10254d5bc <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1023a4a08:     	b	0x1023a4a34 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xb4>
1023a4a0c:     	str	xzr, [sp, #0x8a0]
1023a4a10:     	str	xzr, [sp, #0x8b0]
1023a4a14:     	ldr	x8, [x20, #0x98]
1023a4a18:     	cbnz	x8, 0x1023a49d8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x58>
1023a4a1c:     	str	xzr, [sp, #0x5f8]
1023a4a20:     	str	xzr, [sp, #0x608]
1023a4a24:     	ldr	x8, [x20, #0xb0]
1023a4a28:     	cbnz	x8, 0x1023a49f4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x74>
1023a4a2c:     	str	xzr, [sp, #0x210]
1023a4a30:     	str	xzr, [sp, #0x220]
1023a4a34:     	add	x8, x20, #0xb8
1023a4a38:     	ldr	q0, [x8, #0x50]
1023a4a3c:     	add	x8, sp, #0xf0
1023a4a40:     	add	x8, x8, #0xb8
1023a4a44:     	str	q0, [x8, #0x50]
1023a4a48:     	add	x12, sp, #0x5f8
1023a4a4c:     	add	x8, sp, #0xf0
1023a4a50:     	ldur	q0, [x20, #0xe8]
1023a4a54:     	stur	q0, [x8, #0xe8]
1023a4a58:     	ldur	q0, [x20, #0xf8]
1023a4a5c:     	stur	q0, [x8, #0xf8]
1023a4a60:     	ldr	x9, [x20, #0x118]
1023a4a64:     	ldur	q0, [x20, #0xb8]
1023a4a68:     	stur	q0, [x8, #0xb8]
1023a4a6c:     	ldur	q0, [x20, #0xc8]
1023a4a70:     	stur	q0, [x8, #0xc8]
1023a4a74:     	ldur	q0, [x20, #0xd8]
1023a4a78:     	stur	q0, [x8, #0xd8]
1023a4a7c:     	ldr	q0, [sp, #0x8a0]
1023a4a80:     	ldr	x10, [sp, #0x8b0]
1023a4a84:     	ldr	x11, [sp, #0x608]
1023a4a88:     	str	x10, [sp, #0x170]
1023a4a8c:     	str	x11, [sp, #0x188]
1023a4a90:     	ldr	q1, [x12]
1023a4a94:     	stur	q1, [x8, #0x88]
1023a4a98:     	ldr	x8, [sp, #0x220]
1023a4a9c:     	str	x9, [sp, #0x208]
1023a4aa0:     	str	x8, [sp, #0x1a0]
1023a4aa4:     	ldr	q1, [sp, #0x210]
1023a4aa8:     	str	q1, [sp, #0x190]
1023a4aac:     	ldp	q2, q1, [x20]
1023a4ab0:     	stp	q2, q1, [sp, #0xf0]
1023a4ab4:     	ldr	q1, [x20, #0x60]
1023a4ab8:     	stp	q1, q0, [sp, #0x150]
1023a4abc:     	ldp	q1, q0, [x20, #0x40]
1023a4ac0:     	stp	q1, q0, [sp, #0x130]
1023a4ac4:     	ldp	q0, q1, [x20, #0x20]
1023a4ac8:     	stp	q0, q1, [sp, #0x110]
1023a4acc:     	ldr	x8, [x20, #0x1c8]
1023a4ad0:     	cmp	x8, #0x2
1023a4ad4:     	b.ne	0x1023a4b2c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1ac>
1023a4ad8:     	str	x8, [sp, #0x210]
1023a4adc:     	add	x0, x20, #0x5b0
1023a4ae0:     	bl	0x10275aabc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4ae4:     	str	x0, [sp, #0xd8]
1023a4ae8:     	mov	x22, x1
1023a4aec:     	add	x0, x20, #0x5c0
1023a4af0:     	bl	0x10275b230 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4af4:     	str	x1, [sp, #0xe8]
1023a4af8:     	mov	x24, x0
1023a4afc:     	ldr	x25, [x20, #0x5d8]
1023a4b00:     	add	x8, x25, x25, lsl #1
1023a4b04:     	lsl	x27, x8, #2
1023a4b08:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1023a4b0c:     	movk	x8, #0xaaa, lsl #48
1023a4b10:     	cmp	x25, x8
1023a4b14:     	b.ls	0x1023a4b68 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1e8>
1023a4b18:     	mov	x26, #0x0               ; =0
1023a4b1c:     	mov	x0, x26
1023a4b20:     	mov	x1, x27
1023a4b24:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a4b28:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a4b2c:     	str	w19, [sp, #0xe4]
1023a4b30:     	ldr	x19, [x20, #0x440]
1023a4b34:     	add	x0, x20, #0x430
1023a4b38:     	bl	0x102e81e4c <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1023a4b3c:     	mov	x22, x0
1023a4b40:     	mov	x21, x1
1023a4b44:     	ldr	x28, [x20, #0x410]
1023a4b48:     	lsl	x24, x28, #1
1023a4b4c:     	orr	x8, x24, x28
1023a4b50:     	tbz	x8, #0x3f, 0x1023a4bbc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x23c>
1023a4b54:     	mov	x26, #0x0               ; =0
1023a4b58:     	mov	x0, x26
1023a4b5c:     	mov	x1, x24
1023a4b60:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a4b64:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a4b68:     	str	w19, [sp, #0xe4]
1023a4b6c:     	cbz	x27, 0x1023a4c18 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
1023a4b70:     	ldr	x21, [x20, #0x5d0]
1023a4b74:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a4b78:     	mov	w26, #0x4               ; =4
1023a4b7c:     	mov	x0, x27
1023a4b80:     	mov	w1, #0x4                ; =4
1023a4b84:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a4b88:     	str	x0, [sp, #0xc8]
1023a4b8c:     	cbz	x0, 0x1023a4b1c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x19c>
1023a4b90:     	cbz	x25, 0x1023a4ba4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x224>
1023a4b94:     	ldr	x0, [sp, #0xc8]
1023a4b98:     	mov	x1, x21
1023a4b9c:     	mov	x2, x27
1023a4ba0:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a4ba4:     	mov	x21, #0x0               ; =0
1023a4ba8:     	ldr	x19, [x20, #0x5e8]
1023a4bac:     	lsl	x28, x19, #5
1023a4bb0:     	lsr	x8, x19, #59
1023a4bb4:     	cbz	x8, 0x1023a4c34 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
1023a4bb8:     	b	0x1023a4ca8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1023a4bbc:     	str	x23, [sp, #0xd0]
1023a4bc0:     	ldrb	w27, [x20, #0x400]
1023a4bc4:     	cbz	x24, 0x1023a4cb8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x338>
1023a4bc8:     	ldr	x25, [x20, #0x408]
1023a4bcc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a4bd0:     	mov	w26, #0x1               ; =1
1023a4bd4:     	mov	x0, x24
1023a4bd8:     	mov	w1, #0x1                ; =1
1023a4bdc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a4be0:     	cbz	x0, 0x1023a4b58 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1d8>
1023a4be4:     	mov	x23, x0
1023a4be8:     	cbz	x28, 0x1023a4bfc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x27c>
1023a4bec:     	mov	x0, x23
1023a4bf0:     	mov	x1, x25
1023a4bf4:     	mov	x2, x24
1023a4bf8:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a4bfc:     	cbz	w27, 0x1023a4cc0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x340>
1023a4c00:     	ldrb	w8, [x20, #0x401]
1023a4c04:     	str	w8, [sp, #0xe8]
1023a4c08:     	ldrb	w27, [x20, #0x402]
1023a4c0c:     	mov	w25, #0x1               ; =1
1023a4c10:     	ldr	w26, [x20, #0x404]
1023a4c14:     	b	0x1023a4cc4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x344>
1023a4c18:     	mov	w8, #0x4                ; =4
1023a4c1c:     	str	x8, [sp, #0xc8]
1023a4c20:     	mov	x21, #0x0               ; =0
1023a4c24:     	ldr	x19, [x20, #0x5e8]
1023a4c28:     	lsl	x28, x19, #5
1023a4c2c:     	lsr	x8, x19, #59
1023a4c30:     	cbnz	x8, 0x1023a4ca8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1023a4c34:     	str	x23, [sp, #0xd0]
1023a4c38:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1023a4c3c:     	cmp	x28, x8
1023a4c40:     	b.hi	0x1023a4ca8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1023a4c44:     	ldr	x9, [x20, #0x658]
1023a4c48:     	ldr	x8, [x20, #0x660]
1023a4c4c:     	stp	x8, x9, [sp, #0xb8]
1023a4c50:     	cbz	x28, 0x1023a4ed8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x558>
1023a4c54:     	ldr	x23, [x20, #0x5e0]
1023a4c58:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a4c5c:     	mov	w21, #0x8               ; =8
1023a4c60:     	mov	x0, x28
1023a4c64:     	mov	w1, #0x8                ; =8
1023a4c68:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a4c6c:     	cbz	x0, 0x1023a4ca8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x328>
1023a4c70:     	mov	x26, x0
1023a4c74:     	cbz	x19, 0x1023a4edc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x55c>
1023a4c78:     	mov	x8, #0x0                ; =0
1023a4c7c:     	mov	x9, x19
1023a4c80:     	cmp	x28, x8
1023a4c84:     	b.eq	0x1023a4edc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x55c>
1023a4c88:     	add	x10, x23, x8
1023a4c8c:     	add	x11, x26, x8
1023a4c90:     	ldp	q0, q1, [x10]
1023a4c94:     	stp	q0, q1, [x11]
1023a4c98:     	add	x8, x8, #0x20
1023a4c9c:     	subs	x9, x9, #0x1
1023a4ca0:     	b.ne	0x1023a4c80 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x300>
1023a4ca4:     	b	0x1023a4edc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x55c>
1023a4ca8:     	mov	x0, x21
1023a4cac:     	mov	x1, x28
1023a4cb0:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a4cb4:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a4cb8:     	mov	w23, #0x1               ; =1
1023a4cbc:     	cbnz	w27, 0x1023a4c00 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x280>
1023a4cc0:     	mov	w25, #0x0               ; =0
1023a4cc4:     	add	x0, x20, #0x418
1023a4cc8:     	bl	0x10275b798 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4ccc:     	ldrb	w8, [x20, #0x428]
1023a4cd0:     	sub	w9, w8, #0x3
1023a4cd4:     	mov	w10, #0x2               ; =2
1023a4cd8:     	cmp	w8, #0x2
1023a4cdc:     	csel	w9, w9, w10, hi
1023a4ce0:     	and	w9, w9, #0xff
1023a4ce4:     	cmp	w9, #0x1
1023a4ce8:     	b.gt	0x1023a4cf8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x378>
1023a4cec:     	cbnz	w9, 0x1023a4d04 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x384>
1023a4cf0:     	mov	w8, #0x3                ; =3
1023a4cf4:     	b	0x1023a4d08 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x388>
1023a4cf8:     	cmp	w9, #0x2
1023a4cfc:     	ldrb	w9, [x20, #0x429]
1023a4d00:     	b	0x1023a4d08 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x388>
1023a4d04:     	mov	w8, #0x4                ; =4
1023a4d08:     	str	x19, [sp, #0x250]
1023a4d0c:     	str	x22, [sp, #0x240]
1023a4d10:     	str	x21, [sp, #0x248]
1023a4d14:     	strb	w25, [sp, #0x210]
1023a4d18:     	ldr	w10, [sp, #0xe8]
1023a4d1c:     	strb	w10, [sp, #0x211]
1023a4d20:     	strb	w27, [sp, #0x212]
1023a4d24:     	str	w26, [sp, #0x214]
1023a4d28:     	str	x23, [sp, #0x218]
1023a4d2c:     	str	x28, [sp, #0x220]
1023a4d30:     	str	x0, [sp, #0x228]
1023a4d34:     	str	x1, [sp, #0x230]
1023a4d38:     	strb	w8, [sp, #0x238]
1023a4d3c:     	strb	w9, [sp, #0x239]
1023a4d40:     	ldr	d8, [x20, #0x3f8]
1023a4d44:     	add	x0, x20, #0x448
1023a4d48:     	bl	0x10275b3d0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4d4c:     	mov	x22, x0
1023a4d50:     	mov	x21, x1
1023a4d54:     	add	x0, x20, #0x458
1023a4d58:     	bl	0x10275b3d0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4d5c:     	mov	x24, x0
1023a4d60:     	mov	x23, x1
1023a4d64:     	add	x8, x20, #0x3d0
1023a4d68:     	ldr	x9, [x20, #0x3d0]
1023a4d6c:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1023a4d70:     	cmp	x9, x10
1023a4d74:     	b.ne	0x1023a4d94 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x414>
1023a4d78:     	ldr	q0, [x8]
1023a4d7c:     	stur	q0, [x29, #-0x90]
1023a4d80:     	ldr	x8, [x8, #0x10]
1023a4d84:     	stur	x8, [x29, #-0x80]
1023a4d88:     	ldr	x25, [x20, #0x3e8]
1023a4d8c:     	ldr	x26, [x20, #0x3f0]
1023a4d90:     	b	0x1023a4dc4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x444>
1023a4d94:     	add	x0, x20, #0x3e8
1023a4d98:     	bl	0x1027556b8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4d9c:     	mov	x25, x0
1023a4da0:     	mov	x26, x1
1023a4da4:     	add	x8, sp, #0x5f8
1023a4da8:     	add	x0, x20, #0x3d0
1023a4dac:     	bl	0x102e819c8 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1023a4db0:     	add	x8, sp, #0x5f8
1023a4db4:     	ldr	q0, [x8]
1023a4db8:     	stur	q0, [x29, #-0x90]
1023a4dbc:     	ldr	x8, [sp, #0x608]
1023a4dc0:     	stur	x8, [x29, #-0x80]
1023a4dc4:     	ldrb	w8, [x20, #0x468]
1023a4dc8:     	ldp	q0, q1, [sp, #0x230]
1023a4dcc:     	str	q0, [sp, #0x8f0]
1023a4dd0:     	str	q1, [sp, #0x900]
1023a4dd4:     	ldr	x9, [sp, #0x250]
1023a4dd8:     	ldp	q1, q0, [sp, #0x210]
1023a4ddc:     	str	q0, [sp, #0x8e0]
1023a4de0:     	str	q1, [sp, #0x8d0]
1023a4de4:     	str	d8, [sp, #0x8c8]
1023a4de8:     	str	x9, [sp, #0x910]
1023a4dec:     	str	x22, [sp, #0x918]
1023a4df0:     	str	x21, [sp, #0x920]
1023a4df4:     	str	x24, [sp, #0x928]
1023a4df8:     	str	x23, [sp, #0x930]
1023a4dfc:     	ldur	q0, [x29, #-0x90]
1023a4e00:     	ldur	x9, [x29, #-0x80]
1023a4e04:     	str	q0, [sp, #0x8a0]
1023a4e08:     	str	x9, [sp, #0x8b0]
1023a4e0c:     	str	x25, [sp, #0x8b8]
1023a4e10:     	str	x26, [sp, #0x8c0]
1023a4e14:     	strb	w8, [sp, #0x938]
1023a4e18:     	add	x0, x20, #0x470
1023a4e1c:     	bl	0x10275abb4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4e20:     	mov	x26, x0
1023a4e24:     	mov	x24, x1
1023a4e28:     	add	x0, x20, #0x480
1023a4e2c:     	bl	0x10275abb4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4e30:     	mov	x28, x0
1023a4e34:     	mov	x27, x1
1023a4e38:     	add	x0, x20, #0x490
1023a4e3c:     	bl	0x10275af80 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4e40:     	str	x0, [sp, #0xd8]
1023a4e44:     	str	x1, [sp, #0xe8]
1023a4e48:     	add	x0, x20, #0x4a0
1023a4e4c:     	bl	0x10275af80 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a4e50:     	stp	x0, x1, [sp, #0xc0]
1023a4e54:     	mov	x22, #0x0               ; =0
1023a4e58:     	ldr	x25, [x20, #0x4b8]
1023a4e5c:     	lsl	x21, x25, #6
1023a4e60:     	lsr	x8, x25, #58
1023a4e64:     	cbnz	x8, 0x1023a4ec8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x548>
1023a4e68:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1023a4e6c:     	cmp	x21, x8
1023a4e70:     	b.hi	0x1023a4ec8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x548>
1023a4e74:     	stp	x26, x24, [sp, #0xb0]
1023a4e78:     	cbz	x21, 0x1023a4fdc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x65c>
1023a4e7c:     	ldr	x23, [x20, #0x4b0]
1023a4e80:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a4e84:     	mov	w22, #0x8               ; =8
1023a4e88:     	mov	x0, x21
1023a4e8c:     	mov	w1, #0x8                ; =8
1023a4e90:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a4e94:     	str	x0, [sp, #0xa0]
1023a4e98:     	cbz	x0, 0x1023a4ec8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x548>
1023a4e9c:     	cbz	x25, 0x1023a4eb0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x530>
1023a4ea0:     	ldr	x0, [sp, #0xa0]
1023a4ea4:     	mov	x1, x23
1023a4ea8:     	mov	x2, x21
1023a4eac:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a4eb0:     	mov	x23, #0x0               ; =0
1023a4eb4:     	ldr	x26, [x20, #0x4c8]
1023a4eb8:     	lsl	x22, x26, #6
1023a4ebc:     	lsr	x8, x26, #58
1023a4ec0:     	cbz	x8, 0x1023a4ff8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x678>
1023a4ec4:     	b	0x1023a5040 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1023a4ec8:     	mov	x0, x22
1023a4ecc:     	mov	x1, x21
1023a4ed0:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a4ed4:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a4ed8:     	mov	w26, #0x8               ; =8
1023a4edc:     	ldr	x21, [x20, #0x668]
1023a4ee0:     	ldr	x27, [x20, #0x670]
1023a4ee4:     	ldr	x23, [sp, #0xd0]
1023a4ee8:     	ldr	w8, [sp, #0xe4]
1023a4eec:     	str	w8, [x23, #0x678]
1023a4ef0:     	add	x1, sp, #0xf0
1023a4ef4:     	mov	x0, x23
1023a4ef8:     	mov	w2, #0x120              ; =288
1023a4efc:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a4f00:     	add	x0, x23, #0x1c8
1023a4f04:     	add	x1, sp, #0x210
1023a4f08:     	mov	w2, #0x3e8              ; =1000
1023a4f0c:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a4f10:     	ldr	x8, [sp, #0xd8]
1023a4f14:     	str	x8, [x23, #0x5b0]
1023a4f18:     	str	x22, [x23, #0x5b8]
1023a4f1c:     	str	x24, [x23, #0x5c0]
1023a4f20:     	ldr	x8, [sp, #0xe8]
1023a4f24:     	str	x8, [x23, #0x5c8]
1023a4f28:     	ldr	x8, [sp, #0xc8]
1023a4f2c:     	str	x8, [x23, #0x5d0]
1023a4f30:     	str	x25, [x23, #0x5d8]
1023a4f34:     	ldr	q0, [x20, #0x620]
1023a4f38:     	str	q0, [x23, #0x620]
1023a4f3c:     	ldr	q0, [x20, #0x630]
1023a4f40:     	str	q0, [x23, #0x630]
1023a4f44:     	ldr	q0, [x20, #0x640]
1023a4f48:     	str	q0, [x23, #0x640]
1023a4f4c:     	ldr	x8, [x20, #0x650]
1023a4f50:     	str	x8, [x23, #0x650]
1023a4f54:     	ldr	q0, [x20, #0x5f0]
1023a4f58:     	str	q0, [x23, #0x5f0]
1023a4f5c:     	ldr	q0, [x20, #0x600]
1023a4f60:     	str	q0, [x23, #0x600]
1023a4f64:     	ldr	q0, [x20, #0x610]
1023a4f68:     	str	q0, [x23, #0x610]
1023a4f6c:     	ldp	x8, x9, [sp, #0xb8]
1023a4f70:     	str	x9, [x23, #0x658]
1023a4f74:     	str	x8, [x23, #0x660]
1023a4f78:     	ldp	q1, q0, [x20, #0x120]
1023a4f7c:     	stp	q1, q0, [x23, #0x120]
1023a4f80:     	ldp	q1, q0, [x20, #0x160]
1023a4f84:     	stp	q1, q0, [x23, #0x160]
1023a4f88:     	ldp	q0, q1, [x20, #0x140]
1023a4f8c:     	stp	q0, q1, [x23, #0x140]
1023a4f90:     	ldr	x8, [x20, #0x1c0]
1023a4f94:     	str	x8, [x23, #0x1c0]
1023a4f98:     	ldp	q1, q0, [x20, #0x1a0]
1023a4f9c:     	stp	q1, q0, [x23, #0x1a0]
1023a4fa0:     	ldp	q0, q1, [x20, #0x180]
1023a4fa4:     	stp	q0, q1, [x23, #0x180]
1023a4fa8:     	str	x26, [x23, #0x5e0]
1023a4fac:     	str	x19, [x23, #0x5e8]
1023a4fb0:     	str	x21, [x23, #0x668]
1023a4fb4:     	str	x27, [x23, #0x670]
1023a4fb8:     	add	sp, sp, #0x970
1023a4fbc:     	ldp	x29, x30, [sp, #0x60]
1023a4fc0:     	ldp	x20, x19, [sp, #0x50]
1023a4fc4:     	ldp	x22, x21, [sp, #0x40]
1023a4fc8:     	ldp	x24, x23, [sp, #0x30]
1023a4fcc:     	ldp	x26, x25, [sp, #0x20]
1023a4fd0:     	ldp	x28, x27, [sp, #0x10]
1023a4fd4:     	ldp	d9, d8, [sp], #0x70
1023a4fd8:     	ret
1023a4fdc:     	mov	w8, #0x8                ; =8
1023a4fe0:     	str	x8, [sp, #0xa0]
1023a4fe4:     	mov	x23, #0x0               ; =0
1023a4fe8:     	ldr	x26, [x20, #0x4c8]
1023a4fec:     	lsl	x22, x26, #6
1023a4ff0:     	lsr	x8, x26, #58
1023a4ff4:     	cbnz	x8, 0x1023a5040 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1023a4ff8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1023a4ffc:     	cmp	x22, x8
1023a5000:     	b.hi	0x1023a5040 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1023a5004:     	cbz	x22, 0x1023a5050 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d0>
1023a5008:     	ldr	x24, [x20, #0x4c0]
1023a500c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a5010:     	mov	w23, #0x8               ; =8
1023a5014:     	mov	x0, x22
1023a5018:     	mov	w1, #0x8                ; =8
1023a501c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a5020:     	str	x0, [sp, #0x98]
1023a5024:     	cbz	x0, 0x1023a5040 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6c0>
1023a5028:     	cbz	x26, 0x1023a5058 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d8>
1023a502c:     	ldr	x0, [sp, #0x98]
1023a5030:     	mov	x1, x24
1023a5034:     	mov	x2, x22
1023a5038:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a503c:     	b	0x1023a5058 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6d8>
1023a5040:     	mov	x0, x23
1023a5044:     	mov	x1, x22
1023a5048:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a504c:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a5050:     	mov	w8, #0x8                ; =8
1023a5054:     	str	x8, [sp, #0x98]
1023a5058:     	ldr	x9, [x20, #0x4d8]
1023a505c:     	add	x8, x9, x9, lsl #1
1023a5060:     	lsl	x23, x8, #4
1023a5064:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1023a5068:     	movk	x8, #0x2aa, lsl #48
1023a506c:     	str	x9, [sp, #0x90]
1023a5070:     	cmp	x9, x8
1023a5074:     	b.ls	0x1023a508c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x70c>
1023a5078:     	mov	x24, #0x0               ; =0
1023a507c:     	mov	x0, x24
1023a5080:     	mov	x1, x23
1023a5084:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a5088:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a508c:     	cbz	x23, 0x1023a50f0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x770>
1023a5090:     	ldr	x19, [x20, #0x4d0]
1023a5094:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a5098:     	mov	w24, #0x8               ; =8
1023a509c:     	mov	x0, x23
1023a50a0:     	mov	w1, #0x8                ; =8
1023a50a4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a50a8:     	str	x0, [sp, #0xa8]
1023a50ac:     	cbz	x0, 0x1023a507c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x6fc>
1023a50b0:     	ldr	x9, [sp, #0x90]
1023a50b4:     	cbz	x9, 0x1023a50f8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x778>
1023a50b8:     	mov	x8, #0x0                ; =0
1023a50bc:     	cmp	x23, x8
1023a50c0:     	b.eq	0x1023a50f8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x778>
1023a50c4:     	add	x10, x19, x8
1023a50c8:     	ldr	x11, [sp, #0xa8]
1023a50cc:     	add	x11, x11, x8
1023a50d0:     	ldp	q0, q1, [x10]
1023a50d4:     	ldr	q2, [x10, #0x20]
1023a50d8:     	stp	q1, q2, [x11, #0x10]
1023a50dc:     	str	q0, [x11]
1023a50e0:     	add	x8, x8, #0x30
1023a50e4:     	subs	x9, x9, #0x1
1023a50e8:     	b.ne	0x1023a50bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x73c>
1023a50ec:     	b	0x1023a50f8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x778>
1023a50f0:     	mov	w8, #0x8                ; =8
1023a50f4:     	str	x8, [sp, #0xa8]
1023a50f8:     	mov	x24, #-0x5555555555555556 ; =-6148914691236517206
1023a50fc:     	movk	x24, #0xaaa, lsl #48
1023a5100:     	ldr	x9, [x20, #0x4e8]
1023a5104:     	add	x8, x9, x9, lsl #1
1023a5108:     	lsl	x19, x8, #2
1023a510c:     	str	x9, [sp, #0x88]
1023a5110:     	cmp	x9, x24
1023a5114:     	b.ls	0x1023a512c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7ac>
1023a5118:     	mov	x24, #0x0               ; =0
1023a511c:     	mov	x0, x24
1023a5120:     	mov	x1, x19
1023a5124:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a5128:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a512c:     	str	x19, [sp, #0x78]
1023a5130:     	cbz	x19, 0x1023a5178 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x7f8>
1023a5134:     	ldr	x8, [x20, #0x4e0]
1023a5138:     	str	x8, [sp, #0x70]
1023a513c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a5140:     	mov	w24, #0x4               ; =4
1023a5144:     	mov	x0, x19
1023a5148:     	mov	w1, #0x4                ; =4
1023a514c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a5150:     	str	x0, [sp, #0x80]
1023a5154:     	cbz	x0, 0x1023a511c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x79c>
1023a5158:     	ldr	x8, [sp, #0x88]
1023a515c:     	mov	x24, #-0x5555555555555556 ; =-6148914691236517206
1023a5160:     	movk	x24, #0xaaa, lsl #48
1023a5164:     	cbz	x8, 0x1023a5180 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x800>
1023a5168:     	ldp	x2, x0, [sp, #0x78]
1023a516c:     	ldr	x1, [sp, #0x70]
1023a5170:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a5174:     	b	0x1023a5180 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x800>
1023a5178:     	mov	w8, #0x4                ; =4
1023a517c:     	str	x8, [sp, #0x80]
1023a5180:     	ldr	x9, [x20, #0x4f8]
1023a5184:     	add	x8, x9, x9, lsl #1
1023a5188:     	lsl	x19, x8, #2
1023a518c:     	cmp	x9, x24
1023a5190:     	b.ls	0x1023a51a8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x828>
1023a5194:     	mov	x24, #0x0               ; =0
1023a5198:     	mov	x0, x24
1023a519c:     	mov	x1, x19
1023a51a0:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a51a4:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a51a8:     	str	x9, [sp, #0x70]
1023a51ac:     	str	x19, [sp, #0x58]
1023a51b0:     	cbz	x19, 0x1023a51f0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x870>
1023a51b4:     	ldr	x8, [x20, #0x4f0]
1023a51b8:     	str	x8, [sp, #0x68]
1023a51bc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a51c0:     	mov	w24, #0x4               ; =4
1023a51c4:     	mov	x0, x19
1023a51c8:     	mov	w1, #0x4                ; =4
1023a51cc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a51d0:     	str	x0, [sp, #0x60]
1023a51d4:     	cbz	x0, 0x1023a5198 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x818>
1023a51d8:     	ldr	x8, [sp, #0x70]
1023a51dc:     	cbz	x8, 0x1023a51f8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x878>
1023a51e0:     	ldp	x0, x1, [sp, #0x60]
1023a51e4:     	ldr	x2, [sp, #0x58]
1023a51e8:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a51ec:     	b	0x1023a51f8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x878>
1023a51f0:     	mov	w8, #0x4                ; =4
1023a51f4:     	str	x8, [sp, #0x60]
1023a51f8:     	add	x0, x20, #0x500
1023a51fc:     	bl	0x10275aabc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023a5200:     	str	x0, [sp, #0x48]
1023a5204:     	str	x1, [sp, #0x68]
1023a5208:     	mov	x9, #0x0                ; =0
1023a520c:     	ldr	x8, [x20, #0x518]
1023a5210:     	lsl	x19, x8, #2
1023a5214:     	str	x8, [sp, #0x50]
1023a5218:     	lsr	x8, x8, #62
1023a521c:     	cbnz	x8, 0x1023a5270 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8f0>
1023a5220:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
1023a5224:     	cmp	x19, x8
1023a5228:     	b.hi	0x1023a5270 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8f0>
1023a522c:     	str	x19, [sp, #0x30]
1023a5230:     	cbz	x19, 0x1023a5280 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x900>
1023a5234:     	ldr	x24, [x20, #0x510]
1023a5238:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a523c:     	mov	x0, x19
1023a5240:     	mov	w1, #0x2                ; =2
1023a5244:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a5248:     	mov	w9, #0x2                ; =2
1023a524c:     	str	x0, [sp, #0x38]
1023a5250:     	cbz	x0, 0x1023a5270 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x8f0>
1023a5254:     	ldr	x8, [sp, #0x50]
1023a5258:     	cbz	x8, 0x1023a5288 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x908>
1023a525c:     	ldr	x0, [sp, #0x38]
1023a5260:     	mov	x1, x24
1023a5264:     	mov	x2, x19
1023a5268:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a526c:     	b	0x1023a5288 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x908>
1023a5270:     	mov	x0, x9
1023a5274:     	mov	x1, x19
1023a5278:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a527c:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a5280:     	mov	w8, #0x2                ; =2
1023a5284:     	str	x8, [sp, #0x38]
1023a5288:     	ldr	x19, [x20, #0x528]
1023a528c:     	add	x8, x19, x19, lsl #1
1023a5290:     	lsl	x9, x8, #2
1023a5294:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1023a5298:     	movk	x8, #0xaaa, lsl #48
1023a529c:     	cmp	x19, x8
1023a52a0:     	str	x9, [sp, #0x40]
1023a52a4:     	b.ls	0x1023a52bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x93c>
1023a52a8:     	mov	x24, #0x0               ; =0
1023a52ac:     	mov	x0, x24
1023a52b0:     	ldr	x1, [sp, #0x40]
1023a52b4:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a52b8:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a52bc:     	str	x19, [sp, #0x20]
1023a52c0:     	cbz	x9, 0x1023a5300 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x980>
1023a52c4:     	ldr	x8, [x20, #0x520]
1023a52c8:     	str	x8, [sp, #0x18]
1023a52cc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a52d0:     	mov	w24, #0x4               ; =4
1023a52d4:     	ldr	x0, [sp, #0x40]
1023a52d8:     	mov	w1, #0x4                ; =4
1023a52dc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a52e0:     	str	x0, [sp, #0x28]
1023a52e4:     	cbz	x0, 0x1023a52ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x92c>
1023a52e8:     	cbz	x19, 0x1023a5308 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x988>
1023a52ec:     	ldr	x0, [sp, #0x28]
1023a52f0:     	ldr	x1, [sp, #0x18]
1023a52f4:     	ldr	x2, [sp, #0x40]
1023a52f8:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a52fc:     	b	0x1023a5308 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x988>
1023a5300:     	mov	w8, #0x4                ; =4
1023a5304:     	str	x8, [sp, #0x28]
1023a5308:     	mov	x9, #0x0                ; =0
1023a530c:     	ldr	x19, [x20, #0x538]
1023a5310:     	lsl	x24, x19, #2
1023a5314:     	lsr	x8, x19, #62
1023a5318:     	cbnz	x8, 0x1023a5374 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9f4>
1023a531c:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
1023a5320:     	cmp	x24, x8
1023a5324:     	b.hi	0x1023a5374 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9f4>
1023a5328:     	ldrh	w8, [x20, #0x5ac]
1023a532c:     	ldr	w9, [x20, #0x5a8]
1023a5330:     	cbz	x24, 0x1023a5384 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa04>
1023a5334:     	stp	x9, x8, [sp, #0x10]
1023a5338:     	ldr	x8, [x20, #0x530]
1023a533c:     	str	x8, [sp, #0x8]
1023a5340:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023a5344:     	mov	x0, x24
1023a5348:     	mov	w1, #0x2                ; =2
1023a534c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023a5350:     	mov	w9, #0x2                ; =2
1023a5354:     	cbz	x0, 0x1023a5374 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x9f4>
1023a5358:     	ldr	x23, [sp, #0xd0]
1023a535c:     	cbz	x19, 0x1023a53bc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa3c>
1023a5360:     	mov	x22, x0
1023a5364:     	ldr	x1, [sp, #0x8]
1023a5368:     	mov	x2, x24
1023a536c:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a5370:     	b	0x1023a53c0 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa40>
1023a5374:     	mov	x0, x9
1023a5378:     	mov	x1, x24
1023a537c:     	bl	0x103a05af0 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023a5380:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a5384:     	mov	w22, #0x2               ; =2
1023a5388:     	ldr	x23, [sp, #0xd0]
1023a538c:     	b	0x1023a53c4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa44>
1023a5390:     	adrp	x0, 0x108039000 <_anon.129022d05b1e456d72785029f108c8c0.267+0x218>
1023a5394:     	add	x0, x0, #0x258
1023a5398:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1023a539c:     	adrp	x0, 0x108039000 <_anon.129022d05b1e456d72785029f108c8c0.267+0x218>
1023a53a0:     	add	x0, x0, #0x258
1023a53a4:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1023a53a8:     	b	0x1023a53b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa38>
1023a53ac:     	adrp	x0, 0x108039000 <_anon.129022d05b1e456d72785029f108c8c0.267+0x218>
1023a53b0:     	add	x0, x0, #0x258
1023a53b4:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1023a53b8:     	brk	#0x1
1023a53bc:     	mov	x22, x0
1023a53c0:     	ldp	x9, x8, [sp, #0x10]
1023a53c4:     	ldr	q0, [sp, #0x900]
1023a53c8:     	ldr	q1, [sp, #0x910]
1023a53cc:     	orr	x21, x9, x8, lsl #32
1023a53d0:     	add	x8, sp, #0x5f8
1023a53d4:     	add	x8, x8, #0x208
1023a53d8:     	stp	q0, q1, [x8, #0x60]
1023a53dc:     	ldr	q0, [sp, #0x920]
1023a53e0:     	ldr	q1, [sp, #0x930]
1023a53e4:     	stp	q0, q1, [x8, #0x80]
1023a53e8:     	ldr	q0, [sp, #0x8c0]
1023a53ec:     	ldr	q1, [sp, #0x8d0]
1023a53f0:     	stp	q0, q1, [x8, #0x20]
1023a53f4:     	ldr	q0, [sp, #0x8e0]
1023a53f8:     	ldr	q1, [sp, #0x8f0]
1023a53fc:     	stp	q0, q1, [x8, #0x40]
1023a5400:     	ldr	q0, [sp, #0x8a0]
1023a5404:     	ldr	q1, [sp, #0x8b0]
1023a5408:     	stp	q0, q1, [x8]
1023a540c:     	add	x0, sp, #0x5f8
1023a5410:     	add	x1, x20, #0x1c8
1023a5414:     	mov	w2, #0x208              ; =520
1023a5418:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a541c:     	add	x8, sp, #0x210
1023a5420:     	ldr	q0, [x20, #0x570]
1023a5424:     	add	x8, x8, #0x378
1023a5428:     	ldr	q1, [x20, #0x580]
1023a542c:     	ldr	q2, [x20, #0x590]
1023a5430:     	stp	q1, q2, [x8, #0x40]
1023a5434:     	ldr	q1, [x20, #0x540]
1023a5438:     	ldr	q2, [x20, #0x550]
1023a543c:     	stp	q1, q2, [x8]
1023a5440:     	ldr	q1, [x20, #0x560]
1023a5444:     	stp	q1, q0, [x8, #0x20]
1023a5448:     	ldr	x8, [x20, #0x5a0]
1023a544c:     	str	x8, [sp, #0x5e8]
1023a5450:     	add	x0, sp, #0x210
1023a5454:     	add	x1, sp, #0x5f8
1023a5458:     	mov	w2, #0x2a8              ; =680
1023a545c:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1023a5460:     	ldp	x9, x8, [sp, #0xb0]
1023a5464:     	str	x9, [sp, #0x4b8]
1023a5468:     	str	x8, [sp, #0x4c0]
1023a546c:     	str	x28, [sp, #0x4c8]
1023a5470:     	str	x27, [sp, #0x4d0]
1023a5474:     	ldr	x8, [sp, #0xd8]
1023a5478:     	str	x8, [sp, #0x4d8]
1023a547c:     	ldr	x8, [sp, #0xe8]
1023a5480:     	str	x8, [sp, #0x4e0]
1023a5484:     	ldp	x9, x8, [sp, #0xc0]
1023a5488:     	str	x9, [sp, #0x4e8]
1023a548c:     	str	x8, [sp, #0x4f0]
1023a5490:     	ldp	x8, x9, [sp, #0x98]
1023a5494:     	str	x9, [sp, #0x4f8]
1023a5498:     	str	x25, [sp, #0x500]
1023a549c:     	str	x8, [sp, #0x508]
1023a54a0:     	str	x26, [sp, #0x510]
1023a54a4:     	ldr	x8, [sp, #0xa8]
1023a54a8:     	str	x8, [sp, #0x518]
1023a54ac:     	ldr	x8, [sp, #0x90]
1023a54b0:     	str	x8, [sp, #0x520]
1023a54b4:     	ldp	x9, x8, [sp, #0x80]
1023a54b8:     	str	x9, [sp, #0x528]
1023a54bc:     	str	x8, [sp, #0x530]
1023a54c0:     	ldr	x8, [sp, #0x60]
1023a54c4:     	str	x8, [sp, #0x538]
1023a54c8:     	ldr	x8, [sp, #0x70]
1023a54cc:     	str	x8, [sp, #0x540]
1023a54d0:     	ldr	x8, [sp, #0x48]
1023a54d4:     	str	x8, [sp, #0x548]
1023a54d8:     	ldr	x8, [sp, #0x68]
1023a54dc:     	str	x8, [sp, #0x550]
1023a54e0:     	ldr	x8, [sp, #0x38]
1023a54e4:     	str	x8, [sp, #0x558]
1023a54e8:     	ldr	x8, [sp, #0x50]
1023a54ec:     	str	x8, [sp, #0x560]
1023a54f0:     	ldp	x8, x9, [sp, #0x20]
1023a54f4:     	str	x9, [sp, #0x568]
1023a54f8:     	str	x8, [sp, #0x570]
1023a54fc:     	str	x22, [sp, #0x578]
1023a5500:     	str	x19, [sp, #0x580]
1023a5504:     	lsr	x8, x21, #32
1023a5508:     	strh	w8, [sp, #0x5f4]
1023a550c:     	str	w21, [sp, #0x5f0]
1023a5510:     	ldr	w19, [sp, #0xe4]
1023a5514:     	b	0x1023a4adc <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x15c>
1023a5518:     	mov	x19, x0
1023a551c:     	ldr	x20, [sp, #0x90]
1023a5520:     	b	0x1023a565c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcdc>
1023a5524:     	mov	x19, x0
1023a5528:     	mov	x0, x25
1023a552c:     	mov	x1, x26
1023a5530:     	bl	0x10233d264 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECs1qJAwyMG1lC_11mech_engine>
1023a5534:     	b	0x1023a553c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbbc>
1023a5538:     	mov	x19, x0
1023a553c:     	mov	x0, x24
1023a5540:     	mov	x1, x23
1023a5544:     	bl	0x10233dac0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
1023a5548:     	b	0x1023a5578 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbf8>
1023a554c:     	mov	x19, x0
1023a5550:     	ldr	x20, [sp, #0xe8]
1023a5554:     	ldr	x23, [sp, #0xd8]
1023a5558:     	b	0x1023a5704 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd84>
1023a555c:     	mov	x19, x0
1023a5560:     	b	0x1023a5710 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd90>
1023a5564:     	mov	x19, x0
1023a5568:     	b	0x1023a571c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd9c>
1023a556c:     	mov	x19, x0
1023a5570:     	b	0x1023a5728 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xda8>
1023a5574:     	mov	x19, x0
1023a5578:     	mov	x0, x22
1023a557c:     	mov	x1, x21
1023a5580:     	bl	0x10233dac0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
1023a5584:     	b	0x1023a5590 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc10>
1023a5588:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1023a558c:     	mov	x19, x0
1023a5590:     	add	x0, sp, #0x210
1023a5594:     	bl	0x1023411b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorECs1qJAwyMG1lC_11mech_engine>
1023a5598:     	b	0x1023a57ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1023a559c:     	mov	x19, x0
1023a55a0:     	cbz	x28, 0x1023a5758 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdd8>
1023a55a4:     	mov	x0, x23
1023a55a8:     	mov	x1, x24
1023a55ac:     	mov	w2, #0x1                ; =1
1023a55b0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a55b4:     	b	0x1023a5758 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdd8>
1023a55b8:     	mov	x19, x0
1023a55bc:     	b	0x1023a57ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1023a55c0:     	mov	x19, x0
1023a55c4:     	b	0x1023a5780 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe00>
1023a55c8:     	mov	x19, x0
1023a55cc:     	b	0x1023a5798 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe18>
1023a55d0:     	mov	x19, x0
1023a55d4:     	add	x0, sp, #0x5f8
1023a55d8:     	bl	0x10257982c <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1023a55dc:     	b	0x1023a55e4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc64>
1023a55e0:     	mov	x19, x0
1023a55e4:     	add	x0, sp, #0x8a0
1023a55e8:     	bl	0x10257a0fc <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model16RegionAccessPlanENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1023a55ec:     	b	0x1023a57b4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe34>
1023a55f0:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1023a55f4:     	mov	x19, x0
1023a55f8:     	ldr	x20, [sp, #0x90]
1023a55fc:     	ldr	x8, [sp, #0x20]
1023a5600:     	cbz	x8, 0x1023a5620 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xca0>
1023a5604:     	ldr	x0, [sp, #0x28]
1023a5608:     	ldr	x1, [sp, #0x40]
1023a560c:     	mov	w2, #0x4                ; =4
1023a5610:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a5614:     	b	0x1023a5620 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xca0>
1023a5618:     	mov	x19, x0
1023a561c:     	ldr	x20, [sp, #0x90]
1023a5620:     	ldr	x8, [sp, #0x50]
1023a5624:     	cbz	x8, 0x1023a5640 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcc0>
1023a5628:     	ldp	x1, x0, [sp, #0x30]
1023a562c:     	mov	w2, #0x2                ; =2
1023a5630:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a5634:     	b	0x1023a5640 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcc0>
1023a5638:     	mov	x19, x0
1023a563c:     	ldr	x20, [sp, #0x90]
1023a5640:     	ldr	x8, [sp, #0x68]
1023a5644:     	cbz	x8, 0x1023a565c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcdc>
1023a5648:     	add	x8, x8, x8, lsl #1
1023a564c:     	lsl	x1, x8, #5
1023a5650:     	ldr	x0, [sp, #0x48]
1023a5654:     	mov	w2, #0x8                ; =8
1023a5658:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a565c:     	ldr	x8, [sp, #0x70]
1023a5660:     	cbz	x8, 0x1023a567c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcfc>
1023a5664:     	ldp	x1, x0, [sp, #0x58]
1023a5668:     	mov	w2, #0x4                ; =4
1023a566c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a5670:     	b	0x1023a567c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xcfc>
1023a5674:     	mov	x19, x0
1023a5678:     	ldr	x20, [sp, #0x90]
1023a567c:     	ldr	x8, [sp, #0x88]
1023a5680:     	cbz	x8, 0x1023a569c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd1c>
1023a5684:     	ldp	x1, x0, [sp, #0x78]
1023a5688:     	mov	w2, #0x4                ; =4
1023a568c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a5690:     	b	0x1023a569c <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd1c>
1023a5694:     	mov	x19, x0
1023a5698:     	ldr	x20, [sp, #0x90]
1023a569c:     	cbz	x20, 0x1023a56b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd38>
1023a56a0:     	ldr	x0, [sp, #0xa8]
1023a56a4:     	mov	x1, x23
1023a56a8:     	mov	w2, #0x8                ; =8
1023a56ac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a56b0:     	b	0x1023a56b8 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd38>
1023a56b4:     	mov	x19, x0
1023a56b8:     	cbz	x26, 0x1023a56d4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd54>
1023a56bc:     	ldr	x0, [sp, #0x98]
1023a56c0:     	mov	x1, x22
1023a56c4:     	mov	w2, #0x8                ; =8
1023a56c8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a56cc:     	b	0x1023a56d4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd54>
1023a56d0:     	mov	x19, x0
1023a56d4:     	ldp	x26, x24, [sp, #0xb0]
1023a56d8:     	cbz	x25, 0x1023a56f4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd74>
1023a56dc:     	ldr	x0, [sp, #0xa0]
1023a56e0:     	mov	x1, x21
1023a56e4:     	mov	w2, #0x8                ; =8
1023a56e8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a56ec:     	b	0x1023a56f4 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xd74>
1023a56f0:     	mov	x19, x0
1023a56f4:     	ldr	x20, [sp, #0xe8]
1023a56f8:     	ldr	x23, [sp, #0xd8]
1023a56fc:     	ldp	x0, x1, [sp, #0xc0]
1023a5700:     	bl	0x10233d9b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
1023a5704:     	mov	x0, x23
1023a5708:     	mov	x1, x20
1023a570c:     	bl	0x10233d9b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
1023a5710:     	mov	x0, x28
1023a5714:     	mov	x1, x27
1023a5718:     	bl	0x10233d8b4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
1023a571c:     	mov	x0, x26
1023a5720:     	mov	x1, x24
1023a5724:     	bl	0x10233d8b4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
1023a5728:     	add	x0, sp, #0x8a0
1023a572c:     	bl	0x1023411f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization9BoundCallECs1qJAwyMG1lC_11mech_engine>
1023a5730:     	b	0x1023a57ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1023a5734:     	mov	x19, x0
1023a5738:     	cbz	x25, 0x1023a5774 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdf4>
1023a573c:     	ldr	x0, [sp, #0xc8]
1023a5740:     	mov	x1, x27
1023a5744:     	mov	w2, #0x4                ; =4
1023a5748:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a574c:     	b	0x1023a5774 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xdf4>
1023a5750:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1023a5754:     	mov	x19, x0
1023a5758:     	cbz	x21, 0x1023a57ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1023a575c:     	mov	x0, x22
1023a5760:     	mov	x1, x21
1023a5764:     	mov	w2, #0x1                ; =1
1023a5768:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a576c:     	b	0x1023a57ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1023a5770:     	mov	x19, x0
1023a5774:     	mov	x0, x24
1023a5778:     	ldr	x1, [sp, #0xe8]
1023a577c:     	bl	0x10233da4c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
1023a5780:     	cbz	x22, 0x1023a5798 <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe18>
1023a5784:     	add	x8, x22, x22, lsl #1
1023a5788:     	lsl	x1, x8, #5
1023a578c:     	ldr	x0, [sp, #0xd8]
1023a5790:     	mov	w2, #0x8                ; =8
1023a5794:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023a5798:     	ldr	x8, [sp, #0x210]
1023a579c:     	cmp	x8, #0x2
1023a57a0:     	b.eq	0x1023a57ac <__RNvXs5_NtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turnNtB5_14TurnMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xe2c>
1023a57a4:     	add	x0, sp, #0x210
1023a57a8:     	bl	0x10233ffa0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1023a57ac:     	add	x0, sp, #0xf0
1023a57b0:     	bl	0x10233f610 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15TurnMemoryFactsEBM_>
1023a57b4:     	mov	x0, x19
1023a57b8:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
1023a57bc:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
