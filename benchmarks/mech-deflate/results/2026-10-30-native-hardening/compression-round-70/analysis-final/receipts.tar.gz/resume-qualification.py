"""No performance rerun: resume only the previously unexecuted qualification."""
from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for name in ['units.py','qualify-all.py','type-architecture.py','instruction-windows.py','host-assembly.py']:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name)],check=True);print('DONE',name,flush=True)
(r/'DIAGNOSTIC_RUN_ALLOWED').write_text('Primary and control timing, compilation and functional qualification have finished.\n')
subprocess.run(['python3',str(r/'diagnostic-counts.py')],check=True)
