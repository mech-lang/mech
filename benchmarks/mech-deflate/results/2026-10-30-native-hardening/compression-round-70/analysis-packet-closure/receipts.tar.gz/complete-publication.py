"""Finish only packet/replay after the first publisher's existing-directory error."""
from pathlib import Path
import json,shutil,subprocess
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-70'
subprocess.run(['python3',str(r/'finalize-analysis.py')],check=True)
files=[r/n for n in ['validation.json','analysis','report.md','prior-failures.json','render-report.py','complete-publication.py','publish-packet.py','findings-packet']]
subprocess.run(['python3',str(r/'archive.py'),'analysis-packet-closure',*map(str,files)],check=True)
for name in ['analyze.py','allocation_analysis.py','binary_identity.py','validation.py','render-report.py','reconstruct.py','profile_analysis.py','finalize-analysis.py','allocation-comparison.json','profile-numbers.json','validation.json','binary-audit.json','README.md','mechanism_analysis.py','host_analysis.py','allocation-mechanism.json','host-assembly-comparison.json','instruction_analysis.py','instruction-window-comparison.json','diagnostic_analysis.py']:shutil.copy2(r/name,p/name)
for name in ['scorecard.json','scorecard.csv']:shutil.copy2(r/'analysis'/name,p/name)
shutil.copy2(r/'report.md',p/'REPORT.md');(p/'diagnostic-counts').mkdir(exist_ok=True);shutil.copy2(r/'diagnostic-counts/summary.json',p/'diagnostic-counts/summary.json')
cmd=['python3',str(p/'reconstruct.py'),str(r/'replay-final')];q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
(r/'reconstruction.stdout').write_text(q.stdout);(r/'reconstruction.stderr').write_text(q.stderr);print(q.stdout[-2500:]+q.stderr[-5000:],flush=True);q.check_returncode();receipt=json.loads(q.stdout);receipt.update(command=cmd,exit=q.returncode);(p/'reconstruction.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=w,check=True);subprocess.run(['git','add',str(p)],cwd=w,check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Retain measured owned-plan transfer and bounded execution census'],cwd=w,check=True)
print('R70_CHECKPOINT',subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),flush=True)
