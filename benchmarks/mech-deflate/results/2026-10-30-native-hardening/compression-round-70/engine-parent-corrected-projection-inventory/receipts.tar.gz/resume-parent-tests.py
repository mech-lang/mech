"""Archive a successful parent build under a fresh label, then run unexecuted tests."""
from pathlib import Path
import json,re,subprocess,time,hashlib
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'engine-parent';base=json.loads((p/'build.json').read_text());assert base['exit']==0
for relative,pin in base['production_source_sha256'].items():assert hashlib.sha256((p/Path(relative).name).read_bytes()).hexdigest()==pin
files=[p/'build.json',p/'build.stdout',p/'build.stderr',p/'turn.rs',p/'turn_tests.rs',r/'engine-focused.py',r/'resume-parent-tests.py']
subprocess.run(['python3',str(r/'archive.py'),'engine-parent-corrected-build',*map(str,files)],check=True)
selections=[('projection','native_projection_meter_tests',12),('policy-order','native_projection_meter_keeps_policy_order_after_enclosing_funding',1),('overflow-retry','native_projection_meter_preview_and_charge_keep_compute_node_overflow_atomic',1),('shape','frame_shape::tests::',6),('borrowed-turn','memory_planner::turn::tests::',7),('full-planner','memory_planner::',22)]
for label,selection,count in selections:
 for inventory in [True,False]:
  name=label+'-inventory' if inventory else label;cmd=[str(p/'engine-tests'),selection,*(['--list'] if inventory else ['--nocapture','--test-threads=1'])];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
  row={**base,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'expected_tests':count,'retry_note':'Original corrected Rust build succeeded; only immutable receipt-label reuse failed. Existing executable is used, no compilation or test result is overwritten.'}
  if inventory:row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout);assert m,q.stdout;row.update(passed_tests=int(m[1]),failed_tests=int(m[2]),executed_tests=int(m[1])+int(m[2]));observed=row['executed_tests']
  (p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');subprocess.run(['python3',str(r/'archive.py'),'engine-parent-corrected-'+name,*map(str,[p/(name+'.'+x) for x in ['json','stdout','stderr']]),str(r/'resume-parent-tests.py')],check=True)
  print(name,q.returncode,observed,flush=True)
  if q.returncode:print(q.stdout[-3500:]+q.stderr[-5000:],flush=True)
  q.check_returncode();assert observed==count,row
