from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'units-after';unit=str(p/'gpu-unit-tests')
for label,args,count in [('preparation',['cleanup_effects::tests::'],2),('runtime',['native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map'],json.loads((r/'configuration.json').read_text())['gpu_runtime_expected']),('work-values',['native_artifact::work::','native_artifact::memory::','native_artifact::values::'],32)]:
 for suffix,flags in [('inventory',['--list']),('run',['--nocapture','--test-threads=1'])]:
  name=label if suffix=='run' else label+'-inventory';cmd=[unit,*args,*flags];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
  row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'production_dependencies':str(r/'final-libraries.json'),'expected_tests':count}
  if suffix=='inventory':row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;observed=row['executed_tests']
  (p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  subprocess.run(['python3',str(r/'archive.py'),'qualification-'+name,str(p/(name+'.json')),str(p/(name+'.stdout')),str(p/(name+'.stderr')),str(r/'qualify-all.py')],cwd=w,check=True)
  print(name,q.returncode,observed,flush=True)
  if q.returncode:print(q.stdout[-4000:]+q.stderr[-6000:],flush=True)
  q.check_returncode();assert observed==count,(name,row)
for name in ['qualify.py','linked-acceptance.py','controls.py','workflow-checks.py','ci.py','architecture.py']:
 if name=='controls.py':
  for label in ['before','after']:subprocess.run(['python3',str(r/'control-build.py'),label],check=True)
 print('START',name,flush=True);subprocess.run(['python3',str(r/name)],check=True)
 if name=='qualify.py':(r/'qualification/tests').unlink()
 if name=='linked-acceptance.py':(r/'linked-acceptance/worker').unlink()
 if name=='controls.py':(r/'primary/frame-after').unlink()
