
/private/tmp/mech-admitted-helpers-round78-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101580d6c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit>:
101580d6c:     	sub	sp, sp, #0xd0
101580d70:     	stp	x24, x23, [sp, #0x90]
101580d74:     	stp	x22, x21, [sp, #0xa0]
101580d78:     	stp	x20, x19, [sp, #0xb0]
101580d7c:     	stp	x29, x30, [sp, #0xc0]
101580d80:     	add	x29, sp, #0xc0
101580d84:     	cbz	x0, 0x101580e08 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x9c>
101580d88:     	mov	x19, x0
101580d8c:     	ldr	w8, [x0, #0x440]
101580d90:     	cmp	w8, #0x6
101580d94:     	b.ne	0x101580e10 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0xa4>
101580d98:     	add	x8, sp, #0x40
101580d9c:     	mov	x0, x19
101580da0:     	mov	x21, x1
101580da4:     	bl	0x1015c9328 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
101580da8:     	add	x8, x19, #0x440
101580dac:     	ldr	w20, [sp, #0x40]
101580db0:     	cmp	w20, #0x6
101580db4:     	b.ne	0x101580e18 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0xac>
101580db8:     	ldr	x9, [x19, #0x498]
101580dbc:     	ldr	x10, [x9, #0x590]
101580dc0:     	cmp	x21, x10
101580dc4:     	b.hs	0x101580e00 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x94>
101580dc8:     	ldr	x10, [x9, #0x588]
101580dcc:     	add	x10, x10, x21, lsl #4
101580dd0:     	ldr	x11, [x10]
101580dd4:     	cmp	x11, #0x1
101580dd8:     	b.ne	0x101580e00 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x94>
101580ddc:     	ldr	x0, [x10, #0x8]
101580de0:     	ldr	x1, [x9, #0x580]
101580de4:     	cmp	x0, x1
101580de8:     	b.hs	0x101580f18 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x1ac>
101580dec:     	ldr	x9, [x9, #0x578]
101580df0:     	mov	w10, #0x38              ; =56
101580df4:     	madd	x9, x0, x10, x9
101580df8:     	ldr	x10, [x9]
101580dfc:     	cbz	x10, 0x101580e98 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x12c>
101580e00:     	mov	x0, #0x0                ; =0
101580e04:     	b	0x101580e80 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
101580e08:     	mov	w0, #0x3                ; =3
101580e0c:     	b	0x101580e80 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
101580e10:     	mov	w0, #0x2                ; =2
101580e14:     	b	0x101580e80 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
101580e18:     	ldr	w21, [sp, #0x44]
101580e1c:     	ldp	x22, x23, [sp, #0x48]
101580e20:     	ldur	q0, [sp, #0x58]
101580e24:     	ldur	q1, [sp, #0x68]
101580e28:     	stp	q0, q1, [sp]
101580e2c:     	ldur	q0, [sp, #0x78]
101580e30:     	str	q0, [sp, #0x20]
101580e34:     	ldr	x9, [sp, #0x88]
101580e38:     	str	x9, [sp, #0x30]
101580e3c:     	ldr	w8, [x8]
101580e40:     	cmp	w8, #0x6
101580e44:     	b.eq	0x101580e50 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0xe4>
101580e48:     	add	x0, x19, #0x440
101580e4c:     	bl	0x101573b8c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101580e50:     	str	w20, [x19, #0x440]
101580e54:     	str	w21, [x19, #0x444]
101580e58:     	str	x22, [x19, #0x448]
101580e5c:     	str	x23, [x19, #0x450]
101580e60:     	add	x8, x19, #0x458
101580e64:     	ldr	x9, [sp, #0x30]
101580e68:     	str	x9, [x19, #0x488]
101580e6c:     	ldp	q0, q1, [sp]
101580e70:     	stp	q0, q1, [x8]
101580e74:     	ldr	q0, [sp, #0x20]
101580e78:     	mov	w0, #0x2                ; =2
101580e7c:     	str	q0, [x8, #0x20]
101580e80:     	ldp	x29, x30, [sp, #0xc0]
101580e84:     	ldp	x20, x19, [sp, #0xb0]
101580e88:     	ldp	x22, x21, [sp, #0xa0]
101580e8c:     	ldp	x24, x23, [sp, #0x90]
101580e90:     	add	sp, sp, #0xd0
101580e94:     	ret
101580e98:     	ldr	x10, [x9, #0x18]
101580e9c:     	cbz	x10, 0x101580f24 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x1b8>
101580ea0:     	ldr	x10, [x19, #0x490]
101580ea4:     	ldr	w11, [x10, #0x340]
101580ea8:     	tbz	w11, #0x0, 0x101580ec4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x158>
101580eac:     	ldr	x9, [x9, #0x10]
101580eb0:     	ldr	w9, [x9]
101580eb4:     	ldr	w10, [x10, #0x344]
101580eb8:     	cmp	w10, w9
101580ebc:     	cset	w9, eq
101580ec0:     	b	0x101580ec8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x15c>
101580ec4:     	mov	x9, #0x0                ; =0
101580ec8:     	ldr	x10, [x19, #0x4c8]
101580ecc:     	cbz	x10, 0x101580edc <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x170>
101580ed0:     	mov	x0, #0x0                ; =0
101580ed4:     	str	x9, [x10]
101580ed8:     	b	0x101580e80 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
101580edc:     	ldr	w8, [x8]
101580ee0:     	cmp	w8, #0x6
101580ee4:     	b.eq	0x101580ef0 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x184>
101580ee8:     	add	x0, x19, #0x440
101580eec:     	bl	0x101573b8c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101580ef0:     	str	wzr, [x19, #0x440]
101580ef4:     	mov	w8, #0xc                ; =12
101580ef8:     	strb	w8, [x19, #0x448]
101580efc:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x3>
101580f00:     	add	x8, x8, #0xa0e
101580f04:     	str	x8, [x19, #0x450]
101580f08:     	mov	w8, #0x24               ; =36
101580f0c:     	str	x8, [x19, #0x458]
101580f10:     	mov	w0, #0x3                ; =3
101580f14:     	b	0x101580e80 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
101580f18:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
101580f1c:     	add	x2, x2, #0xa50
101580f20:     	b	0x101580f34 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x1c8>
101580f24:     	mov	x0, #0x0                ; =0
101580f28:     	mov	x1, #0x0                ; =0
101580f2c:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
101580f30:     	add	x2, x2, #0x150
101580f34:     	bl	0x103a05dd4 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101580f38:     	brk	#0x1
101580f3c:     	bl	0x103a05ef8 <__RNvNtCsgDHHaSskbIF_4core9panicking19panic_cannot_unwind>
101580f40:     	bl	0x103a05ef8 <__RNvNtCsgDHHaSskbIF_4core9panicking19panic_cannot_unwind>
