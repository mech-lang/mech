
/private/tmp/mech-admitted-helpers-round78-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101580f44 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper>:
101580f44:     	sub	sp, sp, #0x90
101580f48:     	stp	x20, x19, [sp, #0x70]
101580f4c:     	stp	x29, x30, [sp, #0x80]
101580f50:     	add	x29, sp, #0x80
101580f54:     	cbz	x0, 0x101581060 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x11c>
101580f58:     	ldr	w8, [x0, #0x440]
101580f5c:     	cmp	w8, #0x6
101580f60:     	b.ne	0x101580fb4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x70>
101580f64:     	add	x19, x0, #0x440
101580f68:     	cbz	x6, 0x101580f78 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x34>
101580f6c:     	ldr	x8, [x0, #0x4c8]
101580f70:     	cmp	x6, x8
101580f74:     	b.eq	0x101580fbc <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x78>
101580f78:     	str	wzr, [sp, #0x8]
101580f7c:     	mov	w8, #0xc                ; =12
101580f80:     	strb	w8, [sp, #0x10]
101580f84:     	adrp	x8, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x3>
101580f88:     	add	x8, x8, #0xa32
101580f8c:     	mov	w9, #0x1e               ; =30
101580f90:     	stp	x8, x9, [sp, #0x18]
101580f94:     	ldur	q0, [sp, #0x28]
101580f98:     	ldur	q1, [sp, #0x38]
101580f9c:     	stp	q0, q1, [x19, #0x20]
101580fa0:     	ldur	q0, [sp, #0x48]
101580fa4:     	str	q0, [x19, #0x40]
101580fa8:     	ldur	q0, [sp, #0x18]
101580fac:     	ldur	q1, [sp, #0x8]
101580fb0:     	stp	q1, q0, [x19]
101580fb4:     	mov	w0, #0x2                ; =2
101580fb8:     	b	0x101581064 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x120>
101580fbc:     	stp	x3, x4, [x29, #-0x28]
101580fc0:     	stur	x5, [x29, #-0x18]
101580fc4:     	add	x8, sp, #0x8
101580fc8:     	sub	x3, x29, #0x28
101580fcc:     	mov	x20, x0
101580fd0:     	bl	0x1015ca160 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>
101580fd4:     	ldr	w8, [sp, #0x8]
101580fd8:     	cmp	w8, #0x6
101580fdc:     	b.ne	0x101581004 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0xc0>
101580fe0:     	ldr	x8, [sp, #0x10]
101580fe4:     	cmp	x8, #0x1
101580fe8:     	b.ne	0x10158101c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0xd8>
101580fec:     	ldr	x9, [x20, #0x4c8]
101580ff0:     	cbz	x9, 0x101581024 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0xe0>
101580ff4:     	mov	x0, #0x0                ; =0
101580ff8:     	ldr	x8, [sp, #0x18]
101580ffc:     	str	x8, [x9]
101581000:     	b	0x101581064 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x120>
101581004:     	ldr	w8, [x19]
101581008:     	cmp	w8, #0x6
10158100c:     	b.eq	0x101580f94 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x50>
101581010:     	mov	x0, x19
101581014:     	bl	0x101573b8c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101581018:     	b	0x101580f94 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x50>
10158101c:     	mov	x0, #0x0                ; =0
101581020:     	b	0x101581064 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x120>
101581024:     	mov	x8, x20
101581028:     	ldr	w9, [x19]
10158102c:     	cmp	w9, #0x6
101581030:     	b.eq	0x101581040 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0xfc>
101581034:     	add	x0, x20, #0x440
101581038:     	bl	0x101573b8c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10158103c:     	mov	x8, x20
101581040:     	str	wzr, [x8, #0x440]
101581044:     	mov	w9, #0xc                ; =12
101581048:     	strb	w9, [x8, #0x448]
10158104c:     	adrp	x9, 0x107554000 <_anon.28ece4ee950707df19ca4da222de4961.216+0x3>
101581050:     	add	x9, x9, #0xa0e
101581054:     	str	x9, [x8, #0x450]
101581058:     	mov	w9, #0x24               ; =36
10158105c:     	str	x9, [x8, #0x458]
101581060:     	mov	w0, #0x3                ; =3
101581064:     	ldp	x29, x30, [sp, #0x80]
101581068:     	ldp	x20, x19, [sp, #0x70]
10158106c:     	add	sp, sp, #0x90
101581070:     	ret
101581074:     	bl	0x103a05ef8 <__RNvNtCsgDHHaSskbIF_4core9panicking19panic_cannot_unwind>
