"""Reexecute all five maintained type/memory source contracts on current production."""
from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'type-architecture';p.mkdir();rows=[]
for name in ['type-system','semantic-type-authority','type-memory-boundary','memory-planner','memory-runtime']:
 cmd=['python3','scripts/check-'+name+'.py'];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 rows.append({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at});(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,q.returncode,flush=True)
 if q.returncode:print(q.stdout+q.stderr,flush=True)
 q.check_returncode()
subprocess.run(['python3',str(r/'archive.py'),'type-architecture',str(p),str(r/'type-architecture.py')],check=True)
