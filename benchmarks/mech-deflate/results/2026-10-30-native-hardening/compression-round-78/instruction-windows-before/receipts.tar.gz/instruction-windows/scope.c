#include "/private/tmp/mech-admitted-helpers-round78-20261031/counters/usage.c"
static struct bench_usage entry_start;
static uint64_t entry_instructions, entry_cycles, entry_calls;
static unsigned entry_depth;
void bench_scope_reset(void) { entry_instructions=entry_cycles=entry_calls=entry_depth=0; }
int bench_scope_begin(void) { if(entry_depth) return -1; entry_depth=1; return bench_read_usage(&entry_start); }
int bench_scope_end(void) { struct bench_usage after; if(entry_depth!=1) return -2; int code=bench_read_usage(&after); if(code) return code; entry_instructions+=after.instructions-entry_start.instructions; entry_cycles+=after.cycles-entry_start.cycles; entry_calls++; entry_depth=0; return 0; }
void bench_scope_read(uint64_t *instructions,uint64_t *cycles,uint64_t *calls) { *instructions=entry_instructions;*cycles=entry_cycles;*calls=entry_calls; }
