
/private/tmp/mech-admitted-helpers-round78-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015e3ce4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit>:
1015e3ce4:     	sub	sp, sp, #0xd0
1015e3ce8:     	stp	x24, x23, [sp, #0x90]
1015e3cec:     	stp	x22, x21, [sp, #0xa0]
1015e3cf0:     	stp	x20, x19, [sp, #0xb0]
1015e3cf4:     	stp	x29, x30, [sp, #0xc0]
1015e3cf8:     	add	x29, sp, #0xc0
1015e3cfc:     	cbz	x0, 0x1015e3d80 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x9c>
1015e3d00:     	mov	x19, x0
1015e3d04:     	ldr	w8, [x0, #0x440]
1015e3d08:     	cmp	w8, #0x6
1015e3d0c:     	b.ne	0x1015e3d88 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0xa4>
1015e3d10:     	add	x8, sp, #0x40
1015e3d14:     	mov	x0, x19
1015e3d18:     	mov	x21, x1
1015e3d1c:     	bl	0x101625954 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
1015e3d20:     	add	x8, x19, #0x440
1015e3d24:     	ldr	w20, [sp, #0x40]
1015e3d28:     	cmp	w20, #0x6
1015e3d2c:     	b.ne	0x1015e3d90 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0xac>
1015e3d30:     	ldr	x9, [x19, #0x498]
1015e3d34:     	ldr	x10, [x9, #0x590]
1015e3d38:     	cmp	x21, x10
1015e3d3c:     	b.hs	0x1015e3d78 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x94>
1015e3d40:     	ldr	x10, [x9, #0x588]
1015e3d44:     	add	x10, x10, x21, lsl #4
1015e3d48:     	ldr	x11, [x10]
1015e3d4c:     	cmp	x11, #0x1
1015e3d50:     	b.ne	0x1015e3d78 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x94>
1015e3d54:     	ldr	x0, [x10, #0x8]
1015e3d58:     	ldr	x1, [x9, #0x580]
1015e3d5c:     	cmp	x0, x1
1015e3d60:     	b.hs	0x1015e3e90 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x1ac>
1015e3d64:     	ldr	x9, [x9, #0x578]
1015e3d68:     	mov	w10, #0x38              ; =56
1015e3d6c:     	madd	x9, x0, x10, x9
1015e3d70:     	ldr	x10, [x9]
1015e3d74:     	cbz	x10, 0x1015e3e10 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x12c>
1015e3d78:     	mov	x0, #0x0                ; =0
1015e3d7c:     	b	0x1015e3df8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
1015e3d80:     	mov	w0, #0x3                ; =3
1015e3d84:     	b	0x1015e3df8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
1015e3d88:     	mov	w0, #0x2                ; =2
1015e3d8c:     	b	0x1015e3df8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
1015e3d90:     	ldr	w21, [sp, #0x44]
1015e3d94:     	ldp	x22, x23, [sp, #0x48]
1015e3d98:     	ldur	q0, [sp, #0x58]
1015e3d9c:     	ldur	q1, [sp, #0x68]
1015e3da0:     	stp	q0, q1, [sp]
1015e3da4:     	ldur	q0, [sp, #0x78]
1015e3da8:     	str	q0, [sp, #0x20]
1015e3dac:     	ldr	x9, [sp, #0x88]
1015e3db0:     	str	x9, [sp, #0x30]
1015e3db4:     	ldr	w8, [x8]
1015e3db8:     	cmp	w8, #0x6
1015e3dbc:     	b.eq	0x1015e3dc8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0xe4>
1015e3dc0:     	add	x0, x19, #0x440
1015e3dc4:     	bl	0x1015d6af8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015e3dc8:     	str	w20, [x19, #0x440]
1015e3dcc:     	str	w21, [x19, #0x444]
1015e3dd0:     	str	x22, [x19, #0x448]
1015e3dd4:     	str	x23, [x19, #0x450]
1015e3dd8:     	add	x8, x19, #0x458
1015e3ddc:     	ldr	x9, [sp, #0x30]
1015e3de0:     	str	x9, [x19, #0x488]
1015e3de4:     	ldp	q0, q1, [sp]
1015e3de8:     	stp	q0, q1, [x8]
1015e3dec:     	ldr	q0, [sp, #0x20]
1015e3df0:     	mov	w0, #0x2                ; =2
1015e3df4:     	str	q0, [x8, #0x20]
1015e3df8:     	ldp	x29, x30, [sp, #0xc0]
1015e3dfc:     	ldp	x20, x19, [sp, #0xb0]
1015e3e00:     	ldp	x22, x21, [sp, #0xa0]
1015e3e04:     	ldp	x24, x23, [sp, #0x90]
1015e3e08:     	add	sp, sp, #0xd0
1015e3e0c:     	ret
1015e3e10:     	ldr	x10, [x9, #0x18]
1015e3e14:     	cbz	x10, 0x1015e3e9c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x1b8>
1015e3e18:     	ldr	x10, [x19, #0x490]
1015e3e1c:     	ldr	w11, [x10, #0x340]
1015e3e20:     	tbz	w11, #0x0, 0x1015e3e3c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x158>
1015e3e24:     	ldr	x9, [x9, #0x10]
1015e3e28:     	ldr	w9, [x9]
1015e3e2c:     	ldr	w10, [x10, #0x344]
1015e3e30:     	cmp	w10, w9
1015e3e34:     	cset	w9, eq
1015e3e38:     	b	0x1015e3e40 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x15c>
1015e3e3c:     	mov	x9, #0x0                ; =0
1015e3e40:     	ldr	x10, [x19, #0x4c8]
1015e3e44:     	cbz	x10, 0x1015e3e54 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x170>
1015e3e48:     	mov	x0, #0x0                ; =0
1015e3e4c:     	str	x9, [x10]
1015e3e50:     	b	0x1015e3df8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
1015e3e54:     	ldr	w8, [x8]
1015e3e58:     	cmp	w8, #0x6
1015e3e5c:     	b.eq	0x1015e3e68 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x184>
1015e3e60:     	add	x0, x19, #0x440
1015e3e64:     	bl	0x1015d6af8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015e3e68:     	str	wzr, [x19, #0x440]
1015e3e6c:     	mov	w8, #0xc                ; =12
1015e3e70:     	strb	w8, [x19, #0x448]
1015e3e74:     	adrp	x8, 0x10754e000 <_anon.c6403047f4a14a37c3efa18022aecbda.176+0x1a9>
1015e3e78:     	add	x8, x8, #0xb5e
1015e3e7c:     	str	x8, [x19, #0x450]
1015e3e80:     	mov	w8, #0x24               ; =36
1015e3e84:     	str	x8, [x19, #0x458]
1015e3e88:     	mov	w0, #0x3                ; =3
1015e3e8c:     	b	0x1015e3df8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x114>
1015e3e90:     	adrp	x2, 0x107f08000 <_anon.aa2f8f78b1e53f24f35e8bb9ba7375a8.680+0x220>
1015e3e94:     	add	x2, x2, #0x440
1015e3e98:     	b	0x1015e3eac <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks5admit+0x1c8>
1015e3e9c:     	mov	x0, #0x0                ; =0
1015e3ea0:     	mov	x1, #0x0                ; =0
1015e3ea4:     	adrp	x2, 0x107f06000 <_anon.5625b5f9497b68fa0f61674c706e414d.281+0x58>
1015e3ea8:     	add	x2, x2, #0xc78
1015e3eac:     	bl	0x1039fb3f0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e3eb0:     	brk	#0x1
1015e3eb4:     	bl	0x1039fb514 <__RNvNtCsgDHHaSskbIF_4core9panicking19panic_cannot_unwind>
