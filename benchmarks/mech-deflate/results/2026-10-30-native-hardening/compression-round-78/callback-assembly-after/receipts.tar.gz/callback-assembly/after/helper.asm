
/private/tmp/mech-admitted-helpers-round78-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015e3eb8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper>:
1015e3eb8:     	sub	sp, sp, #0x140
1015e3ebc:     	stp	x28, x27, [sp, #0xe0]
1015e3ec0:     	stp	x26, x25, [sp, #0xf0]
1015e3ec4:     	stp	x24, x23, [sp, #0x100]
1015e3ec8:     	stp	x22, x21, [sp, #0x110]
1015e3ecc:     	stp	x20, x19, [sp, #0x120]
1015e3ed0:     	stp	x29, x30, [sp, #0x130]
1015e3ed4:     	add	x29, sp, #0x130
1015e3ed8:     	cbz	x0, 0x1015e3fac <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0xf4>
1015e3edc:     	ldr	w8, [x0, #0x440]
1015e3ee0:     	cmp	w8, #0x6
1015e3ee4:     	b.ne	0x1015e412c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x274>
1015e3ee8:     	mov	x23, x6
1015e3eec:     	mov	x20, x5
1015e3ef0:     	mov	x21, x4
1015e3ef4:     	mov	x22, x3
1015e3ef8:     	add	x25, sp, #0x90
1015e3efc:     	add	x19, x0, #0x440
1015e3f00:     	cmn	x2, #0x1f
1015e3f04:     	b.eq	0x1015e3fb4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0xfc>
1015e3f08:     	cmn	x2, #0x1e
1015e3f0c:     	b.ne	0x1015e40d4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x21c>
1015e3f10:     	add	x8, sp, #0x90
1015e3f14:     	mov	x24, x0
1015e3f18:     	mov	x27, x1
1015e3f1c:     	bl	0x101625954 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
1015e3f20:     	ldr	w26, [sp, #0x90]
1015e3f24:     	cmp	w26, #0x6
1015e3f28:     	b.ne	0x1015e404c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x194>
1015e3f2c:     	mov	x0, x24
1015e3f30:     	ldr	x10, [x24, #0x498]
1015e3f34:     	ldr	x8, [x10, #0x590]
1015e3f38:     	mov	x1, x27
1015e3f3c:     	cmp	x27, x8
1015e3f40:     	b.hs	0x1015e40d0 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x218>
1015e3f44:     	ldr	x8, [x10, #0x588]
1015e3f48:     	add	x8, x8, x1, lsl #4
1015e3f4c:     	ldr	x9, [x8]
1015e3f50:     	cmp	x9, #0x1
1015e3f54:     	b.ne	0x1015e40d0 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x218>
1015e3f58:     	ldr	x8, [x8, #0x8]
1015e3f5c:     	ldr	x9, [x10, #0x580]
1015e3f60:     	cmp	x8, x9
1015e3f64:     	b.hs	0x1015e4240 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x388>
1015e3f68:     	ldr	x9, [x10, #0x578]
1015e3f6c:     	mov	w10, #0x38              ; =56
1015e3f70:     	madd	x8, x8, x10, x9
1015e3f74:     	ldr	x9, [x8]
1015e3f78:     	cbnz	x9, 0x1015e40d0 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x218>
1015e3f7c:     	ldr	x9, [x8, #0x18]
1015e3f80:     	cbz	x9, 0x1015e424c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x394>
1015e3f84:     	ldr	x9, [x0, #0x490]
1015e3f88:     	ldr	w10, [x9, #0x340]
1015e3f8c:     	cmp	w10, #0x1
1015e3f90:     	b.ne	0x1015e40c0 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x208>
1015e3f94:     	ldr	x8, [x8, #0x10]
1015e3f98:     	ldr	w8, [x8]
1015e3f9c:     	ldr	w9, [x9, #0x344]
1015e3fa0:     	cmp	w9, w8
1015e3fa4:     	cset	w8, eq
1015e3fa8:     	b	0x1015e40c4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x20c>
1015e3fac:     	mov	w0, #0x3                ; =3
1015e3fb0:     	b	0x1015e4130 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x278>
1015e3fb4:     	add	x8, sp, #0x90
1015e3fb8:     	mov	x24, x0
1015e3fbc:     	mov	x27, x1
1015e3fc0:     	bl	0x101625954 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
1015e3fc4:     	ldr	w26, [sp, #0x90]
1015e3fc8:     	cmp	w26, #0x6
1015e3fcc:     	b.ne	0x1015e404c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x194>
1015e3fd0:     	mov	x0, x24
1015e3fd4:     	ldr	x10, [x24, #0x498]
1015e3fd8:     	ldr	x8, [x10, #0x590]
1015e3fdc:     	mov	x1, x27
1015e3fe0:     	cmp	x27, x8
1015e3fe4:     	b.hs	0x1015e41f4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x33c>
1015e3fe8:     	ldr	x8, [x10, #0x588]
1015e3fec:     	add	x8, x8, x1, lsl #4
1015e3ff0:     	ldr	x9, [x8]
1015e3ff4:     	cmp	x9, #0x1
1015e3ff8:     	b.ne	0x1015e41f4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x33c>
1015e3ffc:     	ldr	x8, [x8, #0x8]
1015e4000:     	ldr	x9, [x10, #0x580]
1015e4004:     	cmp	x8, x9
1015e4008:     	b.hs	0x1015e4240 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x388>
1015e400c:     	ldr	x9, [x10, #0x578]
1015e4010:     	mov	w10, #0x38              ; =56
1015e4014:     	madd	x8, x8, x10, x9
1015e4018:     	ldr	x9, [x8]
1015e401c:     	cbnz	x9, 0x1015e41f4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x33c>
1015e4020:     	ldr	x9, [x8, #0x18]
1015e4024:     	cbz	x9, 0x1015e424c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x394>
1015e4028:     	ldr	x9, [x0, #0x490]
1015e402c:     	ldr	w10, [x9, #0x340]
1015e4030:     	tbz	w10, #0x0, 0x1015e41e4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x32c>
1015e4034:     	ldr	x8, [x8, #0x10]
1015e4038:     	ldr	w8, [x8]
1015e403c:     	ldr	w9, [x9, #0x344]
1015e4040:     	cmp	w9, w8
1015e4044:     	cset	w8, eq
1015e4048:     	b	0x1015e41e8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x330>
1015e404c:     	ldr	w20, [sp, #0x94]
1015e4050:     	ldp	x21, x22, [sp, #0x98]
1015e4054:     	ldur	q0, [x25, #0x18]
1015e4058:     	ldur	q1, [x25, #0x28]
1015e405c:     	stp	q0, q1, [sp, #0x50]
1015e4060:     	ldur	q0, [x25, #0x38]
1015e4064:     	str	q0, [sp, #0x70]
1015e4068:     	ldr	x8, [sp, #0xd8]
1015e406c:     	str	x8, [sp, #0x80]
1015e4070:     	ldr	w8, [x19]
1015e4074:     	cmp	w8, #0x6
1015e4078:     	mov	x8, x24
1015e407c:     	b.eq	0x1015e408c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x1d4>
1015e4080:     	add	x0, x24, #0x440
1015e4084:     	bl	0x1015d6af8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015e4088:     	mov	x8, x24
1015e408c:     	str	w26, [x8, #0x440]
1015e4090:     	str	w20, [x8, #0x444]
1015e4094:     	str	x21, [x8, #0x448]
1015e4098:     	str	x22, [x8, #0x450]
1015e409c:     	add	x9, x8, #0x458
1015e40a0:     	ldr	x10, [sp, #0x80]
1015e40a4:     	str	x10, [x8, #0x488]
1015e40a8:     	ldp	q0, q1, [sp, #0x50]
1015e40ac:     	stp	q0, q1, [x9]
1015e40b0:     	ldr	q0, [sp, #0x70]
1015e40b4:     	mov	w0, #0x2                ; =2
1015e40b8:     	str	q0, [x9, #0x20]
1015e40bc:     	b	0x1015e4130 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x278>
1015e40c0:     	mov	x8, #0x0                ; =0
1015e40c4:     	ldr	x9, [x0, #0x4c8]
1015e40c8:     	cbz	x9, 0x1015e4200 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x348>
1015e40cc:     	str	x8, [x9]
1015e40d0:     	mov	w2, #0x1                ; =1
1015e40d4:     	cbz	x23, 0x1015e40e4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x22c>
1015e40d8:     	ldr	x8, [x0, #0x4c8]
1015e40dc:     	cmp	x23, x8
1015e40e0:     	b.eq	0x1015e4150 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x298>
1015e40e4:     	str	wzr, [sp]
1015e40e8:     	mov	w8, #0xc                ; =12
1015e40ec:     	strb	w8, [sp, #0x8]
1015e40f0:     	adrp	x8, 0x10754e000 <_anon.c6403047f4a14a37c3efa18022aecbda.176+0x1a9>
1015e40f4:     	add	x8, x8, #0xb82
1015e40f8:     	mov	w9, #0x1e               ; =30
1015e40fc:     	stp	x8, x9, [sp, #0x10]
1015e4100:     	ldr	w8, [x19]
1015e4104:     	cmp	w8, #0x6
1015e4108:     	b.eq	0x1015e4114 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x25c>
1015e410c:     	mov	x0, x19
1015e4110:     	bl	0x1015d6af8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015e4114:     	ldp	q0, q1, [sp, #0x20]
1015e4118:     	stp	q0, q1, [x19, #0x20]
1015e411c:     	ldr	q0, [sp, #0x40]
1015e4120:     	str	q0, [x19, #0x40]
1015e4124:     	ldp	q1, q0, [sp]
1015e4128:     	stp	q1, q0, [x19]
1015e412c:     	mov	w0, #0x2                ; =2
1015e4130:     	ldp	x29, x30, [sp, #0x130]
1015e4134:     	ldp	x20, x19, [sp, #0x120]
1015e4138:     	ldp	x22, x21, [sp, #0x110]
1015e413c:     	ldp	x24, x23, [sp, #0x100]
1015e4140:     	ldp	x26, x25, [sp, #0xf0]
1015e4144:     	ldp	x28, x27, [sp, #0xe0]
1015e4148:     	add	sp, sp, #0x140
1015e414c:     	ret
1015e4150:     	stp	x22, x21, [sp, #0x90]
1015e4154:     	str	x20, [sp, #0xa0]
1015e4158:     	mov	x8, sp
1015e415c:     	add	x3, sp, #0x90
1015e4160:     	mov	x20, x0
1015e4164:     	bl	0x10162678c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>
1015e4168:     	ldr	w8, [sp]
1015e416c:     	cmp	w8, #0x6
1015e4170:     	b.ne	0x1015e4100 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x248>
1015e4174:     	ldr	x8, [sp, #0x8]
1015e4178:     	cmp	x8, #0x1
1015e417c:     	b.ne	0x1015e4198 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x2e0>
1015e4180:     	ldr	x9, [x20, #0x4c8]
1015e4184:     	cbz	x9, 0x1015e41a0 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x2e8>
1015e4188:     	mov	x0, #0x0                ; =0
1015e418c:     	ldr	x8, [sp, #0x10]
1015e4190:     	str	x8, [x9]
1015e4194:     	b	0x1015e4130 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x278>
1015e4198:     	mov	x0, #0x0                ; =0
1015e419c:     	b	0x1015e4130 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x278>
1015e41a0:     	mov	x8, x20
1015e41a4:     	ldr	w9, [x19]
1015e41a8:     	cmp	w9, #0x6
1015e41ac:     	b.eq	0x1015e41bc <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x304>
1015e41b0:     	add	x0, x20, #0x440
1015e41b4:     	bl	0x1015d6af8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015e41b8:     	mov	x8, x20
1015e41bc:     	str	wzr, [x8, #0x440]
1015e41c0:     	mov	w9, #0xc                ; =12
1015e41c4:     	strb	w9, [x8, #0x448]
1015e41c8:     	adrp	x9, 0x10754e000 <_anon.c6403047f4a14a37c3efa18022aecbda.176+0x1a9>
1015e41cc:     	add	x9, x9, #0xb5e
1015e41d0:     	str	x9, [x8, #0x450]
1015e41d4:     	mov	w9, #0x24               ; =36
1015e41d8:     	str	x9, [x8, #0x458]
1015e41dc:     	mov	w0, #0x3                ; =3
1015e41e0:     	b	0x1015e4130 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x278>
1015e41e4:     	mov	x8, #0x0                ; =0
1015e41e8:     	ldr	x9, [x0, #0x4c8]
1015e41ec:     	cbz	x9, 0x1015e4200 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x348>
1015e41f0:     	str	x8, [x9]
1015e41f4:     	mov	x2, #-0x10              ; =-16
1015e41f8:     	cbnz	x23, 0x1015e40d8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x220>
1015e41fc:     	b	0x1015e40e4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x22c>
1015e4200:     	ldr	w8, [x19]
1015e4204:     	cmp	w8, #0x6
1015e4208:     	b.eq	0x1015e4218 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x360>
1015e420c:     	add	x0, x24, #0x440
1015e4210:     	bl	0x1015d6af8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015e4214:     	mov	x0, x24
1015e4218:     	str	wzr, [x0, #0x440]
1015e421c:     	mov	w8, #0xc                ; =12
1015e4220:     	strb	w8, [x0, #0x448]
1015e4224:     	adrp	x8, 0x10754e000 <_anon.c6403047f4a14a37c3efa18022aecbda.176+0x1a9>
1015e4228:     	add	x8, x8, #0xb5e
1015e422c:     	str	x8, [x0, #0x450]
1015e4230:     	mov	w8, #0x24               ; =36
1015e4234:     	str	x8, [x0, #0x458]
1015e4238:     	mov	w0, #0x3                ; =3
1015e423c:     	b	0x1015e4130 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x278>
1015e4240:     	adrp	x2, 0x107f08000 <_anon.aa2f8f78b1e53f24f35e8bb9ba7375a8.680+0x220>
1015e4244:     	add	x2, x2, #0x440
1015e4248:     	b	0x1015e4258 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5hooks6helper+0x3a0>
1015e424c:     	mov	x8, #0x0                ; =0
1015e4250:     	adrp	x2, 0x107f06000 <_anon.5625b5f9497b68fa0f61674c706e414d.281+0x58>
1015e4254:     	add	x2, x2, #0xc78
1015e4258:     	mov	x0, x8
1015e425c:     	mov	x1, x9
1015e4260:     	bl	0x1039fb3f0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015e4264:     	brk	#0x1
1015e4268:     	bl	0x1039fb514 <__RNvNtCsgDHHaSskbIF_4core9panicking19panic_cannot_unwind>
