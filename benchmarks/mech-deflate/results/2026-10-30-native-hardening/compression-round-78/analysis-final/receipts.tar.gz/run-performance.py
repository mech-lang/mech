"""Serial real-computation timing, counters and diagnostic-only profiling."""
from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
assert json.loads((r/'focused-controls/run.json').read_text())['exit']==0
for name,args in [('linked-build.py',['after']),('run-primary.py',[]),('counters.py',[]),('sites.py',['before']),('sites.py',['after']),('profile-isolated.py',[]),('instruction-windows.py',[])]:
 print('START',name,flush=True)
 subprocess.run(['python3',str(r/name),*args],check=True)
 print('DONE',name,flush=True)
 if name=='linked-build.py':
  subprocess.run(['python3',str(r/'archive.py'),'compiled-artifact',str(r/'linked-primary/after/object.o'),str(r/'linked-primary/after/descriptor.json'),str(r/'linked-primary/after/metadata.json'),str(r/'linked-primary/after/binding.json')],check=True)
(r/'DIAGNOSTIC_RUN_ALLOWED').write_text('Primary, counter, allocation-census and sampling cohorts completed serially. Diagnostic counters are excluded from all performance claims.\n')
subprocess.run(['python3',str(r/'diagnostic-counts.py')],check=True)
print('R78_MEASURED: inspect all matched observations before broad qualification',flush=True)
