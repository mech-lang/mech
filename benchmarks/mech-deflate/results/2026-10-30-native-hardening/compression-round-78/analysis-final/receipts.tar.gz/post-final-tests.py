from pathlib import Path
import subprocess,json,re,time,hashlib
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'units-final';unit=str(p/'gpu-unit-tests')
ci=['locals_snapshot','composition_tests','parent_continuation_is_single_use','native_runtime_consolidation','buffer_frames::tests::batching','buffer_frames::tests::transfer','work::retirement::tests','exhausted_retirement_generation','cleanup_effects::tests','numeric_shadow','numeric_words::tests','numeric_first_change','admitted_helper_tests']
for label,selection,count in [('runtime',['native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map'],331),('work-values',['native_artifact::work::','native_artifact::memory::','native_artifact::values::'],32),('ci',ci,37)]:
 for suffix,flags in [('inventory',['--list']),('run',['--nocapture','--test-threads=1'])]:
  name=label+'-'+suffix;cmd=[unit,*selection,*flags];t=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
  if suffix=='inventory':observed=len(re.findall(r': test$',q.stdout,re.M))
  else:
   m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);observed=int(m[1]) if m else None
  row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t,'expected_tests':count,('listed_tests' if suffix=='inventory' else 'executed_tests'):observed};(p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  subprocess.run(['python3',str(r/'archive.py'),'final-unit-'+name,str(p/(name+'.json')),str(p/(name+'.stdout')),str(p/(name+'.stderr')),str(Path(__file__))],check=True)
  print(name,q.returncode,observed,flush=True)
  if q.returncode:print(q.stdout[-4500:]+q.stderr[-4500:],flush=True)
  q.check_returncode();assert observed==count
for name in ['architecture-final.py','type-architecture.py']:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name)],check=True)
p=r/'final-source';p.mkdir()
for name,cmd in [('format',['/Users/coreymontella/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/bin/cargo','fmt','--all','--','--check']),('whitespace',['git','diff','--check'])]:
 q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode},indent=2)+'\n');q.check_returncode()
config=json.loads((r/'configuration.json').read_text());release=json.loads((r/'final-release.json').read_text())['source_head'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','diff',release,head,'--',*config['production_files']],cwd=w);assert not subprocess.check_output(['git','diff',config['baseline_checkpoint'],head,'--','src'],cwd=w)
proof={'release_source':release,'qualification_source':json.loads((r/'source-scope.json').read_text())['candidate_source'],'checked_head':head,'production_files_identical':True,'non_gpu_source_identical':True,'test_boundary_allowlist_unchanged':not bool(subprocess.check_output(['git','diff',config['baseline_checkpoint'],head,'--','scripts/check-unsafe-boundaries.sh'],cwd=w))};(p/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');subprocess.run(['python3',str(r/'archive.py'),'final-source',str(p),str(Path(__file__))],check=True)
print('FINAL_CANDIDATE_VALIDATED',flush=True)
