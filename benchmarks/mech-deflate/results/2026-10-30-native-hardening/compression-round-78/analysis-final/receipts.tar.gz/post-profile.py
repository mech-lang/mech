from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for name in ['profile-reference.py','audit-callbacks.py']:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name)],check=True)
