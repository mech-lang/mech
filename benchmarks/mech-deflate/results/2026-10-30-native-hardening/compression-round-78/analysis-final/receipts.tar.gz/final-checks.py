"""Actual runtime-only GPU WAE compilation, formatting and source equivalence."""
from pathlib import Path
import json,subprocess,os,time,hashlib
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'final-checks';p.mkdir();base=json.loads((r/'final-release.json').read_text());cmd=base['command'];command=[];i=0
while i<len(cmd):
 if cmd[i]=='--cfg' and cmd[i+1].startswith('feature='):i+=2;continue
 command.append(cmd[i]);i+=1
command[-1]=str(p/'runtime-only.rmeta');command[1:1]=['--emit=metadata','--cfg','feature="canonical-native-program-runtime"','--cfg','feature="canonical-native-runtime"']
commands=[('runtime-only',command,base['environment']),('format',['/Users/coreymontella/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/bin/cargo','fmt','--all','--','--check'],{}),('whitespace',['git','diff','--check'],{})]
for name,cmd,environment in commands:
 t=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**environment},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'environment':environment,'exit':q.returncode,'seconds':time.monotonic()-t,'scope':'Runtime-only GPU cfg compiled against pinned unchanged feature-rich dependency artifacts, warnings-as-errors. This is not a claim of a newly built minimal dependency graph.' if name=='runtime-only' else 'Current committed workspace validation.'},indent=2)+'\n');print(name,q.returncode,flush=True)
 subprocess.run(['python3',str(r/'archive.py'),'final-check-'+name,str(p/(name+'.json')),str(p/(name+'.stdout')),str(p/(name+'.stderr')),str(r/'final-checks.py')],check=True)
 if q.returncode:print(q.stdout[-5000:]+q.stderr[-5000:],flush=True)
 q.check_returncode()
config=json.loads((r/'configuration.json').read_text());revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();release=base['source_head'];delta=subprocess.check_output(['git','diff',release,revision,'--',*config['production_files']],cwd=w);assert not delta
unaffected=subprocess.check_output(['git','diff',config['baseline_checkpoint'],revision,'--','src'],cwd=w);assert not unaffected
proof={'release_source':release,'qualification_source':json.loads((r/'source-scope.json').read_text())['candidate_source'],'checked_head':revision,'production_files_identical':True,'non_gpu_project_source_identical_to_baseline':True,'diff_sha256':hashlib.sha256(delta).hexdigest(),'source_revision_note':'d176bbd is test-only observer/ABI expectation migration. The actual measured release remains14d0c11; no timing is relabeled to the test-only commit.','frozen_scalar_abi':1,'private_program_abi':38,'typed_ir':132,'work_policy':95,'bytecode':14};(p/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');subprocess.run(['python3',str(r/'archive.py'),'production-equivalence',str(p/'source-proof.json'),str(r/'final-checks.py')],check=True)
