from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack')
subprocess.run(['python3',str(r/'scalar-controls.py')],cwd=w,check=True)
p=r/'primary';files=[x for x in p.iterdir() if x.is_file() and (x.name.startswith('scalar-') or x.name in ['frame-before.json','frame-after.json'])];subprocess.run(['python3',str(r/'archive.py'),'scalar',*map(str,files),str(r/'scalar-controls.py')],cwd=w,check=True)
subprocess.run(['python3',str(r/'frame-allocation.py')],cwd=w,check=True)
subprocess.run(['python3',str(r/'archive.py'),'frame-allocation',str(r/'frame-allocation'),str(r/'frame-allocation.py')],cwd=w,check=True)
