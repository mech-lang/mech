"""Bounded disassembly of actual callback entries; no compressor execution."""
from pathlib import Path
from collections import Counter
import json,subprocess,re,hashlib
r=Path(__file__).resolve().parent;p=r/'callback-assembly';p.mkdir()
all_rows={}
for label in ['before','after']:
 d=p/label;d.mkdir();worker=r/'linked-primary'/label/'worker';binding=json.loads((worker.parent/'binding.json').read_text());digest=hashlib.file_digest(worker.open('rb'),'sha256').hexdigest();assert digest==binding['worker_sha256']
 cmd=['xcrun','llvm-nm','-n','--defined-only',str(worker)];q=subprocess.run(cmd,capture_output=True,text=True);q.check_returncode();symbols=[]
 for line in q.stdout.splitlines():
  m=re.match(r'^([0-9a-fA-F]+)\s+([tT])\s+(.+)$',line)
  if m:symbols.append((int(m[1],16),m[3]))
 addresses=sorted(set(a for a,_ in symbols));rows=[]
 for kind,needle in [('admit','5hooks5admit'),('helper','5hooks6helper')]:
  found=[(a,n) for a,n in symbols if needle in n];assert len(found)==1,(kind,found)
  start,name=found[0];stop=min(a for a in addresses if a>start);assert stop-start<65536
  command=['xcrun','llvm-objdump','-d','--no-show-raw-insn',f'--start-address={start:#x}',f'--stop-address={stop:#x}',str(worker)];z=subprocess.run(command,capture_output=True,text=True)
  (d/(kind+'.asm')).write_text(z.stdout);(d/(kind+'.stderr')).write_text(z.stderr);z.check_returncode();instructions=[]
  for line in z.stdout.splitlines():
   m=re.match(r'^\s*([0-9a-fA-F]+):\s+([a-z][a-z0-9.]*)\s*(.*)$',line)
   if m and start<=int(m[1],16)<stop:instructions.append({'relative_address':int(m[1],16)-start,'opcode':m[2],'operands':m[3]})
  rows.append({'kind':kind,'symbol':name,'start':start,'stop':stop,'command':command,'exit':z.returncode,'own_static_instructions':len(instructions),'instructions':instructions,'opcodes':dict(Counter(x['opcode'] for x in instructions))})
 receipt={'worker_sha256':digest,'worker_bytes':worker.stat().st_size,'compiler_source':binding['compiler_source'],'nm_command':cmd,'nm_exit':q.returncode,'full_nm_stdout_sha256':hashlib.sha256(q.stdout.encode()).hexdigest(),'full_nm_stdout_bytes':len(q.stdout.encode()),'regions':rows,'scope':'Exact own routine boundaries verified from ordered symbols; only selected disassembly retained, no unbounded symbol dump. Static instruction counts are not dynamic function attribution.'};(d/'audit.json').write_text(json.dumps(receipt,indent=2)+'\n');all_rows[label]=receipt
 subprocess.run(['python3',str(r/'archive.py'),'callback-assembly-'+label,str(d),str(r/'audit-callbacks.py')],check=True)
print(json.dumps({label:{row['kind']:row['own_static_instructions'] for row in data['regions']} for label,data in all_rows.items()},indent=2))
