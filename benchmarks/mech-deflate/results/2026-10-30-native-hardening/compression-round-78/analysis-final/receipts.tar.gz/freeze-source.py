"""Freeze a reviewed, committed R78 source delta; execute only when parent authorizes."""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack')
c=json.loads((r/'configuration.json').read_text());assert c['initialized'];base=c['baseline_checkpoint']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
allowed=c['production_files']+c['test_files']+sys.argv[1:]
changed=subprocess.check_output(['git','diff','--name-only',base,'--','src','hosts/gpu/src'],cwd=w,text=True).splitlines()
assert set(changed)<=set(allowed),(changed,allowed)
production=subprocess.check_output(['git','diff',base,'--',*c['production_files']],cwd=w)
assert production,'No production change to freeze'
full=subprocess.check_output(['git','diff',base,'--','src','hosts/gpu/src'],cwd=w)
row={'baseline_checkpoint':base,'baseline_build_source':c['baseline_build_source'],'candidate_source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'production_files':c['production_files'],'allowed_source_files':allowed,'changed_source_files':changed,'production_diff_sha256':hashlib.sha256(production).hexdigest(),'complete_source_diff_sha256':hashlib.sha256(full).hexdigest()}
(r/'source-scope.json').write_text(json.dumps(row,indent=2)+'\n');(r/'production.patch').write_bytes(production);(r/'source.patch').write_bytes(full)
print(json.dumps(row,indent=2))
