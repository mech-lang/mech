from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-shared-shadows-round51-20261031');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();b=json.loads((old/'final-release.json').read_text());libs=json.loads((old/'final-libraries.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
for lib in libs.values():assert sha(lib['path'])==lib['sha256']
cmd=b['command'].copy();cmd[-3]=str(p/'source/lib.rs');cmd[-1]=str(p/'variants/after/libmech_gpu.rlib');at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('build.'+stream)).write_text(getattr(q,stream))
row={'command':cmd,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-at,'source_head':source,'base_optimized_gpu_source':'e0c180a47fdeeabada8b6d8df0c57f3f5fdc3d6c','diagnostic_source_sha256':sha(p/'source/native_artifact/program/runtime/invocation/buffer_frames.rs'),'scope':'Isolated diagnostic overlay only; full eight-byte compressor; no instrumented timing used for performance.'};(p/'variants/after/build.json').write_text(json.dumps(row,indent=2)+'\n')
subprocess.run(['python3',str(p/'archive.py'),'gpu-build',str(p/'variants/after/build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(p/'source/native_artifact/program/runtime/invocation/buffer_frames.rs'),str(p/'run.py')],cwd=w,check=True)
if q.returncode:print(q.stderr[-4000:],flush=True)
q.check_returncode();libs['mech_gpu']={**libs['mech_gpu'],'path':cmd[-1],'sha256':sha(cmd[-1])};(p/'variants/after/libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
subprocess.run(['python3',str(p/'linked-build.py'),'after'],cwd=w,check=True)
s=(p/'linked-primary/after/smoke.stderr').read_text().split('MEASURING 1\n',1)[1];import re,collections
rows=[]
for line in s.splitlines():
 if line.startswith('FRAME_COPY '):
  d=dict(re.findall(r'(\w+)=(\w+)',line));rows.append({k:(v=='true' if k=='last_use' else int(v)) for k,v in d.items()})
assert rows;result={'observations':1,'scope':'One complete second eight-byte visit from a matched diagnostic linked worker; trace excluded from performance. Eligibility is existing whole-frame last use, not a payload exclusivity or savings claim.','selected_copy_visits':len(rows),'last_use_visits':sum(x['last_use'] for x in rows),'last_use_managed_handles':sum(x['managed_fields'] for x in rows if x['last_use']),'live_source_visits':sum(not x['last_use'] for x in rows),'live_managed_handles':sum(x['managed_fields'] for x in rows if not x['last_use']),'rows':rows};(p/'census.json').write_text(json.dumps(result,indent=2)+'\n');subprocess.run(['python3',str(p/'archive.py'),'census',str(p/'census.json'),str(p/'variants/after/libraries.json'),str(p/'run.py')],cwd=w,check=True);print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
