from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'units-after';unit=str(p/'gpu-unit-tests')
for label,args,count in [('preparation',['cleanup_effects::tests::'],2),('runtime',['native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map'],326),('work-values',['native_artifact::work::','native_artifact::memory::','native_artifact::values::'],32)]:
 cmd=[unit,*args,'--nocapture','--test-threads=1'];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'executed_tests':int(m[1]) if m else None,'production_dependencies':str(r/'final-libraries.json')};(p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'qualification-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'qualify-all.py')],cwd=w,check=True)
 print(label,q.returncode,row['executed_tests'],flush=True)
 if q.returncode:print(q.stdout[-4000:]+q.stderr[-6000:],flush=True)
 q.check_returncode();assert row['executed_tests']==count
for name in ['qualify.py','linked-acceptance.py','controls.py','workflow-checks.py','ci.py','architecture.py']:
 if name=='controls.py':subprocess.run(['python3',str(r/'control-build.py'),'after'],check=True)
 print('START',name,flush=True);subprocess.run(['python3',str(r/name)],check=True)
 if name=='qualify.py':(r/'qualification/tests').unlink()
 if name=='linked-acceptance.py':(r/'linked-acceptance/worker').unlink()
 if name=='controls.py':(r/'primary/frame-after').unlink()

