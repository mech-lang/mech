from pathlib import Path
import json,os,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];p=r/('units-'+phase);p.mkdir();b=json.loads(Path('/private/tmp/mech-shared-shadows-round51-20261031/units-boundary/build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'gpu-unit-tests');source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
def run(label,command,expected=None):
 t=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-t,'compiler_source':source,'scope':'Exact retained selected GPU unit flags, opt1 and warnings-as-errors; unchanged frozen Core/Engine/Stdlib/Compute graph. No benchmark observations in this cohort.'};m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)
 if m:row.update(executed_tests=int(m[1])+int(m[2]),passed_tests=int(m[1]),failed_tests=int(m[2]))
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 files=[p/(label+'.'+x) for x in ['json','stdout','stderr']]+[r/'units.py',w/'hosts/gpu/src/native_artifact/program/runtime/buffer_frame_retirement_tests/transfer.rs']
 # Archive the source test under this experiment root without changing its body.
 snapshot=r/('test-source-'+phase+'.rs');snapshot.write_bytes(files[-1].read_bytes());files[-1]=snapshot
 subprocess.run(['python3',str(r/'archive.py'),'unit-'+phase+'-'+label,*map(str,files)],cwd=w,check=True);print(phase,label,q.returncode,row.get('passed_tests'),row.get('failed_tests'),flush=True)
 if expected=='red':
  print(q.stdout[-4000:]+q.stderr[-2000:],flush=True);assert q.returncode!=0 and row.get('passed_tests')==2 and row.get('failed_tests')==2
 else:
  if q.returncode:print(q.stdout[-4000:]+q.stderr[-5000:],flush=True)
  q.check_returncode()
  if expected is not None:assert row['passed_tests']==expected
run('build',cmd)
run('transfer',[str(p/'gpu-unit-tests'),'buffer_frames::tests::transfer','--nocapture','--test-threads=1'],'red' if phase.startswith('before') else 4)
