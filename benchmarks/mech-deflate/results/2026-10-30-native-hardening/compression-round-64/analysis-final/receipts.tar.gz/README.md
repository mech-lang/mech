# R64: first-only central projection budget checks

Prepared scratch harness. No R64 compiler build, test, compressor execution or numerical result has been performed by the harness author. Parent owns source application, execution, publication and the retain/reject decision. The baseline is the completed and retained R63 graph; initialize it only after R63 qualification and reporting have finished. No R63 timing or test receipt becomes an R64 observation.

The candidate changes only the two existing budget-policy queries in `src/engine/src/resident/budget.rs`: preview uses `first_call_memory_budget_violation(...).is_none()` and charge matches the first violation directly. The same ordered Core evaluator underlies both APIs. The successful full-result evaluator already allocates nothing for its empty vector. Expected successful allocation-count/byte/reallocation deltas are zero. This is an instruction and call-boundary experiment; no speedup is presumed.

The focused patch adds two tests to `src/engine/src/resident/native_projection_meter_tests.rs`: `native_projection_meter_keeps_policy_order_after_enclosing_funding` and `native_projection_meter_preview_and_charge_keep_compute_node_overflow_atomic`. These must pass on both parent and candidate. Their source remains in `findings-packet/tests.patch`; production patch is separate. Preserve arithmetic overflow, scope checks, enclosing-funding precedence, ordered policy rejection, the already-paid enclosing-work prefix, unchanged accumulated meter state on failure, and retry. Core's existing `first_call_rejection` filter independently compares full and first-only evaluators across 2,048 limit subsets and boundary cases.

## Exact run order

All commands below are for the parent to run serially. `archive.py` deliberately writes and commits receipt packets; none of these commands should be run by an agent without parent authorization. The checkout must be clean at build boundaries. Apply tests and source through ordinary reviewed commits; this harness does not patch authoritative source.

1. Finish and retain R63. Record its accepted checkpoint SHA separately from its actual build SHA. Initialize once:

   `python3 /private/tmp/mech-projection-budget-round64-20261031/initialize-baseline.py <accepted-R63-checkpoint-SHA>`

   This pins R63 libraries, auxiliary dependencies, emitted Object/descriptor/metadata and linked worker. It copies probe sources and existing compiled nonallocating diagnostic probe, verifies hashes, initializes expected allocation totals from R63's completed census counter, and creates the baseline symlinks. It copies no historical allocation census or timing/test results.

2. Apply/commit only `findings-packet/tests.patch` first. Run the parent semantic witnesses and unchanged Core tests:

   `python3 /private/tmp/mech-projection-budget-round64-20261031/engine-focused.py parent`

   `python3 /private/tmp/mech-projection-budget-round64-20261031/core-focused.py`

   The Engine helper stages current Engine sources in scratch and restores only staged `budget.rs` to the accepted baseline version. It never swaps authoritative files. It builds with R63's retained Engine test command and frozen baseline dependency graph. Expected parent selections: projection 12, focused policy-order 1, focused overflow/retry 1, inherited shape 6, with matching nonzero inventories. Core builds a test executable only, using unchanged current Core source and its retained test profile; its frozen production library is never rebuilt. Core selected count 2. All selections must pass, with no inherited expected-red case.

3. Apply/commit `findings-packet/production.patch`. Schedule the Engine projection filter alongside the existing shape filter in the appropriate existing CI profile if not already scheduled. Freeze the bounded current source diff and build the coherent candidate graph:

   `python3 /private/tmp/mech-projection-budget-round64-20261031/freeze-source.py`

   `python3 /private/tmp/mech-projection-budget-round64-20261031/build-changed.py`

   `build-changed.py` reuses exact Engine/Compute/Stdlib/Runtime command/environment receipts from R59 and GPU flags from the retained R63 build. It rebuilds Engine → Compute → Stdlib → Runtime → GPU in one fresh dependency overlay, replacing every explicit dependency and search path coherently. Frozen Core/math/syntax/external hashes are checked before and after. No Cargo-wide or math rebuild. Build and test executable compilation remain outside timing.

4. Run the candidate focused tests, GPU focused tests and inventory, then all serial measurement cohorts and qualification:

   `python3 /private/tmp/mech-projection-budget-round64-20261031/run-remaining.py`

   The runner refuses to proceed without passing parent projection 12/shape 6 and Core 2 receipts. It runs candidate Engine 12 + 6 and focused subsets, builds GPU tests, then runs `run-cohorts.py` and `qualify-all.py` serially. No background builds or tests may overlap primary or diagnostic cohorts.

   `run-cohorts.py`: fresh candidate emission and byte-identity checks → primary → hardware/heap counters → fresh before full census → fresh after full census → Mech CPU-time samples → reference CPU-time samples. The retained R63 linked worker is the primary baseline; the candidate worker binds the coherent new host graph. Candidate Object, descriptor and metadata must match baseline byte-for-byte.

   `qualify-all.py` executes, rather than merely inventories, all 329 selected runtime tests. It also executes preparation 2, work/memory/value 32, components 236, composition 8, path mechanism 1, linked 12, scalar controls 12, frame-allocation controls 8, Python workflow 132, GPU CI 35, Engine CI projection 12/shape 6 and architecture 10. Batches overlap and are not a count of unique tests. Counts are enforced against actual run receipts.

5. After all cohorts finish, derive numeric results and preserve all failures. Copy `decision-template.json` to `decision.json`, fill exact source pins and an evidence-based retain/reject reason; do not force a positive instruction or elapsed result. `prior-failures.json` starts empty and must record any failed current-round attempts with their actual raw receipt and disposition. Never overwrite failed run directories; use an explicitly named new attempt and update the selected receipt paths.

   `python3 /private/tmp/mech-projection-budget-round64-20261031/finalize-analysis.py`

   This executes only analysis scripts, enforces completed qualification, and writes scorecards/report. Add `--archive` only when the parent is ready to archive. Publish the report, scorecard JSON/CSV, allocation-comparison JSON, profile JSON, validation JSON, binary-audit JSON and numerical replay scripts. Then run published `reconstruct.py /new/empty/output/path`: it verifies every archived version and reproduces five public numeric outputs without builds, compressor execution or external scratch dependencies.

## Cohorts and acceptance

Primary has four independently prepared pairs, 16 alternating blocks per pair and 31 calls per variant/block: 3,968 timed observations, 3,984 including per-session warmup/profile rows. A fresh 20,000-call reference sets the comparison multiple. Report before/after multiples and their matched ratio; do not multiply prior rounds' gains. Preserve every adverse pair. Hardware counters use 32 observations per variant; heap counters use 8 measured complete invocations per Mech variant. Each full allocation census is fresh and separately reconciled to its corresponding heap cohort. CPU-time sample weights are not retired instructions. Their elapsed values are not primary elapsed.

Unchanged workload: complete eight-byte `abcdefgh`, exact raw bytes `[75,76,74,78,73,77,75,207,0,0]`, independent inflate, output capacity 13 with clear/reuse, input aliases, 262,144-entry U16 tree, 1,500,513-word U32 cache, depth 300, nice 258, pinned source/bytecode/allocator and original timing/allocation sites. Logical work 60,260,219,686 and comparison work 47,612 are not hardware counters. Final managed bytes/nodes must be zero. No full-scale timing or larger-input performance claim.

`allocation_analysis.py` compares actual request/byte/reallocation totals and complete size/kind histograms. Any unexpected allocation delta needs explanation; equal totals do not imply identical work. `analyze.py` independently rebuilds all primary summaries from raw journals, verifies all 64 block medians, confirms actual image/source/dependency pins and records contrary hardware and OS-memory directions. Post-call RSS/physical footprint is not peak RSS. Local Engine test builds use the retained broader feature configuration; do not claim a minimal profile or completed remote CI. The existing complete-knucleotide runtime exclusion is retained and reported.
