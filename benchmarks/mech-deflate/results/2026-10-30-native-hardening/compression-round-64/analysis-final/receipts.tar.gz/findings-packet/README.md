# Missed central native-projection meter checks

This is a source-and-retained-profile audit, not a measured optimization. No build, test, or compressor was executed by this audit.

## Bounded candidate

`production.patch` changes only `ResidentBudgetMeter::preview_compute_and_nodes` and `ResidentBudgetMeter::charge` in `src/engine/src/resident/budget.rs` (R62 source lines 3001 and 3177). Both currently request the full diagnostic collection, then consume only emptiness or its first item. Use the existing Core `first_call_memory_budget_violation`, retaining current demand, limits, owner, arguments, and check order.

Completed R23 commit `299c70f4c` introduced the maintained first-only API and applied it in selected native sinks. It did not modify central `budget.rs`. This candidate extends that already-proved API to two current, observed callers; it does not introduce another budget evaluator. Leave the other full-evaluator calls in this file alone for this experiment.

## Executed evidence

R62 sample source: `/private/tmp/mech-pointer-locality-round62-20261031/isolated-profile/after.sample.txt`; SHA-256 `7e3d3eddd1d3af0c2514026fa3b659d1bceae92e175f8e980f27955770e22a5c`.

`profile-budget-paths.py` reconstructs the call tree, subtracts children, and retains full ancestry for every selected sample in `profile-budget-paths.json`. The total is 1,320 exclusive sample weights. The full Core evaluator has 19 exclusive weights, all below frame actions:

| Immediate sampled parent | Exclusive weights |
| --- | ---: |
| `ResidentBudgetMeter::charge_retained_nodes` | 6 |
| `ResidentBudgetMeter::charge_compute_work` | 5 |
| `ResidentBudgetMeter::preview_compute_and_nodes` | 6 |
| `measure_native_scalar_frame_footprint` (inlined meter charge) | 1 |
| `ResidentBudgetMeter::try_charge_borrowed_footprint` (inlined charge) | 1 |

The 19 weights are 1.439% of this sampled CPU cohort, not a predicted speedup, an exact call count, or retired instructions. These are distinct from the already-first-only `NativeProjectionIndexContext::check`. The sampled frames show both implementations coexist in the current worker. No stale binary explanation is needed.

On successful admission the full evaluator's empty Vec does not allocate. Expect an instruction/call-boundary reduction rather than promising any success-census allocation delta. On failure it currently constructs all diagnostics although only the first is observable. Do not use removal of failure-only allocations to explain primary successful timing.

## Preserved semantics

The Core first-only function delegates to the same ordered violation visitor. The visitor order is the full evaluator's sort order because owner is the same for every violation. It returns exactly the same first dimension/required/limit, and `resource_budget_error` discards neither information nor precedence.

Preview still performs checked compute/node addition, declines worker scopes, validates current scope identity, previews current enclosing work, then checks call limits. It never spends work or changes the observer high-water mark. Any failure remains an ordinary fast-path miss.

Charge still builds a local next estimate, performs overflow checks, authenticates current scope, and calls `observe_control_work` before call-policy validation. Thus a policy rejection keeps its already-spent enclosing prefix while leaving the meter estimate unchanged; an enclosing-budget rejection precedes the policy rejection and is atomic. `self.accumulated = next` remains after every check. No publication, allocation permit, alias permission, frame representation, or serialized authority changes.

## Existing qualification to reuse, not newly executed here

Core `src/core/src/memory_plan/budget.rs` already contains two tests:

- `first_call_rejection_preserves_all_limit_subsets_and_diagnostic_order`: full evaluator and first-only result compared against independently enumerated expected dimensions for all 2,048 subsets of eleven limits.
- `first_call_rejection_keeps_equality_unset_and_full_width_limits`: unset limits, equality at full width, and simultaneous comparison/compute rejection ordering.

Engine `resident::budget::native_projection_meter_tests` currently contains ten tests. Relevant ones include:

- `native_projection_meter_requires_its_live_work_scope` (escaped/foreign meter rejection, no spend).
- `native_projection_meter_debits_the_existing_ledger_and_tighter_call_caps` (nested/current/root funding).
- `native_projection_meter_checks_current_node_and_byte_limits` (current limits and malformed authority).
- `native_projection_whole_metadata_preview_uses_its_scope_without_spending` (success/rejection/compute overflow, unchanged meter and work, admitted and denied scans).
- `denied_native_projection_preflight_keeps_spent_comparisons_on_retry`.
- `native_schema_precharge_matches_ordered_visitor_at_every_denial_boundary` (policy, account, call caps and full-width overflow).
- `native_schema_precharge_keeps_shared_workers_incremental`.

Run the entire existing ten-test module, the two Core tests, and native library scope/funding tests under the maintained native-artifact feature profile. Confirm executed test counts; the test inventory may change as root continues work. Existing source presence is not a fresh passing receipt.

## Focused additional regression plan

Add two tests to `native_projection_meter_tests.rs` to cover these exact call sites:

1. With enclosing compute cap 100, call-policy compute cap 2 and nodes cap 3, stage compute 5/nodes 4 in one meter charge. Assert exact RetainedNodes rejection (4 > 3) ahead of ComputeWork (5 > 2), unchanged meter, enclosing spent work 5. Retry with compute 2/nodes 3 and verify success without refunding/re-spending the previous observation. Repeat with enclosing compute cap 4 and assert exact enclosing ComputeWork rejection (5 > 4) occurs before either policy error and spends zero.
2. Start with an admitted prefix and run previews that fit, exceed nodes, exceed compute, overflow compute, and overflow nodes. Assert each preview preserves meter, current account and observer; failed preview falls back to the ordinary charge whose error/paid prefix remains exact. Include node overflow with node cap u64::MAX and a one-node admitted prefix; shared worker preview must continue to decline. Existing original/decoded runtime qualification supplies artifact-level controls because no artifact or lowering changes occur.

## Acceptance

After focused tests, rebuild using the same linked profile and retain the original generated Object. The change is host-only; expect Object/descriptor/bytecode hashes and generated text/stack unchanged. Compare full-call instructions, cycles and matched elapsed independently, retain adverse cohorts, and verify complete allocation census rather than inferring any saved allocations. Preserve exact output, logical work 60,260,219,686, comparison work 47,612, original/decoded behavior, finite-prefix controls, clean publication/recovery, and final managed bytes/nodes zero.
