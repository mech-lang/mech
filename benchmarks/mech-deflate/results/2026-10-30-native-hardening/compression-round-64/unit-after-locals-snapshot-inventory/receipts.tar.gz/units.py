"""Current GPU regressions against the coherent candidate graph; no compressor timing."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-frame-shape-round63-20261031');p=r/'units-after';p.mkdir()
config=json.loads((r/'configuration.json').read_text());libs=json.loads((r/'final-libraries.json').read_text());base=json.loads((old/'units-after/build.json').read_text());dep=r/'variants/after/dependency'
cmd=base['command'].copy();cmd[-1]=str(p/'gpu-unit-tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  name,path=a.split('=',1);target=Path(libs[name]['path']) if name in libs else dep/Path(path).name;assert target.exists(),target;cmd[i]=name+'='+str(target)
for i in range(len(cmd)-1,0,-1):
 if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
cmd[1:1]=['-L','dependency='+str(dep),'-L','dependency='+str(r/'variants/after')]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();scope=json.loads((r/'source-scope.json').read_text())
assert hashlib.sha256(subprocess.check_output(['git','diff',scope['baseline_checkpoint'],'--','src','hosts/gpu/src'],cwd=w)).hexdigest()==scope['complete_source_diff_sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
def run(label,command,expected=None):
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':base['environment'],'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':source,'libraries':libs,'scope':'Current source and coherent rebuilt Engine-dependent graph; exact retained opt1 warnings-as-errors test flags. No timing observations in this cohort.'}
 if label.endswith('inventory'):row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M))
 match=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)
 if match:row.update(executed_tests=int(match[1])+int(match[2]),passed_tests=int(match[1]),failed_tests=int(match[2]))
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'unit-after-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'units.py')],cwd=w,check=True)
 print(label,q.returncode,row.get('listed_tests',row.get('executed_tests')),flush=True)
 if q.returncode:print(q.stdout[-3500:]+q.stderr[-5000:],flush=True)
 q.check_returncode()
 if expected is not None:assert row.get('listed_tests',row.get('executed_tests'))==expected,(label,row)
run('build',cmd)
filters=[('vector-address','native_artifact::program::codegen::numeric_words::tests::unit_dimension_addresses_emit_no_division_and_keep_general_geometry'),('first-change','delayed_numeric_first_changes_preserve_current_scalars_two_arrays_and_retry'),('locals-snapshot','entry_locals_snapshot_survives_callback_pointer_change_and_fresh_invocations')]
filters += [('new-'+str(i),name) for i,name in enumerate(config['extra_gpu_test_filters'])]
for label,selection in filters:
 exact=['--exact'] if label=='vector-address' else []
 run(label+'-inventory',[str(p/'gpu-unit-tests'),selection,*exact,'--list'],1)
 run(label,[str(p/'gpu-unit-tests'),selection,*exact,'--nocapture','--test-threads=1'],1)
run('runtime-inventory',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--list'],config['gpu_runtime_expected'])
