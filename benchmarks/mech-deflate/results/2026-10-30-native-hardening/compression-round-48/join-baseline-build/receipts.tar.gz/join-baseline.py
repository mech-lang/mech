from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'join-baseline';p.mkdir();b=json.loads((r/'units-after/build.json').read_text());cmd=b['command'].copy();libs=json.loads((r/'variants/before/libraries.json').read_text());dep=r/'variants/before/dependency'
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=a.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
  elif key.startswith('mech_'):
   path=dep/Path(a.split('=',1)[1]).name;assert path.exists();cmd[i]=key+'='+str(path)
 if a=='dependency='+str(r/'variants/after/dependency'):cmd[i]='dependency='+str(dep)
cmd[1:1]=['-L','dependency='+str(dep)];cmd[-1]=str(p/'gpu-unit-tests')
def run(label,command):
 t=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-t,'scope':'Focused old fixture against frozen matching pre-optimization Core-dependent graph, same test cfg/flags. Establish inherited versus deliberately changed failure-point behavior.'};(p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'join-baseline-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'join-baseline.py')],cwd=w,check=True)
 if q.returncode:print(q.stdout[-3000:]+q.stderr[-5000:],flush=True)
 q.check_returncode();print('BASELINE',label,q.returncode,flush=True)
run('build',cmd)
run('focused',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::invocation::joins::tests::actual_selected_join_global_exact_one_short_and_import_failures_keep_atomic_outputs','--exact','--nocapture','--test-threads=1'])
