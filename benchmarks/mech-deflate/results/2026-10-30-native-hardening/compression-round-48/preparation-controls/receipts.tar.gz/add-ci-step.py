from pathlib import Path
import subprocess
w=Path('/private/tmp/mech-deflate-linear-stack');p=w/'.github/workflows/ci-full.yml';s=p.read_text();needle='      - name: Execute retained unsigned buffer ownership and allocation regressions\n';assert s.count(needle)==1
step='''      - name: Execute exclusive snapshot first-admission regressions
        run: |
          ADMISSION_TESTS=$(cargo +nightly-2026-03-03 test --locked -p mech-core \\
            --all-features --lib -- snapshot::validation::unique_admission_tests:: --list)
          test "$(printf '%s\\n' "$ADMISSION_TESTS" | awk '/^snapshot::validation::unique_admission_tests::.*: test$/ { count += 1 } END { print count + 0 }')" -eq 6
          cargo +nightly-2026-03-03 test --locked -p mech-core --all-features --lib -- \\
            snapshot::validation::unique_admission_tests:: --test-threads=1
'''
p.write_text(s.replace(needle,step+needle));subprocess.run(['git','diff','--check'],cwd=w,check=True);subprocess.run(['git','add','.github/workflows/ci-full.yml'],cwd=w,check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Schedule six guarded first-admission ownership regressions'],cwd=w,check=True)
