from pathlib import Path
import hashlib,shutil,subprocess
w=Path('/private/tmp/mech-deflate-linear-stack');r=Path(__file__).resolve().parent;prior=Path('/private/tmp/mech-unique-root-round47-20261031')
# The complete baseline graph must already be frozen before source mutation.
import json
b=json.loads((r/'variants/before/host.json').read_text());assert b['exit']==0
p=w/'src/core/src/snapshot/validation.rs';s=(prior/'candidate-validation.rs').read_text();needle='#[cfg(test)]\n#[path = "frozen_identity_tests.rs"]';assert s.count(needle)==1
s=s.replace(needle,'#[cfg(test)]\n#[path = "unique_admission_tests.rs"]\nmod unique_admission_tests;\n\n'+needle);assert 'admission_census' not in s;p.write_text(s)
shutil.copy2(prior/'unique_admission_tests.rs',w/'src/core/src/snapshot/unique_admission_tests.rs')
p=w/'src/core/src/memory_runtime/budget.rs';s=p.read_text();old='''    /// Zero fails the next allocation; one lets the registration allocation
    /// succeed and rejects the subsequent owning-wrapper allocation.''';new='''    /// Zero fails the next allocation. One lets registration succeed and
    /// rejects a replacement wrapper when one is needed. Exclusive unadmitted
    /// roots reuse their wrapper and leave that next failure armed.''';assert s.count(old)==1;p.write_text(s.replace(old,new))
q=subprocess.run(['git','diff','--check'],cwd=w);q.check_returncode()
subprocess.run(['git','add','src/core/src/snapshot/validation.rs','src/core/src/snapshot/unique_admission_tests.rs','src/core/src/memory_runtime/budget.rs'],cwd=w,check=True)
subprocess.run(['git','-c','gc.auto=0','commit','-m','Reuse exclusive unadmitted snapshot roots after fallible preparation'],cwd=w,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();(r/'implementation.json').write_text(json.dumps({'head':head,'baseline_source':b['source_head'],'scope':'Only unique unadmitted root reuse, conservative original admission and synchronized data registry; no diagnostic counters.'},indent=2)+'\n')
print('IMPLEMENTATION',head,flush=True)
