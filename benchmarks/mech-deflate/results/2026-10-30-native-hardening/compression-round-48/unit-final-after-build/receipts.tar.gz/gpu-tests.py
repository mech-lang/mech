from pathlib import Path
import json,subprocess,os,time,re
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'units-after';p.mkdir(exist_ok=True)
libs=json.loads((r/'final-libraries.json').read_text());b=json.loads(Path('/private/tmp/mech-frame-pack-move-round43-20261031/units-after/build.json').read_text());cmd=b['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=a.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
  if key=='mech_compute':cmd[i]=key+'='+str(r/'variants/after/dependency/libmech_compute-84cb0ef1d137eee3.rlib')
cmd[1:1]=['-L','dependency='+str(r/'variants/after/dependency')]
cmd[-3:-3]=['-L','dependency='+str(r/'variants/after/dependency'),'-L','dependency='+str(Path(libs['mech_engine']['path']).parent)];cmd[-1]=str(p/'gpu-unit-tests')
def run(label,command,count=None):
 t=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-t,'compiler_source':json.loads((r/'final-release.json').read_text())['source_head']}
 if count is not None:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,q.returncode,row.get('executed_tests'),flush=True)
 subprocess.run(['python3',str(r/'archive.py'),'unit-final-after-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'gpu-tests.py')],cwd=w,check=True)
 if q.returncode:print(q.stdout[-2500:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if count is not None:assert row['executed_tests']==count
run('build',cmd)
run('runtime',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--nocapture','--test-threads=1'],316)
run('work-values',[str(p/'gpu-unit-tests'),'native_artifact::work::','native_artifact::memory::','native_artifact::values::','--nocapture','--test-threads=1'],31)
