from pathlib import Path
import json,os,shlex,subprocess,time,sys
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];p=r/('core-'+phase);p.mkdir()
old=Path('/private/tmp/mech-unique-root-round47-20261031')
line=next(x for x in (old/'final-release.stderr').read_text().splitlines() if '--crate-name mech_core ' in x and 'Running' in x)
cmd=shlex.split(line.strip().removeprefix('Running `').removesuffix('`'))
filtered=[];i=0
while i<len(cmd):
 a=cmd[i]
 if a in ['--error-format=json','--json=diagnostic-rendered-ansi,artifacts,future-incompat','--emit=dep-info,metadata,link']:i+=1;continue
 if a in ['--crate-type','--out-dir']:i+=2;continue
 if a=='-C' and cmd[i+1].startswith(('metadata=','extra-filename=','opt-level=')):i+=2;continue
 if i and cmd[i-1]=='--extern' and a.endswith('.rmeta'):a=a[:-6]+'.rlib'
 filtered.append(a);i+=1
cmd=filtered+['--test','-C','opt-level=1','-o',str(p/'core-unit-tests')]
env={'CARGO_MANIFEST_DIR':str(w/'src/core'),'CARGO_PKG_NAME':'mech-core','CARGO_PKG_VERSION':'0.3.5','CARGO_PKG_VERSION_MAJOR':'0','CARGO_PKG_VERSION_MINOR':'3','CARGO_PKG_VERSION_PATCH':'5'}
t=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('build.'+stream)).write_text(getattr(q,stream))
(p/'build.json').write_text(json.dumps({'command':cmd,'environment':env,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'exit':q.returncode,'seconds':time.monotonic()-t,'scope':'Core tests with exact selected-consumer features and pinned nightly; opt1 test binary, warnings-as-errors. Excluded from primary timing.'},indent=2)+'\n')
print('CORE TEST BUILD',phase,q.returncode,time.monotonic()-t,flush=True)
if q.returncode:print(q.stderr[-8000:],flush=True)
subprocess.run(['python3',str(r/'archive.py'),'core-'+phase+'-build',str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(r/'core-tests.py')],cwd=w,check=True)
q.check_returncode()
cmd=[str(p/'core-unit-tests'),'unique_admission_tests::','--nocapture','--test-threads=1'];q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('regression.'+stream)).write_text(getattr(q,stream))
(p/'regression.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'phase':phase},indent=2)+'\n');print(q.stdout[-4500:]+q.stderr[-5000:],flush=True)
subprocess.run(['python3',str(r/'archive.py'),'core-'+phase+'-regression',str(p/'regression.json'),str(p/'regression.stdout'),str(p/'regression.stderr')],cwd=w,check=True)
if phase=='before':
 assert q.returncode!=0 and '3 passed; 3 failed;' in q.stdout
else:q.check_returncode();assert '6 passed; 0 failed;' in q.stdout
