from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'core-qualification';p.mkdir(exist_ok=True)
base=json.loads((r/'core-after/build.json').read_text());results=[]
rows=[json.loads(x) for x in (r/'variants/after/cargo.log').read_text().splitlines() if x.startswith('{')]
row=next(x for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']=='mech_core')
original=Path(next(x for x in row['filenames'] if x.endswith('.rlib')));frozen=p/original.name;shutil.copy2(original,frozen)
libs={'mech_core':{'path':str(frozen),'sha256':hashlib.sha256(frozen.read_bytes()).hexdigest(),'features':row['features'],'profile':row['profile']}}
(p/'core-pin.json').write_text(json.dumps(libs,indent=2)+'\n')

def run(label,command):
 t=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':base['environment'],'exit':q.returncode,'seconds':time.monotonic()-t,'compiler_source':base['source_head'],'features':'Exact selected-consumer Core feature cfgs, opt1 test executable, warnings-as-errors; integration tests link the exact candidate release Core.'}
 match=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout)
 if match:row['executed_tests']=int(match[1]);assert row['executed_tests']>0
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');results.append(row)
 subprocess.run(['python3',str(r/'archive.py'),'core-qualification-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'core-qualify.py')],cwd=w,check=True)
 print(label,q.returncode,row.get('executed_tests'),flush=True)
 if q.returncode:print(q.stdout[-4000:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
assert json.loads((p/'all-library.json').read_text())['executed_tests']==359
results.append(json.loads((p/'all-library.json').read_text()))
for name in ['memory_runtime','unsigned_buffer_capacity','snapshot_canonical_vectors','snapshot_serde_contract']:
 cmd=base['command'].copy();cmd[cmd.index('--crate-name')+1]=name
 i=cmd.index(str(w/'src/core/src/lib.rs'));cmd[i]=str(w/'src/core/tests'/(name+'.rs'));cmd[-1]=str(p/name)
 cmd[1:1]=['-L','dependency='+str(r/'variants/after/dependency'),'--extern','mech_core='+libs['mech_core']['path']]
 run(name+'-build',cmd);run(name,[str(p/name),'--nocapture','--test-threads=1']);(p/name).unlink()
(p/'summary.json').write_text(json.dumps({'results':results,'distinct_tests':sum(x.get('executed_tests',0) for x in results)},indent=2)+'\n')
