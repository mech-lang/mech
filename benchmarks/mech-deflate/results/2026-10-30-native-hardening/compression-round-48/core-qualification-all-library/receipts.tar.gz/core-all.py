from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'core-qualification';p.mkdir(exist_ok=True);b=json.loads((r/'core-after/build.json').read_text());cmd=[str(r/'core-after/core-unit-tests'),'--nocapture','--test-threads=1'];t=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('all-library.'+stream)).write_text(getattr(q,stream))
m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row={'command':cmd,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-t,'compiler_source':b['source_head'],'executed_tests':int(m[1]) if m else None,'scope':'Entire maintained Core unit root, exact selected-consumer features and WAE. Includes focused witnesses once in this full root. Excluded from timing.'};(p/'all-library.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
subprocess.run(['python3',str(r/'archive.py'),'core-qualification-all-library',str(p/'all-library.json'),str(p/'all-library.stdout'),str(p/'all-library.stderr'),str(r/'core-all.py')],cwd=w,check=True)
if q.returncode:print(q.stdout[-7000:]+q.stderr[-7000:],flush=True)
q.check_returncode();assert row['executed_tests']==359
