from pathlib import Path
import hashlib,itertools,json,math,os,select,statistics,subprocess,time
r=Path(__file__).resolve().parent;root=r/'confirmation-primary';w=Path('/private/tmp/mech-deflate-linear-stack')
root.mkdir();(root/'before').symlink_to(r/'linked-primary/before',target_is_directory=True);(root/'after').symlink_to(r/'linked-primary/after',target_is_directory=True)
labels=['before','after'];expected={label:json.loads((root/label/'binding.json').read_text())['expected_work'] for label in labels}
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [x for x in active if Path(x.strip()).name in {'rustc','cargo','tests','gpu-unit-tests','worker','roc-profile','native_frame_transport'}]
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc')
assert digest(artifact)=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
for label in labels:
 p=root/label;b=json.loads((p/'binding.json').read_text());assert digest(p/'worker')==b['worker_sha256']
 for name,pin in b['pins'].items():assert digest(p/name)==pin['sha256']
reference=Path('/private/tmp/mech-deflate-profiling-20261028/roc-profile');assert digest(reference)=='3941ef59b2c9343d0493cc6b6d14ca4803e6bd27acfe520b1fb59d9b63026324'
cmd=[str(reference),'12']
with (root/'reference.stdout').open('w') as out,(root/'reference.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
q.check_returncode();rows=[line.split('\t') for line in (root/'reference.stdout').read_text().splitlines() if line.startswith('rep\troc-deflate\t')];assert len(rows)==20000;ref=statistics.median(int(row[3]) for row in rows)/1e9
(root/'reference.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'observations':20000,'median_seconds':ref,'binary_sha256':digest(reference)},indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'confirmation-primary-reference',str(root/'reference.json'),str(root/'reference.stdout'),str(root/'reference.stderr'),str(r/'confirm-primary.py')],cwd=w,check=True)
print('REFERENCE',ref,flush=True)
permutations=list(itertools.permutations(labels));groups=[]
for group in range(4):
 p=root/f'group{group}';p.mkdir();workers={};observed={label:[] for label in labels};blocks=[]
 receipt={'group':group,'configuration':'Matched linked compressor; identical tiny setup JIT helpers; unchanged evaluate_into timer. Both programs ready before measurements.','source_revisions':{label:json.loads((root/label/'binding.json').read_text())['compiler_source'] for label in labels},'reference_seconds':ref,'preparation_order':list(permutations[group%len(permutations)]),'blocks':blocks,'all_observations':observed,'independent_units':'Four prepared executable pairs; blocks within a pair are descriptive, not independent repetitions.'}
 def read_line(process):
  while not select.select([process.stdout],[],[],50)[0]:
   assert process.poll() is None,'executable exited while awaiting observation'
   print('LIVE_EXECUTABLE_WAIT',process.pid,flush=True)
  line=process.stdout.readline();assert line,'executable ended before required observation';return line
 def request(label):
  worker=workers[label];process=worker['process'];process.stdin.write('N');process.stdin.flush();line=read_line(process);worker['journal'].write(line);worker['journal'].flush();row=json.loads(line)
  assert row['exact_reference'] and row['independent_inflation'] and row['input_bytes']==8 and row['raw_bytes']==10 and row['capacity']==13 and row['work']==expected[label]
  observed[label].append(row);return row
 failure=None
 try:
  for label in receipt['preparation_order']:
   stderr=(p/(label+'.stderr')).open('w');journal=(p/(label+'.stdout')).open('w');cmd=[str(root/label/'worker'),str(artifact),'992'];process=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1,env={**os.environ,'MECH_BENCH_SESSION':'1'});workers[label]={'process':process,'stderr':stderr,'journal':journal,'command':cmd};print('PREPARING',group,label,process.pid,flush=True);line=read_line(process);journal.write(line);journal.flush();assert line=='SESSION_READY\n'
  for label in receipt['preparation_order']:assert request(label)['warmup']
  for block in range(32):
   order=permutations[(block+group)%len(permutations)];values={}
   for label in order:
    rows=[request(label) for _ in range(31)];assert all(not row['warmup'] and not row['profile'] for row in rows);values[label]=statistics.median(row['seconds'] for row in rows)
   blocks.append({'block':block,'order':list(order),'medians':values,'after_over_before':values['after']/values['before']})
   (p/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
  for label in reversed(receipt['preparation_order']):assert request(label)['profile']
  for label,worker in workers.items():
   worker['process'].stdin.close();assert worker['process'].wait()==0;worker['stderr'].close();worker['journal'].close();assert (p/(label+'.stderr')).read_text().endswith('CLEANUP bytes=0 nodes=0\n')
 except BaseException as error:
  failure=repr(error);receipt['failure']=failure
 finally:
  for worker in workers.values():
   if worker['process'].poll() is None:worker['process'].terminate();worker['process'].wait()
   for key in ['stderr','journal']:
    if not worker[key].closed:worker[key].close()
  (p/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
  subprocess.run(['python3',str(r/'archive.py'),'confirmation-primary-group'+str(group),str(p),str(r/'confirm-primary.py')],cwd=w,check=True)
 if failure:raise RuntimeError(failure)
 summary={'group':group,'medians':{label:statistics.median(row['seconds'] for row in observed[label] if not row['warmup'] and not row['profile']) for label in labels}}
 summary['after_over_before']=summary['medians']['after']/summary['medians']['before'];groups.append(summary);print('GROUP',json.dumps(summary),flush=True)
summary={'configuration':receipt['configuration'],'reference_seconds':ref,'fixed_reference_seconds':.000300,'groups':groups,'primary_observations':7936,'all_observations':7952,'observations_per_variant':3968,'medians':{},'comparisons':{}}
all_rows={label:[] for label in labels};all_blocks=[]
for group in range(4):
 data=json.loads((root/f'group{group}/results.json').read_text());all_blocks+=data['blocks']
 for label in labels:all_rows[label]+=[row for row in data['all_observations'][label] if not row['warmup'] and not row['profile']]
for label in labels:
 rows=all_rows[label];assert len(rows)==3968;median=statistics.median(row['seconds'] for row in rows);summary['medians'][label]={'seconds':median,'multiple_of_reference':median/ref,'multiple_of_fixed_reference':median/.000300}
for numerator,denominator in [('after','before')]:
 key=numerator+'_over_'+denominator;ratios=[block[key] for block in all_blocks];summary['comparisons'][key]={'pooled_ratio':summary['medians'][numerator]['seconds']/summary['medians'][denominator]['seconds'],'improving_groups':sum(group[key]<1 for group in groups),'improving_blocks':sum(ratio<1 for ratio in ratios),'median_block_ratio':statistics.median(ratios),'geometric_block_ratio':math.exp(statistics.mean(math.log(ratio) for ratio in ratios))}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');subprocess.run(['python3',str(r/'archive.py'),'confirmation-primary-summary',str(root/'summary.json'),str(r/'confirm-primary.py')],cwd=w,check=True);print('SUMMARY',json.dumps(summary),flush=True)
