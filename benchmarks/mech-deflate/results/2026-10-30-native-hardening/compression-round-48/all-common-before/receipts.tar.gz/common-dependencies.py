from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];p=r/'variants'/phase
rows=[json.loads(x) for x in (p/'cargo.log').read_text().splitlines() if x.startswith('{')];common={}
cutoff=(r/'linked-primary/before/worker').stat().st_mtime_ns
for row in rows:
 if row.get('reason')!='compiler-artifact' or row['target']['name'].startswith('mech_') or row['target']['kind']==['bin']:continue
 assert row['fresh'],('unrelated dependency rebuilt',row['package_id'])
 key=json.dumps([row['package_id'],row['target']['name'],row['target']['kind'],row['features'],row['profile']],sort_keys=True)
 assert key not in common,key
 artifacts={}
 for name in row['filenames']:
  f=Path(name);assert f.stat().st_mtime_ns<=cutoff,('dependency newer than linked baseline',f)
  artifacts[str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
 common[key]=artifacts
result={'scope':'Every non-application third-party artifact, keyed by package identity, target, features and profile; no duplicate crate-name collapse. Both Cargo logs must show these artifacts Fresh and every file predates baseline linking. Baseline supplemental census captured while only changed Mech crates rebuild; actual file hashes must match after build.','artifacts':common}
(p/'all-common.json').write_text(json.dumps(result,indent=2)+'\n')
if phase=='after':assert result==json.loads((r/'variants/before/all-common.json').read_text()),'unrelated dependency graph changed'
subprocess.run(['python3',str(r/'archive.py'),'all-common-'+phase,str(p/'all-common.json'),str(r/'common-dependencies.py')],cwd=w,check=True)
print('ALL COMMON DEPENDENCIES',phase,len(common),'configurations',sum(len(x) for x in common.values()),'artifacts',flush=True)
