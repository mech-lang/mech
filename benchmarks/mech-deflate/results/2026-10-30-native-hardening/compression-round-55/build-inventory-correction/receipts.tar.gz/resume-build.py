from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase='after';p=r/'variants/after';old=Path('/private/tmp/mech-allocation-sites-round54-20261031');previous=json.loads((old/'final-libraries.json').read_text());head=json.loads((p/'cargo.json').read_text())['source_head']
assert json.loads((p/'cargo.json').read_text())['exit']==0
source=(r/'build-matched.py').read_text();code=source[source.index('sha=lambda f:'):]
exec(compile(code,str(r/'build-matched.py')+' [completed Cargo continuation]','exec'))
subprocess.run(['python3',str(r/'archive.py'),'common-configurations',str(r/'verify-common.py'),str(r/'resume-build.py'),str(p/'common-all.json'),str(p/'common-comparison.json')],cwd=w,check=True)
