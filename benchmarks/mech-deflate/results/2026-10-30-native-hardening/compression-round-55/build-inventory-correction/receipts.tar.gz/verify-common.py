from pathlib import Path
import collections,hashlib,json
r=Path(__file__).resolve().parent
old=Path('/private/tmp/mech-allocation-sites-round54-20261031/variants/after/cargo.log')
def artifacts(path):
 rows=[json.loads(x) for x in path.read_text().splitlines() if x.startswith('{')]
 return [x for x in rows if x.get('reason')=='compiler-artifact' and not x['target']['name'].startswith('mech_') and x['target']['kind']!=['bin']]
def signature(row):
 return {'name':row['target']['name'],'package':row['package_id'],'kind':row['target']['kind'],'features':row['features'],'profile':row['profile'],'filenames':[Path(f).name for f in row['filenames']]}
before=artifacts(old);after=artifacts(r/'variants/after/cargo.log')
assert collections.Counter(json.dumps(signature(x),sort_keys=True) for x in before)==collections.Counter(json.dumps(signature(x),sort_keys=True) for x in after)
full=[]
for row in after:
 full.append({**signature(row),'fresh':row['fresh'],'artifacts':{Path(f).name:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in row['filenames']}})
retained=json.loads((r/'variants/before/common.json').read_text())
for name,entry in retained.items():
 assert any(x['name']==name and all(x[k]==entry[k] for k in ['features','profile','artifacts']) for x in full),name
unicode=[signature(x) for x in before if x['target']['name']=='unicode_segmentation']
assert len(unicode)==2 and all(x['fresh'] for x in after if x['target']['name']=='unicode_segmentation')
report={'status':'All common configuration signatures and every retained historical hash match.','before_configuration_count':len(before),'after_configuration_count':len(after),'retained_hashed_variants_checked':len(retained),'unicode_configurations_in_both_histories':unicode,'cause':'The old dictionary keyed only by crate name overwrote one of the host/runtime configurations. Cargo listed them in reverse order this round. No dependency configuration changed.','historical_scope':'R54 stored one last-listed hash set per crate name. All 138 retained sets match current exact configurations, including optimized runtime unicode-segmentation. The second build-host configuration has identical package/features/profile/filenames in both raw Cargo histories and is reported fresh; a separate pre-build historical hash for that omitted variant was not recorded. R55 now preserves every variant hash.'}
(r/'variants/after/common-all.json').write_text(json.dumps(full,indent=2)+'\n');(r/'variants/after/common-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
