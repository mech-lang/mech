from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for name,args in [('units.py',['after']),('qualify-all.py',[]),('core-integrations.py',[]),('numeric-ci.py',[]),('comparison-witness.py',[])]:
 print('START',name,flush=True)
 subprocess.run(['python3',str(r/name),*args],check=True)
 print('DONE',name,flush=True)
