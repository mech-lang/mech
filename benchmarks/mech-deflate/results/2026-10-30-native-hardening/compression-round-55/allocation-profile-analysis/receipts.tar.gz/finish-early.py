from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for name,args in [('allocation-regression.py',['after']),('linked-build.py',['after']),('run-primary.py',[]),('counters.py',[]),('sites-after.py',[]),('profile-isolated.py',[]),('profile-reference.py',[])]:
 print('START',name,flush=True)
 subprocess.run(['python3',str(r/name),*args],check=True)
 print('DONE',name,flush=True)
