from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'core-qualification';p.mkdir();base=json.loads((r/'core-after/build.json').read_text());libs=json.loads((r/'final-libraries.json').read_text());results=[]
for name in ['memory_runtime','unsigned_buffer_capacity','snapshot_canonical_vectors','snapshot_serde_contract']:
 cmd=base['command'].copy();cmd[cmd.index('--crate-name')+1]=name;cmd[cmd.index(str(w/'src/core/src/lib.rs'))]=str(w/'src/core/tests'/(name+'.rs'));cmd[-1]=str(p/name)
 cmd[1:1]=['-L','dependency='+str(r/'variants/after/dependency'),'--extern','mech_core='+libs['mech_core']['path']]
 for label,args in [(name+'-build',cmd),(name,[str(p/name),'--nocapture','--test-threads=1'])]:
  at=time.monotonic();q=subprocess.run(args,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
  match=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row={'command':args,'environment':base['environment'],'compiler_source':json.loads((r/'final-release.json').read_text())['source_head'],'core':libs['mech_core'],'exit':q.returncode,'seconds':time.monotonic()-at,'executed_tests':int(match[1]) if match else None};results.append(row);(p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  subprocess.run(['python3',str(r/'archive.py'),'core-qualification-'+label,*map(str,[p/(label+'.json'),p/(label+'.stdout'),p/(label+'.stderr'),r/'core-integrations.py'])],cwd=w,check=True)
  print(label,q.returncode,row['executed_tests'],flush=True)
  if q.returncode:print(q.stdout[-4000:]+q.stderr[-6000:],flush=True)
  q.check_returncode()
 (p/name).unlink()
assert sum(x.get('executed_tests') or 0 for x in results)==54
(p/'summary.json').write_text(json.dumps({'results':results,'distinct_tests':54},indent=2)+'\n')
