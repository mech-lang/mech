from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];p=r/('allocation-'+phase);p.mkdir()
base=json.loads(Path('/private/tmp/mech-unique-admission-round48-20261031/core-qualification/unsigned_buffer_capacity-build.json').read_text());libs=json.loads(Path('/private/tmp/mech-allocation-sites-round54-20261031/final-libraries.json').read_text()) if phase=='before' else json.loads((r/'final-libraries.json').read_text())
cmd=base['command'].copy()
for i,a in enumerate(cmd):
 if a=='unsigned_buffer_capacity':cmd[i]='composite_constructor_allocation'
 if a.endswith('/unsigned_buffer_capacity.rs'):cmd[i]=str(w/'src/core/tests/composite_constructor_allocation.rs')
 if a.startswith('mech_core='):cmd[i]='mech_core='+libs['mech_core']['path']
cmd[1:1]=['-L','dependency='+str(Path(libs['mech_core']['path']).parent)];cmd[-1]=str(p/'tests');cmd[cmd.index('opt-level=1')]='opt-level=3'
for name,args in [('build',cmd),('run',[str(p/'tests'),'--nocapture','--test-threads=1'])]:
 at=time.monotonic();q=subprocess.run(args,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 (p/(name+'.json')).write_text(json.dumps({'command':args,'environment':base['environment'],'exit':q.returncode,'seconds':time.monotonic()-at,'core_library':libs['mech_core'],'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'allocation-'+phase+'-'+name,*map(str,[p/(name+'.json'),p/(name+'.stdout'),p/(name+'.stderr'),r/'allocation-regression.py',w/'src/core/tests/composite_constructor_allocation.rs'])],cwd=w,check=True) if False else None
 # Repository source is copied under the private experiment root for the lossless receipt archive.
 (r/'allocation-test.rs').write_text((w/'src/core/tests/composite_constructor_allocation.rs').read_text())
 subprocess.run(['python3',str(r/'archive.py'),'allocation-'+phase+'-'+name,*map(str,[p/(name+'.json'),p/(name+'.stdout'),p/(name+'.stderr'),r/'allocation-regression.py',r/'allocation-test.rs'])],cwd=w,check=True)
 print(phase,name,q.returncode,q.stdout[-1600:]+q.stderr[-2000:],flush=True)
 if name=='build' or phase=='after':q.check_returncode()
 else:assert q.returncode!=0 and '2 passed; 1 failed;' in q.stdout and 'left: 2' in q.stderr and 'right: 1' in q.stderr
