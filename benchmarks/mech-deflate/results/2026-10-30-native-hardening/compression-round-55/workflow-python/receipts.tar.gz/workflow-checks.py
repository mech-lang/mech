from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'ci';p.mkdir(exist_ok=True)
cmd=['/private/tmp/mech-profile-ci-python-20261030/bin/python','-B','-m','unittest','tests.ci.test_ci_full_contract','tests.ci.test_ci_test_inventory'];t=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('workflow-python.'+stream)).write_text(getattr(q,stream))
m=re.search(r'Ran (\d+) tests',q.stderr);row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t,'executed_tests':int(m[1]) if m else None};(p/'workflow-python.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
subprocess.run(['python3',str(r/'archive.py'),'workflow-python',str(p/'workflow-python.json'),str(p/'workflow-python.stdout'),str(p/'workflow-python.stderr'),str(r/'workflow-checks.py')],cwd=w,check=True)
if q.returncode:print(q.stdout[-3000:]+q.stderr[-4000:],flush=True)
q.check_returncode();assert row['executed_tests']==132
