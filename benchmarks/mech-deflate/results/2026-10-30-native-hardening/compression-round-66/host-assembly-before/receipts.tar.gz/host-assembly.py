"""Bounded disassembly of actual linked host functions, after measurement clearance."""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;p=r/'host-assembly';p.mkdir()
for label in ['before','after']:
 worker=r/'linked-primary'/label/'worker';binding=json.loads((worker.parent/'binding.json').read_text());assert hashlib.sha256(worker.read_bytes()).hexdigest()==binding['worker_sha256']
 cmd=[sys.executable,str(r/'findings-packet/audit-private-numeric.py'),str(worker),str(p/label)];q=subprocess.run(cmd,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 (p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'compiler_source':binding['compiler_source'],'worker_sha256':binding['worker_sha256'],'scope':'Post-cohort actual linked host disassembly. Static instruction counts are not executed counts.'},indent=2)+'\n')
 subprocess.run([sys.executable,str(r/'archive.py'),'host-assembly-'+label,str(p),str(r/'host-assembly.py'),str(r/'findings-packet/audit-private-numeric.py')],check=True);q.check_returncode()
subprocess.run([sys.executable,str(r/'host_analysis.py'),str(r),str(r/'host-assembly-comparison.json')],check=True)
subprocess.run([sys.executable,str(r/'archive.py'),'host-assembly-summary',str(r/'host-assembly-comparison.json'),str(r/'host_analysis.py')],check=True)
