
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e1e65c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix20into_private_appends>:
102e1e65c:     	sub	sp, sp, #0x70
102e1e660:     	stp	x29, x30, [sp, #0x60]
102e1e664:     	add	x29, sp, #0x60
102e1e668:     	mov	x7, x3
102e1e66c:     	mov	x3, x2
102e1e670:     	mov	x2, x1
102e1e674:     	ldp	q0, q1, [x0]
102e1e678:     	stp	q0, q1, [sp]
102e1e67c:     	ldr	x5, [x0, #0x20]
102e1e680:     	ldur	q0, [x0, #0x28]
102e1e684:     	ldur	q1, [x0, #0x38]
102e1e688:     	stp	q0, q1, [sp, #0x20]
102e1e68c:     	ldr	w9, [x0, #0x68]
102e1e690:     	ldur	q0, [x0, #0x48]
102e1e694:     	ldur	q1, [x0, #0x58]
102e1e698:     	stp	q0, q1, [x29, #-0x20]
102e1e69c:     	sub	x1, x29, #0x20
102e1e6a0:     	mov	x4, sp
102e1e6a4:     	add	x6, sp, #0x20
102e1e6a8:     	mov	x0, x9
102e1e6ac:     	bl	0x102d66c4c <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix15prepare_appends>
102e1e6b0:     	ldp	x29, x30, [sp, #0x60]
102e1e6b4:     	add	sp, sp, #0x70
102e1e6b8:     	ret
