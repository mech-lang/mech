
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e1e6bc <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix20into_private_updates>:
102e1e6bc:     	sub	sp, sp, #0x50
102e1e6c0:     	stp	x29, x30, [sp, #0x40]
102e1e6c4:     	add	x29, sp, #0x40
102e1e6c8:     	ldp	q0, q1, [x0]
102e1e6cc:     	stp	q0, q1, [sp]
102e1e6d0:     	ldr	x4, [x0, #0x20]
102e1e6d4:     	ldur	q0, [x0, #0x28]
102e1e6d8:     	ldur	q1, [x0, #0x38]
102e1e6dc:     	stp	q0, q1, [sp, #0x20]
102e1e6e0:     	ldr	w0, [x0, #0x68]
102e1e6e4:     	mov	x3, sp
102e1e6e8:     	add	x5, sp, #0x20
102e1e6ec:     	bl	0x102d62474 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare>
102e1e6f0:     	ldp	x29, x30, [sp, #0x40]
102e1e6f4:     	add	sp, sp, #0x50
102e1e6f8:     	ret
