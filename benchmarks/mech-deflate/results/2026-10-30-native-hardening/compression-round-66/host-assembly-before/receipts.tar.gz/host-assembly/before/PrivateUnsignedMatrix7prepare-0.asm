
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d62474 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare>:
102d62474:     	sub	sp, sp, #0x1f0
102d62478:     	stp	x28, x27, [sp, #0x190]
102d6247c:     	stp	x26, x25, [sp, #0x1a0]
102d62480:     	stp	x24, x23, [sp, #0x1b0]
102d62484:     	stp	x22, x21, [sp, #0x1c0]
102d62488:     	stp	x20, x19, [sp, #0x1d0]
102d6248c:     	stp	x29, x30, [sp, #0x1e0]
102d62490:     	add	x29, sp, #0x1e0
102d62494:     	mov	x21, x8
102d62498:     	str	x4, [sp, #0x8]
102d6249c:     	mov	w8, #0x1                ; =1
102d624a0:     	ldadd	x8, x8, [x4]
102d624a4:     	tbnz	x8, #0x3f, 0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d624a8:     	mov	x20, x5
102d624ac:     	mov	x19, x4
102d624b0:     	add	x24, sp, #0x50
102d624b4:     	ldr	x8, [x3]
102d624b8:     	ldur	q0, [x3, #0x8]
102d624bc:     	stur	q0, [x24, #0xc8]
102d624c0:     	ldr	x9, [x3, #0x18]
102d624c4:     	lsl	x10, x8, #4
102d624c8:     	mov	x11, #0x8               ; =8
102d624cc:     	movk	x11, #0x10, lsl #16
102d624d0:     	movk	x11, #0x20, lsl #32
102d624d4:     	movk	x11, #0x40, lsl #48
102d624d8:     	lsr	x10, x11, x10
102d624dc:     	stur	x9, [x29, #-0xb8]
102d624e0:     	stur	x8, [x29, #-0xd0]
102d624e4:     	sturh	w10, [x29, #-0xae]
102d624e8:     	mov	w8, #0x2                ; =2
102d624ec:     	sturb	w8, [x29, #-0xb0]
102d624f0:     	add	x8, sp, #0xa0
102d624f4:     	sub	x3, x29, #0xb0
102d624f8:     	sub	x4, x29, #0xd0
102d624fc:     	mov	x5, x19
102d62500:     	bl	0x102d4565c <__RNvNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix19from_numeric_matrix>
102d62504:     	ldrb	w8, [sp, #0xa0]
102d62508:     	cmp	w8, #0x16
102d6250c:     	b.ne	0x102d62588 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x114>
102d62510:     	ldur	q0, [x24, #0x78]
102d62514:     	stur	q0, [sp, #0x77]
102d62518:     	ldur	q1, [x24, #0x88]
102d6251c:     	ldur	q2, [x24, #0x68]
102d62520:     	ldur	q3, [x24, #0x58]
102d62524:     	stp	q3, q2, [sp, #0x10]
102d62528:     	stp	q0, q1, [sp, #0x30]
102d6252c:     	ldr	x23, [x20]
102d62530:     	mov	w8, #0x1                ; =1
102d62534:     	ldadd	x8, x8, [x23]
102d62538:     	tbnz	x8, #0x3f, 0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d6253c:     	ldp	x28, x25, [x20, #0x8]
102d62540:     	stp	x23, x28, [x29, #-0xb0]
102d62544:     	stur	x25, [x29, #-0xa0]
102d62548:     	add	x0, sp, #0xa0
102d6254c:     	add	x1, sp, #0x10
102d62550:     	bl	0x102d69e64 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value31memory_budget_ownership_witness>
102d62554:     	ldr	w8, [sp, #0xa0]
102d62558:     	cmp	w8, #0x1a
102d6255c:     	b.ne	0x102d625d0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x15c>
102d62560:     	ldp	x22, x26, [sp, #0xa8]
102d62564:     	ldr	x8, [sp, #0x18]
102d62568:     	ldr	x8, [x8, #0x10]
102d6256c:     	ldapur	x9, [x8, #0x50]
102d62570:     	cbz	x9, 0x102d625fc <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x188>
102d62574:     	mov	x8, #0x0                ; =0
102d62578:     	sub	x8, x22, x8
102d6257c:     	cmn	x8, #0x69
102d62580:     	b.ls	0x102d6265c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x1e8>
102d62584:     	b	0x102d626a8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x234>
102d62588:     	ldr	x9, [sp, #0xe0]
102d6258c:     	stur	x9, [x24, #0x3f]
102d62590:     	ldur	q0, [x24, #0x81]
102d62594:     	ldur	q1, [x24, #0x61]
102d62598:     	ldur	q2, [x24, #0x71]
102d6259c:     	stp	q2, q0, [sp, #0x70]
102d625a0:     	ldur	q0, [x24, #0x51]
102d625a4:     	stp	q0, q1, [sp, #0x50]
102d625a8:     	stur	q1, [x21, #0x19]
102d625ac:     	stur	q2, [x21, #0x29]
102d625b0:     	ldr	q1, [sp, #0x80]
102d625b4:     	stur	q1, [x21, #0x39]
102d625b8:     	ldur	x9, [x24, #0x3f]
102d625bc:     	str	x9, [x21, #0x48]
102d625c0:     	stur	q0, [x21, #0x9]
102d625c4:     	strb	w8, [x21, #0x8]
102d625c8:     	str	xzr, [x21]
102d625cc:     	b	0x102d628a8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x434>
102d625d0:     	ldr	w9, [sp, #0xa4]
102d625d4:     	ldur	q0, [x24, #0x68]
102d625d8:     	stur	q0, [x21, #0x28]
102d625dc:     	ldr	x10, [sp, #0xc8]
102d625e0:     	str	x10, [x21, #0x38]
102d625e4:     	ldur	q0, [x24, #0x58]
102d625e8:     	mov	w10, #0x1               ; =1
102d625ec:     	strb	w10, [x21, #0x8]
102d625f0:     	stp	w8, w9, [x21, #0x10]
102d625f4:     	stur	q0, [x21, #0x18]
102d625f8:     	b	0x102d62880 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x40c>
102d625fc:     	str	x22, [sp]
102d62600:     	ldr	x22, [x8, #0x58]
102d62604:     	ldr	x27, [x22, #0x20]
102d62608:     	cbz	x27, 0x102d62648 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x1d4>
102d6260c:     	mov	w8, #0x1                ; =1
102d62610:     	ldadd	x8, x8, [x27]
102d62614:     	tbnz	x8, #0x3f, 0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d62618:     	str	x27, [sp, #0x50]
102d6261c:     	ldur	q0, [x22, #0x28]
102d62620:     	stur	q0, [sp, #0x58]
102d62624:     	mov	x8, #-0x1               ; =-1
102d62628:     	ldaddl	x8, x8, [x27]
102d6262c:     	cmp	x8, #0x1
102d62630:     	b.ne	0x102d62640 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x1cc>
102d62634:     	dmb	ishld
102d62638:     	add	x0, sp, #0x50
102d6263c:     	bl	0x102d6f1fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102d62640:     	cmp	x27, x23
102d62644:     	b.eq	0x102d6268c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x218>
102d62648:     	mov	x8, #0x0                ; =0
102d6264c:     	ldr	x22, [sp]
102d62650:     	sub	x8, x22, x8
102d62654:     	cmn	x8, #0x69
102d62658:     	b.hi	0x102d626a8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x234>
102d6265c:     	add	x27, x8, #0x68
102d62660:     	ldr	x8, [x20, #0x18]
102d62664:     	cmp	x27, x8
102d62668:     	b.ls	0x102d626cc <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x258>
102d6266c:     	mov	w9, #0x1                ; =1
102d62670:     	strb	w9, [x21, #0x8]
102d62674:     	mov	w9, #0xa                ; =10
102d62678:     	str	w9, [x21, #0x10]
102d6267c:     	stp	x27, x8, [x21, #0x18]
102d62680:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
102d62684:     	str	x8, [x21, #0x28]
102d62688:     	b	0x102d62880 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x40c>
102d6268c:     	ldr	x8, [x22, #0x38]
102d62690:     	ldr	x22, [sp]
102d62694:     	cmp	x8, x22
102d62698:     	csel	x8, x8, x22, lo
102d6269c:     	sub	x8, x22, x8
102d626a0:     	cmn	x8, #0x69
102d626a4:     	b.ls	0x102d6265c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x1e8>
102d626a8:     	add	x0, sp, #0xa0
102d626ac:     	bl	0x102d5d6ec <__RNCNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB7_5Value45unshared_memory_budget_admission_for_requireds_0Bb_>
102d626b0:     	ldr	w8, [sp, #0xa0]
102d626b4:     	cmp	w8, #0x1a
102d626b8:     	b.ne	0x102d62a6c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x5f8>
102d626bc:     	ldr	x27, [sp, #0xa8]
102d626c0:     	ldr	x8, [x20, #0x18]
102d626c4:     	cmp	x27, x8
102d626c8:     	b.hi	0x102d6266c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x1f8>
102d626cc:     	ldapur	x8, [x23, #0x30]
102d626d0:     	cbz	x8, 0x102d626f8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x284>
102d626d4:     	sub	x10, x8, #0x1
102d626d8:     	add	x11, x23, #0x30
102d626dc:     	mov	x9, x8
102d626e0:     	casal	x9, x10, [x11]
102d626e4:     	cmp	x9, x8
102d626e8:     	mov	x8, x9
102d626ec:     	b.ne	0x102d626d0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x25c>
102d626f0:     	cmp	x9, #0x1
102d626f4:     	b.eq	0x102d6285c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x3e8>
102d626f8:     	mov	w8, #0x1                ; =1
102d626fc:     	ldadd	x8, x8, [x23]
102d62700:     	tbnz	x8, #0x3f, 0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d62704:     	stp	x23, x28, [sp, #0x50]
102d62708:     	str	x25, [sp, #0x60]
102d6270c:     	b	0x102d62714 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x2a0>
102d62710:     	isb
102d62714:     	ldr	x8, [x19, #0x8]
102d62718:     	cmn	x8, #0x1
102d6271c:     	b.eq	0x102d62710 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x29c>
102d62720:     	tbnz	x8, #0x3f, 0x102d62a3c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x5c8>
102d62724:     	add	x9, x8, #0x1
102d62728:     	add	x10, x19, #0x8
102d6272c:     	mov	x11, x8
102d62730:     	casa	x11, x9, [x10]
102d62734:     	cmp	x11, x8
102d62738:     	mov	x8, x11
102d6273c:     	b.ne	0x102d62718 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x2a4>
102d62740:     	str	x22, [sp]
102d62744:     	ldr	x8, [sp, #0x10]
102d62748:     	mov	w9, #0x1                ; =1
102d6274c:     	ldadd	x9, x8, [x8]
102d62750:     	tbnz	x8, #0x3f, 0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d62754:     	ldr	x8, [sp, #0x10]
102d62758:     	ldr	q0, [sp, #0x50]
102d6275c:     	mov	w9, #0x1                ; =1
102d62760:     	dup.2d	v1, x9
102d62764:     	ldr	x9, [sp, #0x60]
102d62768:     	stp	q1, q0, [x24, #0x50]
102d6276c:     	stp	x9, x19, [sp, #0xc0]
102d62770:     	mov	w9, #0x3                ; =3
102d62774:     	stp	x8, x9, [sp, #0xd0]
102d62778:     	str	xzr, [sp, #0xe8]
102d6277c:     	strb	wzr, [sp, #0xf0]
102d62780:     	mov	x8, #-0x1               ; =-1
102d62784:     	stp	x8, xzr, [sp, #0xf8]
102d62788:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d6278c:     	mov	w0, #0x68               ; =104
102d62790:     	mov	w1, #0x8                ; =8
102d62794:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d62798:     	cbz	x0, 0x102d62850 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x3dc>
102d6279c:     	ldp	q0, q1, [x24, #0x90]
102d627a0:     	stp	q0, q1, [x0, #0x40]
102d627a4:     	ldr	x8, [sp, #0x100]
102d627a8:     	str	x8, [x0, #0x60]
102d627ac:     	ldp	q0, q1, [x24, #0x50]
102d627b0:     	stp	q0, q1, [x0]
102d627b4:     	ldp	q1, q0, [x24, #0x70]
102d627b8:     	stp	q1, q0, [x0, #0x20]
102d627bc:     	str	x0, [sp, #0x98]
102d627c0:     	ldapur	x8, [x23, #0x28]
102d627c4:     	add	x22, x8, x26
102d627c8:     	cmp	x22, x8
102d627cc:     	ccmp	x22, x25, #0x2, hs
102d627d0:     	b.hi	0x102d6292c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x4b8>
102d627d4:     	add	x9, x23, #0x28
102d627d8:     	mov	x10, x8
102d627dc:     	casal	x10, x22, [x9]
102d627e0:     	cmp	x10, x8
102d627e4:     	mov	x8, x10
102d627e8:     	b.ne	0x102d627c4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x350>
102d627ec:     	add	x8, x23, #0x20
102d627f0:     	ldaddal	x26, x8, [x8]
102d627f4:     	mov	w8, #0x1                ; =1
102d627f8:     	ldadd	x8, x8, [x23]
102d627fc:     	tbnz	x8, #0x3f, 0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d62800:     	stp	x23, x28, [sp, #0xa0]
102d62804:     	stp	x25, x26, [sp, #0xb0]
102d62808:     	ldr	x8, [x20, #0x18]
102d6280c:     	subs	x9, x8, x27
102d62810:     	ldr	x10, [sp]
102d62814:     	b.hs	0x102d629d0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x55c>
102d62818:     	mov	x24, x0
102d6281c:     	stp	x8, x27, [x21, #0x18]
102d62820:     	adrp	x8, 0x107707000 <_anon.668a5934515266f09af5f72be082a6fd.583+0x61c>
102d62824:     	add	x8, x8, #0xbdb
102d62828:     	mov	w9, #0x23               ; =35
102d6282c:     	stp	x8, x9, [x21, #0x28]
102d62830:     	mov	w8, #0x1                ; =1
102d62834:     	strb	w8, [x21, #0x8]
102d62838:     	mov	w8, #0x19               ; =25
102d6283c:     	str	w8, [x21, #0x10]
102d62840:     	str	xzr, [x21]
102d62844:     	add	x0, sp, #0xa0
102d62848:     	bl	0x102d5a27c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget18SnapshotNodeChargeEBM_>
102d6284c:     	b	0x102d629b0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x53c>
102d62850:     	add	x8, sp, #0xa0
102d62854:     	add	x0, x8, #0x10
102d62858:     	bl	0x102d5aa94 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation26SnapshotBudgetRegistrationEBM_>
102d6285c:     	mov	w8, #0x1                ; =1
102d62860:     	strb	w8, [x21, #0x8]
102d62864:     	adrp	x8, 0x10754d000 <_anon.4e4cf234dac9fe76f818f23bf1907424.537+0xb6a>
102d62868:     	ldr	d0, [x8, #0xc10]
102d6286c:     	str	d0, [x21, #0x10]
102d62870:     	mov	w8, #0x68               ; =104
102d62874:     	str	x8, [x21, #0x18]
102d62878:     	str	wzr, [x21, #0x20]
102d6287c:     	str	wzr, [x21, #0x28]
102d62880:     	str	xzr, [x21]
102d62884:     	mov	x8, #-0x1               ; =-1
102d62888:     	ldaddl	x8, x8, [x23]
102d6288c:     	cmp	x8, #0x1
102d62890:     	b.ne	0x102d628a0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x42c>
102d62894:     	dmb	ishld
102d62898:     	sub	x0, x29, #0xb0
102d6289c:     	bl	0x102d6f1fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102d628a0:     	add	x0, sp, #0x10
102d628a4:     	bl	0x102d5ac60 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEBM_>
102d628a8:     	ldr	x8, [x20, #0x18]
102d628ac:     	ldr	x9, [x20]
102d628b0:     	ldapur	x10, [x9, #0x18]
102d628b4:     	add	x9, x9, #0x18
102d628b8:     	subs	x11, x10, x8
102d628bc:     	b.lo	0x102d62a90 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x61c>
102d628c0:     	mov	x12, x10
102d628c4:     	casal	x12, x11, [x9]
102d628c8:     	cmp	x12, x10
102d628cc:     	mov	x10, x12
102d628d0:     	b.ne	0x102d628b8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x444>
102d628d4:     	ldr	x8, [x20]
102d628d8:     	mov	x21, #-0x1              ; =-1
102d628dc:     	ldaddl	x21, x8, [x8]
102d628e0:     	cmp	x8, #0x1
102d628e4:     	b.ne	0x102d628f4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x480>
102d628e8:     	dmb	ishld
102d628ec:     	mov	x0, x20
102d628f0:     	bl	0x102d6f1fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102d628f4:     	ldaddl	x21, x8, [x19]
102d628f8:     	cmp	x8, #0x1
102d628fc:     	b.ne	0x102d6290c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x498>
102d62900:     	dmb	ishld
102d62904:     	add	x0, sp, #0x8
102d62908:     	bl	0x102d6f448 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core6schema5table11SchemaTableE9drop_slowBM_>
102d6290c:     	ldp	x29, x30, [sp, #0x1e0]
102d62910:     	ldp	x20, x19, [sp, #0x1d0]
102d62914:     	ldp	x22, x21, [sp, #0x1c0]
102d62918:     	ldp	x24, x23, [sp, #0x1b0]
102d6291c:     	ldp	x26, x25, [sp, #0x1a0]
102d62920:     	ldp	x28, x27, [sp, #0x190]
102d62924:     	add	sp, sp, #0x1f0
102d62928:     	ret
102d6292c:     	mov	x24, x0
102d62930:     	cmp	x22, x8
102d62934:     	b.lo	0x102d62aac <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x638>
102d62938:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d6293c:     	mov	w0, #0x17               ; =23
102d62940:     	mov	w1, #0x1                ; =1
102d62944:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d62948:     	cbz	x0, 0x102d62ac8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x654>
102d6294c:     	adrp	x8, 0x107707000 <_anon.668a5934515266f09af5f72be082a6fd.583+0x61c>
102d62950:     	add	x8, x8, #0x934
102d62954:     	ldr	q0, [x8]
102d62958:     	str	q0, [x0]
102d6295c:     	ldur	x8, [x8, #0xf]
102d62960:     	mov	w10, #0x17              ; =23
102d62964:     	mov	w9, #0xa                ; =10
102d62968:     	stur	x8, [x0, #0xf]
102d6296c:     	str	x10, [sp, #0x50]
102d62970:     	sub	x11, x29, #0x68
102d62974:     	sub	x12, x29, #0xd0
102d62978:     	mov	x8, x22
102d6297c:     	mov	x26, x25
102d62980:     	str	x0, [x12]
102d62984:     	str	x10, [x11]
102d62988:     	ldr	x10, [sp, #0x50]
102d6298c:     	ldur	x11, [x29, #-0xd0]
102d62990:     	ldur	x12, [x29, #-0x68]
102d62994:     	stp	x8, x26, [x21, #0x18]
102d62998:     	stp	x10, x11, [x21, #0x28]
102d6299c:     	mov	w8, #0x1                ; =1
102d629a0:     	strb	w8, [x21, #0x8]
102d629a4:     	str	w9, [x21, #0x10]
102d629a8:     	str	x12, [x21, #0x38]
102d629ac:     	str	xzr, [x21]
102d629b0:     	mov	x8, #-0x1               ; =-1
102d629b4:     	ldaddl	x8, x8, [x24]
102d629b8:     	cmp	x8, #0x1
102d629bc:     	b.ne	0x102d62884 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x410>
102d629c0:     	dmb	ishld
102d629c4:     	add	x0, sp, #0x98
102d629c8:     	bl	0x102d6f69c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation26SnapshotBudgetRegistrationE9drop_slowBM_>
102d629cc:     	b	0x102d62884 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x410>
102d629d0:     	str	x9, [x20, #0x18]
102d629d4:     	ldr	x8, [x20]
102d629d8:     	mov	w9, #0x1                ; =1
102d629dc:     	ldadd	x9, x9, [x8]
102d629e0:     	tbnz	x9, #0x3f, 0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d629e4:     	stp	x19, x8, [x21, #0x48]
102d629e8:     	ldur	q0, [x20, #0x8]
102d629ec:     	stur	q0, [x21, #0x58]
102d629f0:     	str	x27, [x21, #0x68]
102d629f4:     	ldp	q0, q1, [sp, #0x10]
102d629f8:     	stp	q0, q1, [x21]
102d629fc:     	ldp	q0, q1, [sp, #0x30]
102d62a00:     	stp	q0, q1, [x21, #0x20]
102d62a04:     	ldp	q0, q1, [x24, #0x50]
102d62a08:     	stp	q0, q1, [x21, #0x70]
102d62a0c:     	str	x0, [x21, #0x40]
102d62a10:     	stp	x10, xzr, [x21, #0x90]
102d62a14:     	mov	x8, #-0x1               ; =-1
102d62a18:     	ldaddl	x8, x8, [x23]
102d62a1c:     	cmp	x8, #0x1
102d62a20:     	b.ne	0x102d62a30 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x5bc>
102d62a24:     	dmb	ishld
102d62a28:     	sub	x0, x29, #0xb0
102d62a2c:     	bl	0x102d6f1fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102d62a30:     	mov	x0, x20
102d62a34:     	bl	0x102d5a3c4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationEBM_>
102d62a38:     	b	0x102d6290c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x498>
102d62a3c:     	adrp	x8, 0x10805f000 <_anon.42fa521c9e1d7f1ebfe40a7ebc6293fd.62+0x70>
102d62a40:     	add	x8, x8, #0xd58
102d62a44:     	adrp	x9, 0x102da8000 <__RNvNtNtCskIfnrfrMWVM_9mech_core8function8contract32validate_canonical_concatenation+0x35c>
102d62a48:     	add	x9, x9, #0x1ac
102d62a4c:     	stp	x8, x9, [sp, #0xa0]
102d62a50:     	adrp	x0, 0x107716000 <_anon.1310333d1a51811720a63c7d65208aad.13+0x252>
102d62a54:     	add	x0, x0, #0xdfd
102d62a58:     	adrp	x2, 0x10805f000 <_anon.42fa521c9e1d7f1ebfe40a7ebc6293fd.62+0x70>
102d62a5c:     	add	x2, x2, #0xd68
102d62a60:     	add	x1, sp, #0xa0
102d62a64:     	bl	0x103a00ec4 <__RNvNtCsgDHHaSskbIF_4core9panicking9panic_fmt>
102d62a68:     	b	0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d62a6c:     	ldr	w9, [sp, #0xa4]
102d62a70:     	ldr	x10, [sp, #0xa8]
102d62a74:     	ldp	q0, q1, [x24, #0x60]
102d62a78:     	stp	q0, q1, [x21, #0x20]
102d62a7c:     	mov	w11, #0x1               ; =1
102d62a80:     	strb	w11, [x21, #0x8]
102d62a84:     	stp	w8, w9, [x21, #0x10]
102d62a88:     	str	x10, [x21, #0x18]
102d62a8c:     	b	0x102d62880 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x40c>
102d62a90:     	adrp	x0, 0x107707000 <_anon.668a5934515266f09af5f72be082a6fd.583+0x61c>
102d62a94:     	add	x0, x0, #0xc32
102d62a98:     	adrp	x2, 0x108064000 <_anon.a15e41cf4d33068c24abe94d1cbff12e.5>
102d62a9c:     	add	x2, x2, #0x488
102d62aa0:     	mov	w1, #0x45               ; =69
102d62aa4:     	bl	0x103a00ec4 <__RNvNtCsgDHHaSskbIF_4core9panicking9panic_fmt>
102d62aa8:     	b	0x102d62ad4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x660>
102d62aac:     	mov	w9, #0x19               ; =25
102d62ab0:     	sub	x11, x29, #0xd0
102d62ab4:     	add	x12, sp, #0x50
102d62ab8:     	mov	w10, #0x1d              ; =29
102d62abc:     	adrp	x0, 0x107707000 <_anon.668a5934515266f09af5f72be082a6fd.583+0x61c>
102d62ac0:     	add	x0, x0, #0xafe
102d62ac4:     	b	0x102d62980 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x50c>
102d62ac8:     	mov	w0, #0x1                ; =1
102d62acc:     	mov	w1, #0x17               ; =23
102d62ad0:     	bl	0x103a00b04 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d62ad4:     	brk	#0x1
102d62ad8:     	mov	x21, x0
102d62adc:     	mov	x8, #-0x1               ; =-1
102d62ae0:     	ldaddl	x8, x8, [x24]
102d62ae4:     	cmp	x8, #0x1
102d62ae8:     	b.ne	0x102d62b58 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x6e4>
102d62aec:     	dmb	ishld
102d62af0:     	add	x0, sp, #0x98
102d62af4:     	bl	0x102d6f69c <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation26SnapshotBudgetRegistrationE9drop_slowBM_>
102d62af8:     	b	0x102d62b58 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x6e4>
102d62afc:     	mov	x21, x0
102d62b00:     	b	0x102d62b58 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x6e4>
102d62b04:     	mov	x21, x0
102d62b08:     	b	0x102d62b7c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x708>
102d62b0c:     	mov	x21, x0
102d62b10:     	ldr	x8, [x20]
102d62b14:     	mov	x9, #-0x1               ; =-1
102d62b18:     	ldaddl	x9, x8, [x8]
102d62b1c:     	cmp	x8, #0x1
102d62b20:     	b.ne	0x102d62b84 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x710>
102d62b24:     	dmb	ishld
102d62b28:     	mov	x0, x20
102d62b2c:     	bl	0x102d6f1fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102d62b30:     	b	0x102d62b84 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x710>
102d62b34:     	mov	x21, x0
102d62b38:     	ldr	x8, [sp, #0x50]
102d62b3c:     	mov	x9, #-0x1               ; =-1
102d62b40:     	ldaddl	x9, x8, [x8]
102d62b44:     	cmp	x8, #0x1
102d62b48:     	b.ne	0x102d62b58 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x6e4>
102d62b4c:     	dmb	ishld
102d62b50:     	add	x0, sp, #0x50
102d62b54:     	bl	0x102d6f1fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102d62b58:     	mov	x8, #-0x1               ; =-1
102d62b5c:     	ldaddl	x8, x8, [x23]
102d62b60:     	cmp	x8, #0x1
102d62b64:     	b.ne	0x102d62b74 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x700>
102d62b68:     	dmb	ishld
102d62b6c:     	sub	x0, x29, #0xb0
102d62b70:     	bl	0x102d6f1fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102d62b74:     	add	x0, sp, #0x10
102d62b78:     	bl	0x102d5ac60 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEBM_>
102d62b7c:     	mov	x0, x20
102d62b80:     	bl	0x102d5a3c4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationEBM_>
102d62b84:     	mov	x8, #-0x1               ; =-1
102d62b88:     	ldaddl	x8, x8, [x19]
102d62b8c:     	cmp	x8, #0x1
102d62b90:     	b.ne	0x102d62ba0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix7prepare+0x72c>
102d62b94:     	dmb	ishld
102d62b98:     	add	x0, sp, #0x8
102d62b9c:     	bl	0x102d6f448 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core6schema5table11SchemaTableE9drop_slowBM_>
102d62ba0:     	mov	x0, x21
102d62ba4:     	bl	0x103a02120 <dyld_stub_binder+0x103a02120>
102d62ba8:     	bl	0x103a00d3c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
