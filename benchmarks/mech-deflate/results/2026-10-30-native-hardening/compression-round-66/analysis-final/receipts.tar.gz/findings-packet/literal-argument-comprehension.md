# Corrected optional-witness diagnosis

The first optional large witness combined an inline array comprehension with
U16 addition. It failed before evaluation at NodeId(2). An initial suspicion
about the initializer was wrong: replacing the comprehension with an admitted
input array still failed at NodeId(1), on both the parent and candidate.

The native scalar vocabulary includes U32Add but no U16Add. The attached
unsupported-u16-addition.mec isolates the remaining failing program. Changing
only that U16 update to widen to U64, add, and check the cast back makes both
compilers pass all real-size controls. This is the arithmetic already used by
the pinned compressor's rebase-node function (source lines 76–78).

No isolated failure of an inline initializer is claimed. The initial source,
wrong provisional diagnosis and failures are retained as historical evidence;
this correction supersedes that diagnosis. No compiler expansion is made for
an operation the pinned program does not require. A future direct-U16-arithmetic
extension needs its own maintained semantic witness, original/decoded checked
overflow and error-order tests, and native/resident agreement.

The real-size private-update controls use admitted U16/U32 input arrays with
retained aliases, which remain all-zero after every changed result. Separate
source with-capacity/append controls retain U64 path and U8 output behavior.
Their existing NoLimits configuration is recorded separately from the unchanged
finite scalar and component controls. This changes no compressor source.
