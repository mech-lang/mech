# R66: one private numeric owner through first change and publication

Accepted parent: `8e549d40300d1bfcc8f9a2845987f6979a573c34`.
Parent measured compiler: `78209b2aab2175f1fad92ee4daae3d6b38669d36`.
Production change: `60c96f56e11e557a4807976c42f7ab674942aefa`.
Actual current release build source: `739c8b3bf4a11dcfaa87800e6cb171390afc2ff1`.
The later code changes are test fixtures and the strict CI count update, not
changes to the measured compiler. Git diff verifies the complete `src` and
`hosts/gpu/src` trees still match that release source.

The selected checked replacement/append shares its validation, copy/consume,
work and capacity path with the ordinary canonical result. At its output
boundary, a fresh unsigned value can be confined directly to its private phase.
Its final publication owner and registration remain admitted throughout. No
canonical result escapes just to be consumed and reconstructed. Existing
snapshots, aliases, weak identities, imports and physical tickets cannot use the
fresh-owner entry. Runtime post-leaf metadata charges and append preparation
remain ordered as before; finish allocates nothing. Work policy is unchanged.

The design and materialization inventory are in
`docs/design/native-private-numeric-lifetime.md`. The full current census
reconciles exactly: 1,008 requests / 80,640 requested bytes disappear. That
includes 168 each of six sizes: 8, 32, 64, 104, 112 and 160 bytes. Every other
size/kind family is unchanged. Counts measure actual construction removal,
not pooling thousands of unchanged objects.

## Reproduction and serial execution

All raw commands, environments, flags, source revisions, library hashes,
stdout, stderr, actual test counts and failed attempts are in the ordered
receipt archives. `reconstruct.py /new/empty/path` verifies every archived
version, then recreates numerical outputs without compiler execution, a
compressor run, binaries or external scratch paths.

Full execution used the following sequence, in the private round directory:

1. `initialize-baseline.py 8e549d40300d1bfcc8f9a2845987f6979a573c34`
   followed by `freeze-source.py`.
2. `core-focused.py`: actual current Core build and all 367 tests.
3. `build-changed.py`: Core, Syntax, Bytecode, Engine, Compute, selected Math,
   Range, Logic, Compare, Stdlib, Runtime and GPU, serially. The retained opt3
   profiles, features, toolchain and warnings-as-errors are unchanged. Only the
   selected five math operations are built; no full-catalog feature expansion.
   Every external artifact is frozen by hash; no old Core-dependent artifact is
   mixed into the candidate graph.
4. `engine-focused.py parent`: fresh execution of the exact retained parent
   test executable, with explicit historical compilation provenance. Then
   `engine-focused.py after`: fresh current build and execution. Projection 12
   and shape 6 execute on both; focused policy/overflow subsets overlap them.
5. `units.py`: fresh opt1 maintained GPU tests, first-change/error controls and
   a nonzero 329-test runtime inventory.
6. `run-cohorts.py`: fresh linked candidate emission and smoke; four paired
   primary groups; CPU/heap counters; fresh before/after full censuses; separate
   Mech/reference CPU-time samples. No build or test overlaps those cohorts.
7. `qualify-all.py`: actual 329 runtime tests, 236 components, 8 connected,
   12 linked cases, work/memory/value 32, preparation 2, scalar controls 12 with
   unchanged 1.05 ceiling, frame controls 8, small private-lifetime controls
   12, workflow Python 132, selected GPU CI 35 and architecture checks 10.
8. `core-ci.py`: actual Bash/awk inventory guard and 14 unsigned + 7 string
   tests. The previous 11-test guard rejects the expanded suite; the separately
   committed 14-test guard passes. The full Core batch already includes them.
9. `real-final-control-build.py before`, `real-final-control-build.py after`,
   `numeric-lifetime-real-final-controls.py`: 24 original/decoded cases through
   both compiled graphs. Fixed U16 tree length 262144, U32 cache length 1500513,
   U64 path capacity 305257 and U8 output capacity 13. These additional controls
   use the existing NoLimits mode; existing finite controls are unchanged.
   Real input arrays retain aliases and remain zero after changed outputs.
   Path/output remain source with-capacity/append operations. Updates increase
   without added backing or metadata allocations within the fixed capacity.
10. `host-assembly.py`: actual linked ARM64 excerpts, after all cohorts.
    `format-final` checks the last fixture changes. Analysis and packet replay
    run only after all execution is complete.

Primary: 4 independently prepared pairs ×16 alternating blocks ×31 calls ×2
variants = 3,968 timed observations. The 20,000-call reference is fresh.
Counters have 32 observations per variant; heap cohorts have eight measured
complete invocations per Mech variant. Census requests reconcile independently
to those heap cohorts. Samples are CPU-time weights, not retired instructions.

## Bounds and retained failures

The complete eight-byte `abcdefgh` level-12 workload, source/MBC hashes, real
algorithm buffers, table/depth/nice settings, allocation sites, allocator,
output capacity 13 clear/reuse, input aliases and evaluate_into timing are
unchanged. Exact output is `[75,76,74,78,73,77,75,207,0,0]`, independently inflated.
Logical work is 60,260,219,686 and comparison work 47,612; neither is a hardware
instruction count. Final managed bytes/nodes are zero. No larger-input timing.

All setup failures and rejected optional fixtures remain in prior-failures.json
and raw archives. The initial optional U16 fixture used unsupported native U16
addition. Both compilers reject it; widening arithmetic as the actual source
does makes all real-size controls pass. The initial initializer diagnosis was
wrong and is explicitly corrected in the findings packet. No claim is made
that direct native U16 addition is fixed or required by this compressor.

Hosted CI is cancelled by user direction, not awaited or counted as passing.
The inherited reduced-catalog complete-knucleotide exclusion remains explicit.
