"""Compiled original/decoded private writes/appends; fixed capacity, varying visits."""
from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'numeric-lifetime';p.mkdir();results=[]
for kind,steps in [('private-update',[1,64,4096]),('private-append',[1,32,63])]:
 for form in ['original','decoded']:
  by_label={label:[] for label in ['before','after']}
  for n in steps:
   pair={}
   for label in ['before','after']:
    binary=r/'primary'/('frame-'+label);cmd=[str(binary),kind,form,str(n),'2','10'];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);stem=f'{kind}-{form}-{n}-{label}'
    for stream in ['stdout','stderr']:(p/(stem+'.'+stream)).write_text(getattr(q,stream))
    row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'compiler_source':json.loads((r/'primary'/('frame-'+label+'-build.json')).read_text())['source'],'scope':'Diagnostic complete compiled witness, not compressor primary timing. Fixed capacity; invocation-current steps vary without source changes. Real allocation counts include setup, final output and cleanup.'}
    (p/(stem+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    subprocess.run(['python3',str(r/'archive.py'),'numeric-lifetime-'+stem,*map(str,[p/(stem+'.'+ext) for ext in ['json','stdout','stderr']]),str(r/'numeric-lifetime-controls.py')],cwd=w,check=True)
    if q.returncode:print(q.stdout[-3500:]+q.stderr[-5000:],flush=True)
    q.check_returncode();observations=[json.loads(s) for s in q.stdout.splitlines() if s.startswith('{')];assert len(observations)==3;measured=[x for x in observations if not x['warmup']];assert len(measured)==2
    assert all(x['case']==kind and x['form']==form and x['steps']==n and x['invocations']==10 for x in observations)
    assert len({(x['allocation_requests'],x['requested_bytes']) for x in measured})==1
    pair[label]={'metadata':row,'observations':observations};by_label[label].append(measured[0])
   b=pair['before']['observations'][1];a=pair['after']['observations'][1]
   assert a['artifact_sha256']==b['artifact_sha256'];assert a['work_per_invocation']==b['work_per_invocation'];assert a['allocation_requests']<=b['allocation_requests'];assert a['requested_bytes']<=b['requested_bytes']
   results.append({'case':kind,'form':form,'steps':n,'updates_per_invocation':n+1,'variant':pair,'request_delta_per_invocation':(a['allocation_requests']-b['allocation_requests'])/10,'requested_byte_delta_per_invocation':(a['requested_bytes']-b['requested_bytes'])/10});print('PRIVATE_LIFETIME',kind,form,n,b['allocation_requests'],a['allocation_requests'],flush=True)
  for label,rows in by_label.items():
   assert len({x['artifact_sha256'] for x in rows})==1,'Visits must be current arguments to the same compiled artifact'
   assert len({(x['allocation_requests'],x['requested_bytes']) for x in rows})==1,(kind,form,label,rows)
summary={'cases':len(results),'results':results,'allocation_slope_per_private_update_zero':True,'requested_byte_slope_per_private_update_zero':True,'same_artifact_for_current_visit_arguments':True,'original_decoded':True,'scope':'Both parent and candidate already have allocation-free repeated private updates. R66 removes a constant entry conversion; this witness establishes retained no-slope behavior through the actual compiled path. Counts include all invocation work; this is not a claim that every invocation has zero allocations.'}
(p/'results.json').write_text(json.dumps(summary,indent=2)+'\n');subprocess.run(['python3',str(r/'archive.py'),'numeric-lifetime-summary',str(p/'results.json'),str(r/'numeric-lifetime-controls.py')],cwd=w,check=True)
