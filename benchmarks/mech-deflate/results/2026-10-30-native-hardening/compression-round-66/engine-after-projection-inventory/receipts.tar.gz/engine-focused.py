"""Candidate Engine tests, or fresh execution of the exact retained parent test binary."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-inline-debit-round65-20261031');phase=sys.argv[1];assert phase in ['parent','after'];p=r/('engine-'+phase);p.mkdir()
c=json.loads((r/'configuration.json').read_text());base=json.loads((old/'engine-after/build.json').read_text());libs=json.loads(((old if phase=='parent' else r)/'final-libraries.json').read_text());dep=(old if phase=='parent' else r)/'variants/after/dependency'
env=base['environment'].copy();env['CARGO_MANIFEST_DIR']=str(w/'src/engine');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
def run(label,cmd,count=None,inventory=False):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'environment':env,'exit':q.returncode,'seconds':time.monotonic()-at,'phase':phase,'test_source_head':head if phase=='after' else base.get('test_source_head',base.get('compiler_source')),'baseline_checkpoint':c['baseline_checkpoint'],'libraries':libs,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if label!='build' else None,'scope':'Fresh test execution. Parent reuses the exact pinned R65 Engine test executable, built from its recorded source; candidate is newly compiled from current Engine source and coherent Core-dependent artifacts.'}
 if count is not None:
  if inventory:row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout);row.update(executed_tests=int(m[1])+int(m[2]) if m else None,passed_tests=int(m[1]) if m else None,failed_tests=int(m[2]) if m else None);observed=row['executed_tests']
  row['expected_tests']=count
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),p.name+'-'+label,*map(str,[p/(label+'.'+e) for e in ['json','stdout','stderr']]),str(r/'engine-focused.py')],cwd=w,check=True)
 print(phase,label,q.returncode,row.get('executed_tests',row.get('listed_tests')),flush=True)
 if q.returncode:print(q.stdout[-4000:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if count is not None:assert observed==count,(label,row)
if phase=='after':
 binary=p/'engine-tests';cmd=base['command'].copy();cmd[-1]=str(binary);source=next(i for i,a in enumerate(cmd) if a.endswith('/src/engine/src/lib.rs'));cmd[source]=str(w/'src/engine/src/lib.rs')
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern':
   name,path=a.split('=',1);target=Path(libs[name]['path']) if name in libs else dep/Path(path).name;assert target.exists(),target;cmd[i]=name+'='+str(target)
 for i in range(len(cmd)-1,0,-1):
  if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
 cmd[1:1]=['-L','dependency='+str(dep)];run('build',cmd)
else:
 binary=old/'engine-after/engine-tests';assert binary.exists();d={'exit':0,'command':['verify-retained-executable',str(binary)],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'retained_build_receipt':base,'scope':'Verification of a retained test executable, not a fresh build. All selected tests below are freshly executed.'};(p/'build.json').write_text(json.dumps(d,indent=2)+'\n');(p/'build.stdout').write_text('Retained executable verified. No compilation in this stage.\n');(p/'build.stderr').write_text('')
 subprocess.run(['python3',str(r/'archive.py'),p.name+'-build',str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(r/'engine-focused.py')],cwd=w,check=True)
for label,selection,count in [('projection',c['engine_projection_filter'],12),('policy-order','native_projection_meter_keeps_policy_order_after_enclosing_funding',1),('overflow-retry','native_projection_meter_preview_and_charge_keep_compute_node_overflow_atomic',1),('shape','frame_shape::tests::',6)]:
 run(label+'-inventory',[str(binary),selection,'--list'],count,True);run(label,[str(binary),selection,'--nocapture','--test-threads=1'],count)
