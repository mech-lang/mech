from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');label=sys.argv[1];p=r/'numeric-lifetime-large';p.mkdir(exist_ok=True)
b=json.loads((r/'linked-primary'/label/'worker-build.json').read_text());cmd=b['command'].copy();object_args=[i for i,a in enumerate(cmd) if a.startswith('link-arg=') and a.endswith('/object.o')];assert len(object_args)==1;i=object_args[0];assert cmd[i-1]=='-C';del cmd[i-1:i+1]
cmd[-3]=str(w/'hosts/gpu/examples/native_frame_transport.rs');cmd[-1]=str(p/('frame-'+label));cmd[-3:-3]=['--extern','sha2=/private/tmp/mech-live-control-target/release/deps/libsha2-f9316069bed82edc.rlib']
t=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('frame-'+label+'-build.'+stream)).write_text(getattr(q,stream))
(p/('frame-'+label+'-build.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t,'libraries':b['libraries'],'source':b['compiler_source']},indent=2)+'\n')
if q.returncode:print(q.stderr[-5000:],flush=True)
q.check_returncode();(p/('frame-'+label+'.json')).write_text(json.dumps({'path':str(p/('frame-'+label)),'sha256':hashlib.sha256((p/('frame-'+label)).read_bytes()).hexdigest(),'scope':'Exact respective newly matched Core-dependent graph, same primary build flags.'},indent=2)+'\n')
(p/'witness-source.rs').write_bytes((w/'hosts/gpu/examples/native_frame_transport.rs').read_bytes())
subprocess.run(['python3',str(r/'archive.py'),'large-lifetime-control-build-'+label,*map(str,[f for f in p.iterdir() if f.is_file() and label in f.name and f.suffix in ['.json','.stdout','.stderr']]),str(r/'large-control-build.py'),str(p/'witness-source.rs')],cwd=w,check=True)
