"""Build only a current Core test executable; keep the production Core library frozen."""
from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'core-focused';p.mkdir()
c=json.loads((r/'configuration.json').read_text());assert c['initialized']
base=json.loads(Path('/private/tmp/mech-allocation-sites-round54-20261031/core-after/build.json').read_text());dep=Path(c['baseline_directory'])/'variants/after/dependency';cmd=base['command'].copy();assert cmd[-2]=='-o';source_index=next(i for i,arg in enumerate(cmd) if arg.endswith('/src/core/src/lib.rs'));cmd[source_index]=str(w/'src/core/src/lib.rs');cmd[-1]=str(p/'core-unit-tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  name,path=a.split('=',1);target=dep/Path(path).name;assert target.exists(),target;cmd[i]=name+'='+str(target)
for i in range(len(cmd)-1,0,-1):
 if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
cmd[1:1]=['-L','dependency='+str(dep)];env=base['environment'];env['CARGO_MANIFEST_DIR']=str(w/'src/core')
for label,command in [('build',cmd),('inventory',[cmd[-1],'--list']),('selected',[cmd[-1],'--nocapture','--test-threads=1'])]:
 start=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':env,'exit':q.returncode,'seconds':time.monotonic()-start,'scope':'Current Core unit source with retained warnings-as-errors flags. All actual tests run, including fresh private result confinement, original owning-transfer controls, finite budgets and retry.'}
 if label=='inventory':row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M))
 elif label=='selected':
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'core-focused-'+label,*map(str,[p/(label+'.'+ext) for ext in ['json','stdout','stderr']]),str(r/'core-focused.py')],cwd=w,check=True)
 if q.returncode:print(q.stdout[-2500:]+q.stderr[-5000:],flush=True)
 q.check_returncode()
 if label=='inventory': expected=row['listed_tests'];assert expected>0
 if label=='selected':assert row['executed_tests']==expected
