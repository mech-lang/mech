# Inherited optional-witness limitation

The attached minimal source fails native lowering at `NodeId(2)` with
`MissingSemanticWitness` on both the retained parent and current compiler.
The exact commands and stderr are retained in the initial large-witness packet.
No evaluation or timing occurs. This is an existing producer/selected-witness
limitation for an inline matrix comprehension used as a call argument, outside
the private-owner result boundary changed here.

The actual compressor initializes its tree through `initial-nodes(count)` at
lines 74–75 of the pinned source, and initializes its cache inside its existing
compression function. Its maintained pinned artifact and complete eight-byte
execution pass unchanged. The inline-argument reproducer does not block that
program, so this round does not expand into a frontend/lowering repair.

The large private-update acceptance witness instead receives already admitted
packed input arrays of the exact U16/U32 lengths, with caller aliases retained
and checked unchanged. Construction is outside its diagnostic evaluate_into
counter. Its first write must preserve the old input and produces a private
copy; subsequent writes within fixed capacity must have zero allocation slope.
The separate U64 path/U8 output witnesses retain source with-capacity/append.

Future acceptance for the producer limitation: compile this original/decoded
source through the ordinary maintained frontend and native pipeline, verify
current-step outputs and retained aliases, and preserve checked failures. No
claim that this limitation is fixed is made by the current round.
