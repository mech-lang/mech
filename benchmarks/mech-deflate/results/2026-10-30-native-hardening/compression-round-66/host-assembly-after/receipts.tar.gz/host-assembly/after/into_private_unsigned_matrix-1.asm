
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e182ec <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix>:
102e182ec:     	sub	sp, sp, #0x70
102e182f0:     	stp	x20, x19, [sp, #0x50]
102e182f4:     	stp	x29, x30, [sp, #0x60]
102e182f8:     	add	x29, sp, #0x60
102e182fc:     	mov	x19, x0
102e18300:     	mov	x20, x8
102e18304:     	ldr	x8, [x0, #0x30]
102e18308:     	cbz	x8, 0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e1830c:     	ldr	w9, [x19, #0x38]
102e18310:     	ldr	x10, [x8, #0x28]
102e18314:     	cmp	x10, x9
102e18318:     	b.ls	0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e1831c:     	ldr	x8, [x8, #0x20]
102e18320:     	add	x8, x8, x9, lsl #7
102e18324:     	ldrb	w9, [x8, #0x10]
102e18328:     	cmp	w9, #0x10
102e1832c:     	b.ne	0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e18330:     	ldr	x8, [x8, #0x18]
102e18334:     	ldrb	w9, [x8]
102e18338:     	cmp	w9, #0x2
102e1833c:     	b.ne	0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e18340:     	ldrh	w8, [x8, #0x2]
102e18344:     	sub	w9, w8, #0x1
102e18348:     	tst	w8, w9
102e1834c:     	b.ne	0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e18350:     	rbit	w8, w8
102e18354:     	clz	w8, w8
102e18358:     	sub	w8, w8, #0x3
102e1835c:     	cmp	w8, #0x3
102e18360:     	b.hi	0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e18364:     	ldr	x8, [x19, #0x8]
102e18368:     	ldr	x9, [x8, #0x18]
102e1836c:     	cbnz	x9, 0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e18370:     	add	x9, x8, #0x8
102e18374:     	mov	w10, #0x1               ; =1
102e18378:     	mov	x11, #-0x1              ; =-1
102e1837c:     	casa	x10, x11, [x9]
102e18380:     	cmp	x10, #0x1
102e18384:     	b.ne	0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e18388:     	ldapr	x9, [x8]
102e1838c:     	stlur	x10, [x8, #0x8]
102e18390:     	cmp	x9, #0x1
102e18394:     	b.ne	0x102e18460 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x174>
102e18398:     	ldr	x9, [x8, #0x10]
102e1839c:     	add	x10, x9, #0x8
102e183a0:     	mov	w11, #0x1               ; =1
102e183a4:     	mov	x12, #-0x1              ; =-1
102e183a8:     	casa	x11, x12, [x10]
102e183ac:     	cmp	x11, #0x1
102e183b0:     	b.ne	0x102e184c8 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x1dc>
102e183b4:     	ldapr	x10, [x9]
102e183b8:     	stlur	x11, [x9, #0x8]
102e183bc:     	cmp	x10, #0x1
102e183c0:     	b.ne	0x102e184c8 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x1dc>
102e183c4:     	ldr	x8, [x8, #0x10]
102e183c8:     	ldapur	x9, [x8, #0x50]
102e183cc:     	cbz	x9, 0x102e184f0 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x204>
102e183d0:     	ldrb	w9, [x8, #0x10]
102e183d4:     	cmp	w9, #0x19
102e183d8:     	b.ne	0x102e184f0 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x204>
102e183dc:     	ldr	x9, [x8, #0x18]
102e183e0:     	cmp	x9, #0x3
102e183e4:     	b.hi	0x102e184f0 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x204>
102e183e8:     	stp	x1, x8, [sp]
102e183ec:     	ldr	x0, [x8, #0x78]
102e183f0:     	bl	0x102e0ce38 <__RNvMNtNtNtNtCsgirOGyZpP7g_3std3sys4sync4once5queueNtB2_4Once5state>
102e183f4:     	and	w8, w0, #0xff
102e183f8:     	cmp	w8, #0x2
102e183fc:     	b.ne	0x102e1840c <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x120>
102e18400:     	mov	w9, #0x3                ; =3
102e18404:     	ldr	x8, [sp, #0x8]
102e18408:     	str	x9, [x8, #0x78]
102e1840c:     	ldr	x8, [sp, #0x8]
102e18410:     	ldr	x0, [x8, #0x40]
102e18414:     	bl	0x102e0ce38 <__RNvMNtNtNtNtCsgirOGyZpP7g_3std3sys4sync4once5queueNtB2_4Once5state>
102e18418:     	and	w8, w0, #0xff
102e1841c:     	cmp	w8, #0x2
102e18420:     	b.ne	0x102e18430 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x144>
102e18424:     	mov	w9, #0x3                ; =3
102e18428:     	ldr	x8, [sp, #0x8]
102e1842c:     	str	x9, [x8, #0x40]
102e18430:     	ldp	q0, q1, [x19]
102e18434:     	stp	q0, q1, [sp, #0x10]
102e18438:     	ldp	q0, q1, [x19, #0x20]
102e1843c:     	stp	q0, q1, [sp, #0x30]
102e18440:     	add	x1, sp, #0x10
102e18444:     	mov	x0, x20
102e18448:     	ldr	x2, [sp]
102e1844c:     	bl	0x102e0c1a8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit>
102e18450:     	ldp	x29, x30, [sp, #0x60]
102e18454:     	ldp	x20, x19, [sp, #0x50]
102e18458:     	add	sp, sp, #0x70
102e1845c:     	ret
102e18460:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e18464:     	mov	w0, #0x43               ; =67
102e18468:     	mov	w1, #0x1                ; =1
102e1846c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e18470:     	cbz	x0, 0x102e18510 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x224>
102e18474:     	mov	w8, #0x6e77             ; =28279
102e18478:     	movk	w8, #0x7265, lsl #16
102e1847c:     	stur	w8, [x0, #0x3f]
102e18480:     	adrp	x8, 0x107708000 <_anon.e5ab26e9f9da5eb49b5a7d29064db6f1.16+0x58c>
102e18484:     	add	x8, x8, #0xbc5
102e18488:     	ldp	q0, q1, [x8]
102e1848c:     	stp	q0, q1, [x0]
102e18490:     	ldp	q0, q1, [x8, #0x20]
102e18494:     	stp	q0, q1, [x0, #0x20]
102e18498:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x3218>
102e1849c:     	ldr	d0, [x8, #0x168]
102e184a0:     	str	d0, [x20, #0x8]
102e184a4:     	mov	w8, #0x43               ; =67
102e184a8:     	stp	x8, x0, [x20, #0x18]
102e184ac:     	str	x8, [x20, #0x28]
102e184b0:     	str	xzr, [x20]
102e184b4:     	mov	x0, x19
102e184b8:     	ldp	x29, x30, [sp, #0x60]
102e184bc:     	ldp	x20, x19, [sp, #0x50]
102e184c0:     	add	sp, sp, #0x70
102e184c4:     	b	0x102e05a48 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEBM_>
102e184c8:     	add	x0, sp, #0x10
102e184cc:     	bl	0x102e2b120 <__RNvYNCNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtBb_5Value28into_private_unsigned_matrixs0_0INtNtNtCsgDHHaSskbIF_4core3ops8function6FnOnceuE9call_onceBf_>
102e184d0:     	ldr	x8, [sp, #0x18]
102e184d4:     	ldp	q0, q1, [sp, #0x20]
102e184d8:     	stur	q0, [x20, #0x18]
102e184dc:     	stur	q1, [x20, #0x28]
102e184e0:     	ldr	d0, [sp, #0x10]
102e184e4:     	str	d0, [x20, #0x8]
102e184e8:     	str	x8, [x20, #0x10]
102e184ec:     	b	0x102e184b0 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x1c4>
102e184f0:     	add	x0, sp, #0x10
102e184f4:     	bl	0x102e07dd8 <__RNCNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB8_5Value28into_private_unsigned_matrixs0_0Bc_>
102e184f8:     	ldp	q0, q1, [sp, #0x10]
102e184fc:     	stur	q0, [x20, #0x8]
102e18500:     	stur	q1, [x20, #0x18]
102e18504:     	ldr	q0, [sp, #0x30]
102e18508:     	stur	q0, [x20, #0x28]
102e1850c:     	b	0x102e184b0 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix+0x1c4>
102e18510:     	mov	w0, #0x1                ; =1
102e18514:     	mov	w1, #0x43               ; =67
102e18518:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102e1851c:     	brk	#0x1
102e18520:     	mov	x20, x0
102e18524:     	mov	x0, x19
102e18528:     	bl	0x102e05a48 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEBM_>
102e1852c:     	mov	x0, x20
102e18530:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
102e18534:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
