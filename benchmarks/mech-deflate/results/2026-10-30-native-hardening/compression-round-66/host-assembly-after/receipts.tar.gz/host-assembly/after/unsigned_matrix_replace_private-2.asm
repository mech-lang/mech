
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001028a8688 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private>:
1028a8688:     	stp	x28, x27, [sp, #-0x60]!
1028a868c:     	stp	x26, x25, [sp, #0x10]
1028a8690:     	stp	x24, x23, [sp, #0x20]
1028a8694:     	stp	x22, x21, [sp, #0x30]
1028a8698:     	stp	x20, x19, [sp, #0x40]
1028a869c:     	stp	x29, x30, [sp, #0x50]
1028a86a0:     	add	x29, sp, #0x50
1028a86a4:     	sub	sp, sp, #0x200
1028a86a8:     	mov	x20, x1
1028a86ac:     	mov	x19, x8
1028a86b0:     	stp	x2, x3, [sp, #0xd0]
1028a86b4:     	strb	w4, [sp, #0xe7]
1028a86b8:     	ldr	x8, [x5, #0x30]
1028a86bc:     	ldp	q1, q0, [x5, #0x10]
1028a86c0:     	ldr	q2, [x5]
1028a86c4:     	mov.d	v0[1], x8
1028a86c8:     	zip1.2d	v1, v2, v1
1028a86cc:     	cmeq.2d	v0, v0, #0
1028a86d0:     	cmeq.2d	v1, v1, #0
1028a86d4:     	uzp1.4s	v0, v1, v0
1028a86d8:     	umaxv.4s	s0, v0
1028a86dc:     	fmov	w8, s0
1028a86e0:     	tbnz	w8, #0x0, 0x1028a8750 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xc8>
1028a86e4:     	ldr	x8, [x5, #0x40]
1028a86e8:     	cbz	x8, 0x1028a8750 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xc8>
1028a86ec:     	ldr	x8, [x5, #0x50]
1028a86f0:     	cbz	x8, 0x1028a8750 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xc8>
1028a86f4:     	ldr	x8, [x5, #0x60]
1028a86f8:     	cbz	x8, 0x1028a8750 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xc8>
1028a86fc:     	mov	x26, x3
1028a8700:     	mov	x25, x5
1028a8704:     	mov	x22, x7
1028a8708:     	mov	x23, x6
1028a870c:     	mov	x24, x0
1028a8710:     	bl	0x1028a8500 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width>
1028a8714:     	mov	w8, #0x2c               ; =44
1028a8718:     	strb	w8, [sp, #0xf0]
1028a871c:     	cmp	x0, #0x1
1028a8720:     	b.ne	0x1028a8748 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xc0>
1028a8724:     	mov	x21, x1
1028a8728:     	add	x0, sp, #0xf0
1028a872c:     	bl	0x10282cd60 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1028a8730:     	str	x21, [sp, #0xe8]
1028a8734:     	cmp	x21, #0x8
1028a8738:     	b.hs	0x1028a87b8 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0x130>
1028a873c:     	lsl	x8, x21, #3
1028a8740:     	lsr	x8, x26, x8
1028a8744:     	cbz	x8, 0x1028a87b8 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0x130>
1028a8748:     	mov	w22, #0x2c              ; =44
1028a874c:     	b	0x1028a8758 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xd0>
1028a8750:     	ldr	w21, [x0, #0x110]
1028a8754:     	mov	w22, #0x22              ; =34
1028a8758:     	mov	x0, x20
1028a875c:     	bl	0x10282bd7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1028a8760:     	adrp	x8, 0x1076d5000 <_anon.3e49e8fa6a532448d7536ab560d50070.429+0x756>
1028a8764:     	add	x8, x8, #0xbc0
1028a8768:     	mov	w9, #0x36               ; =54
1028a876c:     	strb	w22, [x19, #0x8]
1028a8770:     	stur	w15, [x19, #0x9]
1028a8774:     	lsr	x16, x15, #48
1028a8778:     	strb	w16, [x19, #0xf]
1028a877c:     	lsr	x15, x15, #32
1028a8780:     	sturh	w15, [x19, #0xd]
1028a8784:     	stp	x8, x9, [x19, #0x10]
1028a8788:     	stp	w21, w12, [x19, #0x20]
1028a878c:     	stp	w11, w10, [x19, #0x28]
1028a8790:     	stp	x13, x14, [x19, #0x30]
1028a8794:     	str	xzr, [x19]
1028a8798:     	add	sp, sp, #0x200
1028a879c:     	ldp	x29, x30, [sp, #0x50]
1028a87a0:     	ldp	x20, x19, [sp, #0x40]
1028a87a4:     	ldp	x22, x21, [sp, #0x30]
1028a87a8:     	ldp	x24, x23, [sp, #0x20]
1028a87ac:     	ldp	x26, x25, [sp, #0x10]
1028a87b0:     	ldp	x28, x27, [sp], #0x60
1028a87b4:     	ret
1028a87b8:     	ldp	q0, q1, [x20]
1028a87bc:     	stur	q0, [sp, #0x8]
1028a87c0:     	stur	q1, [sp, #0x18]
1028a87c4:     	ldp	q0, q1, [x20, #0x20]
1028a87c8:     	stur	q0, [sp, #0x28]
1028a87cc:     	ldr	x1, [x25, #0x68]
1028a87d0:     	ldr	x2, [x25, #0x58]
1028a87d4:     	str	x24, [sp]
1028a87d8:     	stur	q1, [sp, #0x38]
1028a87dc:     	mov	x0, x23
1028a87e0:     	stp	x23, x25, [sp, #0x48]
1028a87e4:     	add	x8, sp, #0xd0
1028a87e8:     	stp	x22, x8, [sp, #0x58]
1028a87ec:     	add	x8, sp, #0xe8
1028a87f0:     	add	x9, sp, #0xd8
1028a87f4:     	stp	x8, x9, [sp, #0x68]
1028a87f8:     	add	x8, sp, #0xe7
1028a87fc:     	str	x8, [sp, #0x78]
1028a8800:     	add	x8, sp, #0xf0
1028a8804:     	mov	x3, sp
1028a8808:     	bl	0x1023249f8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_>
1028a880c:     	ldrb	w16, [sp, #0x1f8]
1028a8810:     	cmp	w16, #0x3
1028a8814:     	b.ne	0x1028a8838 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0x1b0>
1028a8818:     	ldp	x8, x9, [sp, #0xf0]
1028a881c:     	ldr	w12, [sp, #0x104]
1028a8820:     	ldr	w21, [sp, #0x100]
1028a8824:     	ldr	w11, [sp, #0x108]
1028a8828:     	ldr	w10, [sp, #0x10c]
1028a882c:     	mov	w22, #0x29              ; =41
1028a8830:     	ldr	x13, [sp, #0x110]
1028a8834:     	b	0x1028a876c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xe4>
1028a8838:     	add	x17, sp, #0xf0
1028a883c:     	ldrb	w22, [sp, #0xf0]
1028a8840:     	ldrb	w8, [sp, #0xf7]
1028a8844:     	ldurh	w9, [x17, #0x5]
1028a8848:     	orr	w8, w9, w8, lsl #16
1028a884c:     	ldur	w9, [x17, #0x1]
1028a8850:     	orr	x15, x9, x8, lsl #32
1028a8854:     	ldp	x8, x9, [sp, #0xf8]
1028a8858:     	ldr	w21, [sp, #0x108]
1028a885c:     	ldr	w12, [sp, #0x10c]
1028a8860:     	ldr	w11, [sp, #0x110]
1028a8864:     	ldr	w10, [sp, #0x114]
1028a8868:     	ldp	x13, x14, [sp, #0x118]
1028a886c:     	ldur	q0, [x17, #0xc8]
1028a8870:     	ldur	q1, [x17, #0xd8]
1028a8874:     	ldur	q2, [x17, #0xe8]
1028a8878:     	stp	q1, q2, [sp, #0xa0]
1028a887c:     	ldur	q1, [x17, #0xf8]
1028a8880:     	str	q1, [sp, #0xc0]
1028a8884:     	ldur	q1, [x17, #0x88]
1028a8888:     	ldur	q2, [x17, #0x98]
1028a888c:     	ldur	q3, [x17, #0xa8]
1028a8890:     	stp	q2, q3, [sp, #0x60]
1028a8894:     	ldur	q2, [x17, #0xb8]
1028a8898:     	stp	q2, q0, [sp, #0x80]
1028a889c:     	ldur	q0, [x17, #0x48]
1028a88a0:     	ldur	q2, [x17, #0x58]
1028a88a4:     	ldur	q3, [x17, #0x68]
1028a88a8:     	stp	q2, q3, [sp, #0x20]
1028a88ac:     	ldur	q2, [x17, #0x78]
1028a88b0:     	stp	q2, q1, [sp, #0x40]
1028a88b4:     	ldur	q1, [x17, #0x38]
1028a88b8:     	stp	q1, q0, [sp]
1028a88bc:     	cmp	w16, #0x2
1028a88c0:     	b.eq	0x1028a876c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0xe4>
1028a88c4:     	ldp	q1, q0, [sp, #0x80]
1028a88c8:     	stur	q0, [x19, #0xc8]
1028a88cc:     	ldp	q0, q2, [sp, #0xa0]
1028a88d0:     	stur	q0, [x19, #0xd8]
1028a88d4:     	stur	q2, [x19, #0xe8]
1028a88d8:     	ldr	q0, [sp, #0xc0]
1028a88dc:     	stur	q0, [x19, #0xf8]
1028a88e0:     	ldp	q2, q0, [sp, #0x40]
1028a88e4:     	stur	q0, [x19, #0x88]
1028a88e8:     	ldp	q0, q3, [sp, #0x60]
1028a88ec:     	stur	q0, [x19, #0x98]
1028a88f0:     	stur	q3, [x19, #0xa8]
1028a88f4:     	stur	q1, [x19, #0xb8]
1028a88f8:     	ldp	q1, q0, [sp]
1028a88fc:     	stur	q0, [x19, #0x48]
1028a8900:     	ldp	q0, q3, [sp, #0x20]
1028a8904:     	stur	q0, [x19, #0x58]
1028a8908:     	stur	q3, [x19, #0x68]
1028a890c:     	stur	q2, [x19, #0x78]
1028a8910:     	stur	q1, [x19, #0x38]
1028a8914:     	strb	w22, [x19]
1028a8918:     	stur	w15, [x19, #0x1]
1028a891c:     	lsr	x16, x15, #48
1028a8920:     	strb	w16, [x19, #0x7]
1028a8924:     	lsr	x15, x15, #32
1028a8928:     	sturh	w15, [x19, #0x5]
1028a892c:     	stp	x8, x9, [x19, #0x8]
1028a8930:     	stp	w21, w12, [x19, #0x18]
1028a8934:     	stp	w11, w10, [x19, #0x20]
1028a8938:     	stp	x13, x14, [x19, #0x28]
1028a893c:     	b	0x1028a8798 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private+0x110>
