
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e07dd8 <__RNCNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB8_5Value28into_private_unsigned_matrixs0_0Bc_>:
102e07dd8:     	stp	x20, x19, [sp, #-0x20]!
102e07ddc:     	stp	x29, x30, [sp, #0x10]
102e07de0:     	add	x29, sp, #0x10
102e07de4:     	mov	x19, x0
102e07de8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e07dec:     	mov	w0, #0x43               ; =67
102e07df0:     	mov	w1, #0x1                ; =1
102e07df4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e07df8:     	cbz	x0, 0x102e07e44 <__RNCNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB8_5Value28into_private_unsigned_matrixs0_0Bc_+0x6c>
102e07dfc:     	mov	w8, #0x6e77             ; =28279
102e07e00:     	movk	w8, #0x7265, lsl #16
102e07e04:     	stur	w8, [x0, #0x3f]
102e07e08:     	adrp	x8, 0x107708000 <_anon.e5ab26e9f9da5eb49b5a7d29064db6f1.16+0x58c>
102e07e0c:     	add	x8, x8, #0xbc5
102e07e10:     	ldp	q0, q1, [x8]
102e07e14:     	stp	q0, q1, [x0]
102e07e18:     	ldp	q0, q1, [x8, #0x20]
102e07e1c:     	stp	q0, q1, [x0, #0x20]
102e07e20:     	mov	w8, #0x43               ; =67
102e07e24:     	stp	x8, x0, [x19, #0x10]
102e07e28:     	str	x8, [x19, #0x20]
102e07e2c:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x3218>
102e07e30:     	ldr	d0, [x8, #0x168]
102e07e34:     	str	d0, [x19]
102e07e38:     	ldp	x29, x30, [sp, #0x10]
102e07e3c:     	ldp	x20, x19, [sp], #0x20
102e07e40:     	ret
102e07e44:     	mov	w0, #0x1                ; =1
102e07e48:     	mov	w1, #0x43               ; =67
102e07e4c:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
