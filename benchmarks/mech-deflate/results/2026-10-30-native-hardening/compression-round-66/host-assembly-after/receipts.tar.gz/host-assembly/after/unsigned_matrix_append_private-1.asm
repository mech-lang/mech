
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010235fbf8 <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB6_25NativePreparedLibraryCall30unsigned_matrix_append_private0Be_>:
10235fbf8:     	sub	sp, sp, #0x160
10235fbfc:     	stp	x20, x19, [sp, #0x140]
10235fc00:     	stp	x29, x30, [sp, #0x150]
10235fc04:     	add	x29, sp, #0x150
10235fc08:     	mov	x19, x0
10235fc0c:     	add	x8, sp, #0x38
10235fc10:     	mov	x0, x1
10235fc14:     	mov	x1, x2
10235fc18:     	bl	0x102e182ec <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix>
10235fc1c:     	ldr	x8, [sp, #0x38]
10235fc20:     	ldp	q0, q1, [sp, #0x40]
10235fc24:     	stp	q0, q1, [sp]
10235fc28:     	ldur	q0, [sp, #0x60]
10235fc2c:     	str	q0, [sp, #0x20]
10235fc30:     	cbz	x8, 0x10235fcb8 <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB6_25NativePreparedLibraryCall30unsigned_matrix_append_private0Be_+0xc0>
10235fc34:     	add	x9, sp, #0x38
10235fc38:     	ldur	q0, [x9, #0xc8]
10235fc3c:     	stur	q0, [x19, #0xc8]
10235fc40:     	ldur	q0, [x9, #0xd8]
10235fc44:     	stur	q0, [x19, #0xd8]
10235fc48:     	ldur	q0, [x9, #0xe8]
10235fc4c:     	stur	q0, [x19, #0xe8]
10235fc50:     	ldur	q0, [x9, #0xf8]
10235fc54:     	stur	q0, [x19, #0xf8]
10235fc58:     	ldur	q0, [x9, #0x88]
10235fc5c:     	stur	q0, [x19, #0x88]
10235fc60:     	ldur	q0, [x9, #0x98]
10235fc64:     	stur	q0, [x19, #0x98]
10235fc68:     	ldur	q0, [x9, #0xa8]
10235fc6c:     	stur	q0, [x19, #0xa8]
10235fc70:     	ldur	q0, [x9, #0xb8]
10235fc74:     	stur	q0, [x19, #0xb8]
10235fc78:     	ldur	q0, [x9, #0x48]
10235fc7c:     	stur	q0, [x19, #0x48]
10235fc80:     	ldur	q0, [x9, #0x58]
10235fc84:     	stur	q0, [x19, #0x58]
10235fc88:     	ldur	q0, [x9, #0x68]
10235fc8c:     	stur	q0, [x19, #0x68]
10235fc90:     	ldur	q0, [x9, #0x78]
10235fc94:     	stur	q0, [x19, #0x78]
10235fc98:     	ldur	q0, [sp, #0x70]
10235fc9c:     	stur	q0, [x19, #0x38]
10235fca0:     	ldp	q0, q1, [sp]
10235fca4:     	stur	q0, [x19, #0x8]
10235fca8:     	stur	q1, [x19, #0x18]
10235fcac:     	ldr	q0, [sp, #0x20]
10235fcb0:     	stur	q0, [x19, #0x28]
10235fcb4:     	b	0x10235fcf4 <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB6_25NativePreparedLibraryCall30unsigned_matrix_append_private0Be_+0xfc>
10235fcb8:     	ldp	q0, q1, [sp]
10235fcbc:     	stur	q0, [sp, #0x3f]
10235fcc0:     	stur	q1, [sp, #0x4f]
10235fcc4:     	ldr	q0, [sp, #0x20]
10235fcc8:     	stur	q0, [sp, #0x5f]
10235fccc:     	ldur	q0, [sp, #0x38]
10235fcd0:     	ldur	q1, [sp, #0x48]
10235fcd4:     	stur	q0, [x19, #0x9]
10235fcd8:     	mov	w9, #0x2b               ; =43
10235fcdc:     	strb	w9, [x19, #0x8]
10235fce0:     	stur	q1, [x19, #0x19]
10235fce4:     	ldur	q0, [sp, #0x58]
10235fce8:     	stur	q0, [x19, #0x29]
10235fcec:     	ldur	x9, [sp, #0x67]
10235fcf0:     	str	x9, [x19, #0x38]
10235fcf4:     	str	x8, [x19]
10235fcf8:     	ldp	x29, x30, [sp, #0x150]
10235fcfc:     	ldp	x20, x19, [sp, #0x140]
10235fd00:     	add	sp, sp, #0x160
10235fd04:     	ret
