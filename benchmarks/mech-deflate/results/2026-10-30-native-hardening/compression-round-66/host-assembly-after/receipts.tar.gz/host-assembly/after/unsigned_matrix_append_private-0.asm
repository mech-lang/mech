
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010231d250 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_>:
10231d250:     	stp	x28, x27, [sp, #-0x60]!
10231d254:     	stp	x26, x25, [sp, #0x10]
10231d258:     	stp	x24, x23, [sp, #0x20]
10231d25c:     	stp	x22, x21, [sp, #0x30]
10231d260:     	stp	x20, x19, [sp, #0x40]
10231d264:     	stp	x29, x30, [sp, #0x50]
10231d268:     	add	x29, sp, #0x50
10231d26c:     	sub	sp, sp, #0xb00
10231d270:     	str	xzr, [sp]
10231d274:     	mov	x20, x8
10231d278:     	ldp	q1, q0, [x3, #0x40]
10231d27c:     	add	x8, sp, #0x29
10231d280:     	stur	q0, [x8, #0xff]
10231d284:     	add	x8, sp, #0xc0
10231d288:     	ldp	q0, q2, [x3, #0x60]
10231d28c:     	stur	q0, [x8, #0x78]
10231d290:     	stur	q2, [x8, #0x88]
10231d294:     	ldp	q2, q0, [x3]
10231d298:     	stur	q0, [sp, #0xe8]
10231d29c:     	ldp	q0, q3, [x3, #0x20]
10231d2a0:     	stur	q0, [sp, #0xf8]
10231d2a4:     	add	x8, sp, #0x9
10231d2a8:     	stur	q3, [x8, #0xff]
10231d2ac:     	add	x8, sp, #0x19
10231d2b0:     	stur	q1, [x8, #0xff]
10231d2b4:     	stp	x1, x2, [sp, #0xb0]
10231d2b8:     	add	x8, sp, #0xb0
10231d2bc:     	stp	x0, x8, [sp, #0xc0]
10231d2c0:     	add	x8, sp, #0xb8
10231d2c4:     	str	x8, [sp, #0xd0]
10231d2c8:     	ldr	x8, [x3, #0x80]
10231d2cc:     	str	x8, [sp, #0x158]
10231d2d0:     	stur	q2, [sp, #0xd8]
10231d2d4:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
10231d2d8:     	add	x0, x0, #0x568
10231d2dc:     	ldr	x8, [x0]
10231d2e0:     	blr	x8
10231d2e4:     	mov	x19, x0
10231d2e8:     	ldrb	w8, [x0, #0x48]
10231d2ec:     	cmp	w8, #0x1
10231d2f0:     	b.eq	0x10231d334 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe4>
10231d2f4:     	cmp	w8, #0x2
10231d2f8:     	b.ne	0x10231d31c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xcc>
10231d2fc:     	ldr	x8, [sp, #0x120]
10231d300:     	cbz	x8, 0x10231d310 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xc0>
10231d304:     	add	x8, sp, #0xc0
10231d308:     	add	x0, x8, #0x60
10231d30c:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231d310:     	adrp	x0, 0x108031000 <_anon.686517066f445f70c1782692b9896900.7+0x55f00>
10231d314:     	add	x0, x0, #0xc40
10231d318:     	bl	0x103a03528 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10231d31c:     	adrp	x1, 0x10283b000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy5_EB8_+0xa90>
10231d320:     	add	x1, x1, #0x2b4
10231d324:     	mov	x0, x19
10231d328:     	bl	0x102e71110 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10231d32c:     	mov	w8, #0x1                ; =1
10231d330:     	strb	w8, [x19, #0x48]
10231d334:     	ldp	q0, q1, [sp, #0x120]
10231d338:     	stp	q0, q1, [sp, #0x1c0]
10231d33c:     	ldp	q0, q1, [sp, #0x140]
10231d340:     	stp	q0, q1, [sp, #0x1e0]
10231d344:     	ldp	q0, q1, [sp, #0xe0]
10231d348:     	stp	q0, q1, [sp, #0x180]
10231d34c:     	ldp	q0, q1, [sp, #0x100]
10231d350:     	stp	q0, q1, [sp, #0x1a0]
10231d354:     	ldp	q0, q1, [sp, #0xc0]
10231d358:     	stp	q0, q1, [sp, #0x160]
10231d35c:     	mov	x8, x19
10231d360:     	ldr	x9, [x8, #0x20]!
10231d364:     	cbnz	x9, 0x10231db3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x8ec>
10231d368:     	mov	x9, #-0x1               ; =-1
10231d36c:     	str	x9, [x19, #0x20]
10231d370:     	ldr	x11, [x19, #0x28]
10231d374:     	ldr	x9, [sp, #0x160]
10231d378:     	ldr	x10, [x9]
10231d37c:     	cbz	x11, 0x10231d3ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x15c>
10231d380:     	cmp	x11, x10
10231d384:     	b.eq	0x10231d3ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x15c>
10231d388:     	str	xzr, [x8]
10231d38c:     	ldr	x8, [sp, #0x1c0]
10231d390:     	cbz	x8, 0x10231d3a0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x150>
10231d394:     	add	x8, sp, #0x160
10231d398:     	add	x0, x8, #0x60
10231d39c:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231d3a0:     	mov	x28, #0x0               ; =0
10231d3a4:     	mov	w8, #0x1                ; =1
10231d3a8:     	b	0x10231d758 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x508>
10231d3ac:     	ldr	x11, [x10]
10231d3b0:     	adds	x11, x11, #0x1
10231d3b4:     	str	x11, [x10]
10231d3b8:     	b.hs	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231d3bc:     	ldp	x12, x11, [x19, #0x20]
10231d3c0:     	add	x12, x12, #0x1
10231d3c4:     	stp	x12, x10, [x19, #0x20]
10231d3c8:     	str	x8, [sp, #0x200]
10231d3cc:     	str	x11, [sp, #0x208]
10231d3d0:     	ldr	x21, [x9]
10231d3d4:     	ldr	x8, [x21]
10231d3d8:     	adds	x8, x8, #0x1
10231d3dc:     	str	x8, [x21]
10231d3e0:     	b.hs	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231d3e4:     	str	xzr, [sp, #0x3b0]
10231d3e8:     	str	x21, [sp, #0x3a0]
10231d3ec:     	str	xzr, [sp, #0x3a8]
10231d3f0:     	ldr	x8, [x19]
10231d3f4:     	cbnz	x8, 0x10231db4c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x8fc>
10231d3f8:     	add	x8, sp, #0x160
10231d3fc:     	ldur	q0, [x19, #0x8]
10231d400:     	stur	q0, [x8, #0xb8]
10231d404:     	ldr	x10, [x19, #0x18]
10231d408:     	ldr	q0, [sp, #0x3a0]
10231d40c:     	stur	q0, [x19, #0x8]
10231d410:     	ldr	x11, [sp, #0x3b0]
10231d414:     	str	x11, [x19, #0x18]
10231d418:     	str	x10, [sp, #0x228]
10231d41c:     	str	x19, [sp, #0x210]
10231d420:     	ldr	x10, [x9]
10231d424:     	ldr	x11, [x10, #0x10]
10231d428:     	mov	x9, #0x7ffffffffffffffe ; =9223372036854775806
10231d42c:     	cmp	x11, x9
10231d430:     	cset	w26, hi
10231d434:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10231d438:     	cmp	x11, x9
10231d43c:     	b.hs	0x10231db5c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x90c>
10231d440:     	ldp	x11, x10, [x10, #0x38]
10231d444:     	ldp	x22, x27, [x19, #0x30]
10231d448:     	ldr	x23, [x19, #0x40]
10231d44c:     	ldp	x12, x13, [sp, #0x168]
10231d450:     	ldr	x12, [x12]
10231d454:     	adds	x11, x11, x12
10231d458:     	csinv	x11, x11, xzr, lo
10231d45c:     	cmp	x27, x11
10231d460:     	csel	x12, x27, x11, lo
10231d464:     	ldr	x13, [x13]
10231d468:     	adds	x10, x10, x13
10231d46c:     	csinv	x10, x10, xzr, lo
10231d470:     	cmp	x23, x10
10231d474:     	csel	x13, x23, x10, lo
10231d478:     	tst	w22, #0x1
10231d47c:     	csel	x11, x12, x11, ne
10231d480:     	csel	x10, x13, x10, ne
10231d484:     	mov	w12, #0x1               ; =1
10231d488:     	stp	x12, x11, [x19, #0x30]
10231d48c:     	str	x10, [x19, #0x40]
10231d490:     	ldur	q0, [x8, #0x68]
10231d494:     	ldur	q1, [x8, #0x78]
10231d498:     	ldur	q2, [x8, #0x88]
10231d49c:     	stp	q1, q2, [sp, #0x2b0]
10231d4a0:     	ldr	x10, [sp, #0x1f8]
10231d4a4:     	str	x10, [sp, #0x2d0]
10231d4a8:     	ldur	q1, [x8, #0x28]
10231d4ac:     	ldur	q2, [x8, #0x38]
10231d4b0:     	ldur	q3, [x8, #0x48]
10231d4b4:     	stp	q2, q3, [sp, #0x270]
10231d4b8:     	ldur	q2, [x8, #0x58]
10231d4bc:     	stp	q2, q0, [sp, #0x290]
10231d4c0:     	ldur	q0, [x8, #0x18]
10231d4c4:     	stp	q0, q1, [sp, #0x250]
10231d4c8:     	ldr	x8, [sp, #0x250]
10231d4cc:     	ldr	x21, [x8]
10231d4d0:     	ldr	x8, [x21, #0x10]
10231d4d4:     	cmp	x8, x9
10231d4d8:     	stp	x23, x22, [sp, #0xa0]
10231d4dc:     	b.hs	0x10231db6c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x91c>
10231d4e0:     	add	x8, x8, #0x1
10231d4e4:     	str	x8, [x21, #0x10]
10231d4e8:     	ldr	x8, [x21, #0x18]
10231d4ec:     	cbz	x8, 0x10231db7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x92c>
10231d4f0:     	mov	w9, #0x1                ; =1
10231d4f4:     	ldadd	x9, x9, [x8]
10231d4f8:     	tbnz	x9, #0x3f, 0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231d4fc:     	add	x28, sp, #0x250
10231d500:     	str	x8, [sp, #0x2d8]
10231d504:     	ldr	q0, [x21, #0x20]
10231d508:     	stur	q0, [x28, #0x90]
10231d50c:     	ldr	x8, [x21, #0x10]
10231d510:     	sub	x8, x8, #0x1
10231d514:     	str	x8, [x21, #0x10]
10231d518:     	ldr	x25, [sp, #0x258]
10231d51c:     	ldr	x8, [x25, #0xc0]
10231d520:     	cbz	x8, 0x10231e208 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfb8>
10231d524:     	ldr	x8, [x25, #0xb8]
10231d528:     	ldr	w9, [x8, #0x2c]
10231d52c:     	ldr	x8, [sp, #0x260]
10231d530:     	ldrb	w8, [x8]
10231d534:     	sub	w8, w8, #0x3
10231d538:     	cmp	w8, #0x2
10231d53c:     	b.hs	0x10231d578 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x328>
10231d540:     	mov	w24, #0x0               ; =0
10231d544:     	ldrb	w8, [x25, #0x20]
10231d548:     	mov	w22, #0x2c              ; =44
10231d54c:     	cmp	w8, #0x10
10231d550:     	b.ne	0x10231d634 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3e4>
10231d554:     	ldr	x8, [x25, #0x38]
10231d558:     	mov	x21, x24
10231d55c:     	cmp	x8, #0x2
10231d560:     	b.ne	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231d564:     	ldr	x21, [x25, #0x28]
10231d568:     	ldrb	w8, [x21]
10231d56c:     	cmp	w8, #0x2
10231d570:     	b.eq	0x10231d5c8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x378>
10231d574:     	b	0x10231d624 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3d4>
10231d578:     	mov	w24, #0x0               ; =0
10231d57c:     	ldrb	w8, [x25, #0x20]
10231d580:     	mov	w22, #0x2c              ; =44
10231d584:     	cmp	w8, #0x10
10231d588:     	b.ne	0x10231d634 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3e4>
10231d58c:     	ldr	x8, [x25, #0x38]
10231d590:     	mov	x21, x24
10231d594:     	cmp	x8, #0x2
10231d598:     	b.ne	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231d59c:     	mov	x22, x9
10231d5a0:     	ldr	x0, [x25, #0x30]
10231d5a4:     	adrp	x1, 0x107678000 <_anon.8cdccdce79f5fe5517216573563a475c.613+0xf7>
10231d5a8:     	add	x1, x1, #0x170
10231d5ac:     	bl	0x1025b6fa4 <__RNvXst_NtCskIfnrfrMWVM_9mech_core9dimensionNtB5_13DimensionExprNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
10231d5b0:     	cbz	w0, 0x10231d624 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3d4>
10231d5b4:     	ldr	x21, [x25, #0x28]
10231d5b8:     	ldrb	w8, [x21]
10231d5bc:     	cmp	w8, #0x2
10231d5c0:     	mov	x9, x22
10231d5c4:     	b.ne	0x10231d624 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3d4>
10231d5c8:     	ldrh	w8, [x21, #0x2]
10231d5cc:     	mov	w22, #0x2c              ; =44
10231d5d0:     	cmp	w8, #0x80
10231d5d4:     	b.eq	0x10231d63c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3ec>
10231d5d8:     	str	w9, [sp, #0x9c]
10231d5dc:     	strb	w22, [sp, #0x3a0]
10231d5e0:     	add	x0, sp, #0x3a0
10231d5e4:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231d5e8:     	ldrb	w8, [x21]
10231d5ec:     	cmp	w8, #0x2
10231d5f0:     	b.ne	0x10231d63c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3ec>
10231d5f4:     	ldrh	w8, [x21, #0x2]
10231d5f8:     	rbit	w8, w8
10231d5fc:     	clz	w8, w8
10231d600:     	cmp	w8, #0x4
10231d604:     	b.le	0x10231d7ec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x59c>
10231d608:     	cmp	w8, #0x5
10231d60c:     	b.eq	0x10231d800 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x5b0>
10231d610:     	cmp	w8, #0x6
10231d614:     	b.ne	0x10231d624 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3d4>
10231d618:     	mov	w21, #0x0               ; =0
10231d61c:     	mov	w24, #0x8               ; =8
10231d620:     	b	0x10231d810 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x5c0>
10231d624:     	mov	w24, #0x0               ; =0
10231d628:     	mov	w21, #0x0               ; =0
10231d62c:     	mov	w22, #0x2c              ; =44
10231d630:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231d634:     	mov	x21, x24
10231d638:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231d63c:     	mov	w24, #0x0               ; =0
10231d640:     	mov	w21, #0x0               ; =0
10231d644:     	ldr	x8, [sp, #0x2d8]
10231d648:     	mov	x9, #-0x1               ; =-1
10231d64c:     	ldaddl	x9, x8, [x8]
10231d650:     	cmp	x8, #0x1
10231d654:     	b.ne	0x10231d664 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x414>
10231d658:     	dmb	ishld
10231d65c:     	add	x0, sp, #0x2d8
10231d660:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10231d664:     	ldr	x8, [sp, #0x298]
10231d668:     	cbz	x8, 0x10231d678 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x428>
10231d66c:     	add	x8, sp, #0x250
10231d670:     	add	x0, x8, #0x48
10231d674:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231d678:     	mov	x28, #0x0               ; =0
10231d67c:     	add	x26, sp, #0x210
10231d680:     	ldp	q0, q1, [sp, #0x230]
10231d684:     	str	q0, [sp, #0x860]
10231d688:     	str	q1, [sp, #0x870]
10231d68c:     	ldr	q0, [sp, #0x990]
10231d690:     	ldr	q1, [sp, #0x9a0]
10231d694:     	ldr	q2, [sp, #0x9b0]
10231d698:     	ldr	q3, [sp, #0x9c0]
10231d69c:     	stp	q2, q3, [sp, #0x3c0]
10231d6a0:     	stp	q0, q1, [sp, #0x3a0]
10231d6a4:     	ldr	q0, [sp, #0x9d0]
10231d6a8:     	ldr	q1, [sp, #0x9e0]
10231d6ac:     	ldr	q2, [sp, #0x9f0]
10231d6b0:     	ldr	q3, [sp, #0xa00]
10231d6b4:     	str	q3, [sp, #0x410]
10231d6b8:     	stp	q1, q2, [sp, #0x3f0]
10231d6bc:     	str	q0, [sp, #0x3e0]
10231d6c0:     	ldr	q0, [sp, #0xa10]
10231d6c4:     	ldr	q1, [sp, #0xa20]
10231d6c8:     	ldr	q2, [sp, #0xa30]
10231d6cc:     	ldr	q3, [sp, #0xa40]
10231d6d0:     	ldr	x8, [sp, #0xa50]
10231d6d4:     	str	x8, [sp, #0x460]
10231d6d8:     	str	q3, [sp, #0x450]
10231d6dc:     	str	q2, [sp, #0x440]
10231d6e0:     	str	q0, [sp, #0x420]
10231d6e4:     	str	q1, [sp, #0x430]
10231d6e8:     	ldp	x8, x9, [sp, #0xa0]
10231d6ec:     	stp	x9, x27, [x19, #0x30]
10231d6f0:     	str	x8, [x19, #0x40]
10231d6f4:     	add	x0, sp, #0x210
10231d6f8:     	bl	0x1023a56a0 <__RNvXs_NvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBa_23NativeLibraryWorkBudget16with_call_limitsNtB4_10ScopeGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
10231d6fc:     	ldr	x8, [sp, #0x218]
10231d700:     	cbz	x8, 0x10231d71c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x4cc>
10231d704:     	ldr	x9, [x8]
10231d708:     	subs	x9, x9, #0x1
10231d70c:     	str	x9, [x8]
10231d710:     	b.ne	0x10231d71c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x4cc>
10231d714:     	add	x0, x26, #0x8
10231d718:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
10231d71c:     	add	x26, sp, #0x200
10231d720:     	add	x0, sp, #0x200
10231d724:     	bl	0x10238b060 <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
10231d728:     	lsl	w8, w24, #8
10231d72c:     	bfxil	x8, x23, #0, #8
10231d730:     	orr	x19, x8, x21, lsl #32
10231d734:     	ldr	x8, [sp, #0x208]
10231d738:     	cbz	x8, 0x10231d754 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x504>
10231d73c:     	ldr	x9, [x8]
10231d740:     	subs	x9, x9, #0x1
10231d744:     	str	x9, [x8]
10231d748:     	b.ne	0x10231d754 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x504>
10231d74c:     	add	x0, x26, #0x8
10231d750:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
10231d754:     	mov	x8, #0x0                ; =0
10231d758:     	ldr	q0, [sp, #0x860]
10231d75c:     	ldr	q1, [sp, #0x870]
10231d760:     	stp	q0, q1, [x20, #0x20]
10231d764:     	ldr	q0, [sp, #0x430]
10231d768:     	ldr	q1, [sp, #0x420]
10231d76c:     	stur	q0, [x20, #0xd8]
10231d770:     	ldr	q0, [sp, #0x440]
10231d774:     	ldr	q2, [sp, #0x450]
10231d778:     	stur	q0, [x20, #0xe8]
10231d77c:     	stur	q2, [x20, #0xf8]
10231d780:     	ldp	q2, q0, [sp, #0x3e0]
10231d784:     	stur	q0, [x20, #0x98]
10231d788:     	ldr	q0, [sp, #0x400]
10231d78c:     	ldr	q3, [sp, #0x410]
10231d790:     	stur	q0, [x20, #0xa8]
10231d794:     	stur	q3, [x20, #0xb8]
10231d798:     	stur	q1, [x20, #0xc8]
10231d79c:     	ldp	q1, q0, [sp, #0x3a0]
10231d7a0:     	stur	q0, [x20, #0x58]
10231d7a4:     	ldp	q0, q3, [sp, #0x3c0]
10231d7a8:     	stur	q0, [x20, #0x68]
10231d7ac:     	stur	q3, [x20, #0x78]
10231d7b0:     	stur	q2, [x20, #0x88]
10231d7b4:     	ldr	x9, [sp, #0x460]
10231d7b8:     	str	x9, [x20, #0x108]
10231d7bc:     	stur	q1, [x20, #0x48]
10231d7c0:     	stp	x8, x28, [x20]
10231d7c4:     	stp	x22, x19, [x20, #0x10]
10231d7c8:     	str	x25, [x20, #0x40]
10231d7cc:     	add	sp, sp, #0xb00
10231d7d0:     	ldp	x29, x30, [sp, #0x50]
10231d7d4:     	ldp	x20, x19, [sp, #0x40]
10231d7d8:     	ldp	x22, x21, [sp, #0x30]
10231d7dc:     	ldp	x24, x23, [sp, #0x20]
10231d7e0:     	ldp	x26, x25, [sp, #0x10]
10231d7e4:     	ldp	x28, x27, [sp], #0x60
10231d7e8:     	ret
10231d7ec:     	mov	w21, #0x1               ; =1
10231d7f0:     	cmp	w8, #0x3
10231d7f4:     	b.ne	0x10231d80c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x5bc>
10231d7f8:     	mov	w24, #0x1               ; =1
10231d7fc:     	b	0x10231d810 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x5c0>
10231d800:     	mov	w21, #0x1               ; =1
10231d804:     	mov	w24, #0x4               ; =4
10231d808:     	b	0x10231d810 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x5c0>
10231d80c:     	mov	w24, #0x2               ; =2
10231d810:     	mov	w8, #0x2c               ; =44
10231d814:     	strb	w8, [sp, #0x3a0]
10231d818:     	add	x0, sp, #0x3a0
10231d81c:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231d820:     	ldr	x8, [sp, #0x260]
10231d824:     	ldrb	w8, [x8]
10231d828:     	cbz	w21, 0x10231d868 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x618>
10231d82c:     	cmp	w8, #0x2
10231d830:     	b.ne	0x10231d868 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x618>
10231d834:     	ldr	x8, [sp, #0x268]
10231d838:     	ldr	x8, [x8]
10231d83c:     	lsl	x9, x24, #3
10231d840:     	lsr	x8, x8, x9
10231d844:     	mov	w22, #0x2c              ; =44
10231d848:     	cbnz	x8, 0x10231daa8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x858>
10231d84c:     	mov	x9, x24
10231d850:     	ldr	x8, [sp, #0x298]
10231d854:     	cbz	x8, 0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231d858:     	add	x8, sp, #0x250
10231d85c:     	add	x17, x8, #0x48
10231d860:     	mov	x24, x9
10231d864:     	b	0x10231d87c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x62c>
10231d868:     	add	x9, sp, #0x250
10231d86c:     	add	x17, x9, #0x48
10231d870:     	ldr	x9, [sp, #0x298]
10231d874:     	cbz	x9, 0x10231d964 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x714>
10231d878:     	cbz	w8, 0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231d87c:     	ldr	x8, [sp, #0x258]
10231d880:     	ldr	x9, [x8, #0xb0]
10231d884:     	cbz	x9, 0x10231e3d4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1184>
10231d888:     	ldr	x9, [x8, #0xa8]
10231d88c:     	ldr	w10, [sp, #0x2d0]
10231d890:     	ldr	w9, [x9]
10231d894:     	cmp	w10, w9
10231d898:     	b.ne	0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231d89c:     	ldur	q0, [x28, #0x58]
10231d8a0:     	ldur	q1, [x28, #0x68]
10231d8a4:     	stp	q0, q1, [sp, #0x3a0]
10231d8a8:     	ldr	x9, [x8, #0x128]
10231d8ac:     	cbz	x9, 0x10231e3e8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1198>
10231d8b0:     	ldr	x9, [x8, #0x120]
10231d8b4:     	ldr	x10, [sp, #0x3a0]
10231d8b8:     	ldr	x11, [sp, #0x3a8]
10231d8bc:     	ldp	x12, x13, [x9]
10231d8c0:     	ldr	x14, [sp, #0x3b0]
10231d8c4:     	ldr	x15, [sp, #0x3b8]
10231d8c8:     	ldp	x16, x9, [x9, #0x10]
10231d8cc:     	cmp	x10, x12
10231d8d0:     	ccmp	x11, x13, #0x0, eq
10231d8d4:     	ccmp	x14, x16, #0x0, eq
10231d8d8:     	ccmp	x15, x9, #0x0, eq
10231d8dc:     	b.ne	0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231d8e0:     	ldr	x9, [x8, #0x190]
10231d8e4:     	add	x8, sp, #0x2f0
10231d8e8:     	add	x1, x9, #0x10
10231d8ec:     	mov	x21, x17
10231d8f0:     	mov	x0, x17
10231d8f4:     	bl	0x102e11a14 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
10231d8f8:     	ldrb	w8, [sp, #0x2f0]
10231d8fc:     	cmp	w8, #0x16
10231d900:     	b.ne	0x10231daac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x85c>
10231d904:     	add	x1, sp, #0x2d8
10231d908:     	mov	x0, x21
10231d90c:     	bl	0x102e13930 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
10231d910:     	mov	w8, #0x2d               ; =45
10231d914:     	strb	w8, [sp, #0x3a0]
10231d918:     	cmp	x0, #0x1
10231d91c:     	b.ne	0x10231dab8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x868>
10231d920:     	mov	x22, x1
10231d924:     	add	x0, sp, #0x3a0
10231d928:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231d92c:     	add	x1, sp, #0x2d8
10231d930:     	mov	x0, x21
10231d934:     	bl	0x102e13a04 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_nodes>
10231d938:     	mov	w8, #0x2d               ; =45
10231d93c:     	strb	w8, [sp, #0x3a0]
10231d940:     	cmp	x0, #0x1
10231d944:     	b.ne	0x10231dab8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x868>
10231d948:     	mov	x23, x1
10231d94c:     	add	x0, sp, #0x3a0
10231d950:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231d954:     	mov	x17, x21
10231d958:     	mov	x0, x22
10231d95c:     	mov	x2, x23
10231d960:     	b	0x10231d970 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x720>
10231d964:     	cbnz	w8, 0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231d968:     	mov	x2, #0x0                ; =0
10231d96c:     	mov	x0, #0x0                ; =0
10231d970:     	ldr	x22, [sp, #0x270]
10231d974:     	ldr	x23, [x22]
10231d978:     	cbz	x23, 0x10231dac8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x878>
10231d97c:     	ldr	x1, [x25, #0xb0]
10231d980:     	cmp	x1, #0x1
10231d984:     	b.ls	0x10231e3fc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x11ac>
10231d988:     	ldr	x8, [x25, #0xa8]
10231d98c:     	ldr	w9, [x22, #0x38]
10231d990:     	ldr	w8, [x8, #0x8]
10231d994:     	cmp	w9, w8
10231d998:     	b.ne	0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231d99c:     	ldp	q0, q1, [x22, #0x10]
10231d9a0:     	stp	q0, q1, [sp, #0x3a0]
10231d9a4:     	ldr	x8, [sp, #0x258]
10231d9a8:     	ldr	x1, [x8, #0x128]
10231d9ac:     	cmp	x1, #0x2
10231d9b0:     	b.lo	0x10231e40c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x11bc>
10231d9b4:     	ldr	x9, [x8, #0x120]
10231d9b8:     	ldr	x10, [sp, #0x3a0]
10231d9bc:     	ldr	x11, [sp, #0x3a8]
10231d9c0:     	ldp	x12, x13, [x9, #0x20]
10231d9c4:     	ldr	x14, [sp, #0x3b0]
10231d9c8:     	ldr	x15, [sp, #0x3b8]
10231d9cc:     	ldp	x16, x9, [x9, #0x30]
10231d9d0:     	cmp	x10, x12
10231d9d4:     	ccmp	x11, x13, #0x0, eq
10231d9d8:     	ccmp	x14, x16, #0x0, eq
10231d9dc:     	ccmp	x15, x9, #0x0, eq
10231d9e0:     	b.ne	0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231d9e4:     	stp	x2, x0, [sp, #0x88]
10231d9e8:     	mov	x21, x17
10231d9ec:     	ldr	x9, [x8, #0x190]
10231d9f0:     	add	x8, sp, #0x338
10231d9f4:     	add	x1, x9, #0x10
10231d9f8:     	mov	x0, x22
10231d9fc:     	bl	0x102e11a14 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
10231da00:     	ldrb	w8, [sp, #0x338]
10231da04:     	cmp	w8, #0x16
10231da08:     	b.ne	0x10231db98 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x948>
10231da0c:     	add	x1, sp, #0x2d8
10231da10:     	mov	x0, x22
10231da14:     	bl	0x102e13930 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
10231da18:     	str	x1, [sp, #0x80]
10231da1c:     	mov	x25, x26
10231da20:     	mov	w8, #0x2d               ; =45
10231da24:     	strb	w8, [sp, #0x3a0]
10231da28:     	cmp	x0, #0x1
10231da2c:     	b.ne	0x10231df10 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xcc0>
10231da30:     	add	x0, sp, #0x3a0
10231da34:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231da38:     	add	x1, sp, #0x2d8
10231da3c:     	mov	x0, x22
10231da40:     	mov	x26, x25
10231da44:     	bl	0x102e13a04 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_nodes>
10231da48:     	str	x1, [sp, #0x78]
10231da4c:     	mov	w8, #0x2d               ; =45
10231da50:     	strb	w8, [sp, #0x3a0]
10231da54:     	cmp	x0, #0x1
10231da58:     	b.ne	0x10231df10 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xcc0>
10231da5c:     	add	x0, sp, #0x3a0
10231da60:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231da64:     	ldr	x8, [sp, #0x268]
10231da68:     	ldr	x9, [sp, #0x278]
10231da6c:     	ldr	x2, [x8]
10231da70:     	ldr	x3, [x9]
10231da74:     	add	x8, sp, #0x990
10231da78:     	mov	x0, x22
10231da7c:     	mov	x1, x24
10231da80:     	mov	x26, x25
10231da84:     	bl	0x10258fe00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine10intrinsics16sequence_buffers13sublist_range>
10231da88:     	ldr	x8, [sp, #0x990]
10231da8c:     	cmp	x8, #0x2
10231da90:     	b.ne	0x10231df48 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xcf8>
10231da94:     	ldr	x11, [sp, #0x998]
10231da98:     	ldr	x12, [sp, #0x9a0]
10231da9c:     	mov	x26, x25
10231daa0:     	mov	x17, x21
10231daa4:     	b	0x10231dad0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x880>
10231daa8:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231daac:     	add	x0, sp, #0x2f0
10231dab0:     	bl	0x10234107c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
10231dab4:     	b	0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231dab8:     	mov	w24, #0x0               ; =0
10231dabc:     	mov	w21, #0x0               ; =0
10231dac0:     	mov	w22, #0x2d              ; =45
10231dac4:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231dac8:     	stp	x2, x0, [sp, #0x88]
10231dacc:     	stp	xzr, xzr, [sp, #0x78]
10231dad0:     	mov	w21, #0x0               ; =0
10231dad4:     	ldr	x8, [sp, #0x278]
10231dad8:     	ldr	x9, [sp, #0x260]
10231dadc:     	ldr	x8, [x8]
10231dae0:     	subs	x10, x12, x11
10231dae4:     	csel	x10, xzr, x10, lo
10231dae8:     	cmp	x23, #0x0
10231daec:     	csel	x22, x8, x10, eq
10231daf0:     	ldrb	w0, [x9]
10231daf4:     	ldr	x8, [sp, #0x298]
10231daf8:     	stp	x12, x10, [sp, #0x60]
10231dafc:     	cbnz	x22, 0x10231dba0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x950>
10231db00:     	sub	w9, w0, #0x5
10231db04:     	mov	x25, x11
10231db08:     	cmn	w9, #0x2
10231db0c:     	b.lo	0x10231dba4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x954>
10231db10:     	cbz	x8, 0x10231dba4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x954>
10231db14:     	ldr	x0, [sp, #0x258]
10231db18:     	mov	x28, x17
10231db1c:     	mov	x1, x17
10231db20:     	bl	0x10235f3d4 <__RNCNCINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB9_25NativePreparedLibraryCall20unsigned_buffer_withNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueNCNvB6_28unsigned_buffer_with_sublist0E0s2_0Bh_>
10231db24:     	mov	x21, x0
10231db28:     	ldr	x9, [sp, #0x260]
10231db2c:     	ldr	x8, [sp, #0x298]
10231db30:     	ldrb	w0, [x9]
10231db34:     	mov	x17, x28
10231db38:     	b	0x10231dba4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x954>
10231db3c:     	adrp	x0, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10231db40:     	add	x0, x0, #0x410
10231db44:     	bl	0x103a03bac <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10231db48:     	b	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231db4c:     	adrp	x0, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10231db50:     	add	x0, x0, #0x3f8
10231db54:     	bl	0x103a03bac <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10231db58:     	b	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231db5c:     	adrp	x0, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
10231db60:     	add	x0, x0, #0x3f0
10231db64:     	bl	0x103a03bdc <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10231db68:     	b	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231db6c:     	adrp	x0, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
10231db70:     	add	x0, x0, #0x360
10231db74:     	bl	0x103a03bdc <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10231db78:     	b	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231db7c:     	adrp	x0, 0x107577000 <_anon.bacf143378b3839dd1972d7136a97b6c.2706+0x7>
10231db80:     	add	x0, x0, #0x687
10231db84:     	adrp	x2, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
10231db88:     	add	x2, x2, #0x378
10231db8c:     	mov	w1, #0x2a               ; =42
10231db90:     	bl	0x103a03c0c <__RNvNtCsgDHHaSskbIF_4core6option13expect_failed>
10231db94:     	b	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231db98:     	add	x0, sp, #0x338
10231db9c:     	b	0x10231dab0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x860>
10231dba0:     	mov	x25, x11
10231dba4:     	cmp	x8, #0x0
10231dba8:     	str	x17, [sp, #0x70]
10231dbac:     	csel	x1, xzr, x17, eq
10231dbb0:     	add	x8, sp, #0x990
10231dbb4:     	mov	x2, x24
10231dbb8:     	mov	x3, x22
10231dbbc:     	bl	0x102592814 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine10intrinsics16sequence_buffers8geometry>
10231dbc0:     	ldr	x8, [sp, #0x990]
10231dbc4:     	cmp	x8, #0x2
10231dbc8:     	b.ne	0x10231dd40 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xaf0>
10231dbcc:     	str	x25, [sp, #0x8]
10231dbd0:     	add	x9, sp, #0x990
10231dbd4:     	ldr	x8, [sp, #0x9a8]
10231dbd8:     	ldur	q0, [x9, #0x8]
10231dbdc:     	str	q0, [sp, #0x380]
10231dbe0:     	str	x8, [sp, #0x390]
10231dbe4:     	ldr	x11, [sp, #0x250]
10231dbe8:     	ldr	x8, [x11]
10231dbec:     	ldr	x9, [x8, #0x10]
10231dbf0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10231dbf4:     	cmp	x9, x10
10231dbf8:     	b.hs	0x10231e30c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x10bc>
10231dbfc:     	str	x11, [sp, #0x40]
10231dc00:     	stp	x23, x24, [sp, #0x18]
10231dc04:     	str	w21, [sp, #0x2c]
10231dc08:     	ldr	x9, [sp, #0x388]
10231dc0c:     	str	x9, [sp, #0x10]
10231dc10:     	ldr	x9, [sp, #0x280]
10231dc14:     	ldr	x10, [sp, #0x288]
10231dc18:     	ldr	x11, [x9]
10231dc1c:     	str	x11, [sp, #0x58]
10231dc20:     	ldrb	w23, [x9, #0x8]
10231dc24:     	ldrb	w11, [x9, #0xb]
10231dc28:     	str	w11, [sp, #0x54]
10231dc2c:     	ldurh	w11, [x9, #0x9]
10231dc30:     	stp	w26, w11, [sp, #0x4c]
10231dc34:     	ldr	w21, [x9, #0xc]
10231dc38:     	ldr	x22, [x10, #0x30]
10231dc3c:     	ldr	x28, [x10, #0x50]
10231dc40:     	ldp	x11, x8, [x8, #0x38]
10231dc44:     	stp	x8, x11, [sp, #0x30]
10231dc48:     	ldp	q0, q1, [x9, #0x10]
10231dc4c:     	str	q0, [sp, #0x540]
10231dc50:     	str	q1, [sp, #0x550]
10231dc54:     	ldp	q0, q1, [x9, #0x70]
10231dc58:     	str	q0, [sp, #0x9d0]
10231dc5c:     	str	q1, [sp, #0x9e0]
10231dc60:     	ldr	q0, [x9, #0x90]
10231dc64:     	str	q0, [sp, #0x9f0]
10231dc68:     	ldr	x8, [x9, #0xa0]
10231dc6c:     	str	x8, [sp, #0xa00]
10231dc70:     	ldp	q0, q1, [x9, #0x30]
10231dc74:     	str	q0, [sp, #0x990]
10231dc78:     	str	q1, [sp, #0x9a0]
10231dc7c:     	ldp	q0, q1, [x9, #0x50]
10231dc80:     	str	q0, [sp, #0x9b0]
10231dc84:     	str	q1, [sp, #0x9c0]
10231dc88:     	ldp	q0, q1, [x10]
10231dc8c:     	str	q0, [sp, #0x740]
10231dc90:     	str	q1, [sp, #0x750]
10231dc94:     	ldr	q0, [x10, #0x20]
10231dc98:     	str	q0, [sp, #0x760]
10231dc9c:     	ldur	q0, [x10, #0x38]
10231dca0:     	str	q0, [sp, #0x5b0]
10231dca4:     	ldr	x8, [x10, #0x48]
10231dca8:     	str	x8, [sp, #0x5c0]
10231dcac:     	ldur	q0, [x10, #0x58]
10231dcb0:     	str	q0, [sp, #0x500]
10231dcb4:     	ldr	x8, [sp, #0x90]
10231dcb8:     	ldr	x9, [sp, #0x80]
10231dcbc:     	adds	x25, x9, x8
10231dcc0:     	b.hs	0x10231e220 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfd0>
10231dcc4:     	mov	w26, #0x2c              ; =44
10231dcc8:     	strb	w26, [sp, #0x860]
10231dccc:     	add	x0, sp, #0x860
10231dcd0:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231dcd4:     	ldr	x8, [sp, #0x88]
10231dcd8:     	ldr	x9, [sp, #0x78]
10231dcdc:     	adds	x24, x9, x8
10231dce0:     	b.hs	0x10231e220 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfd0>
10231dce4:     	strb	w26, [sp, #0x860]
10231dce8:     	add	x0, sp, #0x860
10231dcec:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231dcf0:     	adds	x8, x22, x25
10231dcf4:     	b.hs	0x10231e234 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfe4>
10231dcf8:     	adds	x9, x28, x24
10231dcfc:     	b.hs	0x10231e234 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfe4>
10231dd00:     	ldr	q0, [sp, #0x540]
10231dd04:     	ldr	q1, [sp, #0x550]
10231dd08:     	ldp	w11, w10, [sp, #0x50]
10231dd0c:     	orr	w24, w11, w10, lsl #16
10231dd10:     	str	q0, [sp, #0x650]
10231dd14:     	str	q1, [sp, #0x660]
10231dd18:     	ldr	x13, [sp, #0x58]
10231dd1c:     	cmp	x13, #0x2
10231dd20:     	b.ne	0x10231dd9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb4c>
10231dd24:     	ldr	q0, [sp, #0x650]
10231dd28:     	ldr	q1, [sp, #0x660]
10231dd2c:     	stp	q0, q1, [x29, #-0xb0]
10231dd30:     	stp	q0, q1, [sp, #0x230]
10231dd34:     	mov	w22, #0x29              ; =41
10231dd38:     	ldr	w26, [sp, #0x4c]
10231dd3c:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231dd40:     	ldr	q0, [sp, #0xa10]
10231dd44:     	ldr	q1, [sp, #0xa20]
10231dd48:     	str	q0, [sp, #0x420]
10231dd4c:     	str	q1, [sp, #0x430]
10231dd50:     	ldr	q0, [sp, #0xa30]
10231dd54:     	str	q0, [sp, #0x440]
10231dd58:     	ldr	q0, [sp, #0x9d0]
10231dd5c:     	ldr	q1, [sp, #0x9e0]
10231dd60:     	stp	q0, q1, [sp, #0x3e0]
10231dd64:     	ldr	q0, [sp, #0xa00]
10231dd68:     	ldr	q1, [sp, #0x9f0]
10231dd6c:     	str	q0, [sp, #0x410]
10231dd70:     	str	q1, [sp, #0x400]
10231dd74:     	ldr	q0, [sp, #0x990]
10231dd78:     	ldr	q1, [sp, #0x9a0]
10231dd7c:     	stp	q0, q1, [sp, #0x3a0]
10231dd80:     	ldr	q0, [sp, #0x9c0]
10231dd84:     	ldr	q1, [sp, #0x9b0]
10231dd88:     	stp	q1, q0, [sp, #0x3c0]
10231dd8c:     	add	x0, sp, #0x3a0
10231dd90:     	bl	0x10233d418 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core5error9MechErrorECs1qJAwyMG1lC_11mech_engine>
10231dd94:     	mov	w22, #0x2c              ; =44
10231dd98:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231dd9c:     	add	x10, sp, #0x3a0
10231dda0:     	ldr	q0, [sp, #0x9d0]
10231dda4:     	ldr	q1, [sp, #0x9e0]
10231dda8:     	str	q0, [sp, #0x410]
10231ddac:     	str	q1, [sp, #0x420]
10231ddb0:     	ldr	q0, [sp, #0x9f0]
10231ddb4:     	str	q0, [sp, #0x430]
10231ddb8:     	add	x11, sp, #0x3a0
10231ddbc:     	add	x11, x11, #0x108
10231ddc0:     	ldr	q0, [sp, #0x500]
10231ddc4:     	str	q0, [x11]
10231ddc8:     	ldr	x11, [sp, #0xa00]
10231ddcc:     	ldr	q0, [sp, #0x990]
10231ddd0:     	ldr	q1, [sp, #0x9a0]
10231ddd4:     	stp	q0, q1, [sp, #0x3d0]
10231ddd8:     	ldr	q0, [sp, #0x9b0]
10231dddc:     	ldr	q1, [sp, #0x9c0]
10231dde0:     	stp	q0, q1, [sp, #0x3f0]
10231dde4:     	ldr	q0, [sp, #0x740]
10231dde8:     	ldr	q1, [sp, #0x750]
10231ddec:     	ldr	q2, [sp, #0x760]
10231ddf0:     	str	q2, [sp, #0x470]
10231ddf4:     	str	q1, [sp, #0x460]
10231ddf8:     	str	q0, [sp, #0x450]
10231ddfc:     	ldr	q0, [sp, #0x5b0]
10231de00:     	stur	q0, [x10, #0xe8]
10231de04:     	sturh	w24, [x10, #0x9]
10231de08:     	ldr	x10, [sp, #0x5c0]
10231de0c:     	lsr	w12, w24, #16
10231de10:     	strb	w12, [sp, #0x3ab]
10231de14:     	str	w21, [sp, #0x3ac]
10231de18:     	ldr	q0, [sp, #0x540]
10231de1c:     	ldr	q1, [sp, #0x550]
10231de20:     	stp	q0, q1, [sp, #0x3b0]
10231de24:     	str	x13, [sp, #0x3a0]
10231de28:     	strb	w23, [sp, #0x3a8]
10231de2c:     	str	x11, [sp, #0x440]
10231de30:     	ldr	x11, [sp, #0x40]
10231de34:     	str	x11, [sp, #0x448]
10231de38:     	str	x10, [sp, #0x498]
10231de3c:     	str	x8, [sp, #0x480]
10231de40:     	str	x9, [sp, #0x4a0]
10231de44:     	ldp	x8, x9, [sp, #0x30]
10231de48:     	str	x9, [sp, #0x4b8]
10231de4c:     	str	x8, [sp, #0x4c0]
10231de50:     	str	xzr, [sp, #0x4c8]
10231de54:     	mov	w8, #0x1a               ; =26
10231de58:     	mov	w28, #0x1               ; =1
10231de5c:     	str	w8, [sp, #0x4d0]
10231de60:     	add	x0, sp, #0x990
10231de64:     	add	x1, sp, #0x3a0
10231de68:     	mov	x2, #0x0                ; =0
10231de6c:     	mov	x3, #0x0                ; =0
10231de70:     	mov	x4, #0x0                ; =0
10231de74:     	mov	x5, #0x0                ; =0
10231de78:     	bl	0x1023625c8 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
10231de7c:     	ldrb	w8, [sp, #0x990]
10231de80:     	cmp	w8, #0x8
10231de84:     	b.ne	0x10231e044 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xdf4>
10231de88:     	ldr	x8, [sp, #0x258]
10231de8c:     	ldr	x8, [x8, #0x190]
10231de90:     	ldp	x9, x21, [x8, #0x10]
10231de94:     	mov	w8, #0x2c               ; =44
10231de98:     	strb	w8, [sp, #0x990]
10231de9c:     	cmp	x9, #0x1
10231dea0:     	b.ne	0x10231df24 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xcd4>
10231dea4:     	add	x0, sp, #0x990
10231dea8:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231deac:     	ldr	x8, [sp, #0x258]
10231deb0:     	ldr	x8, [x8, #0x1a8]
10231deb4:     	adds	x8, x8, x21
10231deb8:     	b.hs	0x10231def8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xca8>
10231debc:     	mov	w9, #0x2c               ; =44
10231dec0:     	strb	w9, [sp, #0x990]
10231dec4:     	cmn	x8, #0x1, lsl #12       ; =0x1000
10231dec8:     	b.hs	0x10231def8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xca8>
10231decc:     	add	x21, x8, #0x1, lsl #12  ; =0x1000
10231ded0:     	add	x0, sp, #0x990
10231ded4:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231ded8:     	lsr	x8, x21, #60
10231dedc:     	cbnz	x8, 0x10231def8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xca8>
10231dee0:     	ldr	x8, [sp, #0x258]
10231dee4:     	ldr	x8, [x8, #0x1c8]
10231dee8:     	adds	x22, x8, x21, lsl #4
10231deec:     	mov	w8, #0x2c               ; =44
10231def0:     	strb	w8, [sp, #0x990]
10231def4:     	b.lo	0x10231dfa4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xd54>
10231def8:     	mov	w24, #0x0               ; =0
10231defc:     	mov	w21, #0x0               ; =0
10231df00:     	ldr	q0, [sp, #0x9a0]
10231df04:     	ldr	q1, [sp, #0x9b0]
10231df08:     	stp	q0, q1, [sp, #0x230]
10231df0c:     	b	0x10231df2c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xcdc>
10231df10:     	mov	w24, #0x0               ; =0
10231df14:     	mov	w21, #0x0               ; =0
10231df18:     	mov	w22, #0x2d              ; =45
10231df1c:     	mov	x26, x25
10231df20:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231df24:     	mov	w24, #0x0               ; =0
10231df28:     	mov	w21, #0x0               ; =0
10231df2c:     	mov	w22, #0x2c              ; =44
10231df30:     	ldr	x8, [sp, #0x2d8]
10231df34:     	mov	x9, #-0x1               ; =-1
10231df38:     	ldaddl	x9, x8, [x8]
10231df3c:     	cmp	x8, #0x1
10231df40:     	b.eq	0x10231e078 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe28>
10231df44:     	b	0x10231e084 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe34>
10231df48:     	ldr	q0, [sp, #0xa10]
10231df4c:     	ldr	q1, [sp, #0xa20]
10231df50:     	str	q0, [sp, #0x420]
10231df54:     	str	q1, [sp, #0x430]
10231df58:     	ldr	q0, [sp, #0xa30]
10231df5c:     	str	q0, [sp, #0x440]
10231df60:     	ldr	q0, [sp, #0x9d0]
10231df64:     	ldr	q1, [sp, #0x9e0]
10231df68:     	stp	q0, q1, [sp, #0x3e0]
10231df6c:     	ldr	q0, [sp, #0xa00]
10231df70:     	ldr	q1, [sp, #0x9f0]
10231df74:     	str	q0, [sp, #0x410]
10231df78:     	str	q1, [sp, #0x400]
10231df7c:     	ldr	q0, [sp, #0x990]
10231df80:     	ldr	q1, [sp, #0x9a0]
10231df84:     	stp	q0, q1, [sp, #0x3a0]
10231df88:     	ldr	q0, [sp, #0x9c0]
10231df8c:     	ldr	q1, [sp, #0x9b0]
10231df90:     	stp	q1, q0, [sp, #0x3c0]
10231df94:     	add	x0, sp, #0x3a0
10231df98:     	mov	x26, x25
10231df9c:     	bl	0x10233d418 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core5error9MechErrorECs1qJAwyMG1lC_11mech_engine>
10231dfa0:     	b	0x10231dd94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xb44>
10231dfa4:     	add	x0, sp, #0x990
10231dfa8:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231dfac:     	add	x8, sp, #0x990
10231dfb0:     	add	x0, sp, #0x3a0
10231dfb4:     	mov	x1, x22
10231dfb8:     	mov	x2, #0x0                ; =0
10231dfbc:     	bl	0x102362800 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
10231dfc0:     	ldrb	w8, [sp, #0x990]
10231dfc4:     	cmp	w8, #0x8
10231dfc8:     	b.ne	0x10231e044 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xdf4>
10231dfcc:     	ldr	x8, [sp, #0x258]
10231dfd0:     	ldr	x1, [x8, #0x1c0]
10231dfd4:     	add	x8, sp, #0x860
10231dfd8:     	add	x0, sp, #0x380
10231dfdc:     	bl	0x10258adf4 <__RNvMs_NtNtCs1qJAwyMG1lC_11mech_engine10intrinsics16sequence_buffersNtB4_8Geometry9footprint>
10231dfe0:     	ldr	x8, [sp, #0x860]
10231dfe4:     	cmp	x8, #0x2
10231dfe8:     	b.ne	0x10231e098 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe48>
10231dfec:     	ldr	x8, [sp, #0x870]
10231dff0:     	str	x8, [sp, #0x90]
10231dff4:     	ldr	x24, [sp, #0x878]
10231dff8:     	ldr	x8, [sp, #0x70]
10231dffc:     	ldp	q0, q1, [x8]
10231e000:     	ldp	q2, q3, [x8, #0x20]
10231e004:     	str	q3, [sp, #0x530]
10231e008:     	str	q2, [sp, #0x520]
10231e00c:     	str	q1, [sp, #0x510]
10231e010:     	str	q0, [sp, #0x500]
10231e014:     	mov	w8, #0x4                ; =4
10231e018:     	str	x8, [sp, #0x540]
10231e01c:     	ldr	w8, [sp, #0x2c]
10231e020:     	tbz	w8, #0x0, 0x10231e114 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xec4>
10231e024:     	mov	x25, #0x0               ; =0
10231e028:     	ldr	x8, [sp, #0x20]
10231e02c:     	ldr	x9, [sp, #0x68]
10231e030:     	mul	x8, x9, x8
10231e034:     	ldr	x9, [sp, #0x18]
10231e038:     	cmp	x9, #0x0
10231e03c:     	csel	x28, xzr, x8, eq
10231e040:     	b	0x10231e48c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x123c>
10231e044:     	ldr	w21, [sp, #0x994]
10231e048:     	ldr	w23, [sp, #0x990]
10231e04c:     	add	x8, sp, #0x990
10231e050:     	ldur	q0, [x8, #0x8]
10231e054:     	ldur	q1, [x8, #0x18]
10231e058:     	stp	q0, q1, [sp, #0x230]
10231e05c:     	lsr	w24, w23, #8
10231e060:     	mov	w22, #0x29              ; =41
10231e064:     	ldr	x8, [sp, #0x2d8]
10231e068:     	mov	x9, #-0x1               ; =-1
10231e06c:     	ldaddl	x9, x8, [x8]
10231e070:     	cmp	x8, #0x1
10231e074:     	b.ne	0x10231e084 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe34>
10231e078:     	dmb	ishld
10231e07c:     	add	x0, sp, #0x2d8
10231e080:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10231e084:     	cbz	w28, 0x10231d678 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x428>
10231e088:     	ldr	w26, [sp, #0x4c]
10231e08c:     	ldr	x8, [sp, #0x298]
10231e090:     	cbnz	x8, 0x10231d66c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x41c>
10231e094:     	b	0x10231d678 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x428>
10231e098:     	ldr	q0, [sp, #0x8e0]
10231e09c:     	ldr	q1, [sp, #0x8f0]
10231e0a0:     	str	q0, [sp, #0xa10]
10231e0a4:     	str	q1, [sp, #0xa20]
10231e0a8:     	ldr	q0, [sp, #0x900]
10231e0ac:     	str	q0, [sp, #0xa30]
10231e0b0:     	ldr	q0, [sp, #0x8a0]
10231e0b4:     	ldr	q1, [sp, #0x8b0]
10231e0b8:     	str	q0, [sp, #0x9d0]
10231e0bc:     	str	q1, [sp, #0x9e0]
10231e0c0:     	ldr	q0, [sp, #0x8d0]
10231e0c4:     	ldr	q1, [sp, #0x8c0]
10231e0c8:     	str	q0, [sp, #0xa00]
10231e0cc:     	str	q1, [sp, #0x9f0]
10231e0d0:     	ldr	q0, [sp, #0x860]
10231e0d4:     	ldr	q1, [sp, #0x870]
10231e0d8:     	str	q0, [sp, #0x990]
10231e0dc:     	str	q1, [sp, #0x9a0]
10231e0e0:     	ldr	q0, [sp, #0x890]
10231e0e4:     	ldr	q1, [sp, #0x880]
10231e0e8:     	str	q0, [sp, #0x9c0]
10231e0ec:     	str	q1, [sp, #0x9b0]
10231e0f0:     	add	x0, sp, #0x990
10231e0f4:     	bl	0x10233d418 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core5error9MechErrorECs1qJAwyMG1lC_11mech_engine>
10231e0f8:     	mov	w22, #0x2c              ; =44
10231e0fc:     	ldr	x8, [sp, #0x2d8]
10231e100:     	mov	x9, #-0x1               ; =-1
10231e104:     	ldaddl	x9, x8, [x8]
10231e108:     	cmp	x8, #0x1
10231e10c:     	b.eq	0x10231e078 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe28>
10231e110:     	b	0x10231e084 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe34>
10231e114:     	ldr	x8, [sp, #0x290]
10231e118:     	ldrb	w8, [x8]
10231e11c:     	cmp	w8, #0x1
10231e120:     	b.ne	0x10231e1c4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xf74>
10231e124:     	ldr	x8, [sp, #0x500]
10231e128:     	str	xzr, [sp, #0x500]
10231e12c:     	cbz	x8, 0x10231e1c4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xf74>
10231e130:     	add	x22, sp, #0x500
10231e134:     	ldur	q0, [x22, #0x8]
10231e138:     	stur	q0, [x22, #0xb8]
10231e13c:     	ldur	q0, [x22, #0x18]
10231e140:     	stur	q0, [x22, #0xc8]
10231e144:     	ldur	q0, [x22, #0x28]
10231e148:     	stur	q0, [x22, #0xd8]
10231e14c:     	ldr	x9, [sp, #0x538]
10231e150:     	str	x8, [sp, #0x5b0]
10231e154:     	str	x9, [sp, #0x5e8]
10231e158:     	mov	w26, #0x1               ; =1
10231e15c:     	add	x8, sp, #0x990
10231e160:     	add	x0, sp, #0x5b0
10231e164:     	add	x1, sp, #0x2d8
10231e168:     	mov	w9, #0x1                ; =1
10231e16c:     	str	w9, [sp, #0x88]
10231e170:     	bl	0x102e18018 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB6_5Value30try_into_owned_unsigned_matrix>
10231e174:     	ldr	x23, [sp, #0x990]
10231e178:     	ldr	x28, [sp, #0x998]
10231e17c:     	ldr	q0, [sp, #0x9a0]
10231e180:     	ldr	q1, [sp, #0x9b0]
10231e184:     	str	q0, [sp, #0x5f0]
10231e188:     	str	q1, [sp, #0x600]
10231e18c:     	ldr	x25, [sp, #0x9c0]
10231e190:     	cmp	x23, #0x5
10231e194:     	b.ne	0x10231e298 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1048>
10231e198:     	ldr	q0, [sp, #0x5f0]
10231e19c:     	ldr	q1, [sp, #0x600]
10231e1a0:     	lsr	w24, w28, #8
10231e1a4:     	lsr	x21, x28, #32
10231e1a8:     	stp	q0, q1, [sp, #0x230]
10231e1ac:     	mov	w22, #0x2b              ; =43
10231e1b0:     	mov	x23, x28
10231e1b4:     	ldr	x8, [sp, #0x540]
10231e1b8:     	cmp	x8, #0x4
10231e1bc:     	b.ne	0x10231ec34 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19e4>
10231e1c0:     	b	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231e1c4:     	mov	w23, #0x4               ; =4
10231e1c8:     	ldr	x8, [sp, #0x390]
10231e1cc:     	ldr	x9, [sp, #0x10]
10231e1d0:     	umulh	x9, x9, x8
10231e1d4:     	cmp	xzr, x9
10231e1d8:     	b.ne	0x10231e41c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x11cc>
10231e1dc:     	ldr	x9, [sp, #0x10]
10231e1e0:     	mul	x25, x9, x8
10231e1e4:     	cmp	x23, #0x1
10231e1e8:     	b.le	0x10231e458 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1208>
10231e1ec:     	cmp	x23, #0x2
10231e1f0:     	b.eq	0x10231e23c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfec>
10231e1f4:     	cmp	x23, #0x3
10231e1f8:     	b.ne	0x10231e248 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xff8>
10231e1fc:     	ldr	x8, [sp, #0x548]
10231e200:     	lsl	x22, x8, #3
10231e204:     	b	0x10231e46c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x121c>
10231e208:     	mov	x0, #0x0                ; =0
10231e20c:     	mov	x1, #0x0                ; =0
10231e210:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10231e214:     	add	x2, x2, #0x308
10231e218:     	bl	0x103a03cd8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10231e21c:     	b	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231e220:     	mov	w24, #0x0               ; =0
10231e224:     	mov	w21, #0x0               ; =0
10231e228:     	mov	w22, #0x2c              ; =44
10231e22c:     	ldr	w26, [sp, #0x4c]
10231e230:     	b	0x10231d644 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x3f4>
10231e234:     	mov	w23, #0x2               ; =2
10231e238:     	b	0x10231dd24 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xad4>
10231e23c:     	ldr	x8, [sp, #0x548]
10231e240:     	lsl	x22, x8, #2
10231e244:     	b	0x10231e46c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x121c>
10231e248:     	ldr	x8, [sp, #0x260]
10231e24c:     	ldrb	w8, [x8]
10231e250:     	cmp	w8, #0x5
10231e254:     	b.eq	0x10231e028 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xdd8>
10231e258:     	ldr	x8, [sp, #0x500]
10231e25c:     	cbz	x8, 0x10231e390 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1140>
10231e260:     	ldr	x8, [sp, #0x508]
10231e264:     	ldr	x0, [x8, #0x10]
10231e268:     	mov	w26, #0x1               ; =1
10231e26c:     	mov	w8, #0x1                ; =1
10231e270:     	str	w8, [sp, #0x88]
10231e274:     	bl	0x10235f46c <__RNCNCINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB9_25NativePreparedLibraryCall20unsigned_buffer_withNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueNCNvB6_28unsigned_buffer_with_sublist0E0sa_0Bh_>
10231e278:     	cmp	x0, #0x1
10231e27c:     	b.ne	0x10231e3b4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1164>
10231e280:     	ldr	x8, [sp, #0x20]
10231e284:     	mul	x22, x1, x8
10231e288:     	umulh	x8, x1, x8
10231e28c:     	cmp	xzr, x8
10231e290:     	cset	w8, ne
10231e294:     	b	0x10231e3bc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x116c>
10231e298:     	add	x8, sp, #0x990
10231e29c:     	ldur	q0, [x8, #0x38]
10231e2a0:     	ldur	q1, [x8, #0x48]
10231e2a4:     	str	q0, [sp, #0x610]
10231e2a8:     	str	q1, [sp, #0x620]
10231e2ac:     	ldur	q0, [x8, #0x58]
10231e2b0:     	str	q0, [sp, #0x630]
10231e2b4:     	ldr	x8, [sp, #0x9f8]
10231e2b8:     	str	x8, [sp, #0x640]
10231e2bc:     	cmp	x23, #0x4
10231e2c0:     	b.ne	0x10231e31c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x10cc>
10231e2c4:     	add	x8, sp, #0x500
10231e2c8:     	orr	x22, x8, #0x8
10231e2cc:     	ldr	x8, [sp, #0x500]
10231e2d0:     	cbz	x8, 0x10231e2dc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x108c>
10231e2d4:     	add	x0, sp, #0x500
10231e2d8:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231e2dc:     	ldr	q0, [sp, #0x5f0]
10231e2e0:     	ldr	q1, [sp, #0x600]
10231e2e4:     	stp	q0, q1, [x22]
10231e2e8:     	str	x28, [sp, #0x500]
10231e2ec:     	str	x25, [sp, #0x528]
10231e2f0:     	ldr	q0, [sp, #0x610]
10231e2f4:     	str	q0, [sp, #0x530]
10231e2f8:     	ldr	x23, [sp, #0x540]
10231e2fc:     	cmp	x23, #0x4
10231e300:     	b.eq	0x10231e1c8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xf78>
10231e304:     	ldr	x28, [sp, #0x548]
10231e308:     	b	0x10231e36c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x111c>
10231e30c:     	adrp	x0, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
10231e310:     	add	x0, x0, #0x3f0
10231e314:     	bl	0x103a03bdc <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10231e318:     	b	0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231e31c:     	ldr	x8, [sp, #0x540]
10231e320:     	cmp	x8, #0x4
10231e324:     	b.eq	0x10231e330 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x10e0>
10231e328:     	add	x0, sp, #0x540
10231e32c:     	bl	0x102341b74 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
10231e330:     	ldr	q0, [sp, #0x5f0]
10231e334:     	ldr	q1, [sp, #0x600]
10231e338:     	str	q0, [sp, #0x550]
10231e33c:     	str	q1, [sp, #0x560]
10231e340:     	ldr	q0, [sp, #0x610]
10231e344:     	ldr	q1, [sp, #0x620]
10231e348:     	stur	q0, [x22, #0x78]
10231e34c:     	str	x23, [sp, #0x540]
10231e350:     	str	x28, [sp, #0x548]
10231e354:     	stur	q1, [x22, #0x88]
10231e358:     	ldr	q0, [sp, #0x630]
10231e35c:     	stur	q0, [x22, #0x98]
10231e360:     	ldr	x8, [sp, #0x640]
10231e364:     	str	x25, [sp, #0x570]
10231e368:     	str	x8, [sp, #0x5a8]
10231e36c:     	cmp	x23, #0x1
10231e370:     	b.gt	0x10231e380 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1130>
10231e374:     	cbz	x23, 0x10231e39c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x114c>
10231e378:     	lsl	x28, x28, #1
10231e37c:     	b	0x10231e39c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x114c>
10231e380:     	cmp	x23, #0x2
10231e384:     	b.ne	0x10231e398 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1148>
10231e388:     	lsl	x28, x28, #2
10231e38c:     	b	0x10231e39c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x114c>
10231e390:     	mov	x22, #0x0               ; =0
10231e394:     	b	0x10231e3bc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x116c>
10231e398:     	lsl	x28, x28, #3
10231e39c:     	ldr	x8, [sp, #0x20]
10231e3a0:     	ldr	x9, [sp, #0x10]
10231e3a4:     	mul	x8, x9, x8
10231e3a8:     	cmp	x28, x8
10231e3ac:     	b.hs	0x10231e024 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xdd4>
10231e3b0:     	b	0x10231e1c8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xf78>
10231e3b4:     	mov	x22, #0x0               ; =0
10231e3b8:     	mov	w8, #0x0                ; =0
10231e3bc:     	tbnz	w8, #0x0, 0x10231ece8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1a98>
10231e3c0:     	mov	w8, #0x2c               ; =44
10231e3c4:     	strb	w8, [sp, #0x990]
10231e3c8:     	add	x0, sp, #0x990
10231e3cc:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231e3d0:     	b	0x10231e46c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x121c>
10231e3d4:     	mov	x0, #0x0                ; =0
10231e3d8:     	mov	x1, #0x0                ; =0
10231e3dc:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10231e3e0:     	add	x2, x2, #0x320
10231e3e4:     	b	0x10231e218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfc8>
10231e3e8:     	mov	x0, #0x0                ; =0
10231e3ec:     	mov	x1, #0x0                ; =0
10231e3f0:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10231e3f4:     	add	x2, x2, #0x338
10231e3f8:     	b	0x10231e218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfc8>
10231e3fc:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10231e400:     	add	x2, x2, #0x350
10231e404:     	mov	w0, #0x1                ; =1
10231e408:     	b	0x10231e218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfc8>
10231e40c:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10231e410:     	add	x2, x2, #0x368
10231e414:     	mov	w0, #0x1                ; =1
10231e418:     	b	0x10231e218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xfc8>
10231e41c:     	mov	w26, #0x1               ; =1
10231e420:     	adrp	x0, 0x107677000 <_anon.2314c7dda7e7207dbb1e6612b9b2047f.479+0x2fe>
10231e424:     	add	x0, x0, #0xd2f
10231e428:     	add	x8, sp, #0x860
10231e42c:     	mov	w9, #0x1                ; =1
10231e430:     	str	w9, [sp, #0x88]
10231e434:     	mov	w1, #0x30               ; =48
10231e438:     	bl	0x10259275c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine10intrinsics16sequence_buffers7invalid>
10231e43c:     	ldr	x8, [sp, #0x860]
10231e440:     	cmp	x8, #0x2
10231e444:     	b.ne	0x10231ec6c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1a1c>
10231e448:     	ldr	x25, [sp, #0x868]
10231e44c:     	ldr	x23, [sp, #0x540]
10231e450:     	cmp	x23, #0x1
10231e454:     	b.gt	0x10231e1ec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xf9c>
10231e458:     	cbnz	x23, 0x10231e464 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1214>
10231e45c:     	ldr	x22, [sp, #0x548]
10231e460:     	b	0x10231e46c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x121c>
10231e464:     	ldr	x8, [sp, #0x548]
10231e468:     	lsl	x22, x8, #1
10231e46c:     	ldr	x8, [sp, #0x20]
10231e470:     	ldr	x9, [sp, #0x68]
10231e474:     	mul	x8, x9, x8
10231e478:     	ldr	x9, [sp, #0x18]
10231e47c:     	cmp	x9, #0x0
10231e480:     	csel	x8, xzr, x8, eq
10231e484:     	adds	x28, x22, x8
10231e488:     	b.hs	0x10231e868 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1618>
10231e48c:     	mov	w22, #0x2c              ; =44
10231e490:     	strb	w22, [sp, #0x990]
10231e494:     	add	x0, sp, #0x990
10231e498:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231e49c:     	adds	x23, x25, x21
10231e4a0:     	b.hs	0x10231e868 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1618>
10231e4a4:     	strb	w22, [sp, #0x990]
10231e4a8:     	add	x0, sp, #0x990
10231e4ac:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231e4b0:     	cmn	x24, #0x9
10231e4b4:     	b.hi	0x10231e868 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1618>
10231e4b8:     	mov	w8, #0x2c               ; =44
10231e4bc:     	strb	w8, [sp, #0x990]
10231e4c0:     	add	x0, sp, #0x990
10231e4c4:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231e4c8:     	mov	w26, #0x1               ; =1
10231e4cc:     	add	x0, sp, #0x860
10231e4d0:     	add	x1, sp, #0x3a0
10231e4d4:     	add	x5, x24, #0x8
10231e4d8:     	mov	w8, #0x1                ; =1
10231e4dc:     	str	w8, [sp, #0x88]
10231e4e0:     	mov	x2, #0x0                ; =0
10231e4e4:     	mov	x3, #0x0                ; =0
10231e4e8:     	mov	x4, x23
10231e4ec:     	bl	0x1023625c8 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
10231e4f0:     	add	x24, sp, #0x7f8
10231e4f4:     	ldrb	w8, [sp, #0x860]
10231e4f8:     	cmp	w8, #0x8
10231e4fc:     	b.ne	0x10231e698 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1448>
10231e500:     	ldr	x21, [sp, #0x380]
10231e504:     	movi.2d	v0, #0000000000000000
10231e508:     	str	q0, [sp, #0x670]
10231e50c:     	str	q0, [sp, #0x680]
10231e510:     	str	x28, [sp, #0x690]
10231e514:     	str	xzr, [sp, #0x698]
10231e518:     	str	xzr, [sp, #0x6a0]
10231e51c:     	str	x21, [sp, #0x6a8]
10231e520:     	str	wzr, [sp, #0x6b0]
10231e524:     	str	q0, [sp, #0x650]
10231e528:     	str	q0, [sp, #0x660]
10231e52c:     	ldr	x8, [sp, #0x258]
10231e530:     	ldr	x4, [sp, #0x280]
10231e534:     	ldr	w8, [x8, #0x110]
10231e538:     	mov	w9, #0x3                ; =3
10231e53c:     	orr	x1, x9, x8, lsl #32
10231e540:     	add	x0, sp, #0x990
10231e544:     	add	x2, sp, #0x650
10231e548:     	ldr	x3, [sp, #0x90]
10231e54c:     	bl	0x1023450d0 <__RINvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget30visit_memory_budget_violationsNtB2_21MemoryBudgetViolationNcNtINtNtNtCsgDHHaSskbIF_4core3ops12control_flow11ControlFlowB1k_E5Break0ECs1qJAwyMG1lC_11mech_engine>
10231e550:     	ldrb	w8, [sp, #0x990]
10231e554:     	cmp	w8, #0x8
10231e558:     	b.ne	0x10231e6b8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1468>
10231e55c:     	lsr	x8, x28, #61
10231e560:     	cbnz	x8, 0x10231e6d4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1484>
10231e564:     	mov	w8, #0x2c               ; =44
10231e568:     	strb	w8, [sp, #0x990]
10231e56c:     	mov	x8, #-0x81              ; =-129
10231e570:     	movk	x8, #0x1fff, lsl #48
10231e574:     	cmp	x28, x8
10231e578:     	b.hi	0x10231e6d4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1484>
10231e57c:     	lsl	x22, x28, #3
10231e580:     	add	x0, sp, #0x990
10231e584:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231e588:     	add	x8, sp, #0x860
10231e58c:     	add	x0, sp, #0x3a0
10231e590:     	add	x1, x22, #0x400
10231e594:     	mov	w9, #0x1                ; =1
10231e598:     	str	w9, [sp, #0x88]
10231e59c:     	mov	x2, #0x0                ; =0
10231e5a0:     	bl	0x102362800 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
10231e5a4:     	ldrb	w8, [sp, #0x860]
10231e5a8:     	cmp	w8, #0x8
10231e5ac:     	b.ne	0x10231e698 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1448>
10231e5b0:     	add	x8, sp, #0x990
10231e5b4:     	add	x0, sp, #0x2d8
10231e5b8:     	mov	w9, #0x1                ; =1
10231e5bc:     	str	w9, [sp, #0x88]
10231e5c0:     	mov	x1, x23
10231e5c4:     	bl	0x102d53840 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
10231e5c8:     	ldr	w23, [sp, #0x990]
10231e5cc:     	cmp	w23, #0x1a
10231e5d0:     	b.ne	0x10231e6f4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x14a4>
10231e5d4:     	add	x8, sp, #0x990
10231e5d8:     	ldur	q0, [x8, #0x18]
10231e5dc:     	ldur	q1, [x8, #0x8]
10231e5e0:     	str	q1, [sp, #0x6c0]
10231e5e4:     	str	q0, [sp, #0x6d0]
10231e5e8:     	ldr	x9, [sp, #0x258]
10231e5ec:     	mov	w8, #0x1                ; =1
10231e5f0:     	str	x8, [sp, #0x990]
10231e5f4:     	str	x21, [sp, #0x998]
10231e5f8:     	add	x8, sp, #0x6e8
10231e5fc:     	add	x0, x9, #0x20
10231e600:     	add	x1, sp, #0x990
10231e604:     	mov	w2, #0x2                ; =2
10231e608:     	bl	0x102dae9d4 <__RNvNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value26shape_for_resolved_extents>
10231e60c:     	ldr	x8, [sp, #0x6e8]
10231e610:     	cmp	x8, #0x2
10231e614:     	b.ne	0x10231e71c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x14cc>
10231e618:     	ldr	x8, [sp, #0x6f0]
10231e61c:     	str	x8, [sp, #0x80]
10231e620:     	ldr	x8, [sp, #0x6f8]
10231e624:     	str	x8, [sp, #0x90]
10231e628:     	ldr	w8, [sp, #0x2c]
10231e62c:     	tbz	w8, #0x0, 0x10231e72c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x14dc>
10231e630:     	ldr	x8, [sp, #0x500]
10231e634:     	cbz	x8, 0x10231e838 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x15e8>
10231e638:     	mov	w8, #0x2c               ; =44
10231e63c:     	strb	w8, [sp, #0x990]
10231e640:     	add	x0, sp, #0x990
10231e644:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10231e648:     	ldr	w11, [sp, #0x538]
10231e64c:     	ldr	x8, [sp, #0x500]
10231e650:     	mov	w9, #0x1                ; =1
10231e654:     	ldadd	x9, x9, [x8]
10231e658:     	tbnz	x9, #0x3f, 0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231e65c:     	ldr	x9, [sp, #0x508]
10231e660:     	mov	w10, #0x1               ; =1
10231e664:     	ldadd	x10, x10, [x9]
10231e668:     	tbnz	x10, #0x3f, 0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231e66c:     	ldr	x10, [sp, #0x530]
10231e670:     	cbz	x10, 0x10231e680 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1430>
10231e674:     	mov	w12, #0x1               ; =1
10231e678:     	ldadd	x12, x12, [x10]
10231e67c:     	tbnz	x12, #0x3f, 0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231e680:     	ldr	q0, [sp, #0x510]
10231e684:     	ldr	q1, [sp, #0x520]
10231e688:     	str	q0, [sp, #0x840]
10231e68c:     	str	q1, [sp, #0x850]
10231e690:     	fmov	s0, w11
10231e694:     	b	0x10231e9b0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1760>
10231e698:     	ldr	w21, [sp, #0x864]
10231e69c:     	ldr	w23, [sp, #0x860]
10231e6a0:     	ldp	q0, q1, [x24, #0x70]
10231e6a4:     	stp	q0, q1, [sp, #0x230]
10231e6a8:     	lsr	w24, w23, #8
10231e6ac:     	mov	w22, #0x29              ; =41
10231e6b0:     	cbnz	w26, 0x10231ec28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19d8>
10231e6b4:     	b	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231e6b8:     	ldr	q0, [sp, #0x990]
10231e6bc:     	ldr	q1, [sp, #0x9a0]
10231e6c0:     	stp	q0, q1, [sp, #0x230]
10231e6c4:     	mov	w23, #0x12              ; =18
10231e6c8:     	mov	w22, #0x2a              ; =42
10231e6cc:     	cbnz	w26, 0x10231ec28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19d8>
10231e6d0:     	b	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231e6d4:     	mov	w24, #0x0               ; =0
10231e6d8:     	mov	w21, #0x0               ; =0
10231e6dc:     	ldr	q0, [sp, #0x9a0]
10231e6e0:     	ldr	q1, [sp, #0x9b0]
10231e6e4:     	stp	q0, q1, [sp, #0x230]
10231e6e8:     	mov	w22, #0x2c              ; =44
10231e6ec:     	cbnz	w26, 0x10231ec28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19d8>
10231e6f0:     	b	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231e6f4:     	mov	w24, #0x0               ; =0
10231e6f8:     	ldr	w21, [sp, #0x994]
10231e6fc:     	add	x8, sp, #0x990
10231e700:     	ldur	q0, [x8, #0x8]
10231e704:     	str	q0, [sp, #0x860]
10231e708:     	ldur	q1, [x8, #0x18]
10231e70c:     	ldr	x25, [sp, #0x9b8]
10231e710:     	stp	q0, q1, [sp, #0x230]
10231e714:     	mov	w22, #0x2b              ; =43
10231e718:     	b	0x10231ec24 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19d4>
10231e71c:     	add	x0, sp, #0x6e8
10231e720:     	bl	0x10233f104 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system10diagnostic19TypeResolutionErrorECs1qJAwyMG1lC_11mech_engine>
10231e724:     	mov	w22, #0x2c              ; =44
10231e728:     	b	0x10231ec14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19c4>
10231e72c:     	ldr	x8, [sp, #0x540]
10231e730:     	cmp	x8, #0x4
10231e734:     	cset	w26, eq
10231e738:     	b.ne	0x10231e784 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1534>
10231e73c:     	ldr	x8, [sp, #0x260]
10231e740:     	ldr	x9, [sp, #0x268]
10231e744:     	ldrb	w0, [x8]
10231e748:     	ldr	x8, [sp, #0x500]
10231e74c:     	add	x10, sp, #0x500
10231e750:     	cmp	x8, #0x0
10231e754:     	csel	x1, xzr, x10, eq
10231e758:     	ldr	x3, [x9]
10231e75c:     	ldr	x8, [sp, #0x18]
10231e760:     	cbz	x8, 0x10231e884 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1634>
10231e764:     	ldr	x8, [sp, #0x270]
10231e768:     	ldr	x9, [x8]
10231e76c:     	cbz	x9, 0x10231e880 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1630>
10231e770:     	ldr	x9, [sp, #0x8]
10231e774:     	str	x9, [sp, #0x998]
10231e778:     	ldr	x9, [sp, #0x60]
10231e77c:     	str	x9, [sp, #0x9a0]
10231e780:     	b	0x10231e884 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1634>
10231e784:     	ldr	q0, [sp, #0x580]
10231e788:     	ldr	q1, [sp, #0x590]
10231e78c:     	str	q0, [sp, #0x780]
10231e790:     	str	q1, [sp, #0x790]
10231e794:     	ldr	q0, [sp, #0x5a0]
10231e798:     	str	q0, [sp, #0x7a0]
10231e79c:     	ldr	q0, [sp, #0x540]
10231e7a0:     	ldr	q1, [sp, #0x550]
10231e7a4:     	str	q0, [sp, #0x740]
10231e7a8:     	str	q1, [sp, #0x750]
10231e7ac:     	ldr	q0, [sp, #0x570]
10231e7b0:     	ldr	q1, [sp, #0x560]
10231e7b4:     	str	q0, [sp, #0x770]
10231e7b8:     	str	q1, [sp, #0x760]
10231e7bc:     	add	x8, sp, #0x990
10231e7c0:     	add	x0, sp, #0x740
10231e7c4:     	bl	0x102d80a34 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix10into_parts>
10231e7c8:     	ldr	q0, [sp, #0x990]
10231e7cc:     	ldr	q1, [sp, #0x9a0]
10231e7d0:     	str	q0, [sp, #0x860]
10231e7d4:     	str	q1, [sp, #0x870]
10231e7d8:     	ldr	q0, [sp, #0x9b0]
10231e7dc:     	ldr	q1, [sp, #0x9c0]
10231e7e0:     	str	q0, [sp, #0x7b0]
10231e7e4:     	str	q1, [sp, #0x7c0]
10231e7e8:     	add	x8, sp, #0x990
10231e7ec:     	add	x0, sp, #0x6c0
10231e7f0:     	add	x1, sp, #0x7b0
10231e7f4:     	bl	0x102d53eac <__RNvMs5_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservation14merge_capacity>
10231e7f8:     	ldr	w8, [sp, #0x990]
10231e7fc:     	cmp	w8, #0x1a
10231e800:     	b.ne	0x10231e848 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x15f8>
10231e804:     	ldr	x8, [sp, #0x260]
10231e808:     	ldr	x9, [sp, #0x268]
10231e80c:     	ldrb	w1, [x8]
10231e810:     	ldr	x3, [x9]
10231e814:     	ldr	x8, [sp, #0x18]
10231e818:     	cbz	x8, 0x10231e924 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x16d4>
10231e81c:     	ldr	x8, [sp, #0x270]
10231e820:     	ldr	x9, [x8]
10231e824:     	cbz	x9, 0x10231e920 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x16d0>
10231e828:     	ldr	x10, [sp, #0x8]
10231e82c:     	ldr	x9, [sp, #0x60]
10231e830:     	stp	x10, x9, [x29, #-0xa8]
10231e834:     	b	0x10231e924 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x16d4>
10231e838:     	mov	w24, #0x0               ; =0
10231e83c:     	mov	w21, #0x0               ; =0
10231e840:     	mov	w22, #0x2c              ; =44
10231e844:     	b	0x10231e91c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x16cc>
10231e848:     	add	x8, sp, #0x990
10231e84c:     	ldur	q0, [x8, #0x8]
10231e850:     	ldur	q1, [x8, #0x18]
10231e854:     	stp	q0, q1, [sp, #0x230]
10231e858:     	ldr	x23, [sp, #0x990]
10231e85c:     	ldr	x25, [sp, #0x9b8]
10231e860:     	mov	w22, #0x2b              ; =43
10231e864:     	b	0x10231ebe4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1994>
10231e868:     	mov	w24, #0x0               ; =0
10231e86c:     	mov	w21, #0x0               ; =0
10231e870:     	mov	w26, #0x1               ; =1
10231e874:     	mov	w22, #0x2c              ; =44
10231e878:     	cbnz	w26, 0x10231ec28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19d8>
10231e87c:     	b	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231e880:     	mov	x8, #0x0                ; =0
10231e884:     	str	x8, [sp, #0x990]
10231e888:     	add	x8, sp, #0x860
10231e88c:     	add	x2, sp, #0x380
10231e890:     	add	x4, sp, #0x990
10231e894:     	bl	0x1025916d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine10intrinsics16sequence_buffers24copy_buffer_with_sublist>
10231e898:     	ldr	x8, [sp, #0x860]
10231e89c:     	cmp	x8, #0x2
10231e8a0:     	b.ne	0x10231e8b4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1664>
10231e8a4:     	ldp	q1, q0, [x24, #0x70]
10231e8a8:     	str	q1, [sp, #0x7d0]
10231e8ac:     	str	q0, [sp, #0x7e0]
10231e8b0:     	b	0x10231e958 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1708>
10231e8b4:     	ldr	q0, [sp, #0x8e0]
10231e8b8:     	ldr	q1, [sp, #0x8f0]
10231e8bc:     	str	q0, [sp, #0xa10]
10231e8c0:     	str	q1, [sp, #0xa20]
10231e8c4:     	ldr	q0, [sp, #0x900]
10231e8c8:     	str	q0, [sp, #0xa30]
10231e8cc:     	ldr	q0, [sp, #0x8a0]
10231e8d0:     	ldr	q1, [sp, #0x8b0]
10231e8d4:     	str	q0, [sp, #0x9d0]
10231e8d8:     	str	q1, [sp, #0x9e0]
10231e8dc:     	ldr	q0, [sp, #0x8d0]
10231e8e0:     	ldr	q1, [sp, #0x8c0]
10231e8e4:     	str	q0, [sp, #0xa00]
10231e8e8:     	str	q1, [sp, #0x9f0]
10231e8ec:     	ldr	q0, [sp, #0x860]
10231e8f0:     	ldr	q1, [sp, #0x870]
10231e8f4:     	str	q0, [sp, #0x990]
10231e8f8:     	str	q1, [sp, #0x9a0]
10231e8fc:     	ldr	q0, [sp, #0x890]
10231e900:     	ldr	q1, [sp, #0x880]
10231e904:     	str	q0, [sp, #0x9c0]
10231e908:     	str	q1, [sp, #0x9b0]
10231e90c:     	add	x0, sp, #0x990
10231e910:     	bl	0x10233d418 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core5error9MechErrorECs1qJAwyMG1lC_11mech_engine>
10231e914:     	mov	w26, #0x1               ; =1
10231e918:     	mov	w22, #0x2c              ; =44
10231e91c:     	b	0x10231ebf8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19a8>
10231e920:     	mov	x8, #0x0                ; =0
10231e924:     	stur	x8, [x29, #-0xb0]
10231e928:     	add	x8, sp, #0x990
10231e92c:     	add	x0, sp, #0x860
10231e930:     	add	x2, sp, #0x380
10231e934:     	sub	x4, x29, #0xb0
10231e938:     	bl	0x1028ceb98 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffers6mutate>
10231e93c:     	ldrb	w8, [sp, #0x990]
10231e940:     	cmp	w8, #0x2e
10231e944:     	b.ne	0x10231ebcc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x197c>
10231e948:     	ldr	q0, [sp, #0x860]
10231e94c:     	ldr	q1, [sp, #0x870]
10231e950:     	str	q0, [sp, #0x7d0]
10231e954:     	str	q1, [sp, #0x7e0]
10231e958:     	ldr	x8, [sp, #0x258]
10231e95c:     	ldr	x4, [x8, #0x190]
10231e960:     	mov	w8, #0x1                ; =1
10231e964:     	ldadd	x8, x8, [x4]
10231e968:     	tbnz	x8, #0x3f, 0x10231eb9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x194c>
10231e96c:     	add	x8, sp, #0x7f8
10231e970:     	add	x3, sp, #0x7d0
10231e974:     	ldr	w0, [sp, #0x9c]
10231e978:     	ldr	x1, [sp, #0x80]
10231e97c:     	ldr	x2, [sp, #0x90]
10231e980:     	bl	0x102e17fb4 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrixNtB6_5Value27from_unsigned_matrix_buffer>
10231e984:     	ldrb	w8, [sp, #0x7f8]
10231e988:     	cmp	w8, #0x16
10231e98c:     	b.ne	0x10231ebc0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1970>
10231e990:     	ldr	x8, [sp, #0x800]
10231e994:     	ldr	x9, [sp, #0x808]
10231e998:     	ldur	q0, [x24, #0x18]
10231e99c:     	ldur	q1, [x24, #0x28]
10231e9a0:     	str	q0, [sp, #0x840]
10231e9a4:     	str	q1, [sp, #0x850]
10231e9a8:     	ldr	x10, [sp, #0x830]
10231e9ac:     	ldr	d0, [sp, #0x838]
10231e9b0:     	stp	x8, x9, [x29, #-0xb0]
10231e9b4:     	ldr	q1, [sp, #0x840]
10231e9b8:     	ldr	q2, [sp, #0x850]
10231e9bc:     	stp	q1, q2, [x29, #-0xa0]
10231e9c0:     	stur	x10, [x29, #-0x80]
10231e9c4:     	stur	d0, [x29, #-0x78]
10231e9c8:     	add	x8, sp, #0x6c0
10231e9cc:     	stur	x8, [x29, #-0x70]
10231e9d0:     	add	x0, sp, #0x990
10231e9d4:     	sub	x1, x29, #0xb0
10231e9d8:     	add	x2, sp, #0x6c0
10231e9dc:     	bl	0x10235fbf8 <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB6_25NativePreparedLibraryCall30unsigned_matrix_append_private0Be_>
10231e9e0:     	ldr	x28, [sp, #0x990]
10231e9e4:     	ldr	x22, [sp, #0x998]
10231e9e8:     	add	x8, sp, #0x990
10231e9ec:     	ldur	q0, [x8, #0x18]
10231e9f0:     	ldur	q1, [x8, #0x28]
10231e9f4:     	str	q0, [sp, #0x970]
10231e9f8:     	str	q1, [sp, #0x980]
10231e9fc:     	ldr	x23, [sp, #0x9a0]
10231ea00:     	ldr	x25, [sp, #0x9c8]
10231ea04:     	cbz	x28, 0x10231eba0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1950>
10231ea08:     	ldr	q0, [sp, #0xa70]
10231ea0c:     	ldr	q1, [sp, #0xa80]
10231ea10:     	str	q0, [sp, #0x940]
10231ea14:     	str	q1, [sp, #0x950]
10231ea18:     	ldr	x8, [sp, #0xa90]
10231ea1c:     	str	x8, [sp, #0x960]
10231ea20:     	ldr	q0, [sp, #0xa30]
10231ea24:     	ldr	q1, [sp, #0xa40]
10231ea28:     	str	q0, [sp, #0x900]
10231ea2c:     	str	q1, [sp, #0x910]
10231ea30:     	ldr	q0, [sp, #0xa60]
10231ea34:     	ldr	q1, [sp, #0xa50]
10231ea38:     	str	q0, [sp, #0x930]
10231ea3c:     	str	q1, [sp, #0x920]
10231ea40:     	ldr	q0, [sp, #0x9f0]
10231ea44:     	ldr	q1, [sp, #0xa00]
10231ea48:     	str	q0, [sp, #0x8c0]
10231ea4c:     	str	q1, [sp, #0x8d0]
10231ea50:     	ldr	q0, [sp, #0xa20]
10231ea54:     	ldr	q1, [sp, #0xa10]
10231ea58:     	str	q0, [sp, #0x8f0]
10231ea5c:     	str	q1, [sp, #0x8e0]
10231ea60:     	ldr	q0, [sp, #0x9e0]
10231ea64:     	ldr	q1, [sp, #0x9d0]
10231ea68:     	str	q0, [sp, #0x8b0]
10231ea6c:     	str	q1, [sp, #0x8a0]
10231ea70:     	ldr	q0, [sp, #0x970]
10231ea74:     	ldr	q1, [sp, #0x980]
10231ea78:     	stp	q0, q1, [x24, #0x80]
10231ea7c:     	str	x23, [sp, #0x870]
10231ea80:     	str	x25, [sp, #0x898]
10231ea84:     	str	x22, [sp, #0x868]
10231ea88:     	str	x28, [sp, #0x860]
10231ea8c:     	ldr	q0, [sp, #0x500]
10231ea90:     	ldr	q1, [sp, #0x510]
10231ea94:     	str	q0, [sp, #0x990]
10231ea98:     	str	q1, [sp, #0x9a0]
10231ea9c:     	ldr	q0, [sp, #0x520]
10231eaa0:     	ldr	q1, [sp, #0x530]
10231eaa4:     	str	q0, [sp, #0x9b0]
10231eaa8:     	str	q1, [sp, #0x9c0]
10231eaac:     	ldr	x8, [sp, #0x990]
10231eab0:     	cbz	x8, 0x10231eabc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x186c>
10231eab4:     	add	x0, sp, #0x990
10231eab8:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231eabc:     	add	x8, sp, #0x860
10231eac0:     	ldur	q0, [x8, #0x18]
10231eac4:     	ldur	q1, [x8, #0x28]
10231eac8:     	stp	q0, q1, [sp, #0x230]
10231eacc:     	ldp	q0, q1, [x8, #0xe0]
10231ead0:     	str	q0, [sp, #0xa30]
10231ead4:     	str	q1, [sp, #0xa40]
10231ead8:     	ldr	x9, [x8, #0x100]
10231eadc:     	str	x9, [sp, #0xa50]
10231eae0:     	ldp	q0, q1, [x8, #0xa0]
10231eae4:     	str	q0, [sp, #0x9f0]
10231eae8:     	str	q1, [sp, #0xa00]
10231eaec:     	ldp	q1, q0, [x8, #0xc0]
10231eaf0:     	str	q0, [sp, #0xa20]
10231eaf4:     	str	q1, [sp, #0xa10]
10231eaf8:     	ldp	q0, q1, [x8, #0x60]
10231eafc:     	str	q0, [sp, #0x9b0]
10231eb00:     	str	q1, [sp, #0x9c0]
10231eb04:     	ldp	q1, q0, [x8, #0x80]
10231eb08:     	str	q0, [sp, #0x9e0]
10231eb0c:     	str	q1, [sp, #0x9d0]
10231eb10:     	ldp	q1, q0, [x8, #0x40]
10231eb14:     	ldr	x8, [sp, #0x90]
10231eb18:     	cmp	x8, #0x0
10231eb1c:     	ldr	w8, [sp, #0x2c]
10231eb20:     	csel	w8, wzr, w8, eq
10231eb24:     	str	q0, [sp, #0x9a0]
10231eb28:     	str	q1, [sp, #0x990]
10231eb2c:     	tbz	w8, #0x0, 0x10231eb44 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x18f4>
10231eb30:     	ldr	x8, [sp, #0x90]
10231eb34:     	lsl	x1, x8, #3
10231eb38:     	ldr	x0, [sp, #0x80]
10231eb3c:     	mov	w2, #0x8                ; =8
10231eb40:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10231eb44:     	str	wzr, [sp, #0x88]
10231eb48:     	add	x0, sp, #0x6c0
10231eb4c:     	bl	0x10233f82c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
10231eb50:     	ldr	x8, [sp, #0x540]
10231eb54:     	cmp	x8, #0x4
10231eb58:     	eor	w8, w26, #0x1
10231eb5c:     	csinc	w8, w8, wzr, ne
10231eb60:     	tbnz	w8, #0x0, 0x10231eb6c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x191c>
10231eb64:     	add	x0, sp, #0x540
10231eb68:     	bl	0x102341b74 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
10231eb6c:     	ldr	x8, [sp, #0x2d8]
10231eb70:     	mov	x9, #-0x1               ; =-1
10231eb74:     	ldaddl	x9, x8, [x8]
10231eb78:     	cmp	x8, #0x1
10231eb7c:     	ldr	w26, [sp, #0x4c]
10231eb80:     	b.ne	0x10231eb90 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1940>
10231eb84:     	dmb	ishld
10231eb88:     	add	x0, sp, #0x2d8
10231eb8c:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10231eb90:     	lsr	x21, x23, #32
10231eb94:     	lsr	w24, w23, #8
10231eb98:     	b	0x10231d67c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x42c>
10231eb9c:     	brk	#0x1
10231eba0:     	lsr	w24, w23, #8
10231eba4:     	ldr	q0, [sp, #0x970]
10231eba8:     	ldr	q1, [sp, #0x980]
10231ebac:     	lsr	x21, x23, #32
10231ebb0:     	stp	q0, q1, [sp, #0x230]
10231ebb4:     	ldr	w8, [sp, #0x2c]
10231ebb8:     	tbnz	w8, #0x0, 0x10231ebf8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19a8>
10231ebbc:     	b	0x10231ec14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19c4>
10231ebc0:     	add	x0, sp, #0x7f8
10231ebc4:     	bl	0x10234107c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
10231ebc8:     	b	0x10231e724 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x14d4>
10231ebcc:     	ldr	x22, [sp, #0x990]
10231ebd0:     	ldr	x23, [sp, #0x998]
10231ebd4:     	ldr	q0, [sp, #0x9a0]
10231ebd8:     	ldr	q1, [sp, #0x9b0]
10231ebdc:     	stp	q0, q1, [sp, #0x230]
10231ebe0:     	ldr	x25, [sp, #0x9c0]
10231ebe4:     	add	x0, sp, #0x860
10231ebe8:     	bl	0x102341afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
10231ebec:     	mov	w26, #0x0               ; =0
10231ebf0:     	lsr	x21, x23, #32
10231ebf4:     	lsr	w24, w23, #8
10231ebf8:     	ldr	x8, [sp, #0x90]
10231ebfc:     	cbz	x8, 0x10231ec14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19c4>
10231ec00:     	ldr	x8, [sp, #0x90]
10231ec04:     	lsl	x1, x8, #3
10231ec08:     	ldr	x0, [sp, #0x80]
10231ec0c:     	mov	w2, #0x8                ; =8
10231ec10:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10231ec14:     	mov	w8, #0x1                ; =1
10231ec18:     	str	w8, [sp, #0x88]
10231ec1c:     	add	x0, sp, #0x6c0
10231ec20:     	bl	0x10233f82c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
10231ec24:     	cbz	w26, 0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231ec28:     	ldr	x8, [sp, #0x540]
10231ec2c:     	cmp	x8, #0x4
10231ec30:     	b.eq	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231ec34:     	add	x0, sp, #0x540
10231ec38:     	bl	0x102341b74 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
10231ec3c:     	ldr	x8, [sp, #0x500]
10231ec40:     	cbz	x8, 0x10231ec50 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1a00>
10231ec44:     	mov	w28, #0x0               ; =0
10231ec48:     	add	x0, sp, #0x500
10231ec4c:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231ec50:     	mov	w28, #0x0               ; =0
10231ec54:     	ldr	x8, [sp, #0x2d8]
10231ec58:     	mov	x9, #-0x1               ; =-1
10231ec5c:     	ldaddl	x9, x8, [x8]
10231ec60:     	cmp	x8, #0x1
10231ec64:     	b.eq	0x10231e078 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe28>
10231ec68:     	b	0x10231e084 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0xe34>
10231ec6c:     	ldr	q0, [sp, #0x8e0]
10231ec70:     	ldr	q1, [sp, #0x8f0]
10231ec74:     	str	q0, [sp, #0xa10]
10231ec78:     	str	q1, [sp, #0xa20]
10231ec7c:     	ldr	q0, [sp, #0x900]
10231ec80:     	str	q0, [sp, #0xa30]
10231ec84:     	ldr	q0, [sp, #0x8a0]
10231ec88:     	ldr	q1, [sp, #0x8b0]
10231ec8c:     	str	q0, [sp, #0x9d0]
10231ec90:     	str	q1, [sp, #0x9e0]
10231ec94:     	ldr	q0, [sp, #0x8d0]
10231ec98:     	ldr	q1, [sp, #0x8c0]
10231ec9c:     	str	q0, [sp, #0xa00]
10231eca0:     	str	q1, [sp, #0x9f0]
10231eca4:     	ldr	q0, [sp, #0x860]
10231eca8:     	ldr	q1, [sp, #0x870]
10231ecac:     	str	q0, [sp, #0x990]
10231ecb0:     	str	q1, [sp, #0x9a0]
10231ecb4:     	ldr	q0, [sp, #0x890]
10231ecb8:     	ldr	q1, [sp, #0x880]
10231ecbc:     	str	q0, [sp, #0x9c0]
10231ecc0:     	str	q1, [sp, #0x9b0]
10231ecc4:     	add	x0, sp, #0x990
10231ecc8:     	mov	w8, #0x1                ; =1
10231eccc:     	str	w8, [sp, #0x88]
10231ecd0:     	bl	0x10233d418 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core5error9MechErrorECs1qJAwyMG1lC_11mech_engine>
10231ecd4:     	mov	w22, #0x2c              ; =44
10231ecd8:     	ldr	x8, [sp, #0x540]
10231ecdc:     	cmp	x8, #0x4
10231ece0:     	b.ne	0x10231ec34 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19e4>
10231ece4:     	b	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231ece8:     	mov	w24, #0x0               ; =0
10231ecec:     	mov	w21, #0x0               ; =0
10231ecf0:     	mov	w22, #0x2c              ; =44
10231ecf4:     	ldr	x8, [sp, #0x540]
10231ecf8:     	cmp	x8, #0x4
10231ecfc:     	b.ne	0x10231ec34 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19e4>
10231ed00:     	b	0x10231ec3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x19ec>
10231ed04:     	mov	x20, x0
10231ed08:     	mov	w28, #0x0               ; =0
10231ed0c:     	b	0x10231ef20 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1cd0>
10231ed10:     	mov	x20, x0
10231ed14:     	add	x0, sp, #0x860
10231ed18:     	bl	0x102341c28 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
10231ed1c:     	str	wzr, [sp, #0x88]
10231ed20:     	b	0x10231ed4c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1afc>
10231ed24:     	mov	x20, x0
10231ed28:     	b	0x10231ee0c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bbc>
10231ed2c:     	mov	x20, x0
10231ed30:     	add	x0, sp, #0x860
10231ed34:     	bl	0x102341afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
10231ed38:     	mov	w26, #0x0               ; =0
10231ed3c:     	b	0x10231ed5c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1b0c>
10231ed40:     	mov	x20, x0
10231ed44:     	mov	w8, #0x1                ; =1
10231ed48:     	str	w8, [sp, #0x88]
10231ed4c:     	ldr	w8, [sp, #0x2c]
10231ed50:     	tbnz	w8, #0x0, 0x10231ed64 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1b14>
10231ed54:     	b	0x10231ee14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bc4>
10231ed58:     	mov	x20, x0
10231ed5c:     	mov	w8, #0x1                ; =1
10231ed60:     	str	w8, [sp, #0x88]
10231ed64:     	ldr	x8, [sp, #0x90]
10231ed68:     	cbz	x8, 0x10231ee14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bc4>
10231ed6c:     	ldr	x8, [sp, #0x90]
10231ed70:     	lsl	x1, x8, #3
10231ed74:     	ldr	x0, [sp, #0x80]
10231ed78:     	mov	w2, #0x8                ; =8
10231ed7c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10231ed80:     	b	0x10231ee14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bc4>
10231ed84:     	mov	x20, x0
10231ed88:     	ldr	q0, [sp, #0x5f0]
10231ed8c:     	ldr	q1, [sp, #0x600]
10231ed90:     	str	q0, [sp, #0x550]
10231ed94:     	str	q1, [sp, #0x560]
10231ed98:     	ldr	q0, [sp, #0x610]
10231ed9c:     	ldr	q1, [sp, #0x620]
10231eda0:     	stur	q0, [x22, #0x78]
10231eda4:     	str	x23, [sp, #0x540]
10231eda8:     	str	x28, [sp, #0x548]
10231edac:     	stur	q1, [x22, #0x88]
10231edb0:     	ldr	q0, [sp, #0x630]
10231edb4:     	stur	q0, [x22, #0x98]
10231edb8:     	ldr	x8, [sp, #0x640]
10231edbc:     	mov	w26, #0x1               ; =1
10231edc0:     	mov	w9, #0x1                ; =1
10231edc4:     	str	w9, [sp, #0x88]
10231edc8:     	str	x25, [sp, #0x570]
10231edcc:     	str	x8, [sp, #0x5a8]
10231edd0:     	b	0x10231ee2c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bdc>
10231edd4:     	mov	x20, x0
10231edd8:     	ldr	q0, [sp, #0x5f0]
10231eddc:     	ldr	q1, [sp, #0x600]
10231ede0:     	stp	q0, q1, [x22]
10231ede4:     	str	x28, [sp, #0x500]
10231ede8:     	str	x25, [sp, #0x528]
10231edec:     	ldr	q0, [sp, #0x610]
10231edf0:     	str	q0, [sp, #0x530]
10231edf4:     	mov	w26, #0x1               ; =1
10231edf8:     	mov	w8, #0x1                ; =1
10231edfc:     	str	w8, [sp, #0x88]
10231ee00:     	b	0x10231ee2c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bdc>
10231ee04:     	mov	x20, x0
10231ee08:     	mov	w26, #0x1               ; =1
10231ee0c:     	mov	w8, #0x1                ; =1
10231ee10:     	str	w8, [sp, #0x88]
10231ee14:     	add	x0, sp, #0x6c0
10231ee18:     	bl	0x10233f82c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
10231ee1c:     	b	0x10231ee2c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bdc>
10231ee20:     	mov	x20, x0
10231ee24:     	b	0x10231ee4c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bfc>
10231ee28:     	mov	x20, x0
10231ee2c:     	cbz	w26, 0x10231ee44 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bf4>
10231ee30:     	ldr	x8, [sp, #0x540]
10231ee34:     	cmp	x8, #0x4
10231ee38:     	b.eq	0x10231ee44 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1bf4>
10231ee3c:     	add	x0, sp, #0x540
10231ee40:     	bl	0x102341b74 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
10231ee44:     	ldr	w8, [sp, #0x88]
10231ee48:     	tbz	w8, #0x0, 0x10231ee5c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1c0c>
10231ee4c:     	ldr	x8, [sp, #0x500]
10231ee50:     	cbz	x8, 0x10231ee5c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1c0c>
10231ee54:     	add	x0, sp, #0x500
10231ee58:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231ee5c:     	mov	w28, #0x0               ; =0
10231ee60:     	b	0x10231ef20 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1cd0>
10231ee64:     	mov	x20, x0
10231ee68:     	ldp	x23, x22, [sp, #0xa0]
10231ee6c:     	ldr	w26, [sp, #0x4c]
10231ee70:     	tbnz	w28, #0x0, 0x10231ef74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d24>
10231ee74:     	b	0x10231ef88 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d38>
10231ee78:     	mov	x20, x0
10231ee7c:     	b	0x10231ef20 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1cd0>
10231ee80:     	mov	x20, x0
10231ee84:     	ldr	x8, [sp, #0x120]
10231ee88:     	cbz	x8, 0x10231efec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d9c>
10231ee8c:     	add	x8, sp, #0xc0
10231ee90:     	add	x0, x8, #0x60
10231ee94:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231ee98:     	b	0x10231efec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d9c>
10231ee9c:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10231eea0:     	mov	x20, x0
10231eea4:     	mov	w26, #0x0               ; =0
10231eea8:     	b	0x10231efc0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d70>
10231eeac:     	mov	x20, x0
10231eeb0:     	ldp	x23, x22, [sp, #0xa0]
10231eeb4:     	b	0x10231ef88 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d38>
10231eeb8:     	mov	x20, x0
10231eebc:     	ldr	x8, [sp, #0x208]
10231eec0:     	cbz	x8, 0x10231efec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d9c>
10231eec4:     	ldr	x9, [x8]
10231eec8:     	subs	x9, x9, #0x1
10231eecc:     	str	x9, [x8]
10231eed0:     	b.ne	0x10231efec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d9c>
10231eed4:     	add	x0, x26, #0x8
10231eed8:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
10231eedc:     	b	0x10231efec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d9c>
10231eee0:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10231eee4:     	mov	x20, x0
10231eee8:     	ldr	x8, [sp, #0x218]
10231eeec:     	cbz	x8, 0x10231ef08 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1cb8>
10231eef0:     	ldr	x9, [x8]
10231eef4:     	subs	x9, x9, #0x1
10231eef8:     	str	x9, [x8]
10231eefc:     	b.ne	0x10231ef08 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1cb8>
10231ef00:     	add	x0, x26, #0x8
10231ef04:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
10231ef08:     	mov	w26, #0x0               ; =0
10231ef0c:     	b	0x10231efc0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d70>
10231ef10:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10231ef14:     	str	w26, [sp, #0x4c]
10231ef18:     	mov	x20, x0
10231ef1c:     	mov	w28, #0x1               ; =1
10231ef20:     	ldr	x8, [sp, #0x2d8]
10231ef24:     	mov	x9, #-0x1               ; =-1
10231ef28:     	ldaddl	x9, x8, [x8]
10231ef2c:     	cmp	x8, #0x1
10231ef30:     	ldp	x23, x22, [sp, #0xa0]
10231ef34:     	ldr	w26, [sp, #0x4c]
10231ef38:     	b.ne	0x10231ef48 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1cf8>
10231ef3c:     	dmb	ishld
10231ef40:     	add	x0, sp, #0x2d8
10231ef44:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10231ef48:     	tbnz	w28, #0x0, 0x10231ef74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d24>
10231ef4c:     	b	0x10231ef88 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d38>
10231ef50:     	mov	x20, x0
10231ef54:     	ldr	x8, [x21, #0x10]
10231ef58:     	sub	x8, x8, #0x1
10231ef5c:     	str	x8, [x21, #0x10]
10231ef60:     	b	0x10231ef74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d24>
10231ef64:     	mov	x20, x0
10231ef68:     	b	0x10231ef90 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d40>
10231ef6c:     	mov	x20, x0
10231ef70:     	ldp	x23, x22, [sp, #0xa0]
10231ef74:     	ldr	x8, [sp, #0x298]
10231ef78:     	cbz	x8, 0x10231ef88 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d38>
10231ef7c:     	add	x8, sp, #0x250
10231ef80:     	add	x0, x8, #0x48
10231ef84:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231ef88:     	stp	x22, x27, [x19, #0x30]
10231ef8c:     	str	x23, [x19, #0x40]
10231ef90:     	add	x0, sp, #0x210
10231ef94:     	bl	0x1023425cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits10ScopeGuardEBS_>
10231ef98:     	b	0x10231efc0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d70>
10231ef9c:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10231efa0:     	mov	x20, x0
10231efa4:     	ldr	x8, [x21]
10231efa8:     	subs	x8, x8, #0x1
10231efac:     	str	x8, [x21]
10231efb0:     	b.ne	0x10231efbc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d6c>
10231efb4:     	add	x0, sp, #0x3a0
10231efb8:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
10231efbc:     	mov	w26, #0x1               ; =1
10231efc0:     	add	x0, sp, #0x200
10231efc4:     	bl	0x102342644 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits12AccountGuardEBS_>
10231efc8:     	tbnz	w26, #0x0, 0x10231efd8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d88>
10231efcc:     	b	0x10231efec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d9c>
10231efd0:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10231efd4:     	mov	x20, x0
10231efd8:     	ldr	x8, [sp, #0x1c0]
10231efdc:     	cbz	x8, 0x10231efec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_+0x1d9c>
10231efe0:     	add	x8, sp, #0x160
10231efe4:     	add	x0, x8, #0x60
10231efe8:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10231efec:     	mov	x0, x20
10231eff0:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
10231eff4:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
