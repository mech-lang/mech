
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023249f8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_>:
1023249f8:     	stp	x28, x27, [sp, #-0x60]!
1023249fc:     	stp	x26, x25, [sp, #0x10]
102324a00:     	stp	x24, x23, [sp, #0x20]
102324a04:     	stp	x22, x21, [sp, #0x30]
102324a08:     	stp	x20, x19, [sp, #0x40]
102324a0c:     	stp	x29, x30, [sp, #0x50]
102324a10:     	add	x29, sp, #0x50
102324a14:     	sub	sp, sp, #0x920
102324a18:     	str	xzr, [sp]
102324a1c:     	mov	x20, x8
102324a20:     	ldp	q0, q1, [x3, #0x40]
102324a24:     	add	x8, sp, #0x1
102324a28:     	stur	q0, [x8, #0xff]
102324a2c:     	add	x21, sp, #0xa8
102324a30:     	add	x8, sp, #0x11
102324a34:     	stur	q1, [x8, #0xff]
102324a38:     	ldp	q0, q1, [x3, #0x60]
102324a3c:     	stur	q0, [x21, #0x78]
102324a40:     	stur	q1, [x21, #0x88]
102324a44:     	ldp	q0, q1, [x3]
102324a48:     	stp	q0, q1, [sp, #0xc0]
102324a4c:     	ldp	q0, q1, [x3, #0x20]
102324a50:     	stp	q0, q1, [sp, #0xe0]
102324a54:     	stp	x1, x2, [sp, #0x98]
102324a58:     	add	x8, sp, #0x98
102324a5c:     	stp	x0, x8, [sp, #0xa8]
102324a60:     	add	x8, sp, #0xa0
102324a64:     	str	x8, [sp, #0xb8]
102324a68:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
102324a6c:     	add	x0, x0, #0x568
102324a70:     	ldr	x8, [x0]
102324a74:     	blr	x8
102324a78:     	mov	x19, x0
102324a7c:     	ldrb	w8, [x0, #0x48]
102324a80:     	cmp	w8, #0x1
102324a84:     	b.eq	0x102324ac0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc8>
102324a88:     	cmp	w8, #0x2
102324a8c:     	b.ne	0x102324aa8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xb0>
102324a90:     	add	x8, sp, #0xa8
102324a94:     	add	x0, x8, #0x20
102324a98:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102324a9c:     	adrp	x0, 0x108031000 <_anon.686517066f445f70c1782692b9896900.7+0x55f00>
102324aa0:     	add	x0, x0, #0xc40
102324aa4:     	bl	0x103a03528 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102324aa8:     	adrp	x1, 0x10283b000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy5_EB8_+0xa90>
102324aac:     	add	x1, x1, #0x2b4
102324ab0:     	mov	x0, x19
102324ab4:     	bl	0x102e71110 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102324ab8:     	mov	w8, #0x1                ; =1
102324abc:     	strb	w8, [x19, #0x48]
102324ac0:     	add	x28, sp, #0x140
102324ac4:     	add	x8, sp, #0x9
102324ac8:     	ldur	q0, [x8, #0xff]
102324acc:     	add	x8, sp, #0x19
102324ad0:     	ldur	q1, [x8, #0xff]
102324ad4:     	stur	q0, [x21, #0xf8]
102324ad8:     	add	x8, sp, #0x29
102324adc:     	ldur	q0, [x8, #0xff]
102324ae0:     	stp	q1, q0, [x28, #0x70]
102324ae4:     	ldr	x8, [sp, #0x138]
102324ae8:     	str	x8, [sp, #0x1d0]
102324aec:     	ldur	q0, [sp, #0xc8]
102324af0:     	ldur	q1, [sp, #0xd8]
102324af4:     	stp	q0, q1, [x28, #0x20]
102324af8:     	ldur	q0, [sp, #0xe8]
102324afc:     	ldur	q1, [sp, #0xf8]
102324b00:     	stp	q0, q1, [x28, #0x40]
102324b04:     	ldur	q0, [sp, #0xa8]
102324b08:     	ldur	q1, [sp, #0xb8]
102324b0c:     	stp	q0, q1, [x28]
102324b10:     	mov	x9, x19
102324b14:     	ldr	x8, [x9, #0x20]!
102324b18:     	cbnz	x8, 0x102325224 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x82c>
102324b1c:     	add	x21, sp, #0x6b0
102324b20:     	add	x25, sp, #0x2f0
102324b24:     	mov	x8, #-0x1               ; =-1
102324b28:     	str	x8, [x19, #0x20]
102324b2c:     	ldr	x11, [x19, #0x28]
102324b30:     	ldr	x8, [sp, #0x140]
102324b34:     	ldr	x10, [x8]
102324b38:     	cbz	x11, 0x102324b60 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x168>
102324b3c:     	cmp	x11, x10
102324b40:     	b.eq	0x102324b60 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x168>
102324b44:     	str	xzr, [x9]
102324b48:     	add	x8, sp, #0x140
102324b4c:     	add	x0, x8, #0x20
102324b50:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102324b54:     	mov	w22, #0x0               ; =0
102324b58:     	mov	w26, #0x3               ; =3
102324b5c:     	b	0x102324f30 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x538>
102324b60:     	ldr	x11, [x10]
102324b64:     	adds	x11, x11, #0x1
102324b68:     	str	x11, [x10]
102324b6c:     	b.hs	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102324b70:     	ldp	x12, x11, [x19, #0x20]
102324b74:     	add	x12, x12, #0x1
102324b78:     	stp	x12, x10, [x19, #0x20]
102324b7c:     	stp	x9, x11, [sp, #0x1e0]
102324b80:     	ldr	x21, [x8]
102324b84:     	ldr	x9, [x21]
102324b88:     	adds	x9, x9, #0x1
102324b8c:     	str	x9, [x21]
102324b90:     	b.hs	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102324b94:     	str	xzr, [sp, #0x300]
102324b98:     	str	x21, [sp, #0x2f0]
102324b9c:     	str	xzr, [sp, #0x2f8]
102324ba0:     	ldr	x9, [x19]
102324ba4:     	cbnz	x9, 0x102325234 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x83c>
102324ba8:     	add	x26, sp, #0x210
102324bac:     	ldur	q0, [x19, #0x8]
102324bb0:     	stur	q0, [x28, #0xb8]
102324bb4:     	ldr	x9, [x19, #0x18]
102324bb8:     	ldr	q0, [x26, #0xe0]
102324bbc:     	stur	q0, [x19, #0x8]
102324bc0:     	ldr	x10, [sp, #0x300]
102324bc4:     	str	x10, [x19, #0x18]
102324bc8:     	str	x9, [sp, #0x208]
102324bcc:     	str	x19, [sp, #0x1f0]
102324bd0:     	ldr	x8, [x8]
102324bd4:     	ldr	x9, [x8, #0x10]
102324bd8:     	mov	x10, #0x7ffffffffffffffe ; =9223372036854775806
102324bdc:     	cmp	x9, x10
102324be0:     	cset	w24, hi
102324be4:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102324be8:     	cmp	x9, x10
102324bec:     	b.hs	0x102325244 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x84c>
102324bf0:     	ldp	x9, x8, [x8, #0x38]
102324bf4:     	ldp	x12, x27, [x19, #0x30]
102324bf8:     	ldr	x13, [x19, #0x40]
102324bfc:     	ldp	x10, x11, [sp, #0x148]
102324c00:     	ldr	x10, [x10]
102324c04:     	adds	x9, x9, x10
102324c08:     	csinv	x9, x9, xzr, lo
102324c0c:     	cmp	x27, x9
102324c10:     	csel	x10, x27, x9, lo
102324c14:     	ldr	x11, [x11]
102324c18:     	adds	x8, x8, x11
102324c1c:     	csinv	x8, x8, xzr, lo
102324c20:     	cmp	x13, x8
102324c24:     	stp	x13, x12, [sp, #0x88]
102324c28:     	csel	x11, x13, x8, lo
102324c2c:     	tst	w12, #0x1
102324c30:     	csel	x9, x10, x9, ne
102324c34:     	csel	x8, x11, x8, ne
102324c38:     	mov	w10, #0x1               ; =1
102324c3c:     	stp	x10, x9, [x19, #0x30]
102324c40:     	str	x8, [x19, #0x40]
102324c44:     	ldur	q0, [x28, #0x58]
102324c48:     	ldur	q1, [x28, #0x68]
102324c4c:     	stp	q0, q1, [x28, #0x110]
102324c50:     	ldur	q0, [x28, #0x78]
102324c54:     	ldur	q1, [x28, #0x88]
102324c58:     	stp	q0, q1, [x28, #0x130]
102324c5c:     	ldur	q0, [x28, #0x18]
102324c60:     	ldur	q1, [x28, #0x28]
102324c64:     	stp	q0, q1, [x28, #0xd0]
102324c68:     	ldur	q0, [x28, #0x38]
102324c6c:     	ldur	q1, [x28, #0x48]
102324c70:     	stp	q0, q1, [x28, #0xf0]
102324c74:     	ldr	x8, [sp, #0x210]
102324c78:     	add	x9, sp, #0x210
102324c7c:     	orr	x0, x9, #0x8
102324c80:     	ldr	x9, [x8, #0xb0]
102324c84:     	cbz	x9, 0x102325648 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc50>
102324c88:     	add	x23, sp, #0x7b8
102324c8c:     	ldr	x10, [x8, #0xa8]
102324c90:     	ldr	w9, [sp, #0x250]
102324c94:     	ldr	w10, [x10]
102324c98:     	cmp	w9, w10
102324c9c:     	b.ne	0x102324e38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x440>
102324ca0:     	ldp	q0, q1, [x28, #0x30]
102324ca4:     	stp	q0, q1, [x26, #0xe0]
102324ca8:     	ldr	x10, [x8, #0x128]
102324cac:     	cbz	x10, 0x102325658 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc60>
102324cb0:     	ldr	x10, [x8, #0x120]
102324cb4:     	ldr	x11, [sp, #0x2f0]
102324cb8:     	ldr	x12, [sp, #0x2f8]
102324cbc:     	ldp	x13, x14, [x10]
102324cc0:     	ldr	x15, [sp, #0x300]
102324cc4:     	ldr	x16, [sp, #0x308]
102324cc8:     	ldp	x17, x10, [x10, #0x10]
102324ccc:     	cmp	x11, x13
102324cd0:     	ccmp	x12, x14, #0x0, eq
102324cd4:     	ccmp	x15, x17, #0x0, eq
102324cd8:     	ccmp	x16, x10, #0x0, eq
102324cdc:     	b.ne	0x102324e38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x440>
102324ce0:     	ldr	x10, [x8, #0xc0]
102324ce4:     	cbz	x10, 0x102325690 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc98>
102324ce8:     	ldr	x22, [x8, #0xb8]
102324cec:     	ldr	w10, [x22, #0x2c]
102324cf0:     	cmp	w9, w10
102324cf4:     	b.ne	0x102324e38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x440>
102324cf8:     	ldr	x9, [x8, #0x190]
102324cfc:     	add	x8, sp, #0x290
102324d00:     	add	x1, x9, #0x10
102324d04:     	str	x0, [sp, #0x48]
102324d08:     	bl	0x102e11a14 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
102324d0c:     	ldrb	w8, [sp, #0x290]
102324d10:     	cmp	w8, #0x16
102324d14:     	b.ne	0x102324e2c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x434>
102324d18:     	ldr	x8, [sp, #0x258]
102324d1c:     	ldr	x21, [x8]
102324d20:     	ldr	x8, [x21, #0x10]
102324d24:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102324d28:     	cmp	x8, x9
102324d2c:     	b.hs	0x1023253b0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x9b8>
102324d30:     	add	x8, x8, #0x1
102324d34:     	str	x8, [x21, #0x10]
102324d38:     	ldr	x8, [x21, #0x18]
102324d3c:     	cbz	x8, 0x1023253c0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x9c8>
102324d40:     	str	x22, [sp, #0x80]
102324d44:     	mov	w9, #0x1                ; =1
102324d48:     	ldadd	x9, x9, [x8]
102324d4c:     	tbnz	x9, #0x3f, 0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102324d50:     	str	x8, [sp, #0x2d8]
102324d54:     	ldr	q0, [x21, #0x20]
102324d58:     	stur	q0, [x26, #0xd0]
102324d5c:     	ldr	x8, [x21, #0x10]
102324d60:     	sub	x8, x8, #0x1
102324d64:     	str	x8, [x21, #0x10]
102324d68:     	add	x1, sp, #0x2d8
102324d6c:     	ldr	x21, [sp, #0x48]
102324d70:     	mov	x0, x21
102324d74:     	bl	0x102e13930 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
102324d78:     	mov	w8, #0x2d               ; =45
102324d7c:     	strb	w8, [sp, #0x2f0]
102324d80:     	cmp	x0, #0x1
102324d84:     	b.ne	0x102324fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x5cc>
102324d88:     	mov	x22, x1
102324d8c:     	add	x0, sp, #0x2f0
102324d90:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102324d94:     	add	x1, sp, #0x2d8
102324d98:     	mov	x0, x21
102324d9c:     	bl	0x102e13a04 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_nodes>
102324da0:     	mov	w8, #0x2d               ; =45
102324da4:     	strb	w8, [sp, #0x2f0]
102324da8:     	cmp	x0, #0x1
102324dac:     	b.ne	0x102324fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x5cc>
102324db0:     	mov	x21, x1
102324db4:     	add	x0, sp, #0x2f0
102324db8:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102324dbc:     	ldr	x8, [sp, #0x258]
102324dc0:     	ldr	x13, [x8]
102324dc4:     	ldr	x9, [x13, #0x10]
102324dc8:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102324dcc:     	cmp	x9, x10
102324dd0:     	b.hs	0x102325458 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa60>
102324dd4:     	ldr	x12, [sp, #0x268]
102324dd8:     	ldr	x9, [x12, #0x30]
102324ddc:     	adds	x9, x9, x22
102324de0:     	b.hs	0x102325420 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa28>
102324de4:     	ldr	x10, [x12, #0x50]
102324de8:     	adds	x10, x10, x21
102324dec:     	b.hs	0x102325420 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa28>
102324df0:     	ldr	x11, [sp, #0x260]
102324df4:     	ldr	x14, [x11]
102324df8:     	ldrb	w21, [x11, #0x8]
102324dfc:     	cmp	x14, #0x2
102324e00:     	b.ne	0x102325000 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x608>
102324e04:     	ldrb	w8, [x11, #0xb]
102324e08:     	ldurh	w9, [x11, #0x9]
102324e0c:     	orr	w8, w9, w8, lsl #16
102324e10:     	str	x8, [sp, #0x78]
102324e14:     	ldr	w8, [x11, #0xc]
102324e18:     	ldp	q0, q1, [x11, #0x10]
102324e1c:     	stp	q1, q0, [sp, #0x50]
102324e20:     	str	x8, [sp, #0x80]
102324e24:     	mov	w22, #0x29              ; =41
102324e28:     	b	0x102324fd0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x5d8>
102324e2c:     	add	x0, sp, #0x290
102324e30:     	bl	0x10234107c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
102324e34:     	ldr	x0, [sp, #0x48]
102324e38:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102324e3c:     	mov	w21, #0x0               ; =0
102324e40:     	mov	w22, #0x2c              ; =44
102324e44:     	mov	w26, #0x2               ; =2
102324e48:     	str	x8, [sp, #0x78]
102324e4c:     	str	x8, [sp, #0x80]
102324e50:     	add	x24, sp, #0x1f0
102324e54:     	ldur	w8, [x29, #-0xa8]
102324e58:     	str	w8, [sp, #0x6b0]
102324e5c:     	sub	x8, x29, #0xa8
102324e60:     	ldur	w8, [x8, #0x3]
102324e64:     	add	x9, sp, #0x6b0
102324e68:     	stur	w8, [x9, #0x3]
102324e6c:     	ldur	q0, [x23, #0x98]
102324e70:     	ldur	q1, [x23, #0xa8]
102324e74:     	ldur	q2, [x23, #0xb8]
102324e78:     	stp	q1, q2, [x25, #0xa0]
102324e7c:     	ldur	q1, [x23, #0xc8]
102324e80:     	str	q1, [x25, #0xc0]
102324e84:     	ldur	q1, [x23, #0x58]
102324e88:     	ldur	q2, [x23, #0x68]
102324e8c:     	ldur	q3, [x23, #0x78]
102324e90:     	stp	q2, q3, [x25, #0x60]
102324e94:     	ldur	q2, [x23, #0x88]
102324e98:     	stp	q2, q0, [x25, #0x80]
102324e9c:     	ldur	q0, [x23, #0x18]
102324ea0:     	ldur	q2, [x23, #0x28]
102324ea4:     	ldur	q3, [x23, #0x38]
102324ea8:     	stp	q2, q3, [x25, #0x20]
102324eac:     	ldur	q2, [x23, #0x48]
102324eb0:     	stp	q2, q1, [x25, #0x40]
102324eb4:     	ldur	q1, [x23, #0x8]
102324eb8:     	stp	q1, q0, [x25]
102324ebc:     	ldp	x8, x9, [sp, #0x88]
102324ec0:     	stp	x9, x27, [x19, #0x30]
102324ec4:     	str	x8, [x19, #0x40]
102324ec8:     	add	x0, sp, #0x1f0
102324ecc:     	bl	0x1023a56a0 <__RNvXs_NvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBa_23NativeLibraryWorkBudget16with_call_limitsNtB4_10ScopeGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
102324ed0:     	ldr	x8, [sp, #0x1f8]
102324ed4:     	cbz	x8, 0x102324ef0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x4f8>
102324ed8:     	ldr	x9, [x8]
102324edc:     	subs	x9, x9, #0x1
102324ee0:     	str	x9, [x8]
102324ee4:     	b.ne	0x102324ef0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x4f8>
102324ee8:     	add	x0, x24, #0x8
102324eec:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102324ef0:     	add	x23, sp, #0x1e0
102324ef4:     	add	x0, sp, #0x1e0
102324ef8:     	bl	0x10238b060 <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
102324efc:     	ldp	x8, x9, [sp, #0x78]
102324f00:     	orr	w8, w21, w8, lsl #8
102324f04:     	orr	x19, x8, x9, lsl #32
102324f08:     	ldr	x8, [sp, #0x1e8]
102324f0c:     	cbz	x8, 0x102324f28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x530>
102324f10:     	ldr	x9, [x8]
102324f14:     	subs	x9, x9, #0x1
102324f18:     	str	x9, [x8]
102324f1c:     	b.ne	0x102324f28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x530>
102324f20:     	add	x0, x23, #0x8
102324f24:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102324f28:     	add	x21, sp, #0x6b0
102324f2c:     	ldp	q5, q4, [sp, #0x50]
102324f30:     	ldp	q1, q0, [x25, #0x80]
102324f34:     	stur	q0, [x20, #0xc8]
102324f38:     	ldp	q0, q2, [x25, #0xa0]
102324f3c:     	stur	q0, [x20, #0xd8]
102324f40:     	stur	q2, [x20, #0xe8]
102324f44:     	ldr	q0, [x25, #0xc0]
102324f48:     	stur	q0, [x20, #0xf8]
102324f4c:     	ldp	q2, q0, [x25, #0x40]
102324f50:     	stur	q0, [x20, #0x88]
102324f54:     	ldp	q0, q3, [x25, #0x60]
102324f58:     	stur	q0, [x20, #0x98]
102324f5c:     	stur	q3, [x20, #0xa8]
102324f60:     	stur	q1, [x20, #0xb8]
102324f64:     	ldp	q1, q0, [x25]
102324f68:     	stur	q0, [x20, #0x48]
102324f6c:     	ldp	q0, q3, [x25, #0x20]
102324f70:     	stur	q0, [x20, #0x58]
102324f74:     	stur	q3, [x20, #0x68]
102324f78:     	stur	q2, [x20, #0x78]
102324f7c:     	ldr	w8, [sp, #0x6b0]
102324f80:     	stur	w8, [x20, #0x1]
102324f84:     	ldur	w8, [x21, #0x3]
102324f88:     	str	w8, [x20, #0x4]
102324f8c:     	stur	q1, [x20, #0x38]
102324f90:     	strb	w22, [x20]
102324f94:     	str	x19, [x20, #0x8]
102324f98:     	stp	q4, q5, [x20, #0x10]
102324f9c:     	str	x28, [x20, #0x30]
102324fa0:     	strb	w26, [x20, #0x108]
102324fa4:     	add	sp, sp, #0x920
102324fa8:     	ldp	x29, x30, [sp, #0x50]
102324fac:     	ldp	x20, x19, [sp, #0x40]
102324fb0:     	ldp	x22, x21, [sp, #0x30]
102324fb4:     	ldp	x24, x23, [sp, #0x20]
102324fb8:     	ldp	x26, x25, [sp, #0x10]
102324fbc:     	ldp	x28, x27, [sp], #0x60
102324fc0:     	ret
102324fc4:     	stp	xzr, xzr, [sp, #0x78]
102324fc8:     	mov	w21, #0x0               ; =0
102324fcc:     	mov	w22, #0x2d              ; =45
102324fd0:     	ldr	x8, [sp, #0x2d8]
102324fd4:     	mov	x9, #-0x1               ; =-1
102324fd8:     	ldaddl	x9, x8, [x8]
102324fdc:     	cmp	x8, #0x1
102324fe0:     	b.ne	0x102324ff0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x5f8>
102324fe4:     	dmb	ishld
102324fe8:     	add	x0, sp, #0x2d8
102324fec:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102324ff0:     	ldr	x0, [sp, #0x48]
102324ff4:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102324ff8:     	mov	w26, #0x2               ; =2
102324ffc:     	b	0x102324e50 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x458>
102325000:     	ldur	q0, [x13, #0x38]
102325004:     	ldp	q1, q2, [x12]
102325008:     	stp	q1, q2, [x26, #0x190]
10232500c:     	ldr	q1, [x12, #0x20]
102325010:     	str	q1, [x26, #0x1b0]
102325014:     	ldur	q1, [x12, #0x38]
102325018:     	stur	q1, [x25, #0xe8]
10232501c:     	ldur	x13, [x12, #0x48]
102325020:     	add	x15, sp, #0x2f0
102325024:     	ldur	q1, [x12, #0x58]
102325028:     	add	x12, x15, #0x108
10232502c:     	str	q1, [x12]
102325030:     	str	x14, [sp, #0x2f0]
102325034:     	strb	w21, [sp, #0x2f8]
102325038:     	ldur	q1, [x11, #0x9]
10232503c:     	ldur	q2, [x11, #0x19]
102325040:     	ldur	x12, [x11, #0x28]
102325044:     	ldr	x14, [x11, #0xa0]
102325048:     	str	x12, [sp, #0x318]
10232504c:     	stur	q2, [x25, #0x19]
102325050:     	stur	q1, [x25, #0x9]
102325054:     	ldp	q2, q1, [x11, #0x50]
102325058:     	stp	q2, q1, [x25, #0x50]
10232505c:     	ldp	q2, q1, [x11, #0x30]
102325060:     	stp	q2, q1, [x25, #0x30]
102325064:     	str	x14, [sp, #0x390]
102325068:     	ldp	q1, q2, [x11, #0x80]
10232506c:     	stp	q1, q2, [x25, #0x80]
102325070:     	ldr	q2, [x11, #0x70]
102325074:     	str	q2, [x25, #0x70]
102325078:     	str	x8, [sp, #0x398]
10232507c:     	str	x9, [sp, #0x3d0]
102325080:     	str	x13, [sp, #0x3e8]
102325084:     	str	x10, [sp, #0x3f0]
102325088:     	add	x8, x15, #0x118
10232508c:     	str	q0, [x8]
102325090:     	str	xzr, [sp, #0x418]
102325094:     	mov	w8, #0x1a               ; =26
102325098:     	mov	w9, #0x1                ; =1
10232509c:     	str	x9, [sp, #0x40]
1023250a0:     	str	w8, [sp, #0x420]
1023250a4:     	add	x0, sp, #0x7c0
1023250a8:     	add	x1, sp, #0x2f0
1023250ac:     	mov	x2, #0x0                ; =0
1023250b0:     	mov	x3, #0x0                ; =0
1023250b4:     	mov	x4, #0x0                ; =0
1023250b8:     	mov	x5, #0x0                ; =0
1023250bc:     	bl	0x1023625c8 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
1023250c0:     	ldrb	w8, [sp, #0x7c0]
1023250c4:     	cmp	w8, #0x8
1023250c8:     	b.ne	0x102325398 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x9a0>
1023250cc:     	ldr	x8, [sp, #0x210]
1023250d0:     	ldr	x21, [x8, #0x1c8]
1023250d4:     	cmn	x21, #0x81
1023250d8:     	b.hi	0x102325634 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc3c>
1023250dc:     	mov	w8, #0x2c               ; =44
1023250e0:     	strb	w8, [sp, #0x7c0]
1023250e4:     	add	x0, sp, #0x7c0
1023250e8:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1023250ec:     	mov	w8, #0x1                ; =1
1023250f0:     	str	x8, [sp, #0x40]
1023250f4:     	add	x8, sp, #0x6b0
1023250f8:     	add	x0, sp, #0x2f0
1023250fc:     	add	x1, x21, #0x80
102325100:     	mov	x2, #0x0                ; =0
102325104:     	bl	0x102362800 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
102325108:     	ldrb	w8, [sp, #0x6b0]
10232510c:     	cmp	w8, #0x8
102325110:     	b.ne	0x1023255d8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xbe0>
102325114:     	ldr	x8, [sp, #0x220]
102325118:     	ldr	x9, [x8, #0x10]
10232511c:     	ldrb	w8, [x9, #0x10]
102325120:     	cmp	w8, #0x19
102325124:     	b.ne	0x102325440 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa48>
102325128:     	mov	w8, #0x1                ; =1
10232512c:     	str	x8, [sp, #0x40]
102325130:     	add	x21, sp, #0x7c0
102325134:     	add	x8, sp, #0x7c0
102325138:     	str	x9, [sp, #0x78]
10232513c:     	add	x0, x9, #0x18
102325140:     	bl	0x102df3acc <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot4dataNtB5_11MatrixValue8elements>
102325144:     	ldr	x8, [sp, #0x7c0]
102325148:     	mov	w9, #0x10               ; =16
10232514c:     	mov	w10, #0x8               ; =8
102325150:     	cmp	x8, #0x13
102325154:     	csel	x8, x10, x9, eq
102325158:     	ldr	x10, [sp, #0x78]
10232515c:     	ldur	x9, [x10, #0x18]
102325160:     	mov	w22, #0x2c              ; =44
102325164:     	cmp	x9, #0x3
102325168:     	b.hi	0x102325254 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x85c>
10232516c:     	ldr	x21, [x21, x8]
102325170:     	ldr	x8, [x10, #0x20]
102325174:     	str	x8, [sp, #0x38]
102325178:     	strb	w22, [sp, #0x7c0]
10232517c:     	add	x0, sp, #0x7c0
102325180:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102325184:     	ldr	x8, [sp, #0x270]
102325188:     	ldr	x0, [x8]
10232518c:     	mov	w8, #0x1                ; =1
102325190:     	str	x8, [sp, #0x40]
102325194:     	add	x8, sp, #0x7c0
102325198:     	str	x21, [sp, #0x50]
10232519c:     	mov	x1, x21
1023251a0:     	bl	0x102992d24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric22available_scalar_index>
1023251a4:     	ldrb	w21, [sp, #0x7c0]
1023251a8:     	cmp	w21, #0x8
1023251ac:     	b.ne	0x102325264 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x86c>
1023251b0:     	ldr	x8, [sp, #0x210]
1023251b4:     	ldr	x9, [x8, #0x78]
1023251b8:     	cbz	x9, 0x102325f60 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1568>
1023251bc:     	ldr	x22, [sp, #0x7c8]
1023251c0:     	ldr	x1, [x8, #0x70]
1023251c4:     	mov	w8, #0x1                ; =1
1023251c8:     	str	x8, [sp, #0x40]
1023251cc:     	add	x8, sp, #0x7c0
1023251d0:     	ldr	x0, [sp, #0x48]
1023251d4:     	bl	0x1029a4428 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric26snapshot_matrix_dimensions>
1023251d8:     	ldrb	w21, [sp, #0x7c0]
1023251dc:     	cmp	w21, #0x8
1023251e0:     	b.ne	0x102325264 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x86c>
1023251e4:     	ldr	x10, [sp, #0x7c8]
1023251e8:     	cbz	x10, 0x102325214 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x81c>
1023251ec:     	ldr	x8, [sp, #0x7d0]
1023251f0:     	udiv	x9, x22, x10
1023251f4:     	msub	x10, x9, x10, x22
1023251f8:     	umulh	x11, x10, x8
1023251fc:     	cmp	xzr, x11
102325200:     	b.ne	0x102325214 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x81c>
102325204:     	mul	x8, x10, x8
102325208:     	adds	x8, x9, x8
10232520c:     	str	x8, [sp, #0x30]
102325210:     	b.lo	0x102325284 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x88c>
102325214:     	mov	w26, #0x1               ; =1
102325218:     	mov	w22, #0x29              ; =41
10232521c:     	mov	w21, #0x2               ; =2
102325220:     	b	0x10232544c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa54>
102325224:     	adrp	x0, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
102325228:     	add	x0, x0, #0x410
10232522c:     	bl	0x103a03bac <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102325230:     	b	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102325234:     	adrp	x0, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
102325238:     	add	x0, x0, #0x3f8
10232523c:     	bl	0x103a03bac <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102325240:     	b	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102325244:     	adrp	x0, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
102325248:     	add	x0, x0, #0x3f0
10232524c:     	bl	0x103a03bdc <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102325250:     	b	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102325254:     	stp	xzr, xzr, [sp, #0x78]
102325258:     	mov	w21, #0x0               ; =0
10232525c:     	mov	w26, #0x1               ; =1
102325260:     	b	0x10232560c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc14>
102325264:     	ldrb	w8, [sp, #0x7c3]
102325268:     	ldurh	w9, [x23, #0x9]
10232526c:     	orr	w10, w9, w8, lsl #16
102325270:     	ldr	w8, [sp, #0x7c4]
102325274:     	stp	x10, x8, [sp, #0x78]
102325278:     	ldp	q0, q1, [x23, #0x10]
10232527c:     	stp	q1, q0, [sp, #0x50]
102325280:     	b	0x102325604 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc0c>
102325284:     	mov	w8, #0x1                ; =1
102325288:     	str	x8, [sp, #0x40]
10232528c:     	add	x8, sp, #0x6b0
102325290:     	ldr	x9, [sp, #0x78]
102325294:     	add	x0, x9, #0x18
102325298:     	bl	0x102df3acc <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot4dataNtB5_11MatrixValue8elements>
10232529c:     	ldr	x8, [sp, #0x278]
1023252a0:     	ldr	x2, [x8]
1023252a4:     	add	x0, sp, #0x7c0
1023252a8:     	add	x1, sp, #0x6b0
1023252ac:     	ldr	x3, [sp, #0x30]
1023252b0:     	bl	0x10238a2d8 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates4word>
1023252b4:     	ldrb	w22, [sp, #0x7c0]
1023252b8:     	cmp	w22, #0x2e
1023252bc:     	b.ne	0x1023253dc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x9e4>
1023252c0:     	ldr	x21, [sp, #0x7c8]
1023252c4:     	ldr	x8, [sp, #0x210]
1023252c8:     	ldr	x9, [x8, #0x190]
1023252cc:     	mov	w8, #0x1                ; =1
1023252d0:     	str	x8, [sp, #0x40]
1023252d4:     	add	x8, sp, #0x7c0
1023252d8:     	add	x1, x9, #0x10
1023252dc:     	ldr	x0, [sp, #0x48]
1023252e0:     	bl	0x102e144bc <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot8encodingNtNtB7_10validation5Value18retained_footprint>
1023252e4:     	ldrb	w8, [sp, #0x7c0]
1023252e8:     	cmp	w8, #0x18
1023252ec:     	b.ne	0x10232542c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa34>
1023252f0:     	ldr	x4, [sp, #0x7d0]
1023252f4:     	ldr	x8, [sp, #0x7d8]
1023252f8:     	str	x8, [sp, #0x78]
1023252fc:     	ldr	x8, [sp, #0x210]
102325300:     	ldr	x2, [sp, #0x260]
102325304:     	ldr	w1, [x8, #0x110]
102325308:     	add	x0, sp, #0x7c0
10232530c:     	ldr	x3, [sp, #0x50]
102325310:     	str	x4, [sp, #0x28]
102325314:     	mov	x5, #0x0                ; =0
102325318:     	bl	0x102389ee4 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates12check_output>
10232531c:     	ldrb	w22, [sp, #0x7c0]
102325320:     	cmp	w22, #0x2e
102325324:     	b.ne	0x102325468 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa70>
102325328:     	mov	w8, #0x1                ; =1
10232532c:     	str	x8, [sp, #0x40]
102325330:     	add	x8, sp, #0x7c0
102325334:     	add	x0, sp, #0x2f0
102325338:     	mov	w1, #0x10               ; =16
10232533c:     	mov	w2, #0x1                ; =1
102325340:     	bl	0x102362800 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
102325344:     	ldrb	w8, [sp, #0x7c0]
102325348:     	cmp	w8, #0x8
10232534c:     	b.ne	0x102325398 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x9a0>
102325350:     	ldr	x8, [sp, #0x280]
102325354:     	ldr	x8, [x8]
102325358:     	cmp	x21, x8
10232535c:     	b.ne	0x1023254ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xab4>
102325360:     	ldr	x8, [sp, #0x48]
102325364:     	ldp	q0, q1, [x8]
102325368:     	stur	q0, [x23, #0x8]
10232536c:     	stur	q1, [x23, #0x18]
102325370:     	ldp	q0, q1, [x8, #0x20]
102325374:     	stur	q0, [x23, #0x28]
102325378:     	stur	q1, [x23, #0x38]
10232537c:     	str	xzr, [sp, #0x800]
102325380:     	str	xzr, [sp, #0x40]
102325384:     	add	x0, sp, #0x7c0
102325388:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10232538c:     	mov	w21, #0x0               ; =0
102325390:     	mov	w26, #0x0               ; =0
102325394:     	b	0x102325448 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa50>
102325398:     	ldr	w8, [sp, #0x7c4]
10232539c:     	str	x8, [sp, #0x80]
1023253a0:     	ldr	w8, [sp, #0x7c0]
1023253a4:     	ldp	q0, q1, [x23, #0x10]
1023253a8:     	str	q1, [sp, #0x50]
1023253ac:     	b	0x1023255f4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xbfc>
1023253b0:     	adrp	x0, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
1023253b4:     	add	x0, x0, #0x360
1023253b8:     	bl	0x103a03bdc <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1023253bc:     	b	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
1023253c0:     	adrp	x0, 0x107577000 <_anon.bacf143378b3839dd1972d7136a97b6c.2706+0x7>
1023253c4:     	add	x0, x0, #0x687
1023253c8:     	adrp	x2, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
1023253cc:     	add	x2, x2, #0x378
1023253d0:     	mov	w1, #0x2a               ; =42
1023253d4:     	bl	0x103a03c0c <__RNvNtCsgDHHaSskbIF_4core6option13expect_failed>
1023253d8:     	b	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
1023253dc:     	ldur	w8, [x23, #0x9]
1023253e0:     	stur	w8, [x29, #-0xa8]
1023253e4:     	ldr	w8, [sp, #0x7c4]
1023253e8:     	ldr	w9, [sp, #0x7c8]
1023253ec:     	sub	x10, x29, #0xa8
1023253f0:     	stur	w8, [x10, #0x3]
1023253f4:     	ldr	w8, [sp, #0x7cc]
1023253f8:     	str	x8, [sp, #0x80]
1023253fc:     	ldur	q1, [x23, #0x28]
102325400:     	ldur	q0, [x23, #0x18]
102325404:     	stp	q1, q0, [sp, #0x50]
102325408:     	ldr	x28, [sp, #0x7f0]
10232540c:     	and	w21, w9, #0xff
102325410:     	lsr	w8, w9, #8
102325414:     	str	x8, [sp, #0x78]
102325418:     	mov	w26, #0x1               ; =1
10232541c:     	b	0x10232560c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc14>
102325420:     	mov	w21, #0x2               ; =2
102325424:     	str	x9, [sp, #0x78]
102325428:     	b	0x102324e20 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x428>
10232542c:     	ldrb	w8, [sp, #0x7c0]
102325430:     	cmp	w8, #0x15
102325434:     	b.hi	0x102325440 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xa48>
102325438:     	add	x0, sp, #0x7c0
10232543c:     	bl	0x10234107c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
102325440:     	mov	w21, #0x0               ; =0
102325444:     	mov	w26, #0x1               ; =1
102325448:     	mov	w22, #0x2c              ; =44
10232544c:     	str	x8, [sp, #0x78]
102325450:     	str	x8, [sp, #0x80]
102325454:     	b	0x10232560c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc14>
102325458:     	adrp	x0, 0x108033000 <_anon.a23694c7749b0a7a16b728b605d1204f.304+0x110>
10232545c:     	add	x0, x0, #0x3f0
102325460:     	bl	0x103a03bdc <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102325464:     	b	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102325468:     	ldur	w8, [x23, #0x9]
10232546c:     	stur	w8, [x29, #-0xa8]
102325470:     	ldr	w8, [sp, #0x7c4]
102325474:     	ldr	w9, [sp, #0x7c8]
102325478:     	sub	x10, x29, #0xa8
10232547c:     	stur	w8, [x10, #0x3]
102325480:     	ldr	w8, [sp, #0x7cc]
102325484:     	str	x8, [sp, #0x80]
102325488:     	and	w21, w9, #0xff
10232548c:     	lsr	w8, w9, #8
102325490:     	str	x8, [sp, #0x78]
102325494:     	ldur	q1, [x23, #0x28]
102325498:     	ldur	q0, [x23, #0x18]
10232549c:     	stp	q1, q0, [sp, #0x50]
1023254a0:     	ldr	x28, [sp, #0x7f0]
1023254a4:     	mov	w26, #0x1               ; =1
1023254a8:     	b	0x10232560c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc14>
1023254ac:     	ldr	x8, [sp, #0x210]
1023254b0:     	ldr	x21, [x8, #0x1a8]
1023254b4:     	ldr	x8, [x8, #0x190]
1023254b8:     	ldr	w9, [x8, #0x10]
1023254bc:     	ldr	x22, [x8, #0x18]
1023254c0:     	mov	w8, #0x2c               ; =44
1023254c4:     	strb	w8, [sp, #0x7c0]
1023254c8:     	tbz	w9, #0x0, 0x102325634 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc3c>
1023254cc:     	add	x0, sp, #0x7c0
1023254d0:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1023254d4:     	adds	x21, x22, x21
1023254d8:     	b.hs	0x102325668 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc70>
1023254dc:     	mov	w8, #0x2c               ; =44
1023254e0:     	strb	w8, [sp, #0x7c0]
1023254e4:     	cmn	x21, #0x1, lsl #12      ; =0x1000
1023254e8:     	b.hs	0x102325668 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc70>
1023254ec:     	add	x0, sp, #0x7c0
1023254f0:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1023254f4:     	ldr	x8, [sp, #0x78]
1023254f8:     	cmn	x8, #0x9
1023254fc:     	b.hi	0x102325634 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc3c>
102325500:     	add	x22, x21, #0x1, lsl #12 ; =0x1000
102325504:     	mov	w8, #0x2c               ; =44
102325508:     	strb	w8, [sp, #0x7c0]
10232550c:     	add	x0, sp, #0x7c0
102325510:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102325514:     	mov	w8, #0x1                ; =1
102325518:     	str	x8, [sp, #0x40]
10232551c:     	add	x0, sp, #0x6b0
102325520:     	add	x1, sp, #0x2f0
102325524:     	ldr	x8, [sp, #0x78]
102325528:     	add	x5, x8, #0x8
10232552c:     	mov	x2, #0x0                ; =0
102325530:     	mov	x3, #0x0                ; =0
102325534:     	mov	x4, x22
102325538:     	bl	0x1023625c8 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
10232553c:     	ldrb	w8, [sp, #0x6b0]
102325540:     	cmp	w8, #0x8
102325544:     	b.ne	0x1023255d8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xbe0>
102325548:     	lsr	x8, x22, #60
10232554c:     	cbnz	x8, 0x102325634 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc3c>
102325550:     	lsl	x21, x22, #4
102325554:     	mov	w8, #0x2c               ; =44
102325558:     	strb	w8, [sp, #0x7c0]
10232555c:     	add	x0, sp, #0x7c0
102325560:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102325564:     	mov	w8, #0x1                ; =1
102325568:     	str	x8, [sp, #0x40]
10232556c:     	add	x8, sp, #0x6b0
102325570:     	add	x0, sp, #0x2f0
102325574:     	mov	x1, x21
102325578:     	mov	x2, #0x0                ; =0
10232557c:     	bl	0x102362800 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
102325580:     	ldrb	w8, [sp, #0x6b0]
102325584:     	cmp	w8, #0x8
102325588:     	b.ne	0x1023255d8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xbe0>
10232558c:     	mov	w8, #0x1                ; =1
102325590:     	str	x8, [sp, #0x40]
102325594:     	add	x8, sp, #0x7c0
102325598:     	add	x0, sp, #0x2d8
10232559c:     	mov	x1, x22
1023255a0:     	bl	0x102d53840 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1023255a4:     	ldr	w21, [sp, #0x7c0]
1023255a8:     	cmp	w21, #0x1a
1023255ac:     	cset	w8, ne
1023255b0:     	str	w8, [sp, #0xc]
1023255b4:     	b.eq	0x1023256ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xcb4>
1023255b8:     	ldr	w8, [sp, #0x7c4]
1023255bc:     	stp	xzr, x8, [sp, #0x78]
1023255c0:     	ldp	q0, q1, [x23, #0x10]
1023255c4:     	str	q1, [sp, #0x10]
1023255c8:     	str	q0, [sp, #0x60]
1023255cc:     	mov	w22, #0x2b              ; =43
1023255d0:     	ldr	x28, [sp, #0x7e8]
1023255d4:     	b	0x102325b44 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x114c>
1023255d8:     	ldr	w8, [sp, #0x6b4]
1023255dc:     	str	x8, [sp, #0x80]
1023255e0:     	ldr	w8, [sp, #0x6b0]
1023255e4:     	add	x9, sp, #0x6b0
1023255e8:     	ldur	q0, [x9, #0x18]
1023255ec:     	str	q0, [sp, #0x50]
1023255f0:     	ldur	q0, [x9, #0x8]
1023255f4:     	str	q0, [sp, #0x60]
1023255f8:     	and	w21, w8, #0xff
1023255fc:     	lsr	w8, w8, #8
102325600:     	str	x8, [sp, #0x78]
102325604:     	mov	w26, #0x1               ; =1
102325608:     	mov	w22, #0x29              ; =41
10232560c:     	ldr	x8, [sp, #0x2d8]
102325610:     	mov	x9, #-0x1               ; =-1
102325614:     	ldaddl	x9, x8, [x8]
102325618:     	cmp	x8, #0x1
10232561c:     	b.ne	0x10232562c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc34>
102325620:     	dmb	ishld
102325624:     	add	x0, sp, #0x2d8
102325628:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10232562c:     	cbnz	w26, 0x102324ff0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x5f8>
102325630:     	b	0x102324ff8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x600>
102325634:     	stp	xzr, xzr, [sp, #0x78]
102325638:     	mov	w21, #0x0               ; =0
10232563c:     	mov	w26, #0x1               ; =1
102325640:     	mov	w22, #0x2c              ; =44
102325644:     	b	0x10232560c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc14>
102325648:     	str	x0, [sp, #0x48]
10232564c:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
102325650:     	add	x2, x2, #0x2a8
102325654:     	b	0x10232569c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xca4>
102325658:     	str	x0, [sp, #0x48]
10232565c:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
102325660:     	add	x2, x2, #0x2c0
102325664:     	b	0x10232569c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xca4>
102325668:     	stp	xzr, xzr, [sp, #0x78]
10232566c:     	mov	w21, #0x0               ; =0
102325670:     	ldur	w8, [x23, #0x9]
102325674:     	stur	w8, [x29, #-0xa8]
102325678:     	ldr	w8, [sp, #0x7c4]
10232567c:     	sub	x9, x29, #0xa8
102325680:     	stur	w8, [x9, #0x3]
102325684:     	mov	w26, #0x1               ; =1
102325688:     	mov	w22, #0x2c              ; =44
10232568c:     	b	0x10232560c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc14>
102325690:     	str	x0, [sp, #0x48]
102325694:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
102325698:     	add	x2, x2, #0x2d8
10232569c:     	mov	x0, #0x0                ; =0
1023256a0:     	mov	x1, #0x0                ; =0
1023256a4:     	bl	0x103a03cd8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1023256a8:     	b	0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
1023256ac:     	ldp	q0, q1, [x23, #0x10]
1023256b0:     	stp	q0, q1, [x25, #0x160]
1023256b4:     	ldr	x8, [sp, #0x218]
1023256b8:     	add	x0, x8, #0x10
1023256bc:     	bl	0x102aafbec <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023256c0:     	str	x0, [sp]
1023256c4:     	str	x1, [sp, #0x40]
1023256c8:     	add	x9, sp, #0x470
1023256cc:     	ldr	x8, [sp, #0x288]
1023256d0:     	ldrb	w8, [x8]
1023256d4:     	tbz	w8, #0x0, 0x102325750 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xd58>
1023256d8:     	ldr	x8, [sp, #0x48]
1023256dc:     	ldp	q0, q1, [x8]
1023256e0:     	add	x9, sp, #0x668
1023256e4:     	stur	q0, [x9, #0x48]
1023256e8:     	stur	q1, [x9, #0x58]
1023256ec:     	ldp	q0, q1, [x8, #0x20]
1023256f0:     	stur	q0, [x9, #0x68]
1023256f4:     	stur	q1, [x9, #0x78]
1023256f8:     	add	x8, sp, #0x7c0
1023256fc:     	add	x0, sp, #0x6b0
102325700:     	add	x1, sp, #0x2d8
102325704:     	bl	0x102e18018 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB6_5Value30try_into_owned_unsigned_matrix>
102325708:     	ldr	x8, [sp, #0x7c0]
10232570c:     	ldr	x9, [sp, #0x7c8]
102325710:     	ldur	q0, [x23, #0x28]
102325714:     	str	q0, [sp, #0x10]
102325718:     	ldur	q0, [x23, #0x18]
10232571c:     	str	q0, [sp, #0x60]
102325720:     	ldr	x28, [sp, #0x7f0]
102325724:     	cmp	x8, #0x5
102325728:     	b.ne	0x102325a0c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1014>
10232572c:     	and	w21, w9, #0xff
102325730:     	lsr	w8, w9, #8
102325734:     	str	x8, [sp, #0x78]
102325738:     	lsr	x8, x9, #32
10232573c:     	str	x8, [sp, #0x80]
102325740:     	mov	w22, #0x2b              ; =43
102325744:     	ldr	x8, [sp, #0x40]
102325748:     	cbnz	x8, 0x102325b24 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x112c>
10232574c:     	b	0x102325b38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1140>
102325750:     	ldp	q1, q0, [x28, #0xe0]
102325754:     	str	q1, [sp, #0x60]
102325758:     	str	q0, [sp, #0x10]
10232575c:     	ldr	x10, [sp, #0x218]
102325760:     	ldr	x28, [sp, #0x240]
102325764:     	ldur	q0, [x26, #0x38]
102325768:     	str	q0, [x9, #0xf0]
10232576c:     	mov	w8, #0x4                ; =4
102325770:     	add	x11, sp, #0x470
102325774:     	ldp	q0, q1, [x11, #0xf0]
102325778:     	str	q0, [x11, #0x30]
10232577c:     	ldr	q0, [sp, #0x60]
102325780:     	stur	q0, [x11, #0x8]
102325784:     	ldr	q2, [sp, #0x10]
102325788:     	stur	q2, [x11, #0x18]
10232578c:     	str	x10, [sp, #0x470]
102325790:     	str	x28, [sp, #0x498]
102325794:     	str	x8, [sp, #0x4b0]
102325798:     	str	x9, [sp, #0x4b8]
10232579c:     	stp	q0, q2, [x11, #0x50]
1023257a0:     	stur	q1, [x11, #0x78]
1023257a4:     	ldp	q0, q1, [x11, #0x110]
1023257a8:     	stur	q0, [x11, #0x88]
1023257ac:     	stur	q1, [x11, #0x98]
1023257b0:     	ldr	x9, [sp, #0x5a0]
1023257b4:     	str	x28, [sp, #0x4e0]
1023257b8:     	str	x9, [sp, #0x518]
1023257bc:     	cmp	x8, #0x4
1023257c0:     	b.ne	0x102325834 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xe3c>
1023257c4:     	ldr	x8, [sp, #0x278]
1023257c8:     	ldr	x8, [x8]
1023257cc:     	ldr	x9, [sp, #0x38]
1023257d0:     	umulh	x9, x9, x8
1023257d4:     	cmp	xzr, x9
1023257d8:     	b.ne	0x102325f9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x15a4>
1023257dc:     	ldr	x9, [sp, #0x38]
1023257e0:     	mul	x28, x9, x8
1023257e4:     	mov	w8, #0x2c               ; =44
1023257e8:     	strb	w8, [sp, #0x7c0]
1023257ec:     	add	x0, sp, #0x7c0
1023257f0:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1023257f4:     	ldr	x8, [sp, #0x4b0]
1023257f8:     	cmp	x8, #0x4
1023257fc:     	b.ne	0x102325838 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xe40>
102325800:     	ldr	x8, [sp, #0x278]
102325804:     	ldr	x8, [x8]
102325808:     	ldr	x9, [sp, #0x50]
10232580c:     	umulh	x9, x9, x8
102325810:     	cmp	xzr, x9
102325814:     	b.ne	0x102325f9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x15a4>
102325818:     	ldr	x9, [sp, #0x50]
10232581c:     	mul	x26, x9, x8
102325820:     	mov	w8, #0x2c               ; =44
102325824:     	strb	w8, [sp, #0x7c0]
102325828:     	add	x0, sp, #0x7c0
10232582c:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102325830:     	b	0x10232583c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xe44>
102325834:     	mov	x28, #0x0               ; =0
102325838:     	mov	x26, #0x0               ; =0
10232583c:     	adds	x22, x28, x22
102325840:     	b.hs	0x102325f9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x15a4>
102325844:     	mov	w21, #0x2c              ; =44
102325848:     	strb	w21, [sp, #0x7c0]
10232584c:     	add	x0, sp, #0x7c0
102325850:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102325854:     	strb	w21, [sp, #0x7c0]
102325858:     	add	x0, sp, #0x7c0
10232585c:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102325860:     	mov	w21, #0x1               ; =1
102325864:     	add	x0, sp, #0x6b0
102325868:     	add	x1, sp, #0x2f0
10232586c:     	ldr	x8, [sp, #0x78]
102325870:     	add	x5, x8, #0x8
102325874:     	mov	x2, #0x0                ; =0
102325878:     	mov	x3, #0x0                ; =0
10232587c:     	mov	x4, x22
102325880:     	bl	0x1023625c8 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
102325884:     	ldrb	w8, [sp, #0x6b0]
102325888:     	cmp	w8, #0x8
10232588c:     	b.ne	0x1023259c4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xfcc>
102325890:     	ldr	x8, [sp, #0x210]
102325894:     	ldr	x2, [sp, #0x260]
102325898:     	ldr	w1, [x8, #0x110]
10232589c:     	add	x0, sp, #0x7c0
1023258a0:     	ldr	x3, [sp, #0x50]
1023258a4:     	ldr	x4, [sp, #0x28]
1023258a8:     	mov	x5, x26
1023258ac:     	bl	0x102389ee4 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates12check_output>
1023258b0:     	ldrb	w22, [sp, #0x7c0]
1023258b4:     	cmp	w22, #0x2e
1023258b8:     	b.ne	0x102325a48 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1050>
1023258bc:     	lsr	x8, x26, #61
1023258c0:     	cbnz	x8, 0x102325ac4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x10cc>
1023258c4:     	mov	w8, #0x2c               ; =44
1023258c8:     	strb	w8, [sp, #0x7c0]
1023258cc:     	mov	x8, #-0x81              ; =-129
1023258d0:     	movk	x8, #0x1fff, lsl #48
1023258d4:     	cmp	x26, x8
1023258d8:     	b.hi	0x102325ac4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x10cc>
1023258dc:     	lsl	x22, x26, #3
1023258e0:     	add	x0, sp, #0x7c0
1023258e4:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1023258e8:     	add	x8, sp, #0x6b0
1023258ec:     	add	x0, sp, #0x2f0
1023258f0:     	add	x1, x22, #0x400
1023258f4:     	mov	x2, #0x0                ; =0
1023258f8:     	bl	0x102362800 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
1023258fc:     	ldrb	w8, [sp, #0x6b0]
102325900:     	cmp	w8, #0x8
102325904:     	b.ne	0x1023259c4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xfcc>
102325908:     	ldr	x8, [sp, #0x4b0]
10232590c:     	mov	x26, x8
102325910:     	cmp	x8, #0x4
102325914:     	cset	w8, eq
102325918:     	str	w8, [sp, #0x78]
10232591c:     	b.ne	0x102325b54 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x115c>
102325920:     	add	x8, sp, #0x7c0
102325924:     	add	x0, sp, #0x2d8
102325928:     	mov	x1, x28
10232592c:     	bl	0x102d53840 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
102325930:     	ldr	w21, [sp, #0x7c0]
102325934:     	cmp	w21, #0x1a
102325938:     	b.ne	0x102325c54 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x125c>
10232593c:     	ldp	q0, q1, [x23, #0x10]
102325940:     	add	x8, sp, #0x470
102325944:     	stp	q0, q1, [x8, #0x160]
102325948:     	mov	w21, #0x1               ; =1
10232594c:     	add	x8, sp, #0x6b0
102325950:     	add	x0, sp, #0x450
102325954:     	add	x1, sp, #0x5d0
102325958:     	bl	0x102d53eac <__RNvMs5_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservation14merge_capacity>
10232595c:     	ldr	w8, [sp, #0x6b0]
102325960:     	cmp	w8, #0x1a
102325964:     	b.ne	0x102325f14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x151c>
102325968:     	ldr	x8, [sp, #0x470]
10232596c:     	cbz	x8, 0x102325f9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x15a4>
102325970:     	mov	w22, #0x2c              ; =44
102325974:     	strb	w22, [sp, #0x7c0]
102325978:     	add	x0, sp, #0x7c0
10232597c:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102325980:     	ldr	x8, [sp, #0x478]
102325984:     	ldr	x9, [x8, #0x10]
102325988:     	ldrb	w8, [x9, #0x10]
10232598c:     	cmp	w8, #0x19
102325990:     	b.ne	0x102325fa8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x15b0>
102325994:     	add	x8, sp, #0x6b0
102325998:     	add	x0, x9, #0x18
10232599c:     	bl	0x102df3acc <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot4dataNtB5_11MatrixValue8elements>
1023259a0:     	add	x0, sp, #0x7c0
1023259a4:     	add	x1, sp, #0x6b0
1023259a8:     	ldr	x2, [sp, #0x38]
1023259ac:     	bl	0x102389f8c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates4copy>
1023259b0:     	ldrb	w22, [sp, #0x7c0]
1023259b4:     	cmp	w22, #0x2e
1023259b8:     	b.ne	0x10232601c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1624>
1023259bc:     	ldp	q0, q1, [x23, #0x10]
1023259c0:     	b	0x102325bd4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x11dc>
1023259c4:     	ldr	w8, [sp, #0x6b4]
1023259c8:     	str	x8, [sp, #0x80]
1023259cc:     	ldr	w8, [sp, #0x6b0]
1023259d0:     	add	x9, sp, #0x6b0
1023259d4:     	ldur	q0, [x9, #0x18]
1023259d8:     	str	q0, [sp, #0x10]
1023259dc:     	ldur	q0, [x9, #0x8]
1023259e0:     	str	q0, [sp, #0x60]
1023259e4:     	and	w21, w8, #0xff
1023259e8:     	lsr	w8, w8, #8
1023259ec:     	str	x8, [sp, #0x78]
1023259f0:     	mov	w22, #0x29              ; =41
1023259f4:     	ldr	x8, [sp, #0x4b0]
1023259f8:     	mov	w9, #0x1                ; =1
1023259fc:     	str	w9, [sp, #0x50]
102325a00:     	cmp	x8, #0x4
102325a04:     	b.ne	0x102325af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1100>
102325a08:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102325a0c:     	ldp	q0, q1, [x23, #0x40]
102325a10:     	add	x10, sp, #0x470
102325a14:     	stp	q0, q1, [x10, #0xb0]
102325a18:     	ldur	q0, [x23, #0x60]
102325a1c:     	str	q0, [x10, #0xd0]
102325a20:     	ldr	x10, [sp, #0x828]
102325a24:     	str	x10, [sp, #0x550]
102325a28:     	cmp	x8, #0x4
102325a2c:     	b.ne	0x102325aa0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x10a8>
102325a30:     	add	x8, sp, #0x470
102325a34:     	ldr	q0, [x8, #0xb0]
102325a38:     	str	q0, [x8, #0xf0]
102325a3c:     	mov	w8, #0x4                ; =4
102325a40:     	mov	x10, x9
102325a44:     	b	0x102325770 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xd78>
102325a48:     	ldur	w8, [x23, #0x9]
102325a4c:     	stur	w8, [x29, #-0xa8]
102325a50:     	ldr	w8, [sp, #0x7c4]
102325a54:     	ldr	w9, [sp, #0x7c8]
102325a58:     	sub	x10, x29, #0xa8
102325a5c:     	stur	w8, [x10, #0x3]
102325a60:     	ldr	w8, [sp, #0x7cc]
102325a64:     	str	x8, [sp, #0x80]
102325a68:     	and	w21, w9, #0xff
102325a6c:     	lsr	w8, w9, #8
102325a70:     	str	x8, [sp, #0x78]
102325a74:     	ldur	q0, [x23, #0x28]
102325a78:     	str	q0, [sp, #0x10]
102325a7c:     	ldur	q0, [x23, #0x18]
102325a80:     	str	q0, [sp, #0x60]
102325a84:     	ldr	x28, [sp, #0x7f0]
102325a88:     	ldr	x8, [sp, #0x4b0]
102325a8c:     	mov	w9, #0x1                ; =1
102325a90:     	str	w9, [sp, #0x50]
102325a94:     	cmp	x8, #0x4
102325a98:     	b.ne	0x102325af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1100>
102325a9c:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102325aa0:     	mov	x10, #0x0               ; =0
102325aa4:     	add	x11, sp, #0x470
102325aa8:     	ldp	q0, q1, [x11, #0xb0]
102325aac:     	stp	q0, q1, [x11, #0x100]
102325ab0:     	ldr	q0, [x11, #0xd0]
102325ab4:     	str	q0, [x11, #0x120]
102325ab8:     	ldr	x11, [sp, #0x550]
102325abc:     	str	x11, [sp, #0x5a0]
102325ac0:     	b	0x102325770 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xd78>
102325ac4:     	stp	xzr, xzr, [sp, #0x78]
102325ac8:     	mov	w21, #0x0               ; =0
102325acc:     	ldur	w8, [x23, #0x9]
102325ad0:     	stur	w8, [x29, #-0xa8]
102325ad4:     	ldr	w8, [sp, #0x7c4]
102325ad8:     	sub	x9, x29, #0xa8
102325adc:     	stur	w8, [x9, #0x3]
102325ae0:     	mov	w22, #0x2c              ; =44
102325ae4:     	ldr	x8, [sp, #0x4b0]
102325ae8:     	mov	w9, #0x1                ; =1
102325aec:     	str	w9, [sp, #0x50]
102325af0:     	cmp	x8, #0x4
102325af4:     	b.eq	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102325af8:     	add	x0, sp, #0x4b0
102325afc:     	bl	0x102341b74 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
102325b00:     	ldr	x8, [sp, #0x470]
102325b04:     	cbz	x8, 0x102325b10 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1118>
102325b08:     	add	x0, sp, #0x470
102325b0c:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102325b10:     	ldr	x8, [sp, #0x40]
102325b14:     	cmp	x8, #0x0
102325b18:     	ldr	w8, [sp, #0x50]
102325b1c:     	csel	w8, wzr, w8, eq
102325b20:     	tbz	w8, #0x0, 0x102325b38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1140>
102325b24:     	ldr	x8, [sp, #0x40]
102325b28:     	lsl	x1, x8, #3
102325b2c:     	ldr	x0, [sp]
102325b30:     	mov	w2, #0x8                ; =8
102325b34:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102325b38:     	str	xzr, [sp, #0x40]
102325b3c:     	add	x0, sp, #0x450
102325b40:     	bl	0x10233f82c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
102325b44:     	ldr	q0, [sp, #0x10]
102325b48:     	str	q0, [sp, #0x50]
102325b4c:     	ldr	w26, [sp, #0xc]
102325b50:     	b	0x10232560c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0xc14>
102325b54:     	add	x8, sp, #0x470
102325b58:     	ldp	q0, q1, [x8, #0x80]
102325b5c:     	stp	q0, q1, [x8, #0x1a0]
102325b60:     	ldr	q0, [x8, #0xa0]
102325b64:     	str	q0, [x8, #0x1c0]
102325b68:     	ldp	q0, q1, [x8, #0x40]
102325b6c:     	stp	q0, q1, [x8, #0x160]
102325b70:     	ldp	q1, q0, [x8, #0x60]
102325b74:     	stp	q1, q0, [x8, #0x180]
102325b78:     	mov	w21, #0x0               ; =0
102325b7c:     	add	x8, sp, #0x7c0
102325b80:     	add	x0, sp, #0x5d0
102325b84:     	bl	0x102d80a34 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix10into_parts>
102325b88:     	ldur	q0, [x23, #0x8]
102325b8c:     	add	x8, sp, #0x668
102325b90:     	stur	q0, [x8, #0x48]
102325b94:     	ldur	q0, [x23, #0x18]
102325b98:     	stur	q0, [x8, #0x58]
102325b9c:     	ldur	q0, [x23, #0x28]
102325ba0:     	ldur	q1, [x23, #0x38]
102325ba4:     	add	x8, sp, #0x470
102325ba8:     	stp	q0, q1, [x8, #0x1d0]
102325bac:     	add	x8, sp, #0x7c0
102325bb0:     	add	x0, sp, #0x450
102325bb4:     	add	x1, sp, #0x640
102325bb8:     	bl	0x102d53eac <__RNvMs5_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservation14merge_capacity>
102325bbc:     	ldr	w8, [sp, #0x7c0]
102325bc0:     	cmp	w8, #0x1a
102325bc4:     	b.ne	0x102325c88 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1290>
102325bc8:     	add	x8, sp, #0x668
102325bcc:     	ldur	q0, [x8, #0x48]
102325bd0:     	ldur	q1, [x8, #0x58]
102325bd4:     	add	x8, sp, #0x470
102325bd8:     	stp	q0, q1, [x8, #0x140]
102325bdc:     	ldr	x8, [sp, #0x280]
102325be0:     	ldr	x3, [x8]
102325be4:     	add	x0, sp, #0x7c0
102325be8:     	add	x1, sp, #0x5b0
102325bec:     	ldr	x2, [sp, #0x30]
102325bf0:     	bl	0x10238a3ec <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace>
102325bf4:     	ldrb	w22, [sp, #0x7c0]
102325bf8:     	cmp	w22, #0x2e
102325bfc:     	cset	w8, ne
102325c00:     	str	w8, [sp, #0x50]
102325c04:     	b.eq	0x102325cc8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x12d0>
102325c08:     	ldur	w8, [x23, #0x9]
102325c0c:     	stur	w8, [x29, #-0xa8]
102325c10:     	ldr	w8, [sp, #0x7c4]
102325c14:     	ldr	w9, [sp, #0x7c8]
102325c18:     	sub	x10, x29, #0xa8
102325c1c:     	stur	w8, [x10, #0x3]
102325c20:     	ldr	w8, [sp, #0x7cc]
102325c24:     	str	x8, [sp, #0x80]
102325c28:     	and	w21, w9, #0xff
102325c2c:     	lsr	w8, w9, #8
102325c30:     	str	x8, [sp, #0x78]
102325c34:     	ldur	q0, [x23, #0x28]
102325c38:     	str	q0, [sp, #0x10]
102325c3c:     	ldur	q0, [x23, #0x18]
102325c40:     	str	q0, [sp, #0x60]
102325c44:     	ldr	x28, [sp, #0x7f0]
102325c48:     	add	x0, sp, #0x5b0
102325c4c:     	bl	0x102341afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
102325c50:     	b	0x102326004 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x160c>
102325c54:     	ldr	w8, [sp, #0x7c4]
102325c58:     	stp	xzr, x8, [sp, #0x78]
102325c5c:     	ldp	q0, q1, [x23, #0x10]
102325c60:     	str	q1, [sp, #0x10]
102325c64:     	str	q0, [sp, #0x60]
102325c68:     	mov	w22, #0x2b              ; =43
102325c6c:     	ldr	x28, [sp, #0x7e8]
102325c70:     	ldr	x8, [sp, #0x4b0]
102325c74:     	mov	w9, #0x1                ; =1
102325c78:     	str	w9, [sp, #0x50]
102325c7c:     	cmp	x8, #0x4
102325c80:     	b.ne	0x102325af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1100>
102325c84:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102325c88:     	ldr	w8, [sp, #0x7c4]
102325c8c:     	str	x8, [sp, #0x80]
102325c90:     	ldr	w21, [sp, #0x7c0]
102325c94:     	ldp	q0, q1, [x23, #0x10]
102325c98:     	str	q1, [sp, #0x10]
102325c9c:     	str	q0, [sp, #0x60]
102325ca0:     	ldr	x28, [sp, #0x7e8]
102325ca4:     	add	x0, sp, #0x6b0
102325ca8:     	bl	0x102341afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
102325cac:     	lsr	w8, w21, #8
102325cb0:     	str	x8, [sp, #0x78]
102325cb4:     	and	w21, w21, #0xff
102325cb8:     	mov	w8, #0x1                ; =1
102325cbc:     	str	w8, [sp, #0x50]
102325cc0:     	mov	w22, #0x2b              ; =43
102325cc4:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102325cc8:     	ldr	x8, [sp, #0x80]
102325ccc:     	ldr	w0, [x8, #0x2c]
102325cd0:     	ldr	x8, [sp, #0x210]
102325cd4:     	ldr	x4, [x8, #0x190]
102325cd8:     	mov	w8, #0x1                ; =1
102325cdc:     	ldadd	x8, x8, [x4]
102325ce0:     	tbnz	x8, #0x3f, 0x102325f7c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1584>
102325ce4:     	add	x8, sp, #0x668
102325ce8:     	add	x3, sp, #0x5b0
102325cec:     	ldr	x1, [sp]
102325cf0:     	ldr	x2, [sp, #0x40]
102325cf4:     	bl	0x102e17fb4 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrixNtB6_5Value27from_unsigned_matrix_buffer>
102325cf8:     	ldrb	w8, [sp, #0x668]
102325cfc:     	cmp	w8, #0x16
102325d00:     	b.ne	0x102325f80 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1588>
102325d04:     	ldr	x8, [sp, #0x670]
102325d08:     	ldrb	w9, [sp, #0x678]
102325d0c:     	add	x11, sp, #0x668
102325d10:     	ldur	q0, [x11, #0x11]
102325d14:     	sub	x10, x29, #0xa8
102325d18:     	stur	q0, [x10, #0x9]
102325d1c:     	ldur	q0, [x11, #0x21]
102325d20:     	stur	q0, [x10, #0x19]
102325d24:     	ldur	q0, [x11, #0x31]
102325d28:     	stur	q0, [x10, #0x29]
102325d2c:     	ldr	x10, [sp, #0x6a8]
102325d30:     	stur	x8, [x29, #-0xa8]
102325d34:     	sturb	w9, [x29, #-0xa0]
102325d38:     	add	x8, sp, #0x450
102325d3c:     	stp	x10, x8, [x29, #-0x70]
102325d40:     	add	x0, sp, #0x7c0
102325d44:     	sub	x1, x29, #0xa8
102325d48:     	add	x2, sp, #0x450
102325d4c:     	bl	0x10235fa10 <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB6_25NativePreparedLibraryCall31unsigned_matrix_replace_private0Be_>
102325d50:     	ldr	x21, [sp, #0x7c0]
102325d54:     	ldrb	w22, [sp, #0x7c8]
102325d58:     	ldur	w8, [x23, #0x11]
102325d5c:     	str	w8, [sp, #0x7b8]
102325d60:     	ldr	w8, [sp, #0x7cc]
102325d64:     	stur	w8, [x23, #0x3]
102325d68:     	ldur	q0, [x23, #0x18]
102325d6c:     	str	q0, [sp, #0x60]
102325d70:     	ldur	q0, [x23, #0x30]
102325d74:     	str	q0, [sp, #0x10]
102325d78:     	ldr	x28, [sp, #0x7f8]
102325d7c:     	cbz	x21, 0x102325fcc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x15d4>
102325d80:     	ldur	q4, [x23, #0x28]
102325d84:     	ldur	q0, [x23, #0xd8]
102325d88:     	ldur	q1, [x23, #0xe8]
102325d8c:     	ldur	q2, [x23, #0xf8]
102325d90:     	add	x9, sp, #0x6b0
102325d94:     	stp	q1, q2, [x9, #0xe0]
102325d98:     	ldur	q1, [x23, #0x98]
102325d9c:     	ldur	q2, [x23, #0xa8]
102325da0:     	ldur	q3, [x23, #0xb8]
102325da4:     	stp	q2, q3, [x9, #0xa0]
102325da8:     	ldur	q2, [x23, #0xc8]
102325dac:     	stp	q2, q0, [x9, #0xc0]
102325db0:     	ldur	q0, [x23, #0x58]
102325db4:     	ldur	q2, [x23, #0x68]
102325db8:     	ldur	q3, [x23, #0x78]
102325dbc:     	stp	q2, q3, [x9, #0x60]
102325dc0:     	ldur	q2, [x23, #0x88]
102325dc4:     	stp	q2, q1, [x9, #0x80]
102325dc8:     	ldur	q1, [x23, #0x48]
102325dcc:     	stp	q1, q0, [x9, #0x40]
102325dd0:     	add	x8, sp, #0x470
102325dd4:     	ldp	q0, q1, [x8]
102325dd8:     	stur	q0, [x23, #0x8]
102325ddc:     	stur	q1, [x23, #0x18]
102325de0:     	ldp	q0, q1, [x8, #0x20]
102325de4:     	stur	q0, [x23, #0x28]
102325de8:     	strb	w22, [sp, #0x6b8]
102325dec:     	ldr	w8, [sp, #0x7b8]
102325df0:     	stur	w8, [x9, #0x9]
102325df4:     	ldur	w8, [x23, #0x3]
102325df8:     	str	w8, [sp, #0x6bc]
102325dfc:     	ldr	q0, [sp, #0x60]
102325e00:     	stp	q0, q4, [x9, #0x10]
102325e04:     	str	q4, [sp, #0x50]
102325e08:     	add	x22, sp, #0x6b0
102325e0c:     	add	x8, x22, #0x30
102325e10:     	ldr	q0, [sp, #0x10]
102325e14:     	st1.d	{ v0 }[1], [x8]
102325e18:     	ldr	x8, [sp, #0x8c0]
102325e1c:     	ldr	x9, [sp, #0x7c0]
102325e20:     	str	x8, [sp, #0x7b0]
102325e24:     	str	x28, [sp, #0x6e8]
102325e28:     	str	x21, [sp, #0x6b0]
102325e2c:     	stur	q1, [x23, #0x38]
102325e30:     	cbz	x9, 0x102325e3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1444>
102325e34:     	add	x0, sp, #0x7c0
102325e38:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102325e3c:     	add	x8, sp, #0x6b0
102325e40:     	ldur	w8, [x8, #0x1]
102325e44:     	stur	w8, [x29, #-0xa8]
102325e48:     	ldr	w8, [sp, #0x6b4]
102325e4c:     	ldr	w26, [sp, #0x6b8]
102325e50:     	sub	x9, x29, #0xa8
102325e54:     	stur	w8, [x9, #0x3]
102325e58:     	ldr	w8, [sp, #0x6bc]
102325e5c:     	str	x8, [sp, #0x80]
102325e60:     	ldur	q0, [x22, #0xc8]
102325e64:     	stur	q0, [x23, #0x98]
102325e68:     	ldur	q0, [x22, #0xd8]
102325e6c:     	stur	q0, [x23, #0xa8]
102325e70:     	ldur	q0, [x22, #0xe8]
102325e74:     	stur	q0, [x23, #0xb8]
102325e78:     	ldur	q0, [x22, #0xf8]
102325e7c:     	stur	q0, [x23, #0xc8]
102325e80:     	ldur	q0, [x22, #0x88]
102325e84:     	stur	q0, [x23, #0x58]
102325e88:     	ldur	q0, [x22, #0x98]
102325e8c:     	stur	q0, [x23, #0x68]
102325e90:     	ldur	q0, [x22, #0xa8]
102325e94:     	stur	q0, [x23, #0x78]
102325e98:     	ldur	q0, [x22, #0xb8]
102325e9c:     	stur	q0, [x23, #0x88]
102325ea0:     	ldur	q0, [x22, #0x48]
102325ea4:     	stur	q0, [x23, #0x18]
102325ea8:     	ldur	q0, [x22, #0x58]
102325eac:     	stur	q0, [x23, #0x28]
102325eb0:     	ldur	q0, [x22, #0x68]
102325eb4:     	stur	q0, [x23, #0x38]
102325eb8:     	ldur	q0, [x22, #0x78]
102325ebc:     	stur	q0, [x23, #0x48]
102325ec0:     	ldur	q0, [x22, #0x38]
102325ec4:     	stur	q0, [x23, #0x8]
102325ec8:     	str	xzr, [sp, #0x40]
102325ecc:     	add	x0, sp, #0x450
102325ed0:     	bl	0x10233f82c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
102325ed4:     	ldr	x8, [sp, #0x2d8]
102325ed8:     	mov	x9, #-0x1               ; =-1
102325edc:     	ldaddl	x9, x8, [x8]
102325ee0:     	cmp	x8, #0x1
102325ee4:     	b.ne	0x102325ef4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x14fc>
102325ee8:     	dmb	ishld
102325eec:     	add	x0, sp, #0x2d8
102325ef0:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102325ef4:     	ldr	q0, [sp, #0x10]
102325ef8:     	mov.d	x28, v0[1]
102325efc:     	and	w22, w21, #0xff
102325f00:     	and	w21, w26, #0xff
102325f04:     	lsr	w8, w26, #8
102325f08:     	str	x8, [sp, #0x78]
102325f0c:     	mov	w26, #0x1               ; =1
102325f10:     	b	0x102324e50 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x458>
102325f14:     	ldr	w8, [sp, #0x6b4]
102325f18:     	str	x8, [sp, #0x80]
102325f1c:     	ldr	w8, [sp, #0x6b0]
102325f20:     	add	x9, sp, #0x6b0
102325f24:     	ldur	q0, [x9, #0x18]
102325f28:     	str	q0, [sp, #0x10]
102325f2c:     	ldur	q0, [x9, #0x8]
102325f30:     	str	q0, [sp, #0x60]
102325f34:     	ldr	x28, [sp, #0x6d8]
102325f38:     	and	w21, w8, #0xff
102325f3c:     	lsr	w8, w8, #8
102325f40:     	str	x8, [sp, #0x78]
102325f44:     	mov	w22, #0x2b              ; =43
102325f48:     	ldr	x8, [sp, #0x4b0]
102325f4c:     	mov	w9, #0x1                ; =1
102325f50:     	str	w9, [sp, #0x50]
102325f54:     	cmp	x8, #0x4
102325f58:     	b.ne	0x102325af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1100>
102325f5c:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102325f60:     	mov	w8, #0x1                ; =1
102325f64:     	str	x8, [sp, #0x40]
102325f68:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
102325f6c:     	add	x2, x2, #0x2f0
102325f70:     	mov	x0, #0x0                ; =0
102325f74:     	mov	x1, #0x0                ; =0
102325f78:     	bl	0x103a03cd8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
102325f7c:     	brk	#0x1
102325f80:     	add	x0, sp, #0x668
102325f84:     	bl	0x10234107c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
102325f88:     	mov	w21, #0x0               ; =0
102325f8c:     	mov	w22, #0x2c              ; =44
102325f90:     	str	x8, [sp, #0x78]
102325f94:     	str	x8, [sp, #0x80]
102325f98:     	b	0x102326004 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x160c>
102325f9c:     	stp	xzr, xzr, [sp, #0x78]
102325fa0:     	mov	w21, #0x0               ; =0
102325fa4:     	b	0x102325ae0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x10e8>
102325fa8:     	mov	w21, #0x0               ; =0
102325fac:     	str	x8, [sp, #0x78]
102325fb0:     	str	x8, [sp, #0x80]
102325fb4:     	ldr	x8, [sp, #0x4b0]
102325fb8:     	mov	w9, #0x1                ; =1
102325fbc:     	str	w9, [sp, #0x50]
102325fc0:     	cmp	x8, #0x4
102325fc4:     	b.ne	0x102325af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1100>
102325fc8:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102325fcc:     	ldr	q0, [sp, #0x60]
102325fd0:     	mov.s	w8, v0[1]
102325fd4:     	str	x8, [sp, #0x80]
102325fd8:     	fmov	w8, s0
102325fdc:     	ldur	q0, [x23, #0x20]
102325fe0:     	ldr	w9, [sp, #0x7b8]
102325fe4:     	stur	w9, [x29, #-0xa8]
102325fe8:     	ldur	w9, [x23, #0x3]
102325fec:     	sub	x10, x29, #0xa8
102325ff0:     	stur	w9, [x10, #0x3]
102325ff4:     	and	w21, w8, #0xff
102325ff8:     	lsr	w8, w8, #8
102325ffc:     	str	x8, [sp, #0x78]
102326000:     	str	q0, [sp, #0x60]
102326004:     	cmp	x26, #0x4
102326008:     	b.ne	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
10232600c:     	ldr	x8, [sp, #0x4b0]
102326010:     	cmp	x8, #0x4
102326014:     	b.ne	0x102325af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1100>
102326018:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
10232601c:     	ldur	w8, [x23, #0x9]
102326020:     	stur	w8, [x29, #-0xa8]
102326024:     	ldr	w8, [sp, #0x7c4]
102326028:     	ldr	w9, [sp, #0x7c8]
10232602c:     	sub	x10, x29, #0xa8
102326030:     	stur	w8, [x10, #0x3]
102326034:     	ldr	w8, [sp, #0x7cc]
102326038:     	str	x8, [sp, #0x80]
10232603c:     	ldur	q0, [x23, #0x28]
102326040:     	str	q0, [sp, #0x10]
102326044:     	ldur	q0, [x23, #0x18]
102326048:     	str	q0, [sp, #0x60]
10232604c:     	ldr	x28, [sp, #0x7f0]
102326050:     	and	w21, w9, #0xff
102326054:     	lsr	w8, w9, #8
102326058:     	str	x8, [sp, #0x78]
10232605c:     	ldr	x8, [sp, #0x4b0]
102326060:     	mov	w9, #0x1                ; =1
102326064:     	str	w9, [sp, #0x50]
102326068:     	cmp	x8, #0x4
10232606c:     	b.ne	0x102325af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1100>
102326070:     	b	0x102325b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1108>
102326074:     	mov	x20, x0
102326078:     	add	x0, sp, #0x6b0
10232607c:     	bl	0x102341c28 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
102326080:     	str	wzr, [sp, #0x50]
102326084:     	mov	w21, #0x0               ; =0
102326088:     	b	0x1023260e4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x16ec>
10232608c:     	mov	x20, x0
102326090:     	str	wzr, [sp, #0x50]
102326094:     	b	0x1023260e0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x16e8>
102326098:     	mov	x20, x0
10232609c:     	add	x0, sp, #0x6b0
1023260a0:     	bl	0x102341afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
1023260a4:     	mov	w8, #0x1                ; =1
1023260a8:     	str	w8, [sp, #0x50]
1023260ac:     	b	0x102326104 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x170c>
1023260b0:     	mov	x20, x0
1023260b4:     	b	0x102326104 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x170c>
1023260b8:     	mov	x20, x0
1023260bc:     	ldr	w8, [sp, #0x50]
1023260c0:     	tbnz	w8, #0x0, 0x10232611c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1724>
1023260c4:     	b	0x102326138 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1740>
1023260c8:     	mov	x20, x0
1023260cc:     	b	0x10232611c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1724>
1023260d0:     	mov	x20, x0
1023260d4:     	mov	w8, #0x1                ; =1
1023260d8:     	str	w8, [sp, #0x50]
1023260dc:     	str	w21, [sp, #0x78]
1023260e0:     	mov	w21, #0x1               ; =1
1023260e4:     	ldr	w8, [sp, #0x78]
1023260e8:     	cbz	w8, 0x102326100 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1708>
1023260ec:     	ldr	x8, [sp, #0x4b0]
1023260f0:     	cmp	x8, #0x4
1023260f4:     	b.eq	0x102326100 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1708>
1023260f8:     	add	x0, sp, #0x4b0
1023260fc:     	bl	0x102341b74 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
102326100:     	tbz	w21, #0x0, 0x102326114 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x171c>
102326104:     	ldr	x8, [sp, #0x470]
102326108:     	cbz	x8, 0x102326114 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x171c>
10232610c:     	add	x0, sp, #0x470
102326110:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102326114:     	ldr	w8, [sp, #0x50]
102326118:     	tbz	w8, #0x0, 0x102326138 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1740>
10232611c:     	ldr	x8, [sp, #0x40]
102326120:     	cbz	x8, 0x102326138 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1740>
102326124:     	ldr	x8, [sp, #0x40]
102326128:     	lsl	x1, x8, #3
10232612c:     	ldr	x0, [sp]
102326130:     	mov	w2, #0x8                ; =8
102326134:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102326138:     	mov	w21, #0x0               ; =0
10232613c:     	b	0x102326148 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1750>
102326140:     	mov	x20, x0
102326144:     	mov	w21, #0x1               ; =1
102326148:     	add	x0, sp, #0x450
10232614c:     	bl	0x10233f82c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
102326150:     	b	0x1023261fc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1804>
102326154:     	mov	x20, x0
102326158:     	add	x8, sp, #0xa8
10232615c:     	add	x0, x8, #0x20
102326160:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102326164:     	b	0x1023262ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x18b4>
102326168:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10232616c:     	mov	x20, x0
102326170:     	tbnz	w26, #0x0, 0x10232623c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1844>
102326174:     	b	0x102326244 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x184c>
102326178:     	ldr	x21, [sp, #0x40]
10232617c:     	mov	x20, x0
102326180:     	b	0x1023261fc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1804>
102326184:     	mov	x20, x0
102326188:     	mov	w24, #0x0               ; =0
10232618c:     	b	0x102326288 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1890>
102326190:     	mov	x20, x0
102326194:     	b	0x102326244 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x184c>
102326198:     	mov	x20, x0
10232619c:     	ldr	x8, [sp, #0x1e8]
1023261a0:     	cbz	x8, 0x1023262ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x18b4>
1023261a4:     	ldr	x9, [x8]
1023261a8:     	subs	x9, x9, #0x1
1023261ac:     	str	x9, [x8]
1023261b0:     	b.ne	0x1023262ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x18b4>
1023261b4:     	add	x0, x23, #0x8
1023261b8:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1023261bc:     	b	0x1023262ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x18b4>
1023261c0:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1023261c4:     	mov	x20, x0
1023261c8:     	ldr	x8, [sp, #0x1f8]
1023261cc:     	cbz	x8, 0x1023261e8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x17f0>
1023261d0:     	ldr	x9, [x8]
1023261d4:     	subs	x9, x9, #0x1
1023261d8:     	str	x9, [x8]
1023261dc:     	b.ne	0x1023261e8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x17f0>
1023261e0:     	add	x0, x24, #0x8
1023261e4:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1023261e8:     	mov	w24, #0x0               ; =0
1023261ec:     	b	0x102326288 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1890>
1023261f0:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1023261f4:     	mov	x20, x0
1023261f8:     	mov	w21, #0x1               ; =1
1023261fc:     	ldr	x8, [sp, #0x2d8]
102326200:     	mov	x9, #-0x1               ; =-1
102326204:     	ldaddl	x9, x8, [x8]
102326208:     	cmp	x8, #0x1
10232620c:     	b.ne	0x10232621c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1824>
102326210:     	dmb	ishld
102326214:     	add	x0, sp, #0x2d8
102326218:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10232621c:     	tbnz	w21, #0x0, 0x10232623c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1844>
102326220:     	b	0x102326244 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x184c>
102326224:     	mov	x20, x0
102326228:     	ldr	x8, [x21, #0x10]
10232622c:     	sub	x8, x8, #0x1
102326230:     	str	x8, [x21, #0x10]
102326234:     	b	0x10232623c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1844>
102326238:     	mov	x20, x0
10232623c:     	ldr	x0, [sp, #0x48]
102326240:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102326244:     	ldp	x8, x9, [sp, #0x88]
102326248:     	stp	x9, x27, [x19, #0x30]
10232624c:     	str	x8, [x19, #0x40]
102326250:     	b	0x10232625c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1864>
102326254:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102326258:     	mov	x20, x0
10232625c:     	add	x0, sp, #0x1f0
102326260:     	bl	0x1023425cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits10ScopeGuardEBS_>
102326264:     	b	0x102326288 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x1890>
102326268:     	mov	x20, x0
10232626c:     	ldr	x8, [x21]
102326270:     	subs	x8, x8, #0x1
102326274:     	str	x8, [x21]
102326278:     	b.ne	0x102326284 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x188c>
10232627c:     	add	x0, sp, #0x2f0
102326280:     	bl	0x102366a14 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102326284:     	mov	w24, #0x1               ; =1
102326288:     	add	x0, sp, #0x1e0
10232628c:     	bl	0x102342644 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits12AccountGuardEBS_>
102326290:     	tbnz	w24, #0x0, 0x1023262a0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x18a8>
102326294:     	b	0x1023262ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixbENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3Z_8prepared12word_updatesNtB5v_25NativePreparedLibraryCall28unsigned_matrix_replace_withB2g_NCNvB5s_31unsigned_matrix_replace_private0E0EBa_+0x18b4>
102326298:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10232629c:     	mov	x20, x0
1023262a0:     	add	x8, sp, #0x140
1023262a4:     	add	x0, x8, #0x20
1023262a8:     	bl	0x102340540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1023262ac:     	mov	x0, x20
1023262b0:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
1023262b4:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
