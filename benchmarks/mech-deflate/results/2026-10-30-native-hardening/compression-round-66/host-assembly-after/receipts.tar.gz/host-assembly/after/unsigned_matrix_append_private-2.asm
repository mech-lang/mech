
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001028a8f00 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private>:
1028a8f00:     	stp	x28, x27, [sp, #-0x60]!
1028a8f04:     	stp	x26, x25, [sp, #0x10]
1028a8f08:     	stp	x24, x23, [sp, #0x20]
1028a8f0c:     	stp	x22, x21, [sp, #0x30]
1028a8f10:     	stp	x20, x19, [sp, #0x40]
1028a8f14:     	stp	x29, x30, [sp, #0x50]
1028a8f18:     	add	x29, sp, #0x50
1028a8f1c:     	sub	sp, sp, #0x340
1028a8f20:     	mov	x21, x6
1028a8f24:     	mov	x20, x5
1028a8f28:     	mov	x22, x4
1028a8f2c:     	mov	x25, x3
1028a8f30:     	mov	x24, x2
1028a8f34:     	mov	x26, x1
1028a8f38:     	mov	x23, x0
1028a8f3c:     	mov	x19, x8
1028a8f40:     	bl	0x1028a91d8 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall31supports_unsigned_matrix_append>
1028a8f44:     	tbz	w0, #0x0, 0x1028a9008 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x108>
1028a8f48:     	ldp	q0, q1, [x26]
1028a8f4c:     	stp	q0, q1, [sp]
1028a8f50:     	ldp	q0, q1, [x26, #0x20]
1028a8f54:     	stp	q0, q1, [sp, #0x20]
1028a8f58:     	str	xzr, [sp, #0x48]
1028a8f5c:     	str	x24, [sp, #0x88]
1028a8f60:     	strb	w25, [sp, #0x96]
1028a8f64:     	ldr	x8, [x22, #0x30]
1028a8f68:     	ldp	q1, q0, [x22, #0x10]
1028a8f6c:     	ldr	q2, [x22]
1028a8f70:     	mov.d	v0[1], x8
1028a8f74:     	zip1.2d	v1, v2, v1
1028a8f78:     	cmeq.2d	v0, v0, #0
1028a8f7c:     	cmeq.2d	v1, v1, #0
1028a8f80:     	uzp1.4s	v0, v1, v0
1028a8f84:     	umaxv.4s	s0, v0
1028a8f88:     	fmov	w8, s0
1028a8f8c:     	tbnz	w8, #0x0, 0x1028a9038 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x138>
1028a8f90:     	ldr	x8, [x22, #0x40]
1028a8f94:     	cbz	x8, 0x1028a9038 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x138>
1028a8f98:     	ldr	x8, [x22, #0x50]
1028a8f9c:     	cbz	x8, 0x1028a9038 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x138>
1028a8fa0:     	ldr	x8, [x22, #0x60]
1028a8fa4:     	cbz	x8, 0x1028a9038 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x138>
1028a8fa8:     	ldr	x8, [x23, #0x10]
1028a8fac:     	sub	x25, x8, #0x17
1028a8fb0:     	mov	w8, #0x6                ; =6
1028a8fb4:     	cmp	x25, #0x6
1028a8fb8:     	csel	x26, x25, x8, lo
1028a8fbc:     	mov	w8, #0x2c               ; =44
1028a8fc0:     	strb	w8, [sp, #0x1a8]
1028a8fc4:     	cmp	x25, #0x5
1028a8fc8:     	b.hi	0x1028a8ff0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0xf0>
1028a8fcc:     	add	x0, sp, #0x1a8
1028a8fd0:     	bl	0x10282cd60 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1028a8fd4:     	strb	w26, [sp, #0x97]
1028a8fd8:     	cmp	x25, #0x4
1028a8fdc:     	b.eq	0x1028a8fec <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0xec>
1028a8fe0:     	sub	w8, w26, #0x3
1028a8fe4:     	cmp	w8, #0x2
1028a8fe8:     	b.hs	0x1028a90a8 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x1a8>
1028a8fec:     	mov	w8, #0x2c               ; =44
1028a8ff0:     	strb	w8, [x19, #0x8]
1028a8ff4:     	str	xzr, [x19]
1028a8ff8:     	mov	w20, #0x1               ; =1
1028a8ffc:     	ldr	x8, [sp, #0x48]
1028a9000:     	cbnz	x8, 0x1028a9068 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x168>
1028a9004:     	b	0x1028a9070 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x170>
1028a9008:     	mov	w8, #0x2c               ; =44
1028a900c:     	strb	w8, [x19, #0x8]
1028a9010:     	str	xzr, [x19]
1028a9014:     	mov	x0, x26
1028a9018:     	add	sp, sp, #0x340
1028a901c:     	ldp	x29, x30, [sp, #0x50]
1028a9020:     	ldp	x20, x19, [sp, #0x40]
1028a9024:     	ldp	x22, x21, [sp, #0x30]
1028a9028:     	ldp	x24, x23, [sp, #0x20]
1028a902c:     	ldp	x26, x25, [sp, #0x10]
1028a9030:     	ldp	x28, x27, [sp], #0x60
1028a9034:     	b	0x10282bd7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1028a9038:     	ldr	w8, [x23, #0x110]
1028a903c:     	mov	w9, #0x22               ; =34
1028a9040:     	strb	w9, [x19, #0x8]
1028a9044:     	adrp	x9, 0x1076d5000 <_anon.3e49e8fa6a532448d7536ab560d50070.429+0x756>
1028a9048:     	add	x9, x9, #0xbc0
1028a904c:     	mov	w10, #0x36              ; =54
1028a9050:     	stp	x9, x10, [x19, #0x10]
1028a9054:     	str	w8, [x19, #0x20]
1028a9058:     	str	xzr, [x19]
1028a905c:     	mov	w20, #0x1               ; =1
1028a9060:     	ldr	x8, [sp, #0x48]
1028a9064:     	cbz	x8, 0x1028a9070 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x170>
1028a9068:     	add	x0, sp, #0x48
1028a906c:     	bl	0x10282bd7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1028a9070:     	ldr	x8, [sp]
1028a9074:     	cmp	x8, #0x0
1028a9078:     	csel	w8, wzr, w20, eq
1028a907c:     	tbz	w8, #0x0, 0x1028a9088 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x188>
1028a9080:     	mov	x0, sp
1028a9084:     	bl	0x10282bd7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1028a9088:     	add	sp, sp, #0x340
1028a908c:     	ldp	x29, x30, [sp, #0x50]
1028a9090:     	ldp	x20, x19, [sp, #0x40]
1028a9094:     	ldp	x22, x21, [sp, #0x30]
1028a9098:     	ldp	x24, x23, [sp, #0x20]
1028a909c:     	ldp	x26, x25, [sp, #0x10]
1028a90a0:     	ldp	x28, x27, [sp], #0x60
1028a90a4:     	ret
1028a90a8:     	sub	x8, x29, #0xd8
1028a90ac:     	ldp	q0, q1, [sp]
1028a90b0:     	stur	q0, [x8, #0x48]
1028a90b4:     	stur	q1, [x8, #0x58]
1028a90b8:     	ldp	q0, q1, [sp, #0x20]
1028a90bc:     	stur	q0, [x8, #0x68]
1028a90c0:     	str	x24, [sp, #0x98]
1028a90c4:     	ldr	x1, [x22, #0x68]
1028a90c8:     	ldr	x2, [x22, #0x58]
1028a90cc:     	stp	x20, x23, [x29, #-0xd8]
1028a90d0:     	add	x9, sp, #0x97
1028a90d4:     	add	x10, sp, #0x88
1028a90d8:     	stp	x9, x10, [x29, #-0xc8]
1028a90dc:     	stur	q1, [x8, #0x78]
1028a90e0:     	add	x8, sp, #0x48
1028a90e4:     	add	x9, sp, #0x98
1028a90e8:     	stp	x8, x9, [x29, #-0xb8]
1028a90ec:     	stp	x22, x21, [x29, #-0xa8]
1028a90f0:     	add	x8, sp, #0x96
1028a90f4:     	stur	x8, [x29, #-0x98]
1028a90f8:     	add	x21, sp, #0x1a8
1028a90fc:     	add	x8, sp, #0x1a8
1028a9100:     	sub	x3, x29, #0xd8
1028a9104:     	mov	x0, x20
1028a9108:     	bl	0x10231d250 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixNtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMNtNtB3W_8prepared16unsigned_buffersNtB5s_25NativePreparedLibraryCall20unsigned_buffer_withB2f_NCNvB5p_30unsigned_matrix_append_private0E0EBa_>
1028a910c:     	ldr	w8, [sp, #0x1a8]
1028a9110:     	tbz	w8, #0x0, 0x1028a9168 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x268>
1028a9114:     	mov	w20, #0x0               ; =0
1028a9118:     	add	x8, sp, #0x1a8
1028a911c:     	ldur	q0, [x21, #0x8]
1028a9120:     	ldur	q1, [x21, #0x18]
1028a9124:     	ldur	x9, [x21, #0x28]
1028a9128:     	str	x9, [sp, #0xc0]
1028a912c:     	stur	x9, [x8, #0x27]
1028a9130:     	mov	w9, #0x29               ; =41
1028a9134:     	strb	w9, [x19, #0x8]
1028a9138:     	stp	q0, q1, [sp, #0xa0]
1028a913c:     	stur	q0, [x8, #0x7]
1028a9140:     	stur	q1, [x8, #0x17]
1028a9144:     	ldp	q0, q1, [x8]
1028a9148:     	stur	q0, [x19, #0x9]
1028a914c:     	stur	q1, [x19, #0x19]
1028a9150:     	ldur	q0, [x8, #0x1f]
1028a9154:     	stur	q0, [x19, #0x28]
1028a9158:     	str	xzr, [x19]
1028a915c:     	ldr	x8, [sp, #0x48]
1028a9160:     	cbnz	x8, 0x1028a9068 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x168>
1028a9164:     	b	0x1028a9070 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x170>
1028a9168:     	add	x0, sp, #0xa0
1028a916c:     	add	x1, x21, #0x8
1028a9170:     	mov	w2, #0x108              ; =264
1028a9174:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028a9178:     	add	x1, sp, #0xa0
1028a917c:     	mov	x0, x19
1028a9180:     	mov	w2, #0x108              ; =264
1028a9184:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028a9188:     	ldr	x8, [sp, #0x48]
1028a918c:     	cbz	x8, 0x1028a9088 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x188>
1028a9190:     	add	x0, sp, #0x48
1028a9194:     	b	0x1028a9084 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x184>
1028a9198:     	mov	x19, x0
1028a919c:     	ldr	x8, [sp, #0x48]
1028a91a0:     	cbz	x8, 0x1028a91cc <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x2cc>
1028a91a4:     	add	x0, sp, #0x48
1028a91a8:     	bl	0x10282bd7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1028a91ac:     	b	0x1028a91cc <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x2cc>
1028a91b0:     	mov	x19, x0
1028a91b4:     	ldr	x8, [sp]
1028a91b8:     	cmp	x8, #0x0
1028a91bc:     	csel	w8, wzr, w20, eq
1028a91c0:     	tbz	w8, #0x0, 0x1028a91cc <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private+0x2cc>
1028a91c4:     	mov	x0, sp
1028a91c8:     	bl	0x10282bd7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1028a91cc:     	mov	x0, x19
1028a91d0:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
1028a91d4:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
