
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e2b120 <__RNvYNCNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtBb_5Value28into_private_unsigned_matrixs0_0INtNtNtCsgDHHaSskbIF_4core3ops8function6FnOnceuE9call_onceBf_>:
102e2b120:     	stp	x20, x19, [sp, #-0x20]!
102e2b124:     	stp	x29, x30, [sp, #0x10]
102e2b128:     	add	x29, sp, #0x10
102e2b12c:     	mov	x19, x0
102e2b130:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e2b134:     	mov	w0, #0x43               ; =67
102e2b138:     	mov	w1, #0x1                ; =1
102e2b13c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e2b140:     	cbz	x0, 0x102e2b18c <__RNvYNCNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtBb_5Value28into_private_unsigned_matrixs0_0INtNtNtCsgDHHaSskbIF_4core3ops8function6FnOnceuE9call_onceBf_+0x6c>
102e2b144:     	mov	w8, #0x6e77             ; =28279
102e2b148:     	movk	w8, #0x7265, lsl #16
102e2b14c:     	stur	w8, [x0, #0x3f]
102e2b150:     	adrp	x8, 0x107708000 <_anon.e5ab26e9f9da5eb49b5a7d29064db6f1.16+0x58c>
102e2b154:     	add	x8, x8, #0xbc5
102e2b158:     	ldp	q0, q1, [x8]
102e2b15c:     	stp	q0, q1, [x0]
102e2b160:     	ldp	q0, q1, [x8, #0x20]
102e2b164:     	stp	q0, q1, [x0, #0x20]
102e2b168:     	mov	w8, #0x43               ; =67
102e2b16c:     	stp	x8, x0, [x19, #0x10]
102e2b170:     	str	x8, [x19, #0x20]
102e2b174:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x3218>
102e2b178:     	ldr	d0, [x8, #0x168]
102e2b17c:     	str	d0, [x19]
102e2b180:     	ldp	x29, x30, [sp, #0x10]
102e2b184:     	ldp	x20, x19, [sp], #0x20
102e2b188:     	ret
102e2b18c:     	mov	w0, #0x1                ; =1
102e2b190:     	mov	w1, #0x43               ; =67
102e2b194:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
