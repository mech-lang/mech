
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e0c1a8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit>:
102e0c1a8:     	sub	sp, sp, #0x130
102e0c1ac:     	stp	x28, x27, [sp, #0xd0]
102e0c1b0:     	stp	x26, x25, [sp, #0xe0]
102e0c1b4:     	stp	x24, x23, [sp, #0xf0]
102e0c1b8:     	stp	x22, x21, [sp, #0x100]
102e0c1bc:     	stp	x20, x19, [sp, #0x110]
102e0c1c0:     	stp	x29, x30, [sp, #0x120]
102e0c1c4:     	add	x29, sp, #0x120
102e0c1c8:     	mov	x19, x1
102e0c1cc:     	ldr	x23, [x1, #0x30]
102e0c1d0:     	cbz	x23, 0x102e0c670 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x4c8>
102e0c1d4:     	mov	w8, #0x1                ; =1
102e0c1d8:     	ldadd	x8, x8, [x23]
102e0c1dc:     	tbnz	x8, #0x3f, 0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c1e0:     	mov	x21, x2
102e0c1e4:     	str	x23, [sp, #0x8]
102e0c1e8:     	ldr	x24, [x2]
102e0c1ec:     	mov	w8, #0x1                ; =1
102e0c1f0:     	ldadd	x8, x8, [x24]
102e0c1f4:     	tbnz	x8, #0x3f, 0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c1f8:     	mov	x20, x0
102e0c1fc:     	ldp	x28, x25, [x21, #0x8]
102e0c200:     	stp	x24, x28, [sp, #0x10]
102e0c204:     	str	x25, [sp, #0x20]
102e0c208:     	add	x0, sp, #0x30
102e0c20c:     	mov	x1, x19
102e0c210:     	bl	0x102e13eb4 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value31memory_budget_ownership_witness>
102e0c214:     	ldr	w8, [sp, #0x30]
102e0c218:     	cmp	w8, #0x1a
102e0c21c:     	b.ne	0x102e0c248 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0xa0>
102e0c220:     	ldp	x22, x26, [sp, #0x38]
102e0c224:     	ldr	x8, [x19, #0x8]
102e0c228:     	ldr	x8, [x8, #0x10]
102e0c22c:     	ldapur	x9, [x8, #0x50]
102e0c230:     	cbz	x9, 0x102e0c268 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0xc0>
102e0c234:     	mov	x8, #0x0                ; =0
102e0c238:     	sub	x8, x22, x8
102e0c23c:     	cmn	x8, #0x69
102e0c240:     	b.ls	0x102e0c2c8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x120>
102e0c244:     	b	0x102e0c30c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x164>
102e0c248:     	ldr	w9, [sp, #0x34]
102e0c24c:     	ldur	q0, [sp, #0x48]
102e0c250:     	ldr	x10, [sp, #0x58]
102e0c254:     	str	x10, [x20, #0x30]
102e0c258:     	ldur	q1, [sp, #0x38]
102e0c25c:     	stp	w8, w9, [x20, #0x8]
102e0c260:     	stp	q1, q0, [x20, #0x10]
102e0c264:     	b	0x102e0c4e4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x33c>
102e0c268:     	str	x22, [sp]
102e0c26c:     	ldr	x22, [x8, #0x58]
102e0c270:     	ldr	x27, [x22, #0x20]
102e0c274:     	cbz	x27, 0x102e0c2b4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x10c>
102e0c278:     	mov	w8, #0x1                ; =1
102e0c27c:     	ldadd	x8, x8, [x27]
102e0c280:     	tbnz	x8, #0x3f, 0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c284:     	stur	x27, [x29, #-0x80]
102e0c288:     	ldur	q0, [x22, #0x28]
102e0c28c:     	stur	q0, [x29, #-0x78]
102e0c290:     	mov	x8, #-0x1               ; =-1
102e0c294:     	ldaddl	x8, x8, [x27]
102e0c298:     	cmp	x8, #0x1
102e0c29c:     	b.ne	0x102e0c2ac <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x104>
102e0c2a0:     	dmb	ishld
102e0c2a4:     	sub	x0, x29, #0x80
102e0c2a8:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102e0c2ac:     	cmp	x27, x24
102e0c2b0:     	b.eq	0x102e0c2f0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x148>
102e0c2b4:     	mov	x8, #0x0                ; =0
102e0c2b8:     	ldr	x22, [sp]
102e0c2bc:     	sub	x8, x22, x8
102e0c2c0:     	cmn	x8, #0x69
102e0c2c4:     	b.hi	0x102e0c30c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x164>
102e0c2c8:     	add	x27, x8, #0x68
102e0c2cc:     	ldr	x8, [x21, #0x18]
102e0c2d0:     	cmp	x27, x8
102e0c2d4:     	b.ls	0x102e0c330 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x188>
102e0c2d8:     	mov	w9, #0xa                ; =10
102e0c2dc:     	str	w9, [x20, #0x8]
102e0c2e0:     	stp	x27, x8, [x20, #0x10]
102e0c2e4:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
102e0c2e8:     	str	x8, [x20, #0x20]
102e0c2ec:     	b	0x102e0c4e4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x33c>
102e0c2f0:     	ldr	x8, [x22, #0x38]
102e0c2f4:     	ldr	x22, [sp]
102e0c2f8:     	cmp	x8, x22
102e0c2fc:     	csel	x8, x8, x22, lo
102e0c300:     	sub	x8, x22, x8
102e0c304:     	cmn	x8, #0x69
102e0c308:     	b.ls	0x102e0c2c8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x120>
102e0c30c:     	add	x0, sp, #0x30
102e0c310:     	bl	0x102e07d6c <__RNCNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB7_5Value45unshared_memory_budget_admission_for_requireds_0Bb_>
102e0c314:     	ldr	w8, [sp, #0x30]
102e0c318:     	cmp	w8, #0x1a
102e0c31c:     	b.ne	0x102e0c68c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x4e4>
102e0c320:     	ldr	x27, [sp, #0x38]
102e0c324:     	ldr	x8, [x21, #0x18]
102e0c328:     	cmp	x27, x8
102e0c32c:     	b.hi	0x102e0c2d8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x130>
102e0c330:     	ldapur	x8, [x24, #0x30]
102e0c334:     	cbz	x8, 0x102e0c35c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x1b4>
102e0c338:     	sub	x10, x8, #0x1
102e0c33c:     	add	x11, x24, #0x30
102e0c340:     	mov	x9, x8
102e0c344:     	casal	x9, x10, [x11]
102e0c348:     	cmp	x9, x8
102e0c34c:     	mov	x8, x9
102e0c350:     	b.ne	0x102e0c334 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x18c>
102e0c354:     	cmp	x9, #0x1
102e0c358:     	b.eq	0x102e0c4c8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x320>
102e0c35c:     	mov	w8, #0x1                ; =1
102e0c360:     	ldadd	x8, x8, [x24]
102e0c364:     	tbnz	x8, #0x3f, 0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c368:     	stp	x24, x28, [x29, #-0x80]
102e0c36c:     	stur	x25, [x29, #-0x70]
102e0c370:     	b	0x102e0c378 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x1d0>
102e0c374:     	isb
102e0c378:     	ldr	x8, [x23, #0x8]
102e0c37c:     	cmn	x8, #0x1
102e0c380:     	b.eq	0x102e0c374 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x1cc>
102e0c384:     	tbnz	x8, #0x3f, 0x102e0c640 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x498>
102e0c388:     	add	x9, x8, #0x1
102e0c38c:     	add	x10, x23, #0x8
102e0c390:     	mov	x11, x8
102e0c394:     	casa	x11, x9, [x10]
102e0c398:     	cmp	x11, x8
102e0c39c:     	mov	x8, x11
102e0c3a0:     	b.ne	0x102e0c37c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x1d4>
102e0c3a4:     	str	x22, [sp]
102e0c3a8:     	ldr	x8, [x19]
102e0c3ac:     	mov	w9, #0x1                ; =1
102e0c3b0:     	ldadd	x9, x8, [x8]
102e0c3b4:     	tbnz	x8, #0x3f, 0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c3b8:     	ldr	x8, [x19]
102e0c3bc:     	ldur	q0, [x29, #-0x80]
102e0c3c0:     	mov	w9, #0x1                ; =1
102e0c3c4:     	dup.2d	v1, x9
102e0c3c8:     	ldur	x9, [x29, #-0x70]
102e0c3cc:     	stp	q1, q0, [sp, #0x30]
102e0c3d0:     	stp	x9, x23, [sp, #0x50]
102e0c3d4:     	mov	w9, #0x3                ; =3
102e0c3d8:     	stp	x8, x9, [sp, #0x60]
102e0c3dc:     	str	xzr, [sp, #0x78]
102e0c3e0:     	strb	wzr, [sp, #0x80]
102e0c3e4:     	mov	x8, #-0x1               ; =-1
102e0c3e8:     	stp	x8, xzr, [sp, #0x88]
102e0c3ec:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e0c3f0:     	mov	w0, #0x68               ; =104
102e0c3f4:     	mov	w1, #0x8                ; =8
102e0c3f8:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e0c3fc:     	cbz	x0, 0x102e0c4bc <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x314>
102e0c400:     	ldp	q0, q1, [sp, #0x70]
102e0c404:     	stp	q0, q1, [x0, #0x40]
102e0c408:     	ldr	x8, [sp, #0x90]
102e0c40c:     	str	x8, [x0, #0x60]
102e0c410:     	ldp	q0, q1, [sp, #0x30]
102e0c414:     	stp	q0, q1, [x0]
102e0c418:     	ldp	q1, q0, [sp, #0x50]
102e0c41c:     	stp	q1, q0, [x0, #0x20]
102e0c420:     	str	x0, [sp, #0x28]
102e0c424:     	ldapur	x8, [x24, #0x28]
102e0c428:     	add	x22, x8, x26
102e0c42c:     	cmp	x22, x8
102e0c430:     	ccmp	x22, x25, #0x2, hs
102e0c434:     	b.hi	0x102e0c544 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x39c>
102e0c438:     	add	x9, x24, #0x28
102e0c43c:     	mov	x10, x8
102e0c440:     	casal	x10, x22, [x9]
102e0c444:     	cmp	x10, x8
102e0c448:     	mov	x8, x10
102e0c44c:     	b.ne	0x102e0c428 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x280>
102e0c450:     	add	x8, x24, #0x20
102e0c454:     	ldaddal	x26, x8, [x8]
102e0c458:     	mov	w8, #0x1                ; =1
102e0c45c:     	ldadd	x8, x8, [x24]
102e0c460:     	tbnz	x8, #0x3f, 0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c464:     	stp	x24, x28, [sp, #0x30]
102e0c468:     	stp	x25, x26, [sp, #0x40]
102e0c46c:     	ldr	x8, [x21, #0x18]
102e0c470:     	subs	x9, x8, x27
102e0c474:     	ldr	x10, [sp]
102e0c478:     	b.hs	0x102e0c5dc <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x434>
102e0c47c:     	mov	x21, x0
102e0c480:     	stp	x8, x27, [x20, #0x10]
102e0c484:     	adrp	x8, 0x107702000 <_anon.c733ff1187bca7d3bb3de6458e29153a.1149+0x584>
102e0c488:     	add	x8, x8, #0x5af
102e0c48c:     	mov	w9, #0x23               ; =35
102e0c490:     	stp	x8, x9, [x20, #0x20]
102e0c494:     	mov	w8, #0x19               ; =25
102e0c498:     	str	w8, [x20, #0x8]
102e0c49c:     	str	xzr, [x20]
102e0c4a0:     	add	x0, sp, #0x30
102e0c4a4:     	bl	0x102e05064 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget18SnapshotNodeChargeEBM_>
102e0c4a8:     	mov	x8, #-0x1               ; =-1
102e0c4ac:     	ldaddl	x8, x8, [x21]
102e0c4b0:     	cmp	x8, #0x1
102e0c4b4:     	b.ne	0x102e0c4e8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x340>
102e0c4b8:     	b	0x102e0c5cc <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x424>
102e0c4bc:     	add	x8, sp, #0x30
102e0c4c0:     	add	x0, x8, #0x10
102e0c4c4:     	bl	0x102e0587c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation26SnapshotBudgetRegistrationEBM_>
102e0c4c8:     	adrp	x8, 0x107550000 <_anon.4e4cf234dac9fe76f818f23bf1907424.753+0x2d8>
102e0c4cc:     	ldr	d0, [x8, #0xf18]
102e0c4d0:     	str	d0, [x20, #0x8]
102e0c4d4:     	mov	w8, #0x68               ; =104
102e0c4d8:     	str	x8, [x20, #0x10]
102e0c4dc:     	str	wzr, [x20, #0x18]
102e0c4e0:     	str	wzr, [x20, #0x20]
102e0c4e4:     	str	xzr, [x20]
102e0c4e8:     	mov	x20, #-0x1              ; =-1
102e0c4ec:     	ldaddl	x20, x8, [x24]
102e0c4f0:     	cmp	x8, #0x1
102e0c4f4:     	b.ne	0x102e0c504 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x35c>
102e0c4f8:     	dmb	ishld
102e0c4fc:     	add	x0, sp, #0x10
102e0c500:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102e0c504:     	ldaddl	x20, x8, [x23]
102e0c508:     	cmp	x8, #0x1
102e0c50c:     	b.ne	0x102e0c51c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x374>
102e0c510:     	dmb	ishld
102e0c514:     	add	x0, sp, #0x8
102e0c518:     	bl	0x102e196e4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core6schema5table11SchemaTableE9drop_slowBM_>
102e0c51c:     	mov	x0, x19
102e0c520:     	bl	0x102e05a48 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEBM_>
102e0c524:     	ldp	x29, x30, [sp, #0x120]
102e0c528:     	ldp	x20, x19, [sp, #0x110]
102e0c52c:     	ldp	x22, x21, [sp, #0x100]
102e0c530:     	ldp	x24, x23, [sp, #0xf0]
102e0c534:     	ldp	x26, x25, [sp, #0xe0]
102e0c538:     	ldp	x28, x27, [sp, #0xd0]
102e0c53c:     	add	sp, sp, #0x130
102e0c540:     	ret
102e0c544:     	mov	x21, x0
102e0c548:     	cmp	x22, x8
102e0c54c:     	b.lo	0x102e0c6ac <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x504>
102e0c550:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e0c554:     	mov	w0, #0x17               ; =23
102e0c558:     	mov	w1, #0x1                ; =1
102e0c55c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e0c560:     	cbz	x0, 0x102e0c6c8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x520>
102e0c564:     	adrp	x8, 0x107702000 <_anon.c733ff1187bca7d3bb3de6458e29153a.1149+0x584>
102e0c568:     	add	x8, x8, #0x32e
102e0c56c:     	ldr	q0, [x8]
102e0c570:     	str	q0, [x0]
102e0c574:     	ldur	x8, [x8, #0xf]
102e0c578:     	mov	w10, #0x17              ; =23
102e0c57c:     	mov	w9, #0xa                ; =10
102e0c580:     	stur	x8, [x0, #0xf]
102e0c584:     	stur	x10, [x29, #-0x80]
102e0c588:     	sub	x11, x29, #0x68
102e0c58c:     	sub	x12, x29, #0x60
102e0c590:     	mov	x8, x22
102e0c594:     	mov	x26, x25
102e0c598:     	str	x0, [x12]
102e0c59c:     	str	x10, [x11]
102e0c5a0:     	ldur	x10, [x29, #-0x80]
102e0c5a4:     	ldp	x12, x11, [x29, #-0x68]
102e0c5a8:     	stp	x8, x26, [x20, #0x10]
102e0c5ac:     	stp	x10, x11, [x20, #0x20]
102e0c5b0:     	str	w9, [x20, #0x8]
102e0c5b4:     	str	x12, [x20, #0x30]
102e0c5b8:     	str	xzr, [x20]
102e0c5bc:     	mov	x8, #-0x1               ; =-1
102e0c5c0:     	ldaddl	x8, x8, [x21]
102e0c5c4:     	cmp	x8, #0x1
102e0c5c8:     	b.ne	0x102e0c4e8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x340>
102e0c5cc:     	dmb	ishld
102e0c5d0:     	add	x0, sp, #0x28
102e0c5d4:     	bl	0x102e19938 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation26SnapshotBudgetRegistrationE9drop_slowBM_>
102e0c5d8:     	b	0x102e0c4e8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x340>
102e0c5dc:     	str	x9, [x21, #0x18]
102e0c5e0:     	ldr	x8, [x21]
102e0c5e4:     	mov	w9, #0x1                ; =1
102e0c5e8:     	ldadd	x9, x9, [x8]
102e0c5ec:     	tbnz	x9, #0x3f, 0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c5f0:     	stp	x23, x8, [x20, #0x48]
102e0c5f4:     	ldur	q0, [x21, #0x8]
102e0c5f8:     	stur	q0, [x20, #0x58]
102e0c5fc:     	str	x27, [x20, #0x68]
102e0c600:     	ldp	q0, q1, [x19]
102e0c604:     	stp	q0, q1, [x20]
102e0c608:     	ldp	q0, q1, [x19, #0x20]
102e0c60c:     	stp	q0, q1, [x20, #0x20]
102e0c610:     	ldp	q0, q1, [sp, #0x30]
102e0c614:     	stp	q0, q1, [x20, #0x70]
102e0c618:     	str	x0, [x20, #0x40]
102e0c61c:     	stp	x10, xzr, [x20, #0x90]
102e0c620:     	mov	x8, #-0x1               ; =-1
102e0c624:     	ldaddl	x8, x8, [x24]
102e0c628:     	cmp	x8, #0x1
102e0c62c:     	b.ne	0x102e0c524 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x37c>
102e0c630:     	dmb	ishld
102e0c634:     	add	x0, sp, #0x10
102e0c638:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102e0c63c:     	b	0x102e0c524 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x37c>
102e0c640:     	adrp	x8, 0x108064000 <_anon.0feedccc3211c9143240ab37fbdc3870.74+0x1d0>
102e0c644:     	add	x8, x8, #0x128
102e0c648:     	adrp	x9, 0x102d38000 <__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorNtB6_5Debug3fmtBC_+0x530>
102e0c64c:     	add	x9, x9, #0x428
102e0c650:     	stp	x8, x9, [sp, #0x30]
102e0c654:     	adrp	x0, 0x107719000 <_anon.83f825c59faa74242fea672bbf027ffa.6+0xd8>
102e0c658:     	add	x0, x0, #0x689
102e0c65c:     	adrp	x2, 0x108064000 <_anon.0feedccc3211c9143240ab37fbdc3870.74+0x1d0>
102e0c660:     	add	x2, x2, #0x138
102e0c664:     	add	x1, sp, #0x30
102e0c668:     	bl	0x103a03e48 <__RNvNtCsgDHHaSskbIF_4core9panicking9panic_fmt>
102e0c66c:     	b	0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c670:     	adrp	x0, 0x107708000 <_anon.e5ab26e9f9da5eb49b5a7d29064db6f1.16+0x58c>
102e0c674:     	add	x0, x0, #0xde9
102e0c678:     	adrp	x2, 0x108063000 <_anon.b365aac6d40a4e72c1c3bf1709571b3a.249+0xd18>
102e0c67c:     	add	x2, x2, #0xda0
102e0c680:     	mov	w1, #0x16               ; =22
102e0c684:     	bl	0x103a03c0c <__RNvNtCsgDHHaSskbIF_4core6option13expect_failed>
102e0c688:     	b	0x102e0c6d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x52c>
102e0c68c:     	ldr	w9, [sp, #0x34]
102e0c690:     	ldr	x10, [sp, #0x38]
102e0c694:     	ldp	q0, q1, [sp, #0x40]
102e0c698:     	stur	q0, [x20, #0x18]
102e0c69c:     	stur	q1, [x20, #0x28]
102e0c6a0:     	stp	w8, w9, [x20, #0x8]
102e0c6a4:     	str	x10, [x20, #0x10]
102e0c6a8:     	b	0x102e0c4e4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x33c>
102e0c6ac:     	mov	w9, #0x19               ; =25
102e0c6b0:     	sub	x11, x29, #0x60
102e0c6b4:     	sub	x12, x29, #0x80
102e0c6b8:     	mov	w10, #0x1d              ; =29
102e0c6bc:     	adrp	x0, 0x107702000 <_anon.c733ff1187bca7d3bb3de6458e29153a.1149+0x584>
102e0c6c0:     	add	x0, x0, #0x4d7
102e0c6c4:     	b	0x102e0c598 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x3f0>
102e0c6c8:     	mov	w0, #0x1                ; =1
102e0c6cc:     	mov	w1, #0x17               ; =23
102e0c6d0:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102e0c6d4:     	brk	#0x1
102e0c6d8:     	mov	x20, x0
102e0c6dc:     	mov	x8, #-0x1               ; =-1
102e0c6e0:     	ldaddl	x8, x8, [x21]
102e0c6e4:     	cmp	x8, #0x1
102e0c6e8:     	b.ne	0x102e0c730 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x588>
102e0c6ec:     	dmb	ishld
102e0c6f0:     	add	x0, sp, #0x28
102e0c6f4:     	bl	0x102e19938 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation26SnapshotBudgetRegistrationE9drop_slowBM_>
102e0c6f8:     	b	0x102e0c730 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x588>
102e0c6fc:     	mov	x20, x0
102e0c700:     	b	0x102e0c730 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x588>
102e0c704:     	mov	x20, x0
102e0c708:     	b	0x102e0c764 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x5bc>
102e0c70c:     	mov	x20, x0
102e0c710:     	ldur	x8, [x29, #-0x80]
102e0c714:     	mov	x9, #-0x1               ; =-1
102e0c718:     	ldaddl	x9, x8, [x8]
102e0c71c:     	cmp	x8, #0x1
102e0c720:     	b.ne	0x102e0c730 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x588>
102e0c724:     	dmb	ishld
102e0c728:     	sub	x0, x29, #0x80
102e0c72c:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102e0c730:     	mov	x21, #-0x1              ; =-1
102e0c734:     	ldaddl	x21, x8, [x24]
102e0c738:     	cmp	x8, #0x1
102e0c73c:     	b.ne	0x102e0c74c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x5a4>
102e0c740:     	dmb	ishld
102e0c744:     	add	x0, sp, #0x10
102e0c748:     	bl	0x102e19498 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102e0c74c:     	ldaddl	x21, x8, [x23]
102e0c750:     	cmp	x8, #0x1
102e0c754:     	b.ne	0x102e0c764 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix5admit+0x5bc>
102e0c758:     	dmb	ishld
102e0c75c:     	add	x0, sp, #0x8
102e0c760:     	bl	0x102e196e4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core6schema5table11SchemaTableE9drop_slowBM_>
102e0c764:     	mov	x0, x19
102e0c768:     	bl	0x102e05a48 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEBM_>
102e0c76c:     	mov	x0, x20
102e0c770:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
102e0c774:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
