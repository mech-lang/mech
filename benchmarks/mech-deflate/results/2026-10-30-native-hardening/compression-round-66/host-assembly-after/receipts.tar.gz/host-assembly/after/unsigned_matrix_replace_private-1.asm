
/private/tmp/mech-private-numeric-lifetime-round66-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010235fa10 <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB6_25NativePreparedLibraryCall31unsigned_matrix_replace_private0Be_>:
10235fa10:     	sub	sp, sp, #0x1b0
10235fa14:     	stp	x22, x21, [sp, #0x180]
10235fa18:     	stp	x20, x19, [sp, #0x190]
10235fa1c:     	stp	x29, x30, [sp, #0x1a0]
10235fa20:     	add	x29, sp, #0x1a0
10235fa24:     	mov	x20, x2
10235fa28:     	mov	x21, x1
10235fa2c:     	mov	x19, x0
10235fa30:     	mov	w8, #0x2c               ; =44
10235fa34:     	strb	w8, [sp, #0x38]
10235fa38:     	add	x0, sp, #0x38
10235fa3c:     	bl	0x102341d7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10235fa40:     	ldp	q0, q1, [x21]
10235fa44:     	stp	q0, q1, [x29, #-0x60]
10235fa48:     	ldp	q0, q1, [x21, #0x20]
10235fa4c:     	stp	q0, q1, [x29, #-0x40]
10235fa50:     	add	x8, sp, #0x38
10235fa54:     	sub	x0, x29, #0x60
10235fa58:     	mov	x1, x20
10235fa5c:     	bl	0x102e182ec <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB6_5Value28into_private_unsigned_matrix>
10235fa60:     	ldr	x8, [sp, #0x38]
10235fa64:     	ldp	q0, q1, [sp, #0x40]
10235fa68:     	stp	q0, q1, [sp]
10235fa6c:     	ldur	q0, [sp, #0x60]
10235fa70:     	str	q0, [sp, #0x20]
10235fa74:     	cbz	x8, 0x10235fafc <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB6_25NativePreparedLibraryCall31unsigned_matrix_replace_private0Be_+0xec>
10235fa78:     	add	x9, sp, #0x38
10235fa7c:     	ldur	q0, [x9, #0xc8]
10235fa80:     	stur	q0, [x19, #0xc8]
10235fa84:     	ldur	q0, [x9, #0xd8]
10235fa88:     	stur	q0, [x19, #0xd8]
10235fa8c:     	ldur	q0, [x9, #0xe8]
10235fa90:     	stur	q0, [x19, #0xe8]
10235fa94:     	ldur	q0, [x9, #0xf8]
10235fa98:     	stur	q0, [x19, #0xf8]
10235fa9c:     	ldur	q0, [x9, #0x88]
10235faa0:     	stur	q0, [x19, #0x88]
10235faa4:     	ldur	q0, [x9, #0x98]
10235faa8:     	stur	q0, [x19, #0x98]
10235faac:     	ldur	q0, [x9, #0xa8]
10235fab0:     	stur	q0, [x19, #0xa8]
10235fab4:     	ldur	q0, [x9, #0xb8]
10235fab8:     	stur	q0, [x19, #0xb8]
10235fabc:     	ldur	q0, [x9, #0x48]
10235fac0:     	stur	q0, [x19, #0x48]
10235fac4:     	ldur	q0, [x9, #0x58]
10235fac8:     	stur	q0, [x19, #0x58]
10235facc:     	ldur	q0, [x9, #0x68]
10235fad0:     	stur	q0, [x19, #0x68]
10235fad4:     	ldur	q0, [x9, #0x78]
10235fad8:     	stur	q0, [x19, #0x78]
10235fadc:     	ldur	q0, [sp, #0x70]
10235fae0:     	stur	q0, [x19, #0x38]
10235fae4:     	ldp	q0, q1, [sp]
10235fae8:     	stur	q0, [x19, #0x8]
10235faec:     	stur	q1, [x19, #0x18]
10235faf0:     	ldr	q0, [sp, #0x20]
10235faf4:     	stur	q0, [x19, #0x28]
10235faf8:     	b	0x10235fb38 <__RNCNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB6_25NativePreparedLibraryCall31unsigned_matrix_replace_private0Be_+0x128>
10235fafc:     	ldp	q0, q1, [sp]
10235fb00:     	stur	q0, [sp, #0x3f]
10235fb04:     	stur	q1, [sp, #0x4f]
10235fb08:     	ldr	q0, [sp, #0x20]
10235fb0c:     	stur	q0, [sp, #0x5f]
10235fb10:     	ldur	q0, [sp, #0x38]
10235fb14:     	ldur	q1, [sp, #0x48]
10235fb18:     	stur	q0, [x19, #0x9]
10235fb1c:     	mov	w9, #0x2b               ; =43
10235fb20:     	strb	w9, [x19, #0x8]
10235fb24:     	stur	q1, [x19, #0x19]
10235fb28:     	ldur	q0, [sp, #0x58]
10235fb2c:     	stur	q0, [x19, #0x29]
10235fb30:     	ldur	x9, [sp, #0x67]
10235fb34:     	str	x9, [x19, #0x38]
10235fb38:     	str	x8, [x19]
10235fb3c:     	ldp	x29, x30, [sp, #0x1a0]
10235fb40:     	ldp	x20, x19, [sp, #0x190]
10235fb44:     	ldp	x22, x21, [sp, #0x180]
10235fb48:     	add	sp, sp, #0x1b0
10235fb4c:     	ret
