"""Execute the workflow's real strict owner inventory and its two Rust filters."""
from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'core-ci';p.mkdir()
workflow=(w/'.github/workflows/ci-full.yml').read_text();guard=next(line.strip() for line in workflow.splitlines() if 'BUFFER_OWNERSHIP_TESTS' in line and '-eq' in line);assert guard.endswith('-eq 14')
binary=r/'core-focused/core-unit-tests'
old=subprocess.check_output(['git','show','8e549d40300d1bfcc8f9a2845987f6979a573c34:.github/workflows/ci-full.yml'],cwd=w,text=True);prior=next(line.strip() for line in old.splitlines() if 'BUFFER_OWNERSHIP_TESTS' in line and '-eq' in line);assert prior.endswith('-eq 11')
for label,selected,expected_exit in [('old-inventory',prior,1),('current-inventory',guard,0)]:
 script='BUFFER_OWNERSHIP_TESTS=$("$1" snapshot::validation::owned_unsigned_matrix::tests:: --list)\n'+selected+'\n'
 cmd=['bash','-c',script,'owner-inventory',str(binary)];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);row={'command':cmd,'exit':q.returncode,'expected_exit':expected_exit,'seconds':time.monotonic()-at,'scope':'Actual Bash/awk guard from workflow against the maintained current Core executable; old count intentionally rejects the three added tests. This is not an all-features Cargo build.'}
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');assert q.returncode==expected_exit,row
for label,args,count in [('inventory',['snapshot::validation::owned_unsigned_matrix::tests::','--list'],14),('selected',['snapshot::validation::owned_unsigned_matrix::tests::','snapshot::validation::owned_string::tests::','--nocapture','--test-threads=1'],21)]:
 cmd=[str(binary),*args];q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 if label=='inventory':observed=len(re.findall(r': test$',q.stdout,re.M))
 else:m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);observed=int(m[1]) if m else None
 row={'command':cmd,'exit':q.returncode,'expected_tests':count,'listed_tests' if label=='inventory' else 'executed_tests':observed,'scope':'Actual current maintained Core test executable; exact source/configuration and build command in core-focused/build.json.'};(p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');assert q.returncode==0 and observed==count,row
subprocess.run(['python3',str(r/'archive.py'),'core-ci',str(p),str(r/'core-ci.py')],cwd=w,check=True)
print('CORE_CI_14_LISTED_21_EXECUTED',flush=True)
