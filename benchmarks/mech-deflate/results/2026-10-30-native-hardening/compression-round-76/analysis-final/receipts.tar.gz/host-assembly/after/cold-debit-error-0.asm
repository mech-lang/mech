
/private/tmp/mech-cold-budget-errors-round76-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001039f7bc4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget21forward_debit_failure>:
1039f7bc4:     	ldp	q0, q1, [x1]
1039f7bc8:     	stp	q0, q1, [x0]
1039f7bcc:     	ldr	x8, [x1, #0x20]
1039f7bd0:     	str	x8, [x0, #0x20]
1039f7bd4:     	ret
