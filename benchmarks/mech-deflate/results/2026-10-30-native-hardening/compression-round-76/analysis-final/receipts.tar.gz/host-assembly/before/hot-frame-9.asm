
/private/tmp/mech-cold-budget-errors-round76-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015b16f8 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>:
1015b16f8:     	stp	x20, x19, [sp, #-0x20]!
1015b16fc:     	stp	x29, x30, [sp, #0x10]
1015b1700:     	add	x29, sp, #0x10
1015b1704:     	mov	x19, x4
1015b1708:     	cmp	x3, x2
1015b170c:     	b.hs	0x1015b175c <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_+0x64>
1015b1710:     	mov	w8, #0x170              ; =368
1015b1714:     	madd	x8, x3, x8, x1
1015b1718:     	add	x9, x8, #0x148
1015b171c:     	ldr	q0, [x9]
1015b1720:     	stur	q0, [x0, #0x4]
1015b1724:     	ldp	q0, q1, [x19]
1015b1728:     	stur	q0, [x0, #0x18]
1015b172c:     	ldr	w8, [x8, #0x158]
1015b1730:     	str	w8, [x0, #0x14]
1015b1734:     	stur	q1, [x0, #0x28]
1015b1738:     	ldr	q0, [x19, #0x20]
1015b173c:     	stur	q0, [x0, #0x38]
1015b1740:     	ldr	x8, [x19, #0x30]
1015b1744:     	str	x8, [x0, #0x48]
1015b1748:     	mov	w8, #0x3                ; =3
1015b174c:     	str	w8, [x0]
1015b1750:     	ldp	x29, x30, [sp, #0x10]
1015b1754:     	ldp	x20, x19, [sp], #0x20
1015b1758:     	ret
1015b175c:     	adrp	x8, 0x107f0e000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.84+0xe0>
1015b1760:     	add	x8, x8, #0xee0
1015b1764:     	mov	x0, x3
1015b1768:     	mov	x1, x2
1015b176c:     	mov	x2, x8
1015b1770:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b1774:     	brk	#0x1
1015b1778:     	mov	x20, x0
1015b177c:     	mov	x0, x19
1015b1780:     	bl	0x1015ae7d0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015b1784:     	mov	x0, x20
1015b1788:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
