
/private/tmp/mech-cold-budget-errors-round76-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015b0f1c <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>:
1015b0f1c:     	ldp	x9, x8, [x0]
1015b0f20:     	cmp	x9, x8
1015b0f24:     	b.eq	0x1015b0f9c <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x80>
1015b0f28:     	ldp	x12, x11, [x1]
1015b0f2c:     	mov	w13, #0x18              ; =24
1015b0f30:     	ldr	x14, [x1, #0x28]
1015b0f34:     	b	0x1015b0f40 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x24>
1015b0f38:     	cmp	x9, x8
1015b0f3c:     	b.eq	0x1015b0f88 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x6c>
1015b0f40:     	mov	x10, x9
1015b0f44:     	ldr	w15, [x9], #0x4
1015b0f48:     	cmp	x11, x15
1015b0f4c:     	b.ls	0x1015b0f38 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
1015b0f50:     	umaddl	x15, w15, w13, x12
1015b0f54:     	ldr	x16, [x15]
1015b0f58:     	cmp	x16, #0x1
1015b0f5c:     	b.ne	0x1015b0f38 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
1015b0f60:     	ldp	x16, x15, [x15, #0x8]
1015b0f64:     	add	x15, x15, x16
1015b0f68:     	cmp	x15, x16
1015b0f6c:     	ccmp	x15, x14, #0x2, hs
1015b0f70:     	b.hi	0x1015b0f38 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
1015b0f74:     	mov	w8, #0x1                ; =1
1015b0f78:     	add	x9, x10, #0x4
1015b0f7c:     	str	x9, [x0]
1015b0f80:     	mov	x0, x8
1015b0f84:     	ret
1015b0f88:     	mov	w8, #0x0                ; =0
1015b0f8c:     	add	x9, x10, #0x4
1015b0f90:     	str	x9, [x0]
1015b0f94:     	mov	x0, x8
1015b0f98:     	ret
1015b0f9c:     	mov	w0, #0x0                ; =0
1015b0fa0:     	ret
