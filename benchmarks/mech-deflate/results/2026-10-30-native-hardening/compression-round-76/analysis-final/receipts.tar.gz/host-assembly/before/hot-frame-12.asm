
/private/tmp/mech-cold-budget-errors-round76-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101612614 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>:
101612614:     	sub	sp, sp, #0x1d0
101612618:     	stp	x28, x27, [sp, #0x170]
10161261c:     	stp	x26, x25, [sp, #0x180]
101612620:     	stp	x24, x23, [sp, #0x190]
101612624:     	stp	x22, x21, [sp, #0x1a0]
101612628:     	stp	x20, x19, [sp, #0x1b0]
10161262c:     	stp	x29, x30, [sp, #0x1c0]
101612630:     	add	x29, sp, #0x1c0
101612634:     	mov	x25, x6
101612638:     	mov	x26, x4
10161263c:     	mov	x23, x3
101612640:     	mov	x22, x2
101612644:     	mov	x24, x1
101612648:     	mov	x20, x0
10161264c:     	mov	x19, x8
101612650:     	ldr	x21, [x29, #0x10]
101612654:     	stp	x5, x6, [sp]
101612658:     	str	x7, [sp, #0x10]
10161265c:     	add	x27, sp, #0x80
101612660:     	ldr	w0, [x0, #0x110]
101612664:     	add	x8, sp, #0xc8
101612668:     	mov	x1, x21
10161266c:     	bl	0x10280a534 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
101612670:     	ldrb	w8, [sp, #0xc8]
101612674:     	cmp	w8, #0x29
101612678:     	b.ne	0x1016126cc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb8>
10161267c:     	ldr	x28, [x20, #0x1d8]
101612680:     	cbz	x28, 0x1016126ec <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xd8>
101612684:     	mov	w27, #0x2c              ; =44
101612688:     	strb	w27, [sp, #0xc8]
10161268c:     	add	x0, sp, #0xc8
101612690:     	bl	0x1016181c4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101612694:     	cmp	x22, x26
101612698:     	b.ne	0x1016126c4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb0>
10161269c:     	ldr	x8, [x20, #0x78]
1016126a0:     	cmp	x22, x8
1016126a4:     	b.ne	0x1016126c4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb0>
1016126a8:     	cmp	x25, #0x0
1016126ac:     	cset	w8, ne
1016126b0:     	ldr	x9, [x20, #0x10]
1016126b4:     	cmp	x9, #0xb
1016126b8:     	cset	w9, eq
1016126bc:     	eor	w8, w8, w9
1016126c0:     	tbz	w8, #0x0, 0x101612714 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x100>
1016126c4:     	strb	w27, [x19]
1016126c8:     	b	0x1016126f4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
1016126cc:     	ldur	q0, [x27, #0x48]
1016126d0:     	ldur	q1, [x27, #0x58]
1016126d4:     	stp	q0, q1, [x19]
1016126d8:     	ldur	q0, [x27, #0x68]
1016126dc:     	str	q0, [x19, #0x20]
1016126e0:     	ldr	x8, [sp, #0xf8]
1016126e4:     	str	x8, [x19, #0x30]
1016126e8:     	b	0x1016126f4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
1016126ec:     	mov	w8, #0x2c               ; =44
1016126f0:     	strb	w8, [x19]
1016126f4:     	ldp	x29, x30, [sp, #0x1c0]
1016126f8:     	ldp	x20, x19, [sp, #0x1b0]
1016126fc:     	ldp	x22, x21, [sp, #0x1a0]
101612700:     	ldp	x24, x23, [sp, #0x190]
101612704:     	ldp	x26, x25, [sp, #0x180]
101612708:     	ldp	x28, x27, [sp, #0x170]
10161270c:     	add	sp, sp, #0x1d0
101612710:     	ret
101612714:     	ldp	x8, x9, [x28, #0x10]
101612718:     	stp	x8, x9, [sp, #0x18]
10161271c:     	stp	x24, x22, [sp, #0x28]
101612720:     	stp	x23, x22, [sp, #0x38]
101612724:     	mov	x10, sp
101612728:     	str	x10, [sp, #0x48]
10161272c:     	ldr	x10, [x21, #0x60]
101612730:     	cmp	x10, #0x1
101612734:     	b.ne	0x101612844 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x230>
101612738:     	ldr	w10, [x21, #0x50]
10161273c:     	add	x22, sp, #0x80
101612740:     	tbz	w10, #0x0, 0x101612850 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x23c>
101612744:     	ldp	x11, x10, [x29, #0x18]
101612748:     	ldr	x12, [x21, #0x68]
10161274c:     	ldr	x13, [x21, #0x58]
101612750:     	ldp	x14, x15, [x28, #0x20]
101612754:     	add	x16, x28, #0x50
101612758:     	add	x17, x28, #0x30
10161275c:     	add	x0, x28, #0x38
101612760:     	add	x1, x28, #0x40
101612764:     	add	x2, x28, #0x48
101612768:     	stp	x12, x13, [sp, #0xb8]
10161276c:     	add	x12, sp, #0xb8
101612770:     	stp	x11, x12, [sp, #0xc8]
101612774:     	add	x12, sp, #0xc0
101612778:     	stp	x12, x11, [sp, #0xd8]
10161277c:     	stp	x21, x10, [sp, #0xe8]
101612780:     	stp	x8, x9, [sp, #0xf8]
101612784:     	stp	x14, x15, [sp, #0x108]
101612788:     	stp	x16, x28, [sp, #0x118]
10161278c:     	stp	x17, x0, [sp, #0x128]
101612790:     	stp	x1, x2, [sp, #0x138]
101612794:     	add	x8, sp, #0x8
101612798:     	stp	x8, x20, [sp, #0x148]
10161279c:     	add	x8, sp, #0x18
1016127a0:     	str	x8, [sp, #0x158]
1016127a4:     	adrp	x0, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1016127a8:     	add	x0, x0, #0x860
1016127ac:     	add	x8, sp, #0x80
1016127b0:     	add	x1, sp, #0xc8
1016127b4:     	bl	0x101567654 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
1016127b8:     	ldrb	w8, [sp, #0x80]
1016127bc:     	cmp	w8, #0x2f
1016127c0:     	b.ne	0x10161280c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1f8>
1016127c4:     	ldur	q0, [x22, #0x8]
1016127c8:     	stur	q0, [sp, #0x57]
1016127cc:     	ldur	q1, [x22, #0x18]
1016127d0:     	stur	q1, [sp, #0x67]
1016127d4:     	ldr	x8, [sp, #0xa8]
1016127d8:     	stur	x8, [sp, #0x77]
1016127dc:     	stur	q0, [x22, #0x4f]
1016127e0:     	stur	q1, [x22, #0x5f]
1016127e4:     	stur	x8, [x22, #0x6f]
1016127e8:     	mov	w8, #0x29               ; =41
1016127ec:     	strb	w8, [x19]
1016127f0:     	ldur	q0, [x22, #0x48]
1016127f4:     	stur	q0, [x19, #0x1]
1016127f8:     	ldur	q0, [x22, #0x58]
1016127fc:     	stur	q0, [x19, #0x11]
101612800:     	ldur	q0, [x22, #0x67]
101612804:     	str	q0, [x19, #0x20]
101612808:     	b	0x1016126f4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10161280c:     	ldr	q0, [sp, #0xa0]
101612810:     	stur	q0, [sp, #0x6f]
101612814:     	ldur	q0, [x22, #0x11]
101612818:     	ldur	q1, [x22, #0x1]
10161281c:     	stp	q1, q0, [sp, #0x50]
101612820:     	ldr	x9, [sp, #0xb0]
101612824:     	strb	w8, [x19]
101612828:     	stur	q1, [x19, #0x1]
10161282c:     	ldr	q0, [sp, #0x60]
101612830:     	stur	q0, [x19, #0x11]
101612834:     	ldur	q0, [sp, #0x6f]
101612838:     	str	q0, [x19, #0x20]
10161283c:     	str	x9, [x19, #0x30]
101612840:     	b	0x1016126f4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
101612844:     	adrp	x0, 0x107f13000 <_anon.51f82601ca37a528a7940c4871978f11.291+0x58>
101612848:     	add	x0, x0, #0x6c8
10161284c:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101612850:     	adrp	x0, 0x107f13000 <_anon.51f82601ca37a528a7940c4871978f11.291+0x58>
101612854:     	add	x0, x0, #0x6e0
101612858:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
