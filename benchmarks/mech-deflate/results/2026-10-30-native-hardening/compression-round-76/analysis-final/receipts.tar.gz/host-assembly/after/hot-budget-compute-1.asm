
/private/tmp/mech-cold-budget-errors-round76-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010236996c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
10236996c:     	sub	sp, sp, #0x1e0
102369970:     	stp	x28, x27, [sp, #0x180]
102369974:     	stp	x26, x25, [sp, #0x190]
102369978:     	stp	x24, x23, [sp, #0x1a0]
10236997c:     	stp	x22, x21, [sp, #0x1b0]
102369980:     	stp	x20, x19, [sp, #0x1c0]
102369984:     	stp	x29, x30, [sp, #0x1d0]
102369988:     	add	x29, sp, #0x1d0
10236998c:     	ldr	x9, [x0, #0xd0]
102369990:     	adds	x19, x9, x1
102369994:     	b.hs	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369998:     	ldr	x1, [x0, #0xc8]
10236999c:     	ldr	x27, [x0, #0xf8]
1023699a0:     	ldr	x25, [x0, #0x108]
1023699a4:     	ldp	x21, x23, [x0, #0x118]
1023699a8:     	ldr	x9, [x0]
1023699ac:     	cmp	x9, #0x1
1023699b0:     	b.ne	0x102369a20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
1023699b4:     	cmp	x23, #0x10, lsl #12     ; =0x10000
1023699b8:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023699bc:     	ldr	x9, [x0, #0xe8]
1023699c0:     	mov	w10, #0x1000000         ; =16777216
1023699c4:     	cmp	x9, x10
1023699c8:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023699cc:     	mov	w9, #0x1000000          ; =16777216
1023699d0:     	cmp	x19, x9
1023699d4:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023699d8:     	mov	w9, #0x1000000          ; =16777216
1023699dc:     	cmp	x27, x9
1023699e0:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023699e4:     	mov	w9, #0x1000000          ; =16777216
1023699e8:     	cmp	x25, x9
1023699ec:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023699f0:     	cmp	x21, #0x10, lsl #12     ; =0x10000
1023699f4:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023699f8:     	cmp	x1, #0x10, lsl #12      ; =0x10000
1023699fc:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369a00:     	ldr	x9, [x0, #0x8]
102369a04:     	cmp	x19, x9
102369a08:     	b.hi	0x102369a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102369a0c:     	ldr	x9, [x0, #0x10]
102369a10:     	cmp	x1, x9
102369a14:     	b.ls	0x102369b40 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d4>
102369a18:     	mov	w9, #0x2                ; =2
102369a1c:     	b	0x102369b48 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1dc>
102369a20:     	ldr	x26, [x0, #0x110]
102369a24:     	ldr	x24, [x0, #0x128]
102369a28:     	ldr	x28, [x0, #0x18]
102369a2c:     	cmp	x28, #0x2
102369a30:     	b.ne	0x102369aa8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x13c>
102369a34:     	mov	x22, x8
102369a38:     	ldur	q0, [x0, #0xd8]
102369a3c:     	ldur	q1, [x0, #0xe8]
102369a40:     	mov	x20, x0
102369a44:     	ldur	q2, [x0, #0xf8]
102369a48:     	stp	x1, x19, [sp, #0xe0]
102369a4c:     	stp	q0, q1, [sp, #0xf0]
102369a50:     	str	q2, [sp, #0x110]
102369a54:     	stp	x25, x26, [sp, #0x120]
102369a58:     	stp	x21, x23, [sp, #0x130]
102369a5c:     	str	x24, [sp, #0x140]
102369a60:     	sub	x0, x29, #0x88
102369a64:     	mov	x2, x19
102369a68:     	bl	0x1023782c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102369a6c:     	ldurb	w8, [x29, #-0x88]
102369a70:     	cmp	w8, #0x8
102369a74:     	b.ne	0x102369b18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ac>
102369a78:     	add	x0, sp, #0xb0
102369a7c:     	add	x1, sp, #0xe0
102369a80:     	bl	0x102365fec <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
102369a84:     	mov	x8, x22
102369a88:     	ldrb	w9, [sp, #0xb0]
102369a8c:     	cmp	w9, #0x8
102369a90:     	b.eq	0x102369b3c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d0>
102369a94:     	ldp	q0, q1, [sp, #0xb0]
102369a98:     	stp	q0, q1, [x8]
102369a9c:     	ldr	x9, [sp, #0xd0]
102369aa0:     	str	x9, [x8, #0x20]
102369aa4:     	b	0x102369b4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
102369aa8:     	ldr	x14, [x0, #0xe0]
102369aac:     	ldr	x10, [x0, #0x20]
102369ab0:     	ldp	x11, x9, [x0, #0x38]
102369ab4:     	stp	x9, x10, [sp, #0xa0]
102369ab8:     	ldp	x9, x10, [x0, #0x48]
102369abc:     	stp	x9, x11, [sp, #0x90]
102369ac0:     	ldp	x9, x11, [x0, #0x58]
102369ac4:     	str	x9, [sp, #0x88]
102369ac8:     	ldp	x9, x6, [x0, #0x68]
102369acc:     	stp	x0, x9, [sp, #0x78]
102369ad0:     	ldp	x12, x4, [x0, #0x78]
102369ad4:     	ldp	x7, x2, [x0, #0x88]
102369ad8:     	ldp	x5, x15, [x0, #0x98]
102369adc:     	ldp	w3, w13, [x0, #0xb8]
102369ae0:     	ldr	x22, [x0, #0xc0]
102369ae4:     	adrp	x0, 0x108073000 <__mi_heap_main+0xb28>
102369ae8:     	add	x0, x0, #0x550
102369aec:     	ldr	x9, [x0]
102369af0:     	blr	x9
102369af4:     	mov	x20, x0
102369af8:     	ldrb	w9, [x0, #0x48]
102369afc:     	cmp	w9, #0x1
102369b00:     	b.eq	0x102369bc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x25c>
102369b04:     	cmp	w9, #0x2
102369b08:     	b.ne	0x102369b6c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x200>
102369b0c:     	adrp	x0, 0x108035000 <_anon.686517066f445f70c1782692b9896900.7+0x55f00>
102369b10:     	add	x0, x0, #0xc40
102369b14:     	bl	0x103a05624 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102369b18:     	sub	x8, x29, #0x88
102369b1c:     	ldp	q0, q1, [x8]
102369b20:     	stp	q0, q1, [sp, #0xb0]
102369b24:     	ldur	x8, [x29, #-0x68]
102369b28:     	str	x8, [sp, #0xd0]
102369b2c:     	mov	x8, x22
102369b30:     	ldrb	w9, [sp, #0xb0]
102369b34:     	cmp	w9, #0x8
102369b38:     	b.ne	0x102369a94 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x128>
102369b3c:     	mov	x0, x20
102369b40:     	str	x19, [x0, #0xd0]
102369b44:     	mov	w9, #0x8                ; =8
102369b48:     	strb	w9, [x8]
102369b4c:     	ldp	x29, x30, [sp, #0x1d0]
102369b50:     	ldp	x20, x19, [sp, #0x1c0]
102369b54:     	ldp	x22, x21, [sp, #0x1b0]
102369b58:     	ldp	x24, x23, [sp, #0x1a0]
102369b5c:     	ldp	x26, x25, [sp, #0x190]
102369b60:     	ldp	x28, x27, [sp, #0x180]
102369b64:     	add	sp, sp, #0x1e0
102369b68:     	ret
102369b6c:     	adrp	x9, 0x10277d000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x514>
102369b70:     	add	x9, x9, #0x784
102369b74:     	mov	x0, x20
102369b78:     	stp	x4, x1, [sp, #0x50]
102369b7c:     	mov	x1, x9
102369b80:     	stp	x6, x8, [sp, #0x8]
102369b84:     	stp	x13, x5, [sp, #0x20]
102369b88:     	stp	x2, x14, [sp, #0x40]
102369b8c:     	stp	x15, x7, [sp, #0x30]
102369b90:     	str	w3, [sp, #0x1c]
102369b94:     	stp	x12, x11, [sp, #0x60]
102369b98:     	str	x10, [sp, #0x70]
102369b9c:     	bl	0x102e728f4 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102369ba0:     	ldp	x11, x10, [sp, #0x68]
102369ba4:     	ldp	x1, x12, [sp, #0x58]
102369ba8:     	ldp	x7, x2, [sp, #0x38]
102369bac:     	ldp	x6, x8, [sp, #0x8]
102369bb0:     	ldp	x5, x15, [sp, #0x28]
102369bb4:     	ldp	x14, x4, [sp, #0x48]
102369bb8:     	ldr	w3, [sp, #0x1c]
102369bbc:     	ldr	x13, [sp, #0x20]
102369bc0:     	mov	w9, #0x1                ; =1
102369bc4:     	strb	w9, [x20, #0x48]
102369bc8:     	str	x10, [sp, #0x70]
102369bcc:     	ldr	x9, [x20]
102369bd0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102369bd4:     	cmp	x9, x10
102369bd8:     	b.hs	0x102369dcc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x460>
102369bdc:     	add	x10, x9, #0x1
102369be0:     	str	x10, [x20]
102369be4:     	ldr	x10, [x20, #0x8]
102369be8:     	cbz	x10, 0x102369c70 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x304>
102369bec:     	stp	x12, x11, [sp, #0x60]
102369bf0:     	ldr	x11, [x10, #0x10]
102369bf4:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
102369bf8:     	cmp	x11, x12
102369bfc:     	b.hs	0x102369dd8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x46c>
102369c00:     	ldr	x10, [x10, #0x58]
102369c04:     	str	x9, [x20]
102369c08:     	cmp	x10, x22
102369c0c:     	b.ne	0x102369c74 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x308>
102369c10:     	stp	x7, x2, [sp, #0x38]
102369c14:     	mov	x20, x6
102369c18:     	stp	x5, x15, [sp, #0x28]
102369c1c:     	stp	x14, x4, [sp, #0x48]
102369c20:     	str	w3, [sp, #0x1c]
102369c24:     	str	x13, [sp, #0x20]
102369c28:     	mov	x22, x8
102369c2c:     	add	x0, sp, #0xe0
102369c30:     	str	x1, [sp, #0x58]
102369c34:     	mov	x2, x19
102369c38:     	bl	0x1023782c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102369c3c:     	ldrb	w8, [sp, #0xe0]
102369c40:     	cmp	w8, #0x8
102369c44:     	b.ne	0x102369c7c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x310>
102369c48:     	cmp	x28, #0x1
102369c4c:     	mov	x8, x22
102369c50:     	mov	x11, x20
102369c54:     	ldr	x10, [sp, #0xa8]
102369c58:     	b.ne	0x102369c90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x324>
102369c5c:     	cmp	x23, x10
102369c60:     	b.ls	0x102369c90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x324>
102369c64:     	mov	w9, #0x0                ; =0
102369c68:     	mov	x11, x10
102369c6c:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369c70:     	str	x9, [x20]
102369c74:     	strb	wzr, [x8]
102369c78:     	b	0x102369b4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
102369c7c:     	ldp	q0, q1, [sp, #0xe0]
102369c80:     	stp	q0, q1, [x22]
102369c84:     	ldr	x8, [sp, #0x100]
102369c88:     	str	x8, [x22, #0x20]
102369c8c:     	b	0x102369b4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
102369c90:     	ldp	x9, x10, [sp, #0x98]
102369c94:     	cmp	x9, #0x1
102369c98:     	b.ne	0x102369cb4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102369c9c:     	cmp	x27, x10
102369ca0:     	b.ls	0x102369cb4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102369ca4:     	mov	w9, #0x2                ; =2
102369ca8:     	mov	x23, x27
102369cac:     	mov	x11, x10
102369cb0:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369cb4:     	ldr	x9, [sp, #0x90]
102369cb8:     	cmp	x9, #0x1
102369cbc:     	ldr	x10, [sp, #0x70]
102369cc0:     	b.ne	0x102369cdc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x370>
102369cc4:     	cmp	x25, x10
102369cc8:     	b.ls	0x102369cdc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x370>
102369ccc:     	mov	w9, #0x3                ; =3
102369cd0:     	mov	x23, x25
102369cd4:     	mov	x11, x10
102369cd8:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369cdc:     	ldr	x9, [sp, #0x88]
102369ce0:     	cmp	x9, #0x1
102369ce4:     	ldr	x10, [sp, #0x68]
102369ce8:     	b.ne	0x102369d04 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x398>
102369cec:     	cmp	x21, x10
102369cf0:     	b.ls	0x102369d04 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x398>
102369cf4:     	mov	w9, #0x4                ; =4
102369cf8:     	mov	x23, x21
102369cfc:     	mov	x11, x10
102369d00:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369d04:     	ldr	x9, [sp, #0x80]
102369d08:     	cmp	x9, #0x1
102369d0c:     	ldr	x20, [sp, #0x58]
102369d10:     	b.ne	0x102369d28 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3bc>
102369d14:     	cmp	x20, x11
102369d18:     	b.ls	0x102369d28 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3bc>
102369d1c:     	mov	w9, #0x5                ; =5
102369d20:     	mov	x23, x20
102369d24:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369d28:     	ldr	x9, [sp, #0x60]
102369d2c:     	cmp	x9, #0x1
102369d30:     	ldr	x11, [sp, #0x50]
102369d34:     	b.ne	0x102369d4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e0>
102369d38:     	cmp	x19, x11
102369d3c:     	b.ls	0x102369d4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e0>
102369d40:     	mov	w9, #0x6                ; =6
102369d44:     	mov	x23, x19
102369d48:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369d4c:     	ldp	x9, x11, [sp, #0x38]
102369d50:     	cmp	x9, #0x1
102369d54:     	ldr	x23, [sp, #0x48]
102369d58:     	b.ne	0x102369d6c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x400>
102369d5c:     	cmp	x23, x11
102369d60:     	b.ls	0x102369d6c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x400>
102369d64:     	mov	w9, #0x7                ; =7
102369d68:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369d6c:     	ldp	x9, x11, [sp, #0x28]
102369d70:     	cmp	x9, #0x1
102369d74:     	b.ne	0x102369d8c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x420>
102369d78:     	cmp	x26, x11
102369d7c:     	b.ls	0x102369d8c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x420>
102369d80:     	mov	w9, #0x8                ; =8
102369d84:     	mov	x23, x26
102369d88:     	b	0x102369db0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x444>
102369d8c:     	ldr	w9, [sp, #0x1c]
102369d90:     	cmp	w9, #0x1
102369d94:     	ldr	x0, [sp, #0x78]
102369d98:     	ldr	x11, [sp, #0x20]
102369d9c:     	b.ne	0x102369b40 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d4>
102369da0:     	cmp	w11, w24
102369da4:     	b.hs	0x102369b40 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1d4>
102369da8:     	mov	w23, w24
102369dac:     	mov	w9, #0xa                ; =10
102369db0:     	mov	w10, #0x6               ; =6
102369db4:     	strb	w10, [x8]
102369db8:     	strb	w9, [x8, #0x1]
102369dbc:     	mov	w9, #0x1                ; =1
102369dc0:     	strb	w9, [x8, #0x2]
102369dc4:     	stp	x23, x11, [x8, #0x8]
102369dc8:     	b	0x102369b4c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e0>
102369dcc:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102369dd0:     	add	x0, x0, #0x260
102369dd4:     	bl	0x103a05cd8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102369dd8:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102369ddc:     	add	x0, x0, #0x278
102369de0:     	bl	0x103a05cd8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102369de4:     	brk	#0x1
102369de8:     	ldr	x8, [x20]
102369dec:     	sub	x8, x8, #0x1
102369df0:     	str	x8, [x20]
102369df4:     	bl	0x103a071a0 <dyld_stub_binder+0x103a071a0>
