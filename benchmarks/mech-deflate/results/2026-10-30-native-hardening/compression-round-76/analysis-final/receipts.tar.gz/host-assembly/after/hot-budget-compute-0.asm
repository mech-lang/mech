
/private/tmp/mech-cold-budget-errors-round76-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023640c0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
1023640c0:     	sub	sp, sp, #0xb0
1023640c4:     	stp	x22, x21, [sp, #0x80]
1023640c8:     	stp	x20, x19, [sp, #0x90]
1023640cc:     	stp	x29, x30, [sp, #0xa0]
1023640d0:     	add	x29, sp, #0xa0
1023640d4:     	mov	x19, x8
1023640d8:     	ldr	x20, [x0]
1023640dc:     	ldr	x8, [x20, #0x10]
1023640e0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1023640e4:     	cmp	x8, x9
1023640e8:     	b.hs	0x102364154 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
1023640ec:     	add	x9, x8, #0x1
1023640f0:     	str	x9, [x20, #0x10]
1023640f4:     	ldr	x9, [x20, #0x38]
1023640f8:     	adds	x9, x9, x1
1023640fc:     	b.hs	0x102364160 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xa0>
102364100:     	str	x8, [x20, #0x10]
102364104:     	cmp	x9, x2
102364108:     	b.ls	0x102364124 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x64>
10236410c:     	mov	w8, #0x606              ; =1542
102364110:     	strh	w8, [x19]
102364114:     	mov	w8, #0x1                ; =1
102364118:     	strb	w8, [x19, #0x2]
10236411c:     	stp	x9, x2, [x19, #0x8]
102364120:     	b	0x102364298 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d8>
102364124:     	adrp	x0, 0x108073000 <__mi_heap_main+0xb28>
102364128:     	add	x0, x0, #0x550
10236412c:     	ldr	x8, [x0]
102364130:     	blr	x8
102364134:     	ldrb	w8, [x0, #0x48]
102364138:     	cmp	w8, #0x1
10236413c:     	b.eq	0x1023641a8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe8>
102364140:     	cmp	w8, #0x2
102364144:     	b.ne	0x102364180 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xc0>
102364148:     	adrp	x0, 0x108035000 <_anon.686517066f445f70c1782692b9896900.7+0x55f00>
10236414c:     	add	x0, x0, #0xc40
102364150:     	bl	0x103a05624 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102364154:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102364158:     	add	x0, x0, #0x8b8
10236415c:     	bl	0x103a05cd8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102364160:     	mov	w9, #0x606              ; =1542
102364164:     	strh	w9, [x19]
102364168:     	mov	w9, #0x1                ; =1
10236416c:     	strb	w9, [x19, #0x2]
102364170:     	mov	x9, #-0x1               ; =-1
102364174:     	stp	x9, x2, [x19, #0x8]
102364178:     	str	x8, [x20, #0x10]
10236417c:     	b	0x102364298 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d8>
102364180:     	adrp	x8, 0x10277d000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x514>
102364184:     	add	x8, x8, #0x784
102364188:     	str	x0, [sp]
10236418c:     	mov	x21, x1
102364190:     	mov	x1, x8
102364194:     	bl	0x102e728f4 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102364198:     	ldr	x0, [sp]
10236419c:     	mov	x1, x21
1023641a0:     	mov	w8, #0x1                ; =1
1023641a4:     	strb	w8, [x0, #0x48]
1023641a8:     	ldr	x8, [x0, #0x20]
1023641ac:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1023641b0:     	cmp	x8, x9
1023641b4:     	b.hs	0x102364374 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x2b4>
1023641b8:     	ldr	x8, [x0, #0x28]
1023641bc:     	cmp	x8, #0x0
1023641c0:     	ccmp	x8, x20, #0x4, ne
1023641c4:     	b.ne	0x102364268 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
1023641c8:     	ldr	x8, [x20, #0x10]
1023641cc:     	cbnz	x8, 0x102364380 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x2c0>
1023641d0:     	mov	x8, #-0x1               ; =-1
1023641d4:     	str	x8, [x20, #0x10]
1023641d8:     	ldr	w8, [x0, #0x30]
1023641dc:     	ldp	x9, x10, [x0, #0x38]
1023641e0:     	ldp	x11, x12, [x20, #0x60]
1023641e4:     	cmp	x9, x11
1023641e8:     	csel	x9, x9, x11, lo
1023641ec:     	cmp	x10, x12
1023641f0:     	csel	x10, x10, x12, lo
1023641f4:     	tst	w8, #0x1
1023641f8:     	csel	x11, x9, x11, ne
1023641fc:     	csel	x14, x10, x12, ne
102364200:     	ldr	x8, [x20, #0x38]
102364204:     	adds	x21, x8, x1
102364208:     	b.hs	0x102364364 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x2a4>
10236420c:     	ldr	x8, [x20, #0x48]
102364210:     	adds	x12, x8, x21
102364214:     	b.hs	0x102364364 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x2a4>
102364218:     	ldr	x22, [x20, #0x40]
10236421c:     	ldr	x8, [x20, #0x50]
102364220:     	adds	x15, x8, x22
102364224:     	b.hs	0x102364364 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x2a4>
102364228:     	cmp	x12, x11
10236422c:     	b.hi	0x1023642ac <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1ec>
102364230:     	cmp	x15, x14
102364234:     	b.hi	0x1023642c0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x200>
102364238:     	mov	x0, x20
10236423c:     	ldr	x8, [x0, #0x70]!
102364240:     	cbz	x8, 0x102364270 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1b0>
102364244:     	add	x8, sp, #0x50
102364248:     	mov	x2, #0x0                ; =0
10236424c:     	bl	0x10291bf4c <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102364250:     	ldrb	w9, [sp, #0x50]
102364254:     	cmp	w9, #0x8
102364258:     	b.ne	0x1023642dc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x21c>
10236425c:     	ldr	x8, [x20, #0x10]
102364260:     	add	x9, x8, #0x1
102364264:     	b	0x102364274 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1b4>
102364268:     	mov	w8, #0x0                ; =0
10236426c:     	b	0x102364280 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1c0>
102364270:     	mov	x9, #0x0                ; =0
102364274:     	stp	x21, x22, [x20, #0x38]
102364278:     	mov	w8, #0x8                ; =8
10236427c:     	str	x9, [x20, #0x10]
102364280:     	strb	w8, [x19]
102364284:     	ldp	q0, q1, [sp, #0x50]
102364288:     	stur	q0, [x19, #0x1]
10236428c:     	stur	q1, [x19, #0x11]
102364290:     	ldur	x8, [sp, #0x6f]
102364294:     	str	x8, [x19, #0x20]
102364298:     	ldp	x29, x30, [sp, #0xa0]
10236429c:     	ldp	x20, x19, [sp, #0x90]
1023642a0:     	ldp	x22, x21, [sp, #0x80]
1023642a4:     	add	sp, sp, #0xb0
1023642a8:     	ret
1023642ac:     	mov	x10, #0x0               ; =0
1023642b0:     	mov	w8, #0x1                ; =1
1023642b4:     	mov	w9, #0x6                ; =6
1023642b8:     	mov	w13, #0x6               ; =6
1023642bc:     	b	0x102364308 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x248>
1023642c0:     	mov	x10, #0x0               ; =0
1023642c4:     	mov	w8, #0x1                ; =1
1023642c8:     	mov	w13, #0x5               ; =5
1023642cc:     	mov	w9, #0x6                ; =6
1023642d0:     	mov	x12, x15
1023642d4:     	mov	x11, x14
1023642d8:     	b	0x102364308 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x248>
1023642dc:     	ldrb	w13, [sp, #0x51]
1023642e0:     	ldrb	w8, [sp, #0x52]
1023642e4:     	ldur	w10, [sp, #0x53]
1023642e8:     	str	w10, [sp, #0x48]
1023642ec:     	ldrb	w10, [sp, #0x57]
1023642f0:     	strb	w10, [sp, #0x4c]
1023642f4:     	ldp	x12, x11, [sp, #0x58]
1023642f8:     	ldur	q0, [sp, #0x68]
1023642fc:     	ldr	x10, [x20, #0x10]
102364300:     	add	x10, x10, #0x1
102364304:     	str	q0, [sp, #0x30]
102364308:     	str	x10, [x20, #0x10]
10236430c:     	strb	w9, [sp, #0x50]
102364310:     	strb	w13, [sp, #0x51]
102364314:     	strb	w8, [sp, #0x52]
102364318:     	ldr	w8, [sp, #0x48]
10236431c:     	stur	w8, [sp, #0x53]
102364320:     	ldrb	w8, [sp, #0x4c]
102364324:     	strb	w8, [sp, #0x57]
102364328:     	stp	x12, x11, [sp, #0x58]
10236432c:     	ldr	q0, [sp, #0x30]
102364330:     	stur	q0, [sp, #0x68]
102364334:     	add	x0, sp, #0x8
102364338:     	add	x1, sp, #0x50
10236433c:     	bl	0x1039f7bc4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget21forward_debit_failure>
102364340:     	ldrb	w8, [sp, #0x8]
102364344:     	ldur	q0, [sp, #0x9]
102364348:     	ldur	q1, [sp, #0x19]
10236434c:     	stp	q0, q1, [sp, #0x50]
102364350:     	ldr	x9, [sp, #0x28]
102364354:     	stur	x9, [sp, #0x6f]
102364358:     	cmp	w8, #0x9
10236435c:     	b.ne	0x102364280 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1c0>
102364360:     	b	0x102364148 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x88>
102364364:     	mov	x10, #0x0               ; =0
102364368:     	mov	w8, #0x1                ; =1
10236436c:     	mov	w9, #0x2                ; =2
102364370:     	b	0x102364308 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x248>
102364374:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102364378:     	add	x0, x0, #0x870
10236437c:     	bl	0x103a05cd8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102364380:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102364384:     	add	x0, x0, #0x888
102364388:     	bl	0x103a05ca8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10236438c:     	ldr	x8, [x20, #0x10]
102364390:     	add	x8, x8, #0x1
102364394:     	str	x8, [x20, #0x10]
102364398:     	bl	0x103a071a0 <dyld_stub_binder+0x103a071a0>
