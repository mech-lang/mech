"""Reuse a Rust unit executable only after exact input-tree and library proofs."""
from pathlib import Path
import hashlib,json,os
r=Path(__file__).resolve().parent;p=r/'engine-parent';old=Path('/private/tmp/mech-checked-compute-inline-round72-20261031/engine-parent');sha=lambda f:hashlib.file_digest(Path(f).open('rb'),'sha256').hexdigest()
base=json.loads((old/'build.json').read_text());libs=json.loads(Path('/private/tmp/mech-observed-plan-transfer-round70-20261031/final-libraries.json').read_text());assert base['exit']==0 and base['libraries']==libs
for name,pin in libs.items():assert sha(pin['path'])==pin['sha256'],name
left=old/'source/src/engine';right=p/'source/src/engine'
def tree(root):return {str(f.relative_to(root)):sha(f) for f in sorted(root.rglob('*')) if f.is_file()}
a=tree(left);b=tree(right);assert a==b,[(k,a.get(k),b.get(k)) for k in a.keys()|b.keys() if a.get(k)!=b.get(k)]
assert (old/'source/tests').resolve()==(p/'source/tests').resolve()
exe=old/'engine-tests';expected=sha(exe);(p/'engine-tests').symlink_to(exe);assert sha(p/'engine-tests')==expected
proof={'actual_reused_binary':str(exe),'binary_sha256':expected,'identical_engine_input_files':len(a),'input_tree_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest(),'source_files':a,'library_inputs':libs,'scope':'Actual retained R72 parent Rust executable; complete staged Engine input tree and exact dependencies match byte-for-byte. No fresh parent Rust compilation is claimed. All selections are executed in new processes during R76.'}
(p/'reuse-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(p/'retained-rust-build.json').write_text(json.dumps(base,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k not in ['source_files','library_inputs']}))
