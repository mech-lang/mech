"""Actual warnings-as-errors metadata consumer without native-artifact cfg."""
from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'non-native';p.mkdir();base=json.loads((r/'variants/after/mech_engine.json').read_text());cmd=base['command'].copy();removed=[]
for i in range(len(cmd)-1,0,-1):
 if cmd[i]=='feature="native-artifact"' and cmd[i-1]=='--cfg':removed=cmd[i-1:i+1]+removed;del cmd[i-1:i+1]
assert removed==['--cfg','feature="native-artifact"'];idx=next(i for i,a in enumerate(cmd) if a.startswith('--emit='));cmd[idx]='--emit=metadata';cmd[cmd.index('--out-dir')+1]=str(p)
at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('build.'+stream)).write_text(getattr(q,stream))
row={'command':cmd,'environment':base['environment'],'exit':q.returncode,'seconds':time.monotonic()-at,'removed_cfg':removed,'compiler_source':base['source_head'],'scope':'Exact retained Engine operation cfgs and dependencies, with native-artifact omitted. Actual Rust metadata consumer with warnings-as-errors retained; not a full Cargo feature-matrix or linker claim.'};(p/'build.json').write_text(json.dumps(row,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'non-native',str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(r/'non-native.py')],check=True)
if q.returncode:print(q.stderr[-10000:],flush=True)
q.check_returncode();print('NON_NATIVE_WAE_PASSED',flush=True)
