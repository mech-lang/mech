	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxeEECs5JOyHbDOhEp_7witness:
	.cfi_startproc
	ldr	x1, [x0, #8]
	cbz	x1, LBB0_2
	ldr	x0, [x0]
	mov	w2, #1
	b	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB0_2:
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCsgDHHaSskbIF_4core9panicking13assert_failedINtNtB4_6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEBM_ECs5JOyHbDOhEp_7witness:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	x0, x1, [sp]
Lloh0:
	adrp	x2, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.0@PAGE
Lloh1:
	add	x2, x2, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.0@PAGEOFF
Lloh2:
	adrp	x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.6@PAGE
Lloh3:
	add	x7, x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.6@PAGEOFF
	mov	x1, sp
	add	x3, sp, #8
	mov	w0, #0
	mov	x4, x2
	mov	x5, #0
	bl	__RNvNtCsgDHHaSskbIF_4core9panicking19assert_failed_inner
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.private_extern	__RINvNtCsgirOGyZpP7g_3std2rt10lang_startuECs5JOyHbDOhEp_7witness
	.globl	__RINvNtCsgirOGyZpP7g_3std2rt10lang_startuECs5JOyHbDOhEp_7witness
	.p2align	2
__RINvNtCsgirOGyZpP7g_3std2rt10lang_startuECs5JOyHbDOhEp_7witness:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	str	x0, [sp, #8]
Lloh4:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.1@PAGE
Lloh5:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.1@PAGEOFF
	add	x0, sp, #8
	bl	__RNvNtCsgirOGyZpP7g_3std2rt19lang_start_internal
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc

	.p2align	2
__RINvNtNtCsgirOGyZpP7g_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5JOyHbDOhEp_7witness:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	blr	x0
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNCINvNtCsgirOGyZpP7g_3std2rt10lang_startuE0Cs5JOyHbDOhEp_7witness:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCsgirOGyZpP7g_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5JOyHbDOhEp_7witness
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNSNvYNCINvNtCsgirOGyZpP7g_3std2rt10lang_startuE0INtNtNtCsgDHHaSskbIF_4core3ops8function6FnOnceuE9call_once6vtableCs5JOyHbDOhEp_7witness:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCsgirOGyZpP7g_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5JOyHbDOhEp_7witness
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNvCs5JOyHbDOhEp_7witness15forward_failure:
	.cfi_startproc
	ldp	q0, q1, [x1]
	stp	q0, q1, [x0]
	ldr	x8, [x1, #32]
	str	x8, [x0, #32]
	ret
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI7_0:
	.quad	0
	.quad	-1
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	__RNvCs5JOyHbDOhEp_7witness4main
	.globl	__RNvCs5JOyHbDOhEp_7witness4main
	.p2align	2
__RNvCs5JOyHbDOhEp_7witness4main:
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception0
	sub	sp, sp, #320
	.cfi_def_cfa_offset 320
	stp	x28, x27, [sp, #224]
	stp	x26, x25, [sp, #240]
	stp	x24, x23, [sp, #256]
	stp	x22, x21, [sp, #272]
	stp	x20, x19, [sp, #288]
	stp	x29, x30, [sp, #304]
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	w26, #0
	mov	w8, #0
	mov	x9, #0
	add	x25, sp, #136
	str	wzr, [sp, #20]
	add	x10, sp, #24
	add	x10, x10, #16
	str	x10, [sp, #8]
Lloh6:
	adrp	x10, lCPI7_0@PAGE
Lloh7:
	ldr	q0, [x10, lCPI7_0@PAGEOFF]
	stur	q0, [sp, #40]
Lloh8:
	adrp	x19, __RNvCs5JOyHbDOhEp_7witness6worker@PAGE
Lloh9:
	add	x19, x19, __RNvCs5JOyHbDOhEp_7witness6worker@PAGEOFF
	b	LBB7_2
LBB7_1:
	mov	w8, #1
	mov	w9, #1
	ldr	w10, [sp, #16]
	tbnz	w10, #0, LBB7_77
LBB7_2:
	mov	x20, #0
	str	w8, [sp, #16]
	ldr	x8, [sp, #8]
	ldr	x27, [x8, x9, lsl #3]
	str	x27, [sp, #56]
	b	LBB7_4
LBB7_3:
	add	x20, x20, #1
	add	w26, w26, #2
	cmp	x20, #10
	b.eq	LBB7_1
LBB7_4:
	stp	xzr, x27, [sp, #64]
	stp	xzr, x27, [sp, #80]
	add	x8, sp, #96
	add	x0, sp, #64
	mov	x1, #0
	mov	x2, x20
	bl	_current_debit
Ltmp0:
	add	x8, sp, #136
	add	x0, sp, #80
	mov	x1, #0
	mov	x2, x20
	bl	_cold_debit
Ltmp1:
	ldrb	w24, [sp, #96]
	cmp	w24, #8
	cset	w8, ne
	ldrb	w22, [sp, #136]
	cmp	w22, #8
	cset	w23, eq
	cmp	w8, w23
	b.eq	LBB7_83
	cmp	w24, #8
	mov	x9, #9223372036854775807
	b.eq	LBB7_22
	cmp	w24, w22
	b.ne	LBB7_78
	cmp	w24, #6
	b.eq	LBB7_18
	cmp	w24, #5
	b.eq	LBB7_16
	cmp	w24, #4
	b.ne	LBB7_22
	ldr	w8, [sp, #100]
	ldr	w9, [sp, #140]
	cmp	w8, w9
	b.ne	LBB7_79
	ldr	x2, [sp, #112]
	ldr	x8, [x25, #16]
	cmp	x2, x8
	b.ne	LBB7_79
	ldr	x1, [sp, #144]
	ldr	x0, [sp, #104]
	bl	_memcmp
	cbnz	w0, LBB7_79
	ldr	x2, [sp, #128]
	add	x9, sp, #136
	ldr	x8, [x9, #32]
	cmp	x2, x8
	b.ne	LBB7_79
	add	x25, sp, #136
	ldr	x1, [x9, #24]
	ldr	x0, [sp, #120]
	bl	_memcmp
	mov	x9, #9223372036854775807
	cbz	w0, LBB7_22
	b	LBB7_79
LBB7_16:
	ldr	x8, [sp, #104]
	ldr	x9, [sp, #144]
	cmp	x8, x9
	b.ne	LBB7_82
	ldr	x8, [sp, #112]
	ldr	x9, [x25, #16]
	cmp	x8, x9
	mov	x9, #9223372036854775807
	b.eq	LBB7_22
	b	LBB7_82
LBB7_18:
	ldr	x8, [sp, #104]
	ldr	x9, [sp, #144]
	cmp	x8, x9
	b.ne	LBB7_81
	ldr	x8, [sp, #112]
	ldr	x9, [x25, #16]
	cmp	x8, x9
	b.ne	LBB7_81
	ldrb	w8, [sp, #98]
	ldrb	w9, [sp, #138]
	cmp	w8, w9
	b.ne	LBB7_81
	ldrb	w8, [sp, #97]
	ldrb	w9, [sp, #137]
	cmp	w8, w9
	mov	x9, #9223372036854775807
	b.ne	LBB7_81
LBB7_22:
	ldr	x21, [sp, #64]
	cmp	x21, x9
	b.hs	LBB7_74
	add	x8, x21, #1
	str	x8, [sp, #64]
	ldr	x28, [sp, #80]
	cmp	x28, x9
	b.hs	LBB7_75
	add	x8, x28, #1
	str	x8, [sp, #80]
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #88]
	cmp	x8, x9
	b.ne	LBB7_76
	str	x21, [sp, #64]
	cmp	w22, #8
	b.ne	LBB7_27
	add	w8, w26, #1
	str	w8, [sp, #20]
	b	LBB7_33
LBB7_27:
	cmp	x8, x27
	b.ne	LBB7_80
	add	w8, w26, #1
	str	w8, [sp, #20]
	cmp	w22, #4
	b.ne	LBB7_33
	ldr	x1, [x25, #16]
	cbz	x1, LBB7_31
	ldr	x0, [sp, #144]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB7_31:
	ldr	x1, [x25, #32]
	cbz	x1, LBB7_33
	ldr	x0, [x25, #24]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB7_33:
	cmp	w24, #8
	b.eq	LBB7_39
	cmp	w24, #4
	b.ne	LBB7_39
	ldr	x1, [sp, #112]
	cbz	x1, LBB7_37
	ldr	x0, [sp, #104]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB7_37:
	ldr	x1, [sp, #128]
	cbz	x1, LBB7_39
	ldr	x0, [sp, #120]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB7_39:
	stp	xzr, x27, [sp, #64]
	stp	xzr, x27, [sp, #80]
	add	x8, sp, #96
	add	x0, sp, #64
	mov	x1, x19
	mov	x2, x20
	bl	_current_debit
Ltmp2:
	add	x8, sp, #136
	add	x0, sp, #80
	mov	x1, x19
	mov	x2, x20
	bl	_cold_debit
Ltmp3:
	ldrb	w24, [sp, #96]
	cmp	w24, #8
	cset	w8, ne
	ldrb	w22, [sp, #136]
	cmp	w22, #8
	cset	w23, eq
	cmp	w8, w23
	b.eq	LBB7_83
	cmp	w24, #8
	mov	x9, #9223372036854775806
	b.eq	LBB7_57
	cmp	w24, w22
	b.ne	LBB7_78
	cmp	w24, #4
	b.eq	LBB7_52
	cmp	w24, #5
	b.eq	LBB7_50
	cmp	w24, #6
	b.ne	LBB7_57
	ldr	x8, [sp, #104]
	ldr	x9, [sp, #144]
	cmp	x8, x9
	b.ne	LBB7_81
	ldr	x8, [sp, #112]
	ldr	x9, [x25, #16]
	cmp	x8, x9
	b.ne	LBB7_81
	ldrb	w8, [sp, #98]
	ldrb	w9, [sp, #138]
	cmp	w8, w9
	b.ne	LBB7_81
	ldrb	w8, [sp, #97]
	ldrb	w9, [sp, #137]
	cmp	w8, w9
	mov	x9, #9223372036854775806
	b.eq	LBB7_57
	b	LBB7_81
LBB7_50:
	ldr	x8, [sp, #104]
	ldr	x9, [sp, #144]
	cmp	x8, x9
	b.ne	LBB7_82
	ldr	x8, [sp, #112]
	ldr	x9, [x25, #16]
	cmp	x8, x9
	mov	x9, #9223372036854775806
	b.eq	LBB7_57
	b	LBB7_82
LBB7_52:
	ldr	w8, [sp, #100]
	ldr	w9, [sp, #140]
	cmp	w8, w9
	b.ne	LBB7_79
	ldr	x2, [sp, #112]
	ldr	x8, [x25, #16]
	cmp	x2, x8
	b.ne	LBB7_79
	ldr	x1, [sp, #144]
	ldr	x0, [sp, #104]
	bl	_memcmp
	cbnz	w0, LBB7_79
	ldr	x2, [sp, #128]
	add	x9, sp, #136
	ldr	x8, [x9, #32]
	cmp	x2, x8
	b.ne	LBB7_79
	add	x25, sp, #136
	ldr	x1, [x9, #24]
	ldr	x0, [sp, #120]
	bl	_memcmp
	mov	x9, #9223372036854775806
	cbnz	w0, LBB7_79
LBB7_57:
	ldr	x21, [sp, #64]
	cmp	x21, x9
	b.hi	LBB7_74
	add	x8, x21, #1
	str	x8, [sp, #64]
	ldr	x28, [sp, #80]
	cmp	x28, x9
	b.hi	LBB7_75
	add	x8, x28, #1
	str	x8, [sp, #80]
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #88]
	cmp	x8, x9
	b.ne	LBB7_76
	str	x21, [sp, #64]
	cmp	w22, #8
	b.ne	LBB7_62
	add	w8, w26, #2
	str	w8, [sp, #20]
	b	LBB7_68
LBB7_62:
	cmp	x8, x27
	b.ne	LBB7_80
	add	w8, w26, #2
	str	w8, [sp, #20]
	cmp	w22, #4
	b.ne	LBB7_68
	ldr	x1, [x25, #16]
	cbz	x1, LBB7_66
	ldr	x0, [sp, #144]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB7_66:
	ldr	x1, [x25, #32]
	cbz	x1, LBB7_68
	ldr	x0, [x25, #24]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB7_68:
	cmp	w24, #8
	b.eq	LBB7_3
	cmp	w24, #4
	b.ne	LBB7_3
	ldr	x1, [sp, #112]
	cbz	x1, LBB7_72
	ldr	x0, [sp, #104]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
LBB7_72:
	ldr	x1, [sp, #128]
	cbz	x1, LBB7_3
	ldr	x0, [sp, #120]
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	b	LBB7_3
LBB7_74:
Ltmp7:
Lloh10:
	adrp	x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.7@PAGE
Lloh11:
	add	x0, x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.7@PAGEOFF
	add	x20, sp, #136
	bl	__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed
Ltmp8:
	b	LBB7_84
LBB7_75:
	add	x20, sp, #136
Ltmp10:
Lloh12:
	adrp	x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.8@PAGE
Lloh13:
	add	x0, x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.8@PAGEOFF
	bl	__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed
Ltmp11:
	b	LBB7_84
LBB7_76:
	add	x8, sp, #64
Ltmp13:
Lloh14:
	adrp	x5, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.9@PAGE
Lloh15:
	add	x5, x5, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.9@PAGEOFF
	add	x1, x8, #8
	add	x8, sp, #80
	add	x2, x8, #8
	mov	w0, #0
	mov	x3, #0
	add	x20, sp, #136
	bl	__RINvNtCsgDHHaSskbIF_4core9panicking13assert_failedyyEB4_
Ltmp14:
	b	LBB7_84
LBB7_77:
	add	x8, sp, #20
Lloh16:
	adrp	x9, __RNvXs9_NtNtNtCsgDHHaSskbIF_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGE
Lloh17:
	ldr	x9, [x9, __RNvXs9_NtNtNtCsgDHHaSskbIF_4core3fmt3num3implNtB9_7Display3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp, #136]
Lloh18:
	adrp	x8, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.2@PAGE
Lloh19:
	add	x8, x8, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.2@PAGEOFF
Lloh20:
	adrp	x9, __RNvXsi_NtNtNtCsgDHHaSskbIF_4core3fmt3num3impjNtB9_7Display3fmt@GOTPAGE
Lloh21:
	ldr	x9, [x9, __RNvXsi_NtNtNtCsgDHHaSskbIF_4core3fmt3num3impjNtB9_7Display3fmt@GOTPAGEOFF]
	add	x10, sp, #136
	stp	x8, x9, [x10, #16]
	stp	x8, x9, [x10, #32]
Lloh22:
	adrp	x8, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.3@PAGE
Lloh23:
	add	x8, x8, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.3@PAGEOFF
	stp	x8, x9, [x10, #48]
	stp	x8, x9, [x10, #64]
Lloh24:
	adrp	x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.4@PAGE
Lloh25:
	add	x0, x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.4@PAGEOFF
	add	x1, sp, #136
	bl	__RNvNtNtCsgirOGyZpP7g_3std2io5stdio6__print
	.cfi_def_cfa wsp, 320
	ldp	x29, x30, [sp, #304]
	ldp	x20, x19, [sp, #288]
	ldp	x22, x21, [sp, #272]
	ldp	x24, x23, [sp, #256]
	ldp	x26, x25, [sp, #240]
	ldp	x28, x27, [sp, #224]
	add	sp, sp, #320
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB7_78:
	.cfi_restore_state
	mov	w23, #0
	b	LBB7_83
LBB7_79:
	mov	w23, #0
	mov	w22, #4
	b	LBB7_83
LBB7_80:
Ltmp16:
Lloh26:
	adrp	x5, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.10@PAGE
Lloh27:
	add	x5, x5, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.10@PAGEOFF
	add	x8, sp, #80
	add	x1, x8, #8
	add	x2, sp, #56
	mov	w0, #0
	mov	x3, #0
	add	x20, sp, #136
	bl	__RINvNtCsgDHHaSskbIF_4core9panicking13assert_failedyyEB4_
Ltmp17:
	b	LBB7_84
LBB7_81:
	mov	w23, #0
	mov	w22, #6
	b	LBB7_83
LBB7_82:
	mov	w23, #0
	mov	w22, #5
LBB7_83:
Ltmp5:
	add	x0, sp, #96
	add	x1, sp, #136
	add	x20, sp, #136
	bl	__RINvNtCsgDHHaSskbIF_4core9panicking13assert_failedINtNtB4_6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEBM_ECs5JOyHbDOhEp_7witness
Ltmp6:
LBB7_84:
	brk	#0x1
LBB7_85:
Ltmp4:
	b	LBB7_95
LBB7_86:
Ltmp18:
	str	x28, [sp, #80]
	b	LBB7_90
LBB7_87:
Ltmp15:
	str	x28, [sp, #80]
	str	x21, [sp, #64]
	tbz	w23, #0, LBB7_90
	b	LBB7_95
LBB7_88:
Ltmp12:
	str	x21, [sp, #64]
	tbz	w23, #0, LBB7_90
	b	LBB7_95
LBB7_89:
Ltmp9:
	tbnz	w23, #0, LBB7_95
LBB7_90:
	cmp	w22, #4
	b.ne	LBB7_95
	ldr	x1, [x20, #16]
	cbz	x1, LBB7_93
	ldr	x8, [sp, #144]
	mov	x19, x0
	mov	x0, x8
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	mov	x0, x19
LBB7_93:
	ldr	x1, [x20, #32]
	cbz	x1, LBB7_95
	ldr	x8, [x20, #24]
	mov	x19, x0
	mov	x0, x8
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	mov	x0, x19
LBB7_95:
	ldrb	w8, [sp, #96]
	cmp	w8, #8
	ccmp	w8, #4, #0, ne
	b.eq	LBB7_97
LBB7_96:
	bl	__Unwind_Resume
LBB7_97:
	ldr	x1, [sp, #112]
	cbz	x1, LBB7_99
	ldr	x8, [sp, #104]
	mov	x19, x0
	mov	x0, x8
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	mov	x0, x19
LBB7_99:
	ldr	x1, [sp, #128]
	cbz	x1, LBB7_96
	ldr	x8, [sp, #120]
	mov	x19, x0
	mov	x0, x8
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	mov	x0, x19
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpLdrGot	Lloh20, Lloh21
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpLdrGot	Lloh16, Lloh17
	.loh AdrpAdd	Lloh26, Lloh27
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table7:
Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Lfunc_begin0-Lfunc_begin0
	.uleb128 Ltmp0-Lfunc_begin0
	.byte	0
	.byte	0
	.uleb128 Ltmp0-Lfunc_begin0
	.uleb128 Ltmp1-Ltmp0
	.uleb128 Ltmp4-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp1-Lfunc_begin0
	.uleb128 Ltmp2-Ltmp1
	.byte	0
	.byte	0
	.uleb128 Ltmp2-Lfunc_begin0
	.uleb128 Ltmp3-Ltmp2
	.uleb128 Ltmp4-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp7-Lfunc_begin0
	.uleb128 Ltmp8-Ltmp7
	.uleb128 Ltmp9-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp10-Lfunc_begin0
	.uleb128 Ltmp11-Ltmp10
	.uleb128 Ltmp12-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp13-Lfunc_begin0
	.uleb128 Ltmp14-Ltmp13
	.uleb128 Ltmp15-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp14-Lfunc_begin0
	.uleb128 Ltmp16-Ltmp14
	.byte	0
	.byte	0
	.uleb128 Ltmp16-Lfunc_begin0
	.uleb128 Ltmp17-Ltmp16
	.uleb128 Ltmp18-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp5-Lfunc_begin0
	.uleb128 Ltmp6-Ltmp5
	.uleb128 Ltmp9-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp6-Lfunc_begin0
	.uleb128 Lfunc_end0-Ltmp6
	.byte	0
	.byte	0
Lcst_end0:
	.p2align	2, 0x0

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI8_0:
	.quad	7
	.quad	6
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvCs5JOyHbDOhEp_7witness6worker:
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception1
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	cmp	x0, #3
	b.le	LBB8_6
	cmp	x0, #5
	b.le	LBB8_13
	cmp	x0, #6
	b.eq	LBB8_21
	cmp	x0, #7
	b.eq	LBB8_24
	cmp	x0, #8
	b.ne	LBB8_25
	mov	w9, #1
	b	LBB8_26
LBB8_6:
	cmp	x0, #1
	b.gt	LBB8_10
	cbz	x0, LBB8_18
	cmp	x0, #1
	b.ne	LBB8_25
	strb	wzr, [x8]
	b	LBB8_27
LBB8_10:
	cmp	x0, #2
	b.eq	LBB8_19
	cmp	x0, #3
	b.ne	LBB8_25
	mov	w9, #5
	b	LBB8_20
LBB8_13:
	cmp	x0, #4
	b.eq	LBB8_23
	cmp	x0, #5
	b.ne	LBB8_25
	mov	x20, x8
	bl	__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #6
	mov	w1, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc
	cbz	x0, LBB8_28
	mov	x19, x0
	mov	w8, #25973
	strh	w8, [x0, #4]
	mov	w8, #28783
	movk	w8, #29025, lsl #16
	str	w8, [x0]
	bl	__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #8
	mov	w1, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc
	cbz	x0, LBB8_29
	mov	x8, #25970
	movk	x8, #25962, lsl #16
	movk	x8, #29795, lsl #32
	movk	x8, #25701, lsl #48
	str	x8, [x0]
	mov	w8, #4
	strb	w8, [x20]
	mov	w8, #7
	str	w8, [x20, #4]
	mov	w8, #6
	stp	x19, x8, [x20, #8]
	mov	w8, #8
	stp	x0, x8, [x20, #24]
	b	LBB8_27
LBB8_18:
	mov	w9, #8
	b	LBB8_26
LBB8_19:
	mov	w9, #6
LBB8_20:
	mov	w10, #6
	strb	w10, [x8]
	strb	w9, [x8, #1]
	mov	w9, #1
	strb	w9, [x8, #2]
	b	LBB8_22
LBB8_21:
	mov	w9, #5
	strb	w9, [x8]
LBB8_22:
Lloh28:
	adrp	x9, lCPI8_0@PAGE
Lloh29:
	ldr	q0, [x9, lCPI8_0@PAGEOFF]
	stur	q0, [x8, #8]
	b	LBB8_27
LBB8_23:
	mov	w9, #3
	b	LBB8_26
LBB8_24:
	mov	w9, #2
	b	LBB8_26
LBB8_25:
	mov	w9, #7
LBB8_26:
	strb	w9, [x8]
LBB8_27:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB8_28:
	.cfi_restore_state
	mov	w0, #1
	mov	w1, #6
	bl	__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error
LBB8_29:
Ltmp19:
	mov	w0, #1
	mov	w1, #8
	bl	__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error
Ltmp20:
	brk	#0x1
LBB8_31:
Ltmp21:
	mov	x20, x0
	mov	x0, x19
	mov	w1, #6
	mov	w2, #1
	bl	__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc
	mov	x0, x20
	bl	__Unwind_Resume
	.loh AdrpLdr	Lloh28, Lloh29
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table8:
Lexception1:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1
	.uleb128 Ltmp19-Lfunc_begin1
	.byte	0
	.byte	0
	.uleb128 Ltmp19-Lfunc_begin1
	.uleb128 Ltmp20-Ltmp19
	.uleb128 Ltmp21-Lfunc_begin1
	.byte	0
	.uleb128 Ltmp20-Lfunc_begin1
	.uleb128 Lfunc_end1-Ltmp20
	.byte	0
	.byte	0
Lcst_end1:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRINtNtB8_6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorENtB6_5Debug3fmtCs5JOyHbDOhEp_7witness:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	cmp	w10, #8
	b.ne	LBB9_2
	str	x9, [sp, #8]
Lloh30:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.52@PAGE
Lloh31:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.52@PAGEOFF
Lloh32:
	adrp	x4, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.51@PAGE
Lloh33:
	add	x4, x4, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.51@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #2
	b	LBB9_3
LBB9_2:
	str	x9, [sp, #8]
Lloh34:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.54@PAGE
Lloh35:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.54@PAGEOFF
Lloh36:
	adrp	x4, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.53@PAGE
Lloh37:
	add	x4, x4, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.53@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #3
LBB9_3:
	bl	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh34, Lloh35
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #96]
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	mov	x8, x1
	ldr	x9, [x0]
	ldrb	w10, [x9]
	cmp	w10, #3
	b.gt	LBB10_4
	cmp	w10, #1
	b.gt	LBB10_7
	cbnz	w10, LBB10_12
Lloh38:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.16@PAGE
Lloh39:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.16@PAGEOFF
	b	LBB10_9
LBB10_4:
	cmp	w10, #5
	b.gt	LBB10_10
	cmp	w10, #4
	b.ne	LBB10_13
	add	x10, x9, #24
	add	x11, x9, #4
	stur	x11, [x29, #-8]
Lloh40:
	adrp	x11, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.21@PAGE
Lloh41:
	add	x11, x11, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.21@PAGEOFF
	str	x11, [sp, #48]
	sub	x11, x29, #8
	mov	w12, #4
	stp	x12, x11, [sp, #32]
Lloh42:
	adrp	x11, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.25@PAGE
Lloh43:
	add	x11, x11, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.25@PAGEOFF
Lloh44:
	adrp	x6, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.20@PAGE
Lloh45:
	add	x6, x6, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.20@PAGEOFF
	stp	x6, x11, [sp, #16]
	mov	w11, #6
Lloh46:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.22@PAGE
Lloh47:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.22@PAGEOFF
Lloh48:
	adrp	x3, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.23@PAGE
Lloh49:
	add	x3, x3, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.23@PAGEOFF
	stp	x11, x10, [sp]
	add	x5, x9, #8
Lloh50:
	adrp	x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.24@PAGE
Lloh51:
	add	x7, x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.24@PAGEOFF
	mov	x0, x8
	mov	w2, #14
	mov	w4, #9
	bl	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter26debug_struct_field3_finish
	b	LBB10_14
LBB10_7:
	cmp	w10, #2
	b.ne	LBB10_15
Lloh52:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.18@PAGE
Lloh53:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.18@PAGEOFF
LBB10_9:
	mov	x0, x8
	mov	w2, #12
	.cfi_def_cfa wsp, 112
	b	LBB10_17
LBB10_10:
	.cfi_restore_state
	.cfi_remember_state
	cmp	w10, #6
	b.ne	LBB10_16
	add	x10, x9, #1
	add	x11, x9, #8
	add	x12, x9, #16
	stur	x12, [x29, #-8]
Lloh54:
	adrp	x12, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.27@PAGE
Lloh55:
	add	x14, x12, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.27@PAGEOFF
	sub	x12, x29, #8
	mov	w13, #5
	stp	x12, x14, [sp, #72]
	str	x13, [sp, #64]
Lloh56:
	adrp	x12, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.37@PAGE
Lloh57:
	add	x12, x12, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.37@PAGEOFF
Lloh58:
	adrp	x13, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.26@PAGE
Lloh59:
	add	x13, x13, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.26@PAGEOFF
	stp	x13, x12, [sp, #48]
Lloh60:
	adrp	x12, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.36@PAGE
Lloh61:
	add	x12, x12, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.36@PAGEOFF
Lloh62:
	adrp	x13, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.32@PAGE
Lloh63:
	add	x13, x13, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.32@PAGEOFF
	mov	w14, #8
	stp	x14, x11, [sp, #32]
	mov	w11, #9
Lloh64:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.33@PAGE
Lloh65:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.33@PAGEOFF
	stp	x13, x12, [sp, #16]
Lloh66:
	adrp	x3, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.34@PAGE
Lloh67:
	add	x3, x3, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.34@PAGEOFF
Lloh68:
	adrp	x6, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.31@PAGE
Lloh69:
	add	x6, x6, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.31@PAGEOFF
	add	x5, x9, #2
	stp	x11, x10, [sp]
Lloh70:
	adrp	x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.35@PAGE
Lloh71:
	add	x7, x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.35@PAGEOFF
	mov	x0, x8
	mov	w2, #13
	mov	w4, #5
	bl	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter26debug_struct_field4_finish
	b	LBB10_14
LBB10_12:
Lloh72:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.17@PAGE
Lloh73:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.17@PAGEOFF
	mov	x0, x8
	mov	w2, #13
	.cfi_def_cfa wsp, 112
	b	LBB10_17
LBB10_13:
	.cfi_restore_state
	.cfi_remember_state
	add	x10, x9, #16
	stur	x10, [x29, #-8]
Lloh74:
	adrp	x10, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.27@PAGE
Lloh75:
	add	x10, x10, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.27@PAGEOFF
	str	x10, [sp, #16]
	sub	x10, x29, #8
	mov	w11, #11
	stp	x11, x10, [sp]
Lloh76:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.28@PAGE
Lloh77:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.28@PAGEOFF
Lloh78:
	adrp	x3, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.29@PAGE
Lloh79:
	add	x3, x3, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.29@PAGEOFF
Lloh80:
	adrp	x6, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.26@PAGE
Lloh81:
	add	x6, x6, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.26@PAGEOFF
	add	x5, x9, #8
Lloh82:
	adrp	x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.30@PAGE
Lloh83:
	add	x7, x7, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.30@PAGEOFF
	mov	x0, x8
	mov	w2, #15
	mov	w4, #5
	bl	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
LBB10_14:
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB10_15:
	.cfi_restore_state
	.cfi_remember_state
Lloh84:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.19@PAGE
Lloh85:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.19@PAGEOFF
	mov	x0, x8
	mov	w2, #10
	.cfi_def_cfa wsp, 112
	b	LBB10_17
LBB10_16:
	.cfi_restore_state
Lloh86:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.38@PAGE
Lloh87:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.38@PAGEOFF
	mov	x0, x8
	mov	w2, #16
	.cfi_def_cfa wsp, 112
LBB10_17:
	ldp	x29, x30, [sp, #96]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter9write_str
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh86, Lloh87
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRlNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB11_3
	tbnz	w8, #26, LBB11_4
	b	__RNvXs9_NtNtNtCsgDHHaSskbIF_4core3fmt3num3implNtB9_7Display3fmt
LBB11_3:
	b	__RNvXsv_NtNtCsgDHHaSskbIF_4core3fmt3numlNtB7_8LowerHex3fmt
LBB11_4:
	b	__RNvXsx_NtNtCsgDHHaSskbIF_4core3fmt3numlNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRuNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness:
	.cfi_startproc
	mov	x0, x1
Lloh88:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.50@PAGE
Lloh89:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.50@PAGEOFF
	mov	w2, #2
	b	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter3pad
	.loh AdrpAdd	Lloh88, Lloh89
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRyNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB13_3
	tbnz	w8, #26, LBB13_4
	b	__RNvXsd_NtNtNtCsgDHHaSskbIF_4core3fmt3num3impyNtB9_7Display3fmt
LBB13_3:
	b	__RNvXsC_NtNtCsgDHHaSskbIF_4core3fmt3numyNtB7_8LowerHex3fmt
LBB13_4:
	b	__RNvXsE_NtNtCsgDHHaSskbIF_4core3fmt3numyNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt:
	.cfi_startproc
	mov	x8, x1
	ldrb	w9, [x0]
Lloh90:
	adrp	x10, l_switch.table._RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt@PAGE
Lloh91:
	add	x10, x10, l_switch.table._RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt@PAGEOFF
	ldr	x2, [x10, x9, lsl #3]
Lloh92:
	adrp	x10, l_switch.table._RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt.17@PAGE
Lloh93:
	add	x10, x10, l_switch.table._RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt.17@PAGEOFF
	ldr	x1, [x10, x9, lsl #3]
	mov	x0, x8
	b	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter9write_str
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh90, Lloh91
	.cfi_endproc

	.p2align	2
__RNvXsX_NtNtCsgDHHaSskbIF_4core3fmt3numyNtB7_5Debug3fmt:
	.cfi_startproc
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB15_3
	tbnz	w8, #26, LBB15_4
	b	__RNvXsd_NtNtNtCsgDHHaSskbIF_4core3fmt3num3impyNtB9_7Display3fmt
LBB15_3:
	b	__RNvXsC_NtNtCsgDHHaSskbIF_4core3fmt3numyNtB7_8LowerHex3fmt
LBB15_4:
	b	__RNvXsE_NtNtCsgDHHaSskbIF_4core3fmt3numyNtB7_8UpperHex3fmt
	.cfi_endproc

	.p2align	2
__RNvXsn_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core3fmt5Debug3fmtCs5JOyHbDOhEp_7witness:
	.cfi_startproc
	mov	x2, x1
	ldp	x8, x1, [x0]
	mov	x0, x8
	b	__RNvXsh_NtCsgDHHaSskbIF_4core3fmteNtB5_5Debug3fmt
	.cfi_endproc

	.p2align	2
__RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt:
	.cfi_startproc
	mov	x8, x1
	ldrb	w9, [x0]
Lloh94:
	adrp	x10, l_switch.table._RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt@PAGE
Lloh95:
	add	x10, x10, l_switch.table._RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt@PAGEOFF
	ldr	x2, [x10, x9, lsl #3]
Lloh96:
	adrp	x10, l_switch.table._RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt.18@PAGE
Lloh97:
	add	x10, x10, l_switch.table._RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt.18@PAGEOFF
	ldr	x1, [x10, x9, lsl #3]
	mov	x0, x8
	b	__RNvMsa_NtCsgDHHaSskbIF_4core3fmtNtB5_9Formatter9write_str
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh94, Lloh95
	.cfi_endproc

	.globl	_cold_debit
	.p2align	2
_cold_debit:
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception2
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x19, x8
	ldr	x8, [x0]
	cbnz	x8, LBB18_13
	mov	x20, x0
	mov	x8, #-1
	str	x8, [x0]
	ldr	x8, [x0, #8]
	adds	x21, x8, #1
	b.hs	LBB18_14
	cmp	x21, #100
	b.hi	LBB18_10
	cbz	x1, LBB18_7
Ltmp22:
	add	x8, sp, #8
	mov	x0, x2
	blr	x1
Ltmp23:
	ldrb	w10, [sp, #8]
	cmp	w10, #8
	b.ne	LBB18_11
	ldr	x8, [x20]
	add	x8, x8, #1
	b	LBB18_8
LBB18_7:
	mov	x8, #0
LBB18_8:
	stp	x8, x21, [x20]
	mov	w8, #8
	strb	w8, [x19]
LBB18_9:
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB18_10:
	.cfi_restore_state
	mov	x12, #0
	mov	w8, #6
	mov	w9, #1
	mov	w11, #100
	mov	w10, #6
	b	LBB18_12
LBB18_11:
	ldrb	w8, [sp, #9]
	ldrb	w9, [sp, #10]
	ldur	w11, [sp, #11]
	str	w11, [sp]
	ldrb	w11, [sp, #15]
	strb	w11, [sp, #4]
	ldp	x21, x11, [sp, #16]
	ldr	x12, [x20]
	add	x12, x12, #1
	ldp	x13, x14, [sp, #32]
LBB18_12:
	str	x12, [x20]
	strb	w10, [sp, #8]
	strb	w8, [sp, #9]
	strb	w9, [sp, #10]
	ldr	w8, [sp]
	stur	w8, [sp, #11]
	ldrb	w8, [sp, #4]
	strb	w8, [sp, #15]
	stp	x21, x11, [sp, #16]
	stp	x13, x14, [sp, #32]
	add	x1, sp, #8
	mov	x0, x19
	bl	__RNvCs5JOyHbDOhEp_7witness15forward_failure
	b	LBB18_9
LBB18_13:
Lloh98:
	adrp	x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.55@PAGE
Lloh99:
	add	x0, x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.55@PAGEOFF
	bl	__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed
LBB18_14:
	mov	x12, #0
	mov	w10, #3
	b	LBB18_12
LBB18_15:
Ltmp24:
	ldr	x8, [x20]
	add	x8, x8, #1
	str	x8, [x20]
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh98, Lloh99
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table18:
Lexception2:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Ltmp22-Lfunc_begin2
	.uleb128 Ltmp23-Ltmp22
	.uleb128 Ltmp24-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp23-Lfunc_begin2
	.uleb128 Lfunc_end2-Ltmp23
	.byte	0
	.byte	0
Lcst_end2:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	_current_debit
	.p2align	2
_current_debit:
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception3
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x20, x8
	ldr	x8, [x0]
	cbnz	x8, LBB19_11
	mov	x19, x0
	mov	x8, #-1
	str	x8, [x0]
	ldr	x8, [x0, #8]
	adds	x21, x8, #1
	b.hs	LBB19_12
	cmp	x21, #100
	b.ls	LBB19_4
	mov	w8, #1542
	strh	w8, [x20]
	mov	w8, #1
	strb	w8, [x20, #2]
	mov	w8, #100
	stp	x21, x8, [x20, #8]
	b	LBB19_10
LBB19_4:
	cbz	x1, LBB19_7
Ltmp25:
	add	x8, sp, #8
	mov	x0, x2
	blr	x1
Ltmp26:
	ldrb	w8, [sp, #8]
	cmp	w8, #8
	b.ne	LBB19_9
LBB19_7:
	str	x21, [x19, #8]
	mov	w8, #8
LBB19_8:
	strb	w8, [x20]
	b	LBB19_10
LBB19_9:
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x20]
	ldr	x8, [sp, #40]
	str	x8, [x20, #32]
LBB19_10:
	ldr	x8, [x19]
	add	x8, x8, #1
	str	x8, [x19]
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB19_11:
	.cfi_restore_state
Lloh100:
	adrp	x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.56@PAGE
Lloh101:
	add	x0, x0, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.56@PAGEOFF
	bl	__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed
LBB19_12:
	mov	w8, #3
	b	LBB19_8
LBB19_13:
Ltmp27:
	ldr	x8, [x19]
	add	x8, x8, #1
	str	x8, [x19]
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh100, Lloh101
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table19:
Lexception3:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Ltmp25-Lfunc_begin3
	.uleb128 Ltmp26-Ltmp25
	.uleb128 Ltmp27-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp26-Lfunc_begin3
	.uleb128 Lfunc_end3-Ltmp26
	.byte	0
	.byte	0
Lcst_end3:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	_main
	.p2align	2
_main:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x3, x1
	sxtw	x2, w0
Lloh102:
	adrp	x8, __RNvCs5JOyHbDOhEp_7witness4main@PAGE
Lloh103:
	add	x8, x8, __RNvCs5JOyHbDOhEp_7witness4main@PAGEOFF
	str	x8, [sp, #8]
Lloh104:
	adrp	x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.1@PAGE
Lloh105:
	add	x1, x1, l_anon.5e292f7a00521c8ccc5b83728ed07eb4.1@PAGEOFF
	add	x0, sp, #8
	mov	w4, #0
	bl	__RNvNtCsgirOGyZpP7g_3std2rt19lang_start_internal
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh102, Lloh103
	.cfi_endproc

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRINtNtB8_6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorENtB6_5Debug3fmtCs5JOyHbDOhEp_7witness

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNSNvYNCINvNtCsgirOGyZpP7g_3std2rt10lang_startuE0INtNtNtCsgDHHaSskbIF_4core3ops8function6FnOnceuE9call_once6vtableCs5JOyHbDOhEp_7witness
	.quad	__RNCINvNtCsgirOGyZpP7g_3std2rt10lang_startuE0Cs5JOyHbDOhEp_7witness
	.quad	__RNCINvNtCsgirOGyZpP7g_3std2rt10lang_startuE0Cs5JOyHbDOhEp_7witness

	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.2:
	.asciz	"(\000\000\000\000\000\000"

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.3:
	.asciz	"8\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.4:
	.asciz	"\021EQUIVALENT cases=\300\020 resident_error=\300\021 resident_result=\300\016 native_error=\300\021 iteration_error=\300\001\n"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5:
	.asciz	"/private/tmp/mech-cold-budget-errors-round76-20261031/prototype-borrow/witness.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.6:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5
	.asciz	"Q\000\000\000\000\000\000\000-\000\000\000\t\000\000"

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.7:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5
	.asciz	"Q\000\000\000\000\000\000\000-\000\000\0002\000\000"

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.8:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5
	.asciz	"Q\000\000\000\000\000\000\000-\000\000\000?\000\000"

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.9:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5
	.asciz	"Q\000\000\000\000\000\000\000-\000\000\000$\000\000"

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.10:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5
	.asciz	"Q\000\000\000\000\000\000\000-\000\000\000]\000\000"

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.11:
	.ascii	"opaque"

	.section	__TEXT,__literal8,8byte_literals
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.12:
	.ascii	"Planning"

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.13:
	.ascii	"Admission"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.14:
	.ascii	"Execution"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.15:
	.ascii	"Publication"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.16:
	.ascii	"InvalidInput"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.17:
	.ascii	"InvalidOutput"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.18:
	.ascii	"InvalidShape"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.19:
	.ascii	"Arithmetic"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.20:
	.quad	__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxeEECs5JOyHbDOhEp_7witness
	.asciz	"\020\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXsn_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core3fmt5Debug3fmtCs5JOyHbDOhEp_7witness

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.21:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRlNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.22:
	.ascii	"ProviderStatus"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.23:
	.ascii	"operation"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.24:
	.ascii	"status"

	.section	__TEXT,__literal4,4byte_literals
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.25:
	.ascii	"code"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.26:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXsX_NtNtCsgDHHaSskbIF_4core3fmt3numyNtB7_5Debug3fmt

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.27:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRyNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.28:
	.ascii	"IndexOutOfRange"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.29:
	.ascii	"index"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.30:
	.ascii	"upper_bound"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.31:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	__RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.32:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	__RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.33:
	.ascii	"ResourceLimit"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.34:
	.ascii	"phase"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.35:
	.ascii	"dimension"

	.section	__TEXT,__literal8,8byte_literals
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.36:
	.ascii	"required"

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.37:
	.ascii	"limit"

	.section	__TEXT,__literal16,16byte_literals
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.38:
	.ascii	"IncompleteOutput"

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.39:
	.ascii	"OutputElements"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.40:
	.ascii	"OutputBytes"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.41:
	.ascii	"TemporaryBytes"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.42:
	.ascii	"ClonedBytes"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.43:
	.ascii	"RetainedNodes"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.44:
	.ascii	"ComparisonWork"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.45:
	.ascii	"ComputeWork"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.46:
	.ascii	"ScalarInstructions"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.47:
	.ascii	"TransferBytes"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.48:
	.ascii	"StorageBufferBytes"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.49:
	.ascii	"StorageBindings"

l_anon.5e292f7a00521c8ccc5b83728ed07eb4.50:
	.ascii	"()"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.51:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRuNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.52:
	.ascii	"Ok"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.53:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsgDHHaSskbIF_4core3fmtRNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorNtB6_5Debug3fmtCs5JOyHbDOhEp_7witness

	.section	__TEXT,__const
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.54:
	.ascii	"Err"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.55:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5
	.asciz	"Q\000\000\000\000\000\000\000\027\000\000\000\036\000\000"

	.p2align	3, 0x0
l_anon.5e292f7a00521c8ccc5b83728ed07eb4.56:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.5
	.asciz	"Q\000\000\000\000\000\000\000\017\000\000\000!\000\000"

	.section	__TEXT,__const
	.p2align	3, 0x0
l_switch.table._RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt:
	.quad	8
	.quad	9
	.quad	9
	.quad	11

	.section	__DATA,__const
	.p2align	3, 0x0
l_switch.table._RNvXs1i_NtNtCskIfnrfrMWVM_9mech_core8function8residentNtB6_21ResidentResourcePhaseNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt.17:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.12
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.13
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.14
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.15

	.section	__TEXT,__const
	.p2align	3, 0x0
l_switch.table._RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt:
	.quad	14
	.quad	11
	.quad	14
	.quad	11
	.quad	13
	.quad	14
	.quad	11
	.quad	18
	.quad	13
	.quad	18
	.quad	15

	.section	__DATA,__const
	.p2align	3, 0x0
l_switch.table._RNvXsp_NtNtCskIfnrfrMWVM_9mech_core11memory_plan6budgetNtB5_21MemoryBudgetDimensionNtNtCsgDHHaSskbIF_4core3fmt5Debug3fmt.18:
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.39
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.40
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.41
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.42
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.43
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.44
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.45
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.46
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.47
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.48
	.quad	l_anon.5e292f7a00521c8ccc5b83728ed07eb4.49

.subsections_via_symbols
