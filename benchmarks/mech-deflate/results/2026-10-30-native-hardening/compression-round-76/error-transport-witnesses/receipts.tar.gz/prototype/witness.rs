use mech_core::{MemoryBudgetDimension, ResidentKernelError as Error, ResidentResourcePhase};
pub type Worker = fn(u64) -> Result<(), Error>;
#[unsafe(no_mangle)]
#[inline(never)]
pub fn current_debit(account: &mut u64, worker: Option<Worker>, arg: u64) -> Result<(), Error> {
    let next = account.checked_add(1).ok_or(Error::Arithmetic)?;
    if let Some(worker) = worker { worker(arg)?; }
    *account = next;
    Ok(())
}
#[cold]
#[inline(never)]
fn forward_failure(error: Error) -> Result<(), Error> { Err(error) }
#[unsafe(no_mangle)]
#[inline(never)]
pub fn cold_debit(account: &mut u64, worker: Option<Worker>, arg: u64) -> Result<(), Error> {
    let next = account.checked_add(1).ok_or(Error::Arithmetic)?;
    if let Some(worker) = worker {
        if let Err(error) = worker(arg) { return forward_failure(error); }
    }
    *account = next;
    Ok(())
}
fn worker(arg: u64) -> Result<(), Error> {
    match arg {
        0 => Ok(()), 1 => Err(Error::InvalidInput),
        2 | 3 => Err(Error::ResourceLimit { phase: ResidentResourcePhase::Admission, dimension: if arg == 2 { MemoryBudgetDimension::ComputeWork } else { MemoryBudgetDimension::ComparisonWork }, required: 7, limit: 6 }),
        4 => Err(Error::Arithmetic),
        5 => Err(Error::ProviderStatus { operation: "opaque".into(), status: "rejected".into(), code: 7 }),
        6 => Err(Error::IndexOutOfRange { index: 7, upper_bound: 6 }),
        7 => Err(Error::InvalidShape), 8 => Err(Error::InvalidOutput), _ => Err(Error::IncompleteOutput),
    }
}
fn main() {
    let mut cases = 0;
    for initial in [0, u64::MAX] { for arg in 0..10 { for selected in [None, Some(worker as Worker)] {
        let mut a = initial; let mut b = initial;
        let current = current_debit(&mut a, selected, arg); let cold = cold_debit(&mut b, selected, arg);
        assert_eq!(current, cold); assert_eq!(a, b); if cold.is_err() { assert_eq!(b, initial); }
        cases += 1;
    }}}
    println!("EQUIVALENT cases={cases} resident_error={} resident_result={} native_error={} iteration_error={}", std::mem::size_of::<Error>(),std::mem::size_of::<Result<(), Error>>(),std::mem::size_of::<mech_gpu::native_artifact::NativeExecutionError>(),std::mem::size_of::<mech_gpu::native_artifact::NativeIterationExecutionError>());
}
