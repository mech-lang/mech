from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack')
p=r/'retained-memory';p.mkdir(exist_ok=True)
source=(r/'mech_memory.rs').read_text().replace('fn main() {','unsafe extern "C" { fn mi_collect(force: bool); }\nfn main() {')
source=source.replace(' for sample in 0..=samples + 1 {',''' eprintln!("BEFORE_COLLECT");let mut gate=String::new();std::io::stdin().read_line(&mut gate).unwrap();
 unsafe { mi_collect(true); }
 eprintln!("AFTER_COLLECT");gate.clear();std::io::stdin().read_line(&mut gate).unwrap();
 for sample in 0..=samples + 1 {''')
(p/'main.rs').write_text(source)
def command(name,cmd):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 (p/(name+'.stdout')).write_text(q.stdout);(p/(name+'.stderr')).write_text(q.stderr)
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at},indent=2)+'\n')
 print(name,q.returncode,flush=True);q.check_returncode()
base=json.loads((r/'mech-memory-round37-build.json').read_text());cmd=base['command'].copy();cmd[-3]=str(p/'main.rs');cmd[-1]=str(p/'mech-retained-memory')
command('runner-build',cmd)
cmd=[str(p/'mech-retained-memory'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','1'];at=time.monotonic()
with (p/'run.stdout').open('w') as out,(p/'run.stderr').open('w') as err:
 q=subprocess.Popen(cmd,cwd=w,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True)
 for label,marker in [('before','BEFORE_COLLECT'),('after','AFTER_COLLECT')]:
  deadline=time.monotonic()+180
  while marker not in (p/'run.stderr').read_text():
   assert q.poll() is None;assert time.monotonic()<deadline;time.sleep(.1)
  command(label+'-vmmap',['/usr/bin/vmmap','-summary',str(q.pid)])
  q.stdin.write('\n');q.stdin.flush()
 code=q.wait()
(p/'run.json').write_text(json.dumps({'command':cmd,'exit':code,'seconds':time.monotonic()-at,'scope':'Causal diagnostic only: force the pinned allocator to release unused memory after preparation, before compression. Original benchmark and primary timings unchanged.','binary_sha256':hashlib.sha256((p/'mech-retained-memory').read_bytes()).hexdigest()},indent=2)+'\n')
rows=[json.loads(x) for x in (p/'run.stdout').read_text().splitlines() if x.startswith('{')]
assert code==0 and len(rows)==3 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==44443887150 for x in rows)
assert (p/'run.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
files=[f for f in p.iterdir() if f.name!='mech-retained-memory']
subprocess.run(['python3',str(r/'archive.py'),'retained-memory',*map(str,files),str(r/'attribute-retained-memory.py')],cwd=w,check=True)
print('RETAINED MEMORY ATTRIBUTION COMPLETE',flush=True)
