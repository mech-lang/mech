from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/roc-deflate-repro-20261024/roc-deflate');mi=old/'benchmark/echo-clock/targets/arm64mac/mimalloc.o';inc=r/'include';compiler=Path('/private/tmp/roc-deflate-repro-20261024/roc-install/bin/roc')
assert hashlib.sha256(mi.read_bytes()).hexdigest()=='38c6ec82a41e90a96bb9f1ae2c89058a77909da3fbb69c16e542ae5c858bf874'
def run_build(name,cmd):
 start=time.monotonic();p=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(r/(name+'.stdout')).write_text(p.stdout);(r/(name+'.stderr')).write_text(p.stderr);(r/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start},indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:print(p.stdout[-3500:]+p.stderr[-3500:],flush=True)
 p.check_returncode()
for mode,flag in [('cpu','0'),('memory','1')]:
 platform=r/('platform-'+mode);target=platform/'targets/arm64mac';target.mkdir(parents=True,exist_ok=True)
 for name in ['main.roc','Host.roc','roc_platform_abi.h']:shutil.copy2(r/'reference-platform'/name,platform/name)
 p=platform/'main.roc';p.write_text(p.read_text().replace('"mimalloc.o", app','"mimalloc.o", "usage.o", "allocation_profile.o", app'))
 shutil.copy2(mi,target/'mimalloc.o');shutil.copy2(r/'usage.o',target/'usage.o')
 run_build('roc-'+mode+'-probe-build',['clang','-std=c11','-O3','-Wall','-Wextra','-Werror','-DPROBE_MEMORY='+flag,'-I'+str(inc),'-I'+str(r),'-c',str(r/'allocation_profile.c'),'-o',str(target/'allocation_profile.o')])
 run_build('roc-'+mode+'-host-build',['clang','-std=c11','-O3','-Wall','-Wextra','-Werror','-DMI_STATIC_LIB','-DPROBE_MEMORY='+flag,'-I'+str(inc),'-I'+str(r),'-I'+str(platform),'-c',str(r/'reference-profile-host.c'),'-o',str(target/'host.o')])
 stage=r/('reference-stage-'+mode);stage.mkdir(exist_ok=True)
 base=Path('/private/tmp/mech-deflate-profiling-20261028/roc-stage')
 for name in ['Bench.roc','input','prefix','expected.deflate']:shutil.copy2(base/name,stage/name)
 app=(base/'app.roc').read_text().replace('../../roc-deflate-repro-20261024/roc-deflate/benchmark/echo-clock/main.roc','../platform-'+mode+'/main.roc').replace('../../roc-deflate-repro-20261024/roc-deflate/package/main.roc','../reference-package/main.roc');(stage/'app.roc').write_text(app)
 run_build('roc-'+mode+'-app-build',[str(compiler),'build',str(stage/'app.roc'),'--opt=speed','--target=arm64mac','--jobs=1','--output='+str(r/('reference-'+mode))])
 (r/('reference-'+mode+'-identity.json')).write_text(json.dumps({'sha256':hashlib.sha256((r/('reference-'+mode)).read_bytes()).hexdigest(),'bench_source_sha256':hashlib.sha256((stage/'Bench.roc').read_bytes()).hexdigest(),'host_source_sha256':hashlib.sha256((r/'reference-profile-host.c').read_bytes()).hexdigest(),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'compressor_package_sources_unchanged':True,'mode':mode},indent=2)+'\n')
 p=r/('reference-'+mode+'-run');p.mkdir();cmd=[str(r/('reference-'+mode)),'12'];start=time.monotonic()
 with (p/'run.stdout').open('w') as out,(p/'run.stderr').open('w') as err:q=subprocess.run(cmd,cwd=r,stdout=out,stderr=err)
 (p/'run.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-start,'diagnostic_only':True},indent=2)+'\n')
 rows=[json.loads(s.split(' ',1)[1]) for s in (p/'run.stderr').read_text().splitlines() if s.startswith('ALLOC_PROBE ')];lines=[s for s in (p/'run.stdout').read_text().splitlines() if s.startswith('rep\troc-deflate\t')];print('REFERENCE',mode,'observations',len(rows),'verified compressions',len(lines),flush=True)
 assert q.returncode==0 and len(rows)==32 and len(lines)==20000
 paths=[p,r/'reference-profile-host.c',r/'allocation_profile.c',r/'allocation_profile.h',r/'usage.c',r/'usage.h',r/'package-verification.json',r/('reference-'+mode+'-identity.json'),r/('roc-'+mode+'-app-build.json'),r/('roc-'+mode+'-app-build.stdout'),r/('roc-'+mode+'-app-build.stderr'),r/('roc-'+mode+'-host-build.json'),r/('roc-'+mode+'-host-build.stderr'),r/('roc-'+mode+'-probe-build.json'),r/('roc-'+mode+'-probe-build.stderr'),r/'build-reference.py']
 subprocess.run(['python3',str(r/'archive.py'),'reference-'+mode,*map(str,paths)],cwd=w,check=True)
