#include <libproc.h>
#include <sys/resource.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
int main(void) {
 struct rusage_info_v4 a={0},b={0};
 int ea=proc_pid_rusage(getpid(),RUSAGE_INFO_V4,(rusage_info_t *)&a);
 volatile unsigned long long sum=0;
 for(unsigned long long i=0;i<1000000;i++) sum+=i;
 int eb=proc_pid_rusage(getpid(),RUSAGE_INFO_V4,(rusage_info_t *)&b);
 printf("{\"first_exit\":%d,\"second_exit\":%d,\"errno\":%d,\"instructions\":%llu,\"cycles\":%llu,\"resident\":%llu,\"physical\":%llu,\"lifetime_peak_physical\":%llu,\"sum\":%llu}\n",ea,eb,errno,b.ri_instructions-a.ri_instructions,b.ri_cycles-a.ri_cycles,b.ri_resident_size,b.ri_phys_footprint,b.ri_lifetime_max_phys_footprint,sum);
 return ea||eb;
}
