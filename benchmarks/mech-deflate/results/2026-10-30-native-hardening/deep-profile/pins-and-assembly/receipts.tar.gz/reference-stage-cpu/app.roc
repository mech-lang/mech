app [main!] {
 pf: platform "../platform-cpu/main.roc",
 deflate: "../reference-package/main.roc",
}
import Bench
import "input" as input : List(U8)
import "prefix" as prefix : List(U8)
import "expected.deflate" as expected : List(U8)
main! = |level| Bench.run!(input, prefix, expected, 20000, level)
