#include "allocation_profile.h"
#include "mimalloc.h"
#include <stdint.h>
int main(void) {
 probe_begin();
 void *a=mi_malloc(16);probe_alloc(a,16);
 void *b=mi_malloc(32);probe_alloc(b,32);
 size_t old=probe_usable(b);uintptr_t addr=(uintptr_t)b;
 b=mi_realloc(b,128);probe_realloc(addr,old,b,128);
 probe_free(a);mi_free(a);probe_free(b);mi_free(b);
 probe_end();probe_print(0);return 0;
}
