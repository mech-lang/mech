from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');mi=Path('/private/tmp/roc-deflate-repro-20261024/roc-deflate/benchmark/echo-clock/targets/arm64mac/mimalloc.o')
def command(name,cmd):
 start=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(r/(name+'.stdout')).write_text(q.stdout);(r/(name+'.stderr')).write_text(q.stderr);(r/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-start},indent=2)+'\n');print(name,q.returncode,flush=True)
 if q.returncode:print(q.stderr[-3500:],flush=True)
 q.check_returncode();return q
command('memory-probe-build',['clang','-O3','-std=c11','-Wall','-Wextra','-Werror','-DPROBE_MEMORY=1','-I'+str(r/'include'),'-I'+str(r),'-c',str(r/'allocation_profile.c'),'-o',str(r/'memory_profile.o')])
command('memory-calibration-build',['clang','-O3','-I'+str(r/'include'),'-I'+str(r),str(r/'calibrate_memory.c'),str(r/'memory_profile.o'),str(r/'usage.o'),str(mi),'-o',str(r/'calibrate_memory')])
p=command('memory-calibration',[str(r/'calibrate_memory')]);line=[x for x in p.stderr.splitlines() if x.startswith('ALLOC_PROBE ')][0];row=json.loads(line.split(' ',1)[1]);assert row['allocation_requests']==3 and row['requested_bytes']==176 and row['reallocations']==1 and row['deallocation_calls']==2 and row['live_usable_before']==0 and row['live_usable_after']==0 and row['incremental_peak_live_usable']==144,row
for label,root in [('round36',Path('/private/tmp/mech-retirement-round36-20261030')),('round37',Path('/private/tmp/mech-action-retirement-round37-20261030'))]:
 base=json.loads((root/'primary/current-build.json').read_text());cmd=base['command'].copy();cmd[-3]=str(r/'mech_memory.rs');cmd[-1]=str(r/('mech-memory-'+label));cmd[-3:-3]=['-C','link-arg='+str(r/'usage.o'),'-C','link-arg='+str(r/'memory_profile.o')]
 command('mech-memory-'+label+'-build',cmd)
 p=r/('memory-'+label);p.mkdir();cmd=[str(r/('mech-memory-'+label)),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','8'];start=time.monotonic()
 with (p/'run.stdout').open('w') as out,(p/'run.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (p/'run.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-start,'scope':'Memory instrumentation only; elapsed and instructions are not primary comparison observations','libraries':base['libraries'],'binary_sha256':hashlib.sha256((r/('mech-memory-'+label)).read_bytes()).hexdigest()},indent=2)+'\n')
 rows=[json.loads(x) for x in (p/'run.stdout').read_text().splitlines() if x.startswith('{')];alloc=[json.loads(x.split(' ',1)[1]) for x in (p/'run.stderr').read_text().splitlines() if x.startswith('ALLOC_PROBE ')]
 print('MEMORY',label,q.returncode,'observations',len(rows),len(alloc),flush=True)
 assert q.returncode==0 and len(rows)==len(alloc)==10 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==44443887150 for x in rows)
 assert (p/'run.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
 paths=[p,r/'mech_memory.rs',r/'allocation_profile.rs',r/'allocation_profile.c',r/'allocation_profile.h',r/'usage.c',r/'usage.h',r/'calibrate_memory.c',r/'memory-calibration.json',r/'memory-calibration.stdout',r/'memory-calibration.stderr',r/'build-memory.py',r/('mech-memory-'+label+'-build.json'),r/('mech-memory-'+label+'-build.stderr')]
 subprocess.run(['python3',str(r/'archive.py'),'memory-'+label,*map(str,paths)],cwd=w,check=True)
