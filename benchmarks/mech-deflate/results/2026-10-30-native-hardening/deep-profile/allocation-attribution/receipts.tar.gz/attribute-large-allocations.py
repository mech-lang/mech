from pathlib import Path
import hashlib, json, subprocess, time

r = Path(__file__).resolve().parent
w = Path('/private/tmp/mech-deflate-linear-stack')
p = r / 'allocation-attribution'
p.mkdir(exist_ok=True)
c = (r / 'allocation_profile.c').read_text()
c = c.replace('#include <stdlib.h>', '#include <stdlib.h>\n#include <execinfo.h>\n#include <unistd.h>')
c = c.replace('static struct bench_usage start, finish;', '''static struct bench_usage start, finish;
static unsigned visits, stack_count;
static void *stack_frames[64][40];
static unsigned stack_lengths[64];
static size_t stack_sizes[64];
static void capture_large_stack(size_t bytes) {
    if(visits!=2 || (bytes!=2442056 && bytes!=524288 && bytes!=6002052)) return;
    if(stack_count==64) abort();
    unsigned at=stack_count++;
    stack_sizes[at]=bytes;
    stack_lengths[at]=(unsigned)backtrace(stack_frames[at],40);
}''')
c = c.replace('requested(bytes);maximum(&peak,now);', 'requested(bytes);capture_large_stack(bytes);maximum(&peak,now);')
c = c.replace('void probe_begin(void) {', 'void probe_begin(void) {\n    visits++;stack_count=0;')
c = c.replace('    fputs("]}\\n",stderr);', '''    fputs("]}\\n",stderr);
    for(unsigned i=0;i<stack_count;i++) {
        fprintf(stderr,"ALLOCATION_STACK index=%u bytes=%zu frames=%u\\n",i,stack_sizes[i],stack_lengths[i]);
        fflush(stderr);backtrace_symbols_fd(stack_frames[i],(int)stack_lengths[i],STDERR_FILENO);
    }''')
(p / 'allocation_stacks.c').write_text(c)
rs = (r / 'mech_memory.rs').read_text().replace(' for sample in 0..=samples + 1 {', ''' if std::env::var_os("PROFILE_HOLD").is_some() {
  eprintln!("PROFILE_READY");let mut gate=String::new();std::io::stdin().read_line(&mut gate).unwrap();
 }
 for sample in 0..=samples + 1 {''')
(p / 'main.rs').write_text(rs)

def command(name, cmd):
    start=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
    (p/(name+'.stdout')).write_text(q.stdout);(p/(name+'.stderr')).write_text(q.stderr)
    (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
    print(name,q.returncode,flush=True);q.check_returncode()

command('probe-build',['clang','-O3','-std=c11','-Wall','-Wextra','-Werror','-DPROBE_MEMORY=1','-I'+str(r/'include'),'-I'+str(r),'-c',str(p/'allocation_stacks.c'),'-o',str(p/'stacks.o')])
base=json.loads((Path('/private/tmp/mech-action-retirement-round37-20261030')/'primary/current-build.json').read_text())
cmd=base['command'].copy();cmd[-3]=str(p/'main.rs');cmd[-1]=str(p/'mech-stacks');cmd[-3:-3]=['-C','link-arg='+str(r/'usage.o'),'-C','link-arg='+str(p/'stacks.o')]
command('runner-build',cmd)
cmd=[str(p/'mech-stacks'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','1']
import os
env=os.environ.copy();env['PROFILE_HOLD']='1'
start=time.monotonic()
with (p/'run.stdout').open('w') as out,(p/'run.stderr').open('w') as err:
    q=subprocess.Popen(cmd,cwd=w,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True,env=env)
    deadline=time.monotonic()+180
    while 'PROFILE_READY' not in (p/'run.stderr').read_text():
        assert q.poll() is None, 'runner exited before hold'
        assert time.monotonic()<deadline, 'runner preparation exceeded diagnostic wait'
        time.sleep(.1)
    command('prepared-vmmap',['/usr/bin/vmmap','-summary',str(q.pid)])
    q.stdin.write('\n');q.stdin.flush();code=q.wait()
(p/'run.json').write_text(json.dumps({'command':cmd,'exit':code,'seconds':time.monotonic()-start,'scope':'Diagnostic attribution only: backtraces deliberately perturb allocations/CPU; not timing evidence','libraries':base['libraries'],'binary_sha256':hashlib.sha256((p/'mech-stacks').read_bytes()).hexdigest()},indent=2)+'\n')
rows=[json.loads(x) for x in (p/'run.stdout').read_text().splitlines() if x.startswith('{')]
assert code==0 and len(rows)==3 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==44443887150 for x in rows)
assert (p/'run.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
files=[f for f in p.iterdir() if f.is_file() and f.suffix not in {'.o'} and f.name!='mech-stacks']
subprocess.run(['python3',str(r/'archive.py'),'allocation-attribution',*map(str,files),str(r/'attribute-large-allocations.py')],cwd=w,check=True)
print('ATTRIBUTION COMPLETE',flush=True)
