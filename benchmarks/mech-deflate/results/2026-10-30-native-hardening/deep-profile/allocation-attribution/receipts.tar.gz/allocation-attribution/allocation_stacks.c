#include "allocation_profile.h"
#include "usage.h"
#include "mimalloc.h"
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <execinfo.h>
#include <unistd.h>

#ifndef PROBE_MEMORY
#define PROBE_MEMORY 1
#endif
#define U(x) ((unsigned long long)(x))
static _Atomic uint64_t live, peak, requests, requested_bytes, frees, reallocs, moved, moved_bytes;
static _Atomic uint64_t sizes[64], counts[64];
static _Atomic int active;
static uint64_t baseline;
static uint64_t final_live, final_peak;
static struct bench_usage start, finish;
static unsigned visits, stack_count;
static void *stack_frames[64][40];
static unsigned stack_lengths[64];
static size_t stack_sizes[64];
static void capture_large_stack(size_t bytes) {
    if(visits!=2 || (bytes!=2442056 && bytes!=524288 && bytes!=6002052)) return;
    if(stack_count==64) abort();
    unsigned at=stack_count++;
    stack_sizes[at]=bytes;
    stack_lengths[at]=(unsigned)backtrace(stack_frames[at],40);
}

static void maximum(_Atomic uint64_t *at, uint64_t n) {
    uint64_t prior=atomic_load_explicit(at,memory_order_relaxed);
    while(prior<n && !atomic_compare_exchange_weak_explicit(at,&prior,n,memory_order_relaxed,memory_order_relaxed)) {}
}
static void requested(size_t bytes) {
    atomic_fetch_add_explicit(&requests,1,memory_order_relaxed);
    atomic_fetch_add_explicit(&requested_bytes,bytes,memory_order_relaxed);
    if(bytes<65536) return;
    for(size_t i=0;i<64;i++) {
        uint64_t key=atomic_load_explicit(&sizes[i],memory_order_relaxed);
        if(key==0) {
            uint64_t empty=0;
            if(atomic_compare_exchange_strong_explicit(&sizes[i],&empty,bytes,memory_order_relaxed,memory_order_relaxed)) key=bytes;
            else key=empty;
        }
        if(key==bytes) { atomic_fetch_add_explicit(&counts[i],1,memory_order_relaxed);return; }
    }
    abort(); /* Never silently discard an overflowing histogram. */
}
size_t probe_usable(void *ptr) { return ptr ? mi_usable_size(ptr) : 0; }
void probe_alloc(void *ptr, size_t bytes) {
    if(!PROBE_MEMORY || !ptr) return;
    uint64_t now=atomic_fetch_add_explicit(&live,probe_usable(ptr),memory_order_relaxed)+probe_usable(ptr);
    if(atomic_load_explicit(&active,memory_order_relaxed)) { requested(bytes);capture_large_stack(bytes);maximum(&peak,now); }
}
void probe_realloc(uintptr_t old_address, size_t old_size, void *ptr, size_t bytes) {
    if(!PROBE_MEMORY || !ptr) return;
    size_t size=probe_usable(ptr);
    uint64_t now;
    if(size>=old_size) now=atomic_fetch_add_explicit(&live,size-old_size,memory_order_relaxed)+size-old_size;
    else now=atomic_fetch_sub_explicit(&live,old_size-size,memory_order_relaxed)-(old_size-size);
    if(atomic_load_explicit(&active,memory_order_relaxed)) {
        requested(bytes);atomic_fetch_add_explicit(&reallocs,1,memory_order_relaxed);maximum(&peak,now);
        if(old_address && old_address!=(uintptr_t)ptr) {
            atomic_fetch_add_explicit(&moved,1,memory_order_relaxed);
            atomic_fetch_add_explicit(&moved_bytes,old_size<bytes ? old_size : bytes,memory_order_relaxed);
        }
    }
}
void probe_free(void *ptr) {
    if(!PROBE_MEMORY || !ptr) return;
    size_t size=probe_usable(ptr);
    uint64_t prior=atomic_fetch_sub_explicit(&live,size,memory_order_relaxed);
    if(prior<size) abort();
    if(atomic_load_explicit(&active,memory_order_relaxed)) atomic_fetch_add_explicit(&frees,1,memory_order_relaxed);
}
void probe_begin(void) {
    visits++;stack_count=0;
    atomic_store(&requests,0);atomic_store(&requested_bytes,0);atomic_store(&frees,0);atomic_store(&reallocs,0);atomic_store(&moved,0);atomic_store(&moved_bytes,0);
    for(size_t i=0;i<64;i++) { atomic_store(&sizes[i],0);atomic_store(&counts[i],0); }
    baseline=atomic_load(&live);atomic_store(&peak,baseline);
    if(bench_read_usage(&start)) abort();
    atomic_store_explicit(&active,1,memory_order_relaxed);
}
void probe_end(void) {
    atomic_store_explicit(&active,0,memory_order_relaxed);
    final_live=atomic_load(&live);final_peak=atomic_load(&peak);
    if(bench_read_usage(&finish)) abort();
}
void probe_print(uint64_t sample) {
    fprintf(stderr,"ALLOC_PROBE {\"sample\":%llu,\"memory_instrumented\":%s,\"instructions\":%llu,\"cycles\":%llu,\"allocation_requests\":%llu,\"requested_bytes\":%llu,\"deallocation_calls\":%llu,\"reallocations\":%llu,\"relocating_reallocations\":%llu,\"relocating_realloc_copy_upper_bound\":%llu,\"live_usable_before\":%llu,\"live_usable_after\":%llu,\"peak_live_usable\":%llu,\"incremental_peak_live_usable\":%llu,\"rss_before\":%llu,\"rss_after\":%llu,\"physical_before\":%llu,\"physical_after\":%llu,\"lifetime_peak_physical\":%llu,\"pageins\":%llu,\"large_allocations\":[",U(sample),PROBE_MEMORY?"true":"false",U(finish.instructions-start.instructions),U(finish.cycles-start.cycles),U(atomic_load(&requests)),U(atomic_load(&requested_bytes)),U(atomic_load(&frees)),U(atomic_load(&reallocs)),U(atomic_load(&moved)),U(atomic_load(&moved_bytes)),U(baseline),U(final_live),U(final_peak),U(final_peak-baseline),U(start.rss),U(finish.rss),U(start.footprint),U(finish.footprint),U(finish.lifetime_peak),U(finish.pageins-start.pageins));
    int first=1;
    for(size_t i=0;i<64;i++) if(atomic_load(&sizes[i])) { fprintf(stderr,"%s{\"bytes\":%llu,\"count\":%llu}",first?"":",",U(atomic_load(&sizes[i])),U(atomic_load(&counts[i])));first=0; }
    fputs("]}\n",stderr);
    for(unsigned i=0;i<stack_count;i++) {
        fprintf(stderr,"ALLOCATION_STACK index=%u bytes=%zu frames=%u\n",i,stack_sizes[i],stack_lengths[i]);
        fflush(stderr);backtrace_symbols_fd(stack_frames[i],(int)stack_lengths[i],STDERR_FILENO);
    }
}
