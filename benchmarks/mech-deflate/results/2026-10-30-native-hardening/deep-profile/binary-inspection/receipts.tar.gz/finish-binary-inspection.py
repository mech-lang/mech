from pathlib import Path
import hashlib, json, subprocess, time, xml.etree.ElementTree as ET

r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack')
p=r/'binary-inspection';p.mkdir(exist_ok=True)
reference=Path('/private/tmp/mech-deflate-profiling-20261028/roc-profile')
mech=Path('/private/tmp/mech-action-retirement-round37-20261030/primary/current')

def command(name,cmd):
    at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
    (p/(name+'.stdout')).write_text(q.stdout);(p/(name+'.stderr')).write_text(q.stderr)
    (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at},indent=2)+'\n')
    print(name,q.returncode,flush=True);q.check_returncode();return q.stdout

for label,path in [('reference',reference),('mech-jit-runner',mech),('mech-generated',Path('/private/tmp/mech-retirement-round36-20261030/object/object.o'))]:
    command(label+'-size',['xcrun','size','-m',str(path)])
    command(label+'-symbols',['xcrun','nm','-n',str(path)])

# Inspect the existing original reference; no compressor or platform changes.
cmd=[str(reference),'12'];at=time.monotonic()
with (p/'reference-run.stdout').open('w') as out,(p/'reference-run.stderr').open('w') as err:
    q=subprocess.Popen(cmd,cwd=w,stdout=out,stderr=err)
    time.sleep(.4)
    command('reference-sample',['/usr/bin/sample',str(q.pid),'2','1','-file',str(p/'reference.sample.txt')])
    command('reference-vmmap',['/usr/bin/vmmap','-summary',str(q.pid)])
    code=q.wait()
(p/'reference-run.json').write_text(json.dumps({'command':cmd,'exit':code,'seconds':time.monotonic()-at,'scope':'Fresh diagnostic sample and memory map of original unchanged reference; never primary timing','binary_sha256':hashlib.sha256(reference.read_bytes()).hexdigest()},indent=2)+'\n')
assert code==0
stdout=(p/'reference-run.stdout').read_text();assert stdout.count('rep\troc-deflate\t')==20000

for table in ['CounterMetricByThread','CoreTypeByProcess']:
    command('reference-hardware-'+table,['xcrun','xctrace','export','--input',str(r/'roc-cpu.trace'),'--xpath','/trace-toc/run[@number="1"]/data/table[@schema="'+table+'"]','--output',str(p/('reference-'+table+'.xml'))])

paths=[p,r/'finish-binary-inspection.py',r/'environment.json',r/'tools.json',r/'roc-cpu.json',r/'roc-cpu-toc.xml',r/'roc-cpu.stdout',r/'roc-cpu-recorder.stdout',r/'roc-cpu-recorder.stderr',Path('/private/tmp/mech-action-retirement-round37-20261030/partition-profile.py'),Path('/private/tmp/mech-action-retirement-round37-20261030/partitioned-profile.json')]
# Copy cross-root analysis sources into the diagnostic root for self-contained receipts.
for index in [-2,-1]:
    src=paths[index];dst=r/src.name;dst.write_bytes(src.read_bytes());paths[index]=dst
subprocess.run(['python3',str(r/'archive.py'),'binary-inspection',*map(str,paths)],cwd=w,check=True)
print('INSPECTION COMPLETE',flush=True)
