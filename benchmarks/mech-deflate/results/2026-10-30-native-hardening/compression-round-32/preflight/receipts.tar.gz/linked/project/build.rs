use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, path::PathBuf};

const EXPECTED: &str = "{\"Cargo.toml\":\"56dc9e648a498da815e50ad9be7a34ccd5a3bef08eede042212272dd96d5fdde\",\"application.mec\":\"93e917922fa4057f846d080f8502b280b89ee06ae42ea078e8f4c4147d409431\",\"factory-profile.json\":\"37da5b8455f00f3b6e0e4579be1c9745ee15ffda90f47987de5240baf4cd2538\",\"native-descriptor.bin\":\"1f7b0598c2a422083d45551644838ae22c9bd0dc8b79f802b5cd9ee0d9387221\",\"native-descriptor.json\":\"75875fc87010e29f5110beba6ac01038b5188088f7f9d7ba70a5103ae75583bd\",\"object-identity.bin\":\"fc033d675027f2a2ca18150799792a429dff87b5717eec1eeb2ee4613e171ce4\",\"program.mecb\":\"c2554b843138f4d65d055d01d02d55058e38e8a156dba758264916d1fc82f66f\",\"program.o\":\"e4063104c563cefc7b667a2695f57118032a562adfb361a7f1083e4d4375f1d5\",\"rust-toolchain.toml\":\"19219593d7dba33a75623287af94da940a93fac92eeef99e8fff9b7fd804fcf9\",\"src/main.rs\":\"4547826ea85b29b87d9f43778dc3f6ef14e8a0f682decd8cf1cd4f7f0ed16c36\"}";
fn digest(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}
fn main() {
    assert_eq!(
        std::env::var("HOST").unwrap(),
        std::env::var("TARGET").unwrap(),
        "canonical native object is host-only"
    );
    let root = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let expected: BTreeMap<String, String> = serde_json::from_str(EXPECTED).unwrap();
    let manifest_bytes = fs::read(root.join("linked-manifest.json")).unwrap();
    let manifest: serde_json::Value = serde_json::from_slice(&manifest_bytes).unwrap();
    assert_eq!(manifest["schema"], "mech.canonical-linked-program-application.v1");
    let mut pins: BTreeMap<String, String> =
        serde_json::from_value(manifest["pins"].clone()).unwrap();
    let script = pins.remove("build.rs").expect("build script pin");
    assert_eq!(
        digest(&fs::read(root.join("build.rs")).unwrap()),
        script,
        "build script changed"
    );
    assert_eq!(pins, expected, "manifest generated-input pins changed");
    for (name, hash) in expected {
        assert_eq!(
            digest(&fs::read(root.join(&name)).unwrap()),
            hash,
            "changed generated input {name}"
        );
        println!("cargo:rerun-if-changed={name}");
    }
    println!("cargo:rerun-if-changed=linked-manifest.json");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rustc-link-arg={}", root.join("program.o").display());
}
