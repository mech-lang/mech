from pathlib import Path
import subprocess,json,tarfile,hashlib,datetime
r=Path('/private/tmp/mech-call-cache-round32-20261030');w=Path('/private/tmp/mech-deflate-linear-stack')
for stage,script,folder,patterns in [('scalar',r/'primary/scalar-controls.py',r/'primary',['scalar-*.stdout','scalar-*.stderr','scalar-*.json','frame-before.json']),('frame-allocation',r/'frame-allocation.py',r/'frame-allocation',['*'])]:
 q=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-32'/stage;assert not q.exists()
 p=subprocess.run(['python3',str(script)],cwd=w);q.mkdir();files=sorted({f for pat in patterns for f in folder.glob(pat) if f.is_file()})+[script]
 with tarfile.open(q/'receipts.tar.gz','w:gz') as t:
  for f in files:t.add(f,arcname=str(f.relative_to(r)),recursive=False)
 (q/'manifest.json').write_text(json.dumps({'command':['python3',str(script)],'exit':p.returncode,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':str(f.relative_to(r)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]},indent=2)+'\n')
 subprocess.run(['git','add',str(q)],cwd=w,check=True);subprocess.run(['git','commit','-m','Record protected compact cache '+stage+' controls immediately'],cwd=w,check=True);p.check_returncode()
