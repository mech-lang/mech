from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,tarfile
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');o=r/'profile';o.mkdir();p=r/'primary'
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();blocked={'rustc','cargo','gpu-unit-tests','nested-component-tests','artifact_review','native_frame_transport','before','current','frame-before','frame-after','engine-tests','core-unit-tests'};assert not [x for x in active if Path(x.strip()).name in blocked]
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc');assert hashlib.sha256(artifact.read_bytes()).hexdigest()=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
for label,binary,work in [('after',p/'current',45047079446)]:
 command=[str(binary),str(artifact),'693'];sampled=False;started=time.monotonic();sample_result=None
 with (o/(label+'.stdout')).open('wb') as out,(o/(label+'.stderr')).open('wb') as err:
  process=subprocess.Popen(command,stdout=out,stderr=err)
  try:
   while process.poll() is None:
    if not sampled and 'MEASURING 1\n' in (o/(label+'.stderr')).read_text():
     sampled=True;sample_command=['sample',str(process.pid),'2','-file',str(o/(label+'.sample.txt'))];sample_result=subprocess.run(sample_command,capture_output=True,text=True);(o/(label+'-sampler.log')).write_text(sample_result.stdout+sample_result.stderr)
    if time.monotonic()-started>240:raise TimeoutError('bounded eight-byte profiling process')
    time.sleep(.005)
   code=process.wait()
  finally:
   if process.poll() is None:process.terminate();process.wait(timeout=10)
 rows=[json.loads(l) for l in (o/(label+'.stdout')).read_text().splitlines()]
 receipt={'label':label,'command':command,'exit':code,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'sample_command':sample_command if sampled else None,'sample_exit':sample_result.returncode if sample_result else None,'all_observations_excluded_from_primary':True,'performance_comparison_claimed':False,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(rows)}
 (o/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 q=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-32/profile'/label;q.mkdir(parents=True)
 files=[f for f in o.iterdir() if f.is_file() and f.name.startswith(label)]
 with tarfile.open(q/'receipts.tar.gz','w:gz') as tar:
  for f in sorted(files):tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
 (q/'manifest.json').write_text(json.dumps({'scope':'Diagnostic matched profile only; every process observation excluded from primary and no new elapsed comparison claimed','receipt':receipt,'files':[{'path':str(f.relative_to(r)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(files)]},indent=2)+'\n')
 subprocess.run(['git','add',str(q)],cwd=w,check=True);subprocess.run(['git','commit','-m','Record fresh compact cache profile without primary timing credit'],cwd=w,check=True)
 assert code==0 and sampled and sample_result.returncode==0
 assert len(rows)==695 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==work for x in rows)
 assert (o/(label+'.stderr')).read_text().endswith('CLEANUP bytes=0 nodes=0\n')
 print(label,'PROFILE_COMPLETE',len(rows),'diagnostic observations,all excluded',flush=True)
