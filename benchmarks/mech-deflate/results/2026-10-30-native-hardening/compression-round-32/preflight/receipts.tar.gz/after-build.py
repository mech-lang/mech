from pathlib import Path
import json,subprocess,os,time,hashlib
r=Path('/private/tmp/mech-call-cache-round32-20261030');w=Path('/private/tmp/mech-deflate-linear-stack')
c=json.loads((r/'unit-command.json').read_text());e={**os.environ,'CARGO_MANIFEST_DIR':str(w/'hosts/gpu'),'CARGO_PKG_NAME':'mech-gpu','CARGO_PKG_VERSION':'0.3.5','CARGO_PKG_VERSION_MAJOR':'0','CARGO_PKG_VERSION_MINOR':'3','CARGO_PKG_VERSION_PATCH':'5','CARGO_PKG_DESCRIPTION':'Capability admission and fused WGSL lowering for typed Mech programs'}
for label,cmd in [('unit-build',c),('compact-focused',[str(r/'gpu-unit-tests'),'native_artifact::program::runtime::session::call_cache_tests::','--nocapture','--test-threads=1'])]:
 t=time.monotonic();p=subprocess.run(cmd,cwd=w,env=e,capture_output=True,text=True,timeout=180)
 (r/(label+'.log')).write_text(p.stdout+p.stderr);(r/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'source':'Unmodified maintained GPU unit root; no test body adaptation','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'dirty':subprocess.check_output(['git','status','--short'],cwd=w,text=True)},indent=2)+'\n');print(label,p.returncode,p.stdout[-2500:]+p.stderr[-4000:],flush=True);p.check_returncode()
