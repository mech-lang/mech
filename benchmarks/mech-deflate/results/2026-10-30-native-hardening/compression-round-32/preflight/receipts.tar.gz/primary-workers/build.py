from pathlib import Path
import subprocess,json,hashlib,time
r=Path('/private/tmp/mech-call-cache-round32-20261030');d=r/'primary-workers'
for label,meta in [('before','before-build.json'),('after','current-build.json')]:
 b=json.loads((r/'primary'/meta).read_text());c=b['command'][:];c[-3]=str(d/'session.rs');c[-1]=str(d/label);t=time.monotonic();p=subprocess.run(c,capture_output=True,text=True)
 (d/(label+'-build.log')).write_text(p.stdout+p.stderr);b.update({'command':c,'exit':p.returncode,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256((d/'session.rs').read_bytes()).hexdigest()})
 if p.returncode==0:b['binary_sha256']=hashlib.sha256((d/label).read_bytes()).hexdigest()
 (d/(label+'-build.json')).write_text(json.dumps(b,indent=2)+'\n');print(label,p.returncode,p.stderr[-1500:],flush=True);p.check_returncode()
