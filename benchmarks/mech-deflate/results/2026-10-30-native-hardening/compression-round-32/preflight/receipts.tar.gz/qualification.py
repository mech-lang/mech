from pathlib import Path
import subprocess,json,time,hashlib,shutil
r=Path('/private/tmp/mech-call-cache-round32-20261030');w=Path('/private/tmp/mech-deflate-linear-stack')
def run(label,c):
 t=time.monotonic();p=subprocess.run(c,cwd=w,capture_output=True,text=True)
 (r/(label+'.log')).write_text(p.stdout+p.stderr);(r/(label+'.json')).write_text(json.dumps({'command':c,'exit':p.returncode,'seconds':time.monotonic()-t},indent=2)+'\n')
 print(label,p.returncode,p.stdout[-1600:]+p.stderr[-1600:],flush=True);p.check_returncode()
run('harness-build',['python3',str(r/'primary/build.py')])
p=r/'primary';after=json.loads((p/'current-build.json').read_text());before=json.loads((p/'before-build.json').read_text())
compare={k:{'before':before['libraries'][k]['sha256'],'after':v['sha256'],'equal':before['libraries'][k]['sha256']==v['sha256']} for k,v in after['libraries'].items() if k!='mech_gpu'}
assert len(compare)==7 and all(v['equal'] for v in compare.values());(r/'aligned-libraries.json').write_text(json.dumps(compare,indent=2)+'\n')
d=r/'after-library';d.mkdir();f=d/Path(after['libraries']['mech_gpu']['path']).name;shutil.copy2(after['libraries']['mech_gpu']['path'],f)
for i,a in enumerate(after['command']):
 if a.startswith('mech_gpu='):after['command'][i]='mech_gpu='+str(f)
after['libraries']['mech_gpu']['original_path']=after['libraries']['mech_gpu']['path'];after['libraries']['mech_gpu']['path']=str(f);(p/'current-build.json').write_text(json.dumps(after,indent=2)+'\n')
shutil.copy2('/private/tmp/mech-live-control-target/release/native_frame_transport',p/'frame-after')
(p/'frame-before.json').write_text(json.dumps({'sha256':hashlib.sha256((p/'frame-before').read_bytes()).hexdigest()},indent=2)+'\n')
run('focused-components',['python3',str(r/'components/qualify.py')])
run('full-components',['python3',str(r/'full-components-qualified.py')])
run('selected',['python3',str(p/'qualify-selected.py')])
run('linked',['python3',str(r/'linked/qualify.py')])
source=Path('/private/tmp/mech-final-static-20261028.py').read_text().replace('/private/tmp/mech-assertion-ci-python/bin/python','/private/tmp/mech-profile-ci-python-20261030/bin/python')
(r/'architecture.py').write_text(source)
run('architecture',['python3',str(r/'architecture.py')])
print('QUALIFIED',flush=True)
