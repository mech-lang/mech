//! Checked canonical-artifact native execution.
//!
//! Runtime-only linked applications do not include the source parser, JIT or
//! code generator. JIT and Object emission share one checked definition pass;
//! JIT and linked invocation share one managed typed evaluator.
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/abi.rs"]
mod abi;
#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/application/mod.rs"]
mod application;
#[cfg(feature = "canonical-native-benchmark-policy-runtime")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/benchmark_policy/mod.rs"]
mod benchmark_policy;
#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/compiler/mod.rs"]
mod compiler;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/identity/mod.rs"]
mod identity;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/linked.rs"]
mod linked;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/memory/mod.rs"]
mod memory;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/runtime.rs"]
mod runtime;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/values/mod.rs"]
mod values;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/work/mod.rs"]
mod work;
pub use crate::native_artifact::abi::{
    NATIVE_ARTIFACT_ABI_VERSION, NATIVE_ARTIFACT_ENTRY_SYMBOL, NativeAbiDescriptor,
};
#[cfg(feature = "canonical-native")]
pub use crate::native_artifact::application::{
    GeneratedLinkedApplication, NativeApplicationError, generate_linked_application,
    validate_linked_application_binary_name,
};
#[cfg(feature = "canonical-native-benchmark-policy-runtime")]
pub use crate::native_artifact::benchmark_policy::{
    NativeBenchmarkCapabilityKernel, NativeBenchmarkPolicy,
};
#[cfg(feature = "canonical-native")]
pub use crate::native_artifact::compiler::{
    JitArtifact, NativeCompileError, NativeCompileLimits, NativeObject, emit_object,
    emit_object_with_limits,
};
pub use crate::native_artifact::identity::{
    NATIVE_LINK_IDENTITY_BYTES, NATIVE_TYPED_IR_VERSION, NATIVE_WORK_POLICY_VERSION,
    NativeObjectIdentity,
};
pub use crate::native_artifact::linked::{LinkedArtifact, NativeLinkError};
pub use crate::native_artifact::runtime::{
    NativeExecutionError, NativeExecutionLimits, NativeExecutionPhase, NativeExecutionReport,
};
pub use crate::native_artifact::values::{
    NativeValueArena, NativeValueError, NativeValueHandle, NativeValueSlot,
};
pub use crate::native_artifact::work::NativeWorkMeter;

#[cfg(all(test, feature = "canonical-native"))]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/lexical_integrity_status_tests.rs"]
mod lexical_integrity_status_tests;

#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/control_abi.rs"]
mod control_abi;
#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/control_application.rs"]
mod control_application;
#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/control_compiler.rs"]
mod control_compiler;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/control_identity/mod.rs"]
mod control_identity;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/control_linked.rs"]
mod control_linked;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/control_runtime/mod.rs"]
mod control_runtime;
pub use crate::native_artifact::control_abi::{NativeMatchDescriptor, NativeMatchVisit};
#[cfg(feature = "canonical-native")]
pub use crate::native_artifact::control_compiler::{
    JitMatchArtifact, NativeMatchObject, emit_match_object, emit_match_object_with_limits,
};
pub use crate::native_artifact::control_runtime::{
    NativeMatchExecutionError, NativeMatchExecutionReport,
};

pub use crate::native_artifact::control_identity::{
    NATIVE_MATCH_LINK_IDENTITY_BYTES, NATIVE_MATCH_TYPED_IR_VERSION,
    NATIVE_MATCH_WORK_POLICY_VERSION, NativeMatchObjectIdentity,
};
pub use crate::native_artifact::control_linked::LinkedMatchArtifact;

#[cfg(feature = "canonical-native")]
pub use crate::native_artifact::control_application::generate_linked_match_application;

#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/iteration_abi.rs"]
mod iteration_abi;
#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/iteration_application.rs"]
mod iteration_application;

#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/iteration_compiler.rs"]
mod iteration_compiler;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/iteration_identity/mod.rs"]
mod iteration_identity;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/iteration_linked.rs"]
mod iteration_linked;
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/iteration_runtime/mod.rs"]
mod iteration_runtime;
#[cfg(any(
    feature = "canonical-native",
    feature = "canonical-native-program-runtime"
))]
#[path = "/private/tmp/mech-call-cache-round32-20261030/inventory/program.rs"]
mod program;

#[cfg(feature = "canonical-native-program-runtime")]
pub use crate::native_artifact::program::linked::LinkedProgramArtifact;

pub use crate::native_artifact::iteration_abi::{NativeIterationDescriptor, NativeIterationVisit};
#[cfg(feature = "canonical-native")]
pub use crate::native_artifact::iteration_application::generate_linked_iteration_application;
#[cfg(feature = "canonical-native")]
pub use crate::native_artifact::iteration_compiler::{
    JitIterationArtifact, NativeIterationObject, emit_iteration_object,
    emit_iteration_object_with_limits,
};
pub use crate::native_artifact::iteration_identity::{
    NATIVE_ITERATION_LINK_IDENTITY_BYTES, NATIVE_ITERATION_TYPED_IR_VERSION,
    NATIVE_ITERATION_WORK_POLICY_VERSION, NativeIterationObjectIdentity,
};
pub use crate::native_artifact::iteration_linked::LinkedIterationArtifact;
pub use crate::native_artifact::iteration_runtime::{
    NativeIterationExecutionError, NativeIterationExecutionReport,
};
#[cfg(feature = "canonical-native-benchmark-policy")]
pub use crate::native_artifact::program::application::generate_linked_benchmark_program_application;
#[cfg(feature = "canonical-native-program-host")]
pub use crate::native_artifact::program::application::{
    generate_linked_hosted_program_application,
    generate_linked_hosted_program_application_with_limits,
};
#[cfg(feature = "canonical-native-program")]
pub use crate::native_artifact::program::application::{
    generate_linked_program_application, generate_linked_program_application_with_limits,
};
#[cfg(feature = "canonical-native-program")]
pub use crate::native_artifact::program::compiler::{
    JitProgramArtifact, NativeProgramObject, emit_program_object, emit_program_object_with_limits,
};
#[cfg(feature = "canonical-native-program-runtime")]
pub use crate::native_artifact::program::image::NativeProgramDescriptor;
#[cfg(feature = "canonical-native-program-runtime")]
pub use crate::native_artifact::program::image::identity::{
    NATIVE_PROGRAM_LINK_IDENTITY_BYTES, NATIVE_PROGRAM_TYPED_IR_VERSION,
    NATIVE_PROGRAM_WORK_POLICY_VERSION, NativeProgramObjectIdentity,
};
#[cfg(feature = "canonical-native-program-host-runtime")]
pub use crate::native_artifact::program::runtime::NativeProgramExecutionSession;
#[cfg(feature = "canonical-native-program-runtime")]
pub use crate::native_artifact::program::runtime::{
    NativeProgramExecutionError, NativeProgramExecutionLimits, NativeProgramExecutionReport,
};

#[cfg(feature = "canonical-native-program-runtime")]
pub use crate::native_artifact::program::limits::NativeProgramLimitMode;

#[cfg(feature = "canonical-native")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/codegen/mod.rs"]
mod codegen;

#[cfg(feature = "canonical-native-runtime")]
#[path = "/private/tmp/mech-deflate-linear-stack/hosts/gpu/src/native_artifact/launch/mod.rs"]
pub mod launch;
