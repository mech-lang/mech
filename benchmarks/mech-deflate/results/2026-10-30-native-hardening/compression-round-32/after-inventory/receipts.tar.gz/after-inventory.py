from pathlib import Path
import json,subprocess,os,time,hashlib
r=Path('/private/tmp/mech-call-cache-round32-20261030/after-inventory');w=Path('/private/tmp/mech-deflate-linear-stack');env={**os.environ,'CARGO_MANIFEST_DIR':str(w/'hosts/gpu'),'CARGO_PKG_NAME':'mech-gpu','CARGO_PKG_VERSION':'0.3.5','CARGO_PKG_VERSION_MAJOR':'0','CARGO_PKG_VERSION_MINOR':'3','CARGO_PKG_VERSION_PATCH':'5','CARGO_PKG_DESCRIPTION':'Capability admission and fused WGSL lowering for typed Mech programs'}
for label,c in [('build',json.loads((r/'command.json').read_text())),('run',[str(r/'inventory-tests'),'real_compressor_call_cache_inventory_diagnostic','--nocapture','--test-threads=1'])]:
 t=time.monotonic();p=subprocess.run(c,cwd=w,env=env,capture_output=True,text=True,timeout=300)
 (r/(label+'.log')).write_text(p.stdout+p.stderr);(r/(label+'.json')).write_text(json.dumps({'command':c,'exit':p.returncode,'seconds':time.monotonic()-t,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'scope':'diagnostic, not primary compression measurement'},indent=2)+'\n');print(label,p.returncode,p.stdout[-4500:]+p.stderr[-4500:],flush=True);p.check_returncode()
