"""Rebuild the coherent selected Core-dependent graph with retained release flags."""
from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-borrowed-turn-source-round67-20261031');p=r/'variants/after';dep=p/'dependency'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
commands=json.loads((r/'retained-build-commands.json').read_text())
changed=['mech_core','mech_syntax','mech_bytecode','mech_engine','mech_compute','mech_math','mech_range','mech_logic','mech_compare','mech_stdlib','mech_runtime','mech_gpu']
libs=json.loads((old/'final-libraries.json').read_text());scope=json.loads((r/'source-scope.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
assert hashlib.sha256(subprocess.check_output(['git','diff',scope['baseline_checkpoint'],'--','src','hosts/gpu/src'],cwd=w)).hexdigest()==scope['complete_source_diff_sha256']
assert not p.exists(),'Use a fresh named attempt if a build fails'
dep.mkdir(parents=True)
for pin in libs.values():assert sha(pin['path'])==pin['sha256']
def changing(f):return any(f.name.startswith('lib'+n+'-') or f.name.startswith('lib'+n+'.') for n in changed)
for f in (old/'variants/after/dependency').iterdir():
 if f.is_file() and not changing(f):(dep/f.name).symlink_to(f.resolve())
frozen=[{'path':str(f),'sha256':sha(f),'resolved_path':str(f.resolve()),'bytes':f.stat().st_size} for f in sorted(dep.iterdir())]
(r/'frozen-inputs.json').write_text(json.dumps({'baseline':str(old),'files':frozen},indent=2)+'\n')
def remap(command):
 result=[];i=0
 while i<len(command):
  a=command[i]
  if a=='-L' and command[i+1].startswith('dependency='):i+=2;continue
  if a=='--extern':
   key,path=command[i+1].split('=',1);target=dep/Path(path).name;assert target.exists(),(key,target)
   result.extend([a,key+'='+str(target)]);i+=2;continue
  result.append(a);i+=1
 result[1:1]=['-L','dependency='+str(dep)]
 return result
results=[]
for name in changed:
 original=commands[name];cmd=remap(original['command']);environment=original['environment'].copy();out=p/('build-'+name);out.mkdir()
 source=next(Path(a) for a in cmd if a.endswith('/src/lib.rs'));manifest=source.parent.parent;package=tomllib.loads((manifest/'Cargo.toml').read_text())['package']
 environment.update(CARGO_MANIFEST_DIR=str(manifest),CARGO_PKG_NAME=package['name'],CARGO_PKG_VERSION=package['version'],CARGO_INCREMENTAL='0')
 if '--out-dir' in cmd:cmd[cmd.index('--out-dir')+1]=str(out)
 else:assert name=='mech_gpu' and cmd[-2]=='-o';cmd[-1]=str(p/'libmech_gpu.rlib')
 started=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**environment},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 receipt={'command':cmd,'environment':environment,'exit':q.returncode,'seconds':time.monotonic()-started,'source_head':head,'crate':name,'scope':'Exact retained selected-operation features and release flags. All Core-dependent project crates rebuilt in one isolated graph; external dependencies frozen. No Cargo-wide feature expansion.'}
 (p/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');results.append(receipt)
 subprocess.run(['python3',str(r/'archive.py'),'build-'+name,*map(str,[p/(name+'.json'),p/(name+'.stdout'),p/(name+'.stderr'),r/'build-changed.py',r/'retained-build-commands.json'])],cwd=w,check=True)
 print('BUILD',name,q.returncode,receipt['seconds'],flush=True)
 if q.returncode:print(q.stderr[-7500:],flush=True)
 q.check_returncode()
 for f in out.iterdir():
  if f.suffix in {'.rlib','.rmeta'}:os.link(f,dep/f.name)
 # Math is an explicit rlib/cdylib target, and does not emit a separate rmeta.
 # Its retained command's rlib is the only transitive Rust input.
 for pin in frozen:assert sha(pin['path'])==pin['sha256'],pin['path']
for name,pin in libs.items():
 if name in changed:
  target=p/'libmech_gpu.rlib' if name=='mech_gpu' else dep/Path(pin['path']).name
  assert target.exists(),(name,target);pin.update(path=str(target),sha256=sha(target))
aux={'scope':'Coherent selected Core-dependent graph. All twelve project crates rebuilt; only external artifacts frozen. Identical features and optimized configurations to accepted baseline.','files':[{'path':str(f),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(dep.iterdir()) if f.name.startswith('libmech_') and f.suffix in {'.rlib','.rmeta'}]}
host=results[-1]
implementation={'candidate_build_source':head,'baseline_build_source':json.loads((old/'final-release.json').read_text())['source_head'],'baseline_checkpoint':scope['baseline_checkpoint'],'baseline_directory':str(old),'rebuilt_crates':changed,'scope':'Retain immutable call-port descriptor arrays while preserving descriptor layout/access and creating new arrays after current-shape validation. Account authority, finite limits/work, factory state, ownership and publication remain unchanged. No compressor source or algorithm change.','allocation_expectation':json.loads((r/'allocation-target.json').read_text())}
for target,data in [(p/'libraries.json',libs),(r/'final-libraries.json',libs),(r/'final-release.json',host),(p/'host.json',host),(r/'auxiliary-dependencies.json',aux),(p/'build-summary.json',{'source_head':head,'builds':results}),(r/'implementation.json',implementation)]:target.write_text(json.dumps(data,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-frozen',*map(str,[p/'libraries.json',r/'final-release.json',r/'auxiliary-dependencies.json',r/'frozen-inputs.json',p/'build-summary.json',r/'implementation.json',r/'allocation-target.json',r/'source-scope.json',r/'source.patch',r/'production.patch',r/'build-changed.py'])],cwd=w,check=True)
print('COHERENT_R69_GRAPH',head,flush=True)
