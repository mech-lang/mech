"""Serial coherent release build, focused tests, fresh measurements and qualification."""
from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
for phase in ['before','after']:
 d=json.loads((r/('core-'+phase)/'selected.json').read_text());assert d['exit']==0 and d['executed_tests']==371
negative=json.loads((r/'allocation-before/descriptor.json').read_text());assert negative['exit']==101 and negative['failed_tests']==1
for name,args in [('build-changed.py',[]),('allocation-test.py',['after']),('engine-focused.py',['after']),('units.py',[]),('run-cohorts.py',[]),('qualify-all.py',[])]:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name),*args],check=True);print('DONE',name,flush=True)
