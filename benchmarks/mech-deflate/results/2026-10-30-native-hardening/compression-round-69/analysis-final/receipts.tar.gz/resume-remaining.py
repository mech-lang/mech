"""Resume only not-yet-executed measurements and qualification after exact link retry."""
from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for name,args in [('resume-linked.py',[]),('run-primary.py',[]),('counters.py',[]),('sites.py',['before']),('sites.py',['after']),('profile-isolated.py',[]),('profile-reference.py',[]),('qualify-all.py',[]),('type-architecture.py',[]),('geometry.py',[]),('instruction-windows.py',[]),('host-assembly.py',[])]:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name),*args],check=True);print('DONE',name,flush=True)
