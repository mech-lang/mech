#!/usr/bin/env python3
"""Bounded host-function disassembly. Run only after measurement clearance."""
import argparse, hashlib, json, re, subprocess
from collections import Counter
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('worker', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
needles = ['bound-call-clone', 'current-call-descriptors', 'call-constructor', 'descriptor-clone', 'hot-frame', 'hot-helper', 'hot-visit', 'hot-budget-compute']
nm_command = ['xcrun', 'llvm-nm', '-n', '--defined-only', str(args.worker)]
nm = subprocess.run(nm_command, capture_output=True, text=True)
(args.output / 'nm.stdout').write_text(nm.stdout)
(args.output / 'nm.stderr').write_text(nm.stderr)
if nm.returncode:
    (args.output / 'nm-error.txt').write_text(nm.stderr)
    raise SystemExit(nm.returncode)
symbols = []
for line in nm.stdout.splitlines():
    match = re.match(r'^([0-9a-fA-F]+)\s+([tT])\s+(.+)$', line)
    if match:
        symbols.append((int(match[1], 16), match[3]))
addresses = sorted(set(address for address, _ in symbols))
entries = []
for needle in needles:
    def selected(name):
        if needle == 'hot-frame':
            return '10Invocation19buffer_frame_action' in name
        if needle == 'hot-helper':
            return '10Invocation6helper' in name
        if needle == 'hot-visit':
            return '10Invocation5visit' in name
        if needle == 'hot-budget-compute':
            return 'charge_compute_with_limit' in name or ('ResidentBudgetMeter' in name and 'charge_compute_work' in name)
        if needle == 'bound-call-clone':
            return '9BoundCall' in name and 'Clone5clone' in name and 'Box' not in name
        if needle == 'current-call-descriptors':
            return '9BoundCall' in name and 'with_current_descriptors' in name
        if needle == 'call-constructor':
            return '9BoundCall' in name and any(token in name for token in ['syntax_directed', 'from_resolved_call', 'artifact_operation_for_target'])
        return '23ResolvedValueDescriptor' in name and 'Clone5clone' in name and 'Box' not in name
    matches = [(address, name) for address, name in symbols if selected(name)]
    for ordinal, (address, name) in enumerate(matches):
        later = [value for value in addresses if value > address]
        # Do not accidentally turn missing end-symbol information into an
        # unbounded whole-worker disassembly. Every region is at most 64 KiB.
        end = min(later[0] if later else address + 65536, address + 65536)
        command = ['xcrun', 'llvm-objdump', '-d', '--no-show-raw-insn',
                   f'--start-address={address:#x}', f'--stop-address={end:#x}',
                   str(args.worker)]
        result = subprocess.run(command, capture_output=True, text=True)
        label = f'{needle}-{ordinal}'
        (args.output / f'{label}.asm').write_text(result.stdout)
        (args.output / f'{label}.stderr').write_text(result.stderr)
        opcodes = Counter()
        instructions = []
        for line in result.stdout.splitlines():
            match = re.match(r'^\s*([0-9a-fA-F]+):\s+([a-z][a-z0-9.]*)\s*(.*)$', line)
            if match and address <= int(match[1], 16) < end:
                opcodes[match[2]] += 1
                instructions.append({'address': int(match[1], 16),
                                     'opcode': match[2], 'operands': match[3]})
        entries.append({'needle': needle, 'symbol': name,
                        'start': address, 'stop': end,
                        'command': command, 'exit': result.returncode,
                        'static_instruction_count': len(instructions),
                        'opcodes': dict(sorted(opcodes.items())),
                        'instructions': instructions})
size_command = ['xcrun', 'llvm-size', '-A', str(args.worker)]
size = subprocess.run(size_command, capture_output=True, text=True)
(args.output / 'host-section-sizes.txt').write_text(size.stdout)
(args.output / 'host-section-sizes.stderr').write_text(size.stderr)
result = {'worker': str(args.worker),
          'worker_sha256': hashlib.file_digest(args.worker.open('rb'), 'sha256').hexdigest(),
          'worker_bytes': args.worker.stat().st_size,
          'size_command': size_command, 'size_exit': size.returncode,
          'nm_command': nm_command, 'regions': entries,
          'missing_symbols': [needle for needle in needles
                              if not any(entry['needle'] == needle for entry in entries)],
          'limits': 'Static host functions only. No compressor execution, dynamic count, timing or attribution claim.'}
(args.output / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'regions'}))
for entry in entries:
    print(entry['needle'], hex(entry['start']), entry['static_instruction_count'], entry['exit'])
