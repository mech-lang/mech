
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102cf5e44 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target>:
102cf5e44:     	stp	x28, x27, [sp, #-0x60]!
102cf5e48:     	stp	x26, x25, [sp, #0x10]
102cf5e4c:     	stp	x24, x23, [sp, #0x20]
102cf5e50:     	stp	x22, x21, [sp, #0x30]
102cf5e54:     	stp	x20, x19, [sp, #0x40]
102cf5e58:     	stp	x29, x30, [sp, #0x50]
102cf5e5c:     	add	x29, sp, #0x50
102cf5e60:     	sub	sp, sp, #0x210
102cf5e64:     	mov	x24, x5
102cf5e68:     	mov	x23, x4
102cf5e6c:     	mov	x22, x3
102cf5e70:     	mov	x21, x2
102cf5e74:     	mov	x20, x1
102cf5e78:     	mov	x19, x0
102cf5e7c:     	mov	x25, x8
102cf5e80:     	and	w28, w6, #0xff
102cf5e84:     	sub	w8, w28, #0x1
102cf5e88:     	cmp	w8, #0x2
102cf5e8c:     	b.hs	0x102cf5fdc <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x198>
102cf5e90:     	ldp	x0, x1, [x24, #0x18]
102cf5e94:     	adrp	x2, 0x1076fe000 <_anon.832d17c847cea70163419ed83eb8ed34.259+0x427>
102cf5e98:     	add	x2, x2, #0x732
102cf5e9c:     	add	x8, sp, #0xb0
102cf5ea0:     	mov	w3, #0x1                ; =1
102cf5ea4:     	bl	0x102ddd2e4 <__RINvNtCsgKscDXrlV49_5alloc3str17join_generic_copyehNtNtB4_6string6StringECskIfnrfrMWVM_9mech_core>
102cf5ea8:     	ldr	q0, [sp, #0xb0]
102cf5eac:     	stur	q0, [x29, #-0x80]
102cf5eb0:     	ldr	x8, [sp, #0xc0]
102cf5eb4:     	stur	x8, [x29, #-0x70]
102cf5eb8:     	sub	x8, x29, #0x80
102cf5ebc:     	adrp	x9, 0x102d0d000 <__RNvXsO_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq+0xb4>
102cf5ec0:     	add	x9, x9, #0xd4c
102cf5ec4:     	stp	x8, x9, [sp, #0xb0]
102cf5ec8:     	stp	x24, x9, [sp, #0xc0]
102cf5ecc:     	adrp	x0, 0x10772d000 <_anon.4d16046b51ce2003c3948145f960b58f.3+0x37>
102cf5ed0:     	add	x0, x0, #0xfc4
102cf5ed4:     	add	x8, sp, #0x100
102cf5ed8:     	add	x1, sp, #0xb0
102cf5edc:     	bl	0x102e7ca0c <__RNvNvNtCsgKscDXrlV49_5alloc3fmt6format12format_inner>
102cf5ee0:     	ldur	x1, [x29, #-0x80]
102cf5ee4:     	cbz	x1, 0x102cf5ef4 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0xb0>
102cf5ee8:     	ldur	x0, [x29, #-0x78]
102cf5eec:     	mov	w2, #0x1                ; =1
102cf5ef0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5ef4:     	ldr	q0, [sp, #0x100]
102cf5ef8:     	str	q0, [sp, #0xe0]
102cf5efc:     	ldr	x8, [sp, #0x110]
102cf5f00:     	str	x8, [sp, #0xf0]
102cf5f04:     	ldr	x2, [x19, #0x38]
102cf5f08:     	cmp	x8, x2
102cf5f0c:     	b.ne	0x102cf5f20 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0xdc>
102cf5f10:     	ldr	x0, [sp, #0xe8]
102cf5f14:     	ldr	x1, [x19, #0x30]
102cf5f18:     	bl	0x103a03e4c <dyld_stub_binder+0x103a03e4c>
102cf5f1c:     	cbz	w0, 0x102cf6154 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x310>
102cf5f20:     	ldr	x27, [x19, #0x40]
102cf5f24:     	add	x8, sp, #0xe0
102cf5f28:     	adrp	x9, 0x102d0d000 <__RNvXsO_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq+0xb4>
102cf5f2c:     	add	x9, x9, #0xd5c
102cf5f30:     	stp	x8, x9, [sp, #0xb0]
102cf5f34:     	adrp	x0, 0x10772d000 <_anon.4d16046b51ce2003c3948145f960b58f.3+0x37>
102cf5f38:     	add	x0, x0, #0xfc9
102cf5f3c:     	sub	x8, x29, #0x98
102cf5f40:     	add	x1, sp, #0xb0
102cf5f44:     	bl	0x102e7ca0c <__RNvNvNtCsgKscDXrlV49_5alloc3fmt6format12format_inner>
102cf5f48:     	add	x26, sp, #0x118
102cf5f4c:     	mov	w8, #0x1                ; =1
102cf5f50:     	stp	x8, x27, [sp, #0xb0]
102cf5f54:     	ldr	q0, [x26, #0xb0]
102cf5f58:     	str	q0, [sp, #0xc0]
102cf5f5c:     	ldur	x8, [x29, #-0x88]
102cf5f60:     	str	x8, [sp, #0xd0]
102cf5f64:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
102cf5f68:     	stur	x8, [x29, #-0x80]
102cf5f6c:     	add	x8, sp, #0x118
102cf5f70:     	add	x0, sp, #0xb0
102cf5f74:     	sub	x1, x29, #0x80
102cf5f78:     	bl	0x102cefc04 <__RINvMs2_NtCskIfnrfrMWVM_9mech_core5errorNtB6_9MechError3newNtNtNtB8_8function7catalog31RuntimeOperationBindingMismatchEB8_>
102cf5f7c:     	adrp	x8, 0x10772d000 <_anon.4d16046b51ce2003c3948145f960b58f.3+0x37>
102cf5f80:     	add	x8, x8, #0xef6
102cf5f84:     	mov	w9, #0x4e               ; =78
102cf5f88:     	stp	x8, x9, [sp, #0x1a8]
102cf5f8c:     	mov	w8, #0x324              ; =804
102cf5f90:     	str	w8, [sp, #0x1b8]
102cf5f94:     	ldp	q0, q1, [x26, #0x40]
102cf5f98:     	stp	q0, q1, [x25, #0x40]
102cf5f9c:     	ldp	q1, q0, [x26, #0x60]
102cf5fa0:     	stp	q1, q0, [x25, #0x60]
102cf5fa4:     	ldp	q0, q1, [x26]
102cf5fa8:     	stp	q0, q1, [x25]
102cf5fac:     	ldp	q1, q0, [x26, #0x20]
102cf5fb0:     	stp	q1, q0, [x25, #0x20]
102cf5fb4:     	ldp	q1, q0, [x26, #0x90]
102cf5fb8:     	stp	q1, q0, [x25, #0x90]
102cf5fbc:     	ldr	q0, [x26, #0x80]
102cf5fc0:     	str	q0, [x25, #0x80]
102cf5fc4:     	ldr	x1, [sp, #0xe0]
102cf5fc8:     	cbz	x1, 0x102cf6044 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x200>
102cf5fcc:     	ldr	x0, [sp, #0xe8]
102cf5fd0:     	mov	w2, #0x1                ; =1
102cf5fd4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5fd8:     	b	0x102cf6044 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x200>
102cf5fdc:     	mov	w8, #0x1                ; =1
102cf5fe0:     	strb	w8, [sp, #0xb0]
102cf5fe4:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
102cf5fe8:     	stur	x8, [x29, #-0x80]
102cf5fec:     	mov	x8, sp
102cf5ff0:     	add	x0, sp, #0xb0
102cf5ff4:     	sub	x1, x29, #0x80
102cf5ff8:     	bl	0x102cef0cc <__RINvMs2_NtCskIfnrfrMWVM_9mech_core5errorNtB6_9MechError3newNtNtNtB8_11memory_plan5error15MemoryPlanErrorEB8_>
102cf5ffc:     	adrp	x8, 0x10772d000 <_anon.4d16046b51ce2003c3948145f960b58f.3+0x37>
102cf6000:     	add	x8, x8, #0xef6
102cf6004:     	mov	w9, #0x4e               ; =78
102cf6008:     	stp	x8, x9, [sp, #0x90]
102cf600c:     	mov	w8, #0x312              ; =786
102cf6010:     	str	w8, [sp, #0xa0]
102cf6014:     	ldp	q0, q1, [sp, #0x40]
102cf6018:     	stp	q0, q1, [x25, #0x40]
102cf601c:     	ldp	q1, q0, [sp, #0x60]
102cf6020:     	stp	q1, q0, [x25, #0x60]
102cf6024:     	ldp	q0, q1, [sp]
102cf6028:     	stp	q0, q1, [x25]
102cf602c:     	ldp	q1, q0, [sp, #0x20]
102cf6030:     	stp	q1, q0, [x25, #0x20]
102cf6034:     	ldp	q1, q0, [sp, #0x90]
102cf6038:     	stp	q1, q0, [x25, #0x90]
102cf603c:     	ldr	q0, [sp, #0x80]
102cf6040:     	str	q0, [x25, #0x80]
102cf6044:     	ldr	x26, [x24, #0x20]
102cf6048:     	cbz	x26, 0x102cf6094 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x250>
102cf604c:     	ldr	x25, [x24, #0x18]
102cf6050:     	add	x27, x25, #0x8
102cf6054:     	mov	x28, x26
102cf6058:     	b	0x102cf6068 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x224>
102cf605c:     	add	x27, x27, #0x18
102cf6060:     	subs	x28, x28, #0x1
102cf6064:     	b.eq	0x102cf6080 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x23c>
102cf6068:     	ldur	x1, [x27, #-0x8]
102cf606c:     	cbz	x1, 0x102cf605c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x218>
102cf6070:     	ldr	x0, [x27]
102cf6074:     	mov	w2, #0x1                ; =1
102cf6078:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf607c:     	b	0x102cf605c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x218>
102cf6080:     	add	x8, x26, x26, lsl #1
102cf6084:     	lsl	x1, x8, #3
102cf6088:     	mov	x0, x25
102cf608c:     	mov	w2, #0x8                ; =8
102cf6090:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf6094:     	ldr	x1, [x24]
102cf6098:     	cbz	x1, 0x102cf60a8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x264>
102cf609c:     	ldr	x0, [x24, #0x8]
102cf60a0:     	mov	w2, #0x1                ; =1
102cf60a4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf60a8:     	add	x26, x23, #0x1
102cf60ac:     	mov	x0, x22
102cf60b0:     	subs	x26, x26, #0x1
102cf60b4:     	b.eq	0x102cf60c8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x284>
102cf60b8:     	add	x24, x0, #0xb0
102cf60bc:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf60c0:     	mov	x0, x24
102cf60c4:     	b	0x102cf60b0 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x26c>
102cf60c8:     	cbz	x23, 0x102cf60e0 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x29c>
102cf60cc:     	mov	w8, #0xb0               ; =176
102cf60d0:     	mul	x1, x23, x8
102cf60d4:     	mov	x0, x22
102cf60d8:     	mov	w2, #0x10               ; =16
102cf60dc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf60e0:     	add	x23, x21, #0x1
102cf60e4:     	mov	x0, x20
102cf60e8:     	subs	x23, x23, #0x1
102cf60ec:     	b.eq	0x102cf6100 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x2bc>
102cf60f0:     	add	x22, x0, #0xb0
102cf60f4:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf60f8:     	mov	x0, x22
102cf60fc:     	b	0x102cf60e8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x2a4>
102cf6100:     	cbz	x21, 0x102cf6118 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x2d4>
102cf6104:     	mov	w8, #0xb0               ; =176
102cf6108:     	mul	x1, x21, x8
102cf610c:     	mov	x0, x20
102cf6110:     	mov	w2, #0x10               ; =16
102cf6114:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf6118:     	ldr	x1, [x19, #0x38]
102cf611c:     	cbz	x1, 0x102cf612c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x2e8>
102cf6120:     	ldr	x0, [x19, #0x30]
102cf6124:     	mov	w2, #0x1                ; =1
102cf6128:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf612c:     	mov	x0, x19
102cf6130:     	bl	0x102cf4bdc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration28OperationContractDeclarationEBM_>
102cf6134:     	add	sp, sp, #0x210
102cf6138:     	ldp	x29, x30, [sp, #0x50]
102cf613c:     	ldp	x20, x19, [sp, #0x40]
102cf6140:     	ldp	x22, x21, [sp, #0x30]
102cf6144:     	ldp	x24, x23, [sp, #0x20]
102cf6148:     	ldp	x26, x25, [sp, #0x10]
102cf614c:     	ldp	x28, x27, [sp], #0x60
102cf6150:     	ret
102cf6154:     	mov	x0, x20
102cf6158:     	mov	x1, x21
102cf615c:     	bl	0x102d664f0 <__RNvMsp_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE11from_box_inBN_>
102cf6160:     	mov	x26, x0
102cf6164:     	mov	x27, x1
102cf6168:     	stp	x0, x1, [sp, #0xb0]
102cf616c:     	mov	x0, x22
102cf6170:     	mov	x1, x23
102cf6174:     	bl	0x102d664f0 <__RNvMsp_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE11from_box_inBN_>
102cf6178:     	ldp	q0, q1, [x24]
102cf617c:     	stur	q0, [x25, #0x8]
102cf6180:     	stur	q1, [x25, #0x18]
102cf6184:     	ldp	q1, q0, [x19]
102cf6188:     	stur	q0, [x25, #0x48]
102cf618c:     	ldp	q0, q2, [x19, #0x20]
102cf6190:     	stur	q0, [x25, #0x58]
102cf6194:     	stur	q2, [x25, #0x68]
102cf6198:     	ldr	x8, [x24, #0x20]
102cf619c:     	str	x8, [x25, #0x28]
102cf61a0:     	mov	w8, #0x1                ; =1
102cf61a4:     	str	w8, [x25, #0x30]
102cf61a8:     	ldr	x8, [x19, #0x40]
102cf61ac:     	stur	q1, [x25, #0x38]
102cf61b0:     	stp	x8, x26, [x25, #0x78]
102cf61b4:     	stp	x27, x0, [x25, #0x88]
102cf61b8:     	str	x1, [x25, #0x98]
102cf61bc:     	strb	w28, [x25, #0xa0]
102cf61c0:     	mov	w8, #0x2                ; =2
102cf61c4:     	str	x8, [x25]
102cf61c8:     	ldr	x1, [sp, #0xe0]
102cf61cc:     	cbz	x1, 0x102cf6134 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x2f0>
102cf61d0:     	ldr	x0, [sp, #0xe8]
102cf61d4:     	mov	w2, #0x1                ; =1
102cf61d8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf61dc:     	b	0x102cf6134 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x2f0>
102cf61e0:     	mov	x25, x0
102cf61e4:     	mov	x8, #-0x1               ; =-1
102cf61e8:     	ldaddl	x8, x8, [x26]
102cf61ec:     	cmp	x8, #0x1
102cf61f0:     	b.ne	0x102cf6200 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x3bc>
102cf61f4:     	dmb	ishld
102cf61f8:     	add	x0, sp, #0xb0
102cf61fc:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
102cf6200:     	mov	w27, #0x0               ; =0
102cf6204:     	b	0x102cf6210 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x3cc>
102cf6208:     	mov	x25, x0
102cf620c:     	mov	w27, #0x1               ; =1
102cf6210:     	mov	x0, x19
102cf6214:     	bl	0x102cf4dfc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102cf6218:     	mov	w26, #0x0               ; =0
102cf621c:     	b	0x102cf6248 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x404>
102cf6220:     	mov	x25, x0
102cf6224:     	ldur	x1, [x29, #-0x80]
102cf6228:     	cbz	x1, 0x102cf6280 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x43c>
102cf622c:     	ldur	x0, [x29, #-0x78]
102cf6230:     	mov	w2, #0x1                ; =1
102cf6234:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf6238:     	b	0x102cf6280 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x43c>
102cf623c:     	mov	x25, x0
102cf6240:     	mov	w27, #0x1               ; =1
102cf6244:     	mov	w26, #0x1               ; =1
102cf6248:     	ldr	x1, [sp, #0xe0]
102cf624c:     	cbnz	x1, 0x102cf6260 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x41c>
102cf6250:     	mov	x0, x24
102cf6254:     	bl	0x102cf5554 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function8resident20ResidentOperationKeyEBM_>
102cf6258:     	cbnz	w27, 0x102cf628c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x448>
102cf625c:     	b	0x102cf6298 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x454>
102cf6260:     	ldr	x0, [sp, #0xe8]
102cf6264:     	mov	w2, #0x1                ; =1
102cf6268:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf626c:     	mov	x0, x24
102cf6270:     	bl	0x102cf5554 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function8resident20ResidentOperationKeyEBM_>
102cf6274:     	tbnz	w27, #0x0, 0x102cf628c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x448>
102cf6278:     	b	0x102cf6298 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x454>
102cf627c:     	mov	x25, x0
102cf6280:     	mov	x0, x24
102cf6284:     	bl	0x102cf5554 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function8resident20ResidentOperationKeyEBM_>
102cf6288:     	mov	w26, #0x1               ; =1
102cf628c:     	mov	x0, x22
102cf6290:     	mov	x1, x23
102cf6294:     	bl	0x102cf246c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102cf6298:     	tbnz	w26, #0x0, 0x102cf6320 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x4dc>
102cf629c:     	mov	x0, x25
102cf62a0:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102cf62a4:     	mov	x25, x0
102cf62a8:     	subs	x23, x23, #0x1
102cf62ac:     	b.eq	0x102cf62c4 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x480>
102cf62b0:     	add	x24, x22, #0xb0
102cf62b4:     	mov	x0, x22
102cf62b8:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf62bc:     	mov	x22, x24
102cf62c0:     	b	0x102cf62a8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x464>
102cf62c4:     	mov	w8, #0xb0               ; =176
102cf62c8:     	mul	x1, x21, x8
102cf62cc:     	mov	x0, x20
102cf62d0:     	mov	w2, #0x10               ; =16
102cf62d4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf62d8:     	mov	x0, x19
102cf62dc:     	bl	0x102cf4dfc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102cf62e0:     	mov	x0, x25
102cf62e4:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102cf62e8:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102cf62ec:     	mov	x25, x0
102cf62f0:     	subs	x26, x26, #0x1
102cf62f4:     	b.eq	0x102cf630c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x4c8>
102cf62f8:     	add	x27, x24, #0xb0
102cf62fc:     	mov	x0, x24
102cf6300:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf6304:     	mov	x24, x27
102cf6308:     	b	0x102cf62f0 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall29artifact_operation_for_target+0x4ac>
102cf630c:     	mov	w8, #0xb0               ; =176
102cf6310:     	mul	x1, x23, x8
102cf6314:     	mov	x0, x22
102cf6318:     	mov	w2, #0x10               ; =16
102cf631c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf6320:     	mov	x0, x20
102cf6324:     	mov	x1, x21
102cf6328:     	bl	0x102cf246c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102cf632c:     	mov	x0, x19
102cf6330:     	bl	0x102cf4dfc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102cf6334:     	mov	x0, x25
102cf6338:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102cf633c:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102cf6340:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
