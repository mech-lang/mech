
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023ab3fc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
1023ab3fc:     	sub	sp, sp, #0x130
1023ab400:     	stp	d9, d8, [sp, #0xc0]
1023ab404:     	stp	x28, x27, [sp, #0xd0]
1023ab408:     	stp	x26, x25, [sp, #0xe0]
1023ab40c:     	stp	x24, x23, [sp, #0xf0]
1023ab410:     	stp	x22, x21, [sp, #0x100]
1023ab414:     	stp	x20, x19, [sp, #0x110]
1023ab418:     	stp	x29, x30, [sp, #0x120]
1023ab41c:     	add	x29, sp, #0x120
1023ab420:     	mov	x20, x1
1023ab424:     	mov	x19, x0
1023ab428:     	ldr	x28, [x1, #0x70]
1023ab42c:     	add	x0, x1, #0x60
1023ab430:     	bl	0x102e7d178 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1023ab434:     	str	x0, [sp, #0x10]
1023ab438:     	mov	x21, x1
1023ab43c:     	ldr	x27, [x20, #0x40]
1023ab440:     	lsl	x24, x27, #1
1023ab444:     	orr	x8, x24, x27
1023ab448:     	tbz	x8, #0x3f, 0x1023ab460 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x64>
1023ab44c:     	mov	x26, #0x0               ; =0
1023ab450:     	mov	x0, x26
1023ab454:     	mov	x1, x24
1023ab458:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1023ab45c:     	b	0x1023ab624 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x228>
1023ab460:     	ldrb	w22, [x20, #0x30]
1023ab464:     	cbz	x24, 0x1023ab4b8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbc>
1023ab468:     	ldr	x25, [x20, #0x38]
1023ab46c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1023ab470:     	mov	w26, #0x1               ; =1
1023ab474:     	mov	x0, x24
1023ab478:     	mov	w1, #0x1                ; =1
1023ab47c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1023ab480:     	cbz	x0, 0x1023ab450 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x54>
1023ab484:     	mov	x23, x0
1023ab488:     	cbz	x27, 0x1023ab49c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa0>
1023ab48c:     	mov	x0, x23
1023ab490:     	mov	x1, x25
1023ab494:     	mov	x2, x24
1023ab498:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
1023ab49c:     	cbz	w22, 0x1023ab4c0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc4>
1023ab4a0:     	ldrb	w8, [x20, #0x31]
1023ab4a4:     	str	w8, [sp, #0xc]
1023ab4a8:     	ldrb	w22, [x20, #0x32]
1023ab4ac:     	mov	w25, #0x1               ; =1
1023ab4b0:     	ldr	w26, [x20, #0x34]
1023ab4b4:     	b	0x1023ab4c4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc8>
1023ab4b8:     	mov	w23, #0x1               ; =1
1023ab4bc:     	cbnz	w22, 0x1023ab4a0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa4>
1023ab4c0:     	mov	w25, #0x0               ; =0
1023ab4c4:     	add	x0, x20, #0x48
1023ab4c8:     	bl	0x102aaa400 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023ab4cc:     	ldrb	w8, [x20, #0x58]
1023ab4d0:     	sub	w9, w8, #0x3
1023ab4d4:     	mov	w10, #0x2               ; =2
1023ab4d8:     	cmp	w8, #0x2
1023ab4dc:     	csel	w9, w9, w10, hi
1023ab4e0:     	and	w9, w9, #0xff
1023ab4e4:     	cmp	w9, #0x1
1023ab4e8:     	b.gt	0x1023ab4f8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
1023ab4ec:     	cbnz	w9, 0x1023ab504 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
1023ab4f0:     	mov	w8, #0x3                ; =3
1023ab4f4:     	b	0x1023ab508 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
1023ab4f8:     	cmp	w9, #0x2
1023ab4fc:     	ldrb	w9, [x20, #0x59]
1023ab500:     	b	0x1023ab508 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
1023ab504:     	mov	w8, #0x4                ; =4
1023ab508:     	stp	x21, x28, [sp, #0x50]
1023ab50c:     	ldr	x10, [sp, #0x10]
1023ab510:     	str	x10, [sp, #0x48]
1023ab514:     	strb	w25, [sp, #0x18]
1023ab518:     	ldr	w10, [sp, #0xc]
1023ab51c:     	strb	w10, [sp, #0x19]
1023ab520:     	strb	w22, [sp, #0x1a]
1023ab524:     	str	w26, [sp, #0x1c]
1023ab528:     	stp	x23, x27, [sp, #0x20]
1023ab52c:     	stp	x0, x1, [sp, #0x30]
1023ab530:     	strb	w8, [sp, #0x40]
1023ab534:     	strb	w9, [sp, #0x41]
1023ab538:     	ldr	d8, [x20, #0x28]
1023ab53c:     	mov	w8, #0x1                ; =1
1023ab540:     	ldp	x24, x25, [x20, #0x78]
1023ab544:     	ldadd	x8, x8, [x24]
1023ab548:     	tbnz	x8, #0x3f, 0x1023ab624 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x228>
1023ab54c:     	stp	x24, x25, [sp, #0x60]
1023ab550:     	ldp	x23, x26, [x20, #0x88]
1023ab554:     	mov	w8, #0x1                ; =1
1023ab558:     	ldadd	x8, x8, [x23]
1023ab55c:     	tbnz	x8, #0x3f, 0x1023ab624 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x228>
1023ab560:     	stp	x23, x26, [sp, #0x70]
1023ab564:     	mov	x0, x20
1023ab568:     	ldr	x8, [x0], #0x18
1023ab56c:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1023ab570:     	cmp	x8, x9
1023ab574:     	b.ne	0x1023ab590 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
1023ab578:     	ldr	q0, [x20]
1023ab57c:     	str	q0, [sp, #0x80]
1023ab580:     	ldp	x8, x21, [x20, #0x10]
1023ab584:     	str	x8, [sp, #0x90]
1023ab588:     	ldr	x22, [x20, #0x20]
1023ab58c:     	b	0x1023ab5b8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1bc>
1023ab590:     	bl	0x102aa4878 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1023ab594:     	mov	x21, x0
1023ab598:     	mov	x22, x1
1023ab59c:     	sub	x8, x29, #0x80
1023ab5a0:     	mov	x0, x20
1023ab5a4:     	bl	0x102e7ccf4 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1023ab5a8:     	ldur	q0, [x29, #-0x80]
1023ab5ac:     	str	q0, [sp, #0x80]
1023ab5b0:     	ldur	x8, [x29, #-0x70]
1023ab5b4:     	str	x8, [sp, #0x90]
1023ab5b8:     	ldrb	w8, [x20, #0x98]
1023ab5bc:     	ldur	q0, [sp, #0x38]
1023ab5c0:     	ldur	q1, [sp, #0x48]
1023ab5c4:     	stp	q0, q1, [x19, #0x50]
1023ab5c8:     	ldr	x9, [sp, #0x58]
1023ab5cc:     	ldur	q0, [sp, #0x28]
1023ab5d0:     	ldur	q1, [sp, #0x18]
1023ab5d4:     	stp	q1, q0, [x19, #0x30]
1023ab5d8:     	str	d8, [x19, #0x28]
1023ab5dc:     	stp	x9, x24, [x19, #0x70]
1023ab5e0:     	stp	x25, x23, [x19, #0x80]
1023ab5e4:     	str	x26, [x19, #0x90]
1023ab5e8:     	ldr	q0, [sp, #0x80]
1023ab5ec:     	ldr	x9, [sp, #0x90]
1023ab5f0:     	str	q0, [x19]
1023ab5f4:     	stp	x9, x21, [x19, #0x10]
1023ab5f8:     	str	x22, [x19, #0x20]
1023ab5fc:     	strb	w8, [x19, #0x98]
1023ab600:     	ldp	x29, x30, [sp, #0x120]
1023ab604:     	ldp	x20, x19, [sp, #0x110]
1023ab608:     	ldp	x22, x21, [sp, #0x100]
1023ab60c:     	ldp	x24, x23, [sp, #0xf0]
1023ab610:     	ldp	x26, x25, [sp, #0xe0]
1023ab614:     	ldp	x28, x27, [sp, #0xd0]
1023ab618:     	ldp	d9, d8, [sp, #0xc0]
1023ab61c:     	add	sp, sp, #0x130
1023ab620:     	ret
1023ab624:     	brk	#0x1
1023ab628:     	mov	x19, x0
1023ab62c:     	mov	x0, x21
1023ab630:     	mov	x1, x22
1023ab634:     	bl	0x1023419a0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECs1qJAwyMG1lC_11mech_engine>
1023ab638:     	b	0x1023ab640 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x244>
1023ab63c:     	mov	x19, x0
1023ab640:     	mov	x20, #-0x1              ; =-1
1023ab644:     	ldaddl	x20, x8, [x23]
1023ab648:     	cmp	x8, #0x1
1023ab64c:     	b.ne	0x1023ab65c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x260>
1023ab650:     	dmb	ishld
1023ab654:     	add	x0, sp, #0x70
1023ab658:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
1023ab65c:     	ldr	x8, [sp, #0x60]
1023ab660:     	ldaddl	x20, x8, [x8]
1023ab664:     	cmp	x8, #0x1
1023ab668:     	b.ne	0x1023ab678 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x27c>
1023ab66c:     	dmb	ishld
1023ab670:     	add	x0, sp, #0x60
1023ab674:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
1023ab678:     	add	x0, sp, #0x18
1023ab67c:     	bl	0x102345798 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorECs1qJAwyMG1lC_11mech_engine>
1023ab680:     	b	0x1023ab6c8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2cc>
1023ab684:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1023ab688:     	mov	x19, x0
1023ab68c:     	cbnz	x27, 0x1023ab698 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x29c>
1023ab690:     	mov	x0, x19
1023ab694:     	b	0x1023ab6b0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
1023ab698:     	mov	x0, x23
1023ab69c:     	mov	x1, x24
1023ab6a0:     	mov	w2, #0x1                ; =1
1023ab6a4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023ab6a8:     	mov	x0, x19
1023ab6ac:     	b	0x1023ab6b0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
1023ab6b0:     	cbz	x21, 0x1023ab6cc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2d0>
1023ab6b4:     	mov	x19, x0
1023ab6b8:     	ldr	x0, [sp, #0x10]
1023ab6bc:     	mov	x1, x21
1023ab6c0:     	mov	w2, #0x1                ; =1
1023ab6c4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1023ab6c8:     	mov	x0, x19
1023ab6cc:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
