
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a9cae8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102a9cae8:     	sub	sp, sp, #0x130
102a9caec:     	stp	x28, x27, [sp, #0xe0]
102a9caf0:     	stp	x24, x23, [sp, #0xf0]
102a9caf4:     	stp	x22, x21, [sp, #0x100]
102a9caf8:     	stp	x20, x19, [sp, #0x110]
102a9cafc:     	stp	x29, x30, [sp, #0x120]
102a9cb00:     	add	x29, sp, #0x120
102a9cb04:     	mov	x20, x1
102a9cb08:     	mov	x19, x0
102a9cb0c:     	add	x0, x1, #0x30
102a9cb10:     	bl	0x102aa51cc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a9cb14:     	mov	x21, x0
102a9cb18:     	mov	x22, x1
102a9cb1c:     	stp	x0, x1, [x29, #-0x80]
102a9cb20:     	add	x0, sp, #0x50
102a9cb24:     	mov	x1, x20
102a9cb28:     	bl	0x102a959a0 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102a9cb2c:     	add	x0, x20, #0x40
102a9cb30:     	bl	0x102aaa274 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a9cb34:     	stp	x21, x22, [sp, #0x30]
102a9cb38:     	ldp	q0, q1, [sp, #0x50]
102a9cb3c:     	stp	q0, q1, [sp]
102a9cb40:     	ldr	q0, [sp, #0x70]
102a9cb44:     	str	q0, [sp, #0x20]
102a9cb48:     	stp	x0, x1, [sp, #0x40]
102a9cb4c:     	add	x0, x20, #0x90
102a9cb50:     	bl	0x102aa503c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a9cb54:     	mov	x23, x0
102a9cb58:     	mov	x21, x1
102a9cb5c:     	sub	x0, x29, #0x80
102a9cb60:     	add	x1, x20, #0x50
102a9cb64:     	bl	0x102aabe64 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102a9cb68:     	mov	x22, #0x0               ; =0
102a9cb6c:     	stp	x23, x21, [sp, #0x90]
102a9cb70:     	ldp	q0, q1, [x29, #-0x80]
102a9cb74:     	stp	q0, q1, [sp, #0x50]
102a9cb78:     	ldp	q0, q1, [x29, #-0x60]
102a9cb7c:     	ldr	x24, [x20, #0xa8]
102a9cb80:     	lsl	x21, x24, #3
102a9cb84:     	lsr	x8, x24, #61
102a9cb88:     	stp	q0, q1, [sp, #0x70]
102a9cb8c:     	cbnz	x8, 0x102a9cbd8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xf0>
102a9cb90:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102a9cb94:     	cmp	x21, x8
102a9cb98:     	b.hi	0x102a9cbd8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xf0>
102a9cb9c:     	cbz	x21, 0x102a9cbe8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x100>
102a9cba0:     	ldr	x23, [x20, #0xa0]
102a9cba4:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a9cba8:     	mov	w22, #0x8               ; =8
102a9cbac:     	mov	x0, x21
102a9cbb0:     	mov	w1, #0x8                ; =8
102a9cbb4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a9cbb8:     	cbz	x0, 0x102a9cbd8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xf0>
102a9cbbc:     	mov	x20, x0
102a9cbc0:     	cbz	x24, 0x102a9cbec <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102a9cbc4:     	mov	x0, x20
102a9cbc8:     	mov	x1, x23
102a9cbcc:     	mov	x2, x21
102a9cbd0:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
102a9cbd4:     	b	0x102a9cbec <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102a9cbd8:     	mov	x0, x22
102a9cbdc:     	mov	x1, x21
102a9cbe0:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a9cbe4:     	brk	#0x1
102a9cbe8:     	mov	w20, #0x8               ; =8
102a9cbec:     	ldp	q0, q1, [sp, #0x20]
102a9cbf0:     	stp	q0, q1, [x19, #0x20]
102a9cbf4:     	ldp	q1, q0, [sp]
102a9cbf8:     	stp	q1, q0, [x19]
102a9cbfc:     	ldp	q0, q1, [sp, #0x70]
102a9cc00:     	ldp	q3, q2, [sp, #0x50]
102a9cc04:     	stp	q2, q0, [x19, #0x60]
102a9cc08:     	ldr	q0, [sp, #0x90]
102a9cc0c:     	stp	q1, q0, [x19, #0x80]
102a9cc10:     	ldr	q0, [sp, #0x40]
102a9cc14:     	stp	q0, q3, [x19, #0x40]
102a9cc18:     	stp	x20, x24, [x19, #0xa0]
102a9cc1c:     	ldp	x29, x30, [sp, #0x120]
102a9cc20:     	ldp	x20, x19, [sp, #0x110]
102a9cc24:     	ldp	x22, x21, [sp, #0x100]
102a9cc28:     	ldp	x24, x23, [sp, #0xf0]
102a9cc2c:     	ldp	x28, x27, [sp, #0xe0]
102a9cc30:     	add	sp, sp, #0x130
102a9cc34:     	ret
102a9cc38:     	mov	x19, x0
102a9cc3c:     	mov	x0, x23
102a9cc40:     	mov	x1, x21
102a9cc44:     	bl	0x102a42d20 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEECs1qJAwyMG1lC_11mech_engine>
102a9cc48:     	b	0x102a9cc88 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
102a9cc4c:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102a9cc50:     	mov	x19, x0
102a9cc54:     	b	0x102a9cc88 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
102a9cc58:     	mov	x19, x0
102a9cc5c:     	add	x0, sp, #0x50
102a9cc60:     	bl	0x102a4621c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprECs1qJAwyMG1lC_11mech_engine>
102a9cc64:     	b	0x102a9cc6c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x184>
102a9cc68:     	mov	x19, x0
102a9cc6c:     	sub	x0, x29, #0x80
102a9cc70:     	bl	0x102a42e10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEECs1qJAwyMG1lC_11mech_engine>
102a9cc74:     	b	0x102a9cc90 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a8>
102a9cc78:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102a9cc7c:     	mov	x19, x0
102a9cc80:     	add	x0, sp, #0x50
102a9cc84:     	bl	0x102a45f48 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaECs1qJAwyMG1lC_11mech_engine>
102a9cc88:     	mov	x0, sp
102a9cc8c:     	bl	0x102a48f10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeECs1qJAwyMG1lC_11mech_engine>
102a9cc90:     	mov	x0, x19
102a9cc94:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102a9cc98:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
