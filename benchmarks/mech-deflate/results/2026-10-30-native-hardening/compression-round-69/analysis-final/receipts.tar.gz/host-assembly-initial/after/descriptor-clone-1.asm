
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d0b2a0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d0b2a0:     	sub	sp, sp, #0x140
102d0b2a4:     	stp	x28, x27, [sp, #0xf0]
102d0b2a8:     	stp	x24, x23, [sp, #0x100]
102d0b2ac:     	stp	x22, x21, [sp, #0x110]
102d0b2b0:     	stp	x20, x19, [sp, #0x120]
102d0b2b4:     	stp	x29, x30, [sp, #0x130]
102d0b2b8:     	add	x29, sp, #0x130
102d0b2bc:     	mov	x20, x1
102d0b2c0:     	mov	x19, x0
102d0b2c4:     	ldr	x1, [x1, #0x30]
102d0b2c8:     	ldr	x2, [x20, #0x38]
102d0b2cc:     	add	x0, sp, #0x50
102d0b2d0:     	bl	0x102de8808 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102d0b2d4:     	add	x0, sp, #0x50
102d0b2d8:     	bl	0x102cd2af0 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102d0b2dc:     	mov	x21, x0
102d0b2e0:     	mov	x22, x1
102d0b2e4:     	stp	x0, x1, [x29, #-0x80]
102d0b2e8:     	add	x0, sp, #0x50
102d0b2ec:     	mov	x1, x20
102d0b2f0:     	bl	0x102d05488 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d0b2f4:     	add	x0, x20, #0x40
102d0b2f8:     	bl	0x102df0e08 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d0b2fc:     	stp	x21, x22, [sp, #0x30]
102d0b300:     	ldp	q0, q1, [sp, #0x50]
102d0b304:     	stp	q0, q1, [sp]
102d0b308:     	ldr	q0, [sp, #0x70]
102d0b30c:     	str	q0, [sp, #0x20]
102d0b310:     	stp	x0, x1, [sp, #0x40]
102d0b314:     	add	x0, x20, #0x90
102d0b318:     	bl	0x102deffa8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102d0b31c:     	mov	x21, x0
102d0b320:     	mov	x23, x1
102d0b324:     	stp	x0, x1, [x29, #-0x90]
102d0b328:     	sub	x0, x29, #0x80
102d0b32c:     	add	x1, x20, #0x50
102d0b330:     	bl	0x102d0d668 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d0b334:     	mov	x22, #0x0               ; =0
102d0b338:     	stp	x21, x23, [sp, #0x90]
102d0b33c:     	ldp	q0, q1, [x29, #-0x80]
102d0b340:     	stp	q0, q1, [sp, #0x50]
102d0b344:     	ldp	q0, q1, [x29, #-0x60]
102d0b348:     	ldr	x24, [x20, #0xa8]
102d0b34c:     	lsl	x21, x24, #3
102d0b350:     	lsr	x8, x24, #61
102d0b354:     	stp	q0, q1, [sp, #0x70]
102d0b358:     	cbnz	x8, 0x102d0b3a4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102d0b35c:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102d0b360:     	cmp	x21, x8
102d0b364:     	b.hi	0x102d0b3a4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102d0b368:     	cbz	x21, 0x102d0b3b4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x114>
102d0b36c:     	ldr	x23, [x20, #0xa0]
102d0b370:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d0b374:     	mov	w22, #0x8               ; =8
102d0b378:     	mov	x0, x21
102d0b37c:     	mov	w1, #0x8                ; =8
102d0b380:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d0b384:     	cbz	x0, 0x102d0b3a4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x104>
102d0b388:     	mov	x20, x0
102d0b38c:     	cbz	x24, 0x102d0b3b8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x118>
102d0b390:     	mov	x0, x20
102d0b394:     	mov	x1, x23
102d0b398:     	mov	x2, x21
102d0b39c:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
102d0b3a0:     	b	0x102d0b3b8 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x118>
102d0b3a4:     	mov	x0, x22
102d0b3a8:     	mov	x1, x21
102d0b3ac:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d0b3b0:     	brk	#0x1
102d0b3b4:     	mov	w20, #0x8               ; =8
102d0b3b8:     	ldp	q0, q1, [sp, #0x20]
102d0b3bc:     	stp	q0, q1, [x19, #0x20]
102d0b3c0:     	ldp	q1, q0, [sp]
102d0b3c4:     	stp	q1, q0, [x19]
102d0b3c8:     	ldp	q0, q1, [sp, #0x70]
102d0b3cc:     	ldp	q3, q2, [sp, #0x50]
102d0b3d0:     	stp	q2, q0, [x19, #0x60]
102d0b3d4:     	ldr	q0, [sp, #0x90]
102d0b3d8:     	stp	q1, q0, [x19, #0x80]
102d0b3dc:     	ldr	q0, [sp, #0x40]
102d0b3e0:     	stp	q0, q3, [x19, #0x40]
102d0b3e4:     	stp	x20, x24, [x19, #0xa0]
102d0b3e8:     	ldp	x29, x30, [sp, #0x130]
102d0b3ec:     	ldp	x20, x19, [sp, #0x120]
102d0b3f0:     	ldp	x22, x21, [sp, #0x110]
102d0b3f4:     	ldp	x24, x23, [sp, #0x100]
102d0b3f8:     	ldp	x28, x27, [sp, #0xf0]
102d0b3fc:     	add	sp, sp, #0x140
102d0b400:     	ret
102d0b404:     	mov	x19, x0
102d0b408:     	sub	x0, x29, #0x90
102d0b40c:     	bl	0x102cf2024 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102d0b410:     	b	0x102d0b450 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102d0b414:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d0b418:     	mov	x19, x0
102d0b41c:     	b	0x102d0b450 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102d0b420:     	mov	x19, x0
102d0b424:     	add	x0, sp, #0x50
102d0b428:     	bl	0x102cf3458 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102d0b42c:     	b	0x102d0b434 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
102d0b430:     	mov	x19, x0
102d0b434:     	sub	x0, x29, #0x80
102d0b438:     	bl	0x102cf2114 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102d0b43c:     	b	0x102d0b458 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102d0b440:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d0b444:     	mov	x19, x0
102d0b448:     	add	x0, sp, #0x50
102d0b44c:     	bl	0x102cf31fc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102d0b450:     	mov	x0, sp
102d0b454:     	bl	0x102cf42ec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102d0b458:     	mov	x0, x19
102d0b45c:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102d0b460:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
