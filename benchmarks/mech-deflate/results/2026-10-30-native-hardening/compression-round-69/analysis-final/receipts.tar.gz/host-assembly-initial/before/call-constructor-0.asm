
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d82d98 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call>:
102d82d98:     	sub	sp, sp, #0x180
102d82d9c:     	stp	x28, x27, [sp, #0x120]
102d82da0:     	stp	x26, x25, [sp, #0x130]
102d82da4:     	stp	x24, x23, [sp, #0x140]
102d82da8:     	stp	x22, x21, [sp, #0x150]
102d82dac:     	stp	x20, x19, [sp, #0x160]
102d82db0:     	stp	x29, x30, [sp, #0x170]
102d82db4:     	add	x29, sp, #0x170
102d82db8:     	mov	x24, x6
102d82dbc:     	mov	x25, x5
102d82dc0:     	mov	x22, x4
102d82dc4:     	mov	x21, x3
102d82dc8:     	mov	x20, x2
102d82dcc:     	mov	x19, x1
102d82dd0:     	mov	x26, x0
102d82dd4:     	mov	x23, x8
102d82dd8:     	stp	x1, x2, [sp, #0x48]
102d82ddc:     	stp	x3, x4, [sp, #0x58]
102d82de0:     	add	x8, sp, #0x68
102d82de4:     	bl	0x102d82bc0 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_12ResolvedCall8validate>
102d82de8:     	ldr	x8, [sp, #0x68]
102d82dec:     	cmp	x8, #0x2
102d82df0:     	b.ne	0x102d82e84 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xec>
102d82df4:     	ldp	x1, x2, [x26, #0x58]
102d82df8:     	adrp	x5, 0x107708000 <_anon.470345d915546ec0cf43ab9d77a5d2c9.543+0x2352>
102d82dfc:     	add	x5, x5, #0x1ee
102d82e00:     	add	x0, sp, #0x68
102d82e04:     	mov	x3, x19
102d82e08:     	mov	x4, x20
102d82e0c:     	mov	w6, #0x5                ; =5
102d82e10:     	bl	0x102d900d0 <__RNvNtNtCskIfnrfrMWVM_9mech_core8function14specialization26validate_bound_descriptors>
102d82e14:     	ldr	x8, [sp, #0x68]
102d82e18:     	cmp	x8, #0x2
102d82e1c:     	b.ne	0x102d82e84 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xec>
102d82e20:     	ldp	x1, x2, [x26, #0x78]
102d82e24:     	adrp	x5, 0x107708000 <_anon.470345d915546ec0cf43ab9d77a5d2c9.543+0x2352>
102d82e28:     	add	x5, x5, #0xfa
102d82e2c:     	add	x0, sp, #0x68
102d82e30:     	mov	x3, x21
102d82e34:     	mov	x4, x22
102d82e38:     	mov	w6, #0x6                ; =6
102d82e3c:     	bl	0x102d900d0 <__RNvNtNtCskIfnrfrMWVM_9mech_core8function14specialization26validate_bound_descriptors>
102d82e40:     	ldr	x8, [sp, #0x68]
102d82e44:     	cmp	x8, #0x2
102d82e48:     	b.ne	0x102d82e84 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xec>
102d82e4c:     	ldr	x8, [x26, #0x40]
102d82e50:     	str	x8, [sp, #0x30]
102d82e54:     	add	x0, x26, #0x30
102d82e58:     	bl	0x102e82834 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d82e5c:     	stp	x0, x1, [sp, #0x38]
102d82e60:     	ldr	x9, [x26, #0x10]
102d82e64:     	lsl	x28, x9, #1
102d82e68:     	orr	x8, x28, x9
102d82e6c:     	tbz	x8, #0x3f, 0x102d82f58 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x1c0>
102d82e70:     	mov	x27, #0x0               ; =0
102d82e74:     	mov	x0, x27
102d82e78:     	mov	x1, x28
102d82e7c:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d82e80:     	brk	#0x1
102d82e84:     	ldur	q0, [sp, #0xe8]
102d82e88:     	ldur	q1, [sp, #0xf8]
102d82e8c:     	stp	q0, q1, [x23, #0x80]
102d82e90:     	add	x8, sp, #0x9
102d82e94:     	ldur	q0, [x8, #0xff]
102d82e98:     	str	q0, [x23, #0xa0]
102d82e9c:     	ldur	q0, [sp, #0xa8]
102d82ea0:     	ldur	q1, [sp, #0xb8]
102d82ea4:     	stp	q0, q1, [x23, #0x40]
102d82ea8:     	ldur	q0, [sp, #0xd8]
102d82eac:     	ldur	q1, [sp, #0xc8]
102d82eb0:     	stp	q1, q0, [x23, #0x60]
102d82eb4:     	ldur	q0, [sp, #0x68]
102d82eb8:     	ldur	q1, [sp, #0x78]
102d82ebc:     	stp	q0, q1, [x23]
102d82ec0:     	ldur	q0, [sp, #0x98]
102d82ec4:     	ldur	q1, [sp, #0x88]
102d82ec8:     	stp	q1, q0, [x23, #0x20]
102d82ecc:     	add	x25, x22, #0x1
102d82ed0:     	mov	x0, x21
102d82ed4:     	subs	x25, x25, #0x1
102d82ed8:     	b.eq	0x102d82eec <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x154>
102d82edc:     	add	x24, x0, #0xb0
102d82ee0:     	bl	0x102d81588 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102d82ee4:     	mov	x0, x24
102d82ee8:     	b	0x102d82ed4 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x13c>
102d82eec:     	cbz	x22, 0x102d82f04 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x16c>
102d82ef0:     	mov	w8, #0xb0               ; =176
102d82ef4:     	mul	x1, x22, x8
102d82ef8:     	mov	x0, x21
102d82efc:     	mov	w2, #0x10               ; =16
102d82f00:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d82f04:     	add	x22, x20, #0x1
102d82f08:     	mov	x0, x19
102d82f0c:     	subs	x22, x22, #0x1
102d82f10:     	b.eq	0x102d82f24 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x18c>
102d82f14:     	add	x21, x0, #0xb0
102d82f18:     	bl	0x102d81588 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102d82f1c:     	mov	x0, x21
102d82f20:     	b	0x102d82f0c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x174>
102d82f24:     	cbz	x20, 0x102d83080 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x2e8>
102d82f28:     	mov	w8, #0xb0               ; =176
102d82f2c:     	mul	x1, x20, x8
102d82f30:     	mov	x0, x19
102d82f34:     	mov	w2, #0x10               ; =16
102d82f38:     	ldp	x29, x30, [sp, #0x170]
102d82f3c:     	ldp	x20, x19, [sp, #0x160]
102d82f40:     	ldp	x22, x21, [sp, #0x150]
102d82f44:     	ldp	x24, x23, [sp, #0x140]
102d82f48:     	ldp	x26, x25, [sp, #0x130]
102d82f4c:     	ldp	x28, x27, [sp, #0x120]
102d82f50:     	add	sp, sp, #0x180
102d82f54:     	b	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d82f58:     	str	x9, [sp, #0x28]
102d82f5c:     	ldrb	w9, [x26]
102d82f60:     	cbz	x28, 0x102d82fc8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x230>
102d82f64:     	str	w9, [sp, #0x1c]
102d82f68:     	ldr	x8, [x26, #0x8]
102d82f6c:     	str	x8, [sp, #0x10]
102d82f70:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d82f74:     	mov	w27, #0x1               ; =1
102d82f78:     	mov	x0, x28
102d82f7c:     	mov	w1, #0x1                ; =1
102d82f80:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d82f84:     	str	x0, [sp, #0x20]
102d82f88:     	cbz	x0, 0x102d82e74 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xdc>
102d82f8c:     	ldr	x8, [sp, #0x28]
102d82f90:     	cbz	x8, 0x102d82fa4 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x20c>
102d82f94:     	ldr	x0, [sp, #0x20]
102d82f98:     	ldr	x1, [sp, #0x10]
102d82f9c:     	mov	x2, x28
102d82fa0:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d82fa4:     	ldr	w9, [sp, #0x1c]
102d82fa8:     	cbz	w9, 0x102d82fd4 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x23c>
102d82fac:     	ldrb	w9, [x26, #0x1]
102d82fb0:     	ldrb	w8, [x26, #0x2]
102d82fb4:     	str	w8, [sp, #0x1c]
102d82fb8:     	mov	w27, #0x1               ; =1
102d82fbc:     	ldr	w8, [x26, #0x4]
102d82fc0:     	stp	w8, w9, [sp, #0xc]
102d82fc4:     	b	0x102d82fd8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x240>
102d82fc8:     	mov	w8, #0x1                ; =1
102d82fcc:     	str	x8, [sp, #0x20]
102d82fd0:     	cbnz	w9, 0x102d82fac <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x214>
102d82fd4:     	mov	w27, #0x0               ; =0
102d82fd8:     	add	x0, x26, #0x18
102d82fdc:     	bl	0x102dd9bc0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d82fe0:     	ldrb	w8, [x26, #0x28]
102d82fe4:     	sub	w9, w8, #0x3
102d82fe8:     	mov	w10, #0x2               ; =2
102d82fec:     	cmp	w8, #0x2
102d82ff0:     	csel	w9, w9, w10, hi
102d82ff4:     	and	w9, w9, #0xff
102d82ff8:     	cmp	w9, #0x1
102d82ffc:     	b.gt	0x102d8300c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x274>
102d83000:     	cbnz	w9, 0x102d83018 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x280>
102d83004:     	mov	w8, #0x3                ; =3
102d83008:     	b	0x102d8301c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x284>
102d8300c:     	cmp	w9, #0x2
102d83010:     	ldrb	w9, [x26, #0x29]
102d83014:     	b	0x102d8301c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x284>
102d83018:     	mov	w8, #0x4                ; =4
102d8301c:     	ldr	w10, [x26, #0x98]
102d83020:     	str	x25, [x23, #0x10]
102d83024:     	stp	wzr, w10, [x23, #0x30]
102d83028:     	strb	w27, [x23, #0x38]
102d8302c:     	ldr	w10, [sp, #0x10]
102d83030:     	strb	w10, [x23, #0x39]
102d83034:     	ldr	w10, [sp, #0x1c]
102d83038:     	strb	w10, [x23, #0x3a]
102d8303c:     	ldr	w10, [sp, #0xc]
102d83040:     	str	w10, [x23, #0x3c]
102d83044:     	ldp	x11, x10, [sp, #0x20]
102d83048:     	stp	x11, x10, [x23, #0x40]
102d8304c:     	stp	x0, x1, [x23, #0x50]
102d83050:     	strb	w8, [x23, #0x60]
102d83054:     	strb	w9, [x23, #0x61]
102d83058:     	ldp	x9, x8, [sp, #0x38]
102d8305c:     	stp	x9, x8, [x23, #0x68]
102d83060:     	ldr	x8, [sp, #0x30]
102d83064:     	stp	x8, x19, [x23, #0x78]
102d83068:     	stp	x20, x21, [x23, #0x88]
102d8306c:     	str	x22, [x23, #0x98]
102d83070:     	strb	w24, [x23, #0xa0]
102d83074:     	adrp	x8, 0x107560000 <_anon.3f32b4b9b6912109d8109e11c94e8609.465+0xa3f>
102d83078:     	ldr	q0, [x8, #0xcb0]
102d8307c:     	str	q0, [x23]
102d83080:     	ldp	x29, x30, [sp, #0x170]
102d83084:     	ldp	x20, x19, [sp, #0x160]
102d83088:     	ldp	x22, x21, [sp, #0x150]
102d8308c:     	ldp	x24, x23, [sp, #0x140]
102d83090:     	ldp	x26, x25, [sp, #0x130]
102d83094:     	ldp	x28, x27, [sp, #0x120]
102d83098:     	add	sp, sp, #0x180
102d8309c:     	ret
102d830a0:     	mov	x23, x0
102d830a4:     	ldr	x8, [sp, #0x28]
102d830a8:     	cbz	x8, 0x102d83148 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3b0>
102d830ac:     	ldr	x0, [sp, #0x20]
102d830b0:     	mov	x1, x28
102d830b4:     	mov	w2, #0x1                ; =1
102d830b8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d830bc:     	b	0x102d83148 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3b0>
102d830c0:     	mov	x23, x0
102d830c4:     	b	0x102d8315c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3c4>
102d830c8:     	mov	x23, x0
102d830cc:     	subs	x22, x22, #0x1
102d830d0:     	b.eq	0x102d830e8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x350>
102d830d4:     	add	x24, x21, #0xb0
102d830d8:     	mov	x0, x21
102d830dc:     	bl	0x102d81588 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102d830e0:     	mov	x21, x24
102d830e4:     	b	0x102d830cc <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x334>
102d830e8:     	mov	w8, #0xb0               ; =176
102d830ec:     	mul	x1, x20, x8
102d830f0:     	mov	x0, x19
102d830f4:     	mov	w2, #0x10               ; =16
102d830f8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d830fc:     	mov	x0, x23
102d83100:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102d83104:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d83108:     	mov	x23, x0
102d8310c:     	subs	x25, x25, #0x1
102d83110:     	b.eq	0x102d83128 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x390>
102d83114:     	add	x19, x24, #0xb0
102d83118:     	mov	x0, x24
102d8311c:     	bl	0x102d81588 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102d83120:     	mov	x24, x19
102d83124:     	b	0x102d8310c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x374>
102d83128:     	mov	w8, #0xb0               ; =176
102d8312c:     	mul	x1, x22, x8
102d83130:     	mov	x0, x21
102d83134:     	mov	w2, #0x10               ; =16
102d83138:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d8313c:     	b	0x102d83164 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3cc>
102d83140:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d83144:     	mov	x23, x0
102d83148:     	ldr	x1, [sp, #0x40]
102d8314c:     	cbz	x1, 0x102d8315c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3c4>
102d83150:     	ldr	x0, [sp, #0x38]
102d83154:     	mov	w2, #0x1                ; =1
102d83158:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d8315c:     	add	x0, sp, #0x58
102d83160:     	bl	0x102d7f7a4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102d83164:     	add	x0, sp, #0x48
102d83168:     	bl	0x102d7f7a4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102d8316c:     	mov	x0, x23
102d83170:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102d83174:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
