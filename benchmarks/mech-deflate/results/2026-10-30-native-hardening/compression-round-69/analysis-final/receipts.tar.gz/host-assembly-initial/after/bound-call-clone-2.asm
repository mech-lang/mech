
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e4b7ec <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102e4b7ec:     	sub	sp, sp, #0x140
102e4b7f0:     	stp	d9, d8, [sp, #0xd0]
102e4b7f4:     	stp	x28, x27, [sp, #0xe0]
102e4b7f8:     	stp	x26, x25, [sp, #0xf0]
102e4b7fc:     	stp	x24, x23, [sp, #0x100]
102e4b800:     	stp	x22, x21, [sp, #0x110]
102e4b804:     	stp	x20, x19, [sp, #0x120]
102e4b808:     	stp	x29, x30, [sp, #0x130]
102e4b80c:     	add	x29, sp, #0x130
102e4b810:     	mov	x20, x1
102e4b814:     	mov	x19, x0
102e4b818:     	ldr	x27, [x1, #0x70]
102e4b81c:     	add	x0, x1, #0x60
102e4b820:     	bl	0x102e7d178 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102e4b824:     	str	x0, [sp, #0x10]
102e4b828:     	mov	x21, x1
102e4b82c:     	ldr	x28, [x20, #0x40]
102e4b830:     	lsl	x24, x28, #1
102e4b834:     	orr	x8, x24, x28
102e4b838:     	tbz	x8, #0x3f, 0x102e4b850 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x64>
102e4b83c:     	mov	x26, #0x0               ; =0
102e4b840:     	mov	x0, x26
102e4b844:     	mov	x1, x24
102e4b848:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102e4b84c:     	b	0x102e4ba18 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x22c>
102e4b850:     	ldrb	w22, [x20, #0x30]
102e4b854:     	cbz	x24, 0x102e4b8a8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbc>
102e4b858:     	ldr	x25, [x20, #0x38]
102e4b85c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e4b860:     	mov	w26, #0x1               ; =1
102e4b864:     	mov	x0, x24
102e4b868:     	mov	w1, #0x1                ; =1
102e4b86c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e4b870:     	cbz	x0, 0x102e4b840 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x54>
102e4b874:     	mov	x23, x0
102e4b878:     	cbz	x28, 0x102e4b88c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa0>
102e4b87c:     	mov	x0, x23
102e4b880:     	mov	x1, x25
102e4b884:     	mov	x2, x24
102e4b888:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
102e4b88c:     	cbz	w22, 0x102e4b8b0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc4>
102e4b890:     	ldrb	w8, [x20, #0x31]
102e4b894:     	str	w8, [sp, #0xc]
102e4b898:     	ldrb	w22, [x20, #0x32]
102e4b89c:     	mov	w25, #0x1               ; =1
102e4b8a0:     	ldr	w26, [x20, #0x34]
102e4b8a4:     	b	0x102e4b8b4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc8>
102e4b8a8:     	mov	w23, #0x1               ; =1
102e4b8ac:     	cbnz	w22, 0x102e4b890 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa4>
102e4b8b0:     	mov	w25, #0x0               ; =0
102e4b8b4:     	add	x0, x20, #0x48
102e4b8b8:     	bl	0x102df0f10 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102e4b8bc:     	ldrb	w8, [x20, #0x58]
102e4b8c0:     	sub	w9, w8, #0x3
102e4b8c4:     	mov	w10, #0x2               ; =2
102e4b8c8:     	cmp	w8, #0x2
102e4b8cc:     	csel	w9, w9, w10, hi
102e4b8d0:     	and	w9, w9, #0xff
102e4b8d4:     	cmp	w9, #0x1
102e4b8d8:     	b.gt	0x102e4b8e8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102e4b8dc:     	cbnz	w9, 0x102e4b8f4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102e4b8e0:     	mov	w8, #0x3                ; =3
102e4b8e4:     	b	0x102e4b8f8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102e4b8e8:     	cmp	w9, #0x2
102e4b8ec:     	ldrb	w9, [x20, #0x59]
102e4b8f0:     	b	0x102e4b8f8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102e4b8f4:     	mov	w8, #0x4                ; =4
102e4b8f8:     	strb	w25, [sp, #0x18]
102e4b8fc:     	ldr	w10, [sp, #0xc]
102e4b900:     	strb	w10, [sp, #0x19]
102e4b904:     	strb	w22, [sp, #0x1a]
102e4b908:     	str	w26, [sp, #0x1c]
102e4b90c:     	stp	x23, x28, [sp, #0x20]
102e4b910:     	stp	x21, x27, [sp, #0x50]
102e4b914:     	ldr	x10, [sp, #0x10]
102e4b918:     	str	x10, [sp, #0x48]
102e4b91c:     	stp	x0, x1, [sp, #0x30]
102e4b920:     	strb	w8, [sp, #0x40]
102e4b924:     	strb	w9, [sp, #0x41]
102e4b928:     	ldr	d8, [x20, #0x28]
102e4b92c:     	mov	w8, #0x1                ; =1
102e4b930:     	ldp	x24, x25, [x20, #0x78]
102e4b934:     	ldadd	x8, x8, [x24]
102e4b938:     	tbnz	x8, #0x3f, 0x102e4ba18 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x22c>
102e4b93c:     	stp	x24, x25, [sp, #0x60]
102e4b940:     	ldp	x23, x26, [x20, #0x88]
102e4b944:     	mov	w8, #0x1                ; =1
102e4b948:     	ldadd	x8, x8, [x23]
102e4b94c:     	tbnz	x8, #0x3f, 0x102e4ba18 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x22c>
102e4b950:     	stp	x23, x26, [sp, #0x70]
102e4b954:     	mov	x0, x20
102e4b958:     	ldr	x8, [x0], #0x18
102e4b95c:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
102e4b960:     	cmp	x8, x9
102e4b964:     	b.ne	0x102e4b980 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
102e4b968:     	ldr	q0, [x20]
102e4b96c:     	str	q0, [sp, #0x80]
102e4b970:     	ldp	x8, x21, [x20, #0x10]
102e4b974:     	str	x8, [sp, #0x90]
102e4b978:     	ldr	x22, [x20, #0x20]
102e4b97c:     	b	0x102e4b9ac <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1c0>
102e4b980:     	bl	0x102defb54 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCskIfnrfrMWVM_9mech_core>
102e4b984:     	mov	x21, x0
102e4b988:     	mov	x22, x1
102e4b98c:     	stp	x0, x1, [x29, #-0x90]
102e4b990:     	sub	x8, x29, #0x80
102e4b994:     	mov	x0, x20
102e4b998:     	bl	0x102e7ccf4 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102e4b99c:     	ldur	q0, [x29, #-0x80]
102e4b9a0:     	str	q0, [sp, #0x80]
102e4b9a4:     	ldur	x8, [x29, #-0x70]
102e4b9a8:     	str	x8, [sp, #0x90]
102e4b9ac:     	ldrb	w8, [x20, #0x98]
102e4b9b0:     	ldur	q0, [sp, #0x38]
102e4b9b4:     	ldur	q1, [sp, #0x48]
102e4b9b8:     	stp	q0, q1, [x19, #0x50]
102e4b9bc:     	ldr	x9, [sp, #0x58]
102e4b9c0:     	ldur	q0, [sp, #0x28]
102e4b9c4:     	ldur	q1, [sp, #0x18]
102e4b9c8:     	stp	q1, q0, [x19, #0x30]
102e4b9cc:     	str	d8, [x19, #0x28]
102e4b9d0:     	stp	x9, x24, [x19, #0x70]
102e4b9d4:     	stp	x25, x23, [x19, #0x80]
102e4b9d8:     	str	x26, [x19, #0x90]
102e4b9dc:     	ldr	q0, [sp, #0x80]
102e4b9e0:     	ldr	x9, [sp, #0x90]
102e4b9e4:     	str	q0, [x19]
102e4b9e8:     	stp	x9, x21, [x19, #0x10]
102e4b9ec:     	str	x22, [x19, #0x20]
102e4b9f0:     	strb	w8, [x19, #0x98]
102e4b9f4:     	ldp	x29, x30, [sp, #0x130]
102e4b9f8:     	ldp	x20, x19, [sp, #0x120]
102e4b9fc:     	ldp	x22, x21, [sp, #0x110]
102e4ba00:     	ldp	x24, x23, [sp, #0x100]
102e4ba04:     	ldp	x26, x25, [sp, #0xf0]
102e4ba08:     	ldp	x28, x27, [sp, #0xe0]
102e4ba0c:     	ldp	d9, d8, [sp, #0xd0]
102e4ba10:     	add	sp, sp, #0x140
102e4ba14:     	ret
102e4ba18:     	brk	#0x1
102e4ba1c:     	mov	x19, x0
102e4ba20:     	sub	x0, x29, #0x90
102e4ba24:     	bl	0x102e2f96c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECskIfnrfrMWVM_9mech_core>
102e4ba28:     	b	0x102e4ba30 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x244>
102e4ba2c:     	mov	x19, x0
102e4ba30:     	mov	x20, #-0x1              ; =-1
102e4ba34:     	ldaddl	x20, x8, [x23]
102e4ba38:     	cmp	x8, #0x1
102e4ba3c:     	b.ne	0x102e4ba4c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x260>
102e4ba40:     	dmb	ishld
102e4ba44:     	add	x0, sp, #0x70
102e4ba48:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
102e4ba4c:     	ldr	x8, [sp, #0x60]
102e4ba50:     	ldaddl	x20, x8, [x8]
102e4ba54:     	cmp	x8, #0x1
102e4ba58:     	b.ne	0x102e4ba68 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x27c>
102e4ba5c:     	dmb	ishld
102e4ba60:     	add	x0, sp, #0x60
102e4ba64:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
102e4ba68:     	add	x0, sp, #0x18
102e4ba6c:     	bl	0x102e32034 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102e4ba70:     	b	0x102e4bab8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2cc>
102e4ba74:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102e4ba78:     	mov	x19, x0
102e4ba7c:     	cbnz	x28, 0x102e4ba88 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x29c>
102e4ba80:     	mov	x0, x19
102e4ba84:     	b	0x102e4baa0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
102e4ba88:     	mov	x0, x23
102e4ba8c:     	mov	x1, x24
102e4ba90:     	mov	w2, #0x1                ; =1
102e4ba94:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102e4ba98:     	mov	x0, x19
102e4ba9c:     	b	0x102e4baa0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
102e4baa0:     	cbz	x21, 0x102e4babc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2d0>
102e4baa4:     	mov	x19, x0
102e4baa8:     	ldr	x0, [sp, #0x10]
102e4baac:     	mov	x1, x21
102e4bab0:     	mov	w2, #0x1                ; =1
102e4bab4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102e4bab8:     	mov	x0, x19
102e4babc:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
