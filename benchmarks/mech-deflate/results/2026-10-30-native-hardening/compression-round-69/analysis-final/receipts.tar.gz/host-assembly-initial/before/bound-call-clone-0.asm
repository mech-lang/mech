
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a236cc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102a236cc:     	sub	sp, sp, #0x130
102a236d0:     	stp	d9, d8, [sp, #0xc0]
102a236d4:     	stp	x28, x27, [sp, #0xd0]
102a236d8:     	stp	x26, x25, [sp, #0xe0]
102a236dc:     	stp	x24, x23, [sp, #0xf0]
102a236e0:     	stp	x22, x21, [sp, #0x100]
102a236e4:     	stp	x20, x19, [sp, #0x110]
102a236e8:     	stp	x29, x30, [sp, #0x120]
102a236ec:     	add	x29, sp, #0x120
102a236f0:     	mov	x20, x1
102a236f4:     	mov	x19, x0
102a236f8:     	ldr	x28, [x1, #0x70]
102a236fc:     	add	x0, x1, #0x60
102a23700:     	bl	0x102e82834 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102a23704:     	str	x0, [sp, #0x10]
102a23708:     	mov	x21, x1
102a2370c:     	ldr	x27, [x20, #0x40]
102a23710:     	lsl	x24, x27, #1
102a23714:     	orr	x8, x24, x27
102a23718:     	tbz	x8, #0x3f, 0x102a23730 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x64>
102a2371c:     	mov	x26, #0x0               ; =0
102a23720:     	mov	x0, x26
102a23724:     	mov	x1, x24
102a23728:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a2372c:     	brk	#0x1
102a23730:     	ldrb	w22, [x20, #0x30]
102a23734:     	cbz	x24, 0x102a23788 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbc>
102a23738:     	ldr	x25, [x20, #0x38]
102a2373c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a23740:     	mov	w26, #0x1               ; =1
102a23744:     	mov	x0, x24
102a23748:     	mov	w1, #0x1                ; =1
102a2374c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a23750:     	cbz	x0, 0x102a23720 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x54>
102a23754:     	mov	x23, x0
102a23758:     	cbz	x27, 0x102a2376c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa0>
102a2375c:     	mov	x0, x23
102a23760:     	mov	x1, x25
102a23764:     	mov	x2, x24
102a23768:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a2376c:     	cbz	w22, 0x102a23790 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc4>
102a23770:     	ldrb	w8, [x20, #0x31]
102a23774:     	str	w8, [sp, #0xc]
102a23778:     	ldrb	w22, [x20, #0x32]
102a2377c:     	mov	w25, #0x1               ; =1
102a23780:     	ldr	w26, [x20, #0x34]
102a23784:     	b	0x102a23794 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc8>
102a23788:     	mov	w23, #0x1               ; =1
102a2378c:     	cbnz	w22, 0x102a23770 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa4>
102a23790:     	mov	w25, #0x0               ; =0
102a23794:     	add	x0, x20, #0x48
102a23798:     	bl	0x10276787c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a2379c:     	ldrb	w8, [x20, #0x58]
102a237a0:     	sub	w9, w8, #0x3
102a237a4:     	mov	w10, #0x2               ; =2
102a237a8:     	cmp	w8, #0x2
102a237ac:     	csel	w9, w9, w10, hi
102a237b0:     	and	w9, w9, #0xff
102a237b4:     	cmp	w9, #0x1
102a237b8:     	b.gt	0x102a237c8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102a237bc:     	cbnz	w9, 0x102a237d4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102a237c0:     	mov	w8, #0x3                ; =3
102a237c4:     	b	0x102a237d8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102a237c8:     	cmp	w9, #0x2
102a237cc:     	ldrb	w9, [x20, #0x59]
102a237d0:     	b	0x102a237d8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102a237d4:     	mov	w8, #0x4                ; =4
102a237d8:     	stp	x21, x28, [sp, #0x50]
102a237dc:     	ldr	x10, [sp, #0x10]
102a237e0:     	str	x10, [sp, #0x48]
102a237e4:     	strb	w25, [sp, #0x18]
102a237e8:     	ldr	w10, [sp, #0xc]
102a237ec:     	strb	w10, [sp, #0x19]
102a237f0:     	strb	w22, [sp, #0x1a]
102a237f4:     	str	w26, [sp, #0x1c]
102a237f8:     	stp	x23, x27, [sp, #0x20]
102a237fc:     	stp	x0, x1, [sp, #0x30]
102a23800:     	strb	w8, [sp, #0x40]
102a23804:     	strb	w9, [sp, #0x41]
102a23808:     	ldr	d8, [x20, #0x28]
102a2380c:     	add	x0, x20, #0x78
102a23810:     	bl	0x1027674b4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a23814:     	mov	x21, x0
102a23818:     	mov	x22, x1
102a2381c:     	stp	x0, x1, [sp, #0x60]
102a23820:     	add	x0, x20, #0x88
102a23824:     	bl	0x1027674b4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a23828:     	mov	x23, x0
102a2382c:     	mov	x24, x1
102a23830:     	stp	x0, x1, [sp, #0x70]
102a23834:     	mov	x0, x20
102a23838:     	ldr	x8, [x0], #0x18
102a2383c:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
102a23840:     	cmp	x8, x9
102a23844:     	b.ne	0x102a23860 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
102a23848:     	ldr	q0, [x20]
102a2384c:     	str	q0, [sp, #0x80]
102a23850:     	ldp	x8, x25, [x20, #0x10]
102a23854:     	str	x8, [sp, #0x90]
102a23858:     	ldr	x26, [x20, #0x20]
102a2385c:     	b	0x102a23888 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1bc>
102a23860:     	bl	0x10276179c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a23864:     	mov	x25, x0
102a23868:     	mov	x26, x1
102a2386c:     	sub	x8, x29, #0x80
102a23870:     	mov	x0, x20
102a23874:     	bl	0x102e823b0 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102a23878:     	ldur	q0, [x29, #-0x80]
102a2387c:     	str	q0, [sp, #0x80]
102a23880:     	ldur	x8, [x29, #-0x70]
102a23884:     	str	x8, [sp, #0x90]
102a23888:     	ldrb	w8, [x20, #0x98]
102a2388c:     	ldur	q0, [sp, #0x38]
102a23890:     	ldur	q1, [sp, #0x48]
102a23894:     	stp	q0, q1, [x19, #0x50]
102a23898:     	ldr	x9, [sp, #0x58]
102a2389c:     	ldur	q0, [sp, #0x28]
102a238a0:     	ldur	q1, [sp, #0x18]
102a238a4:     	stp	q1, q0, [x19, #0x30]
102a238a8:     	str	d8, [x19, #0x28]
102a238ac:     	stp	x9, x21, [x19, #0x70]
102a238b0:     	stp	x22, x23, [x19, #0x80]
102a238b4:     	str	x24, [x19, #0x90]
102a238b8:     	ldr	q0, [sp, #0x80]
102a238bc:     	ldr	x9, [sp, #0x90]
102a238c0:     	str	q0, [x19]
102a238c4:     	stp	x9, x25, [x19, #0x10]
102a238c8:     	str	x26, [x19, #0x20]
102a238cc:     	strb	w8, [x19, #0x98]
102a238d0:     	ldp	x29, x30, [sp, #0x120]
102a238d4:     	ldp	x20, x19, [sp, #0x110]
102a238d8:     	ldp	x22, x21, [sp, #0x100]
102a238dc:     	ldp	x24, x23, [sp, #0xf0]
102a238e0:     	ldp	x26, x25, [sp, #0xe0]
102a238e4:     	ldp	x28, x27, [sp, #0xd0]
102a238e8:     	ldp	d9, d8, [sp, #0xc0]
102a238ec:     	add	sp, sp, #0x130
102a238f0:     	ret
102a238f4:     	mov	x19, x0
102a238f8:     	mov	x0, x25
102a238fc:     	mov	x1, x26
102a23900:     	bl	0x1029cb17c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECs1qJAwyMG1lC_11mech_engine>
102a23904:     	b	0x102a2390c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x240>
102a23908:     	mov	x19, x0
102a2390c:     	add	x0, sp, #0x70
102a23910:     	bl	0x1029cc61c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
102a23914:     	b	0x102a2391c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x250>
102a23918:     	mov	x19, x0
102a2391c:     	add	x0, sp, #0x60
102a23920:     	bl	0x1029cc61c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEECs1qJAwyMG1lC_11mech_engine>
102a23924:     	b	0x102a23930 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x264>
102a23928:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102a2392c:     	mov	x19, x0
102a23930:     	add	x0, sp, #0x18
102a23934:     	bl	0x1029d3610 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorECs1qJAwyMG1lC_11mech_engine>
102a23938:     	b	0x102a2397c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b0>
102a2393c:     	mov	x19, x0
102a23940:     	cbnz	x27, 0x102a2394c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x280>
102a23944:     	mov	x0, x19
102a23948:     	b	0x102a23964 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
102a2394c:     	mov	x0, x23
102a23950:     	mov	x1, x24
102a23954:     	mov	w2, #0x1                ; =1
102a23958:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a2395c:     	mov	x0, x19
102a23960:     	b	0x102a23964 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
102a23964:     	cbz	x21, 0x102a23980 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
102a23968:     	mov	x19, x0
102a2396c:     	ldr	x0, [sp, #0x10]
102a23970:     	mov	x1, x21
102a23974:     	mov	w2, #0x1                ; =1
102a23978:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a2397c:     	mov	x0, x19
102a23980:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
