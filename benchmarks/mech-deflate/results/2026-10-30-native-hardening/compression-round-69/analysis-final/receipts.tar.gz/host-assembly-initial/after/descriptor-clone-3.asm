
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e4b3d4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102e4b3d4:     	sub	sp, sp, #0x130
102e4b3d8:     	stp	x28, x27, [sp, #0xe0]
102e4b3dc:     	stp	x24, x23, [sp, #0xf0]
102e4b3e0:     	stp	x22, x21, [sp, #0x100]
102e4b3e4:     	stp	x20, x19, [sp, #0x110]
102e4b3e8:     	stp	x29, x30, [sp, #0x120]
102e4b3ec:     	add	x29, sp, #0x120
102e4b3f0:     	mov	x20, x1
102e4b3f4:     	mov	x19, x0
102e4b3f8:     	ldr	x1, [x1, #0x30]
102e4b3fc:     	ldr	x2, [x20, #0x38]
102e4b400:     	add	x0, sp, #0x50
102e4b404:     	bl	0x102de8808 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102e4b408:     	add	x0, sp, #0x50
102e4b40c:     	bl	0x102cd2af0 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102e4b410:     	mov	x22, x0
102e4b414:     	mov	x21, x1
102e4b418:     	add	x0, sp, #0x50
102e4b41c:     	mov	x1, x20
102e4b420:     	bl	0x102e49e70 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102e4b424:     	add	x0, x20, #0x40
102e4b428:     	bl	0x102df0e08 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102e4b42c:     	stp	x22, x21, [sp, #0x30]
102e4b430:     	ldp	q0, q1, [sp, #0x50]
102e4b434:     	stp	q0, q1, [sp]
102e4b438:     	ldr	q0, [sp, #0x70]
102e4b43c:     	str	q0, [sp, #0x20]
102e4b440:     	stp	x0, x1, [sp, #0x40]
102e4b444:     	add	x0, x20, #0x90
102e4b448:     	bl	0x102deffa8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102e4b44c:     	mov	x23, x0
102e4b450:     	mov	x21, x1
102e4b454:     	sub	x0, x29, #0x80
102e4b458:     	add	x1, x20, #0x50
102e4b45c:     	bl	0x102e4c060 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102e4b460:     	mov	x22, #0x0               ; =0
102e4b464:     	stp	x23, x21, [sp, #0x90]
102e4b468:     	ldp	q0, q1, [x29, #-0x80]
102e4b46c:     	stp	q0, q1, [sp, #0x50]
102e4b470:     	ldp	q0, q1, [x29, #-0x60]
102e4b474:     	ldr	x24, [x20, #0xa8]
102e4b478:     	lsl	x21, x24, #3
102e4b47c:     	lsr	x8, x24, #61
102e4b480:     	stp	q0, q1, [sp, #0x70]
102e4b484:     	cbnz	x8, 0x102e4b4d0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102e4b488:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102e4b48c:     	cmp	x21, x8
102e4b490:     	b.hi	0x102e4b4d0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102e4b494:     	cbz	x21, 0x102e4b4e0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102e4b498:     	ldr	x23, [x20, #0xa0]
102e4b49c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e4b4a0:     	mov	w22, #0x8               ; =8
102e4b4a4:     	mov	x0, x21
102e4b4a8:     	mov	w1, #0x8                ; =8
102e4b4ac:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e4b4b0:     	cbz	x0, 0x102e4b4d0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102e4b4b4:     	mov	x20, x0
102e4b4b8:     	cbz	x24, 0x102e4b4e4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102e4b4bc:     	mov	x0, x20
102e4b4c0:     	mov	x1, x23
102e4b4c4:     	mov	x2, x21
102e4b4c8:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
102e4b4cc:     	b	0x102e4b4e4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102e4b4d0:     	mov	x0, x22
102e4b4d4:     	mov	x1, x21
102e4b4d8:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102e4b4dc:     	brk	#0x1
102e4b4e0:     	mov	w20, #0x8               ; =8
102e4b4e4:     	ldp	q0, q1, [sp, #0x20]
102e4b4e8:     	stp	q0, q1, [x19, #0x20]
102e4b4ec:     	ldp	q1, q0, [sp]
102e4b4f0:     	stp	q1, q0, [x19]
102e4b4f4:     	ldp	q0, q1, [sp, #0x70]
102e4b4f8:     	ldp	q3, q2, [sp, #0x50]
102e4b4fc:     	stp	q2, q0, [x19, #0x60]
102e4b500:     	ldr	q0, [sp, #0x90]
102e4b504:     	stp	q1, q0, [x19, #0x80]
102e4b508:     	ldr	q0, [sp, #0x40]
102e4b50c:     	stp	q0, q3, [x19, #0x40]
102e4b510:     	stp	x20, x24, [x19, #0xa0]
102e4b514:     	ldp	x29, x30, [sp, #0x120]
102e4b518:     	ldp	x20, x19, [sp, #0x110]
102e4b51c:     	ldp	x22, x21, [sp, #0x100]
102e4b520:     	ldp	x24, x23, [sp, #0xf0]
102e4b524:     	ldp	x28, x27, [sp, #0xe0]
102e4b528:     	add	sp, sp, #0x130
102e4b52c:     	ret
102e4b530:     	mov	x19, x0
102e4b534:     	mov	x0, x23
102e4b538:     	mov	x1, x21
102e4b53c:     	bl	0x102e2fb70 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102e4b540:     	b	0x102e4b584 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102e4b544:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102e4b548:     	mov	x19, x0
102e4b54c:     	b	0x102e4b584 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102e4b550:     	mov	x19, x0
102e4b554:     	add	x0, sp, #0x50
102e4b558:     	bl	0x102e30c1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102e4b55c:     	b	0x102e4b564 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x190>
102e4b560:     	mov	x19, x0
102e4b564:     	mov	x0, x22
102e4b568:     	mov	x1, x21
102e4b56c:     	bl	0x102e2fc60 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102e4b570:     	b	0x102e4b58c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102e4b574:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102e4b578:     	mov	x19, x0
102e4b57c:     	add	x0, sp, #0x50
102e4b580:     	bl	0x102e309bc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102e4b584:     	mov	x0, sp
102e4b588:     	bl	0x102e31388 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102e4b58c:     	mov	x0, x19
102e4b590:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102e4b594:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
