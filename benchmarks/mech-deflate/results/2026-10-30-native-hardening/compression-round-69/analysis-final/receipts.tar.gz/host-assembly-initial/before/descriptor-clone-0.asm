
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010275ae14 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
10275ae14:     	sub	sp, sp, #0x130
10275ae18:     	stp	x28, x27, [sp, #0xe0]
10275ae1c:     	stp	x24, x23, [sp, #0xf0]
10275ae20:     	stp	x22, x21, [sp, #0x100]
10275ae24:     	stp	x20, x19, [sp, #0x110]
10275ae28:     	stp	x29, x30, [sp, #0x120]
10275ae2c:     	add	x29, sp, #0x120
10275ae30:     	mov	x20, x1
10275ae34:     	mov	x19, x0
10275ae38:     	add	x0, x1, #0x30
10275ae3c:     	bl	0x1027620f0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10275ae40:     	mov	x22, x0
10275ae44:     	mov	x21, x1
10275ae48:     	add	x0, sp, #0x50
10275ae4c:     	mov	x1, x20
10275ae50:     	bl	0x1027544ec <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
10275ae54:     	add	x0, x20, #0x40
10275ae58:     	bl	0x102767774 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10275ae5c:     	stp	x22, x21, [sp, #0x30]
10275ae60:     	ldp	q0, q1, [sp, #0x50]
10275ae64:     	stp	q0, q1, [sp]
10275ae68:     	ldr	q0, [sp, #0x70]
10275ae6c:     	str	q0, [sp, #0x20]
10275ae70:     	stp	x0, x1, [sp, #0x40]
10275ae74:     	add	x0, x20, #0x90
10275ae78:     	bl	0x102761f60 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
10275ae7c:     	mov	x23, x0
10275ae80:     	mov	x21, x1
10275ae84:     	sub	x0, x29, #0x80
10275ae88:     	add	x1, x20, #0x50
10275ae8c:     	bl	0x1027692c8 <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
10275ae90:     	mov	x22, #0x0               ; =0
10275ae94:     	stp	x23, x21, [sp, #0x90]
10275ae98:     	ldp	q0, q1, [x29, #-0x80]
10275ae9c:     	stp	q0, q1, [sp, #0x50]
10275aea0:     	ldp	q0, q1, [x29, #-0x60]
10275aea4:     	ldr	x24, [x20, #0xa8]
10275aea8:     	lsl	x21, x24, #3
10275aeac:     	lsr	x8, x24, #61
10275aeb0:     	stp	q0, q1, [sp, #0x70]
10275aeb4:     	cbnz	x8, 0x10275af00 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xec>
10275aeb8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
10275aebc:     	cmp	x21, x8
10275aec0:     	b.hi	0x10275af00 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xec>
10275aec4:     	cbz	x21, 0x10275af10 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
10275aec8:     	ldr	x23, [x20, #0xa0]
10275aecc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10275aed0:     	mov	w22, #0x8               ; =8
10275aed4:     	mov	x0, x21
10275aed8:     	mov	w1, #0x8                ; =8
10275aedc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10275aee0:     	cbz	x0, 0x10275af00 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xec>
10275aee4:     	mov	x20, x0
10275aee8:     	cbz	x24, 0x10275af14 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x100>
10275aeec:     	mov	x0, x20
10275aef0:     	mov	x1, x23
10275aef4:     	mov	x2, x21
10275aef8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
10275aefc:     	b	0x10275af14 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x100>
10275af00:     	mov	x0, x22
10275af04:     	mov	x1, x21
10275af08:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
10275af0c:     	brk	#0x1
10275af10:     	mov	w20, #0x8               ; =8
10275af14:     	ldp	q0, q1, [sp, #0x20]
10275af18:     	stp	q0, q1, [x19, #0x20]
10275af1c:     	ldp	q1, q0, [sp]
10275af20:     	stp	q1, q0, [x19]
10275af24:     	ldp	q0, q1, [sp, #0x70]
10275af28:     	ldp	q3, q2, [sp, #0x50]
10275af2c:     	stp	q2, q0, [x19, #0x60]
10275af30:     	ldr	q0, [sp, #0x90]
10275af34:     	stp	q1, q0, [x19, #0x80]
10275af38:     	ldr	q0, [sp, #0x40]
10275af3c:     	stp	q0, q3, [x19, #0x40]
10275af40:     	stp	x20, x24, [x19, #0xa0]
10275af44:     	ldp	x29, x30, [sp, #0x120]
10275af48:     	ldp	x20, x19, [sp, #0x110]
10275af4c:     	ldp	x22, x21, [sp, #0x100]
10275af50:     	ldp	x24, x23, [sp, #0xf0]
10275af54:     	ldp	x28, x27, [sp, #0xe0]
10275af58:     	add	sp, sp, #0x130
10275af5c:     	ret
10275af60:     	mov	x19, x0
10275af64:     	mov	x0, x23
10275af68:     	mov	x1, x21
10275af6c:     	bl	0x102701e2c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEECs1qJAwyMG1lC_11mech_engine>
10275af70:     	b	0x10275afb4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
10275af74:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10275af78:     	mov	x19, x0
10275af7c:     	b	0x10275afb4 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a0>
10275af80:     	mov	x19, x0
10275af84:     	add	x0, sp, #0x50
10275af88:     	bl	0x102705444 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprECs1qJAwyMG1lC_11mech_engine>
10275af8c:     	b	0x10275af94 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x180>
10275af90:     	mov	x19, x0
10275af94:     	mov	x0, x22
10275af98:     	mov	x1, x21
10275af9c:     	bl	0x102701f1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEECs1qJAwyMG1lC_11mech_engine>
10275afa0:     	b	0x10275afbc <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1a8>
10275afa4:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10275afa8:     	mov	x19, x0
10275afac:     	add	x0, sp, #0x50
10275afb0:     	bl	0x102705170 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaECs1qJAwyMG1lC_11mech_engine>
10275afb4:     	mov	x0, sp
10275afb8:     	bl	0x102707f68 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeECs1qJAwyMG1lC_11mech_engine>
10275afbc:     	mov	x0, x19
10275afc0:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
10275afc4:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
