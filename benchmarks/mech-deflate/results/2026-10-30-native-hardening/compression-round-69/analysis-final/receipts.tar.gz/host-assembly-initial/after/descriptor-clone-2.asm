
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102dd4c84 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102dd4c84:     	sub	sp, sp, #0x130
102dd4c88:     	stp	x28, x27, [sp, #0xe0]
102dd4c8c:     	stp	x24, x23, [sp, #0xf0]
102dd4c90:     	stp	x22, x21, [sp, #0x100]
102dd4c94:     	stp	x20, x19, [sp, #0x110]
102dd4c98:     	stp	x29, x30, [sp, #0x120]
102dd4c9c:     	add	x29, sp, #0x120
102dd4ca0:     	mov	x20, x1
102dd4ca4:     	mov	x19, x0
102dd4ca8:     	ldr	x1, [x1, #0x30]
102dd4cac:     	ldr	x2, [x20, #0x38]
102dd4cb0:     	add	x0, sp, #0x50
102dd4cb4:     	bl	0x102de8808 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102dd4cb8:     	add	x0, sp, #0x50
102dd4cbc:     	bl	0x102cd2af0 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102dd4cc0:     	mov	x22, x0
102dd4cc4:     	mov	x21, x1
102dd4cc8:     	add	x0, sp, #0x50
102dd4ccc:     	mov	x1, x20
102dd4cd0:     	bl	0x102dd2898 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102dd4cd4:     	add	x0, x20, #0x40
102dd4cd8:     	bl	0x102df0e08 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102dd4cdc:     	stp	x22, x21, [sp, #0x30]
102dd4ce0:     	ldp	q0, q1, [sp, #0x50]
102dd4ce4:     	stp	q0, q1, [sp]
102dd4ce8:     	ldr	q0, [sp, #0x70]
102dd4cec:     	str	q0, [sp, #0x20]
102dd4cf0:     	stp	x0, x1, [sp, #0x40]
102dd4cf4:     	add	x0, x20, #0x90
102dd4cf8:     	bl	0x102deffa8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102dd4cfc:     	mov	x23, x0
102dd4d00:     	mov	x21, x1
102dd4d04:     	sub	x0, x29, #0x80
102dd4d08:     	add	x1, x20, #0x50
102dd4d0c:     	bl	0x102dd557c <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102dd4d10:     	mov	x22, #0x0               ; =0
102dd4d14:     	stp	x23, x21, [sp, #0x90]
102dd4d18:     	ldp	q0, q1, [x29, #-0x80]
102dd4d1c:     	stp	q0, q1, [sp, #0x50]
102dd4d20:     	ldp	q0, q1, [x29, #-0x60]
102dd4d24:     	ldr	x24, [x20, #0xa8]
102dd4d28:     	lsl	x21, x24, #3
102dd4d2c:     	lsr	x8, x24, #61
102dd4d30:     	stp	q0, q1, [sp, #0x70]
102dd4d34:     	cbnz	x8, 0x102dd4d80 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102dd4d38:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102dd4d3c:     	cmp	x21, x8
102dd4d40:     	b.hi	0x102dd4d80 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102dd4d44:     	cbz	x21, 0x102dd4d90 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102dd4d48:     	ldr	x23, [x20, #0xa0]
102dd4d4c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102dd4d50:     	mov	w22, #0x8               ; =8
102dd4d54:     	mov	x0, x21
102dd4d58:     	mov	w1, #0x8                ; =8
102dd4d5c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102dd4d60:     	cbz	x0, 0x102dd4d80 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102dd4d64:     	mov	x20, x0
102dd4d68:     	cbz	x24, 0x102dd4d94 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102dd4d6c:     	mov	x0, x20
102dd4d70:     	mov	x1, x23
102dd4d74:     	mov	x2, x21
102dd4d78:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
102dd4d7c:     	b	0x102dd4d94 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102dd4d80:     	mov	x0, x22
102dd4d84:     	mov	x1, x21
102dd4d88:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102dd4d8c:     	brk	#0x1
102dd4d90:     	mov	w20, #0x8               ; =8
102dd4d94:     	ldp	q0, q1, [sp, #0x20]
102dd4d98:     	stp	q0, q1, [x19, #0x20]
102dd4d9c:     	ldp	q1, q0, [sp]
102dd4da0:     	stp	q1, q0, [x19]
102dd4da4:     	ldp	q0, q1, [sp, #0x70]
102dd4da8:     	ldp	q3, q2, [sp, #0x50]
102dd4dac:     	stp	q2, q0, [x19, #0x60]
102dd4db0:     	ldr	q0, [sp, #0x90]
102dd4db4:     	stp	q1, q0, [x19, #0x80]
102dd4db8:     	ldr	q0, [sp, #0x40]
102dd4dbc:     	stp	q0, q3, [x19, #0x40]
102dd4dc0:     	stp	x20, x24, [x19, #0xa0]
102dd4dc4:     	ldp	x29, x30, [sp, #0x120]
102dd4dc8:     	ldp	x20, x19, [sp, #0x110]
102dd4dcc:     	ldp	x22, x21, [sp, #0x100]
102dd4dd0:     	ldp	x24, x23, [sp, #0xf0]
102dd4dd4:     	ldp	x28, x27, [sp, #0xe0]
102dd4dd8:     	add	sp, sp, #0x130
102dd4ddc:     	ret
102dd4de0:     	mov	x19, x0
102dd4de4:     	mov	x0, x23
102dd4de8:     	mov	x1, x21
102dd4dec:     	bl	0x102db8f1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102dd4df0:     	b	0x102dd4e34 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102dd4df4:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dd4df8:     	mov	x19, x0
102dd4dfc:     	b	0x102dd4e34 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102dd4e00:     	mov	x19, x0
102dd4e04:     	add	x0, sp, #0x50
102dd4e08:     	bl	0x102dbac98 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102dd4e0c:     	b	0x102dd4e14 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x190>
102dd4e10:     	mov	x19, x0
102dd4e14:     	mov	x0, x22
102dd4e18:     	mov	x1, x21
102dd4e1c:     	bl	0x102db900c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102dd4e20:     	b	0x102dd4e3c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102dd4e24:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102dd4e28:     	mov	x19, x0
102dd4e2c:     	add	x0, sp, #0x50
102dd4e30:     	bl	0x102dba934 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102dd4e34:     	mov	x0, sp
102dd4e38:     	bl	0x102dbb1e4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102dd4e3c:     	mov	x0, x19
102dd4e40:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102dd4e44:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
