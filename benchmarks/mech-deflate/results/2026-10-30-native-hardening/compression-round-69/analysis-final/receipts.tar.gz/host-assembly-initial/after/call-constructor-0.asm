
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102cf59c8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call>:
102cf59c8:     	sub	sp, sp, #0x170
102cf59cc:     	stp	x28, x27, [sp, #0x110]
102cf59d0:     	stp	x26, x25, [sp, #0x120]
102cf59d4:     	stp	x24, x23, [sp, #0x130]
102cf59d8:     	stp	x22, x21, [sp, #0x140]
102cf59dc:     	stp	x20, x19, [sp, #0x150]
102cf59e0:     	stp	x29, x30, [sp, #0x160]
102cf59e4:     	add	x29, sp, #0x160
102cf59e8:     	mov	x24, x6
102cf59ec:     	mov	x25, x5
102cf59f0:     	mov	x22, x4
102cf59f4:     	mov	x21, x3
102cf59f8:     	mov	x20, x2
102cf59fc:     	mov	x19, x1
102cf5a00:     	mov	x26, x0
102cf5a04:     	mov	x23, x8
102cf5a08:     	add	x8, sp, #0x48
102cf5a0c:     	bl	0x102cf57f0 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_12ResolvedCall8validate>
102cf5a10:     	ldr	x8, [sp, #0x48]
102cf5a14:     	cmp	x8, #0x2
102cf5a18:     	b.ne	0x102cf5aac <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xe4>
102cf5a1c:     	ldp	x1, x2, [x26, #0x58]
102cf5a20:     	adrp	x5, 0x1076fe000 <_anon.832d17c847cea70163419ed83eb8ed34.259+0x427>
102cf5a24:     	add	x5, x5, #0x72d
102cf5a28:     	add	x0, sp, #0x48
102cf5a2c:     	mov	x3, x19
102cf5a30:     	mov	x4, x20
102cf5a34:     	mov	w6, #0x5                ; =5
102cf5a38:     	bl	0x102d02fa4 <__RNvNtNtCskIfnrfrMWVM_9mech_core8function14specialization26validate_bound_descriptors>
102cf5a3c:     	ldr	x8, [sp, #0x48]
102cf5a40:     	cmp	x8, #0x2
102cf5a44:     	b.ne	0x102cf5aac <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xe4>
102cf5a48:     	ldp	x1, x2, [x26, #0x78]
102cf5a4c:     	adrp	x5, 0x1076fe000 <_anon.832d17c847cea70163419ed83eb8ed34.259+0x427>
102cf5a50:     	add	x5, x5, #0x63f
102cf5a54:     	add	x0, sp, #0x48
102cf5a58:     	mov	x3, x21
102cf5a5c:     	mov	x4, x22
102cf5a60:     	mov	w6, #0x6                ; =6
102cf5a64:     	bl	0x102d02fa4 <__RNvNtNtCskIfnrfrMWVM_9mech_core8function14specialization26validate_bound_descriptors>
102cf5a68:     	ldr	x8, [sp, #0x48]
102cf5a6c:     	cmp	x8, #0x2
102cf5a70:     	b.ne	0x102cf5aac <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xe4>
102cf5a74:     	ldr	x8, [x26, #0x40]
102cf5a78:     	str	x8, [sp, #0x30]
102cf5a7c:     	add	x0, x26, #0x30
102cf5a80:     	bl	0x102e7d178 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102cf5a84:     	stp	x0, x1, [sp, #0x38]
102cf5a88:     	ldr	x9, [x26, #0x10]
102cf5a8c:     	lsl	x28, x9, #1
102cf5a90:     	orr	x8, x28, x9
102cf5a94:     	tbz	x8, #0x3f, 0x102cf5b7c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x1b4>
102cf5a98:     	mov	x27, #0x0               ; =0
102cf5a9c:     	mov	x0, x27
102cf5aa0:     	mov	x1, x28
102cf5aa4:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102cf5aa8:     	brk	#0x1
102cf5aac:     	ldur	q0, [sp, #0xc8]
102cf5ab0:     	ldur	q1, [sp, #0xd8]
102cf5ab4:     	stp	q0, q1, [x23, #0x80]
102cf5ab8:     	ldur	q0, [sp, #0xe8]
102cf5abc:     	str	q0, [x23, #0xa0]
102cf5ac0:     	ldur	q0, [sp, #0x88]
102cf5ac4:     	ldur	q1, [sp, #0x98]
102cf5ac8:     	stp	q0, q1, [x23, #0x40]
102cf5acc:     	ldur	q0, [sp, #0xb8]
102cf5ad0:     	ldur	q1, [sp, #0xa8]
102cf5ad4:     	stp	q1, q0, [x23, #0x60]
102cf5ad8:     	ldur	q0, [sp, #0x48]
102cf5adc:     	ldur	q1, [sp, #0x58]
102cf5ae0:     	stp	q0, q1, [x23]
102cf5ae4:     	ldur	q0, [sp, #0x78]
102cf5ae8:     	ldur	q1, [sp, #0x68]
102cf5aec:     	stp	q1, q0, [x23, #0x20]
102cf5af0:     	add	x25, x22, #0x1
102cf5af4:     	mov	x0, x21
102cf5af8:     	subs	x25, x25, #0x1
102cf5afc:     	b.eq	0x102cf5b10 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x148>
102cf5b00:     	add	x24, x0, #0xb0
102cf5b04:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf5b08:     	mov	x0, x24
102cf5b0c:     	b	0x102cf5af8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x130>
102cf5b10:     	cbz	x22, 0x102cf5b28 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x160>
102cf5b14:     	mov	w8, #0xb0               ; =176
102cf5b18:     	mul	x1, x22, x8
102cf5b1c:     	mov	x0, x21
102cf5b20:     	mov	w2, #0x10               ; =16
102cf5b24:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5b28:     	add	x22, x20, #0x1
102cf5b2c:     	mov	x0, x19
102cf5b30:     	subs	x22, x22, #0x1
102cf5b34:     	b.eq	0x102cf5b48 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x180>
102cf5b38:     	add	x21, x0, #0xb0
102cf5b3c:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf5b40:     	mov	x0, x21
102cf5b44:     	b	0x102cf5b30 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x168>
102cf5b48:     	cbz	x20, 0x102cf5cf0 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x328>
102cf5b4c:     	mov	w8, #0xb0               ; =176
102cf5b50:     	mul	x1, x20, x8
102cf5b54:     	mov	x0, x19
102cf5b58:     	mov	w2, #0x10               ; =16
102cf5b5c:     	ldp	x29, x30, [sp, #0x160]
102cf5b60:     	ldp	x20, x19, [sp, #0x150]
102cf5b64:     	ldp	x22, x21, [sp, #0x140]
102cf5b68:     	ldp	x24, x23, [sp, #0x130]
102cf5b6c:     	ldp	x26, x25, [sp, #0x120]
102cf5b70:     	ldp	x28, x27, [sp, #0x110]
102cf5b74:     	add	sp, sp, #0x170
102cf5b78:     	b	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5b7c:     	str	x9, [sp, #0x28]
102cf5b80:     	ldrb	w9, [x26]
102cf5b84:     	cbz	x28, 0x102cf5bec <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x224>
102cf5b88:     	str	w9, [sp, #0x1c]
102cf5b8c:     	ldr	x8, [x26, #0x8]
102cf5b90:     	str	x8, [sp, #0x10]
102cf5b94:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102cf5b98:     	mov	w27, #0x1               ; =1
102cf5b9c:     	mov	x0, x28
102cf5ba0:     	mov	w1, #0x1                ; =1
102cf5ba4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102cf5ba8:     	str	x0, [sp, #0x20]
102cf5bac:     	cbz	x0, 0x102cf5a9c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0xd4>
102cf5bb0:     	ldr	x8, [sp, #0x28]
102cf5bb4:     	cbz	x8, 0x102cf5bc8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x200>
102cf5bb8:     	ldr	x0, [sp, #0x20]
102cf5bbc:     	ldr	x1, [sp, #0x10]
102cf5bc0:     	mov	x2, x28
102cf5bc4:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
102cf5bc8:     	ldr	w9, [sp, #0x1c]
102cf5bcc:     	cbz	w9, 0x102cf5bf8 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x230>
102cf5bd0:     	ldrb	w9, [x26, #0x1]
102cf5bd4:     	ldrb	w8, [x26, #0x2]
102cf5bd8:     	str	w8, [sp, #0x1c]
102cf5bdc:     	mov	w27, #0x1               ; =1
102cf5be0:     	ldr	w8, [x26, #0x4]
102cf5be4:     	stp	w8, w9, [sp, #0xc]
102cf5be8:     	b	0x102cf5bfc <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x234>
102cf5bec:     	mov	w8, #0x1                ; =1
102cf5bf0:     	str	x8, [sp, #0x20]
102cf5bf4:     	cbnz	w9, 0x102cf5bd0 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x208>
102cf5bf8:     	mov	w27, #0x0               ; =0
102cf5bfc:     	add	x0, x26, #0x18
102cf5c00:     	bl	0x102df0f10 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102cf5c04:     	ldrb	w8, [x26, #0x28]
102cf5c08:     	sub	w9, w8, #0x3
102cf5c0c:     	mov	w10, #0x2               ; =2
102cf5c10:     	cmp	w8, #0x2
102cf5c14:     	csel	w9, w9, w10, hi
102cf5c18:     	and	w9, w9, #0xff
102cf5c1c:     	cmp	w9, #0x1
102cf5c20:     	b.gt	0x102cf5c30 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x268>
102cf5c24:     	cbnz	w9, 0x102cf5c3c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x274>
102cf5c28:     	mov	w8, #0x3                ; =3
102cf5c2c:     	b	0x102cf5c40 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x278>
102cf5c30:     	cmp	w9, #0x2
102cf5c34:     	ldrb	w9, [x26, #0x29]
102cf5c38:     	b	0x102cf5c40 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x278>
102cf5c3c:     	mov	w8, #0x4                ; =4
102cf5c40:     	ldp	x11, x10, [sp, #0x30]
102cf5c44:     	str	x10, [sp, #0x78]
102cf5c48:     	ldr	x10, [sp, #0x40]
102cf5c4c:     	stp	x10, x11, [sp, #0x80]
102cf5c50:     	strb	w27, [sp, #0x48]
102cf5c54:     	ldr	w10, [sp, #0x10]
102cf5c58:     	strb	w10, [sp, #0x49]
102cf5c5c:     	ldr	w10, [sp, #0x1c]
102cf5c60:     	strb	w10, [sp, #0x4a]
102cf5c64:     	ldr	w10, [sp, #0xc]
102cf5c68:     	str	w10, [sp, #0x4c]
102cf5c6c:     	ldp	x11, x10, [sp, #0x20]
102cf5c70:     	stp	x11, x10, [sp, #0x50]
102cf5c74:     	stp	x0, x1, [sp, #0x60]
102cf5c78:     	strb	w8, [sp, #0x70]
102cf5c7c:     	strb	w9, [sp, #0x71]
102cf5c80:     	ldr	w28, [x26, #0x98]
102cf5c84:     	mov	x0, x19
102cf5c88:     	mov	x1, x20
102cf5c8c:     	bl	0x102d664f0 <__RNvMsp_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE11from_box_inBN_>
102cf5c90:     	mov	x26, x0
102cf5c94:     	mov	x27, x1
102cf5c98:     	stp	x0, x1, [x29, #-0x68]
102cf5c9c:     	mov	x0, x21
102cf5ca0:     	mov	x1, x22
102cf5ca4:     	bl	0x102d664f0 <__RNvMsp_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE11from_box_inBN_>
102cf5ca8:     	ldur	q0, [sp, #0x58]
102cf5cac:     	ldur	q1, [sp, #0x48]
102cf5cb0:     	stur	q0, [x23, #0x48]
102cf5cb4:     	ldur	q0, [sp, #0x68]
102cf5cb8:     	ldur	q2, [sp, #0x78]
102cf5cbc:     	stur	q0, [x23, #0x58]
102cf5cc0:     	stur	q2, [x23, #0x68]
102cf5cc4:     	ldr	x8, [sp, #0x88]
102cf5cc8:     	stur	q1, [x23, #0x38]
102cf5ccc:     	str	x25, [x23, #0x10]
102cf5cd0:     	stp	wzr, w28, [x23, #0x30]
102cf5cd4:     	stp	x8, x26, [x23, #0x78]
102cf5cd8:     	stp	x27, x0, [x23, #0x88]
102cf5cdc:     	str	x1, [x23, #0x98]
102cf5ce0:     	strb	w24, [x23, #0xa0]
102cf5ce4:     	adrp	x8, 0x10755c000 <_anon.8fa99a2ace8d5c9e78d58a535e1dd2f1.900+0x5f8>
102cf5ce8:     	ldr	q0, [x8, #0x8c0]
102cf5cec:     	str	q0, [x23]
102cf5cf0:     	ldp	x29, x30, [sp, #0x160]
102cf5cf4:     	ldp	x20, x19, [sp, #0x150]
102cf5cf8:     	ldp	x22, x21, [sp, #0x140]
102cf5cfc:     	ldp	x24, x23, [sp, #0x130]
102cf5d00:     	ldp	x26, x25, [sp, #0x120]
102cf5d04:     	ldp	x28, x27, [sp, #0x110]
102cf5d08:     	add	sp, sp, #0x170
102cf5d0c:     	ret
102cf5d10:     	mov	x23, x0
102cf5d14:     	mov	x8, #-0x1               ; =-1
102cf5d18:     	ldaddl	x8, x8, [x26]
102cf5d1c:     	cmp	x8, #0x1
102cf5d20:     	b.ne	0x102cf5d30 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x368>
102cf5d24:     	dmb	ishld
102cf5d28:     	sub	x0, x29, #0x68
102cf5d2c:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
102cf5d30:     	add	x0, sp, #0x48
102cf5d34:     	bl	0x102cf4dfc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102cf5d38:     	mov	x0, x23
102cf5d3c:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102cf5d40:     	mov	x23, x0
102cf5d44:     	add	x0, sp, #0x48
102cf5d48:     	bl	0x102cf4dfc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102cf5d4c:     	mov	w24, #0x0               ; =0
102cf5d50:     	b	0x102cf5e1c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x454>
102cf5d54:     	mov	x23, x0
102cf5d58:     	ldr	x8, [sp, #0x28]
102cf5d5c:     	cbz	x8, 0x102cf5dfc <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x434>
102cf5d60:     	ldr	x0, [sp, #0x20]
102cf5d64:     	mov	x1, x28
102cf5d68:     	mov	w2, #0x1                ; =1
102cf5d6c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5d70:     	b	0x102cf5dfc <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x434>
102cf5d74:     	mov	x23, x0
102cf5d78:     	b	0x102cf5e04 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x43c>
102cf5d7c:     	mov	x23, x0
102cf5d80:     	subs	x22, x22, #0x1
102cf5d84:     	b.eq	0x102cf5d9c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3d4>
102cf5d88:     	add	x24, x21, #0xb0
102cf5d8c:     	mov	x0, x21
102cf5d90:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf5d94:     	mov	x21, x24
102cf5d98:     	b	0x102cf5d80 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3b8>
102cf5d9c:     	mov	w8, #0xb0               ; =176
102cf5da0:     	mul	x1, x20, x8
102cf5da4:     	mov	x0, x19
102cf5da8:     	mov	w2, #0x10               ; =16
102cf5dac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5db0:     	mov	x0, x23
102cf5db4:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102cf5db8:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102cf5dbc:     	mov	x23, x0
102cf5dc0:     	subs	x25, x25, #0x1
102cf5dc4:     	b.eq	0x102cf5ddc <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x414>
102cf5dc8:     	add	x26, x24, #0xb0
102cf5dcc:     	mov	x0, x24
102cf5dd0:     	bl	0x102cf4250 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEBM_>
102cf5dd4:     	mov	x24, x26
102cf5dd8:     	b	0x102cf5dc0 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x3f8>
102cf5ddc:     	mov	w8, #0xb0               ; =176
102cf5de0:     	mul	x1, x22, x8
102cf5de4:     	mov	x0, x21
102cf5de8:     	mov	w2, #0x10               ; =16
102cf5dec:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5df0:     	b	0x102cf5e2c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x464>
102cf5df4:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102cf5df8:     	mov	x23, x0
102cf5dfc:     	ldr	x1, [sp, #0x40]
102cf5e00:     	cbnz	x1, 0x102cf5e0c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x444>
102cf5e04:     	mov	w24, #0x1               ; =1
102cf5e08:     	b	0x102cf5e1c <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x454>
102cf5e0c:     	mov	w24, #0x1               ; =1
102cf5e10:     	ldr	x0, [sp, #0x38]
102cf5e14:     	mov	w2, #0x1                ; =1
102cf5e18:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102cf5e1c:     	mov	x0, x21
102cf5e20:     	mov	x1, x22
102cf5e24:     	bl	0x102cf246c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102cf5e28:     	tbz	w24, #0x0, 0x102cf5e38 <__RNvMs1_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCall18from_resolved_call+0x470>
102cf5e2c:     	mov	x0, x19
102cf5e30:     	mov	x1, x20
102cf5e34:     	bl	0x102cf246c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102cf5e38:     	mov	x0, x23
102cf5e3c:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
102cf5e40:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
