
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102e50060 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102e50060:     	sub	sp, sp, #0x130
102e50064:     	stp	x28, x27, [sp, #0xe0]
102e50068:     	stp	x24, x23, [sp, #0xf0]
102e5006c:     	stp	x22, x21, [sp, #0x100]
102e50070:     	stp	x20, x19, [sp, #0x110]
102e50074:     	stp	x29, x30, [sp, #0x120]
102e50078:     	add	x29, sp, #0x120
102e5007c:     	mov	x20, x1
102e50080:     	mov	x19, x0
102e50084:     	ldr	x1, [x1, #0x30]
102e50088:     	ldr	x2, [x20, #0x38]
102e5008c:     	add	x0, sp, #0x50
102e50090:     	bl	0x102dcb540 <__RINvXNvMNtCsgKscDXrlV49_5alloc5sliceSp9to_vec_inNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationNtB3_10ConvertVec6to_vecNtNtB8_5alloc6GlobalEBO_>
102e50094:     	add	x0, sp, #0x50
102e50098:     	bl	0x102cd92e8 <__RNvMs_NtCsgKscDXrlV49_5alloc3vecINtB4_3VecNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationE16into_boxed_sliceBI_>
102e5009c:     	mov	x22, x0
102e500a0:     	mov	x21, x1
102e500a4:     	add	x0, sp, #0x50
102e500a8:     	mov	x1, x20
102e500ac:     	bl	0x102e4dc74 <__RNvXNtCskIfnrfrMWVM_9mech_core9kind_exprNtB2_8KindExprNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102e500b0:     	add	x0, x20, #0x40
102e500b4:     	bl	0x102dd9ab8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved21KindPredicateEvidenceENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102e500b8:     	stp	x22, x21, [sp, #0x30]
102e500bc:     	ldp	q0, q1, [sp, #0x50]
102e500c0:     	stp	q0, q1, [sp]
102e500c4:     	ldr	q0, [sp, #0x70]
102e500c8:     	str	q0, [sp, #0x20]
102e500cc:     	stp	x0, x1, [sp, #0x40]
102e500d0:     	add	x0, x20, #0x90
102e500d4:     	bl	0x102dd8c9c <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBM_>
102e500d8:     	mov	x23, x0
102e500dc:     	mov	x21, x1
102e500e0:     	sub	x0, x29, #0x80
102e500e4:     	add	x1, x20, #0x50
102e500e8:     	bl	0x102e508ec <__RNvXsh_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102e500ec:     	mov	x22, #0x0               ; =0
102e500f0:     	stp	x23, x21, [sp, #0x90]
102e500f4:     	ldp	q0, q1, [x29, #-0x80]
102e500f8:     	stp	q0, q1, [sp, #0x50]
102e500fc:     	ldp	q0, q1, [x29, #-0x60]
102e50100:     	ldr	x24, [x20, #0xa8]
102e50104:     	lsl	x21, x24, #3
102e50108:     	lsr	x8, x24, #61
102e5010c:     	stp	q0, q1, [sp, #0x70]
102e50110:     	cbnz	x8, 0x102e5015c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102e50114:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
102e50118:     	cmp	x21, x8
102e5011c:     	b.hi	0x102e5015c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102e50120:     	cbz	x21, 0x102e5016c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102e50124:     	ldr	x23, [x20, #0xa0]
102e50128:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102e5012c:     	mov	w22, #0x8               ; =8
102e50130:     	mov	x0, x21
102e50134:     	mov	w1, #0x8                ; =8
102e50138:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102e5013c:     	cbz	x0, 0x102e5015c <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102e50140:     	mov	x20, x0
102e50144:     	cbz	x24, 0x102e50170 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102e50148:     	mov	x0, x20
102e5014c:     	mov	x1, x23
102e50150:     	mov	x2, x21
102e50154:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102e50158:     	b	0x102e50170 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x110>
102e5015c:     	mov	x0, x22
102e50160:     	mov	x1, x21
102e50164:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102e50168:     	brk	#0x1
102e5016c:     	mov	w20, #0x8               ; =8
102e50170:     	ldp	q0, q1, [sp, #0x20]
102e50174:     	stp	q0, q1, [x19, #0x20]
102e50178:     	ldp	q1, q0, [sp]
102e5017c:     	stp	q1, q0, [x19]
102e50180:     	ldp	q0, q1, [sp, #0x70]
102e50184:     	ldp	q3, q2, [sp, #0x50]
102e50188:     	stp	q2, q0, [x19, #0x60]
102e5018c:     	ldr	q0, [sp, #0x90]
102e50190:     	stp	q1, q0, [x19, #0x80]
102e50194:     	ldr	q0, [sp, #0x40]
102e50198:     	stp	q0, q3, [x19, #0x40]
102e5019c:     	stp	x20, x24, [x19, #0xa0]
102e501a0:     	ldp	x29, x30, [sp, #0x120]
102e501a4:     	ldp	x20, x19, [sp, #0x110]
102e501a8:     	ldp	x22, x21, [sp, #0x100]
102e501ac:     	ldp	x24, x23, [sp, #0xf0]
102e501b0:     	ldp	x28, x27, [sp, #0xe0]
102e501b4:     	add	sp, sp, #0x130
102e501b8:     	ret
102e501bc:     	mov	x19, x0
102e501c0:     	mov	x0, x23
102e501c4:     	mov	x1, x21
102e501c8:     	bl	0x102e344c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension18DimensionParameterEEB1k_>
102e501cc:     	b	0x102e50210 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102e501d0:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102e501d4:     	mov	x19, x0
102e501d8:     	b	0x102e50210 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b0>
102e501dc:     	mov	x19, x0
102e501e0:     	add	x0, sp, #0x50
102e501e4:     	bl	0x102e36244 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core9kind_expr8KindExprEBK_>
102e501e8:     	b	0x102e501f0 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x190>
102e501ec:     	mov	x19, x0
102e501f0:     	mov	x0, x22
102e501f4:     	mov	x1, x21
102e501f8:     	bl	0x102e345b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtCskIfnrfrMWVM_9mech_core9dimension29DimensionParameterDeclarationEEB1k_>
102e501fc:     	b	0x102e50218 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_valueNtB5_23ResolvedValueDescriptorNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102e50200:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102e50204:     	mov	x19, x0
102e50208:     	add	x0, sp, #0x50
102e5020c:     	bl	0x102e35ee0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtCskIfnrfrMWVM_9mech_core6schema6SchemaEBK_>
102e50210:     	mov	x0, sp
102e50214:     	bl	0x102e36790 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11type_system8resolved12ResolvedTypeEBM_>
102e50218:     	mov	x0, x19
102e5021c:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102e50220:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
