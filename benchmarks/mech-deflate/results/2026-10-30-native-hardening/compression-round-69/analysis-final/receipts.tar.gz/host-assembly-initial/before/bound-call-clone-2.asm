
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d97ca0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d97ca0:     	sub	sp, sp, #0x130
102d97ca4:     	stp	d9, d8, [sp, #0xc0]
102d97ca8:     	stp	x28, x27, [sp, #0xd0]
102d97cac:     	stp	x26, x25, [sp, #0xe0]
102d97cb0:     	stp	x24, x23, [sp, #0xf0]
102d97cb4:     	stp	x22, x21, [sp, #0x100]
102d97cb8:     	stp	x20, x19, [sp, #0x110]
102d97cbc:     	stp	x29, x30, [sp, #0x120]
102d97cc0:     	add	x29, sp, #0x120
102d97cc4:     	mov	x20, x1
102d97cc8:     	mov	x19, x0
102d97ccc:     	ldr	x28, [x1, #0x70]
102d97cd0:     	add	x0, x1, #0x60
102d97cd4:     	bl	0x102e82834 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d97cd8:     	str	x0, [sp, #0x10]
102d97cdc:     	mov	x21, x1
102d97ce0:     	ldr	x27, [x20, #0x40]
102d97ce4:     	lsl	x24, x27, #1
102d97ce8:     	orr	x8, x24, x27
102d97cec:     	tbz	x8, #0x3f, 0x102d97d04 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x64>
102d97cf0:     	mov	x26, #0x0               ; =0
102d97cf4:     	mov	x0, x26
102d97cf8:     	mov	x1, x24
102d97cfc:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d97d00:     	brk	#0x1
102d97d04:     	ldrb	w22, [x20, #0x30]
102d97d08:     	cbz	x24, 0x102d97d5c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbc>
102d97d0c:     	ldr	x25, [x20, #0x38]
102d97d10:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d97d14:     	mov	w26, #0x1               ; =1
102d97d18:     	mov	x0, x24
102d97d1c:     	mov	w1, #0x1                ; =1
102d97d20:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d97d24:     	cbz	x0, 0x102d97cf4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x54>
102d97d28:     	mov	x23, x0
102d97d2c:     	cbz	x27, 0x102d97d40 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa0>
102d97d30:     	mov	x0, x23
102d97d34:     	mov	x1, x25
102d97d38:     	mov	x2, x24
102d97d3c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d97d40:     	cbz	w22, 0x102d97d64 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc4>
102d97d44:     	ldrb	w8, [x20, #0x31]
102d97d48:     	str	w8, [sp, #0xc]
102d97d4c:     	ldrb	w22, [x20, #0x32]
102d97d50:     	mov	w25, #0x1               ; =1
102d97d54:     	ldr	w26, [x20, #0x34]
102d97d58:     	b	0x102d97d68 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc8>
102d97d5c:     	mov	w23, #0x1               ; =1
102d97d60:     	cbnz	w22, 0x102d97d44 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa4>
102d97d64:     	mov	w25, #0x0               ; =0
102d97d68:     	add	x0, x20, #0x48
102d97d6c:     	bl	0x102dd9bc0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d97d70:     	ldrb	w8, [x20, #0x58]
102d97d74:     	sub	w9, w8, #0x3
102d97d78:     	mov	w10, #0x2               ; =2
102d97d7c:     	cmp	w8, #0x2
102d97d80:     	csel	w9, w9, w10, hi
102d97d84:     	and	w9, w9, #0xff
102d97d88:     	cmp	w9, #0x1
102d97d8c:     	b.gt	0x102d97d9c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102d97d90:     	cbnz	w9, 0x102d97da8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102d97d94:     	mov	w8, #0x3                ; =3
102d97d98:     	b	0x102d97dac <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102d97d9c:     	cmp	w9, #0x2
102d97da0:     	ldrb	w9, [x20, #0x59]
102d97da4:     	b	0x102d97dac <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102d97da8:     	mov	w8, #0x4                ; =4
102d97dac:     	stp	x21, x28, [sp, #0x50]
102d97db0:     	ldr	x10, [sp, #0x10]
102d97db4:     	str	x10, [sp, #0x48]
102d97db8:     	strb	w25, [sp, #0x18]
102d97dbc:     	ldr	w10, [sp, #0xc]
102d97dc0:     	strb	w10, [sp, #0x19]
102d97dc4:     	strb	w22, [sp, #0x1a]
102d97dc8:     	str	w26, [sp, #0x1c]
102d97dcc:     	stp	x23, x27, [sp, #0x20]
102d97dd0:     	stp	x0, x1, [sp, #0x30]
102d97dd4:     	strb	w8, [sp, #0x40]
102d97dd8:     	strb	w9, [sp, #0x41]
102d97ddc:     	ldr	d8, [x20, #0x28]
102d97de0:     	add	x0, x20, #0x78
102d97de4:     	bl	0x102dd97f8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d97de8:     	mov	x21, x0
102d97dec:     	mov	x22, x1
102d97df0:     	stp	x0, x1, [sp, #0x60]
102d97df4:     	add	x0, x20, #0x88
102d97df8:     	bl	0x102dd97f8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d97dfc:     	mov	x23, x0
102d97e00:     	mov	x24, x1
102d97e04:     	stp	x0, x1, [sp, #0x70]
102d97e08:     	mov	x0, x20
102d97e0c:     	ldr	x8, [x0], #0x18
102d97e10:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
102d97e14:     	cmp	x8, x9
102d97e18:     	b.ne	0x102d97e34 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
102d97e1c:     	ldr	q0, [x20]
102d97e20:     	str	q0, [sp, #0x80]
102d97e24:     	ldp	x8, x25, [x20, #0x10]
102d97e28:     	str	x8, [sp, #0x90]
102d97e2c:     	ldr	x26, [x20, #0x20]
102d97e30:     	b	0x102d97e5c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1bc>
102d97e34:     	bl	0x102dd8848 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCskIfnrfrMWVM_9mech_core>
102d97e38:     	mov	x25, x0
102d97e3c:     	mov	x26, x1
102d97e40:     	sub	x8, x29, #0x80
102d97e44:     	mov	x0, x20
102d97e48:     	bl	0x102e823b0 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d97e4c:     	ldur	q0, [x29, #-0x80]
102d97e50:     	str	q0, [sp, #0x80]
102d97e54:     	ldur	x8, [x29, #-0x70]
102d97e58:     	str	x8, [sp, #0x90]
102d97e5c:     	ldrb	w8, [x20, #0x98]
102d97e60:     	ldur	q0, [sp, #0x38]
102d97e64:     	ldur	q1, [sp, #0x48]
102d97e68:     	stp	q0, q1, [x19, #0x50]
102d97e6c:     	ldr	x9, [sp, #0x58]
102d97e70:     	ldur	q0, [sp, #0x28]
102d97e74:     	ldur	q1, [sp, #0x18]
102d97e78:     	stp	q1, q0, [x19, #0x30]
102d97e7c:     	str	d8, [x19, #0x28]
102d97e80:     	stp	x9, x21, [x19, #0x70]
102d97e84:     	stp	x22, x23, [x19, #0x80]
102d97e88:     	str	x24, [x19, #0x90]
102d97e8c:     	ldr	q0, [sp, #0x80]
102d97e90:     	ldr	x9, [sp, #0x90]
102d97e94:     	str	q0, [x19]
102d97e98:     	stp	x9, x25, [x19, #0x10]
102d97e9c:     	str	x26, [x19, #0x20]
102d97ea0:     	strb	w8, [x19, #0x98]
102d97ea4:     	ldp	x29, x30, [sp, #0x120]
102d97ea8:     	ldp	x20, x19, [sp, #0x110]
102d97eac:     	ldp	x22, x21, [sp, #0x100]
102d97eb0:     	ldp	x24, x23, [sp, #0xf0]
102d97eb4:     	ldp	x26, x25, [sp, #0xe0]
102d97eb8:     	ldp	x28, x27, [sp, #0xd0]
102d97ebc:     	ldp	d9, d8, [sp, #0xc0]
102d97ec0:     	add	sp, sp, #0x130
102d97ec4:     	ret
102d97ec8:     	mov	x19, x0
102d97ecc:     	mov	x0, x25
102d97ed0:     	mov	x1, x26
102d97ed4:     	bl	0x102d7f048 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECskIfnrfrMWVM_9mech_core>
102d97ed8:     	b	0x102d97ee0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x240>
102d97edc:     	mov	x19, x0
102d97ee0:     	add	x0, sp, #0x70
102d97ee4:     	bl	0x102d7f7a4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102d97ee8:     	b	0x102d97ef0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x250>
102d97eec:     	mov	x19, x0
102d97ef0:     	add	x0, sp, #0x60
102d97ef4:     	bl	0x102d7f7a4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102d97ef8:     	b	0x102d97f04 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x264>
102d97efc:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d97f00:     	mov	x19, x0
102d97f04:     	add	x0, sp, #0x18
102d97f08:     	bl	0x102d82134 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102d97f0c:     	b	0x102d97f50 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b0>
102d97f10:     	mov	x19, x0
102d97f14:     	cbnz	x27, 0x102d97f20 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x280>
102d97f18:     	mov	x0, x19
102d97f1c:     	b	0x102d97f38 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
102d97f20:     	mov	x0, x23
102d97f24:     	mov	x1, x24
102d97f28:     	mov	w2, #0x1                ; =1
102d97f2c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d97f30:     	mov	x0, x19
102d97f34:     	b	0x102d97f38 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
102d97f38:     	cbz	x21, 0x102d97f54 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
102d97f3c:     	mov	x19, x0
102d97f40:     	ldr	x0, [sp, #0x10]
102d97f44:     	mov	x1, x21
102d97f48:     	mov	w2, #0x1                ; =1
102d97f4c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d97f50:     	mov	x0, x19
102d97f54:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
