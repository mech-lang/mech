
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d7a010 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d7a010:     	sub	sp, sp, #0x120
102d7a014:     	stp	d9, d8, [sp, #0xb0]
102d7a018:     	stp	x28, x27, [sp, #0xc0]
102d7a01c:     	stp	x26, x25, [sp, #0xd0]
102d7a020:     	stp	x24, x23, [sp, #0xe0]
102d7a024:     	stp	x22, x21, [sp, #0xf0]
102d7a028:     	stp	x20, x19, [sp, #0x100]
102d7a02c:     	stp	x29, x30, [sp, #0x110]
102d7a030:     	add	x29, sp, #0x110
102d7a034:     	mov	x20, x1
102d7a038:     	mov	x19, x0
102d7a03c:     	ldr	x28, [x1, #0x70]
102d7a040:     	add	x0, x1, #0x60
102d7a044:     	bl	0x102e82834 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d7a048:     	str	x0, [sp, #0x10]
102d7a04c:     	mov	x21, x1
102d7a050:     	ldr	x27, [x20, #0x40]
102d7a054:     	lsl	x24, x27, #1
102d7a058:     	orr	x8, x24, x27
102d7a05c:     	tbz	x8, #0x3f, 0x102d7a074 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x64>
102d7a060:     	mov	x26, #0x0               ; =0
102d7a064:     	mov	x0, x26
102d7a068:     	mov	x1, x24
102d7a06c:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d7a070:     	brk	#0x1
102d7a074:     	ldrb	w22, [x20, #0x30]
102d7a078:     	cbz	x24, 0x102d7a0cc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbc>
102d7a07c:     	ldr	x25, [x20, #0x38]
102d7a080:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d7a084:     	mov	w26, #0x1               ; =1
102d7a088:     	mov	x0, x24
102d7a08c:     	mov	w1, #0x1                ; =1
102d7a090:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d7a094:     	cbz	x0, 0x102d7a064 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x54>
102d7a098:     	mov	x23, x0
102d7a09c:     	cbz	x27, 0x102d7a0b0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa0>
102d7a0a0:     	mov	x0, x23
102d7a0a4:     	mov	x1, x25
102d7a0a8:     	mov	x2, x24
102d7a0ac:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102d7a0b0:     	cbz	w22, 0x102d7a0d4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc4>
102d7a0b4:     	ldrb	w8, [x20, #0x31]
102d7a0b8:     	str	w8, [sp, #0xc]
102d7a0bc:     	ldrb	w22, [x20, #0x32]
102d7a0c0:     	mov	w25, #0x1               ; =1
102d7a0c4:     	ldr	w26, [x20, #0x34]
102d7a0c8:     	b	0x102d7a0d8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc8>
102d7a0cc:     	mov	w23, #0x1               ; =1
102d7a0d0:     	cbnz	w22, 0x102d7a0b4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa4>
102d7a0d4:     	mov	w25, #0x0               ; =0
102d7a0d8:     	add	x0, x20, #0x48
102d7a0dc:     	bl	0x102dd9bc0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d7a0e0:     	ldrb	w8, [x20, #0x58]
102d7a0e4:     	sub	w9, w8, #0x3
102d7a0e8:     	mov	w10, #0x2               ; =2
102d7a0ec:     	cmp	w8, #0x2
102d7a0f0:     	csel	w9, w9, w10, hi
102d7a0f4:     	and	w9, w9, #0xff
102d7a0f8:     	cmp	w9, #0x1
102d7a0fc:     	b.gt	0x102d7a10c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102d7a100:     	cbnz	w9, 0x102d7a118 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102d7a104:     	mov	w8, #0x3                ; =3
102d7a108:     	b	0x102d7a11c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102d7a10c:     	cmp	w9, #0x2
102d7a110:     	ldrb	w9, [x20, #0x59]
102d7a114:     	b	0x102d7a11c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102d7a118:     	mov	w8, #0x4                ; =4
102d7a11c:     	stp	x21, x28, [sp, #0x50]
102d7a120:     	ldr	x10, [sp, #0x10]
102d7a124:     	str	x10, [sp, #0x48]
102d7a128:     	strb	w25, [sp, #0x18]
102d7a12c:     	ldr	w10, [sp, #0xc]
102d7a130:     	strb	w10, [sp, #0x19]
102d7a134:     	strb	w22, [sp, #0x1a]
102d7a138:     	str	w26, [sp, #0x1c]
102d7a13c:     	stp	x23, x27, [sp, #0x20]
102d7a140:     	stp	x0, x1, [sp, #0x30]
102d7a144:     	strb	w8, [sp, #0x40]
102d7a148:     	strb	w9, [sp, #0x41]
102d7a14c:     	ldr	d8, [x20, #0x28]
102d7a150:     	add	x0, x20, #0x78
102d7a154:     	bl	0x102dd97f8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d7a158:     	mov	x22, x0
102d7a15c:     	mov	x21, x1
102d7a160:     	add	x0, x20, #0x88
102d7a164:     	bl	0x102dd97f8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d7a168:     	mov	x24, x0
102d7a16c:     	mov	x23, x1
102d7a170:     	mov	x0, x20
102d7a174:     	ldr	x8, [x0], #0x18
102d7a178:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
102d7a17c:     	cmp	x8, x9
102d7a180:     	b.ne	0x102d7a19c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x18c>
102d7a184:     	ldr	q0, [x20]
102d7a188:     	str	q0, [sp, #0x60]
102d7a18c:     	ldp	x8, x25, [x20, #0x10]
102d7a190:     	str	x8, [sp, #0x70]
102d7a194:     	ldr	x26, [x20, #0x20]
102d7a198:     	b	0x102d7a1c8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1b8>
102d7a19c:     	bl	0x102dd8848 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCskIfnrfrMWVM_9mech_core>
102d7a1a0:     	mov	x25, x0
102d7a1a4:     	mov	x26, x1
102d7a1a8:     	stp	x0, x1, [sp, #0x80]
102d7a1ac:     	sub	x8, x29, #0x80
102d7a1b0:     	mov	x0, x20
102d7a1b4:     	bl	0x102e823b0 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d7a1b8:     	ldur	q0, [x29, #-0x80]
102d7a1bc:     	str	q0, [sp, #0x60]
102d7a1c0:     	ldur	x8, [x29, #-0x70]
102d7a1c4:     	str	x8, [sp, #0x70]
102d7a1c8:     	ldrb	w8, [x20, #0x98]
102d7a1cc:     	ldur	q0, [sp, #0x38]
102d7a1d0:     	ldur	q1, [sp, #0x48]
102d7a1d4:     	stp	q0, q1, [x19, #0x50]
102d7a1d8:     	ldr	x9, [sp, #0x58]
102d7a1dc:     	ldur	q0, [sp, #0x28]
102d7a1e0:     	ldur	q1, [sp, #0x18]
102d7a1e4:     	stp	q1, q0, [x19, #0x30]
102d7a1e8:     	str	d8, [x19, #0x28]
102d7a1ec:     	stp	x9, x22, [x19, #0x70]
102d7a1f0:     	stp	x21, x24, [x19, #0x80]
102d7a1f4:     	str	x23, [x19, #0x90]
102d7a1f8:     	ldr	q0, [sp, #0x60]
102d7a1fc:     	ldr	x9, [sp, #0x70]
102d7a200:     	str	q0, [x19]
102d7a204:     	stp	x9, x25, [x19, #0x10]
102d7a208:     	str	x26, [x19, #0x20]
102d7a20c:     	strb	w8, [x19, #0x98]
102d7a210:     	ldp	x29, x30, [sp, #0x110]
102d7a214:     	ldp	x20, x19, [sp, #0x100]
102d7a218:     	ldp	x22, x21, [sp, #0xf0]
102d7a21c:     	ldp	x24, x23, [sp, #0xe0]
102d7a220:     	ldp	x26, x25, [sp, #0xd0]
102d7a224:     	ldp	x28, x27, [sp, #0xc0]
102d7a228:     	ldp	d9, d8, [sp, #0xb0]
102d7a22c:     	add	sp, sp, #0x120
102d7a230:     	ret
102d7a234:     	mov	x19, x0
102d7a238:     	add	x0, sp, #0x80
102d7a23c:     	bl	0x102d5dd00 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECskIfnrfrMWVM_9mech_core>
102d7a240:     	b	0x102d7a248 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x238>
102d7a244:     	mov	x19, x0
102d7a248:     	mov	x0, x24
102d7a24c:     	mov	x1, x23
102d7a250:     	bl	0x102d5e350 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102d7a254:     	b	0x102d7a25c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x24c>
102d7a258:     	mov	x19, x0
102d7a25c:     	mov	x0, x22
102d7a260:     	mov	x1, x21
102d7a264:     	bl	0x102d5e350 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorEEB1m_>
102d7a268:     	b	0x102d7a274 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x264>
102d7a26c:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d7a270:     	mov	x19, x0
102d7a274:     	add	x0, sp, #0x18
102d7a278:     	bl	0x102d60270 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102d7a27c:     	b	0x102d7a2c0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b0>
102d7a280:     	mov	x19, x0
102d7a284:     	cbnz	x27, 0x102d7a290 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x280>
102d7a288:     	mov	x0, x19
102d7a28c:     	b	0x102d7a2a8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
102d7a290:     	mov	x0, x23
102d7a294:     	mov	x1, x24
102d7a298:     	mov	w2, #0x1                ; =1
102d7a29c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d7a2a0:     	mov	x0, x19
102d7a2a4:     	b	0x102d7a2a8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x298>
102d7a2a8:     	cbz	x21, 0x102d7a2c4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
102d7a2ac:     	mov	x19, x0
102d7a2b0:     	ldr	x0, [sp, #0x10]
102d7a2b4:     	mov	x1, x21
102d7a2b8:     	mov	w2, #0x1                ; =1
102d7a2bc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d7a2c0:     	mov	x0, x19
102d7a2c4:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
