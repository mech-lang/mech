
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102d0cc78 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>:
102d0cc78:     	sub	sp, sp, #0x130
102d0cc7c:     	stp	d9, d8, [sp, #0xc0]
102d0cc80:     	stp	x28, x27, [sp, #0xd0]
102d0cc84:     	stp	x26, x25, [sp, #0xe0]
102d0cc88:     	stp	x24, x23, [sp, #0xf0]
102d0cc8c:     	stp	x22, x21, [sp, #0x100]
102d0cc90:     	stp	x20, x19, [sp, #0x110]
102d0cc94:     	stp	x29, x30, [sp, #0x120]
102d0cc98:     	add	x29, sp, #0x120
102d0cc9c:     	mov	x20, x1
102d0cca0:     	mov	x19, x0
102d0cca4:     	ldr	x28, [x1, #0x70]
102d0cca8:     	add	x0, x1, #0x60
102d0ccac:     	bl	0x102e7d178 <__RNvXsf_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxeENtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d0ccb0:     	str	x0, [sp, #0x10]
102d0ccb4:     	mov	x21, x1
102d0ccb8:     	ldr	x27, [x20, #0x40]
102d0ccbc:     	lsl	x24, x27, #1
102d0ccc0:     	orr	x8, x24, x27
102d0ccc4:     	tbz	x8, #0x3f, 0x102d0ccdc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x64>
102d0ccc8:     	mov	x26, #0x0               ; =0
102d0cccc:     	mov	x0, x26
102d0ccd0:     	mov	x1, x24
102d0ccd4:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102d0ccd8:     	b	0x102d0cea0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x228>
102d0ccdc:     	ldrb	w22, [x20, #0x30]
102d0cce0:     	cbz	x24, 0x102d0cd34 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xbc>
102d0cce4:     	ldr	x25, [x20, #0x38]
102d0cce8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102d0ccec:     	mov	w26, #0x1               ; =1
102d0ccf0:     	mov	x0, x24
102d0ccf4:     	mov	w1, #0x1                ; =1
102d0ccf8:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102d0ccfc:     	cbz	x0, 0x102d0cccc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x54>
102d0cd00:     	mov	x23, x0
102d0cd04:     	cbz	x27, 0x102d0cd18 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa0>
102d0cd08:     	mov	x0, x23
102d0cd0c:     	mov	x1, x25
102d0cd10:     	mov	x2, x24
102d0cd14:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
102d0cd18:     	cbz	w22, 0x102d0cd3c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc4>
102d0cd1c:     	ldrb	w8, [x20, #0x31]
102d0cd20:     	str	w8, [sp, #0xc]
102d0cd24:     	ldrb	w22, [x20, #0x32]
102d0cd28:     	mov	w25, #0x1               ; =1
102d0cd2c:     	ldr	w26, [x20, #0x34]
102d0cd30:     	b	0x102d0cd40 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xc8>
102d0cd34:     	mov	w23, #0x1               ; =1
102d0cd38:     	cbnz	w22, 0x102d0cd1c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xa4>
102d0cd3c:     	mov	w25, #0x0               ; =0
102d0cd40:     	add	x0, x20, #0x48
102d0cd44:     	bl	0x102df0f10 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract11declaration16OutputPortPolicyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneBO_>
102d0cd48:     	ldrb	w8, [x20, #0x58]
102d0cd4c:     	sub	w9, w8, #0x3
102d0cd50:     	mov	w10, #0x2               ; =2
102d0cd54:     	cmp	w8, #0x2
102d0cd58:     	csel	w9, w9, w10, hi
102d0cd5c:     	and	w9, w9, #0xff
102d0cd60:     	cmp	w9, #0x1
102d0cd64:     	b.gt	0x102d0cd74 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0xfc>
102d0cd68:     	cbnz	w9, 0x102d0cd80 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x108>
102d0cd6c:     	mov	w8, #0x3                ; =3
102d0cd70:     	b	0x102d0cd84 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102d0cd74:     	cmp	w9, #0x2
102d0cd78:     	ldrb	w9, [x20, #0x59]
102d0cd7c:     	b	0x102d0cd84 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x10c>
102d0cd80:     	mov	w8, #0x4                ; =4
102d0cd84:     	stp	x21, x28, [sp, #0x50]
102d0cd88:     	ldr	x10, [sp, #0x10]
102d0cd8c:     	str	x10, [sp, #0x48]
102d0cd90:     	strb	w25, [sp, #0x18]
102d0cd94:     	ldr	w10, [sp, #0xc]
102d0cd98:     	strb	w10, [sp, #0x19]
102d0cd9c:     	strb	w22, [sp, #0x1a]
102d0cda0:     	str	w26, [sp, #0x1c]
102d0cda4:     	stp	x23, x27, [sp, #0x20]
102d0cda8:     	stp	x0, x1, [sp, #0x30]
102d0cdac:     	strb	w8, [sp, #0x40]
102d0cdb0:     	strb	w9, [sp, #0x41]
102d0cdb4:     	ldr	d8, [x20, #0x28]
102d0cdb8:     	mov	w8, #0x1                ; =1
102d0cdbc:     	ldp	x24, x25, [x20, #0x78]
102d0cdc0:     	ldadd	x8, x8, [x24]
102d0cdc4:     	tbnz	x8, #0x3f, 0x102d0cea0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x228>
102d0cdc8:     	stp	x24, x25, [sp, #0x60]
102d0cdcc:     	ldp	x23, x26, [x20, #0x88]
102d0cdd0:     	mov	w8, #0x1                ; =1
102d0cdd4:     	ldadd	x8, x8, [x23]
102d0cdd8:     	tbnz	x8, #0x3f, 0x102d0cea0 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x228>
102d0cddc:     	stp	x23, x26, [sp, #0x70]
102d0cde0:     	mov	x0, x20
102d0cde4:     	ldr	x8, [x0], #0x18
102d0cde8:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
102d0cdec:     	cmp	x8, x9
102d0cdf0:     	b.ne	0x102d0ce0c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x194>
102d0cdf4:     	ldr	q0, [x20]
102d0cdf8:     	str	q0, [sp, #0x80]
102d0cdfc:     	ldp	x8, x21, [x20, #0x10]
102d0ce00:     	str	x8, [sp, #0x90]
102d0ce04:     	ldr	x22, [x20, #0x20]
102d0ce08:     	b	0x102d0ce34 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x1bc>
102d0ce0c:     	bl	0x102defb54 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtB7_6string6StringENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCskIfnrfrMWVM_9mech_core>
102d0ce10:     	mov	x21, x0
102d0ce14:     	mov	x22, x1
102d0ce18:     	sub	x8, x29, #0x80
102d0ce1c:     	mov	x0, x20
102d0ce20:     	bl	0x102e7ccf4 <__RNvXs4_NtCsgKscDXrlV49_5alloc6stringNtB5_6StringNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102d0ce24:     	ldur	q0, [x29, #-0x80]
102d0ce28:     	str	q0, [sp, #0x80]
102d0ce2c:     	ldur	x8, [x29, #-0x70]
102d0ce30:     	str	x8, [sp, #0x90]
102d0ce34:     	ldrb	w8, [x20, #0x98]
102d0ce38:     	ldur	q0, [sp, #0x38]
102d0ce3c:     	ldur	q1, [sp, #0x48]
102d0ce40:     	stp	q0, q1, [x19, #0x50]
102d0ce44:     	ldr	x9, [sp, #0x58]
102d0ce48:     	ldur	q0, [sp, #0x28]
102d0ce4c:     	ldur	q1, [sp, #0x18]
102d0ce50:     	stp	q1, q0, [x19, #0x30]
102d0ce54:     	str	d8, [x19, #0x28]
102d0ce58:     	stp	x9, x24, [x19, #0x70]
102d0ce5c:     	stp	x25, x23, [x19, #0x80]
102d0ce60:     	str	x26, [x19, #0x90]
102d0ce64:     	ldr	q0, [sp, #0x80]
102d0ce68:     	ldr	x9, [sp, #0x90]
102d0ce6c:     	str	q0, [x19]
102d0ce70:     	stp	x9, x21, [x19, #0x10]
102d0ce74:     	str	x22, [x19, #0x20]
102d0ce78:     	strb	w8, [x19, #0x98]
102d0ce7c:     	ldp	x29, x30, [sp, #0x120]
102d0ce80:     	ldp	x20, x19, [sp, #0x110]
102d0ce84:     	ldp	x22, x21, [sp, #0x100]
102d0ce88:     	ldp	x24, x23, [sp, #0xf0]
102d0ce8c:     	ldp	x26, x25, [sp, #0xe0]
102d0ce90:     	ldp	x28, x27, [sp, #0xd0]
102d0ce94:     	ldp	d9, d8, [sp, #0xc0]
102d0ce98:     	add	sp, sp, #0x130
102d0ce9c:     	ret
102d0cea0:     	brk	#0x1
102d0cea4:     	mov	x19, x0
102d0cea8:     	mov	x0, x21
102d0ceac:     	mov	x1, x22
102d0ceb0:     	bl	0x102cf1d10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtBL_6string6StringEECskIfnrfrMWVM_9mech_core>
102d0ceb4:     	b	0x102d0cebc <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x244>
102d0ceb8:     	mov	x19, x0
102d0cebc:     	mov	x20, #-0x1              ; =-1
102d0cec0:     	ldaddl	x20, x8, [x23]
102d0cec4:     	cmp	x8, #0x1
102d0cec8:     	b.ne	0x102d0ced8 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x260>
102d0cecc:     	dmb	ishld
102d0ced0:     	add	x0, sp, #0x70
102d0ced4:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
102d0ced8:     	ldr	x8, [sp, #0x60]
102d0cedc:     	ldaddl	x20, x8, [x8]
102d0cee0:     	cmp	x8, #0x1
102d0cee4:     	b.ne	0x102d0cef4 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x27c>
102d0cee8:     	dmb	ishld
102d0ceec:     	add	x0, sp, #0x60
102d0cef0:     	bl	0x102d66318 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcSNtNtNtCskIfnrfrMWVM_9mech_core11type_system14resolved_value23ResolvedValueDescriptorE9drop_slowBN_>
102d0cef4:     	add	x0, sp, #0x18
102d0cef8:     	bl	0x102cf4dfc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization27ResolvedOperationDescriptorEBM_>
102d0cefc:     	b	0x102d0cf44 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2cc>
102d0cf00:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102d0cf04:     	mov	x19, x0
102d0cf08:     	cbnz	x27, 0x102d0cf14 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x29c>
102d0cf0c:     	mov	x0, x19
102d0cf10:     	b	0x102d0cf2c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
102d0cf14:     	mov	x0, x23
102d0cf18:     	mov	x1, x24
102d0cf1c:     	mov	w2, #0x1                ; =1
102d0cf20:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d0cf24:     	mov	x0, x19
102d0cf28:     	b	0x102d0cf2c <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2b4>
102d0cf2c:     	cbz	x21, 0x102d0cf48 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone+0x2d0>
102d0cf30:     	mov	x19, x0
102d0cf34:     	ldr	x0, [sp, #0x10]
102d0cf38:     	mov	x1, x21
102d0cf3c:     	mov	w2, #0x1                ; =1
102d0cf40:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102d0cf44:     	mov	x0, x19
102d0cf48:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
