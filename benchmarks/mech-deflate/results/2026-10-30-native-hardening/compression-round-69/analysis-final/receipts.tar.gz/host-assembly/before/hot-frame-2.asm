
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014b00c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_>:
1014b00c8:     	sub	sp, sp, #0x150
1014b00cc:     	stp	x28, x27, [sp, #0xf0]
1014b00d0:     	stp	x26, x25, [sp, #0x100]
1014b00d4:     	stp	x24, x23, [sp, #0x110]
1014b00d8:     	stp	x22, x21, [sp, #0x120]
1014b00dc:     	stp	x20, x19, [sp, #0x130]
1014b00e0:     	stp	x29, x30, [sp, #0x140]
1014b00e4:     	add	x29, sp, #0x140
1014b00e8:     	mov	x21, x2
1014b00ec:     	mov	x24, x1
1014b00f0:     	str	x8, [sp, #0x40]
1014b00f4:     	ldr	x8, [x0, #0x8]
1014b00f8:     	str	x0, [sp, #0x50]
1014b00fc:     	cbz	x8, 0x1014b028c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1c4>
1014b0100:     	ldr	x20, [x0]
1014b0104:     	lsl	x22, x8, #2
1014b0108:     	ldp	x8, x19, [x24, #0x10]
1014b010c:     	add	x10, x8, #0x10
1014b0110:     	ldp	x25, x8, [x21]
1014b0114:     	ldp	x9, x11, [x21, #0x28]
1014b0118:     	stp	x11, x9, [sp, #0x28]
1014b011c:     	ldp	x9, x11, [x21, #0x10]
1014b0120:     	str	x11, [sp, #0x38]
1014b0124:     	stp	x10, x9, [sp, #0x18]
1014b0128:     	stp	x8, x19, [sp, #0x8]
1014b012c:     	add	x26, x8, #0x1
1014b0130:     	mov	w8, #0x2c               ; =44
1014b0134:     	ldr	w23, [x20], #0x4
1014b0138:     	cmp	x19, x23
1014b013c:     	b.ls	0x1014b05f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014b0140:     	strb	w8, [sp, #0x90]
1014b0144:     	add	x0, sp, #0x90
1014b0148:     	bl	0x1014b3524 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014b014c:     	sub	x26, x26, #0x1
1014b0150:     	cbz	x26, 0x1014b0678 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5b0>
1014b0154:     	ldrb	w8, [x25]
1014b0158:     	cmp	w8, #0x3
1014b015c:     	b.ne	0x1014b0190 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0xc8>
1014b0160:     	ldr	x0, [x25, #0x8]
1014b0164:     	ldr	x8, [sp, #0x38]
1014b0168:     	cmp	x0, x8
1014b016c:     	b.hs	0x1014b06bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5f4>
1014b0170:     	ldr	x8, [sp, #0x30]
1014b0174:     	cmp	x0, x8
1014b0178:     	b.hs	0x1014b06cc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x604>
1014b017c:     	lsl	x8, x0, #6
1014b0180:     	ldr	x9, [sp, #0x20]
1014b0184:     	ldr	x8, [x9, x8]
1014b0188:     	cbnz	x8, 0x1014b01c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x100>
1014b018c:     	b	0x1014b01d0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014b0190:     	ldp	q0, q1, [x25]
1014b0194:     	stp	q0, q1, [sp, #0x90]
1014b0198:     	ldr	x8, [sp, #0x28]
1014b019c:     	ldr	x8, [x8]
1014b01a0:     	ldr	x1, [x8]
1014b01a4:     	add	x0, sp, #0x68
1014b01a8:     	add	x2, sp, #0x90
1014b01ac:     	bl	0x1014b6e58 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014b01b0:     	ldr	x8, [sp, #0x68]
1014b01b4:     	cmp	x8, #0x1
1014b01b8:     	b.ne	0x1014b01d0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014b01bc:     	ldr	x8, [sp, #0x70]
1014b01c0:     	cbz	x8, 0x1014b01d0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014b01c4:     	ldr	x8, [x8]
1014b01c8:     	ldp	x19, x28, [x8, #0x10]
1014b01cc:     	b	0x1014b01d8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x110>
1014b01d0:     	mov	x28, #0x0               ; =0
1014b01d4:     	mov	w19, #0x8               ; =8
1014b01d8:     	mov	x1, x27
1014b01dc:     	lsl	x27, x28, #3
1014b01e0:     	lsr	x8, x28, #61
1014b01e4:     	cmp	x8, #0x0
1014b01e8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1014b01ec:     	ccmp	x27, x8, #0x2, eq
1014b01f0:     	b.hi	0x1014b02b8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1f0>
1014b01f4:     	str	x24, [sp, #0x48]
1014b01f8:     	cbz	x27, 0x1014b0230 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x168>
1014b01fc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014b0200:     	mov	x0, x27
1014b0204:     	mov	w1, #0x8                ; =8
1014b0208:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1014b020c:     	cbz	x0, 0x1014b06dc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x614>
1014b0210:     	mov	x24, x0
1014b0214:     	cbz	x28, 0x1014b0228 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x160>
1014b0218:     	mov	x0, x24
1014b021c:     	mov	x1, x19
1014b0220:     	mov	x2, x27
1014b0224:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1014b0228:     	mov	x27, x24
1014b022c:     	b	0x1014b0238 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x170>
1014b0230:     	mov	w27, #0x8               ; =8
1014b0234:     	mov	w24, #0x8               ; =8
1014b0238:     	ldr	x8, [sp, #0x18]
1014b023c:     	add	x0, x8, x23, lsl #7
1014b0240:     	add	x8, sp, #0x90
1014b0244:     	mov	x1, x24
1014b0248:     	mov	x2, x28
1014b024c:     	bl	0x102dad340 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
1014b0250:     	ldr	x8, [sp, #0x90]
1014b0254:     	cmp	x8, #0x1e
1014b0258:     	b.ne	0x1014b05d4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x50c>
1014b025c:     	ldr	x8, [sp, #0xa0]
1014b0260:     	cbz	x8, 0x1014b0274 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1ac>
1014b0264:     	ldr	x0, [sp, #0x98]
1014b0268:     	lsl	x1, x8, #3
1014b026c:     	mov	w2, #0x8                ; =8
1014b0270:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014b0274:     	add	x25, x25, #0x20
1014b0278:     	sub	x22, x22, #0x4
1014b027c:     	ldp	x24, x0, [sp, #0x48]
1014b0280:     	ldr	x19, [sp, #0x10]
1014b0284:     	mov	w8, #0x2c               ; =44
1014b0288:     	cbnz	x22, 0x1014b0134 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x6c>
1014b028c:     	ldr	x25, [x0, #0x30]
1014b0290:     	lsl	x19, x25, #3
1014b0294:     	lsr	x8, x25, #61
1014b0298:     	cmp	x8, #0x0
1014b029c:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1014b02a0:     	ccmp	x19, x8, #0x2, eq
1014b02a4:     	b.ls	0x1014b02c0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1f8>
1014b02a8:     	mov	x24, #0x0               ; =0
1014b02ac:     	mov	x0, x24
1014b02b0:     	mov	x1, x19
1014b02b4:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014b02b8:     	mov	x0, #0x0                ; =0
1014b02bc:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014b02c0:     	str	x24, [sp, #0x48]
1014b02c4:     	cbz	x19, 0x1014b0300 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x238>
1014b02c8:     	mov	x20, x0
1014b02cc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014b02d0:     	mov	w24, #0x8               ; =8
1014b02d4:     	mov	x0, x19
1014b02d8:     	mov	w1, #0x8                ; =8
1014b02dc:     	bl	0x1000096b8 <__RNvCsfBzVIH1HIC6_7___rustc19___rust_alloc_zeroed>
1014b02e0:     	str	x0, [sp, #0x38]
1014b02e4:     	cbz	x0, 0x1014b02ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1e4>
1014b02e8:     	ldp	x24, x8, [x20, #0x10]
1014b02ec:     	lsl	x9, x8, #6
1014b02f0:     	sub	x9, x9, x8, lsl #3
1014b02f4:     	stp	x25, x9, [sp, #0x18]
1014b02f8:     	cbnz	x8, 0x1014b031c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x254>
1014b02fc:     	b	0x1014b0428 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014b0300:     	mov	w8, #0x8                ; =8
1014b0304:     	str	x8, [sp, #0x38]
1014b0308:     	ldp	x24, x8, [x0, #0x10]
1014b030c:     	lsl	x9, x8, #6
1014b0310:     	sub	x9, x9, x8, lsl #3
1014b0314:     	stp	xzr, x9, [sp, #0x18]
1014b0318:     	cbz	x8, 0x1014b0428 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014b031c:     	ldp	x22, x26, [x21]
1014b0320:     	add	x28, x24, #0x18
1014b0324:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b0328:     	add	x8, x8, #0x608
1014b032c:     	str	x8, [sp, #0x10]
1014b0330:     	ldp	x8, x9, [x21, #0x28]
1014b0334:     	stp	x9, x8, [sp, #0x28]
1014b0338:     	ldr	x20, [sp, #0x20]
1014b033c:     	ldp	x23, x27, [x21, #0x10]
1014b0340:     	b	0x1014b0358 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x290>
1014b0344:     	ldr	x8, [sp, #0x38]
1014b0348:     	str	x1, [x8, x0, lsl #3]
1014b034c:     	add	x28, x28, #0x38
1014b0350:     	subs	x20, x20, #0x38
1014b0354:     	b.eq	0x1014b0428 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014b0358:     	ldr	x0, [x28, #0x18]
1014b035c:     	cmp	x0, x26
1014b0360:     	b.hs	0x1014b06ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5e4>
1014b0364:     	add	x8, x22, x0, lsl #5
1014b0368:     	ldrb	w9, [x8]
1014b036c:     	cmp	w9, #0x3
1014b0370:     	b.ne	0x1014b039c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x2d4>
1014b0374:     	ldr	x0, [x8, #0x8]
1014b0378:     	cmp	x0, x27
1014b037c:     	b.hs	0x1014b068c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5c4>
1014b0380:     	ldr	x8, [sp, #0x30]
1014b0384:     	cmp	x0, x8
1014b0388:     	b.hs	0x1014b069c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5d4>
1014b038c:     	lsl	x8, x0, #6
1014b0390:     	ldr	x19, [x23, x8]
1014b0394:     	cbnz	x19, 0x1014b03d0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x308>
1014b0398:     	b	0x1014b0590 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014b039c:     	ldp	q0, q1, [x8]
1014b03a0:     	stp	q0, q1, [sp, #0x90]
1014b03a4:     	ldr	x8, [sp, #0x28]
1014b03a8:     	ldr	x8, [x8]
1014b03ac:     	ldr	x1, [x8]
1014b03b0:     	add	x0, sp, #0x68
1014b03b4:     	add	x2, sp, #0x90
1014b03b8:     	bl	0x1014b6e58 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014b03bc:     	ldp	x9, x8, [sp, #0x68]
1014b03c0:     	cmp	x9, #0x1
1014b03c4:     	ccmp	x8, #0x0, #0x4, eq
1014b03c8:     	b.eq	0x1014b0590 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014b03cc:     	ldr	x19, [x8]
1014b03d0:     	mov	w8, #0x2c               ; =44
1014b03d4:     	strb	w8, [sp, #0x90]
1014b03d8:     	add	x0, sp, #0x90
1014b03dc:     	bl	0x1014b3524 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014b03e0:     	add	x8, sp, #0x90
1014b03e4:     	add	x0, x19, #0x10
1014b03e8:     	mov	x1, x28
1014b03ec:     	bl	0x102e317a0 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014b03f0:     	ldp	x8, x1, [sp, #0x90]
1014b03f4:     	cmp	x8, #0x1e
1014b03f8:     	b.ne	0x1014b0574 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4ac>
1014b03fc:     	ldur	w8, [x28, #-0x18]
1014b0400:     	cmp	w8, #0x2
1014b0404:     	b.ne	0x1014b034c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x284>
1014b0408:     	ldur	w0, [x28, #-0x14]
1014b040c:     	cmp	x25, x0
1014b0410:     	b.hi	0x1014b0344 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x27c>
1014b0414:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b0418:     	add	x2, x2, #0x5c0
1014b041c:     	mov	x1, x25
1014b0420:     	bl	0x103a06714 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b0424:     	b	0x1014b0724 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x65c>
1014b0428:     	ldp	x9, x8, [sp, #0x48]
1014b042c:     	ldr	w19, [x8, #0x38]
1014b0430:     	ldr	x8, [x9, #0x18]
1014b0434:     	cmp	x8, x19
1014b0438:     	b.ls	0x1014b0590 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014b043c:     	ldr	x20, [x9, #0x10]
1014b0440:     	mov	w8, #0x2c               ; =44
1014b0444:     	strb	w8, [sp, #0x90]
1014b0448:     	add	x0, sp, #0x90
1014b044c:     	bl	0x1014b3524 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014b0450:     	add	x9, x20, x19, lsl #7
1014b0454:     	add	x8, sp, #0x68
1014b0458:     	add	x0, x9, #0x10
1014b045c:     	ldr	x1, [sp, #0x38]
1014b0460:     	mov	x2, x25
1014b0464:     	bl	0x102dad340 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
1014b0468:     	ldr	x8, [sp, #0x68]
1014b046c:     	cmp	x8, #0x1e
1014b0470:     	b.ne	0x1014b05b8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4f0>
1014b0474:     	ldp	x8, x20, [sp, #0x70]
1014b0478:     	str	x8, [sp, #0x38]
1014b047c:     	stp	x8, x20, [sp, #0x58]
1014b0480:     	ldp	x25, x22, [x21]
1014b0484:     	ldp	x28, x9, [x21, #0x28]
1014b0488:     	ldp	x21, x26, [x21, #0x10]
1014b048c:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b0490:     	add	x8, x8, #0x608
1014b0494:     	stp	x8, x9, [sp, #0x48]
1014b0498:     	ldr	x27, [sp, #0x20]
1014b049c:     	cbz	x27, 0x1014b0620 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x558>
1014b04a0:     	ldr	x0, [x24, #0x30]
1014b04a4:     	cmp	x0, x22
1014b04a8:     	b.hs	0x1014b06e8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x620>
1014b04ac:     	add	x8, x25, x0, lsl #5
1014b04b0:     	ldrb	w9, [x8]
1014b04b4:     	cmp	w9, #0x3
1014b04b8:     	b.ne	0x1014b04e0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x418>
1014b04bc:     	ldr	x0, [x8, #0x8]
1014b04c0:     	cmp	x0, x26
1014b04c4:     	b.hs	0x1014b06f0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x628>
1014b04c8:     	cmp	x0, x28
1014b04cc:     	b.hs	0x1014b0704 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x63c>
1014b04d0:     	lsl	x8, x0, #6
1014b04d4:     	ldr	x19, [x21, x8]
1014b04d8:     	cbnz	x19, 0x1014b0518 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x450>
1014b04dc:     	b	0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b04e0:     	ldp	q0, q1, [x8]
1014b04e4:     	stp	q0, q1, [sp, #0x90]
1014b04e8:     	ldr	x8, [sp, #0x50]
1014b04ec:     	ldr	x8, [x8]
1014b04f0:     	ldr	x1, [x8]
1014b04f4:     	sub	x0, x29, #0x70
1014b04f8:     	add	x2, sp, #0x90
1014b04fc:     	bl	0x1014b6e58 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014b0500:     	ldur	x8, [x29, #-0x70]
1014b0504:     	cmp	x8, #0x1
1014b0508:     	b.ne	0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b050c:     	ldur	x8, [x29, #-0x68]
1014b0510:     	cbz	x8, 0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b0514:     	ldr	x19, [x8]
1014b0518:     	mov	w8, #0x2c               ; =44
1014b051c:     	strb	w8, [sp, #0x90]
1014b0520:     	add	x0, sp, #0x90
1014b0524:     	bl	0x1014b3524 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014b0528:     	add	x8, sp, #0x68
1014b052c:     	add	x0, x19, #0x10
1014b0530:     	add	x1, x24, #0x18
1014b0534:     	bl	0x102e317a0 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014b0538:     	ldp	x8, x23, [sp, #0x68]
1014b053c:     	cmp	x8, #0x1e
1014b0540:     	b.ne	0x1014b0628 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x560>
1014b0544:     	add	x8, sp, #0x90
1014b0548:     	add	x0, sp, #0x58
1014b054c:     	mov	x1, x24
1014b0550:     	bl	0x102e317a0 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014b0554:     	ldp	x8, x1, [sp, #0x90]
1014b0558:     	cmp	x8, #0x1e
1014b055c:     	b.ne	0x1014b0644 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x57c>
1014b0560:     	add	x24, x24, #0x38
1014b0564:     	sub	x27, x27, #0x38
1014b0568:     	cmp	x1, x23
1014b056c:     	b.eq	0x1014b049c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x3d4>
1014b0570:     	b	0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b0574:     	and	x8, x8, #0x1e
1014b0578:     	cmp	x8, #0x14
1014b057c:     	b.ne	0x1014b0590 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014b0580:     	cbz	x1, 0x1014b0590 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014b0584:     	ldr	x0, [sp, #0xa0]
1014b0588:     	mov	w2, #0x1                ; =1
1014b058c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014b0590:     	mov	w8, #0x2c               ; =44
1014b0594:     	ldr	x9, [sp, #0x40]
1014b0598:     	strb	w8, [x9]
1014b059c:     	ldr	x8, [sp, #0x18]
1014b05a0:     	cbz	x8, 0x1014b0600 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014b05a4:     	lsl	x1, x8, #3
1014b05a8:     	ldr	x0, [sp, #0x38]
1014b05ac:     	mov	w2, #0x8                ; =8
1014b05b0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014b05b4:     	b	0x1014b0600 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014b05b8:     	and	x8, x8, #0x1e
1014b05bc:     	cmp	x8, #0x14
1014b05c0:     	b.ne	0x1014b05f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014b05c4:     	ldr	x1, [sp, #0x70]
1014b05c8:     	cbz	x1, 0x1014b05f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014b05cc:     	ldr	x0, [sp, #0x78]
1014b05d0:     	b	0x1014b05ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x524>
1014b05d4:     	and	x8, x8, #0x1e
1014b05d8:     	cmp	x8, #0x14
1014b05dc:     	b.ne	0x1014b05f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014b05e0:     	ldr	x1, [sp, #0x98]
1014b05e4:     	cbz	x1, 0x1014b05f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014b05e8:     	ldr	x0, [sp, #0xa0]
1014b05ec:     	mov	w2, #0x1                ; =1
1014b05f0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014b05f4:     	mov	w8, #0x2c               ; =44
1014b05f8:     	ldr	x9, [sp, #0x40]
1014b05fc:     	strb	w8, [x9]
1014b0600:     	ldp	x29, x30, [sp, #0x140]
1014b0604:     	ldp	x20, x19, [sp, #0x130]
1014b0608:     	ldp	x22, x21, [sp, #0x120]
1014b060c:     	ldp	x24, x23, [sp, #0x110]
1014b0610:     	ldp	x26, x25, [sp, #0x100]
1014b0614:     	ldp	x28, x27, [sp, #0xf0]
1014b0618:     	add	sp, sp, #0x150
1014b061c:     	ret
1014b0620:     	mov	w8, #0x2e               ; =46
1014b0624:     	b	0x1014b0664 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x59c>
1014b0628:     	and	x8, x8, #0x1e
1014b062c:     	cmp	x8, #0x14
1014b0630:     	b.ne	0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b0634:     	cbz	x23, 0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b0638:     	ldr	x0, [sp, #0x78]
1014b063c:     	mov	x1, x23
1014b0640:     	b	0x1014b0658 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x590>
1014b0644:     	and	x8, x8, #0x1e
1014b0648:     	cmp	x8, #0x14
1014b064c:     	b.ne	0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b0650:     	cbz	x1, 0x1014b0660 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014b0654:     	ldr	x0, [sp, #0xa0]
1014b0658:     	mov	w2, #0x1                ; =1
1014b065c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014b0660:     	mov	w8, #0x2c               ; =44
1014b0664:     	ldr	x9, [sp, #0x40]
1014b0668:     	strb	w8, [x9]
1014b066c:     	cbz	x20, 0x1014b0600 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014b0670:     	lsl	x1, x20, #3
1014b0674:     	b	0x1014b05a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4e0>
1014b0678:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b067c:     	add	x2, x2, #0x608
1014b0680:     	ldr	x0, [sp, #0x8]
1014b0684:     	mov	x1, x0
1014b0688:     	bl	0x103a06714 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b068c:     	mov	x26, x27
1014b0690:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b0694:     	add	x8, x8, #0x620
1014b0698:     	b	0x1014b06a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5e0>
1014b069c:     	ldr	x26, [sp, #0x30]
1014b06a0:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b06a4:     	add	x8, x8, #0x638
1014b06a8:     	str	x8, [sp, #0x10]
1014b06ac:     	mov	x1, x26
1014b06b0:     	ldr	x2, [sp, #0x10]
1014b06b4:     	bl	0x103a06714 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b06b8:     	b	0x1014b0724 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x65c>
1014b06bc:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b06c0:     	add	x2, x2, #0x620
1014b06c4:     	ldr	x1, [sp, #0x38]
1014b06c8:     	bl	0x103a06714 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b06cc:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b06d0:     	add	x2, x2, #0x638
1014b06d4:     	ldr	x1, [sp, #0x30]
1014b06d8:     	bl	0x103a06714 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b06dc:     	mov	x1, x27
1014b06e0:     	mov	w0, #0x8                ; =8
1014b06e4:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014b06e8:     	str	x20, [sp, #0x18]
1014b06ec:     	b	0x1014b0718 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x650>
1014b06f0:     	str	x20, [sp, #0x18]
1014b06f4:     	mov	x22, x26
1014b06f8:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b06fc:     	add	x8, x8, #0x620
1014b0700:     	b	0x1014b0714 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x64c>
1014b0704:     	str	x20, [sp, #0x18]
1014b0708:     	mov	x22, x28
1014b070c:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b0710:     	add	x8, x8, #0x638
1014b0714:     	str	x8, [sp, #0x48]
1014b0718:     	mov	x1, x22
1014b071c:     	ldr	x2, [sp, #0x48]
1014b0720:     	bl	0x103a06714 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b0724:     	brk	#0x1
1014b0728:     	b	0x1014b0740 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x678>
1014b072c:     	mov	x21, x0
1014b0730:     	str	x20, [sp, #0x18]
1014b0734:     	cbnz	x20, 0x1014b074c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x684>
1014b0738:     	b	0x1014b0760 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x698>
1014b073c:     	b	0x1014b0740 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x678>
1014b0740:     	mov	x21, x0
1014b0744:     	ldr	x8, [sp, #0x18]
1014b0748:     	cbz	x8, 0x1014b0760 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x698>
1014b074c:     	ldr	x8, [sp, #0x18]
1014b0750:     	lsl	x1, x8, #3
1014b0754:     	ldr	x0, [sp, #0x38]
1014b0758:     	mov	w2, #0x8                ; =8
1014b075c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014b0760:     	mov	x0, x21
1014b0764:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
