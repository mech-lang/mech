
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014c38ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_>:
1014c38ec:     	sub	sp, sp, #0xd0
1014c38f0:     	stp	x28, x27, [sp, #0x70]
1014c38f4:     	stp	x26, x25, [sp, #0x80]
1014c38f8:     	stp	x24, x23, [sp, #0x90]
1014c38fc:     	stp	x22, x21, [sp, #0xa0]
1014c3900:     	stp	x20, x19, [sp, #0xb0]
1014c3904:     	stp	x29, x30, [sp, #0xc0]
1014c3908:     	add	x29, sp, #0xc0
1014c390c:     	ldrb	w8, [x0, #0x3c]
1014c3910:     	cmp	w8, #0x1
1014c3914:     	b.ne	0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3918:     	ldp	x21, x24, [x0, #0x10]
1014c391c:     	ldp	x9, x8, [x0, #0x20]
1014c3920:     	stp	x9, x8, [sp]
1014c3924:     	ldp	x27, x19, [x1]
1014c3928:     	ldp	x8, x9, [x1, #0x28]
1014c392c:     	stp	x9, x8, [sp, #0x18]
1014c3930:     	ldp	x8, x9, [x1, #0x10]
1014c3934:     	str	x9, [sp, #0x28]
1014c3938:     	str	x8, [sp, #0x10]
1014c393c:     	add	x26, x21, #0x8
1014c3940:     	lsl	x8, x24, #6
1014c3944:     	sub	x20, x8, x24, lsl #3
1014c3948:     	mov	x23, x21
1014c394c:     	b	0x1014c3984 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x98>
1014c3950:     	add	x8, sp, #0x30
1014c3954:     	add	x0, x9, #0x10
1014c3958:     	add	x1, x25, #0x18
1014c395c:     	bl	0x102d644bc <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c3960:     	ldr	x8, [sp, #0x30]
1014c3964:     	cmp	x8, #0x1e
1014c3968:     	b.ne	0x1014c3b10 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x224>
1014c396c:     	ldr	x8, [sp, #0x38]
1014c3970:     	add	x23, x23, #0x38
1014c3974:     	add	x26, x26, #0x38
1014c3978:     	sub	x20, x20, #0x38
1014c397c:     	cmp	x8, x28
1014c3980:     	b.ne	0x1014c3b34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c3984:     	cmp	x20, #0x0
1014c3988:     	cset	w22, eq
1014c398c:     	cbz	x20, 0x1014c3b34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c3990:     	ldr	x0, [x23, #0x30]
1014c3994:     	cmp	x0, x19
1014c3998:     	b.hs	0x1014c3b58 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x26c>
1014c399c:     	add	x8, x27, x0, lsl #5
1014c39a0:     	ldrb	w9, [x8]
1014c39a4:     	cmp	w9, #0x3
1014c39a8:     	b.ne	0x1014c39dc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0xf0>
1014c39ac:     	ldr	x0, [x8, #0x8]
1014c39b0:     	ldr	x8, [sp, #0x28]
1014c39b4:     	cmp	x0, x8
1014c39b8:     	b.hs	0x1014c3b68 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x27c>
1014c39bc:     	ldr	x8, [sp, #0x20]
1014c39c0:     	cmp	x0, x8
1014c39c4:     	b.hs	0x1014c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x28c>
1014c39c8:     	lsl	x8, x0, #6
1014c39cc:     	ldr	x9, [sp, #0x10]
1014c39d0:     	ldr	x9, [x9, x8]
1014c39d4:     	cbnz	x9, 0x1014c3a14 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x128>
1014c39d8:     	b	0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c39dc:     	ldp	q0, q1, [x8]
1014c39e0:     	stp	q0, q1, [sp, #0x30]
1014c39e4:     	ldr	x8, [sp, #0x18]
1014c39e8:     	ldr	x8, [x8]
1014c39ec:     	ldr	x1, [x8]
1014c39f0:     	add	x0, sp, #0x58
1014c39f4:     	add	x2, sp, #0x30
1014c39f8:     	bl	0x1014cb71c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c39fc:     	ldr	x8, [sp, #0x58]
1014c3a00:     	cmp	x8, #0x1
1014c3a04:     	b.ne	0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3a08:     	ldr	x8, [sp, #0x60]
1014c3a0c:     	cbz	x8, 0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3a10:     	ldr	x9, [x8]
1014c3a14:     	add	x8, sp, #0x30
1014c3a18:     	add	x0, x9, #0x10
1014c3a1c:     	add	x1, x23, #0x18
1014c3a20:     	bl	0x102d644bc <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c3a24:     	ldr	x8, [sp, #0x30]
1014c3a28:     	cmp	x8, #0x1e
1014c3a2c:     	b.ne	0x1014c3b10 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x224>
1014c3a30:     	ldr	x28, [sp, #0x38]
1014c3a34:     	ldr	w8, [x23]
1014c3a38:     	cmp	w8, #0x2
1014c3a3c:     	b.eq	0x1014c3a60 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x174>
1014c3a40:     	cmp	w8, #0x1
1014c3a44:     	b.ne	0x1014c3b34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c3a48:     	ldr	x8, [x26], #0x38
1014c3a4c:     	add	x23, x23, #0x38
1014c3a50:     	sub	x20, x20, #0x38
1014c3a54:     	cmp	x8, x28
1014c3a58:     	b.eq	0x1014c3984 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x98>
1014c3a5c:     	b	0x1014c3b34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c3a60:     	ldur	w8, [x26, #-0x4]
1014c3a64:     	ldr	x9, [sp, #0x8]
1014c3a68:     	cmp	x9, x8
1014c3a6c:     	b.ls	0x1014c3b34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c3a70:     	ldr	x9, [sp]
1014c3a74:     	ldr	x8, [x9, x8, lsl #3]
1014c3a78:     	cmp	x8, x24
1014c3a7c:     	b.hs	0x1014c3b34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c3a80:     	mov	w9, #0x38               ; =56
1014c3a84:     	madd	x25, x8, x9, x21
1014c3a88:     	ldr	x0, [x25, #0x30]
1014c3a8c:     	cmp	x0, x19
1014c3a90:     	b.hs	0x1014c3b58 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x26c>
1014c3a94:     	add	x8, x27, x0, lsl #5
1014c3a98:     	ldrb	w9, [x8]
1014c3a9c:     	cmp	w9, #0x3
1014c3aa0:     	b.ne	0x1014c3ad4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x1e8>
1014c3aa4:     	ldr	x0, [x8, #0x8]
1014c3aa8:     	ldr	x8, [sp, #0x28]
1014c3aac:     	cmp	x0, x8
1014c3ab0:     	b.hs	0x1014c3b68 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x27c>
1014c3ab4:     	ldr	x8, [sp, #0x20]
1014c3ab8:     	cmp	x0, x8
1014c3abc:     	b.hs	0x1014c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x28c>
1014c3ac0:     	lsl	x8, x0, #6
1014c3ac4:     	ldr	x9, [sp, #0x10]
1014c3ac8:     	ldr	x9, [x9, x8]
1014c3acc:     	cbnz	x9, 0x1014c3950 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x64>
1014c3ad0:     	b	0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3ad4:     	ldp	q0, q1, [x8]
1014c3ad8:     	stp	q0, q1, [sp, #0x30]
1014c3adc:     	ldr	x8, [sp, #0x18]
1014c3ae0:     	ldr	x8, [x8]
1014c3ae4:     	ldr	x1, [x8]
1014c3ae8:     	add	x0, sp, #0x58
1014c3aec:     	add	x2, sp, #0x30
1014c3af0:     	bl	0x1014cb71c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c3af4:     	ldr	x8, [sp, #0x58]
1014c3af8:     	cmp	x8, #0x1
1014c3afc:     	b.ne	0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3b00:     	ldr	x8, [sp, #0x60]
1014c3b04:     	cbz	x8, 0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3b08:     	ldr	x9, [x8]
1014c3b0c:     	b	0x1014c3950 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x64>
1014c3b10:     	and	x8, x8, #0x1e
1014c3b14:     	cmp	x8, #0x14
1014c3b18:     	b.ne	0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3b1c:     	ldr	x1, [sp, #0x38]
1014c3b20:     	cbz	x1, 0x1014c3b30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c3b24:     	ldr	x0, [sp, #0x40]
1014c3b28:     	mov	w2, #0x1                ; =1
1014c3b2c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c3b30:     	mov	w22, #0x0               ; =0
1014c3b34:     	mov	x0, x22
1014c3b38:     	ldp	x29, x30, [sp, #0xc0]
1014c3b3c:     	ldp	x20, x19, [sp, #0xb0]
1014c3b40:     	ldp	x22, x21, [sp, #0xa0]
1014c3b44:     	ldp	x24, x23, [sp, #0x90]
1014c3b48:     	ldp	x26, x25, [sp, #0x80]
1014c3b4c:     	ldp	x28, x27, [sp, #0x70]
1014c3b50:     	add	sp, sp, #0xd0
1014c3b54:     	ret
1014c3b58:     	adrp	x2, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c3b5c:     	add	x2, x2, #0x728
1014c3b60:     	mov	x1, x19
1014c3b64:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c3b68:     	adrp	x2, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c3b6c:     	add	x2, x2, #0x740
1014c3b70:     	ldr	x1, [sp, #0x28]
1014c3b74:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c3b78:     	adrp	x2, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c3b7c:     	add	x2, x2, #0x758
1014c3b80:     	ldr	x1, [sp, #0x20]
1014c3b84:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
