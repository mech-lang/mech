
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010155166c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>:
10155166c:     	stp	x28, x27, [sp, #-0x60]!
101551670:     	stp	x26, x25, [sp, #0x10]
101551674:     	stp	x24, x23, [sp, #0x20]
101551678:     	stp	x22, x21, [sp, #0x30]
10155167c:     	stp	x20, x19, [sp, #0x40]
101551680:     	stp	x29, x30, [sp, #0x50]
101551684:     	add	x29, sp, #0x50
101551688:     	sub	sp, sp, #0x4c0
10155168c:     	str	xzr, [sp]
101551690:     	ldr	x27, [x1, #0x498]
101551694:     	ldr	x8, [x27, #0x4a0]
101551698:     	cmp	x2, x8
10155169c:     	b.hs	0x101551768 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
1015516a0:     	mov	x22, x5
1015516a4:     	mov	x23, x4
1015516a8:     	mov	x20, x2
1015516ac:     	mov	x21, x1
1015516b0:     	add	x26, sp, #0x400
1015516b4:     	ldr	x8, [x27, #0x498]
1015516b8:     	mov	w9, #0x28               ; =40
1015516bc:     	madd	x24, x2, x9, x8
1015516c0:     	ldr	w8, [x24]
1015516c4:     	cmp	w8, #0x1
1015516c8:     	b.gt	0x10155174c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe0>
1015516cc:     	cbnz	w8, 0x10155177c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x110>
1015516d0:     	cbnz	x3, 0x1015519d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015516d4:     	ldr	x1, [x27, #0x380]
1015516d8:     	cmp	x20, x1
1015516dc:     	b.hs	0x1015529ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1380>
1015516e0:     	ldr	x8, [x27, #0x378]
1015516e4:     	mov	w9, #0x170              ; =368
1015516e8:     	madd	x8, x20, x9, x8
1015516ec:     	ldp	x10, x9, [x8]
1015516f0:     	cmp	x10, #0x2
1015516f4:     	sbcs	xzr, x9, xzr
1015516f8:     	b.hs	0x101551ba4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x538>
1015516fc:     	ldr	w9, [x8, #0x130]
101551700:     	ldr	w10, [x24, #0x4]
101551704:     	cmp	w9, w10
101551708:     	b.ne	0x101551bc0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
10155170c:     	ldr	x9, [x8, #0x128]
101551710:     	cmp	x22, x9
101551714:     	b.ne	0x101551bc0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
101551718:     	stp	x24, x0, [sp, #0x38]
10155171c:     	add	x9, x27, #0x488
101551720:     	ldr	x8, [x8, #0x120]
101551724:     	str	x8, [sp, #0x30]
101551728:     	lsl	x8, x22, #2
10155172c:     	stp	x8, x9, [sp, #0x18]
101551730:     	cbz	x22, 0x101551d98 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
101551734:     	mov	x10, #0x0               ; =0
101551738:     	mov	x25, #0x0               ; =0
10155173c:     	ldr	x24, [x21, #0x490]
101551740:     	ldr	x26, [sp, #0x18]
101551744:     	str	x24, [sp, #0x28]
101551748:     	b	0x101551808 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x19c>
10155174c:     	cmp	w8, #0x2
101551750:     	b.ne	0x101551768 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
101551754:     	cbz	x3, 0x1015519bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
101551758:     	cmp	x3, #0x12
10155175c:     	b.ne	0x1015519d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
101551760:     	cbnz	x22, 0x1015519d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
101551764:     	b	0x101551a2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
101551768:     	mov	w8, #0x2                ; =2
10155176c:     	str	x8, [x0, #0x8]
101551770:     	mov	w8, #0x6                ; =6
101551774:     	str	w8, [x0]
101551778:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10155177c:     	cmp	x3, #0x1
101551780:     	b.ne	0x1015519d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
101551784:     	cbnz	x22, 0x1015519d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
101551788:     	mov	x19, x0
10155178c:     	add	x0, sp, #0x400
101551790:     	mov	x1, x21
101551794:     	mov	x2, x20
101551798:     	bl	0x101564c88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
10155179c:     	ldr	w8, [sp, #0x400]
1015517a0:     	cmp	w8, #0x1
1015517a4:     	b.ne	0x101551a0c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3a0>
1015517a8:     	ldr	w3, [sp, #0x404]
1015517ac:     	ldr	w4, [sp, #0x408]
1015517b0:     	ldp	w8, w9, [x24, #0x4]
1015517b4:     	cmp	w3, w8
1015517b8:     	ccmp	w4, w9, #0x0, eq
1015517bc:     	mov	x11, x19
1015517c0:     	b.eq	0x101551bdc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x570>
1015517c4:     	str	wzr, [x11]
1015517c8:     	mov	w8, #0xc                ; =12
1015517cc:     	strb	w8, [x11, #0x8]
1015517d0:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015517d4:     	add	x8, x8, #0x953
1015517d8:     	mov	w9, #0x2e               ; =46
1015517dc:     	stp	x8, x9, [x11, #0x10]
1015517e0:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015517e4:     	ldp	q0, q1, [sp, #0x2f0]
1015517e8:     	ldp	q2, q3, [sp, #0x310]
1015517ec:     	stp	q2, q3, [x24, #0x20]
1015517f0:     	stp	q0, q1, [x24]
1015517f4:     	add	x10, x19, #0x40
1015517f8:     	add	x25, x25, #0x1
1015517fc:     	subs	x26, x26, #0x4
101551800:     	ldr	x24, [sp, #0x28]
101551804:     	b.eq	0x101551d98 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
101551808:     	str	x26, [sp, #0x48]
10155180c:     	ldr	x8, [x27, #0x360]
101551810:     	ldr	x9, [sp, #0x30]
101551814:     	ldr	w1, [x9, x25, lsl #2]
101551818:     	cmp	x8, x1
10155181c:     	b.ls	0x1015529d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
101551820:     	ldr	x8, [x27, #0x358]
101551824:     	mov	w9, #0x140              ; =320
101551828:     	umaddl	x8, w1, w9, x8
10155182c:     	ldrb	w9, [x8, #0x124]
101551830:     	cmp	w9, #0x7
101551834:     	b.ne	0x101551900 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x294>
101551838:     	cmp	x25, x22
10155183c:     	b.hs	0x1015529fc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1390>
101551840:     	ldr	x8, [x23, x25, lsl #3]
101551844:     	cbnz	x8, 0x101551f54 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8e8>
101551848:     	ldr	x8, [x27, #0x490]
10155184c:     	cmp	x8, x1
101551850:     	b.ls	0x101551888 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
101551854:     	ldr	x8, [sp, #0x20]
101551858:     	ldr	x8, [x8]
10155185c:     	mov	w9, #0x18               ; =24
101551860:     	umaddl	x8, w1, w9, x8
101551864:     	ldr	x9, [x8]
101551868:     	cmp	x9, #0x1
10155186c:     	b.ne	0x101551888 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
101551870:     	ldp	x8, x9, [x8, #0x8]
101551874:     	adds	x8, x8, x9
101551878:     	b.hs	0x101551888 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
10155187c:     	ldr	x9, [x27, #0x4b0]
101551880:     	cmp	x8, x9
101551884:     	b.ls	0x101551950 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
101551888:     	mov	x26, x10
10155188c:     	add	x8, sp, #0x400
101551890:     	add	x0, x24, #0xf0
101551894:     	add	x2, x24, #0x2f8
101551898:     	bl	0x10156d704 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10155189c:     	ldr	x8, [sp, #0x400]
1015518a0:     	add	x9, sp, #0x400
1015518a4:     	ldur	q0, [x9, #0x8]
1015518a8:     	ldur	q1, [x9, #0x18]
1015518ac:     	stp	q0, q1, [sp, #0x50]
1015518b0:     	ldur	q0, [x9, #0x28]
1015518b4:     	str	q0, [sp, #0x70]
1015518b8:     	ldur	x9, [x9, #0x38]
1015518bc:     	str	x9, [sp, #0x80]
1015518c0:     	cbz	x8, 0x101551f94 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x928>
1015518c4:     	mov	w19, #0x0               ; =0
1015518c8:     	ldp	q0, q1, [sp, #0x50]
1015518cc:     	add	x10, sp, #0x2f0
1015518d0:     	stur	q0, [x10, #0x8]
1015518d4:     	stur	q1, [x10, #0x18]
1015518d8:     	ldr	q0, [sp, #0x70]
1015518dc:     	stur	q0, [x10, #0x28]
1015518e0:     	ldr	x9, [sp, #0x80]
1015518e4:     	stur	x9, [x10, #0x38]
1015518e8:     	mov	x10, x26
1015518ec:     	str	x8, [sp, #0x2f0]
1015518f0:     	ldr	x1, [x24, #0xd8]
1015518f4:     	cmp	x25, x1
1015518f8:     	b.lo	0x101551968 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
1015518fc:     	b	0x1015519a8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
101551900:     	cmp	x25, x22
101551904:     	b.hs	0x101552a10 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13a4>
101551908:     	ldr	x8, [x23, x25, lsl #3]
10155190c:     	cmp	w9, #0x3
101551910:     	b.gt	0x10155192c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2c0>
101551914:     	sub	w9, w9, #0x1
101551918:     	cmp	w9, #0x3
10155191c:     	b.lo	0x101551950 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
101551920:     	cmp	x8, #0x2
101551924:     	b.lo	0x101551950 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
101551928:     	b	0x101551fe4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10155192c:     	cmp	w9, #0x4
101551930:     	b.eq	0x101551948 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2dc>
101551934:     	cmp	w9, #0x5
101551938:     	b.ne	0x10155198c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x320>
10155193c:     	cmp	x8, #0x10, lsl #12      ; =0x10000
101551940:     	b.lo	0x101551950 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
101551944:     	b	0x101551fe4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
101551948:     	cmp	x8, #0x100
10155194c:     	b.hs	0x101551fe4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
101551950:     	mov	x8, #0x0                ; =0
101551954:     	mov	w19, #0x1               ; =1
101551958:     	str	x8, [sp, #0x2f0]
10155195c:     	ldr	x1, [x24, #0xd8]
101551960:     	cmp	x25, x1
101551964:     	b.hs	0x1015519a8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
101551968:     	ldr	x28, [x24, #0xd0]
10155196c:     	add	x24, x28, x10
101551970:     	ldr	x8, [x24]
101551974:     	mov	x19, x10
101551978:     	ldr	x26, [sp, #0x48]
10155197c:     	cbz	x8, 0x1015517e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
101551980:     	add	x0, x28, x19
101551984:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101551988:     	b	0x1015517e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
10155198c:     	lsr	x8, x8, #32
101551990:     	cbnz	x8, 0x101551fe4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
101551994:     	mov	w19, #0x1               ; =1
101551998:     	str	x8, [sp, #0x2f0]
10155199c:     	ldr	x1, [x24, #0xd8]
1015519a0:     	cmp	x25, x1
1015519a4:     	b.lo	0x101551968 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
1015519a8:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
1015519ac:     	add	x2, x2, #0x300
1015519b0:     	mov	x0, x25
1015519b4:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015519b8:     	b	0x101552ad0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015519bc:     	cmp	x22, #0x2
1015519c0:     	b.ne	0x1015519d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015519c4:     	ldp	x9, x8, [x23]
1015519c8:     	orr	x8, x9, x8
1015519cc:     	cbz	x8, 0x101551a2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
1015519d0:     	str	wzr, [x0]
1015519d4:     	mov	w8, #0xc                ; =12
1015519d8:     	strb	w8, [x0, #0x8]
1015519dc:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015519e0:     	add	x8, x8, #0xa86
1015519e4:     	mov	w9, #0x34               ; =52
1015519e8:     	stp	x8, x9, [x0, #0x10]
1015519ec:     	add	sp, sp, #0x4c0
1015519f0:     	ldp	x29, x30, [sp, #0x50]
1015519f4:     	ldp	x20, x19, [sp, #0x40]
1015519f8:     	ldp	x22, x21, [sp, #0x30]
1015519fc:     	ldp	x24, x23, [sp, #0x20]
101551a00:     	ldp	x26, x25, [sp, #0x10]
101551a04:     	ldp	x28, x27, [sp], #0x60
101551a08:     	ret
101551a0c:     	str	wzr, [x19]
101551a10:     	mov	w8, #0xc                ; =12
101551a14:     	str	w8, [x19, #0x8]
101551a18:     	adrp	x8, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101551a1c:     	add	x8, x8, #0xa4e
101551a20:     	mov	w9, #0x27               ; =39
101551a24:     	stp	x8, x9, [x19, #0x10]
101551a28:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551a2c:     	ldr	x1, [x27, #0x380]
101551a30:     	cmp	x20, x1
101551a34:     	b.hs	0x101552a24 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13b8>
101551a38:     	stp	x24, x0, [sp, #0x38]
101551a3c:     	ldr	x8, [x27, #0x378]
101551a40:     	mov	w9, #0x170              ; =368
101551a44:     	madd	x26, x20, x9, x8
101551a48:     	cbz	x3, 0x101551d0c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6a0>
101551a4c:     	cmp	x3, #0x12
101551a50:     	b.ne	0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551a54:     	ldp	x9, x8, [x26]
101551a58:     	eor	x9, x9, #0x3
101551a5c:     	orr	x8, x9, x8
101551a60:     	cbnz	x8, 0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551a64:     	ldr	w22, [x26, #0x28]
101551a68:     	ldr	x8, [sp, #0x38]
101551a6c:     	ldr	w8, [x8, #0x4]
101551a70:     	cmp	w22, w8
101551a74:     	b.ne	0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551a78:     	ldr	w24, [x26, #0x2c]
101551a7c:     	ldr	x8, [sp, #0x38]
101551a80:     	ldr	w8, [x8, #0x8]
101551a84:     	cmp	w24, w8
101551a88:     	b.ne	0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551a8c:     	mov	x25, #0x0               ; =0
101551a90:     	mov	w28, #0x3               ; =3
101551a94:     	add	x0, x27, #0x488
101551a98:     	mov	x1, x22
101551a9c:     	bl	0x101564bd4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
101551aa0:     	cbz	x0, 0x101551f70 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
101551aa4:     	ldr	x8, [sp, #0x38]
101551aa8:     	ldr	x23, [x8, #0x10]
101551aac:     	cmp	x23, x1
101551ab0:     	b.hs	0x101551f70 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
101551ab4:     	add	x8, x0, x23, lsl #5
101551ab8:     	ldrb	w9, [x8]
101551abc:     	cmp	w9, #0x2
101551ac0:     	b.ne	0x101552198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
101551ac4:     	ldp	x8, x9, [x8, #0x8]
101551ac8:     	adds	x8, x8, x9
101551acc:     	b.hs	0x101552198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
101551ad0:     	ldr	x9, [x27, #0x4b0]
101551ad4:     	cmp	x8, x9
101551ad8:     	b.hi	0x101552198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
101551adc:     	cmp	x28, #0x2
101551ae0:     	sbcs	xzr, x25, xzr
101551ae4:     	b.hs	0x101552300 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc94>
101551ae8:     	ldr	x1, [x26, #0x128]
101551aec:     	cmp	x1, #0x1
101551af0:     	b.ls	0x101552a9c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1430>
101551af4:     	ldr	x8, [x26, #0x120]
101551af8:     	ldr	x25, [x21, #0x490]
101551afc:     	ldr	w1, [x8, #0x4]
101551b00:     	add	x8, sp, #0x400
101551b04:     	add	x0, x25, #0xf0
101551b08:     	add	x2, x25, #0x2f8
101551b0c:     	bl	0x10156d704 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101551b10:     	add	x8, sp, #0x400
101551b14:     	ldur	q0, [x8, #0x8]
101551b18:     	ldur	q1, [x8, #0x18]
101551b1c:     	stp	q0, q1, [sp, #0x150]
101551b20:     	ldur	q0, [x8, #0x28]
101551b24:     	str	q0, [sp, #0x170]
101551b28:     	ldr	x8, [sp, #0x400]
101551b2c:     	ldr	x9, [sp, #0x438]
101551b30:     	str	x9, [sp, #0x180]
101551b34:     	cbz	x8, 0x101552408 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd9c>
101551b38:     	ldp	q0, q1, [sp, #0x150]
101551b3c:     	add	x9, sp, #0x230
101551b40:     	stur	q0, [x9, #0x48]
101551b44:     	stur	q1, [x9, #0x58]
101551b48:     	ldr	q0, [sp, #0x170]
101551b4c:     	stur	q0, [x9, #0x68]
101551b50:     	ldr	x9, [sp, #0x180]
101551b54:     	str	x9, [sp, #0x2a8]
101551b58:     	str	x8, [sp, #0x270]
101551b5c:     	ldr	x1, [x27, #0x408]
101551b60:     	cmp	x20, x1
101551b64:     	b.hs	0x101552ac0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1454>
101551b68:     	ldr	x8, [x27, #0x400]
101551b6c:     	add	x23, x8, x20, lsl #9
101551b70:     	ldp	x9, x8, [x23]
101551b74:     	eor	x9, x9, #0x2
101551b78:     	orr	x8, x9, x8
101551b7c:     	cbnz	x8, 0x101552428 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xdbc>
101551b80:     	ldr	x10, [sp, #0x40]
101551b84:     	str	wzr, [x10]
101551b88:     	mov	w8, #0xc                ; =12
101551b8c:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101551b90:     	add	x9, x9, #0xa95
101551b94:     	stp	x8, x9, [x10, #0x8]
101551b98:     	mov	w8, #0x23               ; =35
101551b9c:     	str	x8, [x10, #0x18]
101551ba0:     	b	0x1015528b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
101551ba4:     	str	wzr, [x0]
101551ba8:     	mov	w8, #0xc                ; =12
101551bac:     	strb	w8, [x0, #0x8]
101551bb0:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101551bb4:     	add	x8, x8, #0x92b
101551bb8:     	mov	w9, #0x28               ; =40
101551bbc:     	b	0x1015519e8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
101551bc0:     	str	wzr, [x0]
101551bc4:     	mov	w8, #0xc                ; =12
101551bc8:     	strb	w8, [x0, #0x8]
101551bcc:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101551bd0:     	add	x8, x8, #0x909
101551bd4:     	mov	w9, #0x22               ; =34
101551bd8:     	b	0x1015519e8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
101551bdc:     	ldp	x8, x9, [x24, #0x18]
101551be0:     	lsl	x9, x9, #2
101551be4:     	stp	x24, x11, [sp, #0x38]
101551be8:     	cbz	x9, 0x101551c18 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ac>
101551bec:     	ldr	w10, [x8], #0x4
101551bf0:     	sub	x9, x9, #0x4
101551bf4:     	cmp	w10, w3
101551bf8:     	b.ne	0x101551be8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x57c>
101551bfc:     	ldr	x25, [x21, #0x490]
101551c00:     	add	x0, sp, #0x400
101551c04:     	add	x1, x25, #0x3c0
101551c08:     	add	x2, x27, #0x488
101551c0c:     	add	x5, x25, #0x2f8
101551c10:     	bl	0x1015463f4 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb1_EBb_>
101551c14:     	b	0x101551c30 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5c4>
101551c18:     	ldr	x25, [x21, #0x490]
101551c1c:     	add	x0, sp, #0x400
101551c20:     	add	x1, x25, #0x3c0
101551c24:     	add	x2, x27, #0x488
101551c28:     	add	x5, x25, #0x2f8
101551c2c:     	bl	0x1015460d0 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb0_EBb_>
101551c30:     	ldr	w8, [sp, #0x400]
101551c34:     	cmp	w8, #0x6
101551c38:     	b.ne	0x10155233c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
101551c3c:     	mov	x22, #0x0               ; =0
101551c40:     	ldr	x9, [sp, #0x38]
101551c44:     	ldr	x8, [x9, #0x20]
101551c48:     	cbz	x8, 0x101551d84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
101551c4c:     	ldr	x23, [x9, #0x18]
101551c50:     	lsl	x24, x8, #2
101551c54:     	b	0x101551c60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5f4>
101551c58:     	subs	x24, x24, #0x4
101551c5c:     	b.eq	0x101551d84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
101551c60:     	ldr	w20, [x23], #0x4
101551c64:     	ldr	x1, [x25, #0x3c0]
101551c68:     	add	x0, sp, #0x400
101551c6c:     	add	x2, x27, #0x4d0
101551c70:     	add	x4, x25, #0x2f8
101551c74:     	mov	x3, x20
101551c78:     	bl	0x101550a64 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
101551c7c:     	ldr	w9, [sp, #0x400]
101551c80:     	ldrb	w8, [sp, #0x404]
101551c84:     	cmp	w9, #0x6
101551c88:     	b.ne	0x101551de0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x774>
101551c8c:     	tbnz	w8, #0x0, 0x101551c58 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
101551c90:     	add	x8, sp, #0x400
101551c94:     	add	x0, x25, #0xf0
101551c98:     	add	x2, x25, #0x2f8
101551c9c:     	mov	x1, x20
101551ca0:     	bl	0x10156df84 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
101551ca4:     	ldrb	w8, [sp, #0x400]
101551ca8:     	cmp	w8, #0x14
101551cac:     	b.eq	0x101551c58 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
101551cb0:     	ldr	q0, [sp, #0x400]
101551cb4:     	ldr	q1, [sp, #0x410]
101551cb8:     	stp	q0, q1, [sp, #0x2f0]
101551cbc:     	ldr	q2, [sp, #0x420]
101551cc0:     	str	q2, [sp, #0x310]
101551cc4:     	ldr	x8, [sp, #0x430]
101551cc8:     	str	x8, [sp, #0x320]
101551ccc:     	stur	q0, [x26, #0x4]
101551cd0:     	stur	q1, [x26, #0x14]
101551cd4:     	stur	q2, [x26, #0x24]
101551cd8:     	stur	x8, [x26, #0x34]
101551cdc:     	mov	w8, #0x2                ; =2
101551ce0:     	ldr	x9, [sp, #0x40]
101551ce4:     	str	w8, [x9]
101551ce8:     	ldr	q0, [sp, #0x400]
101551cec:     	ldr	q1, [sp, #0x410]
101551cf0:     	stur	q0, [x9, #0x4]
101551cf4:     	stur	q1, [x9, #0x14]
101551cf8:     	ldr	q0, [sp, #0x420]
101551cfc:     	stur	q0, [x9, #0x24]
101551d00:     	ldur	q0, [x26, #0x2c]
101551d04:     	str	q0, [x9, #0x30]
101551d08:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551d0c:     	ldp	x28, x25, [x26]
101551d10:     	cmp	x28, #0x2
101551d14:     	sbcs	xzr, x25, xzr
101551d18:     	b.hs	0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551d1c:     	ldr	x8, [x26, #0x128]
101551d20:     	cmp	x8, #0x2
101551d24:     	b.ne	0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551d28:     	ldr	x8, [x26, #0x120]
101551d2c:     	ldr	w22, [x8]
101551d30:     	ldr	x8, [sp, #0x38]
101551d34:     	ldr	w8, [x8, #0x4]
101551d38:     	cmp	w22, w8
101551d3c:     	b.ne	0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551d40:     	ldr	w24, [x26, #0x130]
101551d44:     	ldr	x8, [sp, #0x38]
101551d48:     	ldr	w8, [x8, #0x8]
101551d4c:     	cmp	w24, w8
101551d50:     	b.ne	0x101551d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
101551d54:     	ldr	x8, [x26, #0x10]
101551d58:     	cmp	x8, #0xb
101551d5c:     	b.eq	0x101551a94 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x428>
101551d60:     	ldr	x10, [sp, #0x40]
101551d64:     	str	wzr, [x10]
101551d68:     	mov	w8, #0xc                ; =12
101551d6c:     	strb	w8, [x10, #0x8]
101551d70:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101551d74:     	add	x8, x8, #0xa5b
101551d78:     	mov	w9, #0x2b               ; =43
101551d7c:     	stp	x8, x9, [x10, #0x10]
101551d80:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551d84:     	ldr	x9, [sp, #0x40]
101551d88:     	stp	x22, x21, [x9, #0x8]
101551d8c:     	mov	w8, #0x6                ; =6
101551d90:     	str	w8, [x9]
101551d94:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551d98:     	ldr	x1, [x27, #0x408]
101551d9c:     	cmp	x20, x1
101551da0:     	b.hs	0x101552a34 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13c8>
101551da4:     	ldr	x8, [x27, #0x400]
101551da8:     	add	x28, x8, x20, lsl #9
101551dac:     	ldp	x9, x8, [x28]
101551db0:     	eor	x9, x9, #0x2
101551db4:     	orr	x8, x9, x8
101551db8:     	ldr	x19, [sp, #0x40]
101551dbc:     	cbnz	x8, 0x101551e18 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7ac>
101551dc0:     	str	wzr, [x19]
101551dc4:     	mov	w8, #0xc                ; =12
101551dc8:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101551dcc:     	add	x9, x9, #0xa2b
101551dd0:     	stp	x8, x9, [x19, #0x8]
101551dd4:     	mov	w8, #0x23               ; =35
101551dd8:     	str	x8, [x19, #0x18]
101551ddc:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551de0:     	ldur	q0, [x26, #0x15]
101551de4:     	ldr	x10, [sp, #0x40]
101551de8:     	stur	q0, [x10, #0x15]
101551dec:     	ldur	q0, [x26, #0x25]
101551df0:     	stur	q0, [x10, #0x25]
101551df4:     	ldur	q0, [x26, #0x35]
101551df8:     	stur	q0, [x10, #0x35]
101551dfc:     	ldr	q0, [sp, #0x440]
101551e00:     	str	q0, [x10, #0x40]
101551e04:     	ldur	q0, [x26, #0x5]
101551e08:     	stur	q0, [x10, #0x5]
101551e0c:     	str	w9, [x10]
101551e10:     	strb	w8, [x10, #0x4]
101551e14:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551e18:     	add	x24, sp, #0x400
101551e1c:     	add	x8, sp, #0x400
101551e20:     	mov	x0, x21
101551e24:     	mov	w1, #0x0                ; =0
101551e28:     	bl	0x101574b2c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101551e2c:     	ldr	w8, [sp, #0x400]
101551e30:     	tbz	w8, #0x0, 0x101551e64 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7f8>
101551e34:     	ldur	q0, [x24, #0x18]
101551e38:     	ldur	q1, [x24, #0x28]
101551e3c:     	ldur	q2, [x24, #0x38]
101551e40:     	stp	q1, q2, [sp, #0x310]
101551e44:     	ldur	q3, [x24, #0x48]
101551e48:     	str	q3, [sp, #0x330]
101551e4c:     	ldur	q4, [x24, #0x8]
101551e50:     	stp	q4, q0, [sp, #0x2f0]
101551e54:     	stp	q1, q2, [x19, #0x20]
101551e58:     	str	q3, [x19, #0x40]
101551e5c:     	stp	q4, q0, [x19]
101551e60:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551e64:     	ldr	x10, [sp, #0x30]
101551e68:     	ldr	x8, [sp, #0x18]
101551e6c:     	add	x8, x10, x8
101551e70:     	ldur	q0, [x24, #0x48]
101551e74:     	ldur	q1, [x24, #0x58]
101551e78:     	stp	q0, q1, [sp, #0x330]
101551e7c:     	ldur	x9, [x24, #0x68]
101551e80:     	str	x9, [sp, #0x350]
101551e84:     	ldur	q2, [x24, #0x8]
101551e88:     	str	q2, [sp, #0x2f0]
101551e8c:     	ldur	q3, [x24, #0x38]
101551e90:     	ldur	q4, [x24, #0x18]
101551e94:     	ldur	q5, [x24, #0x28]
101551e98:     	stp	q2, q4, [sp, #0x90]
101551e9c:     	stp	q5, q3, [sp, #0xb0]
101551ea0:     	str	x9, [sp, #0xf0]
101551ea4:     	stp	q0, q1, [sp, #0xd0]
101551ea8:     	str	x10, [sp, #0x400]
101551eac:     	str	x8, [sp, #0x408]
101551eb0:     	add	x0, sp, #0x400
101551eb4:     	add	x1, x27, #0x488
101551eb8:     	bl	0x10154d06c <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>
101551ebc:     	ldr	x25, [x21, #0x490]
101551ec0:     	ldr	x2, [x25, #0xd8]
101551ec4:     	cmp	x22, x2
101551ec8:     	add	x26, sp, #0x400
101551ecc:     	tbz	w0, #0x0, 0x101552004 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x998>
101551ed0:     	b.hi	0x10155296c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1300>
101551ed4:     	ldr	x1, [x25, #0xd0]
101551ed8:     	ldp	q0, q1, [x21, #0x80]
101551edc:     	str	q0, [sp, #0x480]
101551ee0:     	str	q1, [sp, #0x490]
101551ee4:     	ldr	x8, [x21, #0xa0]
101551ee8:     	str	x8, [sp, #0x4a0]
101551eec:     	ldp	q0, q1, [x21, #0x40]
101551ef0:     	str	q0, [sp, #0x440]
101551ef4:     	str	q1, [sp, #0x450]
101551ef8:     	ldp	q1, q0, [x21, #0x60]
101551efc:     	str	q0, [sp, #0x470]
101551f00:     	str	q1, [sp, #0x460]
101551f04:     	ldp	q0, q1, [x21]
101551f08:     	str	q0, [sp, #0x400]
101551f0c:     	str	q1, [sp, #0x410]
101551f10:     	ldp	q1, q0, [x21, #0x20]
101551f14:     	add	x8, x25, #0x3b8
101551f18:     	str	q0, [sp, #0x430]
101551f1c:     	str	q1, [sp, #0x420]
101551f20:     	add	x9, sp, #0x90
101551f24:     	stp	x8, x9, [sp, #0x8]
101551f28:     	add	x9, sp, #0x400
101551f2c:     	str	x9, [sp]
101551f30:     	add	x8, sp, #0xf8
101551f34:     	add	x5, x25, #0x3c0
101551f38:     	mov	x0, x28
101551f3c:     	mov	x2, x22
101551f40:     	mov	x3, x23
101551f44:     	mov	x4, x22
101551f48:     	mov	x6, #0x0                ; =0
101551f4c:     	bl	0x10160d474 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>
101551f50:     	b	0x101552074 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa08>
101551f54:     	ldr	x10, [sp, #0x40]
101551f58:     	str	wzr, [x10]
101551f5c:     	mov	w8, #0xc                ; =12
101551f60:     	strb	w8, [x10, #0x8]
101551f64:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101551f68:     	add	x8, x8, #0x8b4
101551f6c:     	b	0x101551d78 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x70c>
101551f70:     	ldr	x10, [sp, #0x40]
101551f74:     	str	wzr, [x10]
101551f78:     	mov	w8, #0xc                ; =12
101551f7c:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101551f80:     	add	x9, x9, #0xa75
101551f84:     	stp	x8, x9, [x10, #0x8]
101551f88:     	mov	w8, #0x20               ; =32
101551f8c:     	str	x8, [x10, #0x18]
101551f90:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551f94:     	ldp	q0, q1, [sp, #0x50]
101551f98:     	add	x9, sp, #0x400
101551f9c:     	stur	q0, [x9, #0x4]
101551fa0:     	stur	q1, [x9, #0x14]
101551fa4:     	ldr	q0, [sp, #0x70]
101551fa8:     	stur	q0, [x9, #0x24]
101551fac:     	ldr	x8, [sp, #0x80]
101551fb0:     	stur	x8, [x9, #0x34]
101551fb4:     	ldr	q0, [sp, #0x400]
101551fb8:     	ldr	q1, [sp, #0x410]
101551fbc:     	ldr	x10, [sp, #0x40]
101551fc0:     	stur	q0, [x10, #0x4]
101551fc4:     	mov	w8, #0x2                ; =2
101551fc8:     	str	w8, [x10]
101551fcc:     	stur	q1, [x10, #0x14]
101551fd0:     	ldr	q0, [sp, #0x420]
101551fd4:     	stur	q0, [x10, #0x24]
101551fd8:     	ldur	q0, [x9, #0x2c]
101551fdc:     	str	q0, [x10, #0x30]
101551fe0:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101551fe4:     	ldr	x10, [sp, #0x40]
101551fe8:     	str	wzr, [x10]
101551fec:     	mov	w8, #0xc                ; =12
101551ff0:     	strb	w8, [x10, #0x8]
101551ff4:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101551ff8:     	add	x8, x8, #0x8df
101551ffc:     	mov	w9, #0x2a               ; =42
101552000:     	b	0x101551d7c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
101552004:     	b.hi	0x101552980 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1314>
101552008:     	ldr	x1, [x25, #0xd0]
10155200c:     	ldp	q0, q1, [x21, #0x80]
101552010:     	str	q0, [sp, #0x480]
101552014:     	str	q1, [sp, #0x490]
101552018:     	ldr	x8, [x21, #0xa0]
10155201c:     	str	x8, [sp, #0x4a0]
101552020:     	ldp	q0, q1, [x21, #0x40]
101552024:     	str	q0, [sp, #0x440]
101552028:     	str	q1, [sp, #0x450]
10155202c:     	ldp	q1, q0, [x21, #0x60]
101552030:     	str	q0, [sp, #0x470]
101552034:     	str	q1, [sp, #0x460]
101552038:     	ldp	q0, q1, [x21]
10155203c:     	str	q0, [sp, #0x400]
101552040:     	str	q1, [sp, #0x410]
101552044:     	ldp	q1, q0, [x21, #0x20]
101552048:     	str	q0, [sp, #0x430]
10155204c:     	str	q1, [sp, #0x420]
101552050:     	add	x8, sp, #0xf8
101552054:     	add	x5, sp, #0x400
101552058:     	add	x6, x25, #0x3b8
10155205c:     	add	x7, sp, #0x90
101552060:     	mov	x0, x28
101552064:     	mov	x2, x22
101552068:     	mov	x3, x23
10155206c:     	mov	x4, x22
101552070:     	bl	0x1026b66e4 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_frame_words>
101552074:     	ldrb	w8, [sp, #0xf8]
101552078:     	cmp	w8, #0x2e
10155207c:     	b.ne	0x10155211c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xab0>
101552080:     	ldr	x2, [x25, #0xd8]
101552084:     	cmp	x22, x2
101552088:     	b.hi	0x101552994 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1328>
10155208c:     	ldr	x6, [x25, #0xd0]
101552090:     	ldp	x4, x8, [sp, #0x30]
101552094:     	ldr	w3, [x8, #0x4]
101552098:     	add	x8, x25, #0x2f8
10155209c:     	stp	x22, x8, [sp, #0x8]
1015520a0:     	add	x0, sp, #0x400
1015520a4:     	add	x1, x25, #0x3c0
1015520a8:     	add	x2, x27, #0x488
1015520ac:     	str	x23, [sp]
1015520b0:     	mov	x5, x22
1015520b4:     	mov	x7, x22
1015520b8:     	bl	0x101550364 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4pack>
1015520bc:     	ldr	x2, [x25, #0xd8]
1015520c0:     	cmp	x22, x2
1015520c4:     	b.hi	0x1015529c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1354>
1015520c8:     	ldr	x0, [x25, #0xd0]
1015520cc:     	str	xzr, [sp, #0x2f0]
1015520d0:     	add	x2, sp, #0x2f0
1015520d4:     	mov	x1, x22
1015520d8:     	bl	0x1014d2da0 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
1015520dc:     	ldr	w8, [sp, #0x400]
1015520e0:     	cmp	w8, #0x6
1015520e4:     	b.eq	0x101551c3c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d0>
1015520e8:     	ldur	q0, [x26, #0x14]
1015520ec:     	ldr	x9, [sp, #0x40]
1015520f0:     	stur	q0, [x9, #0x14]
1015520f4:     	ldur	q0, [x26, #0x24]
1015520f8:     	stur	q0, [x9, #0x24]
1015520fc:     	ldur	q0, [x26, #0x34]
101552100:     	stur	q0, [x9, #0x34]
101552104:     	ldr	q0, [sp, #0x440]
101552108:     	str	q0, [x9, #0x40]
10155210c:     	ldur	q0, [x26, #0x4]
101552110:     	stur	q0, [x9, #0x4]
101552114:     	str	w8, [x9]
101552118:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10155211c:     	ldr	x2, [x25, #0xd8]
101552120:     	cmp	x22, x2
101552124:     	b.hi	0x1015529a8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x133c>
101552128:     	ldr	x0, [x25, #0xd0]
10155212c:     	str	xzr, [sp, #0x400]
101552130:     	add	x2, sp, #0x400
101552134:     	mov	x1, x22
101552138:     	bl	0x1014d2da0 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
10155213c:     	ldr	x1, [x27, #0x380]
101552140:     	cmp	x20, x1
101552144:     	b.hs	0x101552a44 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13d8>
101552148:     	ldr	x8, [x27, #0x378]
10155214c:     	mov	w9, #0x170              ; =368
101552150:     	madd	x8, x20, x9, x8
101552154:     	ldr	w9, [x8, #0x158]
101552158:     	add	x10, sp, #0xf8
10155215c:     	add	x8, x8, #0x148
101552160:     	ldr	q0, [x8]
101552164:     	ldp	q1, q2, [x10]
101552168:     	ldr	x11, [sp, #0x40]
10155216c:     	stur	q1, [x11, #0x18]
101552170:     	stur	q2, [x11, #0x28]
101552174:     	ldr	q1, [x10, #0x20]
101552178:     	stur	q1, [x11, #0x38]
10155217c:     	ldr	x8, [sp, #0x128]
101552180:     	str	x8, [x11, #0x48]
101552184:     	mov	w8, #0x3                ; =3
101552188:     	str	w8, [x11]
10155218c:     	stur	q0, [x11, #0x4]
101552190:     	str	w9, [x11, #0x14]
101552194:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101552198:     	ldr	x25, [x21, #0x490]
10155219c:     	ldr	x1, [x25, #0x3c0]
1015521a0:     	add	x0, sp, #0x400
1015521a4:     	add	x2, x27, #0x488
1015521a8:     	add	x5, x25, #0x2f8
1015521ac:     	mov	x3, x22
1015521b0:     	mov	x4, x23
1015521b4:     	bl	0x101550ccc <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames7project>
1015521b8:     	ldr	w8, [sp, #0x400]
1015521bc:     	cmp	w8, #0x6
1015521c0:     	b.ne	0x1015522b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc48>
1015521c4:     	add	x8, sp, #0x400
1015521c8:     	ldur	q0, [x8, #0x38]
1015521cc:     	ldur	q1, [x8, #0x28]
1015521d0:     	ldur	q2, [x8, #0x18]
1015521d4:     	ldur	q3, [x8, #0x8]
1015521d8:     	stp	q3, q2, [sp, #0x230]
1015521dc:     	stp	q1, q0, [sp, #0x250]
1015521e0:     	ldp	x9, x8, [x26]
1015521e4:     	mov	w10, #0x1               ; =1
1015521e8:     	cmp	x10, x9
1015521ec:     	ngcs	xzr, x8
1015521f0:     	b.lo	0x10155269c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1030>
1015521f4:     	ldr	x8, [x26, #0x128]
1015521f8:     	cmp	x8, #0x2
1015521fc:     	b.lo	0x101552a64 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13f8>
101552200:     	ldr	x8, [x26, #0x120]
101552204:     	ldr	w1, [x8, #0x4]
101552208:     	mov	w22, #0x1               ; =1
10155220c:     	add	x8, sp, #0x400
101552210:     	add	x0, x25, #0xf0
101552214:     	add	x2, x25, #0x2f8
101552218:     	bl	0x10156d704 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10155221c:     	add	x8, sp, #0x400
101552220:     	ldur	q0, [x8, #0x8]
101552224:     	ldur	q1, [x8, #0x18]
101552228:     	stp	q0, q1, [sp, #0x2b0]
10155222c:     	ldur	q0, [x8, #0x28]
101552230:     	str	q0, [sp, #0x2d0]
101552234:     	ldr	x8, [sp, #0x400]
101552238:     	ldr	x9, [sp, #0x438]
10155223c:     	str	x9, [sp, #0x2e0]
101552240:     	cbz	x8, 0x101552364 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcf8>
101552244:     	ldp	q0, q1, [sp, #0x2b0]
101552248:     	add	x9, sp, #0x230
10155224c:     	stur	q0, [x9, #0x48]
101552250:     	stur	q1, [x9, #0x58]
101552254:     	ldr	q0, [sp, #0x2d0]
101552258:     	add	x26, sp, #0x230
10155225c:     	stur	q0, [x9, #0x68]
101552260:     	ldr	x9, [sp, #0x2e0]
101552264:     	str	x9, [sp, #0x2a8]
101552268:     	str	x8, [sp, #0x270]
10155226c:     	ldr	x1, [x27, #0x408]
101552270:     	cmp	x20, x1
101552274:     	b.hs	0x101552aac <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1440>
101552278:     	ldr	x8, [x27, #0x400]
10155227c:     	add	x22, x8, x20, lsl #9
101552280:     	ldp	x9, x8, [x22]
101552284:     	eor	x9, x9, #0x2
101552288:     	orr	x8, x9, x8
10155228c:     	cbnz	x8, 0x1015523b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd48>
101552290:     	ldr	x10, [sp, #0x40]
101552294:     	str	wzr, [x10]
101552298:     	mov	w8, #0xc                ; =12
10155229c:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
1015522a0:     	add	x9, x9, #0xab8
1015522a4:     	stp	x8, x9, [x10, #0x8]
1015522a8:     	mov	w8, #0x2a               ; =42
1015522ac:     	str	x8, [x10, #0x18]
1015522b0:     	b	0x10155283c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
1015522b4:     	add	x10, sp, #0x400
1015522b8:     	ldur	q0, [x10, #0x14]
1015522bc:     	ldur	q1, [x10, #0x24]
1015522c0:     	ldur	q2, [x10, #0x34]
1015522c4:     	stp	q1, q2, [sp, #0x310]
1015522c8:     	ldr	w9, [sp, #0x444]
1015522cc:     	str	w9, [sp, #0x330]
1015522d0:     	ldur	q3, [x10, #0x4]
1015522d4:     	stp	q3, q0, [sp, #0x2f0]
1015522d8:     	ldr	x10, [sp, #0x448]
1015522dc:     	ldr	x11, [sp, #0x40]
1015522e0:     	stur	q0, [x11, #0x14]
1015522e4:     	stur	q1, [x11, #0x24]
1015522e8:     	stur	q2, [x11, #0x34]
1015522ec:     	str	w9, [x11, #0x44]
1015522f0:     	stur	q3, [x11, #0x4]
1015522f4:     	str	w8, [x11]
1015522f8:     	str	x10, [x11, #0x48]
1015522fc:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101552300:     	ldr	x25, [x21, #0x490]
101552304:     	add	x0, sp, #0x400
101552308:     	add	x1, x25, #0x3c0
10155230c:     	add	x2, x27, #0x488
101552310:     	add	x6, x25, #0x2f8
101552314:     	mov	x3, x22
101552318:     	mov	x4, x23
10155231c:     	mov	x5, x24
101552320:     	bl	0x10154f6f8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames17project_composite>
101552324:     	ldr	w8, [sp, #0x400]
101552328:     	cmp	w8, #0x6
10155232c:     	b.ne	0x10155233c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
101552330:     	mov	x22, #0x0               ; =0
101552334:     	add	x26, sp, #0x400
101552338:     	b	0x101551c40 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10155233c:     	ldr	q0, [sp, #0x420]
101552340:     	ldr	q1, [sp, #0x430]
101552344:     	ldr	x8, [sp, #0x40]
101552348:     	stp	q0, q1, [x8, #0x20]
10155234c:     	ldr	q0, [sp, #0x440]
101552350:     	str	q0, [x8, #0x40]
101552354:     	ldr	q0, [sp, #0x410]
101552358:     	ldr	q1, [sp, #0x400]
10155235c:     	stp	q1, q0, [x8]
101552360:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101552364:     	ldp	q0, q1, [sp, #0x2b0]
101552368:     	add	x9, sp, #0x400
10155236c:     	stur	q0, [x9, #0x4]
101552370:     	stur	q1, [x9, #0x14]
101552374:     	ldr	q0, [sp, #0x2d0]
101552378:     	stur	q0, [x9, #0x24]
10155237c:     	ldr	x8, [sp, #0x2e0]
101552380:     	stur	x8, [x9, #0x34]
101552384:     	ldr	q0, [sp, #0x400]
101552388:     	ldr	q1, [sp, #0x410]
10155238c:     	ldr	x10, [sp, #0x40]
101552390:     	stur	q0, [x10, #0x4]
101552394:     	mov	w8, #0x2                ; =2
101552398:     	str	w8, [x10]
10155239c:     	stur	q1, [x10, #0x14]
1015523a0:     	ldr	q0, [sp, #0x420]
1015523a4:     	stur	q0, [x10, #0x24]
1015523a8:     	ldur	q0, [x9, #0x2c]
1015523ac:     	str	q0, [x10, #0x30]
1015523b0:     	b	0x101552848 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11dc>
1015523b4:     	add	x24, sp, #0x400
1015523b8:     	add	x8, sp, #0x400
1015523bc:     	mov	x0, x21
1015523c0:     	mov	w1, #0x0                ; =0
1015523c4:     	bl	0x101574b2c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015523c8:     	ldr	x8, [sp, #0x400]
1015523cc:     	cmp	x8, #0x1
1015523d0:     	b.ne	0x10155247c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe10>
1015523d4:     	ldur	q0, [x24, #0x18]
1015523d8:     	ldur	q1, [x24, #0x28]
1015523dc:     	ldur	q2, [x24, #0x38]
1015523e0:     	stp	q1, q2, [sp, #0x310]
1015523e4:     	ldur	q3, [x24, #0x48]
1015523e8:     	str	q3, [sp, #0x330]
1015523ec:     	ldur	q4, [x24, #0x8]
1015523f0:     	stp	q4, q0, [sp, #0x2f0]
1015523f4:     	ldr	x8, [sp, #0x40]
1015523f8:     	stp	q1, q2, [x8, #0x20]
1015523fc:     	str	q3, [x8, #0x40]
101552400:     	stp	q4, q0, [x8]
101552404:     	b	0x10155283c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
101552408:     	ldp	q0, q1, [sp, #0x150]
10155240c:     	add	x9, sp, #0x400
101552410:     	stur	q0, [x9, #0x4]
101552414:     	stur	q1, [x9, #0x14]
101552418:     	ldr	q0, [sp, #0x170]
10155241c:     	stur	q0, [x9, #0x24]
101552420:     	ldr	x8, [sp, #0x180]
101552424:     	b	0x101551fb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x944>
101552428:     	add	x24, sp, #0x400
10155242c:     	add	x8, sp, #0x400
101552430:     	mov	x0, x21
101552434:     	mov	w1, #0x0                ; =0
101552438:     	bl	0x101574b2c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10155243c:     	ldr	x8, [sp, #0x400]
101552440:     	cmp	x8, #0x1
101552444:     	b.ne	0x101552528 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xebc>
101552448:     	ldur	q0, [x24, #0x18]
10155244c:     	ldur	q1, [x24, #0x28]
101552450:     	ldur	q2, [x24, #0x38]
101552454:     	stp	q1, q2, [sp, #0x310]
101552458:     	ldur	q3, [x24, #0x48]
10155245c:     	str	q3, [sp, #0x330]
101552460:     	ldur	q4, [x24, #0x8]
101552464:     	stp	q4, q0, [sp, #0x2f0]
101552468:     	ldr	x8, [sp, #0x40]
10155246c:     	stp	q1, q2, [x8, #0x20]
101552470:     	str	q3, [x8, #0x40]
101552474:     	stp	q4, q0, [x8]
101552478:     	b	0x1015528b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
10155247c:     	ldur	q0, [x24, #0x48]
101552480:     	ldur	q1, [x24, #0x58]
101552484:     	stp	q0, q1, [sp, #0x330]
101552488:     	ldur	x8, [x24, #0x68]
10155248c:     	str	x8, [sp, #0x350]
101552490:     	ldur	q2, [x24, #0x8]
101552494:     	ldur	q3, [x24, #0x18]
101552498:     	stp	q2, q3, [sp, #0x2f0]
10155249c:     	ldur	q4, [x24, #0x38]
1015524a0:     	ldur	q5, [x24, #0x28]
1015524a4:     	stp	q2, q3, [sp, #0x360]
1015524a8:     	stp	q5, q4, [sp, #0x380]
1015524ac:     	str	x8, [sp, #0x3c0]
1015524b0:     	stp	q0, q1, [sp, #0x3a0]
1015524b4:     	ldr	x8, [sp, #0x230]
1015524b8:     	cbz	x8, 0x101552610 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfa4>
1015524bc:     	ldp	q0, q1, [x21, #0x80]
1015524c0:     	str	q0, [sp, #0x480]
1015524c4:     	str	q1, [sp, #0x490]
1015524c8:     	ldr	x8, [x21, #0xa0]
1015524cc:     	str	x8, [sp, #0x4a0]
1015524d0:     	ldp	q0, q1, [x21, #0x40]
1015524d4:     	str	q0, [sp, #0x440]
1015524d8:     	str	q1, [sp, #0x450]
1015524dc:     	ldp	q1, q0, [x21, #0x60]
1015524e0:     	str	q0, [sp, #0x470]
1015524e4:     	str	q1, [sp, #0x460]
1015524e8:     	ldp	q0, q1, [x21]
1015524ec:     	str	q0, [sp, #0x400]
1015524f0:     	str	q1, [sp, #0x410]
1015524f4:     	ldp	q1, q0, [x21, #0x20]
1015524f8:     	str	q0, [sp, #0x430]
1015524fc:     	str	q1, [sp, #0x420]
101552500:     	add	x8, sp, #0x3c8
101552504:     	add	x1, sp, #0x270
101552508:     	add	x3, sp, #0x230
10155250c:     	add	x4, sp, #0x400
101552510:     	add	x5, x25, #0x3b8
101552514:     	add	x6, sp, #0x360
101552518:     	mov	x0, x22
10155251c:     	mov	x2, x23
101552520:     	bl	0x1026b6a88 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall25admit_buffer_record_field>
101552524:     	b	0x101552684 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1018>
101552528:     	ldur	q0, [x24, #0x48]
10155252c:     	ldur	q1, [x24, #0x58]
101552530:     	stp	q0, q1, [sp, #0x330]
101552534:     	ldur	x8, [x24, #0x68]
101552538:     	str	x8, [sp, #0x350]
10155253c:     	ldur	q2, [x24, #0x8]
101552540:     	ldur	q3, [x24, #0x18]
101552544:     	stp	q2, q3, [sp, #0x2f0]
101552548:     	ldur	q4, [x24, #0x38]
10155254c:     	ldur	q5, [x24, #0x28]
101552550:     	stp	q2, q3, [sp, #0x190]
101552554:     	stp	q5, q4, [sp, #0x1b0]
101552558:     	str	x8, [sp, #0x1f0]
10155255c:     	stp	q0, q1, [sp, #0x1d0]
101552560:     	ldr	x8, [sp, #0x38]
101552564:     	ldr	x7, [x8, #0x10]
101552568:     	ldp	q0, q1, [x21, #0x80]
10155256c:     	str	q0, [sp, #0x480]
101552570:     	str	q1, [sp, #0x490]
101552574:     	ldr	x8, [x21, #0xa0]
101552578:     	str	x8, [sp, #0x4a0]
10155257c:     	ldp	q0, q1, [x21, #0x40]
101552580:     	str	q0, [sp, #0x440]
101552584:     	str	q1, [sp, #0x450]
101552588:     	ldp	q1, q0, [x21, #0x60]
10155258c:     	str	q0, [sp, #0x470]
101552590:     	str	q1, [sp, #0x460]
101552594:     	ldp	q0, q1, [x21]
101552598:     	str	q0, [sp, #0x400]
10155259c:     	str	q1, [sp, #0x410]
1015525a0:     	ldp	q1, q0, [x21, #0x20]
1015525a4:     	add	x8, x25, #0x3b8
1015525a8:     	str	q0, [sp, #0x430]
1015525ac:     	str	q1, [sp, #0x420]
1015525b0:     	add	x9, sp, #0x190
1015525b4:     	stp	x8, x9, [sp, #0x8]
1015525b8:     	add	x9, sp, #0x400
1015525bc:     	adrp	x1, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015525c0:     	add	x1, x1, #0x988
1015525c4:     	str	x9, [sp]
1015525c8:     	add	x8, sp, #0x1f8
1015525cc:     	add	x5, x25, #0x3c0
1015525d0:     	add	x6, sp, #0x270
1015525d4:     	adrp	x3, 0x107553000 <_anon.61c4a8641e5b3956ea8870164c4e553f.880+0x331>
1015525d8:     	add	x3, x3, #0xc20
1015525dc:     	mov	x0, x23
1015525e0:     	mov	w2, #0x2                ; =2
1015525e4:     	mov	w4, #0x2                ; =2
1015525e8:     	bl	0x10160d6bc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>
1015525ec:     	ldrb	w8, [sp, #0x1f8]
1015525f0:     	cmp	w8, #0x2e
1015525f4:     	b.ne	0x101552874 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1208>
1015525f8:     	add	x0, sp, #0x270
1015525fc:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552600:     	ldr	x8, [sp, #0x38]
101552604:     	ldr	x23, [x8, #0x10]
101552608:     	ldr	w24, [x8, #0x8]
10155260c:     	b	0x101552304 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc98>
101552610:     	ldr	w3, [sp, #0x248]
101552614:     	ldur	q0, [x26, #0x8]
101552618:     	str	q0, [sp, #0x2f0]
10155261c:     	ldp	q0, q1, [x21, #0x80]
101552620:     	str	q0, [sp, #0x480]
101552624:     	str	q1, [sp, #0x490]
101552628:     	ldr	x8, [x21, #0xa0]
10155262c:     	str	x8, [sp, #0x4a0]
101552630:     	ldp	q0, q1, [x21, #0x40]
101552634:     	str	q0, [sp, #0x440]
101552638:     	str	q1, [sp, #0x450]
10155263c:     	ldp	q1, q0, [x21, #0x60]
101552640:     	str	q0, [sp, #0x470]
101552644:     	str	q1, [sp, #0x460]
101552648:     	ldp	q0, q1, [x21]
10155264c:     	str	q0, [sp, #0x400]
101552650:     	str	q1, [sp, #0x410]
101552654:     	ldp	q1, q0, [x21, #0x20]
101552658:     	str	q0, [sp, #0x430]
10155265c:     	str	q1, [sp, #0x420]
101552660:     	add	x8, sp, #0x3c8
101552664:     	add	x1, sp, #0x270
101552668:     	add	x4, sp, #0x2f0
10155266c:     	add	x5, sp, #0x400
101552670:     	add	x6, x25, #0x3b8
101552674:     	add	x7, sp, #0x360
101552678:     	mov	x0, x22
10155267c:     	mov	x2, x23
101552680:     	bl	0x1026b6740 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_record_word>
101552684:     	ldrb	w8, [sp, #0x3c8]
101552688:     	cmp	w8, #0x2e
10155268c:     	b.ne	0x101552800 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1194>
101552690:     	mov	w22, #0x1               ; =1
101552694:     	add	x0, sp, #0x270
101552698:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10155269c:     	ldr	x8, [x27, #0x360]
1015526a0:     	ldr	x9, [sp, #0x38]
1015526a4:     	ldr	w1, [x9, #0x8]
1015526a8:     	cmp	x8, x1
1015526ac:     	b.ls	0x101552a58 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13ec>
1015526b0:     	ldr	x8, [x27, #0x358]
1015526b4:     	mov	w9, #0x140              ; =320
1015526b8:     	umaddl	x9, w1, w9, x8
1015526bc:     	ldr	x8, [sp, #0x230]
1015526c0:     	cbz	x8, 0x1015527a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1138>
1015526c4:     	ldp	q0, q1, [sp, #0x230]
1015526c8:     	str	q0, [sp, #0x400]
1015526cc:     	str	q1, [sp, #0x410]
1015526d0:     	ldp	q0, q1, [sp, #0x250]
1015526d4:     	str	q0, [sp, #0x420]
1015526d8:     	str	q1, [sp, #0x430]
1015526dc:     	ldr	x8, [x27, #0x448]
1015526e0:     	cmp	x8, x1
1015526e4:     	b.ls	0x101552a84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1418>
1015526e8:     	ldr	x8, [x27, #0x440]
1015526ec:     	mov	w10, #0x24              ; =36
1015526f0:     	umaddl	x8, w1, w10, x8
1015526f4:     	ldr	w10, [sp, #0x438]
1015526f8:     	ldr	w11, [x8, #0x20]
1015526fc:     	cmp	w10, w11
101552700:     	b.ne	0x101552774 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
101552704:     	ldp	q0, q1, [sp, #0x240]
101552708:     	stp	q0, q1, [sp, #0x2f0]
10155270c:     	ldr	x10, [sp, #0x2f0]
101552710:     	ldr	x11, [sp, #0x2f8]
101552714:     	ldp	x12, x13, [x8]
101552718:     	ldr	x14, [sp, #0x300]
10155271c:     	ldr	x15, [sp, #0x308]
101552720:     	ldp	x16, x8, [x8, #0x10]
101552724:     	cmp	x10, x12
101552728:     	ccmp	x11, x13, #0x0, eq
10155272c:     	ccmp	x14, x16, #0x0, eq
101552730:     	ccmp	x15, x8, #0x0, eq
101552734:     	b.ne	0x101552774 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
101552738:     	ldrb	w8, [x9, #0x124]
10155273c:     	cmp	w8, #0x7
101552740:     	b.ne	0x101552774 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
101552744:     	add	x8, sp, #0x2f0
101552748:     	add	x0, x25, #0xf0
10155274c:     	add	x2, sp, #0x400
101552750:     	add	x3, x25, #0x2f8
101552754:     	bl	0x10156f20c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
101552758:     	ldrb	w8, [sp, #0x2f0]
10155275c:     	cmp	w8, #0x14
101552760:     	b.ne	0x1015528bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1250>
101552764:     	mov	w22, #0x0               ; =0
101552768:     	add	x0, sp, #0x400
10155276c:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552770:     	b	0x101552330 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcc4>
101552774:     	ldr	x10, [sp, #0x40]
101552778:     	str	wzr, [x10]
10155277c:     	mov	w8, #0xc                ; =12
101552780:     	strb	w8, [x10, #0x8]
101552784:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101552788:     	add	x8, x8, #0xa31
10155278c:     	mov	w9, #0x2a               ; =42
101552790:     	stp	x8, x9, [x10, #0x10]
101552794:     	mov	w22, #0x0               ; =0
101552798:     	add	x0, sp, #0x400
10155279c:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015527a0:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015527a4:     	ldr	w8, [sp, #0x248]
1015527a8:     	ldr	w10, [x9, #0x130]
1015527ac:     	cmp	w8, w10
1015527b0:     	b.ne	0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015527b4:     	ldrb	w8, [sp, #0x239]
1015527b8:     	ldr	x21, [sp, #0x240]
1015527bc:     	ldrb	w10, [sp, #0x238]
1015527c0:     	ldrb	w9, [x9, #0x124]
1015527c4:     	cmp	w10, #0x2
1015527c8:     	b.le	0x1015527e8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x117c>
1015527cc:     	cmp	w10, #0x4
1015527d0:     	b.gt	0x10155285c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11f0>
1015527d4:     	cmp	w10, #0x3
1015527d8:     	b.ne	0x10155291c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12b0>
1015527dc:     	cmp	w9, #0x3
1015527e0:     	b.eq	0x101552940 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015527e4:     	b	0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015527e8:     	cbz	w10, 0x101552904 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1298>
1015527ec:     	cmp	w10, #0x1
1015527f0:     	b.ne	0x101552910 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a4>
1015527f4:     	cmp	w9, #0x1
1015527f8:     	b.eq	0x101552940 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015527fc:     	b	0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
101552800:     	ldr	x1, [x27, #0x378]
101552804:     	ldr	x2, [x27, #0x380]
101552808:     	add	x0, sp, #0x400
10155280c:     	add	x4, sp, #0x3c8
101552810:     	mov	x3, x20
101552814:     	bl	0x10154d848 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>
101552818:     	ldr	q0, [sp, #0x420]
10155281c:     	ldr	q1, [sp, #0x430]
101552820:     	ldr	x8, [sp, #0x40]
101552824:     	stp	q0, q1, [x8, #0x20]
101552828:     	ldr	q0, [sp, #0x440]
10155282c:     	str	q0, [x8, #0x40]
101552830:     	ldr	q0, [sp, #0x410]
101552834:     	ldr	q1, [sp, #0x400]
101552838:     	stp	q1, q0, [x8]
10155283c:     	mov	w22, #0x1               ; =1
101552840:     	add	x0, sp, #0x270
101552844:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552848:     	ldr	x8, [sp, #0x230]
10155284c:     	cbz	x8, 0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
101552850:     	add	x0, sp, #0x230
101552854:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552858:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10155285c:     	cmp	w10, #0x5
101552860:     	b.ne	0x101552934 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12c8>
101552864:     	cmp	w9, #0x5
101552868:     	b.ne	0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10155286c:     	ldrh	w21, [sp, #0x23a]
101552870:     	b	0x101552940 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
101552874:     	ldr	x1, [x27, #0x378]
101552878:     	ldr	x2, [x27, #0x380]
10155287c:     	add	x0, sp, #0x400
101552880:     	add	x4, sp, #0x1f8
101552884:     	mov	x3, x20
101552888:     	bl	0x10154d7b4 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>
10155288c:     	ldr	q0, [sp, #0x420]
101552890:     	ldr	q1, [sp, #0x430]
101552894:     	ldr	x8, [sp, #0x40]
101552898:     	stp	q0, q1, [x8, #0x20]
10155289c:     	ldr	q0, [sp, #0x440]
1015528a0:     	str	q0, [x8, #0x40]
1015528a4:     	ldr	q0, [sp, #0x410]
1015528a8:     	ldr	q1, [sp, #0x400]
1015528ac:     	stp	q1, q0, [x8]
1015528b0:     	add	x0, sp, #0x270
1015528b4:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015528b8:     	b	0x1015519ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015528bc:     	add	x10, sp, #0x230
1015528c0:     	ldur	w9, [x10, #0xc1]
1015528c4:     	ldr	x11, [sp, #0x40]
1015528c8:     	stur	w9, [x11, #0x9]
1015528cc:     	ldr	w9, [sp, #0x2f4]
1015528d0:     	str	w9, [x11, #0xc]
1015528d4:     	ldr	q0, [sp, #0x310]
1015528d8:     	stur	q0, [x11, #0x28]
1015528dc:     	ldr	x9, [sp, #0x320]
1015528e0:     	str	x9, [x11, #0x38]
1015528e4:     	ldr	d0, [sp, #0x308]
1015528e8:     	ldur	q1, [x10, #0xc8]
1015528ec:     	mov	w9, #0x2                ; =2
1015528f0:     	str	w9, [x11]
1015528f4:     	strb	w8, [x11, #0x8]
1015528f8:     	str	q1, [x11, #0x10]
1015528fc:     	str	d0, [x11, #0x20]
101552900:     	b	0x101552794 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1128>
101552904:     	cbnz	w9, 0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
101552908:     	and	x21, x8, #0x1
10155290c:     	b	0x101552940 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
101552910:     	cmp	w9, #0x2
101552914:     	b.eq	0x101552940 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
101552918:     	b	0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10155291c:     	cmp	w9, #0x4
101552920:     	b.ne	0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
101552924:     	mov	w22, #0x1               ; =1
101552928:     	mov	x21, x8
10155292c:     	add	x26, sp, #0x400
101552930:     	b	0x101551c40 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
101552934:     	cmp	w9, #0x6
101552938:     	b.ne	0x10155294c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10155293c:     	ldr	w21, [sp, #0x23c]
101552940:     	mov	w22, #0x1               ; =1
101552944:     	add	x26, sp, #0x400
101552948:     	b	0x101551c40 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10155294c:     	ldr	x10, [sp, #0x40]
101552950:     	str	wzr, [x10]
101552954:     	mov	w8, #0xc                ; =12
101552958:     	strb	w8, [x10, #0x8]
10155295c:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101552960:     	add	x8, x8, #0xa08
101552964:     	mov	w9, #0x29               ; =41
101552968:     	b	0x101551d7c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
10155296c:     	adrp	x3, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552970:     	add	x3, x3, #0x2a0
101552974:     	mov	x0, #0x0                ; =0
101552978:     	mov	x1, x22
10155297c:     	bl	0x103a02a54 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101552980:     	adrp	x3, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552984:     	add	x3, x3, #0x228
101552988:     	mov	x0, #0x0                ; =0
10155298c:     	mov	x1, x22
101552990:     	bl	0x103a02a54 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101552994:     	adrp	x3, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552998:     	add	x3, x3, #0x288
10155299c:     	mov	x0, #0x0                ; =0
1015529a0:     	mov	x1, x22
1015529a4:     	bl	0x103a02a54 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015529a8:     	adrp	x3, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
1015529ac:     	add	x3, x3, #0x258
1015529b0:     	mov	x0, #0x0                ; =0
1015529b4:     	mov	x1, x22
1015529b8:     	bl	0x103a02a54 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015529bc:     	b	0x101552ad0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015529c0:     	adrp	x3, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
1015529c4:     	add	x3, x3, #0x270
1015529c8:     	mov	x0, #0x0                ; =0
1015529cc:     	mov	x1, x22
1015529d0:     	bl	0x103a02a54 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015529d4:     	b	0x101552ad0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015529d8:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
1015529dc:     	add	x2, x2, #0x2b8
1015529e0:     	mov	x0, x1
1015529e4:     	mov	x1, x8
1015529e8:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015529ec:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
1015529f0:     	add	x2, x2, #0x1f8
1015529f4:     	mov	x0, x20
1015529f8:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015529fc:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a00:     	add	x2, x2, #0x2d0
101552a04:     	mov	x0, x25
101552a08:     	mov	x1, x22
101552a0c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552a10:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a14:     	add	x2, x2, #0x2e8
101552a18:     	mov	x0, x25
101552a1c:     	mov	x1, x22
101552a20:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552a24:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a28:     	add	x2, x2, #0x318
101552a2c:     	mov	x0, x20
101552a30:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552a34:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a38:     	add	x2, x2, #0x210
101552a3c:     	mov	x0, x20
101552a40:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552a44:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a48:     	add	x2, x2, #0x240
101552a4c:     	mov	x0, x20
101552a50:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552a54:     	b	0x101552ad0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
101552a58:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a5c:     	add	x2, x2, #0x390
101552a60:     	b	0x101552a70 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1404>
101552a64:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a68:     	add	x2, x2, #0x360
101552a6c:     	mov	w1, #0x1                ; =1
101552a70:     	mov	w22, #0x1               ; =1
101552a74:     	mov	x0, x1
101552a78:     	mov	x1, x8
101552a7c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552a80:     	b	0x101552ad0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
101552a84:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552a88:     	add	x2, x2, #0x3a8
101552a8c:     	mov	x0, x1
101552a90:     	mov	x1, x8
101552a94:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552a98:     	b	0x101552ad0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
101552a9c:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552aa0:     	add	x2, x2, #0x330
101552aa4:     	mov	w0, #0x1                ; =1
101552aa8:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552aac:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552ab0:     	add	x2, x2, #0x378
101552ab4:     	mov	x0, x20
101552ab8:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552abc:     	b	0x101552ad0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
101552ac0:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101552ac4:     	add	x2, x2, #0x348
101552ac8:     	mov	x0, x20
101552acc:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101552ad0:     	brk	#0x1
101552ad4:     	mov	x20, x0
101552ad8:     	add	x0, sp, #0x400
101552adc:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552ae0:     	b	0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552ae4:     	mov	x20, x0
101552ae8:     	add	x0, sp, #0x270
101552aec:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552af0:     	b	0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552af4:     	mov	x20, x0
101552af8:     	add	x0, sp, #0x270
101552afc:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552b00:     	mov	w22, #0x1               ; =1
101552b04:     	b	0x101552b0c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14a0>
101552b08:     	mov	x20, x0
101552b0c:     	cbz	w22, 0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552b10:     	ldr	x8, [sp, #0x230]
101552b14:     	cbz	x8, 0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552b18:     	add	x0, sp, #0x230
101552b1c:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552b20:     	b	0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552b24:     	add	x8, x28, x19
101552b28:     	ldp	q0, q1, [sp, #0x2f0]
101552b2c:     	ldp	q2, q3, [sp, #0x310]
101552b30:     	stp	q2, q3, [x8, #0x20]
101552b34:     	stp	q0, q1, [x8]
101552b38:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
101552b3c:     	mov	x20, x0
101552b40:     	tbnz	w19, #0x0, 0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552b44:     	add	x0, sp, #0x2f0
101552b48:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101552b4c:     	b	0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552b50:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101552b54:     	mov	x20, x0
101552b58:     	ldr	w8, [sp, #0x400]
101552b5c:     	cmp	w8, #0x6
101552b60:     	b.eq	0x101552b80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
101552b64:     	add	x0, sp, #0x400
101552b68:     	bl	0x10154a66c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101552b6c:     	mov	x0, x20
101552b70:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
101552b74:     	mov	x20, x0
101552b78:     	add	x0, sp, #0xf8
101552b7c:     	bl	0x10154a800 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101552b80:     	mov	x0, x20
101552b84:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
