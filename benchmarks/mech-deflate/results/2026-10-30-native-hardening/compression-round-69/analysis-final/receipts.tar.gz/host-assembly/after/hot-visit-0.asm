
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101545800 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>:
101545800:     	sub	sp, sp, #0x50
101545804:     	stp	x22, x21, [sp, #0x20]
101545808:     	stp	x20, x19, [sp, #0x30]
10154580c:     	stp	x29, x30, [sp, #0x40]
101545810:     	add	x29, sp, #0x40
101545814:     	cbz	x0, 0x1015458c8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101545818:     	ldr	x8, [x0]
10154581c:     	cmp	x8, #0x1
101545820:     	b.ne	0x101545860 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x60>
101545824:     	ldr	x8, [x1]
101545828:     	ldr	x9, [x8, #0x10]
10154582c:     	cmp	x9, #0x2
101545830:     	b.eq	0x1015458c8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101545834:     	ldr	x9, [x0, #0x8]
101545838:     	ldr	x10, [x8, #0x40]
10154583c:     	cmp	x9, x10
101545840:     	b.hs	0x1015458c8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101545844:     	ldr	x8, [x8, #0x38]
101545848:     	mov	w10, #0x3c8             ; =968
10154584c:     	madd	x8, x9, x10, x8
101545850:     	ldr	x8, [x8, #0x290]
101545854:     	cbz	x8, 0x1015458c8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101545858:     	mov	x1, x0
10154585c:     	b	0x1015458cc <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
101545860:     	ldr	x8, [x0, #0x18]
101545864:     	cbz	x8, 0x101545924 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x124>
101545868:     	ldr	x8, [x0, #0x10]
10154586c:     	ldr	w8, [x8]
101545870:     	ldr	x9, [x1, #0x20]
101545874:     	ldr	x9, [x9]
101545878:     	cmp	x9, x8
10154587c:     	b.ne	0x1015458c8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101545880:     	ldr	x8, [x1, #0x18]
101545884:     	ldr	x8, [x8]
101545888:     	cmp	x8, #0x2
10154588c:     	b.ne	0x1015458c8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101545890:     	mov	x21, x1
101545894:     	ldr	x9, [x1, #0x8]
101545898:     	add	x8, sp, #0x8
10154589c:     	mov	x20, x0
1015458a0:     	mov	x0, x9
1015458a4:     	bl	0x102368c08 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015458a8:     	ldr	x8, [sp, #0x8]
1015458ac:     	cmp	x8, #0x1
1015458b0:     	b.ne	0x1015458c8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015458b4:     	mov	x0, x20
1015458b8:     	ldr	x8, [sp, #0x10]
1015458bc:     	ldr	x19, [x20, #0x30]
1015458c0:     	cmp	x8, x19
1015458c4:     	b.hs	0x1015458e4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xe4>
1015458c8:     	mov	x1, #0x0                ; =0
1015458cc:     	mov	x0, x1
1015458d0:     	ldp	x29, x30, [sp, #0x40]
1015458d4:     	ldp	x20, x19, [sp, #0x30]
1015458d8:     	ldp	x22, x21, [sp, #0x20]
1015458dc:     	add	sp, sp, #0x50
1015458e0:     	ret
1015458e4:     	ldr	x8, [x21, #0x10]
1015458e8:     	ldr	x9, [x8, #0x18]!
1015458ec:     	ldur	x21, [x8, #-0x8]
1015458f0:     	cbz	x9, 0x101545908 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x108>
1015458f4:     	mov	x0, x8
1015458f8:     	bl	0x1023697a8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
1015458fc:     	mov	x8, x0
101545900:     	mov	x0, x20
101545904:     	b	0x10154590c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x10c>
101545908:     	ldur	x8, [x8, #-0x10]
10154590c:     	mov	x1, #0x0                ; =0
101545910:     	subs	x8, x21, x8
101545914:     	b.lo	0x1015458cc <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
101545918:     	cmp	x8, x19
10154591c:     	b.hs	0x101545858 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x58>
101545920:     	b	0x1015458cc <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
101545924:     	adrp	x2, 0x107f08000 <_anon.0504008e54a1502d122e47b3b8bf1e07.436+0x1e8>
101545928:     	add	x2, x2, #0xdd0
10154592c:     	mov	x0, #0x0                ; =0
101545930:     	mov	x1, #0x0                ; =0
101545934:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
