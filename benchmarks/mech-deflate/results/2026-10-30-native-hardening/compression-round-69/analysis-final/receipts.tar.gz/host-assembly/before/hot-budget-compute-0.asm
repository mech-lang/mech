
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102999e08 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
102999e08:     	sub	sp, sp, #0x80
102999e0c:     	stp	x22, x21, [sp, #0x50]
102999e10:     	stp	x20, x19, [sp, #0x60]
102999e14:     	stp	x29, x30, [sp, #0x70]
102999e18:     	add	x29, sp, #0x70
102999e1c:     	mov	x19, x8
102999e20:     	ldr	x20, [x0]
102999e24:     	ldr	x8, [x20, #0x10]
102999e28:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102999e2c:     	cmp	x8, x9
102999e30:     	b.hs	0x102999e9c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
102999e34:     	add	x9, x8, #0x1
102999e38:     	str	x9, [x20, #0x10]
102999e3c:     	ldr	x9, [x20, #0x38]
102999e40:     	adds	x9, x9, x1
102999e44:     	b.hs	0x102999ea8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xa0>
102999e48:     	str	x8, [x20, #0x10]
102999e4c:     	cmp	x9, x2
102999e50:     	b.ls	0x102999e6c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x64>
102999e54:     	mov	w8, #0x606              ; =1542
102999e58:     	strh	w8, [x19]
102999e5c:     	mov	w8, #0x1                ; =1
102999e60:     	strb	w8, [x19, #0x2]
102999e64:     	stp	x9, x2, [x19, #0x8]
102999e68:     	b	0x10299a038 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
102999e6c:     	adrp	x0, 0x108073000 <__mi_heap_main+0xb28>
102999e70:     	add	x0, x0, #0x550
102999e74:     	ldr	x8, [x0]
102999e78:     	blr	x8
102999e7c:     	ldrb	w8, [x0, #0x48]
102999e80:     	cmp	w8, #0x1
102999e84:     	b.eq	0x102999ef0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe8>
102999e88:     	cmp	w8, #0x2
102999e8c:     	b.ne	0x102999ec8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xc0>
102999e90:     	adrp	x0, 0x10804f000 <_anon.5245c210884fd18e01c7938c721b2e18.255+0x6698>
102999e94:     	add	x0, x0, #0xc20
102999e98:     	bl	0x103a05f64 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102999e9c:     	adrp	x0, 0x108051000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.310+0x148>
102999ea0:     	add	x0, x0, #0x918
102999ea4:     	bl	0x103a06618 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102999ea8:     	mov	w9, #0x606              ; =1542
102999eac:     	strh	w9, [x19]
102999eb0:     	mov	w9, #0x1                ; =1
102999eb4:     	strb	w9, [x19, #0x2]
102999eb8:     	mov	x9, #-0x1               ; =-1
102999ebc:     	stp	x9, x2, [x19, #0x8]
102999ec0:     	str	x8, [x20, #0x10]
102999ec4:     	b	0x10299a038 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
102999ec8:     	adrp	x8, 0x102335000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x68>
102999ecc:     	add	x8, x8, #0xc30
102999ed0:     	str	x0, [sp, #0x8]
102999ed4:     	mov	x21, x1
102999ed8:     	mov	x1, x8
102999edc:     	bl	0x102e73214 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102999ee0:     	ldr	x0, [sp, #0x8]
102999ee4:     	mov	x1, x21
102999ee8:     	mov	w8, #0x1                ; =1
102999eec:     	strb	w8, [x0, #0x48]
102999ef0:     	ldr	x8, [x0, #0x20]
102999ef4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102999ef8:     	cmp	x8, x9
102999efc:     	b.hs	0x10299a058 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x250>
102999f00:     	ldr	x8, [x0, #0x28]
102999f04:     	cmp	x8, #0x0
102999f08:     	ccmp	x8, x20, #0x4, ne
102999f0c:     	b.ne	0x102999f88 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x180>
102999f10:     	ldr	x8, [x20, #0x10]
102999f14:     	cbnz	x8, 0x10299a064 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x25c>
102999f18:     	mov	x8, #-0x1               ; =-1
102999f1c:     	str	x8, [x20, #0x10]
102999f20:     	ldr	w8, [x0, #0x30]
102999f24:     	ldp	x9, x10, [x0, #0x38]
102999f28:     	ldp	x11, x12, [x20, #0x60]
102999f2c:     	cmp	x9, x11
102999f30:     	csel	x9, x9, x11, lo
102999f34:     	cmp	x10, x12
102999f38:     	csel	x10, x10, x12, lo
102999f3c:     	tst	w8, #0x1
102999f40:     	csel	x9, x9, x11, ne
102999f44:     	csel	x13, x10, x12, ne
102999f48:     	ldr	x8, [x20, #0x38]
102999f4c:     	adds	x21, x8, x1
102999f50:     	b.hs	0x10299a04c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102999f54:     	ldr	x8, [x20, #0x48]
102999f58:     	adds	x10, x8, x21
102999f5c:     	b.hs	0x10299a04c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102999f60:     	ldr	x22, [x20, #0x40]
102999f64:     	ldr	x8, [x20, #0x50]
102999f68:     	adds	x14, x8, x22
102999f6c:     	b.hs	0x10299a04c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102999f70:     	cmp	x10, x9
102999f74:     	b.ls	0x102999f90 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x188>
102999f78:     	mov	w12, #0x6               ; =6
102999f7c:     	mov	w11, #0x1               ; =1
102999f80:     	mov	w8, #0x6                ; =6
102999f84:     	b	0x10299a004 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102999f88:     	mov	w8, #0x0                ; =0
102999f8c:     	b	0x10299a010 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x208>
102999f90:     	cmp	x14, x13
102999f94:     	b.ls	0x102999fb0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
102999f98:     	mov	w8, #0x6                ; =6
102999f9c:     	mov	w12, #0x5               ; =5
102999fa0:     	mov	w11, #0x1               ; =1
102999fa4:     	mov	x9, x13
102999fa8:     	mov	x10, x14
102999fac:     	b	0x10299a004 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102999fb0:     	mov	x0, x20
102999fb4:     	ldr	x8, [x0, #0x70]!
102999fb8:     	cbz	x8, 0x102999fd4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1cc>
102999fbc:     	add	x8, sp, #0x28
102999fc0:     	mov	x2, #0x0                ; =0
102999fc4:     	bl	0x1029fef14 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102999fc8:     	ldrb	w8, [sp, #0x28]
102999fcc:     	cmp	w8, #0x8
102999fd0:     	b.ne	0x102999fe0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d8>
102999fd4:     	stp	x21, x22, [x20, #0x38]
102999fd8:     	mov	w8, #0x8                ; =8
102999fdc:     	b	0x10299a004 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102999fe0:     	ldrb	w12, [sp, #0x29]
102999fe4:     	ldrb	w11, [sp, #0x2a]
102999fe8:     	ldur	w9, [sp, #0x2b]
102999fec:     	str	w9, [sp, #0x20]
102999ff0:     	ldrb	w9, [sp, #0x2f]
102999ff4:     	strb	w9, [sp, #0x24]
102999ff8:     	ldp	x10, x9, [sp, #0x30]
102999ffc:     	ldur	q0, [sp, #0x40]
10299a000:     	str	q0, [sp, #0x10]
10299a004:     	ldr	x13, [x20, #0x10]
10299a008:     	add	x13, x13, #0x1
10299a00c:     	str	x13, [x20, #0x10]
10299a010:     	strb	w8, [x19]
10299a014:     	strb	w12, [x19, #0x1]
10299a018:     	strb	w11, [x19, #0x2]
10299a01c:     	ldr	w8, [sp, #0x20]
10299a020:     	stur	w8, [x19, #0x3]
10299a024:     	ldrb	w8, [sp, #0x24]
10299a028:     	strb	w8, [x19, #0x7]
10299a02c:     	stp	x10, x9, [x19, #0x8]
10299a030:     	ldr	q0, [sp, #0x10]
10299a034:     	stur	q0, [x19, #0x18]
10299a038:     	ldp	x29, x30, [sp, #0x70]
10299a03c:     	ldp	x20, x19, [sp, #0x60]
10299a040:     	ldp	x22, x21, [sp, #0x50]
10299a044:     	add	sp, sp, #0x80
10299a048:     	ret
10299a04c:     	mov	w8, #0x2                ; =2
10299a050:     	mov	w11, #0x1               ; =1
10299a054:     	b	0x102999fdc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d4>
10299a058:     	adrp	x0, 0x108051000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.310+0x148>
10299a05c:     	add	x0, x0, #0x8d0
10299a060:     	bl	0x103a06618 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10299a064:     	adrp	x0, 0x108051000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.310+0x148>
10299a068:     	add	x0, x0, #0x8e8
10299a06c:     	bl	0x103a065e8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10299a070:     	ldr	x8, [x20, #0x10]
10299a074:     	add	x8, x8, #0x1
10299a078:     	str	x8, [x20, #0x10]
10299a07c:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
