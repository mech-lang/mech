
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102369360 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
102369360:     	sub	sp, sp, #0x80
102369364:     	stp	x20, x19, [sp, #0x60]
102369368:     	stp	x29, x30, [sp, #0x70]
10236936c:     	add	x29, sp, #0x70
102369370:     	ldr	x19, [x0]
102369374:     	ldr	x9, [x19, #0x10]
102369378:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10236937c:     	cmp	x9, x10
102369380:     	b.hs	0x1023693ec <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x8c>
102369384:     	add	x10, x9, #0x1
102369388:     	str	x10, [x19, #0x10]
10236938c:     	ldr	x10, [x19, #0x38]
102369390:     	adds	x10, x10, x1
102369394:     	b.hs	0x1023693f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x98>
102369398:     	str	x9, [x19, #0x10]
10236939c:     	cmp	x10, x2
1023693a0:     	b.ls	0x1023693bc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x5c>
1023693a4:     	mov	w9, #0x606              ; =1542
1023693a8:     	strh	w9, [x8]
1023693ac:     	mov	w9, #0x1                ; =1
1023693b0:     	strb	w9, [x8, #0x2]
1023693b4:     	stp	x10, x2, [x8, #0x8]
1023693b8:     	b	0x1023694ec <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
1023693bc:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
1023693c0:     	add	x0, x0, #0x550
1023693c4:     	ldr	x9, [x0]
1023693c8:     	blr	x9
1023693cc:     	ldrb	w9, [x0, #0x48]
1023693d0:     	cmp	w9, #0x1
1023693d4:     	b.eq	0x102369440 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe0>
1023693d8:     	cmp	w9, #0x2
1023693dc:     	b.ne	0x102369418 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xb8>
1023693e0:     	adrp	x0, 0x108032000 <_anon.686517066f445f70c1782692b9896900.7+0x569e8>
1023693e4:     	add	x0, x0, #0x1b8
1023693e8:     	bl	0x103a020f0 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
1023693ec:     	adrp	x0, 0x108033000 <_anon.75812f05b385a6fb12f95ada298af815.207+0x170>
1023693f0:     	add	x0, x0, #0x9a8
1023693f4:     	bl	0x103a027a4 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1023693f8:     	mov	w10, #0x606             ; =1542
1023693fc:     	strh	w10, [x8]
102369400:     	mov	w10, #0x1               ; =1
102369404:     	strb	w10, [x8, #0x2]
102369408:     	mov	x10, #-0x1              ; =-1
10236940c:     	stp	x10, x2, [x8, #0x8]
102369410:     	str	x9, [x19, #0x10]
102369414:     	b	0x1023694ec <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x18c>
102369418:     	adrp	x9, 0x102a55000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact23guarded_histogram_query8selected9candidateNtNtB6_7program25NativeProgramArtifactPlanEB8_+0xb64>
10236941c:     	add	x9, x9, #0xb18
102369420:     	stp	x1, x0, [sp]
102369424:     	mov	x1, x9
102369428:     	mov	x20, x8
10236942c:     	bl	0x102e6db58 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102369430:     	ldp	x1, x0, [sp]
102369434:     	mov	x8, x20
102369438:     	mov	w9, #0x1                ; =1
10236943c:     	strb	w9, [x0, #0x48]
102369440:     	ldr	x9, [x0, #0x20]
102369444:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102369448:     	cmp	x9, x10
10236944c:     	b.hs	0x1023694fc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x19c>
102369450:     	ldr	x9, [x0, #0x28]
102369454:     	cmp	x9, #0x0
102369458:     	ccmp	x9, x19, #0x4, ne
10236945c:     	b.ne	0x1023694d0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x170>
102369460:     	mov	x20, x8
102369464:     	ldr	x8, [x19, #0x10]
102369468:     	cbnz	x8, 0x102369508 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
10236946c:     	mov	x2, x1
102369470:     	mov	x8, #-0x1               ; =-1
102369474:     	str	x8, [x19, #0x10]
102369478:     	ldr	q0, [x0, #0x30]
10236947c:     	str	q0, [sp, #0x10]
102369480:     	ldr	x8, [x0, #0x40]
102369484:     	str	x8, [sp, #0x20]
102369488:     	add	x0, sp, #0x38
10236948c:     	add	x1, x19, #0x18
102369490:     	add	x4, sp, #0x10
102369494:     	mov	x3, #0x0                ; =0
102369498:     	bl	0x102381244 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits>
10236949c:     	ldr	x8, [x19, #0x10]
1023694a0:     	add	x8, x8, #0x1
1023694a4:     	str	x8, [x19, #0x10]
1023694a8:     	ldrb	w9, [sp, #0x38]
1023694ac:     	ldur	q0, [sp, #0x39]
1023694b0:     	ldur	q1, [sp, #0x49]
1023694b4:     	stp	q0, q1, [sp, #0x10]
1023694b8:     	ldr	x8, [sp, #0x58]
1023694bc:     	stur	x8, [sp, #0x2f]
1023694c0:     	cmp	w9, #0x9
1023694c4:     	mov	x8, x20
1023694c8:     	b.ne	0x1023694d4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x174>
1023694cc:     	b	0x1023693e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x80>
1023694d0:     	mov	w9, #0x0                ; =0
1023694d4:     	strb	w9, [x8]
1023694d8:     	ldp	q0, q1, [sp, #0x10]
1023694dc:     	stur	q0, [x8, #0x1]
1023694e0:     	stur	q1, [x8, #0x11]
1023694e4:     	ldur	x9, [sp, #0x2f]
1023694e8:     	str	x9, [x8, #0x20]
1023694ec:     	ldp	x29, x30, [sp, #0x70]
1023694f0:     	ldp	x20, x19, [sp, #0x60]
1023694f4:     	add	sp, sp, #0x80
1023694f8:     	ret
1023694fc:     	adrp	x0, 0x108033000 <_anon.75812f05b385a6fb12f95ada298af815.207+0x170>
102369500:     	add	x0, x0, #0x960
102369504:     	bl	0x103a027a4 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102369508:     	adrp	x0, 0x108033000 <_anon.75812f05b385a6fb12f95ada298af815.207+0x170>
10236950c:     	add	x0, x0, #0x978
102369510:     	bl	0x103a02774 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102369514:     	ldr	x8, [x19, #0x10]
102369518:     	add	x8, x8, #0x1
10236951c:     	str	x8, [x19, #0x10]
102369520:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
