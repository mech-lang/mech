
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101589cd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>:
101589cd4:     	sub	sp, sp, #0x110
101589cd8:     	stp	x28, x27, [sp, #0xb0]
101589cdc:     	stp	x26, x25, [sp, #0xc0]
101589ce0:     	stp	x24, x23, [sp, #0xd0]
101589ce4:     	stp	x22, x21, [sp, #0xe0]
101589ce8:     	stp	x20, x19, [sp, #0xf0]
101589cec:     	stp	x29, x30, [sp, #0x100]
101589cf0:     	add	x29, sp, #0x100
101589cf4:     	stp	x6, x0, [sp, #0x8]
101589cf8:     	mov	x22, x3
101589cfc:     	mov	x25, x1
101589d00:     	mov	x19, #0x0               ; =0
101589d04:     	mov	x26, #0x0               ; =0
101589d08:     	mov	x23, #0x0               ; =0
101589d0c:     	mov	x24, #0x0               ; =0
101589d10:     	ldp	x27, x9, [x4]
101589d14:     	ldr	x10, [x4, #0x30]
101589d18:     	ldp	x8, x11, [x4, #0x10]
101589d1c:     	stp	x11, x5, [sp, #0x38]
101589d20:     	str	x8, [sp, #0x20]
101589d24:     	ldp	x8, x11, [x4, #0x20]
101589d28:     	stp	x11, x10, [sp, #0x28]
101589d2c:     	str	x8, [sp, #0x18]
101589d30:     	lsl	x8, x2, #7
101589d34:     	sub	x28, x8, x2, lsl #3
101589d38:     	str	x9, [sp]
101589d3c:     	add	x21, x9, #0x1
101589d40:     	cmp	x28, x19
101589d44:     	b.eq	0x101589efc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x228>
101589d48:     	subs	x21, x21, #0x1
101589d4c:     	b.eq	0x101589f94 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2c0>
101589d50:     	ldrb	w8, [x27]
101589d54:     	cmp	w8, #0x3
101589d58:     	b.ne	0x101589e30 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x15c>
101589d5c:     	ldr	x0, [x27, #0x8]
101589d60:     	ldr	x8, [sp, #0x38]
101589d64:     	cmp	x0, x8
101589d68:     	b.hs	0x101589fa8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2d4>
101589d6c:     	ldr	x8, [sp, #0x28]
101589d70:     	cmp	x0, x8
101589d74:     	b.hs	0x101589fb8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2e4>
101589d78:     	ldp	x9, x8, [sp, #0x18]
101589d7c:     	add	x20, x8, x0, lsl #6
101589d80:     	ldr	x8, [x20]
101589d84:     	ldr	x10, [x9, x0, lsl #3]
101589d88:     	cbz	x8, 0x101589e64 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x190>
101589d8c:     	cbnz	x10, 0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589d90:     	ldr	w9, [x20, #0x38]
101589d94:     	add	x8, x25, x19
101589d98:     	ldr	w10, [x8, #0x70]
101589d9c:     	cmp	w9, w10
101589da0:     	b.ne	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589da4:     	ldp	q0, q1, [x20, #0x10]
101589da8:     	stp	q0, q1, [sp, #0x60]
101589dac:     	ldp	x9, x10, [sp, #0x60]
101589db0:     	ldp	x11, x12, [x8, #0x50]
101589db4:     	ldp	x13, x14, [sp, #0x70]
101589db8:     	ldp	x15, x8, [x8, #0x60]
101589dbc:     	cmp	x9, x11
101589dc0:     	ccmp	x10, x12, #0x0, eq
101589dc4:     	ccmp	x13, x15, #0x0, eq
101589dc8:     	ccmp	x14, x8, #0x0, eq
101589dcc:     	b.ne	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589dd0:     	mov	x0, x20
101589dd4:     	ldr	x1, [sp, #0x40]
101589dd8:     	bl	0x102d60768 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
101589ddc:     	cmp	x0, #0x1
101589de0:     	b.ne	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589de4:     	add	x8, sp, #0x60
101589de8:     	mov	x0, x20
101589dec:     	mov	x1, x22
101589df0:     	bl	0x102d5e84c <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
101589df4:     	ldrb	w8, [sp, #0x60]
101589df8:     	cmp	w8, #0x16
101589dfc:     	b.ne	0x101589f34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x260>
101589e00:     	add	x8, sp, #0x60
101589e04:     	add	x0, x25, x19
101589e08:     	mov	x1, x20
101589e0c:     	mov	x2, x22
101589e10:     	bl	0x102366298 <__RNvMNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget15frame_footprintNtB2_28PreparedNativeFrameFootprint5value>
101589e14:     	ldr	w8, [sp, #0x60]
101589e18:     	tbz	w8, #0x0, 0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589e1c:     	ldp	x9, x8, [sp, #0x70]
101589e20:     	ldr	x10, [sp, #0x80]
101589e24:     	adds	x26, x9, x26
101589e28:     	b.lo	0x101589ed8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x204>
101589e2c:     	b	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589e30:     	ldp	q0, q1, [x27]
101589e34:     	stp	q0, q1, [sp, #0x60]
101589e38:     	ldr	x8, [sp, #0x30]
101589e3c:     	ldr	x8, [x8]
101589e40:     	ldr	x1, [x8]
101589e44:     	add	x0, sp, #0x48
101589e48:     	add	x2, sp, #0x60
101589e4c:     	bl	0x1015a6324 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101589e50:     	ldr	x8, [sp, #0x48]
101589e54:     	cmp	x8, #0x1
101589e58:     	b.ne	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589e5c:     	ldp	x20, x10, [sp, #0x50]
101589e60:     	cbnz	x20, 0x101589d8c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0xb8>
101589e64:     	ldrb	w8, [x25, x19]
101589e68:     	tbnz	w8, #0x0, 0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589e6c:     	add	x8, x25, x19
101589e70:     	ldrb	w11, [x8, #0x1]
101589e74:     	ldp	x9, x8, [x8, #0x10]
101589e78:     	cmp	w11, #0x3
101589e7c:     	b.gt	0x101589e98 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1c4>
101589e80:     	sub	w11, w11, #0x1
101589e84:     	cmp	w11, #0x3
101589e88:     	b.lo	0x101589ec8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101589e8c:     	cmp	x10, #0x2
101589e90:     	b.lo	0x101589ec8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101589e94:     	b	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589e98:     	cmp	w11, #0x4
101589e9c:     	b.eq	0x101589eb4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1e0>
101589ea0:     	cmp	w11, #0x5
101589ea4:     	b.ne	0x101589ec0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1ec>
101589ea8:     	cmp	x10, #0x10, lsl #12     ; =0x10000
101589eac:     	b.lo	0x101589ec8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101589eb0:     	b	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589eb4:     	cmp	x10, #0xff
101589eb8:     	b.ls	0x101589ec8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101589ebc:     	b	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589ec0:     	lsr	x10, x10, #32
101589ec4:     	cbnz	x10, 0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589ec8:     	add	x10, x25, x19
101589ecc:     	ldr	x10, [x10, #0x20]
101589ed0:     	adds	x26, x9, x26
101589ed4:     	b.hs	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589ed8:     	adds	x23, x10, x23
101589edc:     	cset	w9, hs
101589ee0:     	adds	x24, x8, x24
101589ee4:     	cset	w8, hs
101589ee8:     	tbnz	w9, #0x0, 0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589eec:     	add	x27, x27, #0x20
101589ef0:     	add	x19, x19, #0x78
101589ef4:     	tbz	w8, #0x0, 0x101589d40 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x6c>
101589ef8:     	b	0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589efc:     	add	x8, sp, #0x60
101589f00:     	ldr	x0, [sp, #0x8]
101589f04:     	mov	x1, x23
101589f08:     	mov	x2, x24
101589f0c:     	bl	0x102372d00 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter29try_charge_borrowed_footprint>
101589f10:     	ldrb	w9, [sp, #0x60]
101589f14:     	ldrb	w8, [sp, #0x61]
101589f18:     	cmp	w9, #0x8
101589f1c:     	b.ne	0x101589f6c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x298>
101589f20:     	tbz	w8, #0x0, 0x101589f3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101589f24:     	mov	w8, #0x1                ; =1
101589f28:     	ldr	x9, [sp, #0x10]
101589f2c:     	stp	x8, x26, [x9, #0x8]
101589f30:     	b	0x101589f44 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x270>
101589f34:     	add	x0, sp, #0x60
101589f38:     	bl	0x10159c3e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
101589f3c:     	ldr	x9, [sp, #0x10]
101589f40:     	str	xzr, [x9, #0x8]
101589f44:     	mov	w8, #0x8                ; =8
101589f48:     	strb	w8, [x9]
101589f4c:     	ldp	x29, x30, [sp, #0x100]
101589f50:     	ldp	x20, x19, [sp, #0xf0]
101589f54:     	ldp	x22, x21, [sp, #0xe0]
101589f58:     	ldp	x24, x23, [sp, #0xd0]
101589f5c:     	ldp	x26, x25, [sp, #0xc0]
101589f60:     	ldp	x28, x27, [sp, #0xb0]
101589f64:     	add	sp, sp, #0x110
101589f68:     	ret
101589f6c:     	ldur	q0, [sp, #0x62]
101589f70:     	ldr	x11, [sp, #0x10]
101589f74:     	stur	q0, [x11, #0x2]
101589f78:     	ldur	q0, [sp, #0x72]
101589f7c:     	stur	q0, [x11, #0x12]
101589f80:     	ldr	x10, [sp, #0x80]
101589f84:     	str	x10, [x11, #0x20]
101589f88:     	strb	w9, [x11]
101589f8c:     	strb	w8, [x11, #0x1]
101589f90:     	b	0x101589f4c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x278>
101589f94:     	adrp	x2, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101589f98:     	add	x2, x2, #0x548
101589f9c:     	ldr	x0, [sp]
101589fa0:     	mov	x1, x0
101589fa4:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101589fa8:     	adrp	x2, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101589fac:     	add	x2, x2, #0x560
101589fb0:     	ldr	x1, [sp, #0x38]
101589fb4:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101589fb8:     	adrp	x2, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101589fbc:     	add	x2, x2, #0x578
101589fc0:     	ldr	x1, [sp, #0x28]
101589fc4:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
