
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101590760 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>:
101590760:     	stp	x28, x27, [sp, #-0x60]!
101590764:     	stp	x26, x25, [sp, #0x10]
101590768:     	stp	x24, x23, [sp, #0x20]
10159076c:     	stp	x22, x21, [sp, #0x30]
101590770:     	stp	x20, x19, [sp, #0x40]
101590774:     	stp	x29, x30, [sp, #0x50]
101590778:     	add	x29, sp, #0x50
10159077c:     	sub	sp, sp, #0x610
101590780:     	str	xzr, [sp]
101590784:     	mov	x23, x1
101590788:     	mov	x20, x8
10159078c:     	ldr	x8, [x0]
101590790:     	mov	x0, #0x0                ; =0
101590794:     	blr	x8
101590798:     	cbz	x0, 0x101591244 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xae4>
10159079c:     	mov	x19, x0
1015907a0:     	mov	x8, x0
1015907a4:     	ldr	x9, [x8, #0x20]!
1015907a8:     	cbnz	x9, 0x1015911d0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa70>
1015907ac:     	ldp	x0, x21, [x23]
1015907b0:     	ldp	x28, x24, [x23, #0x10]
1015907b4:     	ldp	x26, x22, [x23, #0x20]
1015907b8:     	ldp	x27, x16, [x23, #0x38]
1015907bc:     	ldp	x17, x14, [x23, #0x48]
1015907c0:     	ldp	x9, x25, [x23, #0x58]
1015907c4:     	str	x9, [sp, #0x70]
1015907c8:     	ldp	x9, x11, [x23, #0x68]
1015907cc:     	str	x9, [sp, #0x60]
1015907d0:     	ldp	x12, x1, [x23, #0x78]
1015907d4:     	ldp	x13, x15, [x23, #0x88]
1015907d8:     	mov	x9, #-0x1               ; =-1
1015907dc:     	str	x9, [x19, #0x20]
1015907e0:     	ldr	x10, [x19, #0x28]
1015907e4:     	ldr	x9, [x0]
1015907e8:     	cbz	x10, 0x101590804 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
1015907ec:     	cmp	x10, x9
1015907f0:     	b.eq	0x101590804 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
1015907f4:     	mov	x9, #0x0                ; =0
1015907f8:     	str	xzr, [x8]
1015907fc:     	mov	w26, #0x2f              ; =47
101590800:     	b	0x101590c28 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4c8>
101590804:     	ldr	x10, [x9]
101590808:     	adds	x10, x10, #0x1
10159080c:     	str	x10, [x9]
101590810:     	b.hs	0x10159127c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
101590814:     	str	x11, [sp, #0x10]
101590818:     	ldp	x11, x10, [x19, #0x20]
10159081c:     	add	x11, x11, #0x1
101590820:     	stp	x11, x9, [x19, #0x20]
101590824:     	stp	x8, x10, [sp, #0x88]
101590828:     	ldr	x23, [x0]
10159082c:     	ldr	x8, [x23]
101590830:     	adds	x8, x8, #0x1
101590834:     	str	x8, [x23]
101590838:     	b.hs	0x10159127c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
10159083c:     	stp	xzr, xzr, [sp, #0xd8]
101590840:     	str	x23, [sp, #0xd0]
101590844:     	ldr	x8, [x19]
101590848:     	cbnz	x8, 0x101591214 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xab4>
10159084c:     	stp	x13, x1, [sp, #0x38]
101590850:     	stp	x17, x14, [sp, #0x18]
101590854:     	stp	x16, x15, [sp, #0x28]
101590858:     	str	x12, [sp, #0x8]
10159085c:     	ldur	q0, [x19, #0x8]
101590860:     	ldr	x8, [x19, #0x18]
101590864:     	str	x8, [sp, #0xb0]
101590868:     	stur	q0, [sp, #0xa0]
10159086c:     	ldr	q0, [sp, #0xd0]
101590870:     	ldr	x8, [sp, #0xe0]
101590874:     	str	x8, [x19, #0x18]
101590878:     	stur	q0, [x19, #0x8]
10159087c:     	str	x19, [sp, #0x98]
101590880:     	bl	0x1023697a8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101590884:     	ldp	x12, x9, [x19, #0x30]
101590888:     	ldr	x11, [x19, #0x40]
10159088c:     	ldr	x8, [x21]
101590890:     	adds	x8, x0, x8
101590894:     	csinv	x8, x8, xzr, lo
101590898:     	cmp	x9, x8
10159089c:     	stp	x11, x9, [sp, #0x48]
1015908a0:     	csel	x9, x9, x8, lo
1015908a4:     	ldr	x10, [x28]
1015908a8:     	adds	x10, x1, x10
1015908ac:     	csinv	x10, x10, xzr, lo
1015908b0:     	cmp	x11, x10
1015908b4:     	csel	x11, x11, x10, lo
1015908b8:     	str	x12, [sp, #0x58]
1015908bc:     	tst	w12, #0x1
1015908c0:     	csel	x8, x9, x8, ne
1015908c4:     	csel	x9, x11, x10, ne
1015908c8:     	mov	w10, #0x1               ; =1
1015908cc:     	stp	x10, x8, [x19, #0x30]
1015908d0:     	str	x9, [x19, #0x40]
1015908d4:     	add	x8, sp, #0xb8
1015908d8:     	mov	x0, x24
1015908dc:     	bl	0x102368ae4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015908e0:     	add	x23, sp, #0x320
1015908e4:     	add	x28, sp, #0x230
1015908e8:     	ldp	q0, q1, [x26, #0x80]
1015908ec:     	stp	q0, q1, [x28, #0x80]
1015908f0:     	ldr	x8, [x26, #0xa0]
1015908f4:     	str	x8, [sp, #0x2d0]
1015908f8:     	ldp	q0, q1, [x26, #0x40]
1015908fc:     	stp	q0, q1, [x28, #0x40]
101590900:     	ldp	q1, q0, [x26, #0x60]
101590904:     	stp	q1, q0, [x28, #0x60]
101590908:     	ldp	q0, q1, [x26]
10159090c:     	stp	q0, q1, [x28]
101590910:     	ldp	q1, q0, [x26, #0x20]
101590914:     	stp	q1, q0, [x28, #0x20]
101590918:     	ldr	q0, [x22, #0x30]
10159091c:     	str	q0, [x28, #0x120]
101590920:     	ldr	q0, [x22, #0x40]
101590924:     	str	q0, [x28, #0x130]
101590928:     	ldr	q0, [x22, #0x50]
10159092c:     	str	q0, [x28, #0x140]
101590930:     	ldr	x8, [x22, #0x60]
101590934:     	str	x8, [sp, #0x380]
101590938:     	ldr	q0, [x22]
10159093c:     	str	q0, [x28, #0xf0]
101590940:     	ldr	q0, [x22, #0x10]
101590944:     	str	q0, [x28, #0x100]
101590948:     	ldr	q0, [x22, #0x20]
10159094c:     	str	q0, [x28, #0x110]
101590950:     	ldr	q0, [x26, #0x70]
101590954:     	str	q0, [x23, #0x1a0]
101590958:     	ldr	q0, [x26, #0x80]
10159095c:     	str	q0, [x23, #0x1b0]
101590960:     	ldr	q0, [x26, #0x90]
101590964:     	str	q0, [x23, #0x1c0]
101590968:     	ldr	x8, [x26, #0xa0]
10159096c:     	str	x8, [sp, #0x4f0]
101590970:     	ldr	q0, [x26, #0x30]
101590974:     	str	q0, [x23, #0x160]
101590978:     	ldr	q0, [x26, #0x40]
10159097c:     	str	q0, [x23, #0x170]
101590980:     	ldr	q0, [x26, #0x50]
101590984:     	str	q0, [x23, #0x180]
101590988:     	ldr	q0, [x26, #0x60]
10159098c:     	str	q0, [x23, #0x190]
101590990:     	ldr	q0, [x26]
101590994:     	str	q0, [x23, #0x130]
101590998:     	ldr	q0, [x26, #0x10]
10159099c:     	str	q0, [x23, #0x140]
1015909a0:     	ldr	q0, [x26, #0x20]
1015909a4:     	str	q0, [x23, #0x150]
1015909a8:     	add	x8, sp, #0xd0
1015909ac:     	add	x1, sp, #0x450
1015909b0:     	add	x2, sp, #0x320
1015909b4:     	mov	x0, x24
1015909b8:     	bl	0x102368174 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext3new>
1015909bc:     	ldr	x25, [x25]
1015909c0:     	lsr	x8, x25, #61
1015909c4:     	cbnz	x8, 0x101591224 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xac4>
1015909c8:     	lsl	x26, x25, #3
1015909cc:     	mov	w8, #0x2c               ; =44
1015909d0:     	strb	w8, [sp, #0x450]
1015909d4:     	add	x0, sp, #0x450
1015909d8:     	bl	0x10159d258 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015909dc:     	add	x8, sp, #0x320
1015909e0:     	add	x0, sp, #0xd0
1015909e4:     	mov	x1, x26
1015909e8:     	mov	x2, #0x0                ; =0
1015909ec:     	bl	0x102368440 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
1015909f0:     	ldrb	w8, [sp, #0x320]
1015909f4:     	cmp	w8, #0x8
1015909f8:     	b.ne	0x101590adc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x37c>
1015909fc:     	add	x8, sp, #0x450
101590a00:     	add	x0, sp, #0xd0
101590a04:     	add	x2, x27, #0x8
101590a08:     	mov	x1, x25
101590a0c:     	bl	0x102367f0c <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext14check_capacity>
101590a10:     	add	x21, sp, #0x450
101590a14:     	ldrb	w8, [sp, #0x450]
101590a18:     	cmp	w8, #0x8
101590a1c:     	b.ne	0x101590af4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x394>
101590a20:     	add	x8, sp, #0x450
101590a24:     	add	x0, sp, #0xb8
101590a28:     	mov	x1, x25
101590a2c:     	bl	0x102e34ea4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101590a30:     	ldr	w25, [sp, #0x450]
101590a34:     	cmp	w25, #0x1a
101590a38:     	b.ne	0x101590c6c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x50c>
101590a3c:     	ldur	q0, [x21, #0x8]
101590a40:     	ldur	q1, [x21, #0x18]
101590a44:     	stp	q0, q1, [x28, #0xb0]
101590a48:     	add	x8, sp, #0x450
101590a4c:     	add	x0, sp, #0xb8
101590a50:     	add	x1, x27, #0x8
101590a54:     	bl	0x102e34d78 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
101590a58:     	ldr	w25, [sp, #0x450]
101590a5c:     	cmp	w25, #0x1a
101590a60:     	ldr	x8, [sp, #0x40]
101590a64:     	b.ne	0x101590c90 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x530>
101590a68:     	ldur	q0, [x21, #0x8]
101590a6c:     	ldur	q1, [x21, #0x18]
101590a70:     	stp	q0, q1, [x28, #0xd0]
101590a74:     	ldr	x1, [x8]
101590a78:     	cbz	x1, 0x101590aa0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x340>
101590a7c:     	ldr	x2, [x8, #0x8]
101590a80:     	add	x8, sp, #0x450
101590a84:     	add	x3, sp, #0xb8
101590a88:     	add	x4, sp, #0xd0
101590a8c:     	ldr	x0, [sp, #0x38]
101590a90:     	bl	0x1026b73c8 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB6_25NativePreparedLibraryCall23admit_composed_selector>
101590a94:     	ldrb	w26, [sp, #0x450]
101590a98:     	cmp	w26, #0x2e
101590a9c:     	b.ne	0x10159108c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x92c>
101590aa0:     	add	x8, sp, #0x450
101590aa4:     	add	x1, sp, #0x230
101590aa8:     	mov	x0, x24
101590aac:     	bl	0x102371818 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter21for_native_projection>
101590ab0:     	ldr	x9, [sp, #0x450]
101590ab4:     	ldr	x8, [sp, #0x458]
101590ab8:     	ldp	q2, q3, [x21, #0x10]
101590abc:     	cmp	x9, #0x2
101590ac0:     	b.ne	0x101590cb4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x554>
101590ac4:     	stp	q3, q2, [sp, #0x60]
101590ac8:     	and	w25, w8, #0xff
101590acc:     	lsr	w21, w8, #8
101590ad0:     	lsr	x22, x8, #32
101590ad4:     	mov	w26, #0x29              ; =41
101590ad8:     	b	0x1015910d4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
101590adc:     	ldr	w22, [sp, #0x324]
101590ae0:     	ldr	w8, [sp, #0x320]
101590ae4:     	ldur	q0, [x23, #0x18]
101590ae8:     	str	q0, [sp, #0x60]
101590aec:     	ldur	q0, [x23, #0x8]
101590af0:     	b	0x101590b08 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3a8>
101590af4:     	ldr	w22, [sp, #0x454]
101590af8:     	ldr	w8, [sp, #0x450]
101590afc:     	ldur	q0, [x21, #0x18]
101590b00:     	str	q0, [sp, #0x60]
101590b04:     	ldur	q0, [x21, #0x8]
101590b08:     	str	q0, [sp, #0x70]
101590b0c:     	and	w25, w8, #0xff
101590b10:     	lsr	w21, w8, #8
101590b14:     	mov	w26, #0x29              ; =41
101590b18:     	ldr	w8, [sp, #0x200]
101590b1c:     	cmp	w8, #0x1a
101590b20:     	b.eq	0x101590b74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101590b24:     	cmp	w8, #0xa
101590b28:     	b.eq	0x101590b44 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3e4>
101590b2c:     	cmp	w8, #0x13
101590b30:     	b.ne	0x101590b74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101590b34:     	ldr	x1, [sp, #0x210]
101590b38:     	mov	w8, #0x10               ; =16
101590b3c:     	cbnz	x1, 0x101590b5c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3fc>
101590b40:     	b	0x101590b74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101590b44:     	ldr	x1, [sp, #0x218]
101590b48:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101590b4c:     	cmp	x1, x8
101590b50:     	b.eq	0x101590b74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101590b54:     	mov	w8, #0x18               ; =24
101590b58:     	cbz	x1, 0x101590b74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101590b5c:     	add	x9, sp, #0xd0
101590b60:     	add	x9, x9, #0x130
101590b64:     	add	x8, x9, x8
101590b68:     	ldr	x0, [x8, #0x8]
101590b6c:     	mov	w2, #0x1                ; =1
101590b70:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101590b74:     	ldr	x8, [sp, #0xb8]
101590b78:     	mov	x9, #-0x1               ; =-1
101590b7c:     	ldaddl	x9, x8, [x8]
101590b80:     	cmp	x8, #0x1
101590b84:     	b.ne	0x101590b94 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
101590b88:     	dmb	ishld
101590b8c:     	add	x0, sp, #0xb8
101590b90:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101590b94:     	add	x27, sp, #0x98
101590b98:     	ldur	w8, [x29, #-0xe0]
101590b9c:     	str	w8, [sp, #0xd0]
101590ba0:     	ldurh	w8, [x29, #-0xdc]
101590ba4:     	strh	w8, [sp, #0xd4]
101590ba8:     	ldp	x8, x9, [sp, #0x50]
101590bac:     	stp	x9, x8, [x19, #0x30]
101590bb0:     	ldr	x8, [sp, #0x48]
101590bb4:     	str	x8, [x19, #0x40]
101590bb8:     	add	x0, sp, #0x98
101590bbc:     	bl	0x1023ac474 <__RNvXs_NvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBa_23NativeLibraryWorkBudget16with_call_limitsNtB4_10ScopeGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101590bc0:     	ldr	x8, [sp, #0xa0]
101590bc4:     	cbz	x8, 0x101590be0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
101590bc8:     	ldr	x9, [x8]
101590bcc:     	subs	x9, x9, #0x1
101590bd0:     	str	x9, [x8]
101590bd4:     	b.ne	0x101590be0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
101590bd8:     	add	x0, x27, #0x8
101590bdc:     	bl	0x10236e608 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101590be0:     	add	x19, sp, #0x88
101590be4:     	add	x0, sp, #0x88
101590be8:     	bl	0x102390bc8 <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101590bec:     	and	x27, x21, #0xffffff
101590bf0:     	mov	w21, w22
101590bf4:     	ldr	x8, [sp, #0x90]
101590bf8:     	cbz	x8, 0x101590c14 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
101590bfc:     	ldr	x9, [x8]
101590c00:     	subs	x9, x9, #0x1
101590c04:     	str	x9, [x8]
101590c08:     	b.ne	0x101590c14 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
101590c0c:     	add	x0, x19, #0x8
101590c10:     	bl	0x10236e608 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101590c14:     	lsl	x8, x27, #8
101590c18:     	orr	x8, x8, x21, lsl #32
101590c1c:     	mov	w9, w25
101590c20:     	orr	x9, x8, x9
101590c24:     	ldp	q1, q0, [sp, #0x60]
101590c28:     	ldr	w8, [sp, #0xd0]
101590c2c:     	stur	w8, [x20, #0x2]
101590c30:     	ldrh	w8, [sp, #0xd4]
101590c34:     	strh	w8, [x20, #0x6]
101590c38:     	strb	w26, [x20]
101590c3c:     	strb	w23, [x20, #0x1]
101590c40:     	str	x9, [x20, #0x8]
101590c44:     	stp	q0, q1, [x20, #0x10]
101590c48:     	str	x24, [x20, #0x30]
101590c4c:     	add	sp, sp, #0x610
101590c50:     	ldp	x29, x30, [sp, #0x50]
101590c54:     	ldp	x20, x19, [sp, #0x40]
101590c58:     	ldp	x22, x21, [sp, #0x30]
101590c5c:     	ldp	x24, x23, [sp, #0x20]
101590c60:     	ldp	x26, x25, [sp, #0x10]
101590c64:     	ldp	x28, x27, [sp], #0x60
101590c68:     	ret
101590c6c:     	add	x8, sp, #0x450
101590c70:     	mov	w21, #0x0               ; =0
101590c74:     	ldr	w22, [sp, #0x454]
101590c78:     	ldur	q1, [x8, #0x18]
101590c7c:     	ldur	q0, [x8, #0x8]
101590c80:     	stp	q1, q0, [sp, #0x60]
101590c84:     	mov	w26, #0x2b              ; =43
101590c88:     	ldr	x24, [sp, #0x478]
101590c8c:     	b	0x101590b18 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101590c90:     	add	x8, sp, #0x450
101590c94:     	mov	w21, #0x0               ; =0
101590c98:     	ldr	w22, [sp, #0x454]
101590c9c:     	ldur	q1, [x8, #0x18]
101590ca0:     	ldur	q0, [x8, #0x8]
101590ca4:     	stp	q1, q0, [sp, #0x60]
101590ca8:     	mov	w26, #0x2b              ; =43
101590cac:     	ldr	x24, [sp, #0x478]
101590cb0:     	b	0x1015910fc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x99c>
101590cb4:     	ldp	q0, q1, [x21, #0xf0]
101590cb8:     	stp	q0, q1, [x28, #0x1e0]
101590cbc:     	ldp	q0, q1, [x21, #0x110]
101590cc0:     	stp	q0, q1, [x28, #0x200]
101590cc4:     	ldp	q0, q1, [x21, #0xb0]
101590cc8:     	stp	q0, q1, [x28, #0x1a0]
101590ccc:     	ldp	q0, q1, [x21, #0xd0]
101590cd0:     	stp	q0, q1, [x28, #0x1c0]
101590cd4:     	ldp	q0, q1, [x21, #0x70]
101590cd8:     	stp	q0, q1, [x28, #0x160]
101590cdc:     	ldp	q0, q1, [x21, #0x90]
101590ce0:     	stp	q0, q1, [x28, #0x180]
101590ce4:     	ldp	q0, q1, [x21, #0x30]
101590ce8:     	stp	q0, q1, [x28, #0x120]
101590cec:     	ldp	q0, q1, [x21, #0x50]
101590cf0:     	stp	q0, q1, [x28, #0x140]
101590cf4:     	stp	q2, q3, [x28, #0x100]
101590cf8:     	str	x8, [sp, #0x328]
101590cfc:     	str	x9, [sp, #0x320]
101590d00:     	ldr	x10, [sp, #0x70]
101590d04:     	ldr	x1, [x10]
101590d08:     	cbz	x1, 0x101590d70 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
101590d0c:     	ldp	x9, x8, [sp, #0x30]
101590d10:     	ldr	x8, [x8, #0x190]
101590d14:     	ldr	q0, [x9]
101590d18:     	str	q0, [x21]
101590d1c:     	ldr	q0, [x9, #0x10]
101590d20:     	str	q0, [x21, #0x10]
101590d24:     	ldr	q0, [x9, #0x20]
101590d28:     	str	q0, [x21, #0x20]
101590d2c:     	ldr	x9, [x9, #0x30]
101590d30:     	str	x9, [sp, #0x480]
101590d34:     	ldr	x2, [x10, #0x8]
101590d38:     	sub	x0, x29, #0xe0
101590d3c:     	add	x3, x8, #0x10
101590d40:     	add	x4, sp, #0x450
101590d44:     	add	x5, sp, #0xb8
101590d48:     	add	x6, sp, #0x320
101590d4c:     	bl	0x101589cd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>
101590d50:     	ldurb	w25, [x29, #-0xe0]
101590d54:     	cmp	w25, #0x8
101590d58:     	b.ne	0x101590fd4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x874>
101590d5c:     	ldur	x8, [x29, #-0xd8]
101590d60:     	cbz	x8, 0x101590d70 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
101590d64:     	ldur	x22, [x29, #-0xd0]
101590d68:     	ldr	x11, [sp, #0x30]
101590d6c:     	b	0x101591004 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
101590d70:     	ldr	x11, [sp, #0x30]
101590d74:     	ldr	x8, [sp, #0x18]
101590d78:     	cbz	x8, 0x101591000 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a0>
101590d7c:     	mov	x21, #0x0               ; =0
101590d80:     	mov	x22, #0x0               ; =0
101590d84:     	mov	x24, #0x0               ; =0
101590d88:     	adrp	x9, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101590d8c:     	add	x9, x9, #0x548
101590d90:     	str	x9, [sp, #0x40]
101590d94:     	lsl	x28, x8, #2
101590d98:     	mov	w27, #0x2c              ; =44
101590d9c:     	ldr	x1, [x11, #0x8]
101590da0:     	cmp	x24, x1
101590da4:     	b.hs	0x101591270 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb10>
101590da8:     	ldr	x8, [x11]
101590dac:     	add	x8, x8, x21
101590db0:     	ldrb	w9, [x8]
101590db4:     	cmp	w9, #0x3
101590db8:     	str	x22, [sp, #0x70]
101590dbc:     	b.ne	0x101590e00 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6a0>
101590dc0:     	ldr	x8, [x8, #0x8]
101590dc4:     	ldr	x1, [x11, #0x18]
101590dc8:     	cmp	x8, x1
101590dcc:     	b.hs	0x101591250 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xaf0>
101590dd0:     	ldr	x1, [x11, #0x28]
101590dd4:     	cmp	x8, x1
101590dd8:     	b.hs	0x101591260 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb00>
101590ddc:     	ldr	x9, [x11, #0x10]
101590de0:     	add	x9, x9, x8, lsl #6
101590de4:     	ldr	x10, [x9]
101590de8:     	cmp	x10, #0x0
101590dec:     	csel	x26, xzr, x9, eq
101590df0:     	ldr	x9, [x11, #0x20]
101590df4:     	ldr	x25, [x9, x8, lsl #3]
101590df8:     	strb	w27, [sp, #0x450]
101590dfc:     	b	0x101590e40 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6e0>
101590e00:     	ldr	q0, [x8]
101590e04:     	add	x9, sp, #0x450
101590e08:     	str	q0, [x9]
101590e0c:     	ldr	q0, [x8, #0x10]
101590e10:     	str	q0, [x9, #0x10]
101590e14:     	ldr	x8, [x11, #0x30]
101590e18:     	ldr	x8, [x8]
101590e1c:     	ldr	x1, [x8]
101590e20:     	sub	x0, x29, #0xe0
101590e24:     	add	x2, sp, #0x450
101590e28:     	bl	0x1015a6324 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101590e2c:     	ldur	x8, [x29, #-0xe0]
101590e30:     	strb	w27, [sp, #0x450]
101590e34:     	cmp	x8, #0x1
101590e38:     	b.ne	0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590e3c:     	ldp	x26, x25, [x29, #-0xd8]
101590e40:     	add	x0, sp, #0x450
101590e44:     	bl	0x10159d258 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101590e48:     	ldr	x8, [sp, #0x38]
101590e4c:     	ldr	x23, [x8, #0x190]
101590e50:     	ldr	x8, [sp, #0x28]
101590e54:     	ldr	w22, [x8, x24, lsl #2]
101590e58:     	ldr	x8, [x23, #0x28]
101590e5c:     	cmp	x8, x22
101590e60:     	b.ls	0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590e64:     	ldr	x8, [x23, #0x20]
101590e68:     	mov	w9, #0x2c               ; =44
101590e6c:     	add	x27, x8, x22, lsl #7
101590e70:     	strb	w9, [sp, #0x450]
101590e74:     	add	x0, sp, #0x450
101590e78:     	bl	0x10159d258 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101590e7c:     	cbz	x26, 0x101590f24 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x7c4>
101590e80:     	cbnz	x25, 0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590e84:     	ldr	w8, [x26, #0x38]
101590e88:     	cmp	w8, w22
101590e8c:     	b.ne	0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590e90:     	ldp	q1, q0, [x26, #0x10]
101590e94:     	add	x8, sp, #0x450
101590e98:     	stp	q1, q0, [x8, #0x130]
101590e9c:     	ldur	q0, [x27, #0x70]
101590ea0:     	str	q0, [x8]
101590ea4:     	ldur	q0, [x27, #0x80]
101590ea8:     	str	q0, [x8, #0x10]
101590eac:     	ldp	x8, x9, [x29, #-0xe0]
101590eb0:     	ldr	x10, [sp, #0x450]
101590eb4:     	ldr	x11, [sp, #0x458]
101590eb8:     	ldp	x12, x13, [x29, #-0xd0]
101590ebc:     	ldr	x14, [sp, #0x460]
101590ec0:     	ldr	x15, [sp, #0x468]
101590ec4:     	cmp	x8, x10
101590ec8:     	ccmp	x9, x11, #0x0, eq
101590ecc:     	ccmp	x12, x14, #0x0, eq
101590ed0:     	ccmp	x13, x15, #0x0, eq
101590ed4:     	b.ne	0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590ed8:     	add	x1, sp, #0xb8
101590edc:     	mov	x0, x26
101590ee0:     	bl	0x102d60768 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
101590ee4:     	mov	w27, #0x2c              ; =44
101590ee8:     	cmp	x0, #0x1
101590eec:     	b.ne	0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590ef0:     	sub	x8, x29, #0xb8
101590ef4:     	add	x1, x23, #0x10
101590ef8:     	mov	x0, x26
101590efc:     	bl	0x102d5e84c <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
101590f00:     	ldurb	w8, [x29, #-0xb8]
101590f04:     	cmp	w8, #0x16
101590f08:     	b.ne	0x101591230 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad0>
101590f0c:     	add	x8, sp, #0x450
101590f10:     	add	x0, sp, #0x320
101590f14:     	add	x2, x23, #0x10
101590f18:     	mov	x1, x26
101590f1c:     	bl	0x1023834b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget42measure_borrowed_canonical_value_footprint>
101590f20:     	b	0x101590f94 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x834>
101590f24:     	ldur	x8, [x27, #0x58]
101590f28:     	cbnz	x8, 0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590f2c:     	ldurh	w1, [x27, #0x12]
101590f30:     	ldurb	w0, [x27, #0x10]
101590f34:     	bl	0x1015a3e58 <__RNvMNtCs1qJAwyMG1lC_11mech_engine13native_scalarNtB2_16NativeScalarKind16from_schema_body>
101590f38:     	and	w26, w0, #0xff
101590f3c:     	mov	w22, #0x2c              ; =44
101590f40:     	strb	w22, [sp, #0x450]
101590f44:     	cmp	w26, #0x7
101590f48:     	b.eq	0x101591238 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad8>
101590f4c:     	add	x0, sp, #0x450
101590f50:     	bl	0x10159d258 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101590f54:     	sub	x0, x29, #0x70
101590f58:     	mov	x1, x26
101590f5c:     	mov	x2, x25
101590f60:     	bl	0x1015a3ec8 <__RNvMNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact2irNtB2_17NativeScalarValue9from_bits>
101590f64:     	strb	w22, [sp, #0x450]
101590f68:     	ldurb	w8, [x29, #-0x70]
101590f6c:     	cmp	w8, #0x7
101590f70:     	b.eq	0x101591238 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad8>
101590f74:     	add	x0, sp, #0x450
101590f78:     	bl	0x10159d258 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101590f7c:     	add	x8, sp, #0x450
101590f80:     	add	x0, sp, #0x320
101590f84:     	add	x1, x27, #0x10
101590f88:     	sub	x2, x29, #0x70
101590f8c:     	bl	0x102382808 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget37measure_native_scalar_frame_footprint>
101590f90:     	mov	w27, #0x2c              ; =44
101590f94:     	ldrb	w25, [sp, #0x450]
101590f98:     	cmp	w25, #0x8
101590f9c:     	b.ne	0x1015911f0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa90>
101590fa0:     	ldr	x8, [sp, #0x460]
101590fa4:     	ldr	x22, [sp, #0x70]
101590fa8:     	adds	x22, x8, x22
101590fac:     	b.hs	0x1015910c4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
101590fb0:     	strb	w27, [sp, #0x450]
101590fb4:     	add	x0, sp, #0x450
101590fb8:     	bl	0x10159d258 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101590fbc:     	add	x21, x21, #0x20
101590fc0:     	add	x24, x24, #0x1
101590fc4:     	subs	x28, x28, #0x4
101590fc8:     	ldr	x11, [sp, #0x30]
101590fcc:     	b.ne	0x101590d9c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x63c>
101590fd0:     	b	0x101591004 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
101590fd4:     	sub	x8, x29, #0xe0
101590fd8:     	ldurb	w9, [x29, #-0xdd]
101590fdc:     	ldurh	w10, [x8, #0x1]
101590fe0:     	orr	w21, w10, w9, lsl #16
101590fe4:     	ldur	w22, [x29, #-0xdc]
101590fe8:     	ldur	q0, [x8, #0x18]
101590fec:     	str	q0, [sp, #0x60]
101590ff0:     	ldur	q0, [x8, #0x8]
101590ff4:     	str	q0, [sp, #0x70]
101590ff8:     	mov	w26, #0x29              ; =41
101590ffc:     	b	0x1015910d4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
101591000:     	mov	x22, #0x0               ; =0
101591004:     	ldr	x0, [sp, #0x20]
101591008:     	mov	x1, x11
10159100c:     	bl	0x1014c38ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_>
101591010:     	add	x21, sp, #0x450
101591014:     	tbnz	w0, #0x0, 0x10159103c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8dc>
101591018:     	ldp	x2, x8, [sp, #0x30]
10159101c:     	ldr	x9, [x8, #0x190]
101591020:     	add	x8, sp, #0x450
101591024:     	add	x1, x9, #0x10
101591028:     	ldr	x0, [sp, #0x20]
10159102c:     	bl	0x1014c3b88 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_>
101591030:     	ldrb	w26, [sp, #0x450]
101591034:     	cmp	w26, #0x2e
101591038:     	b.ne	0x10159108c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x92c>
10159103c:     	ldr	x8, [sp, #0x60]
101591040:     	ldr	x8, [x8]
101591044:     	subs	x8, x22, x8
101591048:     	ldr	x11, [sp, #0x38]
10159104c:     	add	x12, sp, #0x450
101591050:     	b.lo	0x10159106c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x90c>
101591054:     	ldr	x9, [sp, #0x10]
101591058:     	ldr	x9, [x9]
10159105c:     	mov	w10, #0x2c              ; =44
101591060:     	strb	w10, [sp, #0x450]
101591064:     	adds	x22, x9, x8
101591068:     	b.lo	0x101591128 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x9c8>
10159106c:     	mov	w21, #0x0               ; =0
101591070:     	mov	w25, #0x0               ; =0
101591074:     	mov	w22, #0x0               ; =0
101591078:     	ldur	w8, [x12, #0x2]
10159107c:     	stur	w8, [x29, #-0xe0]
101591080:     	ldrh	w8, [sp, #0x456]
101591084:     	sturh	w8, [x29, #-0xdc]
101591088:     	b	0x1015910d0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
10159108c:     	ldrb	w23, [sp, #0x451]
101591090:     	ldur	w8, [x21, #0x2]
101591094:     	stur	w8, [x29, #-0xe0]
101591098:     	ldrh	w8, [sp, #0x456]
10159109c:     	sturh	w8, [x29, #-0xdc]
1015910a0:     	ldr	w22, [sp, #0x45c]
1015910a4:     	ldr	w8, [sp, #0x458]
1015910a8:     	and	w25, w8, #0xff
1015910ac:     	add	x9, sp, #0x450
1015910b0:     	lsr	w21, w8, #8
1015910b4:     	ldp	q0, q1, [x9, #0x10]
1015910b8:     	stp	q1, q0, [sp, #0x60]
1015910bc:     	ldr	x24, [sp, #0x480]
1015910c0:     	b	0x1015910d4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015910c4:     	mov	w21, #0x0               ; =0
1015910c8:     	mov	w25, #0x0               ; =0
1015910cc:     	mov	w22, #0x0               ; =0
1015910d0:     	mov	w26, #0x2c              ; =44
1015910d4:     	add	x0, sp, #0x300
1015910d8:     	bl	0x102e4b598 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_22ManagedNodeReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
1015910dc:     	ldr	x8, [sp, #0x300]
1015910e0:     	mov	x9, #-0x1               ; =-1
1015910e4:     	ldaddl	x9, x8, [x8]
1015910e8:     	cmp	x8, #0x1
1015910ec:     	b.ne	0x1015910fc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x99c>
1015910f0:     	dmb	ishld
1015910f4:     	add	x0, sp, #0x300
1015910f8:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015910fc:     	add	x0, sp, #0x2e0
101591100:     	bl	0x102e4b618 <__RNvXs6_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101591104:     	ldr	x8, [sp, #0x2e0]
101591108:     	mov	x9, #-0x1               ; =-1
10159110c:     	ldaddl	x9, x8, [x8]
101591110:     	cmp	x8, #0x1
101591114:     	b.ne	0x101590b18 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101591118:     	dmb	ishld
10159111c:     	add	x0, sp, #0x2e0
101591120:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101591124:     	b	0x101590b18 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101591128:     	add	x0, sp, #0x450
10159112c:     	mov	x21, x11
101591130:     	bl	0x10159d258 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101591134:     	ldr	w8, [x21, #0x110]
101591138:     	ldr	x9, [sp, #0x8]
10159113c:     	ldr	x9, [x9]
101591140:     	movi.2d	v0, #0000000000000000
101591144:     	add	x21, sp, #0x450
101591148:     	stp	q0, q0, [x21, #0x20]
10159114c:     	str	q0, [x21, #0x40]
101591150:     	str	xzr, [sp, #0x4a0]
101591154:     	str	x9, [sp, #0x4a8]
101591158:     	str	wzr, [sp, #0x4b0]
10159115c:     	stp	q0, q0, [x21]
101591160:     	mov	w9, #0x3                ; =3
101591164:     	orr	x1, x9, x8, lsl #32
101591168:     	sub	x0, x29, #0xe0
10159116c:     	add	x2, sp, #0x450
101591170:     	add	x4, sp, #0x230
101591174:     	mov	x3, x22
101591178:     	bl	0x10159f9dc <__RINvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget30visit_memory_budget_violationsNtB2_21MemoryBudgetViolationNcNtINtNtNtCsgDHHaSskbIF_4core3ops12control_flow11ControlFlowB1k_E5Break0ECs7fdMCt8k5K6_8mech_gpu>
10159117c:     	ldurb	w8, [x29, #-0xe0]
101591180:     	cmp	w8, #0x8
101591184:     	b.ne	0x1015911dc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa7c>
101591188:     	add	x0, sp, #0x300
10159118c:     	bl	0x10159b234 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101591190:     	add	x0, sp, #0x2e0
101591194:     	bl	0x10159b2ac <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101591198:     	ldr	w8, [sp, #0x200]
10159119c:     	cmp	w8, #0x1a
1015911a0:     	b.eq	0x1015911b0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa50>
1015911a4:     	add	x8, sp, #0xd0
1015911a8:     	add	x0, x8, #0x130
1015911ac:     	bl	0x10159b1e4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
1015911b0:     	mov	w25, #0x0               ; =0
1015911b4:     	ldr	x8, [sp, #0xb8]
1015911b8:     	mov	x9, #-0x1               ; =-1
1015911bc:     	ldaddl	x9, x8, [x8]
1015911c0:     	mov	w26, #0x2e              ; =46
1015911c4:     	cmp	x8, #0x1
1015911c8:     	b.eq	0x101590b88 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x428>
1015911cc:     	b	0x101590b94 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
1015911d0:     	adrp	x0, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
1015911d4:     	add	x0, x0, #0x4b8
1015911d8:     	bl	0x103a02774 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1015911dc:     	ldp	q0, q1, [x21, #0x130]
1015911e0:     	stp	q1, q0, [sp, #0x60]
1015911e4:     	mov	w26, #0x2a              ; =42
1015911e8:     	mov	w25, #0x12              ; =18
1015911ec:     	b	0x1015910d4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015911f0:     	ldrb	w8, [sp, #0x453]
1015911f4:     	add	x10, sp, #0x450
1015911f8:     	ldurh	w9, [x10, #0x1]
1015911fc:     	orr	w21, w9, w8, lsl #16
101591200:     	ldr	w22, [sp, #0x454]
101591204:     	ldur	q0, [x10, #0x18]
101591208:     	str	q0, [sp, #0x60]
10159120c:     	ldur	q0, [x10, #0x8]
101591210:     	b	0x101590ff4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x894>
101591214:     	adrp	x0, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101591218:     	add	x0, x0, #0x4a0
10159121c:     	bl	0x103a02774 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
101591220:     	b	0x10159127c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
101591224:     	mov	w25, #0x0               ; =0
101591228:     	mov	w26, #0x2c              ; =44
10159122c:     	b	0x101590b18 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101591230:     	sub	x0, x29, #0xb8
101591234:     	bl	0x10159c3e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
101591238:     	mov	w25, #0x0               ; =0
10159123c:     	mov	w26, #0x2c              ; =44
101591240:     	b	0x1015910d4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
101591244:     	adrp	x0, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101591248:     	add	x0, x0, #0x210
10159124c:     	bl	0x103a020f0 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
101591250:     	mov	x24, x8
101591254:     	adrp	x8, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101591258:     	add	x8, x8, #0x560
10159125c:     	b	0x10159126c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb0c>
101591260:     	mov	x24, x8
101591264:     	adrp	x8, 0x107f0b000 <_anon.61c4a8641e5b3956ea8870164c4e553f.881+0x798>
101591268:     	add	x8, x8, #0x578
10159126c:     	str	x8, [sp, #0x40]
101591270:     	mov	x0, x24
101591274:     	ldr	x2, [sp, #0x40]
101591278:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10159127c:     	brk	#0x1
101591280:     	mov	x20, x0
101591284:     	ldr	x8, [sp, #0x300]
101591288:     	mov	x9, #-0x1               ; =-1
10159128c:     	ldaddl	x9, x8, [x8]
101591290:     	cmp	x8, #0x1
101591294:     	b.ne	0x1015912f0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
101591298:     	dmb	ishld
10159129c:     	add	x0, sp, #0x300
1015912a0:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015912a4:     	b	0x1015912f0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
1015912a8:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015912ac:     	b	0x1015912e4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb84>
1015912b0:     	mov	x20, x0
1015912b4:     	ldr	x8, [sp, #0x2e0]
1015912b8:     	mov	x9, #-0x1               ; =-1
1015912bc:     	ldaddl	x9, x8, [x8]
1015912c0:     	cmp	x8, #0x1
1015912c4:     	b.ne	0x101591378 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015912c8:     	dmb	ishld
1015912cc:     	add	x0, sp, #0x2e0
1015912d0:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015912d4:     	b	0x101591378 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015912d8:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015912dc:     	mov	x20, x0
1015912e0:     	b	0x1015912f0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
1015912e4:     	mov	x20, x0
1015912e8:     	add	x0, sp, #0x300
1015912ec:     	bl	0x10159b234 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015912f0:     	add	x0, sp, #0x2e0
1015912f4:     	bl	0x10159b2ac <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015912f8:     	b	0x101591378 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015912fc:     	mov	x20, x0
101591300:     	b	0x1015913ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
101591304:     	mov	x20, x0
101591308:     	ldr	x8, [sp, #0x90]
10159130c:     	cbz	x8, 0x1015913f4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
101591310:     	ldr	x9, [x8]
101591314:     	subs	x9, x9, #0x1
101591318:     	str	x9, [x8]
10159131c:     	b.ne	0x1015913f4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
101591320:     	add	x0, x19, #0x8
101591324:     	bl	0x10236e608 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101591328:     	b	0x1015913f4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
10159132c:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101591330:     	mov	x20, x0
101591334:     	ldr	x8, [sp, #0xa0]
101591338:     	cbz	x8, 0x1015913ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
10159133c:     	ldr	x9, [x8]
101591340:     	subs	x9, x9, #0x1
101591344:     	str	x9, [x8]
101591348:     	b.ne	0x1015913ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
10159134c:     	add	x0, x27, #0x8
101591350:     	bl	0x10236e608 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101591354:     	b	0x1015913ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
101591358:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10159135c:     	mov	x20, x0
101591360:     	b	0x101591390 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc30>
101591364:     	mov	x20, x0
101591368:     	b	0x1015913c0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc60>
10159136c:     	mov	x20, x0
101591370:     	b	0x1015913b0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc50>
101591374:     	mov	x20, x0
101591378:     	ldr	w8, [sp, #0x200]
10159137c:     	cmp	w8, #0x1a
101591380:     	b.eq	0x101591390 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc30>
101591384:     	add	x8, sp, #0xd0
101591388:     	add	x0, x8, #0x130
10159138c:     	bl	0x10159b1e4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
101591390:     	ldr	x8, [sp, #0xb8]
101591394:     	mov	x9, #-0x1               ; =-1
101591398:     	ldaddl	x9, x8, [x8]
10159139c:     	cmp	x8, #0x1
1015913a0:     	b.ne	0x1015913b0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc50>
1015913a4:     	dmb	ishld
1015913a8:     	add	x0, sp, #0xb8
1015913ac:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015913b0:     	ldp	x8, x9, [sp, #0x50]
1015913b4:     	stp	x9, x8, [x19, #0x30]
1015913b8:     	ldr	x8, [sp, #0x48]
1015913bc:     	str	x8, [x19, #0x40]
1015913c0:     	add	x0, sp, #0x98
1015913c4:     	bl	0x10159f8ec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits10ScopeGuardECs7fdMCt8k5K6_8mech_gpu>
1015913c8:     	b	0x1015913ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015913cc:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015913d0:     	mov	x20, x0
1015913d4:     	ldr	x8, [x23]
1015913d8:     	subs	x8, x8, #0x1
1015913dc:     	str	x8, [x23]
1015913e0:     	b.ne	0x1015913ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015913e4:     	add	x0, sp, #0xd0
1015913e8:     	bl	0x10236e608 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1015913ec:     	add	x0, sp, #0x88
1015913f0:     	bl	0x10159f964 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits12AccountGuardECs7fdMCt8k5K6_8mech_gpu>
1015913f4:     	mov	x0, x20
1015913f8:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
1015913fc:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101591400:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
