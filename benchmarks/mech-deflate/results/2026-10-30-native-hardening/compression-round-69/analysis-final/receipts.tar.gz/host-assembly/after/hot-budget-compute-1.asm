
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023709e4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
1023709e4:     	stp	x28, x27, [sp, #-0x60]!
1023709e8:     	stp	x26, x25, [sp, #0x10]
1023709ec:     	stp	x24, x23, [sp, #0x20]
1023709f0:     	stp	x22, x21, [sp, #0x30]
1023709f4:     	stp	x20, x19, [sp, #0x40]
1023709f8:     	stp	x29, x30, [sp, #0x50]
1023709fc:     	add	x29, sp, #0x50
102370a00:     	sub	sp, sp, #0x1a0
102370a04:     	ldr	x9, [x0, #0xd0]
102370a08:     	adds	x13, x9, x1
102370a0c:     	b.hs	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a10:     	ldr	x21, [x0, #0xc8]
102370a14:     	ldr	x26, [x0, #0xe8]
102370a18:     	ldr	x28, [x0, #0xf8]
102370a1c:     	ldr	x25, [x0, #0x108]
102370a20:     	ldp	x22, x23, [x0, #0x118]
102370a24:     	ldr	x9, [x0]
102370a28:     	cmp	x9, #0x1
102370a2c:     	b.ne	0x102370a98 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
102370a30:     	cmp	x23, #0x10, lsl #12     ; =0x10000
102370a34:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a38:     	mov	w9, #0x1000000          ; =16777216
102370a3c:     	cmp	x26, x9
102370a40:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a44:     	mov	w9, #0x1000000          ; =16777216
102370a48:     	cmp	x13, x9
102370a4c:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a50:     	mov	w9, #0x1000000          ; =16777216
102370a54:     	cmp	x28, x9
102370a58:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a5c:     	mov	w9, #0x1000000          ; =16777216
102370a60:     	cmp	x25, x9
102370a64:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a68:     	cmp	x22, #0x10, lsl #12     ; =0x10000
102370a6c:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a70:     	cmp	x21, #0x10, lsl #12     ; =0x10000
102370a74:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a78:     	ldr	x9, [x0, #0x8]
102370a7c:     	cmp	x13, x9
102370a80:     	b.hi	0x102370a90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102370a84:     	ldr	x9, [x0, #0x10]
102370a88:     	cmp	x21, x9
102370a8c:     	b.ls	0x102370bd0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102370a90:     	mov	w9, #0x2                ; =2
102370a94:     	b	0x102370bd8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f4>
102370a98:     	ldp	x24, x2, [x0, #0xd8]
102370a9c:     	ldr	x20, [x0, #0xf0]
102370aa0:     	ldr	x9, [x0, #0x100]
102370aa4:     	ldr	x1, [x0, #0x110]
102370aa8:     	ldr	x15, [x0, #0x128]
102370aac:     	ldr	x27, [x0, #0x18]
102370ab0:     	cmp	x27, #0x2
102370ab4:     	b.ne	0x102370b28 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x144>
102370ab8:     	mov	x19, x0
102370abc:     	mov	x27, x8
102370ac0:     	stp	x21, x13, [x29, #-0xf0]
102370ac4:     	mov	x21, x13
102370ac8:     	stp	x24, x2, [x29, #-0xe0]
102370acc:     	stp	x26, x20, [x29, #-0xd0]
102370ad0:     	stp	x28, x9, [x29, #-0xc0]
102370ad4:     	stp	x25, x1, [x29, #-0xb0]
102370ad8:     	stp	x22, x23, [x29, #-0xa0]
102370adc:     	stur	x15, [x29, #-0x90]
102370ae0:     	sub	x8, x29, #0x88
102370ae4:     	sub	x0, x29, #0xf0
102370ae8:     	bl	0x1023803dc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102370aec:     	ldurb	w8, [x29, #-0x88]
102370af0:     	cmp	w8, #0x8
102370af4:     	b.ne	0x102370ba4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1c0>
102370af8:     	add	x0, sp, #0xd0
102370afc:     	sub	x1, x29, #0xf0
102370b00:     	bl	0x10236c6ec <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
102370b04:     	mov	x8, x27
102370b08:     	ldrb	w9, [sp, #0xd0]
102370b0c:     	cmp	w9, #0x8
102370b10:     	b.eq	0x102370bc8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e4>
102370b14:     	ldp	q0, q1, [sp, #0xd0]
102370b18:     	stp	q0, q1, [x8]
102370b1c:     	ldr	x9, [sp, #0xf0]
102370b20:     	str	x9, [x8, #0x20]
102370b24:     	b	0x102370bdc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102370b28:     	str	x9, [sp, #0xc0]
102370b2c:     	ldr	x10, [x0, #0x20]
102370b30:     	ldp	x11, x9, [x0, #0x38]
102370b34:     	stp	x9, x10, [sp, #0xb0]
102370b38:     	ldp	x10, x9, [x0, #0x48]
102370b3c:     	stp	x9, x11, [sp, #0xa0]
102370b40:     	ldr	x9, [x0, #0x58]
102370b44:     	stp	x9, x10, [sp, #0x90]
102370b48:     	ldp	x10, x9, [x0, #0x60]
102370b4c:     	str	x9, [sp, #0x88]
102370b50:     	ldp	x11, x9, [x0, #0x70]
102370b54:     	stp	x0, x9, [sp, #0x78]
102370b58:     	ldp	x6, x12, [x0, #0x80]
102370b5c:     	ldp	x4, x7, [x0, #0x90]
102370b60:     	ldr	x3, [x0, #0xa0]
102370b64:     	ldp	w5, w14, [x0, #0xb8]
102370b68:     	ldr	x9, [x0, #0xc0]
102370b6c:     	str	x9, [sp, #0xc8]
102370b70:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
102370b74:     	add	x0, x0, #0x550
102370b78:     	ldr	x9, [x0]
102370b7c:     	blr	x9
102370b80:     	mov	x19, x0
102370b84:     	ldrb	w9, [x0, #0x48]
102370b88:     	cmp	w9, #0x1
102370b8c:     	b.eq	0x102370c58 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x274>
102370b90:     	cmp	w9, #0x2
102370b94:     	b.ne	0x102370bfc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x218>
102370b98:     	adrp	x0, 0x108032000 <_anon.686517066f445f70c1782692b9896900.7+0x569e8>
102370b9c:     	add	x0, x0, #0x1b8
102370ba0:     	bl	0x103a020f0 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102370ba4:     	sub	x8, x29, #0x88
102370ba8:     	ldp	q0, q1, [x8]
102370bac:     	stp	q0, q1, [sp, #0xd0]
102370bb0:     	ldur	x8, [x29, #-0x68]
102370bb4:     	str	x8, [sp, #0xf0]
102370bb8:     	mov	x8, x27
102370bbc:     	ldrb	w9, [sp, #0xd0]
102370bc0:     	cmp	w9, #0x8
102370bc4:     	b.ne	0x102370b14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x130>
102370bc8:     	mov	x0, x19
102370bcc:     	mov	x13, x21
102370bd0:     	str	x13, [x0, #0xd0]
102370bd4:     	mov	w9, #0x8                ; =8
102370bd8:     	strb	w9, [x8]
102370bdc:     	add	sp, sp, #0x1a0
102370be0:     	ldp	x29, x30, [sp, #0x50]
102370be4:     	ldp	x20, x19, [sp, #0x40]
102370be8:     	ldp	x22, x21, [sp, #0x30]
102370bec:     	ldp	x24, x23, [sp, #0x20]
102370bf0:     	ldp	x26, x25, [sp, #0x10]
102370bf4:     	ldp	x28, x27, [sp], #0x60
102370bf8:     	ret
102370bfc:     	stp	x1, x15, [sp, #0x10]
102370c00:     	adrp	x1, 0x102a55000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact23guarded_histogram_query8selected9candidateNtNtB6_7program25NativeProgramArtifactPlanEB8_+0xb64>
102370c04:     	add	x1, x1, #0xb18
102370c08:     	mov	x0, x19
102370c0c:     	str	x8, [sp, #0x20]
102370c10:     	stp	x6, x13, [sp, #0x50]
102370c14:     	stp	x14, x7, [sp, #0x30]
102370c18:     	str	x2, [sp, #0x8]
102370c1c:     	stp	x3, x4, [sp, #0x40]
102370c20:     	str	w5, [sp, #0x2c]
102370c24:     	stp	x12, x11, [sp, #0x60]
102370c28:     	str	x10, [sp, #0x70]
102370c2c:     	bl	0x102e6db58 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102370c30:     	ldp	x11, x10, [sp, #0x68]
102370c34:     	ldp	x13, x12, [sp, #0x58]
102370c38:     	ldp	x7, x3, [sp, #0x38]
102370c3c:     	ldp	x4, x6, [sp, #0x48]
102370c40:     	ldr	w5, [sp, #0x2c]
102370c44:     	ldp	x2, x1, [sp, #0x8]
102370c48:     	ldp	x15, x8, [sp, #0x18]
102370c4c:     	ldr	x14, [sp, #0x30]
102370c50:     	mov	w9, #0x1                ; =1
102370c54:     	strb	w9, [x19, #0x48]
102370c58:     	str	x10, [sp, #0x70]
102370c5c:     	ldr	x9, [x19]
102370c60:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102370c64:     	cmp	x9, x10
102370c68:     	b.hs	0x102370e78 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x494>
102370c6c:     	add	x10, x9, #0x1
102370c70:     	str	x10, [x19]
102370c74:     	ldr	x10, [x19, #0x8]
102370c78:     	cbz	x10, 0x102370d20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x33c>
102370c7c:     	stp	x12, x11, [sp, #0x60]
102370c80:     	ldr	x11, [x10, #0x10]
102370c84:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
102370c88:     	cmp	x11, x12
102370c8c:     	b.hs	0x102370e84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x4a0>
102370c90:     	ldr	x10, [x10, #0x58]
102370c94:     	str	x9, [x19]
102370c98:     	ldr	x9, [sp, #0xc8]
102370c9c:     	cmp	x10, x9
102370ca0:     	b.ne	0x102370d24 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x340>
102370ca4:     	stp	x7, x3, [sp, #0x38]
102370ca8:     	stp	x4, x6, [sp, #0x48]
102370cac:     	str	w5, [sp, #0x2c]
102370cb0:     	str	x14, [sp, #0x30]
102370cb4:     	mov	x19, x8
102370cb8:     	stp	x21, x13, [x29, #-0xf0]
102370cbc:     	str	x13, [sp, #0x58]
102370cc0:     	stp	x24, x2, [x29, #-0xe0]
102370cc4:     	mov	x24, x2
102370cc8:     	stp	x26, x20, [x29, #-0xd0]
102370ccc:     	ldr	x8, [sp, #0xc0]
102370cd0:     	stp	x28, x8, [x29, #-0xc0]
102370cd4:     	stp	x25, x1, [x29, #-0xb0]
102370cd8:     	mov	x26, x1
102370cdc:     	stp	x22, x23, [x29, #-0xa0]
102370ce0:     	mov	x20, x15
102370ce4:     	stur	x15, [x29, #-0x90]
102370ce8:     	sub	x8, x29, #0x88
102370cec:     	sub	x0, x29, #0xf0
102370cf0:     	bl	0x1023803dc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102370cf4:     	ldurb	w8, [x29, #-0x88]
102370cf8:     	cmp	w8, #0x8
102370cfc:     	b.ne	0x102370d2c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102370d00:     	cmp	x27, #0x1
102370d04:     	mov	x8, x19
102370d08:     	ldr	x11, [sp, #0xb8]
102370d0c:     	b.ne	0x102370d44 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102370d10:     	cmp	x23, x11
102370d14:     	b.ls	0x102370d44 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102370d18:     	mov	w9, #0x0                ; =0
102370d1c:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370d20:     	str	x9, [x19]
102370d24:     	strb	wzr, [x8]
102370d28:     	b	0x102370bdc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102370d2c:     	sub	x8, x29, #0x88
102370d30:     	ldp	q0, q1, [x8]
102370d34:     	stp	q0, q1, [x19]
102370d38:     	ldur	x8, [x29, #-0x68]
102370d3c:     	str	x8, [x19, #0x20]
102370d40:     	b	0x102370bdc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102370d44:     	ldp	x9, x11, [sp, #0xa8]
102370d48:     	cmp	x9, #0x1
102370d4c:     	b.ne	0x102370d64 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102370d50:     	cmp	x28, x11
102370d54:     	b.ls	0x102370d64 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102370d58:     	mov	w9, #0x2                ; =2
102370d5c:     	mov	x23, x28
102370d60:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370d64:     	ldp	x9, x11, [sp, #0x98]
102370d68:     	cmp	x9, #0x1
102370d6c:     	b.ne	0x102370d84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
102370d70:     	cmp	x25, x11
102370d74:     	b.ls	0x102370d84 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
102370d78:     	mov	w9, #0x3                ; =3
102370d7c:     	mov	x23, x25
102370d80:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370d84:     	ldr	x9, [sp, #0x90]
102370d88:     	cmp	x9, #0x1
102370d8c:     	ldr	x11, [sp, #0x70]
102370d90:     	b.ne	0x102370da8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
102370d94:     	cmp	x22, x11
102370d98:     	b.ls	0x102370da8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
102370d9c:     	mov	w9, #0x4                ; =4
102370da0:     	mov	x23, x22
102370da4:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370da8:     	ldr	x9, [sp, #0x88]
102370dac:     	cmp	x9, #0x1
102370db0:     	ldr	x11, [sp, #0x68]
102370db4:     	b.ne	0x102370dcc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
102370db8:     	cmp	x21, x11
102370dbc:     	b.ls	0x102370dcc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
102370dc0:     	mov	w9, #0x5                ; =5
102370dc4:     	mov	x23, x21
102370dc8:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370dcc:     	ldr	x9, [sp, #0x80]
102370dd0:     	cmp	x9, #0x1
102370dd4:     	ldp	x11, x13, [sp, #0x50]
102370dd8:     	b.ne	0x102370df0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
102370ddc:     	cmp	x13, x11
102370de0:     	b.ls	0x102370df0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
102370de4:     	mov	w9, #0x6                ; =6
102370de8:     	mov	x23, x13
102370dec:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370df0:     	ldr	x9, [sp, #0x60]
102370df4:     	cmp	x9, #0x1
102370df8:     	ldr	x11, [sp, #0x48]
102370dfc:     	b.ne	0x102370e14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102370e00:     	cmp	x24, x11
102370e04:     	b.ls	0x102370e14 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102370e08:     	mov	w9, #0x7                ; =7
102370e0c:     	mov	x23, x24
102370e10:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370e14:     	ldp	x9, x11, [sp, #0x38]
102370e18:     	cmp	x9, #0x1
102370e1c:     	b.ne	0x102370e38 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102370e20:     	mov	x24, x26
102370e24:     	cmp	x26, x11
102370e28:     	b.ls	0x102370e38 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102370e2c:     	mov	w9, #0x8                ; =8
102370e30:     	mov	x23, x24
102370e34:     	b	0x102370e5c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102370e38:     	ldr	w9, [sp, #0x2c]
102370e3c:     	cmp	w9, #0x1
102370e40:     	ldr	x0, [sp, #0x78]
102370e44:     	ldr	x11, [sp, #0x30]
102370e48:     	b.ne	0x102370bd0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102370e4c:     	cmp	w11, w20
102370e50:     	b.hs	0x102370bd0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102370e54:     	mov	w23, w20
102370e58:     	mov	w9, #0xa                ; =10
102370e5c:     	mov	w10, #0x6               ; =6
102370e60:     	strb	w10, [x8]
102370e64:     	strb	w9, [x8, #0x1]
102370e68:     	mov	w9, #0x1                ; =1
102370e6c:     	strb	w9, [x8, #0x2]
102370e70:     	stp	x23, x11, [x8, #0x8]
102370e74:     	b	0x102370bdc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102370e78:     	adrp	x0, 0x108033000 <_anon.75812f05b385a6fb12f95ada298af815.207+0x170>
102370e7c:     	add	x0, x0, #0x298
102370e80:     	bl	0x103a027a4 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102370e84:     	adrp	x0, 0x108033000 <_anon.75812f05b385a6fb12f95ada298af815.207+0x170>
102370e88:     	add	x0, x0, #0x2b0
102370e8c:     	bl	0x103a027a4 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102370e90:     	brk	#0x1
102370e94:     	ldr	x8, [x19]
102370e98:     	sub	x8, x8, #0x1
102370e9c:     	str	x8, [x19]
102370ea0:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
