
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010154d7b4 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>:
10154d7b4:     	stp	x20, x19, [sp, #-0x20]!
10154d7b8:     	stp	x29, x30, [sp, #0x10]
10154d7bc:     	add	x29, sp, #0x10
10154d7c0:     	mov	x19, x4
10154d7c4:     	cmp	x3, x2
10154d7c8:     	b.hs	0x10154d818 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_+0x64>
10154d7cc:     	mov	w8, #0x170              ; =368
10154d7d0:     	madd	x8, x3, x8, x1
10154d7d4:     	add	x9, x8, #0x148
10154d7d8:     	ldr	q0, [x9]
10154d7dc:     	stur	q0, [x0, #0x4]
10154d7e0:     	ldp	q0, q1, [x19]
10154d7e4:     	stur	q0, [x0, #0x18]
10154d7e8:     	ldr	w8, [x8, #0x158]
10154d7ec:     	str	w8, [x0, #0x14]
10154d7f0:     	stur	q1, [x0, #0x28]
10154d7f4:     	ldr	q0, [x19, #0x20]
10154d7f8:     	stur	q0, [x0, #0x38]
10154d7fc:     	ldr	x8, [x19, #0x30]
10154d800:     	str	x8, [x0, #0x48]
10154d804:     	mov	w8, #0x3                ; =3
10154d808:     	str	w8, [x0]
10154d80c:     	ldp	x29, x30, [sp, #0x10]
10154d810:     	ldp	x20, x19, [sp], #0x20
10154d814:     	ret
10154d818:     	adrp	x8, 0x107f08000 <_anon.0504008e54a1502d122e47b3b8bf1e07.436+0x1e8>
10154d81c:     	add	x8, x8, #0xb60
10154d820:     	mov	x0, x3
10154d824:     	mov	x1, x2
10154d828:     	mov	x2, x8
10154d82c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154d830:     	brk	#0x1
10154d834:     	mov	x20, x0
10154d838:     	mov	x0, x19
10154d83c:     	bl	0x10154a800 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10154d840:     	mov	x0, x20
10154d844:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
