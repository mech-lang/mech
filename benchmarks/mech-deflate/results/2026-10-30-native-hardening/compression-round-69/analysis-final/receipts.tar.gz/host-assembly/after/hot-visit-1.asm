
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101565eac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>:
101565eac:     	stp	x28, x27, [sp, #-0x60]!
101565eb0:     	stp	x26, x25, [sp, #0x10]
101565eb4:     	stp	x24, x23, [sp, #0x20]
101565eb8:     	stp	x22, x21, [sp, #0x30]
101565ebc:     	stp	x20, x19, [sp, #0x40]
101565ec0:     	stp	x29, x30, [sp, #0x50]
101565ec4:     	add	x29, sp, #0x50
101565ec8:     	sub	sp, sp, #0x2e0
101565ecc:     	mov	x19, x8
101565ed0:     	ldr	x8, [x0, #0x238]
101565ed4:     	ldr	w9, [x0, #0x268]
101565ed8:     	cmp	x8, #0x3
101565edc:     	ccmp	w9, #0x0, #0x4, ne
101565ee0:     	b.ne	0x101565f14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x68>
101565ee4:     	ldr	x8, [x0, #0xc0]
101565ee8:     	cmp	x8, #0x2
101565eec:     	b.ne	0x101565f30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84>
101565ef0:     	ldr	x8, [x0, #0xa8]
101565ef4:     	cbz	x8, 0x101565f6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc0>
101565ef8:     	str	wzr, [x19]
101565efc:     	mov	w8, #0xc                ; =12
101565f00:     	strb	w8, [x19, #0x8]
101565f04:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101565f08:     	add	x8, x8, #0xedb
101565f0c:     	mov	w9, #0x2a               ; =42
101565f10:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101565f14:     	str	wzr, [x19]
101565f18:     	mov	w8, #0xc                ; =12
101565f1c:     	strb	w8, [x19, #0x8]
101565f20:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101565f24:     	add	x8, x8, #0x63
101565f28:     	mov	w9, #0x24               ; =36
101565f2c:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101565f30:     	str	wzr, [x19]
101565f34:     	mov	w8, #0xc                ; =12
101565f38:     	strb	w8, [x19, #0x8]
101565f3c:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101565f40:     	add	x8, x8, #0xea7
101565f44:     	mov	w9, #0x34               ; =52
101565f48:     	stp	x8, x9, [x19, #0x10]
101565f4c:     	add	sp, sp, #0x2e0
101565f50:     	ldp	x29, x30, [sp, #0x50]
101565f54:     	ldp	x20, x19, [sp, #0x40]
101565f58:     	ldp	x22, x21, [sp, #0x30]
101565f5c:     	ldp	x24, x23, [sp, #0x20]
101565f60:     	ldp	x26, x25, [sp, #0x10]
101565f64:     	ldp	x28, x27, [sp], #0x60
101565f68:     	ret
101565f6c:     	mov	x20, x1
101565f70:     	ldrb	w8, [x0, #0x508]
101565f74:     	tbz	w8, #0x0, 0x101565fb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
101565f78:     	ldr	x8, [x0, #0x498]
101565f7c:     	ldr	w9, [x8, #0x300]
101565f80:     	cmp	w9, #0x1
101565f84:     	b.ne	0x101565fb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
101565f88:     	ldr	w8, [x8, #0x304]
101565f8c:     	cmp	x20, x8
101565f90:     	b.ne	0x101565fb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
101565f94:     	str	wzr, [x19]
101565f98:     	mov	w8, #0xc                ; =12
101565f9c:     	strb	w8, [x19, #0x8]
101565fa0:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101565fa4:     	add	x8, x8, #0x2b
101565fa8:     	mov	w9, #0x38               ; =56
101565fac:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101565fb0:     	ldr	x24, [x0, #0x490]
101565fb4:     	ldr	w8, [x24, #0x2f0]
101565fb8:     	tbz	w8, #0x0, 0x101565fe0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
101565fbc:     	ldr	w1, [x24, #0x2f4]
101565fc0:     	mov	x21, x0
101565fc4:     	bl	0x1015650cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
101565fc8:     	mov	x8, x0
101565fcc:     	mov	x0, x21
101565fd0:     	ldr	x24, [x21, #0x490]
101565fd4:     	tbz	w8, #0x0, 0x101565fe0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
101565fd8:     	ldrb	w8, [x24, #0x460]
101565fdc:     	tbz	w8, #0x0, 0x1015660dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x230>
101565fe0:     	ldr	x21, [x0, #0x498]
101565fe4:     	ldr	w9, [x24, #0xb8]
101565fe8:     	ldr	w8, [x24, #0x2f0]
101565fec:     	cmp	w9, #0x1
101565ff0:     	b.ne	0x101566028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x17c>
101565ff4:     	tbz	w8, #0x0, 0x10156600c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x160>
101565ff8:     	ldp	w22, w8, [x24, #0xbc]
101565ffc:     	ldr	w9, [x24, #0x2f4]
101566000:     	cmp	x20, x8
101566004:     	ccmp	w9, w22, #0x0, eq
101566008:     	b.eq	0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10156600c:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101566010:     	add	x8, x8, #0xdf9
101566014:     	mov	w9, #0x26               ; =38
101566018:     	str	wzr, [x19]
10156601c:     	mov	w10, #0xc               ; =12
101566020:     	str	w10, [x19, #0x8]
101566024:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101566028:     	ldr	w22, [x24, #0x2f4]
10156602c:     	tbz	w8, #0x0, 0x1015660bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x210>
101566030:     	ldr	x8, [x21, #0x590]
101566034:     	cmp	x8, x22
101566038:     	b.ls	0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10156603c:     	ldr	x8, [x21, #0x588]
101566040:     	add	x8, x8, x22, lsl #4
101566044:     	ldr	x9, [x8]
101566048:     	cmp	x9, #0x1
10156604c:     	b.ne	0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101566050:     	ldr	x8, [x8, #0x8]
101566054:     	ldr	x1, [x21, #0x580]
101566058:     	cmp	x8, x1
10156605c:     	b.hs	0x101566bb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd08>
101566060:     	ldr	x9, [x21, #0x578]
101566064:     	mov	w10, #0x38              ; =56
101566068:     	madd	x8, x8, x10, x9
10156606c:     	ldr	x9, [x8]
101566070:     	cmp	x9, #0x1
101566074:     	b.ne	0x1015660f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x24c>
101566078:     	ldr	x9, [x24, #0x10]
10156607c:     	cmp	x9, #0x2
101566080:     	b.eq	0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101566084:     	ldr	x9, [x8, #0x8]
101566088:     	ldr	x10, [x24, #0x40]
10156608c:     	cmp	x9, x10
101566090:     	b.hs	0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101566094:     	ldr	x10, [x24, #0x38]
101566098:     	mov	w11, #0x3c8             ; =968
10156609c:     	madd	x9, x9, x11, x10
1015660a0:     	ldr	x9, [x9, #0x290]
1015660a4:     	cbz	x9, 0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015660a8:     	ldr	x9, [x8, #0x18]
1015660ac:     	cbz	x9, 0x101566ba0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015660b0:     	ldr	x9, [x8, #0x10]
1015660b4:     	ldr	w9, [x9]
1015660b8:     	b	0x10156611c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x270>
1015660bc:     	mov	w15, #0x0               ; =0
1015660c0:     	mov	w14, #0x0               ; =0
1015660c4:     	add	x23, sp, #0x120
1015660c8:     	mov	x28, x0
1015660cc:     	ldr	x26, [x28, #0xf8]!
1015660d0:     	cmp	x26, #0x2
1015660d4:     	b.eq	0x101566158 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
1015660d8:     	b	0x101566270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
1015660dc:     	str	wzr, [x19]
1015660e0:     	mov	w8, #0xc                ; =12
1015660e4:     	strb	w8, [x19, #0x8]
1015660e8:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
1015660ec:     	add	x8, x8, #0xf05
1015660f0:     	mov	w9, #0x25               ; =37
1015660f4:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015660f8:     	ldr	x9, [x8, #0x18]
1015660fc:     	cbz	x9, 0x101566ba0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
101566100:     	ldr	w9, [x24, #0x340]
101566104:     	tbz	w9, #0x0, 0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101566108:     	ldr	x9, [x8, #0x10]
10156610c:     	ldr	w9, [x9]
101566110:     	ldr	w10, [x24, #0x344]
101566114:     	cmp	w10, w9
101566118:     	b.ne	0x10156613c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10156611c:     	cmp	w22, w9
101566120:     	b.ne	0x101566228 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x37c>
101566124:     	lsr	x9, x20, #32
101566128:     	cbz	x9, 0x101566238 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x38c>
10156612c:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101566130:     	add	x8, x8, #0xe49
101566134:     	mov	w9, #0x1a               ; =26
101566138:     	b	0x101566018 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
10156613c:     	mov	w15, #0x1               ; =1
101566140:     	mov	w14, #0x1               ; =1
101566144:     	add	x23, sp, #0x120
101566148:     	mov	x28, x0
10156614c:     	ldr	x26, [x28, #0xf8]!
101566150:     	cmp	x26, #0x2
101566154:     	b.ne	0x101566270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
101566158:     	cbz	w14, 0x10156620c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x360>
10156615c:     	mov	w2, w22
101566160:     	ldr	x8, [x21, #0x188]
101566164:     	cmp	x8, x2
101566168:     	b.ls	0x10156672c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
10156616c:     	ldr	x8, [x21, #0x180]
101566170:     	ldr	x8, [x8, x2, lsl #3]
101566174:     	cbz	x8, 0x10156672c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
101566178:     	sub	x8, x8, #0x1
10156617c:     	and	x9, x8, #0x3
101566180:     	cmp	x9, #0x2
101566184:     	b.ne	0x10156672c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
101566188:     	lsr	x8, x8, #2
10156618c:     	ldr	x1, [x21, #0x160]
101566190:     	cmp	x8, x1
101566194:     	b.hs	0x101566bc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd18>
101566198:     	ldr	x9, [x21, #0x158]
10156619c:     	mov	w10, #0x48              ; =72
1015661a0:     	madd	x9, x8, x10, x9
1015661a4:     	ldr	w10, [x9, #0x40]
1015661a8:     	cmp	x20, x10
1015661ac:     	b.ne	0x1015661fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015661b0:     	ldr	w10, [x24, #0x2e8]
1015661b4:     	cmp	w10, #0x1
1015661b8:     	b.ne	0x1015661fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015661bc:     	ldr	w10, [x9, #0x30]
1015661c0:     	ldr	w11, [x24, #0x2ec]
1015661c4:     	cmp	w11, w10
1015661c8:     	b.ne	0x1015661fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015661cc:     	ldr	w9, [x9, #0x34]
1015661d0:     	mov	w10, #0x1               ; =1
1015661d4:     	orr	x9, x10, x9, lsl #1
1015661d8:     	ldr	x1, [x0, #0x4b8]
1015661dc:     	cmp	x9, x1
1015661e0:     	b.hs	0x101566c14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd68>
1015661e4:     	ldr	x10, [x0, #0x4b0]
1015661e8:     	ldr	x9, [x10, x9, lsl #3]
1015661ec:     	ldr	x10, [x0, #0xc0]
1015661f0:     	cmp	x9, #0x0
1015661f4:     	ccmp	x10, #0x2, #0x0, eq
1015661f8:     	b.eq	0x101566714 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
1015661fc:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101566200:     	add	x8, x8, #0xd46
101566204:     	mov	w9, #0x35               ; =53
101566208:     	b	0x10156674c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
10156620c:     	ldrb	w8, [x24, #0x338]
101566210:     	cmp	w8, #0x1
101566214:     	b.ne	0x101566220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x374>
101566218:     	ldr	x8, [x0, #0x4c0]
10156621c:     	cbnz	x8, 0x101566740 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x894>
101566220:     	str	x20, [sp, #0x10]
101566224:     	b	0x10156640c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x560>
101566228:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
10156622c:     	add	x8, x8, #0xe63
101566230:     	mov	w9, #0x1a               ; =26
101566234:     	b	0x101566018 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
101566238:     	mov	x25, x0
10156623c:     	mov	x0, x8
101566240:     	mov	x1, x20
101566244:     	bl	0x1015afaa4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB2_5Group11predecessor>
101566248:     	tbz	w0, #0x0, 0x101566704 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x858>
10156624c:     	mov	x22, x1
101566250:     	mov	w15, #0x1               ; =1
101566254:     	mov	w14, #0x1               ; =1
101566258:     	mov	x0, x25
10156625c:     	add	x23, sp, #0x120
101566260:     	mov	x28, x0
101566264:     	ldr	x26, [x28, #0xf8]!
101566268:     	cmp	x26, #0x2
10156626c:     	b.eq	0x101566158 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
101566270:     	cbz	w14, 0x1015663a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4f4>
101566274:     	mov	w2, w22
101566278:     	ldr	x1, [x21, #0x380]
10156627c:     	cmp	x1, x2
101566280:     	b.ls	0x101566b7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd0>
101566284:     	ldr	x8, [x21, #0x378]
101566288:     	mov	w9, #0x170              ; =368
10156628c:     	umaddl	x8, w2, w9, x8
101566290:     	ldp	x10, x9, [x8]
101566294:     	mov	w11, #0x11              ; =17
101566298:     	eor	x10, x10, x11
10156629c:     	orr	x9, x10, x9
1015662a0:     	cbnz	x9, 0x101566390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
1015662a4:     	ldr	x1, [x21, #0x390]
1015662a8:     	ldr	w25, [x8, #0x10]
1015662ac:     	cmp	x1, x25
1015662b0:     	b.ls	0x101566b90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xce4>
1015662b4:     	ldr	x8, [x21, #0x388]
1015662b8:     	mov	w9, #0x180              ; =384
1015662bc:     	umaddl	x27, w25, w9, x8
1015662c0:     	ldp	x9, x8, [x27]
1015662c4:     	mov	w10, #0x5               ; =5
1015662c8:     	eor	x9, x9, x10
1015662cc:     	orr	x8, x9, x8
1015662d0:     	cbnz	x8, 0x101566390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
1015662d4:     	ldr	x8, [x21, #0x558]
1015662d8:     	cmp	x8, x2
1015662dc:     	b.ls	0x1015662f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x44c>
1015662e0:     	ldr	x8, [x21, #0x550]
1015662e4:     	mov	w9, #0x28               ; =40
1015662e8:     	umull	x9, w2, w9
1015662ec:     	ldr	w8, [x8, x9]
1015662f0:     	cmp	w8, #0x5
1015662f4:     	b.ne	0x101566350 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4a4>
1015662f8:     	str	x0, [sp, #0x8]
1015662fc:     	mov	x0, x24
101566300:     	mov	x1, x21
101566304:     	mov	x24, x14
101566308:     	mov	x23, x15
10156630c:     	bl	0x101578ef4 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
101566310:     	mov	x15, x23
101566314:     	mov	x14, x24
101566318:     	mov	x8, x0
10156631c:     	ldr	x0, [sp, #0x8]
101566320:     	add	x23, sp, #0x120
101566324:     	tbnz	w8, #0x0, 0x101566350 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4a4>
101566328:     	ldr	x1, [x21, #0x360]
10156632c:     	ldr	w8, [x27, #0x30]
101566330:     	cmp	x1, x8
101566334:     	b.ls	0x101566bd4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd28>
101566338:     	ldr	x9, [x21, #0x358]
10156633c:     	mov	w10, #0x140             ; =320
101566340:     	umaddl	x8, w8, w10, x9
101566344:     	ldrb	w8, [x8, #0x124]
101566348:     	cmp	w8, #0x7
10156634c:     	b.eq	0x101566390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
101566350:     	mov	x27, x15
101566354:     	mov	x24, x14
101566358:     	mov	x1, x0
10156635c:     	add	x0, sp, #0x178
101566360:     	mov	x21, x1
101566364:     	mov	x2, x25
101566368:     	mov	w3, #0x1                ; =1
10156636c:     	bl	0x1015652c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
101566370:     	ldr	w8, [sp, #0x178]
101566374:     	cmp	w8, #0x6
101566378:     	b.ne	0x101566934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
10156637c:     	mov	x0, x21
101566380:     	ldr	x26, [x21, #0xf8]
101566384:     	ldr	x21, [x21, #0x498]
101566388:     	mov	x14, x24
10156638c:     	mov	x15, x27
101566390:     	str	x20, [sp, #0x10]
101566394:     	cmp	x26, #0x2
101566398:     	b.ne	0x1015663a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4f8>
10156639c:     	b	0x10156640c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x560>
1015663a0:     	str	x20, [sp, #0x10]
1015663a4:     	ldr	x9, [x21, #0x5a0]
1015663a8:     	ldr	x8, [x0, #0x1c0]
1015663ac:     	cmp	x8, x9
1015663b0:     	b.hs	0x10156652c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
1015663b4:     	ldr	x9, [x21, #0x598]
1015663b8:     	mov	w10, #0x58              ; =88
1015663bc:     	madd	x8, x8, x10, x9
1015663c0:     	ldr	x9, [x8, #0x18]
1015663c4:     	cbz	x9, 0x10156652c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
1015663c8:     	ldr	x8, [x8, #0x10]
1015663cc:     	cmp	x9, #0x1
1015663d0:     	b.ne	0x1015663dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x530>
1015663d4:     	mov	x10, #0x0               ; =0
1015663d8:     	b	0x101566400 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x554>
1015663dc:     	mov	x10, #0x0               ; =0
1015663e0:     	lsr	x11, x9, #1
1015663e4:     	add	x12, x11, x10
1015663e8:     	ldr	w13, [x8, x12, lsl #2]
1015663ec:     	cmp	w13, w20
1015663f0:     	csel	x10, x10, x12, hi
1015663f4:     	sub	x9, x9, x11
1015663f8:     	cmp	x9, #0x1
1015663fc:     	b.hi	0x1015663e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x534>
101566400:     	ldr	w8, [x8, x10, lsl #2]
101566404:     	cmp	w8, w20
101566408:     	b.ne	0x10156652c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
10156640c:     	ldr	x8, [x21, #0x380]
101566410:     	cmp	x20, x8
101566414:     	b.hs	0x101566548 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x69c>
101566418:     	mov	x25, x15
10156641c:     	mov	x26, x14
101566420:     	ldr	x24, [x21, #0x378]
101566424:     	mov	x1, x0
101566428:     	add	x0, sp, #0x178
10156642c:     	mov	x21, x1
101566430:     	mov	x2, x20
101566434:     	bl	0x101574c84 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation31validate_selected_join_boundary>
101566438:     	ldr	w8, [sp, #0x178]
10156643c:     	cmp	w8, #0x6
101566440:     	b.ne	0x101566934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
101566444:     	mov	w8, #0x170              ; =368
101566448:     	madd	x24, x20, x8, x24
10156644c:     	mov	x8, x21
101566450:     	ldr	x9, [x21, #0x490]
101566454:     	ldr	x10, [x9, #0x1e0]
101566458:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
10156645c:     	cmp	x10, x11
101566460:     	b.eq	0x10156648c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x5e0>
101566464:     	ldr	x1, [x9, #0x2d0]
101566468:     	ldr	x2, [x9, #0x2e0]
10156646c:     	ldp	x3, x4, [x24]
101566470:     	ldrb	w5, [x24, #0x10]
101566474:     	add	x0, sp, #0x178
101566478:     	bl	0x10156bea0 <__RNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections11string_spanNtB7_5State22validate_span_boundary>
10156647c:     	ldr	w8, [sp, #0x178]
101566480:     	cmp	w8, #0x6
101566484:     	b.ne	0x101566934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
101566488:     	mov	x8, x21
10156648c:     	ldr	x9, [x8, #0x498]
101566490:     	mov	x23, x8
101566494:     	add	x0, x9, #0x578
101566498:     	mov	x1, x20
10156649c:     	bl	0x1015706e8 <__RNvMs_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB4_6Layout5group>
1015664a0:     	ldr	x8, [x23, #0x490]
1015664a4:     	add	x9, x8, #0x3b8
1015664a8:     	add	x10, x8, #0x2f8
1015664ac:     	stp	x8, x9, [sp, #0x178]
1015664b0:     	stp	x10, x28, [sp, #0x188]
1015664b4:     	add	x8, sp, #0x10
1015664b8:     	str	x8, [sp, #0x198]
1015664bc:     	add	x1, sp, #0x178
1015664c0:     	bl	0x101545800 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>
1015664c4:     	cbz	x0, 0x1015664e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x634>
1015664c8:     	ldr	x8, [x0, #0x18]
1015664cc:     	cbz	x8, 0x101566ba0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015664d0:     	ldr	x8, [x0, #0x10]
1015664d4:     	ldr	w8, [x8]
1015664d8:     	cmp	x20, x8
1015664dc:     	b.ne	0x1015665d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x728>
1015664e0:     	ldr	x8, [x28]
1015664e4:     	cmp	x8, #0x2
1015664e8:     	csinc	w8, w25, wzr, ne
1015664ec:     	tbz	w8, #0x0, 0x101566568 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x6bc>
1015664f0:     	ldr	x8, [x21, #0x490]
1015664f4:     	add	x10, x8, #0x2e8
1015664f8:     	ldr	x8, [x21, #0x498]
1015664fc:     	ldr	x11, [x21, #0x4b0]
101566500:     	ldr	x9, [x21, #0x4b8]
101566504:     	stp	x10, x8, [sp, #0x1b0]
101566508:     	stp	x11, x9, [sp, #0x1c0]
10156650c:     	mov	w9, #0x13               ; =19
101566510:     	strb	w9, [sp, #0x178]
101566514:     	add	x23, sp, #0x120
101566518:     	cbz	x0, 0x101566610 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x764>
10156651c:     	mov	x25, x0
101566520:     	ldr	x4, [x0, #0x30]
101566524:     	mov	w3, #0x1                ; =1
101566528:     	b	0x101566618 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x76c>
10156652c:     	str	wzr, [x19]
101566530:     	mov	w8, #0xc                ; =12
101566534:     	strb	w8, [x19, #0x8]
101566538:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
10156653c:     	add	x8, x8, #0xf2a
101566540:     	mov	w9, #0x2f               ; =47
101566544:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101566548:     	str	wzr, [x19]
10156654c:     	mov	w8, #0xc                ; =12
101566550:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101566554:     	add	x9, x9, #0x837
101566558:     	stp	x8, x9, [x19, #0x8]
10156655c:     	mov	w8, #0x25               ; =37
101566560:     	str	x8, [x19, #0x18]
101566564:     	b	0x101565f4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101566568:     	ldr	x8, [x21, #0x498]
10156656c:     	ldr	x11, [x8, #0x5a0]
101566570:     	ldr	x10, [x21, #0x1c0]
101566574:     	cmp	x10, x11
101566578:     	add	x23, sp, #0x120
10156657c:     	b.hs	0x1015665f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x744>
101566580:     	cbnz	x0, 0x1015666dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x830>
101566584:     	ldr	x11, [x8, #0x598]
101566588:     	mov	w12, #0x58              ; =88
10156658c:     	madd	x10, x10, x12, x11
101566590:     	ldr	w2, [x10, #0x38]
101566594:     	cmp	x20, x2
101566598:     	b.ne	0x1015666dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x830>
10156659c:     	mov	x25, x0
1015665a0:     	ldr	x10, [x21, #0x490]
1015665a4:     	add	x10, x10, #0x2e8
1015665a8:     	ldr	x11, [x21, #0x4b0]
1015665ac:     	ldr	x9, [x21, #0x4b8]
1015665b0:     	stp	x10, x8, [sp, #0x1b0]
1015665b4:     	stp	x11, x9, [sp, #0x1c0]
1015665b8:     	mov	w8, #0x13               ; =19
1015665bc:     	strb	w8, [sp, #0x178]
1015665c0:     	add	x8, sp, #0x18
1015665c4:     	add	x0, sp, #0x178
1015665c8:     	mov	x1, x20
1015665cc:     	bl	0x1015a76cc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE20visit_outlined_entryB9_>
1015665d0:     	b	0x101566634 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x788>
1015665d4:     	str	wzr, [x19]
1015665d8:     	mov	w8, #0xc                ; =12
1015665dc:     	strb	w8, [x19, #0x8]
1015665e0:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015665e4:     	add	x8, x8, #0x0
1015665e8:     	mov	w9, #0x2b               ; =43
1015665ec:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015665f0:     	str	wzr, [x19]
1015665f4:     	mov	w8, #0xc                ; =12
1015665f8:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
1015665fc:     	add	x9, x9, #0x85c
101566600:     	stp	x8, x9, [x19, #0x8]
101566604:     	mov	w8, #0x1a               ; =26
101566608:     	str	x8, [x19, #0x18]
10156660c:     	b	0x101565f4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101566610:     	mov	x25, x0
101566614:     	mov	x3, #0x0                ; =0
101566618:     	ldr	w7, [x8, #0x3f0]
10156661c:     	add	x0, sp, #0x18
101566620:     	add	x1, sp, #0x178
101566624:     	mov	x2, x20
101566628:     	mov	x5, x26
10156662c:     	mov	x6, x22
101566630:     	bl	0x1015a6f6c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>
101566634:     	ldrb	w8, [sp, #0x18]
101566638:     	cmp	w8, #0x13
10156663c:     	b.ne	0x10156667c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x7d0>
101566640:     	add	x0, sp, #0x178
101566644:     	bl	0x101549050 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
101566648:     	add	x0, sp, #0x178
10156664c:     	mov	x1, x21
101566650:     	mov	x2, x20
101566654:     	bl	0x10157287c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation12continuationNtB6_10Invocation23arm_parent_continuation>
101566658:     	ldr	w8, [sp, #0x178]
10156665c:     	cmp	w8, #0x6
101566660:     	b.ne	0x101566934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
101566664:     	cbz	x25, 0x1015666f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84c>
101566668:     	ldr	x8, [x25]
10156666c:     	mov	x0, x21
101566670:     	cbz	x8, 0x10156675c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8b0>
101566674:     	mov	w8, #0x0                ; =0
101566678:     	b	0x101566770 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8c4>
10156667c:     	ldur	q0, [sp, #0x18]
101566680:     	ldur	q1, [sp, #0x28]
101566684:     	stp	q0, q1, [sp, #0x120]
101566688:     	ldur	q2, [sp, #0x38]
10156668c:     	str	q2, [sp, #0x140]
101566690:     	ldr	x8, [sp, #0x48]
101566694:     	str	x8, [sp, #0x150]
101566698:     	stur	q0, [sp, #0x1c]
10156669c:     	stur	q1, [sp, #0x2c]
1015666a0:     	stur	q2, [sp, #0x3c]
1015666a4:     	stur	x8, [sp, #0x4c]
1015666a8:     	mov	w8, #0x1                ; =1
1015666ac:     	str	w8, [x19]
1015666b0:     	ldur	q0, [sp, #0x18]
1015666b4:     	ldur	q1, [sp, #0x28]
1015666b8:     	stur	q0, [x19, #0x4]
1015666bc:     	stur	q1, [x19, #0x14]
1015666c0:     	ldur	q0, [sp, #0x38]
1015666c4:     	stur	q0, [x19, #0x24]
1015666c8:     	ldur	q0, [sp, #0x44]
1015666cc:     	str	q0, [x19, #0x30]
1015666d0:     	add	x0, sp, #0x178
1015666d4:     	bl	0x101549050 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
1015666d8:     	b	0x101565f4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015666dc:     	str	wzr, [x19]
1015666e0:     	mov	w8, #0xc                ; =12
1015666e4:     	strb	w8, [x19, #0x8]
1015666e8:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
1015666ec:     	add	x8, x8, #0xf59
1015666f0:     	mov	w9, #0x26               ; =38
1015666f4:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015666f8:     	mov	w8, #0x0                ; =0
1015666fc:     	mov	x0, x21
101566700:     	b	0x101566770 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8c4>
101566704:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101566708:     	add	x8, x8, #0xe1f
10156670c:     	mov	w9, #0x2a               ; =42
101566710:     	b	0x101566018 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
101566714:     	ldr	x9, [x0, #0x4c0]
101566718:     	str	xzr, [x0, #0x4c0]
10156671c:     	cbz	x9, 0x1015669a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaf4>
101566720:     	sub	x9, x9, #0x1
101566724:     	cmp	x9, x8
101566728:     	b.ne	0x1015669b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xb04>
10156672c:     	ldrb	w8, [x24, #0x338]
101566730:     	cmp	w8, #0x1
101566734:     	b.ne	0x101566278 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
101566738:     	ldr	x8, [x0, #0x4c0]
10156673c:     	cbz	x8, 0x101566278 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
101566740:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101566744:     	add	x8, x8, #0xf7f
101566748:     	mov	w9, #0x29               ; =41
10156674c:     	str	wzr, [x19]
101566750:     	mov	w10, #0xc               ; =12
101566754:     	str	x10, [x19, #0x8]
101566758:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10156675c:     	ldr	x8, [x25, #0x18]
101566760:     	cbz	x8, 0x101566ba0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
101566764:     	ldr	x8, [x25, #0x10]
101566768:     	ldr	w9, [x8]
10156676c:     	mov	w8, #0x1                ; =1
101566770:     	ldr	x10, [x0, #0x490]
101566774:     	str	w8, [x10, #0x340]
101566778:     	str	w9, [x10, #0x344]
10156677c:     	ldr	x8, [x0, #0x490]
101566780:     	str	wzr, [x8, #0xb8]
101566784:     	ldr	x22, [x0, #0x498]
101566788:     	mov	x1, x20
10156678c:     	bl	0x10155af88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
101566790:     	cbz	x0, 0x1015667c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x918>
101566794:     	ldrb	w8, [x0]
101566798:     	cmp	w8, #0x6
10156679c:     	b.ne	0x1015667c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x918>
1015667a0:     	ldr	x9, [x21, #0x490]
1015667a4:     	add	x8, sp, #0x178
1015667a8:     	add	x0, x9, #0x3b8
1015667ac:     	mov	w1, #0x20               ; =32
1015667b0:     	mov	w2, #0x20               ; =32
1015667b4:     	bl	0x1023697d8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>
1015667b8:     	ldrb	w8, [sp, #0x178]
1015667bc:     	cmp	w8, #0x8
1015667c0:     	b.ne	0x101566958 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaac>
1015667c4:     	ldr	x1, [x22, #0x458]
1015667c8:     	cmp	x20, x1
1015667cc:     	b.hs	0x101566be4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd38>
1015667d0:     	ldr	x8, [x22, #0x450]
1015667d4:     	add	x10, x8, x20, lsl #6
1015667d8:     	ldr	w8, [x10, #0x18]
1015667dc:     	cmp	w8, #0x4
1015667e0:     	mov	x9, x21
1015667e4:     	b.ne	0x10156683c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
1015667e8:     	ldr	x8, [x9, #0x220]
1015667ec:     	cmp	x8, #0x2
1015667f0:     	b.eq	0x10156683c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
1015667f4:     	ldr	x8, [x22, #0x208]
1015667f8:     	ldr	x0, [x9, #0x1d8]
1015667fc:     	cmp	x0, x8
101566800:     	b.hs	0x101566c50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xda4>
101566804:     	ldr	w8, [x10, #0x1c]
101566808:     	ldr	x10, [x22, #0x200]
10156680c:     	mov	w11, #0x70              ; =112
101566810:     	madd	x10, x0, x11, x10
101566814:     	ldr	w10, [x10, #0x40]
101566818:     	cmp	w10, w8
10156681c:     	b.ne	0x10156683c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
101566820:     	add	x0, x9, #0x1d8
101566824:     	bl	0x10154b9b0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
101566828:     	mov	w8, #0x2                ; =2
10156682c:     	mov	x9, x21
101566830:     	str	x8, [x21, #0x220]
101566834:     	ldr	x1, [x22, #0x458]
101566838:     	add	x23, sp, #0x120
10156683c:     	cmp	x20, x1
101566840:     	b.hs	0x101566bf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd48>
101566844:     	ldr	x8, [x22, #0x450]
101566848:     	add	x8, x8, x20, lsl #6
10156684c:     	ldr	w10, [x8, #0x18]
101566850:     	cmp	w10, #0x4
101566854:     	b.ne	0x1015668ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa00>
101566858:     	ldr	w2, [x8, #0x1c]
10156685c:     	ldr	x8, [x22, #0x390]
101566860:     	cmp	x8, x2
101566864:     	b.ls	0x101566c24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd78>
101566868:     	ldr	x8, [x22, #0x388]
10156686c:     	mov	w10, #0x180             ; =384
101566870:     	umaddl	x8, w2, w10, x8
101566874:     	ldp	x8, x10, [x8]
101566878:     	mov	w11, #0x5               ; =5
10156687c:     	eor	x8, x8, x11
101566880:     	orr	x8, x8, x10
101566884:     	cbnz	x8, 0x1015668ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa00>
101566888:     	mov	x1, x9
10156688c:     	add	x0, sp, #0x178
101566890:     	mov	w3, #0x2                ; =2
101566894:     	bl	0x1015652c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
101566898:     	ldr	w8, [sp, #0x178]
10156689c:     	cmp	w8, #0x6
1015668a0:     	b.ne	0x101566934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015668a4:     	ldr	x1, [x22, #0x458]
1015668a8:     	mov	x9, x21
1015668ac:     	cmp	x20, x1
1015668b0:     	b.hs	0x101566c04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd58>
1015668b4:     	ldr	x8, [x22, #0x450]
1015668b8:     	add	x8, x8, x20, lsl #6
1015668bc:     	ldr	w10, [x8, #0x18]
1015668c0:     	cmp	w10, #0x4
1015668c4:     	b.ne	0x101566aa4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbf8>
1015668c8:     	ldr	w2, [x8, #0x1c]
1015668cc:     	ldr	x1, [x22, #0x390]
1015668d0:     	cmp	x1, x2
1015668d4:     	b.ls	0x101566c3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd90>
1015668d8:     	ldr	x8, [x22, #0x388]
1015668dc:     	mov	w10, #0x180             ; =384
1015668e0:     	umaddl	x8, w2, w10, x8
1015668e4:     	ldp	x8, x10, [x8]
1015668e8:     	cmp	x8, #0x3
1015668ec:     	sbcs	xzr, x10, xzr
1015668f0:     	b.hs	0x101566aa4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbf8>
1015668f4:     	ldr	x12, [x9, #0x490]
1015668f8:     	ldr	x8, [x12, #0x1e0]
1015668fc:     	ldr	d0, [x12, #0x1e8]
101566900:     	ldrb	w9, [x12, #0x1f0]
101566904:     	ldp	x10, x11, [x12, #0x1f8]
101566908:     	mov	x13, #-0x8000000000000000 ; =-9223372036854775808
10156690c:     	str	x13, [x12, #0x1e0]
101566910:     	cmp	x8, x13
101566914:     	b.ne	0x1015669c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xb14>
101566918:     	str	wzr, [x19]
10156691c:     	mov	w8, #0xc                ; =12
101566920:     	strb	w8, [x19, #0x8]
101566924:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101566928:     	add	x8, x8, #0x876
10156692c:     	mov	w9, #0x1d               ; =29
101566930:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101566934:     	ldur	q0, [x23, #0x68]
101566938:     	ldur	q1, [x23, #0x78]
10156693c:     	ldur	q2, [x23, #0x88]
101566940:     	stp	q1, q2, [x19, #0x20]
101566944:     	ldur	q1, [x23, #0x98]
101566948:     	str	q1, [x19, #0x40]
10156694c:     	ldur	q1, [x23, #0x58]
101566950:     	stp	q1, q0, [x19]
101566954:     	b	0x101565f4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101566958:     	ldur	q0, [x23, #0x58]
10156695c:     	ldur	q1, [x23, #0x68]
101566960:     	stp	q0, q1, [x29, #-0xb0]
101566964:     	ldr	x8, [sp, #0x198]
101566968:     	stur	x8, [x29, #-0x90]
10156696c:     	add	x9, x24, #0x148
101566970:     	ldr	w10, [x24, #0x158]
101566974:     	stur	w10, [x29, #-0x70]
101566978:     	ldr	q2, [x9]
10156697c:     	stur	q2, [x29, #-0x80]
101566980:     	mov	w9, #0x4                ; =4
101566984:     	str	w9, [x19]
101566988:     	stur	q2, [x19, #0x4]
10156698c:     	str	w10, [x19, #0x14]
101566990:     	stur	q0, [x19, #0x18]
101566994:     	stur	q1, [x19, #0x28]
101566998:     	str	x8, [x19, #0x38]
10156699c:     	b	0x101565f4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015669a0:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015669a4:     	add	x8, x8, #0x792
1015669a8:     	mov	w9, #0x2c               ; =44
1015669ac:     	b	0x10156674c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
1015669b0:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015669b4:     	add	x8, x8, #0x7be
1015669b8:     	mov	w9, #0x31               ; =49
1015669bc:     	b	0x10156674c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
1015669c0:     	add	x13, sp, #0x18
1015669c4:     	add	x14, x12, #0x238
1015669c8:     	add	x15, x12, #0x208
1015669cc:     	ldp	q1, q2, [x15]
1015669d0:     	stp	q1, q2, [sp, #0x40]
1015669d4:     	ldr	q4, [x15, #0x20]
1015669d8:     	ldp	q1, q2, [x14, #0x90]
1015669dc:     	stur	q2, [x13, #0xf8]
1015669e0:     	ldr	q2, [x14, #0x80]
1015669e4:     	stur	q1, [x13, #0xe8]
1015669e8:     	stur	q2, [x13, #0xd8]
1015669ec:     	ldp	q2, q1, [x14, #0x60]
1015669f0:     	stur	q1, [x13, #0xc8]
1015669f4:     	stur	q2, [x13, #0xb8]
1015669f8:     	ldp	q2, q1, [x14, #0x40]
1015669fc:     	stur	q1, [x13, #0xa8]
101566a00:     	stur	q2, [x13, #0x98]
101566a04:     	ldp	q2, q1, [x14, #0x20]
101566a08:     	stur	q1, [x13, #0x88]
101566a0c:     	ldp	q1, q3, [x14]
101566a10:     	stp	q4, q1, [sp, #0x60]
101566a14:     	stur	q3, [sp, #0x80]
101566a18:     	add	x14, x12, #0x1f1
101566a1c:     	ldr	w12, [x12, #0x1f4]
101566a20:     	str	w12, [sp, #0x2c]
101566a24:     	ldr	w12, [x14]
101566a28:     	stur	w12, [sp, #0x29]
101566a2c:     	stur	q2, [x13, #0x78]
101566a30:     	str	x8, [sp, #0x18]
101566a34:     	str	d0, [sp, #0x20]
101566a38:     	strb	w9, [sp, #0x28]
101566a3c:     	stp	x10, x11, [sp, #0x30]
101566a40:     	str	x21, [sp, #0x178]
101566a44:     	add	x8, sp, #0x120
101566a48:     	add	x0, sp, #0x18
101566a4c:     	add	x1, sp, #0x178
101566a50:     	bl	0x1015c9178 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections8lifetimeNtB4_5State14release_source>
101566a54:     	add	x0, sp, #0x178
101566a58:     	add	x1, sp, #0x18
101566a5c:     	mov	w2, #0x108              ; =264
101566a60:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
101566a64:     	ldr	x8, [x21, #0x490]
101566a68:     	ldr	x9, [x8, #0x1e0]
101566a6c:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101566a70:     	cmp	x9, x10
101566a74:     	b.eq	0x101566a84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbd8>
101566a78:     	add	x0, x8, #0x1e0
101566a7c:     	bl	0x10154a9c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101566a80:     	ldr	x8, [x21, #0x490]
101566a84:     	add	x0, x8, #0x1e0
101566a88:     	add	x1, sp, #0x178
101566a8c:     	mov	w2, #0x108              ; =264
101566a90:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
101566a94:     	ldr	w8, [sp, #0x120]
101566a98:     	cmp	w8, #0x6
101566a9c:     	b.ne	0x101566b48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc9c>
101566aa0:     	mov	x9, x21
101566aa4:     	ldr	x20, [x9, #0x490]
101566aa8:     	ldrb	w8, [x20, #0x338]
101566aac:     	tbz	w8, #0x0, 0x101566b1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc70>
101566ab0:     	ldr	x8, [x20, #0x1e0]
101566ab4:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101566ab8:     	cmp	x8, x9
101566abc:     	b.eq	0x101566acc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc20>
101566ac0:     	add	x0, x20, #0x1e0
101566ac4:     	bl	0x1015c02d4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collectionsNtB2_5State11is_complete>
101566ac8:     	tbz	w0, #0x0, 0x101566b2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc80>
101566acc:     	ldr	x8, [x20, #0x10]
101566ad0:     	cmp	x8, #0x2
101566ad4:     	b.eq	0x101566af8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc4c>
101566ad8:     	ldr	x8, [x20, #0xa8]
101566adc:     	cbz	x8, 0x101566af8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc4c>
101566ae0:     	str	wzr, [x19]
101566ae4:     	mov	w8, #0xc                ; =12
101566ae8:     	strb	w8, [x19, #0x8]
101566aec:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101566af0:     	add	x8, x8, #0xfa8
101566af4:     	b	0x101566b40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc94>
101566af8:     	ldr	x8, [x21, #0x4c0]
101566afc:     	cbz	x8, 0x101566b1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc70>
101566b00:     	str	wzr, [x19]
101566b04:     	mov	w8, #0xc                ; =12
101566b08:     	strb	w8, [x19, #0x8]
101566b0c:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101566b10:     	add	x8, x8, #0xf7f
101566b14:     	mov	w9, #0x29               ; =41
101566b18:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101566b1c:     	strb	wzr, [x20, #0x460]
101566b20:     	mov	w8, #0x6                ; =6
101566b24:     	str	w8, [x19]
101566b28:     	b	0x101565f4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101566b2c:     	str	wzr, [x19]
101566b30:     	mov	w8, #0xc                ; =12
101566b34:     	strb	w8, [x19, #0x8]
101566b38:     	adrp	x8, 0x107551000 <_anon.61c4a8641e5b3956ea8870164c4e553f.372+0x908>
101566b3c:     	add	x8, x8, #0xfd4
101566b40:     	mov	w9, #0x2c               ; =44
101566b44:     	b	0x101565f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101566b48:     	add	x9, sp, #0x120
101566b4c:     	ldur	q0, [x9, #0x14]
101566b50:     	stur	q0, [x19, #0x14]
101566b54:     	ldur	q0, [x9, #0x24]
101566b58:     	stur	q0, [x19, #0x24]
101566b5c:     	ldur	q0, [x9, #0x34]
101566b60:     	stur	q0, [x19, #0x34]
101566b64:     	ldr	q0, [sp, #0x160]
101566b68:     	str	q0, [x19, #0x40]
101566b6c:     	ldur	q0, [x9, #0x4]
101566b70:     	stur	q0, [x19, #0x4]
101566b74:     	str	w8, [x19]
101566b78:     	b	0x101565f4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101566b7c:     	adrp	x8, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566b80:     	add	x8, x8, #0x58
101566b84:     	mov	x0, x2
101566b88:     	mov	x2, x8
101566b8c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566b90:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566b94:     	add	x2, x2, #0x70
101566b98:     	mov	x0, x25
101566b9c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566ba0:     	adrp	x2, 0x107f08000 <_anon.0504008e54a1502d122e47b3b8bf1e07.436+0x1e8>
101566ba4:     	add	x2, x2, #0xdd0
101566ba8:     	mov	x0, #0x0                ; =0
101566bac:     	mov	x1, #0x0                ; =0
101566bb0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566bb4:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566bb8:     	add	x2, x2, #0x688
101566bbc:     	mov	x0, x8
101566bc0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566bc4:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566bc8:     	add	x2, x2, #0x8b0
101566bcc:     	mov	x0, x8
101566bd0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566bd4:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566bd8:     	add	x2, x2, #0x88
101566bdc:     	mov	x0, x8
101566be0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566be4:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566be8:     	add	x2, x2, #0xa0
101566bec:     	mov	x0, x20
101566bf0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566bf4:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566bf8:     	add	x2, x2, #0xb8
101566bfc:     	mov	x0, x20
101566c00:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566c04:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566c08:     	add	x2, x2, #0xe8
101566c0c:     	mov	x0, x20
101566c10:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566c14:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566c18:     	add	x2, x2, #0x8c8
101566c1c:     	mov	x0, x9
101566c20:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566c24:     	adrp	x9, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566c28:     	add	x9, x9, #0xd0
101566c2c:     	mov	x0, x2
101566c30:     	mov	x1, x8
101566c34:     	mov	x2, x9
101566c38:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566c3c:     	adrp	x8, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101566c40:     	add	x8, x8, #0x100
101566c44:     	mov	x0, x2
101566c48:     	mov	x2, x8
101566c4c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566c50:     	adrp	x2, 0x107f08000 <_anon.0504008e54a1502d122e47b3b8bf1e07.436+0x1e8>
101566c54:     	add	x2, x2, #0xde8
101566c58:     	mov	x1, x8
101566c5c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101566c60:     	mov	x19, x0
101566c64:     	ldr	x8, [x21, #0x490]
101566c68:     	add	x0, x8, #0x1e0
101566c6c:     	add	x1, sp, #0x178
101566c70:     	mov	w2, #0x108              ; =264
101566c74:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
101566c78:     	ldr	w8, [sp, #0x120]
101566c7c:     	cmp	w8, #0x6
101566c80:     	b.eq	0x101566cb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xe08>
101566c84:     	add	x0, sp, #0x120
101566c88:     	bl	0x10154a66c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101566c8c:     	mov	x0, x19
101566c90:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
101566c94:     	mov	x19, x0
101566c98:     	add	x0, sp, #0x18
101566c9c:     	bl	0x10154a9c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101566ca0:     	b	0x101566cb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xe08>
101566ca4:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101566ca8:     	mov	x19, x0
101566cac:     	mov	w8, #0x2                ; =2
101566cb0:     	str	x8, [x21, #0x220]
101566cb4:     	mov	x0, x19
101566cb8:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
101566cbc:     	mov	x19, x0
101566cc0:     	add	x0, sp, #0x178
101566cc4:     	bl	0x101549050 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
101566cc8:     	mov	x0, x19
101566ccc:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
101566cd0:     	mov	x19, x0
101566cd4:     	add	x0, sp, #0x178
101566cd8:     	bl	0x101549050 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
101566cdc:     	mov	x0, x19
101566ce0:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
