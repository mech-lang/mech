
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010154d06c <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>:
10154d06c:     	ldp	x9, x8, [x0]
10154d070:     	cmp	x9, x8
10154d074:     	b.eq	0x10154d0ec <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x80>
10154d078:     	ldp	x12, x11, [x1]
10154d07c:     	mov	w13, #0x18              ; =24
10154d080:     	ldr	x14, [x1, #0x28]
10154d084:     	b	0x10154d090 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x24>
10154d088:     	cmp	x9, x8
10154d08c:     	b.eq	0x10154d0d8 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x6c>
10154d090:     	mov	x10, x9
10154d094:     	ldr	w15, [x9], #0x4
10154d098:     	cmp	x11, x15
10154d09c:     	b.ls	0x10154d088 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
10154d0a0:     	umaddl	x15, w15, w13, x12
10154d0a4:     	ldr	x16, [x15]
10154d0a8:     	cmp	x16, #0x1
10154d0ac:     	b.ne	0x10154d088 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
10154d0b0:     	ldp	x16, x15, [x15, #0x8]
10154d0b4:     	add	x15, x15, x16
10154d0b8:     	cmp	x15, x16
10154d0bc:     	ccmp	x15, x14, #0x2, hs
10154d0c0:     	b.hi	0x10154d088 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
10154d0c4:     	mov	w8, #0x1                ; =1
10154d0c8:     	add	x9, x10, #0x4
10154d0cc:     	str	x9, [x0]
10154d0d0:     	mov	x0, x8
10154d0d4:     	ret
10154d0d8:     	mov	w8, #0x0                ; =0
10154d0dc:     	add	x9, x10, #0x4
10154d0e0:     	str	x9, [x0]
10154d0e4:     	mov	x0, x8
10154d0e8:     	ret
10154d0ec:     	mov	w0, #0x0                ; =0
10154d0f0:     	ret
