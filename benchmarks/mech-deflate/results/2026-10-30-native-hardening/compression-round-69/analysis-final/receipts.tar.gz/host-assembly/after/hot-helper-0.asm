
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101566ce4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>:
101566ce4:     	stp	x28, x27, [sp, #-0x60]!
101566ce8:     	stp	x26, x25, [sp, #0x10]
101566cec:     	stp	x24, x23, [sp, #0x20]
101566cf0:     	stp	x22, x21, [sp, #0x30]
101566cf4:     	stp	x20, x19, [sp, #0x40]
101566cf8:     	stp	x29, x30, [sp, #0x50]
101566cfc:     	add	x29, sp, #0x50
101566d00:     	sub	sp, sp, #0x810
101566d04:     	str	xzr, [sp]
101566d08:     	add	x9, x2, #0x1d
101566d0c:     	cmp	x9, #0x1f
101566d10:     	b.hi	0x101566d3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101566d14:     	mov	w10, #-0x10000001       ; =-268435457
101566d18:     	lsr	w10, w10, w9
101566d1c:     	tbz	w10, #0x0, 0x101566d3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101566d20:     	adrp	x10, 0x107553000 <_anon.61c4a8641e5b3956ea8870164c4e553f.880+0x331>
101566d24:     	add	x10, x10, #0xad0
101566d28:     	ldr	x22, [x10, x9, lsl #3]
101566d2c:     	ldr	x9, [x0, #0x238]
101566d30:     	cmp	x9, #0x3
101566d34:     	b.ne	0x101566d50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6c>
101566d38:     	b	0x101566d78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101566d3c:     	sub	x21, x2, #0x3
101566d40:     	mov	w22, #0x3               ; =3
101566d44:     	ldr	x9, [x0, #0x238]
101566d48:     	cmp	x9, #0x3
101566d4c:     	b.eq	0x101566d78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101566d50:     	ldr	w9, [x0, #0x268]
101566d54:     	cbz	w9, 0x101566d78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101566d58:     	str	wzr, [x8]
101566d5c:     	mov	w9, #0xc                ; =12
101566d60:     	strb	w9, [x8, #0x8]
101566d64:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101566d68:     	add	x9, x9, #0x247
101566d6c:     	mov	w10, #0x25              ; =37
101566d70:     	stp	x9, x10, [x8, #0x10]
101566d74:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101566d78:     	cmp	x22, #0xb
101566d7c:     	b.eq	0x101566e54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
101566d80:     	add	x27, sp, #0x550
101566d84:     	add	x24, sp, #0x440
101566d88:     	add	x26, sp, #0x330
101566d8c:     	add	x25, sp, #0x220
101566d90:     	cmp	x22, #0x1d
101566d94:     	b.eq	0x101566de8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104>
101566d98:     	cmp	x22, #0x1f
101566d9c:     	b.ne	0x101566e84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a0>
101566da0:     	ldp	x20, x28, [x3]
101566da4:     	ldr	x10, [x3, #0x10]
101566da8:     	ldp	x12, x11, [x0, #0xc0]
101566dac:     	ldp	x26, x19, [x0, #0xd0]
101566db0:     	ldp	x22, x25, [x0, #0xe0]
101566db4:     	ldr	w9, [x0, #0xf0]
101566db8:     	mov	w13, #0x2               ; =2
101566dbc:     	str	x13, [x0, #0xc0]
101566dc0:     	cbz	x12, 0x101566f00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x21c>
101566dc4:     	cmp	x12, #0x2
101566dc8:     	b.ne	0x101566f1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x238>
101566dcc:     	str	wzr, [x8]
101566dd0:     	mov	w9, #0xc                ; =12
101566dd4:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101566dd8:     	add	x10, x10, #0xc4e
101566ddc:     	stp	x9, x10, [x8, #0x8]
101566de0:     	mov	w9, #0x20               ; =32
101566de4:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101566de8:     	ldr	x19, [x0, #0x498]
101566dec:     	ldr	x9, [x19, #0x270]
101566df0:     	cmp	x1, x9
101566df4:     	b.hs	0x101566ec8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
101566df8:     	ldr	x9, [x19, #0x268]
101566dfc:     	add	x9, x9, x1, lsl #4
101566e00:     	ldr	w10, [x9]
101566e04:     	tbz	w10, #0x0, 0x101566ec8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
101566e08:     	ldr	x9, [x9, #0x8]
101566e0c:     	ldr	x10, [x19, #0x258]
101566e10:     	cmp	x9, x10
101566e14:     	b.hs	0x1015695e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28fc>
101566e18:     	ldr	x10, [x19, #0x250]
101566e1c:     	mov	w11, #0x160             ; =352
101566e20:     	madd	x21, x9, x11, x10
101566e24:     	mov	x20, x21
101566e28:     	ldr	x10, [x20, #0x30]!
101566e2c:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
101566e30:     	cmp	x10, x11
101566e34:     	b.ne	0x10156701c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x338>
101566e38:     	str	wzr, [x8]
101566e3c:     	mov	w9, #0xc                ; =12
101566e40:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101566e44:     	add	x10, x10, #0xbd6
101566e48:     	stp	x9, x10, [x8, #0x8]
101566e4c:     	mov	w9, #0x23               ; =35
101566e50:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101566e54:     	mov	x9, x0
101566e58:     	mov	x0, x8
101566e5c:     	mov	x2, x1
101566e60:     	mov	x1, x9
101566e64:     	add	sp, sp, #0x810
101566e68:     	ldp	x29, x30, [sp, #0x50]
101566e6c:     	ldp	x20, x19, [sp, #0x40]
101566e70:     	ldp	x22, x21, [sp, #0x30]
101566e74:     	ldp	x24, x23, [sp, #0x20]
101566e78:     	ldp	x26, x25, [sp, #0x10]
101566e7c:     	ldp	x28, x27, [sp], #0x60
101566e80:     	b	0x1015594a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
101566e84:     	ldr	x9, [x0, #0xc0]
101566e88:     	cmp	x9, #0x2
101566e8c:     	b.ne	0x101566ee4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x200>
101566e90:     	cmp	x22, #0x15
101566e94:     	b.gt	0x101566fd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4>
101566e98:     	sub	x9, x22, #0xc
101566e9c:     	cmp	x9, #0x4
101566ea0:     	b.hs	0x1015672a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5c0>
101566ea4:     	lsr	x9, x1, #32
101566ea8:     	cbz	x9, 0x10156705c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x378>
101566eac:     	str	wzr, [x8]
101566eb0:     	mov	w9, #0xc                ; =12
101566eb4:     	strb	w9, [x8, #0x8]
101566eb8:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101566ebc:     	add	x9, x9, #0xead
101566ec0:     	mov	w10, #0x15              ; =21
101566ec4:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101566ec8:     	str	wzr, [x8]
101566ecc:     	mov	w9, #0xc                ; =12
101566ed0:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101566ed4:     	add	x10, x10, #0xae2
101566ed8:     	stp	x9, x10, [x8, #0x8]
101566edc:     	mov	w9, #0x2d               ; =45
101566ee0:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101566ee4:     	str	wzr, [x8]
101566ee8:     	mov	w9, #0xc                ; =12
101566eec:     	strb	w9, [x8, #0x8]
101566ef0:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101566ef4:     	add	x9, x9, #0x87
101566ef8:     	mov	w10, #0x35              ; =53
101566efc:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101566f00:     	str	wzr, [x8]
101566f04:     	mov	w9, #0xc                ; =12
101566f08:     	strb	w9, [x8, #0x8]
101566f0c:     	adrp	x9, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101566f10:     	add	x9, x9, #0xdfc
101566f14:     	mov	w10, #0x27              ; =39
101566f18:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101566f1c:     	ldr	x21, [x0, #0x498]
101566f20:     	ldr	x12, [x21, #0x178]
101566f24:     	cmp	x11, x12
101566f28:     	b.hs	0x101566f9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101566f2c:     	ldr	x12, [x21, #0x170]
101566f30:     	add	x12, x12, x11, lsl #4
101566f34:     	ldr	x11, [x12]
101566f38:     	ldr	x13, [x21, #0x160]
101566f3c:     	cmp	x11, x13
101566f40:     	b.hs	0x101566f9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101566f44:     	ldr	x12, [x12, #0x8]
101566f48:     	ldr	x13, [x21, #0x158]
101566f4c:     	mov	w14, #0x48              ; =72
101566f50:     	madd	x11, x11, x14, x13
101566f54:     	ldr	x13, [x11, #0x28]
101566f58:     	cmp	x12, x13
101566f5c:     	b.hs	0x101566f9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101566f60:     	ldr	x13, [x11, #0x20]
101566f64:     	mov	w14, #0x110             ; =272
101566f68:     	madd	x23, x12, x14, x13
101566f6c:     	mov	x24, x23
101566f70:     	ldr	x13, [x24, #0x30]!
101566f74:     	mov	x12, #-0x8000000000000000 ; =-9223372036854775808
101566f78:     	cmp	x13, x12
101566f7c:     	b.ne	0x101567514 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x830>
101566f80:     	str	wzr, [x8]
101566f84:     	mov	w9, #0xc                ; =12
101566f88:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101566f8c:     	add	x10, x10, #0xc6e
101566f90:     	stp	x9, x10, [x8, #0x8]
101566f94:     	mov	w9, #0x1f               ; =31
101566f98:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101566f9c:     	str	wzr, [x8]
101566fa0:     	mov	w9, #0xc                ; =12
101566fa4:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101566fa8:     	add	x10, x10, #0xdcb
101566fac:     	stp	x9, x10, [x8, #0x8]
101566fb0:     	mov	w9, #0x29               ; =41
101566fb4:     	str	x9, [x8, #0x18]
101566fb8:     	add	sp, sp, #0x810
101566fbc:     	ldp	x29, x30, [sp, #0x50]
101566fc0:     	ldp	x20, x19, [sp, #0x40]
101566fc4:     	ldp	x22, x21, [sp, #0x30]
101566fc8:     	ldp	x24, x23, [sp, #0x20]
101566fcc:     	ldp	x26, x25, [sp, #0x10]
101566fd0:     	ldp	x28, x27, [sp], #0x60
101566fd4:     	ret
101566fd8:     	sub	x9, x22, #0x17
101566fdc:     	cmp	x9, #0x4
101566fe0:     	b.hs	0x1015672dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f8>
101566fe4:     	cmn	x2, #0x17
101566fe8:     	b.gt	0x1015670d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f0>
101566fec:     	cmn	x2, #0x18
101566ff0:     	b.eq	0x1015673f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x714>
101566ff4:     	cmn	x2, #0x17
101566ff8:     	b.ne	0x1015673dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f8>
101566ffc:     	ldr	x9, [x0, #0xf8]
101567000:     	cmp	x9, #0x2
101567004:     	b.ne	0x101567564 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x880>
101567008:     	str	wzr, [x8]
10156700c:     	mov	w9, #0xc                ; =12
101567010:     	adrp	x10, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567014:     	add	x10, x10, #0x595
101567018:     	b	0x101567534 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x850>
10156701c:     	ldp	x10, x11, [x21, #0x68]
101567020:     	sub	x23, x10, #0x18
101567024:     	lsl	x10, x11, #5
101567028:     	cbz	x10, 0x10156728c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a8>
10156702c:     	ldr	x11, [x23, #0x18]
101567030:     	add	x23, x23, #0x20
101567034:     	sub	x10, x10, #0x20
101567038:     	cmp	x11, x1
10156703c:     	b.ne	0x101567028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344>
101567040:     	ldr	w10, [x23]
101567044:     	cmp	w10, #0x5
101567048:     	b.eq	0x101567540 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x85c>
10156704c:     	cmp	w10, #0x6
101567050:     	b.ne	0x10156728c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a8>
101567054:     	mov	w22, #0x8               ; =8
101567058:     	b	0x101567544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x860>
10156705c:     	ldr	x9, [x0, #0x4b8]
101567060:     	lsr	x10, x9, #59
101567064:     	cbnz	x10, 0x1015682cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15e8>
101567068:     	mov	x10, #-0x21             ; =-33
10156706c:     	movk	x10, #0x7ff, lsl #48
101567070:     	cmp	x9, x10
101567074:     	b.hi	0x1015682cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15e8>
101567078:     	mov	x25, x2
10156707c:     	mov	x21, x3
101567080:     	mov	x19, x1
101567084:     	mov	x23, x8
101567088:     	mov	x20, x0
10156708c:     	ldr	x26, [x0, #0x490]
101567090:     	lsl	x8, x9, #5
101567094:     	and	x8, x8, #0xffffffffffffffc0
101567098:     	add	x22, x8, #0x400
10156709c:     	ldr	x8, [x26, #0x310]
1015670a0:     	cbz	x8, 0x1015674a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c0>
1015670a4:     	ldr	x2, [x26, #0x308]
1015670a8:     	add	x8, sp, #0x550
1015670ac:     	add	x0, x26, #0x310
1015670b0:     	mov	x1, x22
1015670b4:     	bl	0x102369360 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015670b8:     	ldrb	w8, [sp, #0x550]
1015670bc:     	cmp	w8, #0x8
1015670c0:     	b.ne	0x1015674c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7e0>
1015670c4:     	mov	x0, x20
1015670c8:     	mov	x1, x19
1015670cc:     	mov	x10, x25
1015670d0:     	b	0x101567a54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd70>
1015670d4:     	cmn	x2, #0x16
1015670d8:     	b.eq	0x101567420 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x73c>
1015670dc:     	cmn	x2, #0x15
1015670e0:     	b.ne	0x1015673dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f8>
1015670e4:     	ldr	x9, [x0, #0x498]
1015670e8:     	str	x9, [sp, #0x660]
1015670ec:     	ldr	x19, [x3, #0x10]
1015670f0:     	ldr	x10, [x9, #0x5a0]
1015670f4:     	cmp	x19, x10
1015670f8:     	b.hs	0x1015675fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x918>
1015670fc:     	ldr	x9, [x9, #0x598]
101567100:     	mov	w10, #0x58              ; =88
101567104:     	madd	x22, x19, x10, x9
101567108:     	ldr	w9, [x22, #0x3c]
10156710c:     	cmp	x1, x9
101567110:     	b.ne	0x1015676cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
101567114:     	ldr	x24, [x0, #0x490]
101567118:     	ldr	w9, [x24, #0x2f0]
10156711c:     	cmp	w9, #0x1
101567120:     	b.ne	0x1015676cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
101567124:     	ldr	w9, [x24, #0x2f4]
101567128:     	cmp	w9, w1
10156712c:     	b.ne	0x1015676cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
101567130:     	ldr	w9, [x24, #0x2e8]
101567134:     	cmp	w9, #0x1
101567138:     	b.ne	0x1015676cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10156713c:     	ldr	w9, [x22, #0x34]
101567140:     	ldr	w10, [x24, #0x2ec]
101567144:     	cmp	w10, w9
101567148:     	b.ne	0x1015676cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10156714c:     	ldrb	w10, [x24, #0x460]
101567150:     	cmp	w10, #0x1
101567154:     	b.ne	0x1015676cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
101567158:     	mov	x23, x8
10156715c:     	str	x0, [sp, #0x58]
101567160:     	ldr	x8, [x0, #0xf8]
101567164:     	cmp	x8, #0x2
101567168:     	b.ne	0x1015680ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
10156716c:     	ldr	x8, [sp, #0x58]
101567170:     	ldrb	w8, [x8, #0x508]
101567174:     	tbnz	w8, #0x0, 0x1015680ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
101567178:     	lsl	x0, x9, #1
10156717c:     	ldr	x8, [sp, #0x58]
101567180:     	ldr	x1, [x8, #0x4b8]
101567184:     	cmp	x0, x1
101567188:     	b.hs	0x10156a2dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35f8>
10156718c:     	ldr	x8, [sp, #0x58]
101567190:     	ldr	x9, [x8, #0x4b0]
101567194:     	ldr	x28, [x9, x0, lsl #3]
101567198:     	ldr	x8, [x8, #0x3c0]
10156719c:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015671a0:     	cmp	x8, x9
1015671a4:     	b.ne	0x101568360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x167c>
1015671a8:     	mov	x21, x3
1015671ac:     	bl	0x102e6ab68 <__RNvNtNtCsgirOGyZpP7g_3std6thread9functions21available_parallelism>
1015671b0:     	cmp	x0, #0x1
1015671b4:     	b.ne	0x1015671c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e0>
1015671b8:     	mov	x0, x1
1015671bc:     	bl	0x101547efc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtNtB4_3num7nonzero7NonZerojENtNtNtCsgirOGyZpP7g_3std2io5error5ErrorEECs7fdMCt8k5K6_8mech_gpu>
1015671c0:     	mov	w1, #0x1                ; =1
1015671c4:     	mov	w8, #0x20               ; =32
1015671c8:     	cmp	x1, #0x20
1015671cc:     	csel	x20, x1, x8, lo
1015671d0:     	sub	x8, x28, #0x1
1015671d4:     	cmp	x8, x20
1015671d8:     	b.hs	0x1015680ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015671dc:     	ldr	x8, [x22, #0x28]
1015671e0:     	str	x8, [sp, #0x50]
1015671e4:     	cmp	x8, x20
1015671e8:     	b.hi	0x1015680ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015671ec:     	ldr	x8, [x22, #0x20]
1015671f0:     	str	x8, [sp, #0x48]
1015671f4:     	add	x8, sp, #0x550
1015671f8:     	add	x0, x24, #0x3b8
1015671fc:     	bl	0x102368c08 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101567200:     	ldr	x8, [sp, #0x550]
101567204:     	cmp	x8, #0x1
101567208:     	b.ne	0x1015680ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
10156720c:     	ldr	x8, [sp, #0x558]
101567210:     	cbz	x8, 0x1015680ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
101567214:     	ldr	x8, [x21]
101567218:     	str	x8, [sp, #0x40]
10156721c:     	cbz	x8, 0x10156897c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c98>
101567220:     	ldr	x8, [x21, #0x8]
101567224:     	cbz	x8, 0x10156897c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c98>
101567228:     	mov	x21, x8
10156722c:     	ldr	x9, [x8, #0x38]
101567230:     	ldr	x8, [sp, #0x58]
101567234:     	cmp	x9, x8
101567238:     	b.ne	0x101567270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
10156723c:     	ldr	x8, [x21]
101567240:     	cmp	x8, #0x25
101567244:     	b.ne	0x101567270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
101567248:     	ldr	x8, [x21, #0x10]
10156724c:     	ldr	x9, [sp, #0x660]
101567250:     	ldr	x9, [x9, #0x360]
101567254:     	cmp	x8, x9
101567258:     	b.lo	0x101567270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
10156725c:     	ldr	x8, [x21, #0x28]
101567260:     	cbz	x8, 0x101567270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
101567264:     	ldr	x8, [x21, #0x70]
101567268:     	cmp	x8, #0x4
10156726c:     	b.ne	0x1015698dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bf8>
101567270:     	str	wzr, [x23]
101567274:     	mov	w8, #0xc                ; =12
101567278:     	strb	w8, [x23, #0x8]
10156727c:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567280:     	add	x8, x8, #0x427
101567284:     	mov	w9, #0x28               ; =40
101567288:     	b	0x101567f7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
10156728c:     	str	wzr, [x8]
101567290:     	mov	w9, #0xc                ; =12
101567294:     	strb	w9, [x8, #0x8]
101567298:     	adrp	x9, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
10156729c:     	add	x9, x9, #0xb0b
1015672a0:     	b	0x1015676a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
1015672a4:     	mov	x19, x2
1015672a8:     	mov	x23, x3
1015672ac:     	cmp	x22, #0x14
1015672b0:     	b.ne	0x101567350 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
1015672b4:     	ldr	x9, [x0, #0x490]
1015672b8:     	ldr	x10, [x0, #0x498]
1015672bc:     	mov	x24, x0
1015672c0:     	mov	x0, x9
1015672c4:     	mov	x20, x1
1015672c8:     	mov	x1, x10
1015672cc:     	mov	x2, x20
1015672d0:     	mov	x25, x8
1015672d4:     	bl	0x101578e24 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015672d8:     	b	0x101567310 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x62c>
1015672dc:     	mov	x19, x2
1015672e0:     	mov	x23, x3
1015672e4:     	cmp	x22, #0x16
1015672e8:     	b.ne	0x101567350 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
1015672ec:     	ldr	x9, [x0, #0x490]
1015672f0:     	ldr	x10, [x0, #0x498]
1015672f4:     	mov	x24, x0
1015672f8:     	mov	x0, x9
1015672fc:     	mov	x20, x1
101567300:     	mov	x1, x10
101567304:     	mov	x2, x20
101567308:     	mov	x25, x8
10156730c:     	bl	0x1015621a8 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
101567310:     	mov	x1, x20
101567314:     	mov	x8, x25
101567318:     	mov	x9, x0
10156731c:     	mov	x0, x24
101567320:     	tbz	w9, #0x0, 0x101567350 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
101567324:     	mov	x20, x8
101567328:     	add	x8, sp, #0x550
10156732c:     	mov	x24, x0
101567330:     	mov	x25, x1
101567334:     	bl	0x101565eac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
101567338:     	ldr	w8, [sp, #0x550]
10156733c:     	cmp	w8, #0x6
101567340:     	b.ne	0x1015674f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x80c>
101567344:     	mov	x8, x20
101567348:     	mov	x0, x24
10156734c:     	mov	x1, x25
101567350:     	ldr	x9, [x0, #0x490]
101567354:     	ldr	w10, [x9, #0x2f0]
101567358:     	tbz	w10, #0x0, 0x1015673c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6dc>
10156735c:     	ldr	w10, [x9, #0x2f4]
101567360:     	cmp	x1, x10
101567364:     	b.ne	0x1015673c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6dc>
101567368:     	mov	x3, x23
10156736c:     	ldr	x23, [x0, #0x498]
101567370:     	mov	x20, x1
101567374:     	mov	x25, x0
101567378:     	cmp	x22, #0x1a
10156737c:     	b.gt	0x1015678bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbd8>
101567380:     	sub	x10, x22, #0x13
101567384:     	cmp	x10, #0x4
101567388:     	b.hs	0x101567b98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xeb4>
10156738c:     	mov	x0, x8
101567390:     	mov	x1, x25
101567394:     	mov	x2, x20
101567398:     	mov	x4, x3
10156739c:     	mov	x3, x19
1015673a0:     	add	sp, sp, #0x810
1015673a4:     	ldp	x29, x30, [sp, #0x50]
1015673a8:     	ldp	x20, x19, [sp, #0x40]
1015673ac:     	ldp	x22, x21, [sp, #0x30]
1015673b0:     	ldp	x24, x23, [sp, #0x20]
1015673b4:     	ldp	x26, x25, [sp, #0x10]
1015673b8:     	ldp	x28, x27, [sp], #0x60
1015673bc:     	b	0x1015773c4 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation19retained_map_helper>
1015673c0:     	str	wzr, [x8]
1015673c4:     	mov	w9, #0xc                ; =12
1015673c8:     	strb	w9, [x8, #0x8]
1015673cc:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015673d0:     	add	x9, x9, #0x224
1015673d4:     	mov	w10, #0x23              ; =35
1015673d8:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015673dc:     	str	wzr, [x8]
1015673e0:     	mov	w9, #0xc                ; =12
1015673e4:     	strb	w9, [x8, #0x8]
1015673e8:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015673ec:     	add	x9, x9, #0x65f
1015673f0:     	mov	w10, #0x20              ; =32
1015673f4:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015673f8:     	ldr	x9, [x0, #0xf8]
1015673fc:     	cmp	x9, #0x2
101567400:     	b.ne	0x101567618 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x934>
101567404:     	str	wzr, [x8]
101567408:     	mov	w9, #0xc                ; =12
10156740c:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101567410:     	add	x10, x10, #0xc31
101567414:     	stp	x9, x10, [x8, #0x8]
101567418:     	mov	w9, #0x26               ; =38
10156741c:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101567420:     	ldr	x13, [x3]
101567424:     	ldr	x26, [x0, #0x498]
101567428:     	ldr	x9, [x26, #0x5a0]
10156742c:     	cmp	x13, x9
101567430:     	b.hs	0x1015676b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
101567434:     	ldp	x10, x9, [x3, #0x8]
101567438:     	orr	x9, x10, x9
10156743c:     	cbnz	x9, 0x1015676e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101567440:     	ldr	x9, [x26, #0x598]
101567444:     	mov	w10, #0x58              ; =88
101567448:     	madd	x22, x13, x10, x9
10156744c:     	ldr	w9, [x22, #0x44]
101567450:     	cmp	x1, x9
101567454:     	b.ne	0x1015676e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101567458:     	ldr	x20, [x0, #0x490]
10156745c:     	ldr	w9, [x20, #0x2f0]
101567460:     	cmp	w9, #0x1
101567464:     	b.ne	0x1015676e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101567468:     	ldr	w9, [x20, #0x2f4]
10156746c:     	cmp	w9, w1
101567470:     	b.ne	0x1015676e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101567474:     	ldrb	w9, [x20, #0x460]
101567478:     	cmp	w9, #0x1
10156747c:     	b.ne	0x1015676e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101567480:     	mov	x19, x8
101567484:     	ldr	x8, [x0, #0x3c0]
101567488:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10156748c:     	cmp	x8, x9
101567490:     	b.ne	0x101567fdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12f8>
101567494:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
101567498:     	ldr	q0, [x8]
10156749c:     	stur	q0, [x19, #0x8]
1015674a0:     	b	0x101568174 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1490>
1015674a4:     	bl	0x102368b7c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015674a8:     	tbz	w0, #0x0, 0x101567704 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
1015674ac:     	mov	w11, #0x0               ; =0
1015674b0:     	mov	w10, #0x0               ; =0
1015674b4:     	mov	x8, #0x0                ; =0
1015674b8:     	mov	w13, #0x7               ; =7
1015674bc:     	mov	x12, x23
1015674c0:     	b	0x101567880 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
1015674c4:     	ldr	x8, [sp, #0x550]
1015674c8:     	ldr	x14, [sp, #0x558]
1015674cc:     	ldr	x9, [sp, #0x560]
1015674d0:     	and	x10, x8, #0xffff
1015674d4:     	cmp	x10, #0x606
1015674d8:     	mov	x12, x23
1015674dc:     	b.ne	0x101567868 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb84>
1015674e0:     	mov	w10, #0x0               ; =0
1015674e4:     	mov	w13, #0x6               ; =6
1015674e8:     	mov	x8, x14
1015674ec:     	b	0x101567880 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
1015674f0:     	ldr	q0, [sp, #0x570]
1015674f4:     	ldr	q1, [sp, #0x580]
1015674f8:     	stp	q0, q1, [x20, #0x20]
1015674fc:     	ldr	q0, [sp, #0x590]
101567500:     	str	q0, [x20, #0x40]
101567504:     	ldr	q0, [sp, #0x560]
101567508:     	ldr	q1, [sp, #0x550]
10156750c:     	stp	q1, q0, [x20]
101567510:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101567514:     	mov	x14, x23
101567518:     	ldr	x13, [x14, #0xb0]!
10156751c:     	cmp	x13, x12
101567520:     	b.ne	0x101567900 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc1c>
101567524:     	str	wzr, [x8]
101567528:     	mov	w9, #0xc                ; =12
10156752c:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101567530:     	add	x10, x10, #0xc8d
101567534:     	stp	x9, x10, [x8, #0x8]
101567538:     	mov	w9, #0x21               ; =33
10156753c:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101567540:     	mov	w22, #0x10              ; =16
101567544:     	ldr	x10, [x3, #0x10]
101567548:     	cbz	x10, 0x101567730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa4c>
10156754c:     	str	wzr, [x8]
101567550:     	mov	w9, #0xc                ; =12
101567554:     	strb	w9, [x8, #0x8]
101567558:     	adrp	x9, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
10156755c:     	add	x9, x9, #0xadd
101567560:     	b	0x1015676a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
101567564:     	ldr	x23, [x0, #0x498]
101567568:     	ldr	x11, [x23, #0x5a0]
10156756c:     	ldr	x10, [x0, #0x1c0]
101567570:     	cmp	x10, x11
101567574:     	b.hs	0x101567a0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd28>
101567578:     	ldr	x21, [x0, #0x490]
10156757c:     	ldr	w11, [x21, #0x2f0]
101567580:     	cmp	w11, #0x1
101567584:     	b.ne	0x101567c00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf1c>
101567588:     	ldr	x11, [x3, #0x8]
10156758c:     	cmp	x11, x10
101567590:     	b.ne	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
101567594:     	ldr	x11, [x3, #0x10]
101567598:     	cbnz	x11, 0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
10156759c:     	cbnz	x9, 0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015675a0:     	ldr	x9, [x23, #0x598]
1015675a4:     	mov	w11, #0x58              ; =88
1015675a8:     	madd	x24, x10, x11, x9
1015675ac:     	ldr	w26, [x24, #0x48]
1015675b0:     	cmp	x1, x26
1015675b4:     	b.ne	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015675b8:     	ldr	w9, [x21, #0x2e8]
1015675bc:     	tbz	w9, #0x0, 0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015675c0:     	ldr	w9, [x24, #0x34]
1015675c4:     	ldr	w10, [x21, #0x2ec]
1015675c8:     	cmp	w10, w9
1015675cc:     	b.ne	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015675d0:     	ldr	x9, [x24, #0x18]
1015675d4:     	cbz	x9, 0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015675d8:     	mov	x25, x3
1015675dc:     	mov	x20, x0
1015675e0:     	mov	x22, x8
1015675e4:     	ldr	w19, [x21, #0x2f4]
1015675e8:     	ldr	x8, [x24, #0x10]
1015675ec:     	cmp	x9, #0x1
1015675f0:     	b.ne	0x1015681fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1518>
1015675f4:     	mov	x10, #0x0               ; =0
1015675f8:     	b	0x101568220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x153c>
1015675fc:     	str	wzr, [x8]
101567600:     	mov	w9, #0xc                ; =12
101567604:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101567608:     	add	x10, x10, #0x9ba
10156760c:     	stp	x9, x10, [x8, #0x8]
101567610:     	mov	w9, #0x22               ; =34
101567614:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101567618:     	ldr	x11, [x0, #0x498]
10156761c:     	ldr	x12, [x11, #0x5a0]
101567620:     	ldr	x10, [x0, #0x1c0]
101567624:     	cmp	x10, x12
101567628:     	b.hs	0x101567a28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd44>
10156762c:     	ldr	x11, [x11, #0x598]
101567630:     	mov	w12, #0x58              ; =88
101567634:     	madd	x11, x10, x12, x11
101567638:     	ldr	w11, [x11, #0x38]
10156763c:     	cmp	x1, x11
101567640:     	b.ne	0x101567694 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
101567644:     	add	x11, x0, #0x1c8
101567648:     	ldr	q0, [x11]
10156764c:     	stur	q0, [x27, #0x8]
101567650:     	ldp	x11, x12, [x3]
101567654:     	ldr	x13, [x3, #0x10]
101567658:     	ldr	x14, [sp, #0x558]
10156765c:     	ldr	x15, [sp, #0x560]
101567660:     	cmp	x11, x10
101567664:     	ccmp	x12, x14, #0x0, eq
101567668:     	ccmp	x13, x15, #0x0, eq
10156766c:     	cset	w10, ne
101567670:     	cbnz	x9, 0x101567694 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
101567674:     	cbnz	w10, 0x101567694 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
101567678:     	ldr	x9, [x0, #0x490]
10156767c:     	ldr	w10, [x9, #0x2f0]
101567680:     	cbnz	w10, 0x101567694 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
101567684:     	ldr	w10, [x9, #0x2e8]
101567688:     	cbnz	w10, 0x101567694 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
10156768c:     	ldrb	w10, [x9, #0x338]
101567690:     	tbz	w10, #0x0, 0x101568150 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x146c>
101567694:     	str	wzr, [x8]
101567698:     	mov	w9, #0xc                ; =12
10156769c:     	strb	w9, [x8, #0x8]
1015676a0:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015676a4:     	add	x9, x9, #0x631
1015676a8:     	mov	w10, #0x2e              ; =46
1015676ac:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015676b0:     	str	wzr, [x8]
1015676b4:     	mov	w9, #0xc                ; =12
1015676b8:     	adrp	x10, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015676bc:     	add	x10, x10, #0x485
1015676c0:     	stp	x9, x10, [x8, #0x8]
1015676c4:     	mov	w9, #0x14               ; =20
1015676c8:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015676cc:     	str	wzr, [x8]
1015676d0:     	mov	w9, #0xc                ; =12
1015676d4:     	strb	w9, [x8, #0x8]
1015676d8:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015676dc:     	add	x9, x9, #0x44f
1015676e0:     	mov	w10, #0x36              ; =54
1015676e4:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015676e8:     	str	wzr, [x8]
1015676ec:     	mov	w9, #0xc                ; =12
1015676f0:     	strb	w9, [x8, #0x8]
1015676f4:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015676f8:     	add	x9, x9, #0x56f
1015676fc:     	mov	w10, #0x26              ; =38
101567700:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101567704:     	ldr	x8, [x26, #0x300]
101567708:     	ldr	x9, [x26, #0x308]
10156770c:     	adds	x8, x8, x22
101567710:     	b.hs	0x10156879c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab8>
101567714:     	cmp	x8, x9
101567718:     	b.ls	0x101567a44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd60>
10156771c:     	mov	x12, x23
101567720:     	mov	w11, #0x0               ; =0
101567724:     	mov	w10, #0x0               ; =0
101567728:     	mov	w13, #0x6               ; =6
10156772c:     	b	0x101567880 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
101567730:     	ldr	x10, [x0, #0x490]
101567734:     	ldr	x10, [x10, #0x3c0]
101567738:     	cbz	x10, 0x1015678a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
10156773c:     	ldr	x11, [x10, #0x40]
101567740:     	cmp	x11, #0x2
101567744:     	b.eq	0x1015678a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
101567748:     	ldr	x11, [x10, #0xd8]
10156774c:     	cmp	x11, x9
101567750:     	b.ne	0x1015678a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
101567754:     	ldr	x11, [x23, x22]
101567758:     	ldr	x12, [x10, #0x78]
10156775c:     	cmp	x11, x12
101567760:     	b.hs	0x1015678a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
101567764:     	ldr	x10, [x10, #0x70]
101567768:     	mov	w12, #0x108             ; =264
10156776c:     	mul	x11, x11, x12
101567770:     	ldr	x10, [x10, x11]
101567774:     	cbnz	x10, 0x10156754c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x868>
101567778:     	add	x24, sp, #0x440
10156777c:     	stp	x9, x1, [sp, #0x48]
101567780:     	mov	x28, x8
101567784:     	ldr	x8, [x0, #0x4d0]
101567788:     	cbz	x8, 0x101567f44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1260>
10156778c:     	ldr	x10, [x21, #0xb8]
101567790:     	add	x9, x10, #0x2
101567794:     	ldr	x11, [x0, #0x4d8]
101567798:     	cmp	x9, x11
10156779c:     	b.hs	0x101567f44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1260>
1015677a0:     	str	x0, [sp, #0x58]
1015677a4:     	add	x10, x10, #0x3
1015677a8:     	cmp	x10, x11
1015677ac:     	b.hs	0x101567f44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1260>
1015677b0:     	ldr	x9, [x8, x9, lsl #3]
1015677b4:     	ldr	x8, [x8, x10, lsl #3]
1015677b8:     	stp	x9, x8, [sp, #0x38]
1015677bc:     	ldr	q0, [x3]
1015677c0:     	str	q0, [sp, #0x440]
1015677c4:     	mov	w8, #0x5                ; =5
1015677c8:     	str	x8, [sp, #0x450]
1015677cc:     	add	x0, sp, #0x550
1015677d0:     	add	x3, sp, #0x440
1015677d4:     	ldp	x2, x1, [sp, #0x50]
1015677d8:     	bl	0x1015594a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
1015677dc:     	ldr	w8, [sp, #0x550]
1015677e0:     	cmp	w8, #0x6
1015677e4:     	b.ne	0x101568440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x175c>
1015677e8:     	ldr	x1, [x19, #0x380]
1015677ec:     	ldr	x8, [sp, #0x50]
1015677f0:     	cmp	x8, x1
1015677f4:     	b.hs	0x10156a340 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x365c>
1015677f8:     	ldr	x9, [x19, #0x378]
1015677fc:     	mov	w10, #0x170             ; =368
101567800:     	ldr	x8, [sp, #0x50]
101567804:     	madd	x8, x8, x10, x9
101567808:     	ldp	x8, x9, [x8]
10156780c:     	cmp	x8, #0x2
101567810:     	sbcs	xzr, x9, xzr
101567814:     	b.hs	0x101568578 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1894>
101567818:     	ldr	x1, [x19, #0x408]
10156781c:     	ldr	x8, [sp, #0x50]
101567820:     	cmp	x8, x1
101567824:     	b.hs	0x10156a350 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x366c>
101567828:     	ldr	x9, [x19, #0x400]
10156782c:     	ldr	x8, [sp, #0x50]
101567830:     	add	x9, x9, x8, lsl #9
101567834:     	str	x9, [sp, #0x30]
101567838:     	ldp	x9, x8, [x9]
10156783c:     	eor	x9, x9, #0x2
101567840:     	orr	x8, x9, x8
101567844:     	cbnz	x8, 0x1015685d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18f4>
101567848:     	str	wzr, [x28]
10156784c:     	mov	w8, #0xc                ; =12
101567850:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101567854:     	add	x9, x9, #0xb0f
101567858:     	stp	x8, x9, [x28, #0x8]
10156785c:     	mov	w8, #0x23               ; =35
101567860:     	str	x8, [x28, #0x18]
101567864:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101567868:     	mov	x10, x9
10156786c:     	lsr	x11, x9, #32
101567870:     	ldur	q0, [x27, #0x18]
101567874:     	stur	q0, [x29, #-0x70]
101567878:     	mov	w13, #0x7               ; =7
10156787c:     	mov	x9, x14
101567880:     	str	wzr, [x12]
101567884:     	strb	w13, [x12, #0x8]
101567888:     	stp	x8, x9, [x12, #0x10]
10156788c:     	stp	w10, w11, [x12, #0x20]
101567890:     	ldur	q0, [x29, #-0x70]
101567894:     	stur	q0, [x12, #0x28]
101567898:     	str	wzr, [x12, #0x38]
10156789c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015678a0:     	str	wzr, [x8]
1015678a4:     	mov	w9, #0xc                ; =12
1015678a8:     	adrp	x10, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015678ac:     	add	x10, x10, #0x234
1015678b0:     	stp	x9, x10, [x8, #0x8]
1015678b4:     	mov	w9, #0x2b               ; =43
1015678b8:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015678bc:     	sub	x10, x22, #0x1b
1015678c0:     	cmp	x10, #0x2
1015678c4:     	b.hs	0x101567bcc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xee8>
1015678c8:     	ldp	x5, x6, [x3, #0x8]
1015678cc:     	ldr	x4, [x3]
1015678d0:     	mov	x0, x8
1015678d4:     	mov	x1, x25
1015678d8:     	mov	x2, x20
1015678dc:     	mov	x3, x19
1015678e0:     	add	sp, sp, #0x810
1015678e4:     	ldp	x29, x30, [sp, #0x50]
1015678e8:     	ldp	x20, x19, [sp, #0x40]
1015678ec:     	ldp	x22, x21, [sp, #0x30]
1015678f0:     	ldp	x24, x23, [sp, #0x20]
1015678f4:     	ldp	x26, x25, [sp, #0x10]
1015678f8:     	ldp	x28, x27, [sp], #0x60
1015678fc:     	b	0x1015648c0 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation17frozen_map_helper>
101567900:     	cbnz	x10, 0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
101567904:     	ldr	x12, [x0, #0x490]
101567908:     	ldr	w10, [x12, #0x2f0]
10156790c:     	cmp	w10, #0x1
101567910:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
101567914:     	ldr	w10, [x12, #0x2f4]
101567918:     	cmp	w10, w9
10156791c:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
101567920:     	ldr	w9, [x12, #0x2e8]
101567924:     	cmp	w9, #0x1
101567928:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
10156792c:     	ldr	w9, [x11, #0x30]
101567930:     	ldr	w10, [x12, #0x2ec]
101567934:     	cmp	w10, w9
101567938:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
10156793c:     	stp	x14, x12, [sp, #0x38]
101567940:     	stp	x8, x1, [sp, #0x48]
101567944:     	mov	w8, #0x1                ; =1
101567948:     	orr	x8, x8, x9, lsl #1
10156794c:     	str	x0, [sp, #0x58]
101567950:     	ldr	x1, [x0, #0x4b8]
101567954:     	cmp	x8, x1
101567958:     	b.hs	0x10156a2bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35d8>
10156795c:     	ldr	x9, [sp, #0x58]
101567960:     	ldr	x9, [x9, #0x4b0]
101567964:     	ldr	x8, [x9, x8, lsl #3]
101567968:     	cmp	x8, #0x1
10156796c:     	ldp	x9, x8, [sp, #0x40]
101567970:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
101567974:     	add	x0, x9, #0x3b8
101567978:     	bl	0x1023697a8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
10156797c:     	ldp	x9, x8, [sp, #0x40]
101567980:     	cmp	x0, x26
101567984:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
101567988:     	cmp	x1, x19
10156798c:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
101567990:     	add	x8, sp, #0x550
101567994:     	add	x0, x9, #0x3b8
101567998:     	bl	0x102368c08 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
10156799c:     	ldr	x8, [sp, #0x48]
1015679a0:     	ldr	x9, [sp, #0x550]
1015679a4:     	cmp	x9, #0x1
1015679a8:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015679ac:     	ldr	x9, [sp, #0x558]
1015679b0:     	cmp	x9, x22
1015679b4:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015679b8:     	ldr	x9, [sp, #0x560]
1015679bc:     	cmp	x9, x25
1015679c0:     	b.ne	0x1015679f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015679c4:     	cbz	x20, 0x1015687f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b0c>
1015679c8:     	cmp	x20, #0x2
1015679cc:     	b.eq	0x1015687b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ad0>
1015679d0:     	cmp	x20, #0x3
1015679d4:     	b.ne	0x1015687d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015679d8:     	cbnz	x28, 0x1015687d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015679dc:     	ldp	x1, x2, [x23, #0x8]
1015679e0:     	ldr	x0, [sp, #0x50]
1015679e4:     	bl	0x101579c70 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
1015679e8:     	tbnz	w0, #0x0, 0x1015687c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ae4>
1015679ec:     	b	0x1015687d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015679f0:     	str	wzr, [x8]
1015679f4:     	mov	w9, #0xc                ; =12
1015679f8:     	strb	w9, [x8, #0x8]
1015679fc:     	adrp	x9, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101567a00:     	add	x9, x9, #0xdbe
101567a04:     	mov	w10, #0x3e              ; =62
101567a08:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101567a0c:     	str	wzr, [x8]
101567a10:     	mov	w9, #0xc                ; =12
101567a14:     	adrp	x10, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567a18:     	add	x10, x10, #0x5b6
101567a1c:     	stp	x9, x10, [x8, #0x8]
101567a20:     	mov	w9, #0x13               ; =19
101567a24:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101567a28:     	str	wzr, [x8]
101567a2c:     	mov	w9, #0xc                ; =12
101567a30:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101567a34:     	add	x10, x10, #0xc57
101567a38:     	stp	x9, x10, [x8, #0x8]
101567a3c:     	mov	w9, #0x19               ; =25
101567a40:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101567a44:     	mov	x0, x20
101567a48:     	mov	x1, x19
101567a4c:     	mov	x10, x25
101567a50:     	str	x8, [x26, #0x300]
101567a54:     	add	x8, sp, #0x550
101567a58:     	cmn	x10, #0xd
101567a5c:     	b.ne	0x101567a7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd98>
101567a60:     	bl	0x10156f860 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation17check_prefix_exit>
101567a64:     	ldr	w8, [sp, #0x550]
101567a68:     	cmp	w8, #0x6
101567a6c:     	b.ne	0x101567ab0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdcc>
101567a70:     	mov	x8, x23
101567a74:     	mov	x9, x25
101567a78:     	b	0x101567ad4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdf0>
101567a7c:     	bl	0x10156f9c4 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation19check_prefix_header>
101567a80:     	ldr	w8, [sp, #0x550]
101567a84:     	cmp	w8, #0x6
101567a88:     	b.ne	0x101567ab0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdcc>
101567a8c:     	mov	x9, x25
101567a90:     	cmn	x25, #0xa
101567a94:     	mov	x8, x23
101567a98:     	b.ne	0x101567ad4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdf0>
101567a9c:     	mov	x1, x20
101567aa0:     	ldr	x10, [x20, #0xa8]
101567aa4:     	mov	x3, x21
101567aa8:     	cbnz	x10, 0x101567b7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe98>
101567aac:     	b	0x101567af8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe14>
101567ab0:     	ldr	q0, [sp, #0x570]
101567ab4:     	ldr	q1, [sp, #0x580]
101567ab8:     	stp	q0, q1, [x23, #0x20]
101567abc:     	ldr	q0, [sp, #0x590]
101567ac0:     	str	q0, [x23, #0x40]
101567ac4:     	ldr	q0, [sp, #0x560]
101567ac8:     	ldr	q1, [sp, #0x550]
101567acc:     	stp	q1, q0, [x23]
101567ad0:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101567ad4:     	mov	x3, x21
101567ad8:     	ldp	x10, x11, [x21]
101567adc:     	ldr	x12, [x21, #0x10]
101567ae0:     	orr	x10, x10, x11
101567ae4:     	mov	x1, x20
101567ae8:     	ldr	x11, [x20, #0xa8]
101567aec:     	orr	x11, x12, x11
101567af0:     	orr	x10, x10, x11
101567af4:     	cbnz	x10, 0x101567b7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe98>
101567af8:     	ldr	x10, [x1, #0x290]
101567afc:     	cmp	x10, #0x6
101567b00:     	b.ne	0x101567b7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe98>
101567b04:     	ldr	x10, [x1, #0x498]
101567b08:     	ldr	x11, [x10]
101567b0c:     	cmp	x11, #0x2
101567b10:     	b.eq	0x101568aa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dbc>
101567b14:     	add	x25, x1, #0x238
101567b18:     	ldr	x11, [x25]
101567b1c:     	cmp	x11, #0x3
101567b20:     	b.eq	0x101568aac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dc8>
101567b24:     	ldr	x22, [x10, #0x138]
101567b28:     	ldr	w11, [x1, #0x280]
101567b2c:     	cmn	x9, #0xc
101567b30:     	b.gt	0x101567cb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd4>
101567b34:     	cmn	x9, #0xd
101567b38:     	b.eq	0x101567de0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10fc>
101567b3c:     	cmn	x9, #0xc
101567b40:     	b.ne	0x101567dc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10e0>
101567b44:     	mov	x9, x19
101567b48:     	cmp	w11, w9
101567b4c:     	b.ne	0x101567b60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe7c>
101567b50:     	ldrb	w11, [x1, #0x288]
101567b54:     	tbz	w11, #0x0, 0x101567b60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe7c>
101567b58:     	ldrb	w11, [x1, #0x289]
101567b5c:     	tbz	w11, #0x0, 0x101567f84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12a0>
101567b60:     	str	wzr, [x8]
101567b64:     	mov	w9, #0xc                ; =12
101567b68:     	strb	w9, [x8, #0x8]
101567b6c:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567b70:     	add	x9, x9, #0x961
101567b74:     	mov	w10, #0x29              ; =41
101567b78:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101567b7c:     	str	wzr, [x8]
101567b80:     	mov	w9, #0xc                ; =12
101567b84:     	strb	w9, [x8, #0x8]
101567b88:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567b8c:     	add	x9, x9, #0x9a6
101567b90:     	mov	w10, #0x24              ; =36
101567b94:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101567b98:     	cmp	x22, #0xa
101567b9c:     	b.ne	0x101567c1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf38>
101567ba0:     	mov	x0, x8
101567ba4:     	mov	x1, x25
101567ba8:     	mov	x2, x20
101567bac:     	add	sp, sp, #0x810
101567bb0:     	ldp	x29, x30, [sp, #0x50]
101567bb4:     	ldp	x20, x19, [sp, #0x40]
101567bb8:     	ldp	x22, x21, [sp, #0x30]
101567bbc:     	ldp	x24, x23, [sp, #0x20]
101567bc0:     	ldp	x26, x25, [sp, #0x10]
101567bc4:     	ldp	x28, x27, [sp], #0x60
101567bc8:     	b	0x101559ae8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation17begin_closed_tail>
101567bcc:     	cmp	x22, #0x1e
101567bd0:     	b.ne	0x101567c1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf38>
101567bd4:     	mov	x0, x8
101567bd8:     	mov	x1, x25
101567bdc:     	mov	x2, x20
101567be0:     	add	sp, sp, #0x810
101567be4:     	ldp	x29, x30, [sp, #0x50]
101567be8:     	ldp	x20, x19, [sp, #0x40]
101567bec:     	ldp	x22, x21, [sp, #0x30]
101567bf0:     	ldp	x24, x23, [sp, #0x20]
101567bf4:     	ldp	x26, x25, [sp, #0x10]
101567bf8:     	ldp	x28, x27, [sp], #0x60
101567bfc:     	b	0x10155685c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB4_10Invocation21begin_numeric_segment>
101567c00:     	str	wzr, [x8]
101567c04:     	mov	w9, #0xc                ; =12
101567c08:     	strb	w9, [x8, #0x8]
101567c0c:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567c10:     	add	x9, x9, #0x5c9
101567c14:     	mov	w10, #0x18              ; =24
101567c18:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101567c1c:     	mov	x24, x3
101567c20:     	mov	x19, x8
101567c24:     	mov	x0, x9
101567c28:     	mov	x1, x23
101567c2c:     	mov	x2, x20
101567c30:     	bl	0x101564b14 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation20frozen_native_action>
101567c34:     	tbnz	w0, #0x0, 0x101567c98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
101567c38:     	mov	x8, x25
101567c3c:     	ldr	x25, [x25, #0x490]
101567c40:     	str	x8, [sp, #0x58]
101567c44:     	ldr	x26, [x8, #0x498]
101567c48:     	mov	x0, x25
101567c4c:     	mov	x1, x26
101567c50:     	mov	x2, x20
101567c54:     	bl	0x101578ef4 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
101567c58:     	tbnz	w0, #0x0, 0x101567c98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
101567c5c:     	mov	x0, x25
101567c60:     	mov	x1, x26
101567c64:     	mov	x2, x20
101567c68:     	bl	0x101578e24 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
101567c6c:     	tbnz	w0, #0x0, 0x101567c98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
101567c70:     	mov	x0, x25
101567c74:     	mov	x1, x26
101567c78:     	mov	x2, x20
101567c7c:     	bl	0x101578e8c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_exit>
101567c80:     	tbnz	w0, #0x0, 0x101567c98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
101567c84:     	mov	x0, x25
101567c88:     	mov	x1, x26
101567c8c:     	mov	x2, x20
101567c90:     	bl	0x1015621a8 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
101567c94:     	tbz	w0, #0x0, 0x1015681bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14d8>
101567c98:     	str	wzr, [x19]
101567c9c:     	mov	w8, #0xc                ; =12
101567ca0:     	strb	w8, [x19, #0x8]
101567ca4:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567ca8:     	add	x8, x8, #0x1f9
101567cac:     	mov	w9, #0x2b               ; =43
101567cb0:     	stp	x8, x9, [x19, #0x10]
101567cb4:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101567cb8:     	cmn	x9, #0xb
101567cbc:     	b.eq	0x101567e88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11a4>
101567cc0:     	cmn	x9, #0xa
101567cc4:     	b.ne	0x101567dc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10e0>
101567cc8:     	ldrb	w21, [x1, #0x284]
101567ccc:     	ldr	x2, [x1, #0x278]
101567cd0:     	mov	x8, x1
101567cd4:     	add	x0, sp, #0x550
101567cd8:     	mov	x1, x3
101567cdc:     	add	x3, x8, #0x250
101567ce0:     	bl	0x101574f2c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB4_9Retention7checked>
101567ce4:     	ldr	w8, [sp, #0x550]
101567ce8:     	cmp	w8, #0x6
101567cec:     	b.ne	0x101567f0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1228>
101567cf0:     	ldr	x8, [sp, #0x568]
101567cf4:     	ldur	q0, [x27, #0x8]
101567cf8:     	str	q0, [sp, #0x220]
101567cfc:     	str	x8, [sp, #0x230]
101567d00:     	tbnz	w21, #0x0, 0x101567f64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
101567d04:     	mov	x8, x20
101567d08:     	ldr	x9, [x20, #0xc0]
101567d0c:     	cmp	x9, #0x2
101567d10:     	b.ne	0x101567f64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
101567d14:     	ldr	x9, [x8, #0x220]
101567d18:     	cmp	x9, #0x2
101567d1c:     	b.eq	0x101567f64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
101567d20:     	ldr	x9, [x8, #0x1d8]
101567d24:     	cmp	x9, x22
101567d28:     	b.ne	0x101567f64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
101567d2c:     	ldr	x21, [x8, #0x4d8]
101567d30:     	mov	x8, #-0x41              ; =-65
101567d34:     	movk	x8, #0xfff, lsl #48
101567d38:     	cmp	x21, x8
101567d3c:     	b.hi	0x1015693dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26f8>
101567d40:     	ldr	x8, [x20, #0x490]
101567d44:     	lsl	x9, x21, #4
101567d48:     	add	x0, sp, #0x550
101567d4c:     	add	x1, x8, #0x2f8
101567d50:     	add	x2, x9, #0x400
101567d54:     	bl	0x10154e858 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101567d58:     	ldrb	w8, [sp, #0x550]
101567d5c:     	cmp	w8, #0xe
101567d60:     	b.ne	0x1015680f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1414>
101567d64:     	cbz	x21, 0x101567d78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1094>
101567d68:     	ldr	x0, [x20, #0x4d0]
101567d6c:     	cbz	x0, 0x101568490 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17ac>
101567d70:     	lsl	x1, x21, #3
101567d74:     	bl	0x103a03d14 <dyld_stub_binder+0x103a03d14>
101567d78:     	add	x0, x20, #0x1d8
101567d7c:     	bl	0x10154b9b0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
101567d80:     	mov	w8, #0x2                ; =2
101567d84:     	str	x8, [x20, #0x220]
101567d88:     	ldr	x8, [x20, #0x238]
101567d8c:     	cmp	x8, #0x3
101567d90:     	b.eq	0x101569ccc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fe8>
101567d94:     	ldr	q0, [sp, #0x220]
101567d98:     	str	q0, [x25]
101567d9c:     	ldr	x8, [sp, #0x230]
101567da0:     	str	x8, [x25, #0x10]
101567da4:     	ldr	x8, [x25]
101567da8:     	cmp	x8, #0x3
101567dac:     	b.eq	0x101569cd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ff4>
101567db0:     	mov	w8, #0x1                ; =1
101567db4:     	str	w8, [x20, #0x268]
101567db8:     	str	w19, [x20, #0x26c]
101567dbc:     	str	xzr, [x23, #0x8]
101567dc0:     	b	0x1015680b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d4>
101567dc4:     	str	wzr, [x8]
101567dc8:     	mov	w9, #0xc                ; =12
101567dcc:     	strb	w9, [x8, #0x8]
101567dd0:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567dd4:     	add	x9, x9, #0x98a
101567dd8:     	mov	w10, #0x1c              ; =28
101567ddc:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101567de0:     	ldr	w9, [x1, #0x270]
101567de4:     	cbnz	w9, 0x101567ed8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
101567de8:     	ldr	x9, [x1, #0xc0]
101567dec:     	cmp	x9, #0x2
101567df0:     	b.ne	0x101567ed8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
101567df4:     	ldr	x9, [x1, #0x220]
101567df8:     	cmp	x9, #0x2
101567dfc:     	b.eq	0x101567ed8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
101567e00:     	ldr	x9, [x1, #0x1d8]
101567e04:     	cmp	x9, x22
101567e08:     	b.ne	0x101567ed8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
101567e0c:     	ldr	x21, [x1, #0x4d8]
101567e10:     	mov	x8, #-0x41              ; =-65
101567e14:     	movk	x8, #0xfff, lsl #48
101567e18:     	cmp	x21, x8
101567e1c:     	b.hi	0x1015693dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26f8>
101567e20:     	ldr	x8, [x20, #0x490]
101567e24:     	lsl	x9, x21, #4
101567e28:     	add	x0, sp, #0x550
101567e2c:     	add	x1, x8, #0x2f8
101567e30:     	add	x2, x9, #0x400
101567e34:     	bl	0x10154e858 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101567e38:     	ldrb	w8, [sp, #0x550]
101567e3c:     	cmp	w8, #0xe
101567e40:     	b.ne	0x1015680f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1414>
101567e44:     	cbz	x21, 0x101567e58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1174>
101567e48:     	ldr	x0, [x20, #0x4d0]
101567e4c:     	cbz	x0, 0x101568490 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17ac>
101567e50:     	lsl	x1, x21, #3
101567e54:     	bl	0x103a03d14 <dyld_stub_binder+0x103a03d14>
101567e58:     	add	x0, x20, #0x1d8
101567e5c:     	bl	0x10154b9b0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
101567e60:     	mov	w8, #0x2                ; =2
101567e64:     	str	x8, [x20, #0x220]
101567e68:     	ldr	x8, [x20, #0x238]
101567e6c:     	cmp	x8, #0x3
101567e70:     	b.eq	0x101569c04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f20>
101567e74:     	mov	w8, #0x1                ; =1
101567e78:     	str	w8, [x20, #0x270]
101567e7c:     	str	w19, [x20, #0x274]
101567e80:     	str	xzr, [x23, #0x8]
101567e84:     	b	0x1015680b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d4>
101567e88:     	cmp	w11, w19
101567e8c:     	b.ne	0x101567ef4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1210>
101567e90:     	ldrb	w9, [x1, #0x288]
101567e94:     	tbnz	w9, #0x0, 0x101567ef4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1210>
101567e98:     	ldrb	w9, [x1, #0x289]
101567e9c:     	tbnz	w9, #0x0, 0x101567ef4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1210>
101567ea0:     	add	x0, sp, #0x550
101567ea4:     	mov	x2, x19
101567ea8:     	mov	x4, x22
101567eac:     	bl	0x10155c3c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23prepare_borrowed_region>
101567eb0:     	ldr	w8, [sp, #0x550]
101567eb4:     	cmp	w8, #0x6
101567eb8:     	b.ne	0x1015680c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13e0>
101567ebc:     	ldr	x8, [x25]
101567ec0:     	cmp	x8, #0x3
101567ec4:     	b.eq	0x101569964 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c80>
101567ec8:     	ldur	q0, [x27, #0x8]
101567ecc:     	mov	w8, #0x1                ; =1
101567ed0:     	strb	w8, [x20, #0x288]
101567ed4:     	b	0x1015680b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d0>
101567ed8:     	str	wzr, [x8]
101567edc:     	mov	w9, #0xc                ; =12
101567ee0:     	strb	w9, [x8, #0x8]
101567ee4:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567ee8:     	add	x9, x9, #0x8d2
101567eec:     	mov	w10, #0x2f              ; =47
101567ef0:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101567ef4:     	str	wzr, [x8]
101567ef8:     	mov	w9, #0xc                ; =12
101567efc:     	strb	w9, [x8, #0x8]
101567f00:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567f04:     	add	x9, x9, #0x933
101567f08:     	b	0x1015676a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
101567f0c:     	ldr	q0, [sp, #0x560]
101567f10:     	ldr	q1, [sp, #0x570]
101567f14:     	stur	q0, [x24, #0xc]
101567f18:     	ldur	q0, [x27, #0x4]
101567f1c:     	str	q0, [sp, #0x440]
101567f20:     	ldr	q0, [sp, #0x580]
101567f24:     	ldr	q2, [sp, #0x590]
101567f28:     	stp	q0, q2, [x23, #0x30]
101567f2c:     	ldr	q0, [sp, #0x440]
101567f30:     	stur	q0, [x23, #0x4]
101567f34:     	ldur	q0, [x24, #0xc]
101567f38:     	stp	q0, q1, [x23, #0x10]
101567f3c:     	str	w8, [x23]
101567f40:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101567f44:     	str	wzr, [x28]
101567f48:     	mov	w8, #0xc                ; =12
101567f4c:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101567f50:     	add	x9, x9, #0xd29
101567f54:     	stp	x8, x9, [x28, #0x8]
101567f58:     	mov	w8, #0x30               ; =48
101567f5c:     	str	x8, [x28, #0x18]
101567f60:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101567f64:     	str	wzr, [x23]
101567f68:     	mov	w8, #0xc                ; =12
101567f6c:     	strb	w8, [x23, #0x8]
101567f70:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101567f74:     	add	x8, x8, #0x901
101567f78:     	mov	w9, #0x32               ; =50
101567f7c:     	stp	x8, x9, [x23, #0x10]
101567f80:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101567f84:     	ldr	x1, [x10, #0x270]
101567f88:     	cmp	x9, x1
101567f8c:     	b.hs	0x10156a2cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e8>
101567f90:     	ldr	x8, [x10, #0x268]
101567f94:     	add	x8, x8, x19, lsl #4
101567f98:     	ldr	w9, [x8]
101567f9c:     	tbz	w9, #0x0, 0x10156819c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b8>
101567fa0:     	ldr	x3, [x8, #0x8]
101567fa4:     	add	x0, sp, #0x550
101567fa8:     	mov	x1, x20
101567fac:     	mov	x2, x21
101567fb0:     	bl	0x101559b38 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation19begin_closed_region>
101567fb4:     	ldr	w8, [sp, #0x550]
101567fb8:     	cmp	w8, #0x6
101567fbc:     	b.ne	0x1015680c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13e0>
101567fc0:     	ldr	x8, [x25]
101567fc4:     	cmp	x8, #0x3
101567fc8:     	b.eq	0x101569c8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fa8>
101567fcc:     	ldur	q0, [x27, #0x8]
101567fd0:     	mov	w8, #0x1                ; =1
101567fd4:     	strb	w8, [x20, #0x289]
101567fd8:     	b	0x1015680b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d0>
101567fdc:     	mov	x21, x0
101567fe0:     	ldr	x9, [x0, #0x3d8]
101567fe4:     	cbz	x9, 0x1015682e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1604>
101567fe8:     	ldr	x10, [x21, #0x3d0]
101567fec:     	cmp	x10, x8
101567ff0:     	csel	x12, xzr, x8, lo
101567ff4:     	sub	x12, x10, x12
101567ff8:     	ldr	x11, [x21, #0x3c8]
101567ffc:     	mov	w14, #0x58              ; =88
101568000:     	madd	x12, x12, x14, x11
101568004:     	ldr	x14, [x12, #0x40]
101568008:     	cmp	x14, x13
10156800c:     	b.ne	0x101568180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
101568010:     	ldr	w13, [x20, #0x2e8]
101568014:     	cmp	w13, #0x1
101568018:     	b.ne	0x101568180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
10156801c:     	ldr	w13, [x22, #0x34]
101568020:     	ldr	w14, [x20, #0x2ec]
101568024:     	cmp	w14, w13
101568028:     	b.ne	0x101568180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
10156802c:     	lsl	x0, x13, #1
101568030:     	ldr	x1, [x21, #0x4b8]
101568034:     	cmp	x0, x1
101568038:     	b.hs	0x10156a3b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36d0>
10156803c:     	ldr	x13, [x12, #0x50]
101568040:     	ldr	x14, [x21, #0x4b0]
101568044:     	ldr	x14, [x14, x0, lsl #3]
101568048:     	subs	x13, x13, x14
10156804c:     	b.lo	0x101568180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
101568050:     	ldr	x14, [x12, #0x48]
101568054:     	cmp	x13, x14
101568058:     	b.ne	0x101568180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
10156805c:     	ldr	x23, [x21, #0x3f8]
101568060:     	ldr	x13, [x21, #0x3e8]
101568064:     	cmp	x13, x23
101568068:     	b.eq	0x101568090 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13ac>
10156806c:     	add	x24, x13, #0xc8
101568070:     	str	x24, [x21, #0x3e8]
101568074:     	ldr	x1, [x13]
101568078:     	ldp	w0, w17, [x13, #0x8]
10156807c:     	ldrb	w16, [x13, #0x10]
101568080:     	ldp	x15, x14, [x13, #0x18]
101568084:     	cbz	x1, 0x10156918c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24a8>
101568088:     	cmp	x1, #0x2
10156808c:     	b.ne	0x101569290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25ac>
101568090:     	str	wzr, [x19]
101568094:     	mov	w8, #0xc                ; =12
101568098:     	strb	w8, [x19, #0x8]
10156809c:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015680a0:     	add	x8, x8, #0x4b6
1015680a4:     	mov	w9, #0x16               ; =22
1015680a8:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015680ac:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
1015680b0:     	ldr	q0, [x8]
1015680b4:     	stur	q0, [x23, #0x8]
1015680b8:     	mov	w8, #0x6                ; =6
1015680bc:     	str	w8, [x23]
1015680c0:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015680c4:     	ldr	w9, [sp, #0x554]
1015680c8:     	ldur	q0, [x27, #0x18]
1015680cc:     	stur	q0, [x23, #0x18]
1015680d0:     	ldur	q0, [x27, #0x28]
1015680d4:     	stur	q0, [x23, #0x28]
1015680d8:     	ldur	q0, [x27, #0x38]
1015680dc:     	stur	q0, [x23, #0x38]
1015680e0:     	ldr	x10, [sp, #0x598]
1015680e4:     	str	x10, [x23, #0x48]
1015680e8:     	ldur	q0, [x27, #0x8]
1015680ec:     	stp	w8, w9, [x23]
1015680f0:     	stur	q0, [x23, #0x8]
1015680f4:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015680f8:     	ldr	q0, [sp, #0x550]
1015680fc:     	ldr	q1, [sp, #0x560]
101568100:     	str	q0, [sp, #0x440]
101568104:     	str	q1, [sp, #0x450]
101568108:     	ldr	q2, [sp, #0x570]
10156810c:     	str	q2, [sp, #0x460]
101568110:     	ldr	x8, [sp, #0x580]
101568114:     	str	x8, [sp, #0x470]
101568118:     	stur	q0, [x27, #0x4]
10156811c:     	stur	q1, [x27, #0x14]
101568120:     	stur	q2, [x27, #0x24]
101568124:     	stur	x8, [x27, #0x34]
101568128:     	str	wzr, [x23]
10156812c:     	ldr	q0, [sp, #0x550]
101568130:     	ldr	q1, [sp, #0x560]
101568134:     	stur	q0, [x23, #0x4]
101568138:     	stur	q1, [x23, #0x14]
10156813c:     	ldr	q0, [sp, #0x570]
101568140:     	stur	q0, [x23, #0x24]
101568144:     	ldur	q0, [x27, #0x2c]
101568148:     	str	q0, [x23, #0x30]
10156814c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568150:     	mov	x19, x8
101568154:     	add	x0, sp, #0x550
101568158:     	add	x1, x9, #0x2f8
10156815c:     	mov	w2, #0x100              ; =256
101568160:     	bl	0x10154e858 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101568164:     	ldrb	w8, [sp, #0x550]
101568168:     	cmp	w8, #0xe
10156816c:     	b.ne	0x101568308 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1624>
101568170:     	str	xzr, [x19, #0x8]
101568174:     	mov	w8, #0x6                ; =6
101568178:     	str	w8, [x19]
10156817c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568180:     	str	wzr, [x19]
101568184:     	mov	w8, #0xc                ; =12
101568188:     	strb	w8, [x19, #0x8]
10156818c:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101568190:     	add	x8, x8, #0x53c
101568194:     	mov	w9, #0x33               ; =51
101568198:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
10156819c:     	str	wzr, [x23]
1015681a0:     	mov	w8, #0xc                ; =12
1015681a4:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
1015681a8:     	add	x9, x9, #0xec2
1015681ac:     	stp	x8, x9, [x23, #0x8]
1015681b0:     	mov	w8, #0x26               ; =38
1015681b4:     	str	x8, [x23, #0x18]
1015681b8:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015681bc:     	cmp	x22, #0x9
1015681c0:     	b.eq	0x10156851c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1838>
1015681c4:     	cmp	x22, #0x8
1015681c8:     	b.ne	0x10156854c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1868>
1015681cc:     	mov	x0, x19
1015681d0:     	ldr	x1, [sp, #0x58]
1015681d4:     	mov	x2, x20
1015681d8:     	mov	x3, x24
1015681dc:     	add	sp, sp, #0x810
1015681e0:     	ldp	x29, x30, [sp, #0x50]
1015681e4:     	ldp	x20, x19, [sp, #0x40]
1015681e8:     	ldp	x22, x21, [sp, #0x30]
1015681ec:     	ldp	x24, x23, [sp, #0x20]
1015681f0:     	ldp	x26, x25, [sp, #0x10]
1015681f4:     	ldp	x28, x27, [sp], #0x60
1015681f8:     	b	0x10155d540 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation24prepare_borrowed_strings>
1015681fc:     	mov	x10, #0x0               ; =0
101568200:     	lsr	x11, x9, #1
101568204:     	add	x12, x11, x10
101568208:     	ldr	w13, [x8, x12, lsl #2]
10156820c:     	cmp	w13, w19
101568210:     	csel	x10, x10, x12, hi
101568214:     	sub	x9, x9, x11
101568218:     	cmp	x9, #0x1
10156821c:     	b.hi	0x101568200 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x151c>
101568220:     	ldr	w8, [x8, x10, lsl #2]
101568224:     	cmp	w8, w19
101568228:     	mov	x8, x22
10156822c:     	b.ne	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
101568230:     	ldr	x1, [x23, #0x380]
101568234:     	cmp	x1, x19
101568238:     	b.ls	0x10156a330 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
10156823c:     	ldr	x8, [x23, #0x378]
101568240:     	mov	w9, #0x170              ; =368
101568244:     	umaddl	x8, w19, w9, x8
101568248:     	add	x9, x8, #0x15c
10156824c:     	ldr	w8, [x8, #0x16c]
101568250:     	str	w8, [sp, #0x560]
101568254:     	ldr	q0, [x9]
101568258:     	str	q0, [sp, #0x550]
10156825c:     	add	x8, sp, #0x440
101568260:     	add	x0, sp, #0x550
101568264:     	bl	0x102a7db00 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
101568268:     	ldr	w8, [sp, #0x440]
10156826c:     	cmp	w8, #0x1
101568270:     	b.ne	0x101568280 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x159c>
101568274:     	ldr	w8, [sp, #0x444]
101568278:     	cmp	w8, w26
10156827c:     	b.eq	0x101568298 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15b4>
101568280:     	ldr	w8, [sp, #0x448]
101568284:     	cmp	w8, #0x1
101568288:     	b.ne	0x1015685b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d4>
10156828c:     	ldr	w8, [sp, #0x44c]
101568290:     	cmp	w8, w26
101568294:     	b.ne	0x1015685b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d4>
101568298:     	mov	x0, x20
10156829c:     	mov	x1, x19
1015682a0:     	bl	0x1015650cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
1015682a4:     	cbz	w0, 0x1015684ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c8>
1015682a8:     	ldrb	w8, [x21, #0x460]
1015682ac:     	cmp	w8, #0x1
1015682b0:     	mov	x8, x22
1015682b4:     	b.ne	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015682b8:     	mov	x9, x20
1015682bc:     	ldr	x10, [x20, #0xc0]
1015682c0:     	cmp	x10, #0x2
1015682c4:     	b.eq	0x1015684c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17dc>
1015682c8:     	b	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015682cc:     	str	wzr, [x8]
1015682d0:     	mov	w9, #0xc                ; =12
1015682d4:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
1015682d8:     	add	x10, x10, #0x8b0
1015682dc:     	stp	x9, x10, [x8, #0x8]
1015682e0:     	mov	w9, #0x1a               ; =26
1015682e4:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015682e8:     	str	wzr, [x19]
1015682ec:     	mov	w8, #0xc                ; =12
1015682f0:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015682f4:     	add	x9, x9, #0x499
1015682f8:     	stp	x8, x9, [x19, #0x8]
1015682fc:     	mov	w8, #0x1d               ; =29
101568300:     	str	x8, [x19, #0x18]
101568304:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568308:     	ldr	q0, [sp, #0x550]
10156830c:     	ldr	q1, [sp, #0x560]
101568310:     	str	q0, [sp, #0x440]
101568314:     	str	q1, [sp, #0x450]
101568318:     	ldr	q2, [sp, #0x570]
10156831c:     	str	q2, [sp, #0x460]
101568320:     	ldr	x8, [sp, #0x580]
101568324:     	str	x8, [sp, #0x470]
101568328:     	stur	q0, [x27, #0x4]
10156832c:     	stur	q1, [x27, #0x14]
101568330:     	stur	q2, [x27, #0x24]
101568334:     	stur	x8, [x27, #0x34]
101568338:     	str	wzr, [x19]
10156833c:     	ldr	q0, [sp, #0x550]
101568340:     	ldr	q1, [sp, #0x560]
101568344:     	stur	q0, [x19, #0x4]
101568348:     	stur	q1, [x19, #0x14]
10156834c:     	ldr	q0, [sp, #0x570]
101568350:     	stur	q0, [x19, #0x24]
101568354:     	ldur	q0, [x27, #0x2c]
101568358:     	str	q0, [x19, #0x30]
10156835c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568360:     	ldr	x9, [sp, #0x58]
101568364:     	ldr	x9, [x9, #0x3d8]
101568368:     	cbz	x9, 0x101568598 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18b4>
10156836c:     	ldr	x9, [sp, #0x58]
101568370:     	ldr	x10, [x9, #0x3d0]
101568374:     	cmp	x10, x8
101568378:     	csel	x8, xzr, x8, lo
10156837c:     	sub	x8, x10, x8
101568380:     	ldr	x9, [x9, #0x3c8]
101568384:     	mov	w10, #0x58              ; =88
101568388:     	madd	x20, x8, x10, x9
10156838c:     	ldr	x8, [x20, #0x40]
101568390:     	cmp	x8, x19
101568394:     	b.ne	0x101568474 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1790>
101568398:     	ldr	x8, [x20, #0x48]
10156839c:     	cbnz	x8, 0x101568474 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1790>
1015683a0:     	ldr	x8, [x20, #0x50]
1015683a4:     	cmp	x8, x28
1015683a8:     	b.ne	0x101568474 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1790>
1015683ac:     	ldr	w1, [x22, #0x50]
1015683b0:     	add	x8, sp, #0x550
1015683b4:     	add	x0, x24, #0xf0
1015683b8:     	add	x2, x24, #0x2f8
1015683bc:     	bl	0x10156d704 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015683c0:     	ldur	q0, [x27, #0x8]
1015683c4:     	ldur	q1, [x27, #0x18]
1015683c8:     	stp	q0, q1, [sp, #0x3a0]
1015683cc:     	ldur	q0, [x27, #0x28]
1015683d0:     	str	q0, [sp, #0x3c0]
1015683d4:     	ldr	x8, [sp, #0x550]
1015683d8:     	ldr	x9, [sp, #0x588]
1015683dc:     	str	x9, [sp, #0x3d0]
1015683e0:     	cbz	x8, 0x101568b90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1eac>
1015683e4:     	ldp	q0, q1, [sp, #0x3a0]
1015683e8:     	add	x9, sp, #0x440
1015683ec:     	stur	q0, [x9, #0x8]
1015683f0:     	ldr	x10, [sp, #0x3d0]
1015683f4:     	ldr	q0, [sp, #0x3c0]
1015683f8:     	stur	q0, [x9, #0x28]
1015683fc:     	stur	q1, [x9, #0x18]
101568400:     	str	x10, [sp, #0x478]
101568404:     	str	x8, [sp, #0x440]
101568408:     	ldr	x8, [sp, #0x448]
10156840c:     	ldr	x9, [x20, #0x8]
101568410:     	ldr	x8, [x8, #0x10]
101568414:     	ldr	x9, [x9, #0x10]
101568418:     	cmp	x8, x9
10156841c:     	b.eq	0x101568d04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2020>
101568420:     	mov	w8, #0x0                ; =0
101568424:     	mov	w9, #0xc                ; =12
101568428:     	strb	w9, [x23, #0x8]
10156842c:     	mov	w9, #0x27               ; =39
101568430:     	str	x9, [x23, #0x18]
101568434:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101568438:     	add	x9, x9, #0x2c6
10156843c:     	b	0x101568d14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2030>
101568440:     	ldr	w9, [sp, #0x554]
101568444:     	ldur	q0, [x27, #0x18]
101568448:     	stur	q0, [x28, #0x18]
10156844c:     	ldur	q0, [x27, #0x28]
101568450:     	stur	q0, [x28, #0x28]
101568454:     	ldur	q0, [x27, #0x38]
101568458:     	stur	q0, [x28, #0x38]
10156845c:     	ldr	x10, [sp, #0x598]
101568460:     	str	x10, [x28, #0x48]
101568464:     	ldur	q0, [x27, #0x8]
101568468:     	stp	w8, w9, [x28]
10156846c:     	stur	q0, [x28, #0x8]
101568470:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568474:     	str	wzr, [x23]
101568478:     	mov	w8, #0xc                ; =12
10156847c:     	strb	w8, [x23, #0x8]
101568480:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101568484:     	add	x8, x8, #0x2ed
101568488:     	mov	w9, #0x36               ; =54
10156848c:     	b	0x101567f7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
101568490:     	str	wzr, [x23]
101568494:     	mov	w8, #0xc                ; =12
101568498:     	strb	w8, [x23, #0x8]
10156849c:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015684a0:     	add	x8, x8, #0xee6
1015684a4:     	mov	w9, #0x29               ; =41
1015684a8:     	b	0x101567f7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
1015684ac:     	mov	x9, x20
1015684b0:     	ldr	x8, [x20, #0xc0]
1015684b4:     	cmp	x8, #0x2
1015684b8:     	mov	x8, x22
1015684bc:     	b.ne	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015684c0:     	ldr	x9, [x9, #0x220]
1015684c4:     	cmp	x9, #0x2
1015684c8:     	b.ne	0x1015685bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015684cc:     	ldr	x8, [x23, #0x360]
1015684d0:     	ldr	w1, [x24, #0x4c]
1015684d4:     	cmp	x8, x1
1015684d8:     	b.ls	0x10156a3a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36bc>
1015684dc:     	ldr	x8, [x23, #0x358]
1015684e0:     	mov	w9, #0x140              ; =320
1015684e4:     	umaddl	x8, w1, w9, x8
1015684e8:     	ldrb	w9, [x8, #0x124]
1015684ec:     	ldr	x8, [x25]
1015684f0:     	cmp	w9, #0x7
1015684f4:     	b.ne	0x101568734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a50>
1015684f8:     	cbz	x8, 0x101568998 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cb4>
1015684fc:     	str	wzr, [x22]
101568500:     	mov	w8, #0xc                ; =12
101568504:     	strb	w8, [x22, #0x8]
101568508:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156850c:     	add	x8, x8, #0x5e1
101568510:     	mov	w9, #0x28               ; =40
101568514:     	stp	x8, x9, [x22, #0x10]
101568518:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156851c:     	mov	x0, x19
101568520:     	ldr	x1, [sp, #0x58]
101568524:     	mov	x2, x20
101568528:     	mov	x3, x24
10156852c:     	add	sp, sp, #0x810
101568530:     	ldp	x29, x30, [sp, #0x50]
101568534:     	ldp	x20, x19, [sp, #0x40]
101568538:     	ldp	x22, x21, [sp, #0x30]
10156853c:     	ldp	x24, x23, [sp, #0x20]
101568540:     	ldp	x26, x25, [sp, #0x10]
101568544:     	ldp	x28, x27, [sp], #0x60
101568548:     	b	0x10155b048 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23borrowed_string_failure>
10156854c:     	ldr	x0, [sp, #0x58]
101568550:     	mov	x1, x20
101568554:     	bl	0x10155af88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
101568558:     	cbz	x0, 0x1015686c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19e4>
10156855c:     	str	wzr, [x19]
101568560:     	mov	w8, #0xc                ; =12
101568564:     	strb	w8, [x19, #0x8]
101568568:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156856c:     	add	x8, x8, #0xbc
101568570:     	mov	w9, #0x2e               ; =46
101568574:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
101568578:     	str	wzr, [x28]
10156857c:     	mov	w8, #0xc                ; =12
101568580:     	strb	w8, [x28, #0x8]
101568584:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101568588:     	add	x8, x8, #0xaba
10156858c:     	mov	w9, #0x23               ; =35
101568590:     	stp	x8, x9, [x28, #0x10]
101568594:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568598:     	str	wzr, [x23]
10156859c:     	mov	w8, #0xc                ; =12
1015685a0:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
1015685a4:     	add	x9, x9, #0x8b4
1015685a8:     	stp	x8, x9, [x23, #0x8]
1015685ac:     	mov	w8, #0x14               ; =20
1015685b0:     	str	x8, [x23, #0x18]
1015685b4:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015685b8:     	mov	x8, x22
1015685bc:     	str	wzr, [x8]
1015685c0:     	mov	w9, #0xc                ; =12
1015685c4:     	strb	w9, [x8, #0x8]
1015685c8:     	adrp	x9, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015685cc:     	add	x9, x9, #0x609
1015685d0:     	mov	w10, #0x28              ; =40
1015685d4:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015685d8:     	ldr	x8, [sp, #0x58]
1015685dc:     	ldr	x8, [x8, #0x490]
1015685e0:     	add	x0, sp, #0x550
1015685e4:     	add	x1, x8, #0x2f8
1015685e8:     	mov	w2, #0x40               ; =64
1015685ec:     	bl	0x10154e858 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015685f0:     	ldrb	w8, [sp, #0x550]
1015685f4:     	cmp	w8, #0xe
1015685f8:     	b.ne	0x10156886c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b88>
1015685fc:     	ldr	x0, [x23, x22]
101568600:     	ldr	x8, [x21, #0x40]
101568604:     	str	x8, [sp, #0x28]
101568608:     	cmp	x0, x8
10156860c:     	b.hs	0x10156a404 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3720>
101568610:     	ldr	x10, [x21, #0x38]
101568614:     	ldr	w3, [x21, #0xe0]
101568618:     	ldr	x8, [sp, #0x58]
10156861c:     	ldr	x8, [x8, #0x490]
101568620:     	mov	w9, #0x18               ; =24
101568624:     	mul	x9, x0, x9
101568628:     	str	x10, [sp, #0x20]
10156862c:     	ldr	x4, [x10, x9]
101568630:     	ldr	x1, [x8, #0x3c0]
101568634:     	add	x0, sp, #0x550
101568638:     	add	x2, x19, #0x488
10156863c:     	bl	0x10154fbcc <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames18take_managed_owner>
101568640:     	ldr	w8, [sp, #0x550]
101568644:     	cmp	w8, #0x6
101568648:     	b.ne	0x101568930 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c4c>
10156864c:     	ldur	q0, [x27, #0x28]
101568650:     	stur	q0, [x24, #0x24]
101568654:     	ldur	q1, [x27, #0x38]
101568658:     	ldur	q2, [x27, #0x18]
10156865c:     	ldur	q3, [x27, #0x8]
101568660:     	stp	q3, q2, [sp, #0x60]
101568664:     	stp	q0, q1, [sp, #0x80]
101568668:     	add	x24, sp, #0x550
10156866c:     	add	x8, sp, #0x550
101568670:     	ldr	x0, [sp, #0x58]
101568674:     	mov	w1, #0x0                ; =0
101568678:     	bl	0x101574b2c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10156867c:     	ldr	x8, [sp, #0x550]
101568680:     	cmp	x8, #0x1
101568684:     	b.ne	0x101568ab8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dd4>
101568688:     	ldur	q0, [x24, #0x18]
10156868c:     	ldur	q1, [x24, #0x28]
101568690:     	ldur	q2, [x24, #0x38]
101568694:     	str	q1, [sp, #0x460]
101568698:     	str	q2, [sp, #0x470]
10156869c:     	ldur	q3, [x24, #0x48]
1015686a0:     	str	q3, [sp, #0x480]
1015686a4:     	ldur	q4, [x24, #0x8]
1015686a8:     	str	q0, [sp, #0x450]
1015686ac:     	str	q4, [sp, #0x440]
1015686b0:     	stp	q1, q2, [x28, #0x20]
1015686b4:     	str	q3, [x28, #0x40]
1015686b8:     	stp	q4, q0, [x28]
1015686bc:     	add	x0, sp, #0x60
1015686c0:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015686c4:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015686c8:     	ldr	x8, [x23, #0x558]
1015686cc:     	cmp	x20, x8
1015686d0:     	b.hs	0x1015686ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a08>
1015686d4:     	ldr	x8, [x23, #0x550]
1015686d8:     	mov	w9, #0x28               ; =40
1015686dc:     	mul	x9, x20, x9
1015686e0:     	ldr	w8, [x8, x9]
1015686e4:     	cmp	w8, #0x5
1015686e8:     	b.ne	0x1015689e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d00>
1015686ec:     	cmp	x22, #0x6
1015686f0:     	b.gt	0x1015688e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c00>
1015686f4:     	cmp	x22, #0x4
1015686f8:     	b.eq	0x101568bc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ee0>
1015686fc:     	cmp	x22, #0x5
101568700:     	b.eq	0x101568c4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f68>
101568704:     	cmp	x22, #0x6
101568708:     	b.ne	0x101568c24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f40>
10156870c:     	ldr	q0, [x24]
101568710:     	str	q0, [sp, #0x550]
101568714:     	ldr	x8, [x24, #0x10]
101568718:     	str	x8, [sp, #0x560]
10156871c:     	add	x3, sp, #0x550
101568720:     	mov	x0, x19
101568724:     	ldr	x1, [sp, #0x58]
101568728:     	mov	x2, x20
10156872c:     	bl	0x10155f7ac <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation25prepare_string_map_region>
101568730:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568734:     	mov	x9, #0x0                ; =0
101568738:     	ldr	x10, [x21, #0x330]
10156873c:     	ldr	x11, [x21, #0x3c8]
101568740:     	ldr	x12, [x21, #0x430]
101568744:     	ldp	q0, q1, [x21, #0x3d0]
101568748:     	ldp	q2, q3, [x21, #0x3f0]
10156874c:     	ldr	q4, [x21, #0x410]
101568750:     	ldr	q5, [x21, #0x420]
101568754:     	mov	w13, #0x1               ; =1
101568758:     	stp	x13, x9, [x20, #0xf8]
10156875c:     	str	x8, [x20, #0x108]
101568760:     	ldp	q6, q7, [sp, #0x60]
101568764:     	stp	q6, q7, [x20, #0x110]
101568768:     	ldr	q6, [sp, #0x80]
10156876c:     	str	q6, [x20, #0x130]
101568770:     	stp	x10, x11, [x20, #0x140]
101568774:     	stp	q0, q1, [x20, #0x150]
101568778:     	stp	q2, q3, [x20, #0x170]
10156877c:     	stp	q4, q5, [x20, #0x190]
101568780:     	str	x12, [x20, #0x1b0]
101568784:     	str	w19, [x20, #0x1b8]
101568788:     	dup.2d	v0, x13
10156878c:     	stur	q0, [x22, #0x8]
101568790:     	mov	w8, #0x6                ; =6
101568794:     	str	w8, [x22]
101568798:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156879c:     	mov	w11, #0x0               ; =0
1015687a0:     	mov	w10, #0x0               ; =0
1015687a4:     	mov	w13, #0x6               ; =6
1015687a8:     	mov	x8, #-0x1               ; =-1
1015687ac:     	mov	x12, x23
1015687b0:     	b	0x101567880 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
1015687b4:     	cbnz	x28, 0x1015687d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015687b8:     	ldp	x1, x2, [x23, #0x8]
1015687bc:     	ldr	x0, [sp, #0x50]
1015687c0:     	bl	0x101579c70 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
1015687c4:     	tbz	w0, #0x0, 0x1015687d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015687c8:     	mov	x8, #0x0                ; =0
1015687cc:     	b	0x10156882c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b48>
1015687d0:     	ldr	x8, [sp, #0x48]
1015687d4:     	str	wzr, [x8]
1015687d8:     	mov	w9, #0xc                ; =12
1015687dc:     	strb	w9, [x8, #0x8]
1015687e0:     	adrp	x9, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015687e4:     	add	x9, x9, #0xd86
1015687e8:     	mov	w10, #0x38              ; =56
1015687ec:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015687f0:     	ldr	x9, [x23, #0xa0]
1015687f4:     	cbz	x9, 0x1015688c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1be0>
1015687f8:     	ldr	x8, [x23, #0x98]
1015687fc:     	lsl	x9, x9, #5
101568800:     	b	0x101568810 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b2c>
101568804:     	add	x8, x8, #0x20
101568808:     	subs	x9, x9, #0x20
10156880c:     	b.eq	0x1015688c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1be0>
101568810:     	ldr	w11, [x8, #0x18]
101568814:     	ldr	x10, [sp, #0x50]
101568818:     	cmp	x10, x11
10156881c:     	b.ne	0x101568804 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b20>
101568820:     	ldr	w10, [x8, #0x1c]
101568824:     	cmp	x28, x10
101568828:     	b.ne	0x101568804 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b20>
10156882c:     	str	x8, [sp, #0x220]
101568830:     	ldr	x9, [sp, #0x40]
101568834:     	ldp	x8, x9, [x9, #0xd0]
101568838:     	lsl	x9, x9, #6
10156883c:     	cbz	x9, 0x101568a00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d1c>
101568840:     	ldr	x10, [x8], #0x40
101568844:     	sub	x9, x9, #0x40
101568848:     	cbz	x10, 0x10156883c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b58>
10156884c:     	ldr	x8, [sp, #0x48]
101568850:     	str	wzr, [x8]
101568854:     	mov	w9, #0xc                ; =12
101568858:     	strb	w9, [x8, #0x8]
10156885c:     	adrp	x9, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101568860:     	add	x9, x9, #0xd54
101568864:     	mov	w10, #0x32              ; =50
101568868:     	b	0x101566d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10156886c:     	ldr	q0, [sp, #0x550]
101568870:     	ldr	q1, [sp, #0x560]
101568874:     	str	q0, [sp, #0x440]
101568878:     	str	q1, [sp, #0x450]
10156887c:     	ldr	q2, [sp, #0x570]
101568880:     	str	q2, [sp, #0x460]
101568884:     	ldr	x8, [sp, #0x580]
101568888:     	str	x8, [sp, #0x470]
10156888c:     	stur	q0, [x27, #0x4]
101568890:     	stur	q1, [x27, #0x14]
101568894:     	stur	q2, [x27, #0x24]
101568898:     	stur	x8, [x27, #0x34]
10156889c:     	str	wzr, [x28]
1015688a0:     	ldr	q0, [sp, #0x550]
1015688a4:     	ldr	q1, [sp, #0x560]
1015688a8:     	stur	q0, [x28, #0x4]
1015688ac:     	stur	q1, [x28, #0x14]
1015688b0:     	ldr	q0, [sp, #0x570]
1015688b4:     	stur	q0, [x28, #0x24]
1015688b8:     	ldur	q0, [x27, #0x2c]
1015688bc:     	str	q0, [x28, #0x30]
1015688c0:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015688c4:     	ldr	x8, [sp, #0x48]
1015688c8:     	str	wzr, [x8]
1015688cc:     	mov	w9, #0xc                ; =12
1015688d0:     	adrp	x10, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
1015688d4:     	add	x10, x10, #0xcae
1015688d8:     	stp	x9, x10, [x8, #0x8]
1015688dc:     	mov	w9, #0x31               ; =49
1015688e0:     	b	0x101566fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015688e4:     	cmp	x22, #0x7
1015688e8:     	b.eq	0x101568bf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f10>
1015688ec:     	cmp	x22, #0x10
1015688f0:     	b.eq	0x101568c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f98>
1015688f4:     	cmp	x22, #0x11
1015688f8:     	b.ne	0x101568c24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f40>
1015688fc:     	ldp	x4, x5, [x24, #0x8]
101568900:     	ldr	x3, [x24]
101568904:     	mov	x0, x19
101568908:     	ldr	x1, [sp, #0x58]
10156890c:     	mov	x2, x20
101568910:     	add	sp, sp, #0x810
101568914:     	ldp	x29, x30, [sp, #0x50]
101568918:     	ldp	x20, x19, [sp, #0x40]
10156891c:     	ldp	x22, x21, [sp, #0x30]
101568920:     	ldp	x24, x23, [sp, #0x20]
101568924:     	ldp	x26, x25, [sp, #0x10]
101568928:     	ldp	x28, x27, [sp], #0x60
10156892c:     	b	0x101576b70 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation21finish_join_map_chunk>
101568930:     	ldur	q0, [x27, #0x14]
101568934:     	ldur	q1, [x27, #0x24]
101568938:     	ldur	q2, [x27, #0x34]
10156893c:     	str	q1, [sp, #0x460]
101568940:     	str	q2, [sp, #0x470]
101568944:     	ldr	w9, [sp, #0x594]
101568948:     	str	w9, [sp, #0x480]
10156894c:     	ldur	q3, [x27, #0x4]
101568950:     	str	q0, [sp, #0x450]
101568954:     	str	q3, [sp, #0x440]
101568958:     	ldr	x10, [sp, #0x598]
10156895c:     	stur	q0, [x28, #0x14]
101568960:     	stur	q1, [x28, #0x24]
101568964:     	stur	q2, [x28, #0x34]
101568968:     	str	w9, [x28, #0x44]
10156896c:     	stur	q3, [x28, #0x4]
101568970:     	str	w8, [x28]
101568974:     	str	x10, [x28, #0x48]
101568978:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156897c:     	str	wzr, [x23]
101568980:     	mov	w8, #0xc                ; =12
101568984:     	strb	w8, [x23, #0x8]
101568988:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156898c:     	add	x8, x8, #0x323
101568990:     	mov	w9, #0x24               ; =36
101568994:     	b	0x101567f7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
101568998:     	add	x8, sp, #0x550
10156899c:     	add	x0, x21, #0xf0
1015689a0:     	add	x2, x21, #0x2f8
1015689a4:     	bl	0x10156d704 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015689a8:     	ldr	x9, [sp, #0x550]
1015689ac:     	ldr	x8, [sp, #0x558]
1015689b0:     	ldr	q0, [sp, #0x560]
1015689b4:     	ldr	q1, [sp, #0x570]
1015689b8:     	str	q0, [sp, #0x440]
1015689bc:     	str	q1, [sp, #0x450]
1015689c0:     	ldr	q0, [sp, #0x580]
1015689c4:     	str	q0, [sp, #0x460]
1015689c8:     	cbz	x9, 0x101568cac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fc8>
1015689cc:     	ldr	q0, [sp, #0x440]
1015689d0:     	ldr	q1, [sp, #0x450]
1015689d4:     	stp	q0, q1, [sp, #0x60]
1015689d8:     	ldr	q0, [sp, #0x460]
1015689dc:     	str	q0, [sp, #0x80]
1015689e0:     	b	0x101568738 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a54>
1015689e4:     	str	wzr, [x19]
1015689e8:     	mov	w8, #0xc                ; =12
1015689ec:     	strb	w8, [x19, #0x8]
1015689f0:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015689f4:     	add	x8, x8, #0x1d5
1015689f8:     	mov	w9, #0x24               ; =36
1015689fc:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
101568a00:     	add	x8, sp, #0x220
101568a04:     	str	x8, [sp, #0x440]
101568a08:     	str	x24, [sp, #0x448]
101568a0c:     	ldr	x19, [sp, #0x58]
101568a10:     	str	x19, [sp, #0x450]
101568a14:     	ldr	x8, [sp, #0x38]
101568a18:     	str	x8, [sp, #0x458]
101568a1c:     	str	x21, [sp, #0x460]
101568a20:     	add	x0, sp, #0x550
101568a24:     	add	x1, sp, #0x440
101568a28:     	bl	0x10154da90 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB6_10Invocation19end_numeric_segments4_0Be_>
101568a2c:     	ldr	x8, [x19, #0x490]
101568a30:     	ldr	x2, [x8, #0xd8]
101568a34:     	ldr	x1, [x23, #0x40]
101568a38:     	cmp	x1, x2
101568a3c:     	b.hi	0x101569f7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3298>
101568a40:     	ldr	x0, [x8, #0xd0]
101568a44:     	str	xzr, [sp, #0x440]
101568a48:     	add	x2, sp, #0x440
101568a4c:     	bl	0x1014d2da0 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
101568a50:     	ldr	w8, [sp, #0x550]
101568a54:     	cmp	w8, #0x6
101568a58:     	b.ne	0x101568cd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fec>
101568a5c:     	ldr	x9, [sp, #0x58]
101568a60:     	ldr	x8, [x9, #0x490]
101568a64:     	str	wzr, [x8, #0x340]
101568a68:     	ldr	x10, [x9, #0x490]
101568a6c:     	mov	w8, #0x1                ; =1
101568a70:     	str	w8, [x10, #0x2f0]
101568a74:     	ldr	x8, [sp, #0x50]
101568a78:     	str	w8, [x10, #0x2f4]
101568a7c:     	ldr	x8, [x9, #0x490]
101568a80:     	cmp	x20, #0x2
101568a84:     	cset	w9, ne
101568a88:     	strb	w9, [x8, #0x460]
101568a8c:     	ldr	x8, [sp, #0x48]
101568a90:     	str	xzr, [x8, #0x8]
101568a94:     	mov	w9, #0x6                ; =6
101568a98:     	str	w9, [x8]
101568a9c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568aa0:     	adrp	x0, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101568aa4:     	add	x0, x0, #0x478
101568aa8:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101568aac:     	adrp	x0, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101568ab0:     	add	x0, x0, #0x490
101568ab4:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101568ab8:     	ldur	q0, [x24, #0x48]
101568abc:     	ldur	q1, [x24, #0x58]
101568ac0:     	str	q0, [sp, #0x480]
101568ac4:     	str	q1, [sp, #0x490]
101568ac8:     	ldur	x8, [x24, #0x68]
101568acc:     	str	x8, [sp, #0x4a0]
101568ad0:     	ldur	q2, [x24, #0x8]
101568ad4:     	ldur	q3, [x24, #0x18]
101568ad8:     	str	q2, [sp, #0x440]
101568adc:     	str	q3, [sp, #0x450]
101568ae0:     	ldur	q4, [x24, #0x38]
101568ae4:     	ldur	q5, [x24, #0x28]
101568ae8:     	stp	q2, q3, [sp, #0xa0]
101568aec:     	stp	q5, q4, [sp, #0xc0]
101568af0:     	str	x8, [sp, #0x100]
101568af4:     	stp	q0, q1, [sp, #0xe0]
101568af8:     	ldr	w8, [x23]
101568afc:     	cmp	w8, #0x6
101568b00:     	b.ne	0x101568d28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2044>
101568b04:     	ldp	q0, q1, [sp, #0x60]
101568b08:     	str	q0, [sp, #0x440]
101568b0c:     	str	q1, [sp, #0x450]
101568b10:     	ldp	q0, q1, [sp, #0x80]
101568b14:     	str	q0, [sp, #0x460]
101568b18:     	str	q1, [sp, #0x470]
101568b1c:     	ldr	x8, [sp, #0x58]
101568b20:     	ldp	q0, q1, [x8, #0x80]
101568b24:     	str	q0, [sp, #0x5d0]
101568b28:     	str	q1, [sp, #0x5e0]
101568b2c:     	ldr	x9, [x8, #0xa0]
101568b30:     	str	x9, [sp, #0x5f0]
101568b34:     	ldp	q0, q1, [x8, #0x40]
101568b38:     	str	q0, [sp, #0x590]
101568b3c:     	str	q1, [sp, #0x5a0]
101568b40:     	ldp	q1, q0, [x8, #0x60]
101568b44:     	str	q0, [sp, #0x5c0]
101568b48:     	str	q1, [sp, #0x5b0]
101568b4c:     	ldp	q0, q1, [x8]
101568b50:     	str	q0, [sp, #0x550]
101568b54:     	str	q1, [sp, #0x560]
101568b58:     	ldp	q1, q0, [x8, #0x20]
101568b5c:     	str	q0, [sp, #0x580]
101568b60:     	str	q1, [sp, #0x570]
101568b64:     	ldr	x9, [x8, #0x490]
101568b68:     	add	x8, sp, #0x110
101568b6c:     	add	x1, sp, #0x440
101568b70:     	add	x4, sp, #0x550
101568b74:     	add	x5, x9, #0x3b8
101568b78:     	add	x6, sp, #0xa0
101568b7c:     	ldr	x0, [sp, #0x30]
101568b80:     	ldr	x2, [sp, #0x40]
101568b84:     	mov	w3, #0x1                ; =1
101568b88:     	bl	0x1026a90a0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private>
101568b8c:     	b	0x101568db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x20cc>
101568b90:     	ldp	q0, q1, [sp, #0x3a0]
101568b94:     	stur	q0, [x27, #0x4]
101568b98:     	stur	q1, [x27, #0x14]
101568b9c:     	ldr	q0, [sp, #0x3c0]
101568ba0:     	stur	q0, [x27, #0x24]
101568ba4:     	ldr	x8, [sp, #0x3d0]
101568ba8:     	stur	x8, [x27, #0x34]
101568bac:     	ldr	q0, [sp, #0x550]
101568bb0:     	ldr	q1, [sp, #0x560]
101568bb4:     	stur	q0, [x23, #0x4]
101568bb8:     	mov	w8, #0x2                ; =2
101568bbc:     	str	w8, [x23]
101568bc0:     	b	0x101568138 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1454>
101568bc4:     	mov	x0, x19
101568bc8:     	ldr	x1, [sp, #0x58]
101568bcc:     	mov	x2, x20
101568bd0:     	mov	x3, x24
101568bd4:     	add	sp, sp, #0x810
101568bd8:     	ldp	x29, x30, [sp, #0x50]
101568bdc:     	ldp	x20, x19, [sp, #0x40]
101568be0:     	ldp	x22, x21, [sp, #0x30]
101568be4:     	ldp	x24, x23, [sp, #0x20]
101568be8:     	ldp	x26, x25, [sp, #0x10]
101568bec:     	ldp	x28, x27, [sp], #0x60
101568bf0:     	b	0x10155a76c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation21prepare_window_region>
101568bf4:     	mov	x0, x19
101568bf8:     	ldr	x1, [sp, #0x58]
101568bfc:     	mov	x2, x20
101568c00:     	mov	x3, x24
101568c04:     	add	sp, sp, #0x810
101568c08:     	ldp	x29, x30, [sp, #0x50]
101568c0c:     	ldp	x20, x19, [sp, #0x40]
101568c10:     	ldp	x22, x21, [sp, #0x30]
101568c14:     	ldp	x24, x23, [sp, #0x20]
101568c18:     	ldp	x26, x25, [sp, #0x10]
101568c1c:     	ldp	x28, x27, [sp], #0x60
101568c20:     	b	0x10155f404 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation24finish_string_map_region>
101568c24:     	ldr	x8, [sp, #0x58]
101568c28:     	ldr	x8, [x8, #0xa8]
101568c2c:     	cbz	x8, 0x101569378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2694>
101568c30:     	str	wzr, [x19]
101568c34:     	mov	w8, #0xc                ; =12
101568c38:     	strb	w8, [x19, #0x8]
101568c3c:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101568c40:     	add	x8, x8, #0xea
101568c44:     	mov	w9, #0x2d               ; =45
101568c48:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
101568c4c:     	mov	x0, x19
101568c50:     	ldr	x1, [sp, #0x58]
101568c54:     	mov	x2, x20
101568c58:     	mov	x3, x24
101568c5c:     	add	sp, sp, #0x810
101568c60:     	ldp	x29, x30, [sp, #0x50]
101568c64:     	ldp	x20, x19, [sp, #0x40]
101568c68:     	ldp	x22, x21, [sp, #0x30]
101568c6c:     	ldp	x24, x23, [sp, #0x20]
101568c70:     	ldp	x26, x25, [sp, #0x10]
101568c74:     	ldp	x28, x27, [sp], #0x60
101568c78:     	b	0x10155a170 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation20finish_window_region>
101568c7c:     	mov	x0, x19
101568c80:     	ldr	x1, [sp, #0x58]
101568c84:     	mov	x2, x20
101568c88:     	mov	x3, x24
101568c8c:     	add	sp, sp, #0x810
101568c90:     	ldp	x29, x30, [sp, #0x50]
101568c94:     	ldp	x20, x19, [sp, #0x40]
101568c98:     	ldp	x22, x21, [sp, #0x30]
101568c9c:     	ldp	x24, x23, [sp, #0x20]
101568ca0:     	ldp	x26, x25, [sp, #0x10]
101568ca4:     	ldp	x28, x27, [sp], #0x60
101568ca8:     	b	0x101576ed0 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation22prepare_join_map_chunk>
101568cac:     	ldr	q0, [sp, #0x440]
101568cb0:     	ldr	q1, [sp, #0x450]
101568cb4:     	stp	q0, q1, [x22, #0x10]
101568cb8:     	ldr	q0, [sp, #0x460]
101568cbc:     	str	q0, [x22, #0x30]
101568cc0:     	mov	w9, #0x2                ; =2
101568cc4:     	str	w9, [x22]
101568cc8:     	str	x8, [x22, #0x8]
101568ccc:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568cd0:     	ldur	q0, [x27, #0x14]
101568cd4:     	ldr	x9, [sp, #0x48]
101568cd8:     	stur	q0, [x9, #0x14]
101568cdc:     	ldur	q0, [x27, #0x24]
101568ce0:     	stur	q0, [x9, #0x24]
101568ce4:     	ldur	q0, [x27, #0x34]
101568ce8:     	stur	q0, [x9, #0x34]
101568cec:     	ldr	q0, [sp, #0x590]
101568cf0:     	str	q0, [x9, #0x40]
101568cf4:     	ldur	q0, [x27, #0x4]
101568cf8:     	stur	q0, [x9, #0x4]
101568cfc:     	str	w8, [x9]
101568d00:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568d04:     	mov	w8, #0x1                ; =1
101568d08:     	str	x8, [x23, #0x8]
101568d0c:     	mov	w8, #0x6                ; =6
101568d10:     	mov	w9, #0x2                ; =2
101568d14:     	str	x9, [x23, #0x10]
101568d18:     	str	w8, [x23]
101568d1c:     	add	x0, sp, #0x440
101568d20:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101568d24:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101568d28:     	ldp	q0, q1, [sp, #0x60]
101568d2c:     	str	q0, [sp, #0x440]
101568d30:     	str	q1, [sp, #0x450]
101568d34:     	ldp	q0, q1, [sp, #0x80]
101568d38:     	str	q0, [sp, #0x460]
101568d3c:     	str	q1, [sp, #0x470]
101568d40:     	ldr	x8, [sp, #0x58]
101568d44:     	ldp	q0, q1, [x8, #0x80]
101568d48:     	str	q0, [sp, #0x5d0]
101568d4c:     	str	q1, [sp, #0x5e0]
101568d50:     	ldr	x9, [x8, #0xa0]
101568d54:     	str	x9, [sp, #0x5f0]
101568d58:     	ldp	q0, q1, [x8, #0x40]
101568d5c:     	str	q0, [sp, #0x590]
101568d60:     	str	q1, [sp, #0x5a0]
101568d64:     	ldp	q1, q0, [x8, #0x60]
101568d68:     	str	q0, [sp, #0x5c0]
101568d6c:     	str	q1, [sp, #0x5b0]
101568d70:     	ldp	q0, q1, [x8]
101568d74:     	str	q0, [sp, #0x550]
101568d78:     	str	q1, [sp, #0x560]
101568d7c:     	ldp	q1, q0, [x8, #0x20]
101568d80:     	str	q0, [sp, #0x580]
101568d84:     	str	q1, [sp, #0x570]
101568d88:     	ldr	x9, [x8, #0x490]
101568d8c:     	add	x8, sp, #0x110
101568d90:     	add	x1, sp, #0x440
101568d94:     	add	x5, sp, #0x550
101568d98:     	add	x6, x9, #0x3b8
101568d9c:     	add	x7, sp, #0xa0
101568da0:     	ldp	x0, x2, [sp, #0x30]
101568da4:     	ldr	x3, [sp, #0x40]
101568da8:     	mov	w4, #0x1                ; =1
101568dac:     	bl	0x1026a8ab8 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private>
101568db0:     	ldr	x9, [sp, #0x110]
101568db4:     	add	x8, sp, #0x110
101568db8:     	cbz	x9, 0x1015692e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2600>
101568dbc:     	add	x10, sp, #0x110
101568dc0:     	ldur	q0, [x10, #0xc8]
101568dc4:     	stur	q0, [x25, #0xc8]
101568dc8:     	ldur	q0, [x10, #0xd8]
101568dcc:     	stur	q0, [x25, #0xd8]
101568dd0:     	ldur	q0, [x10, #0xe8]
101568dd4:     	stur	q0, [x25, #0xe8]
101568dd8:     	ldur	q0, [x10, #0xf8]
101568ddc:     	stur	q0, [x25, #0xf8]
101568de0:     	ldur	q0, [x10, #0x88]
101568de4:     	stur	q0, [x25, #0x88]
101568de8:     	ldur	q0, [x10, #0x98]
101568dec:     	stur	q0, [x25, #0x98]
101568df0:     	ldur	q0, [x10, #0xa8]
101568df4:     	stur	q0, [x25, #0xa8]
101568df8:     	ldur	q0, [x10, #0xb8]
101568dfc:     	stur	q0, [x25, #0xb8]
101568e00:     	ldur	q0, [x10, #0x58]
101568e04:     	stur	q0, [x25, #0x58]
101568e08:     	ldur	q0, [x10, #0x68]
101568e0c:     	stur	q0, [x25, #0x68]
101568e10:     	ldur	q0, [x10, #0x78]
101568e14:     	stur	q0, [x25, #0x78]
101568e18:     	ldur	q0, [x8, #0x18]
101568e1c:     	stur	q0, [x25, #0x18]
101568e20:     	ldur	q0, [x8, #0x28]
101568e24:     	stur	q0, [x25, #0x28]
101568e28:     	ldur	q0, [x8, #0x38]
101568e2c:     	stur	q0, [x25, #0x38]
101568e30:     	ldur	q0, [x8, #0x48]
101568e34:     	stur	q0, [x25, #0x48]
101568e38:     	ldur	q0, [x8, #0x8]
101568e3c:     	stur	q0, [x25, #0x8]
101568e40:     	str	x9, [sp, #0x220]
101568e44:     	ldr	x8, [sp, #0x58]
101568e48:     	ldr	x9, [x8, #0x490]
101568e4c:     	sub	x8, x29, #0xb0
101568e50:     	add	x0, x9, #0x3b8
101568e54:     	bl	0x102368ae4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
101568e58:     	ldr	x8, [x19, #0x5e8]
101568e5c:     	cmn	x8, #0x1, lsl #12       ; =0x1000
101568e60:     	b.hs	0x10156a214 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3530>
101568e64:     	add	x24, x8, #0x1, lsl #12  ; =0x1000
101568e68:     	lsr	x8, x24, #60
101568e6c:     	cbnz	x8, 0x10156a234 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3550>
101568e70:     	ldr	x8, [sp, #0x58]
101568e74:     	ldr	x8, [x8, #0x490]
101568e78:     	lsl	x2, x24, #4
101568e7c:     	mov	w19, #0x1               ; =1
101568e80:     	add	x0, sp, #0x550
101568e84:     	add	x1, x8, #0x2f8
101568e88:     	bl	0x10154e858 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101568e8c:     	ldrb	w8, [sp, #0x550]
101568e90:     	cmp	w8, #0xe
101568e94:     	b.ne	0x101569320 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x263c>
101568e98:     	add	x8, sp, #0x550
101568e9c:     	sub	x0, x29, #0xb0
101568ea0:     	mov	x1, x24
101568ea4:     	bl	0x102e34ea4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101568ea8:     	ldr	w8, [sp, #0x550]
101568eac:     	cmp	w8, #0x1a
101568eb0:     	b.ne	0x101569530 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x284c>
101568eb4:     	ldur	q0, [x27, #0x18]
101568eb8:     	ldur	q1, [x27, #0x8]
101568ebc:     	stp	q1, q0, [x29, #-0x90]
101568ec0:     	ldr	x1, [x23, x22]
101568ec4:     	ldr	x8, [sp, #0x28]
101568ec8:     	cmp	x1, x8
101568ecc:     	b.hs	0x10156aa10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d2c>
101568ed0:     	mov	w8, #0x18               ; =24
101568ed4:     	ldr	x9, [sp, #0x20]
101568ed8:     	madd	x8, x1, x8, x9
101568edc:     	ldrb	w8, [x8, #0x12]
101568ee0:     	tbz	w8, #0x0, 0x101569098 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x23b4>
101568ee4:     	ldr	x8, [sp, #0x58]
101568ee8:     	ldr	x8, [x8, #0x490]
101568eec:     	ldr	x8, [x8, #0x3c0]
101568ef0:     	cbz	x8, 0x1015695f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2910>
101568ef4:     	ldr	x9, [x8, #0x40]
101568ef8:     	cmp	x9, #0x2
101568efc:     	b.eq	0x1015695f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2910>
101568f00:     	ldr	x10, [x8, #0xd8]
101568f04:     	ldr	x9, [sp, #0x48]
101568f08:     	cmp	x10, x9
101568f0c:     	b.ne	0x1015695f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2910>
101568f10:     	ldr	x9, [x8, #0x80]
101568f14:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101568f18:     	cmp	x9, x10
101568f1c:     	b.eq	0x1015695f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2910>
101568f20:     	ldr	x9, [x8, #0x90]
101568f24:     	cmp	x1, x9
101568f28:     	b.hs	0x1015695f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2910>
101568f2c:     	ldr	x8, [x8, #0x88]
101568f30:     	mov	w9, #0x70               ; =112
101568f34:     	madd	x8, x1, x9, x8
101568f38:     	ldr	x11, [x8]
101568f3c:     	ldr	d0, [x8, #0x8]
101568f40:     	ldrb	w12, [x8, #0x10]
101568f44:     	ldp	x9, x10, [x8, #0x18]
101568f48:     	str	xzr, [x8]
101568f4c:     	cbz	x11, 0x101569f90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32ac>
101568f50:     	ldur	q1, [x8, #0x58]
101568f54:     	stur	q1, [x26, #0x58]
101568f58:     	ldr	x13, [x8, #0x68]
101568f5c:     	str	x13, [sp, #0x398]
101568f60:     	str	x11, [sp, #0x330]
101568f64:     	str	d0, [sp, #0x338]
101568f68:     	strb	w12, [sp, #0x340]
101568f6c:     	ldur	w11, [x8, #0x11]
101568f70:     	stur	w11, [x26, #0x11]
101568f74:     	ldr	w11, [x8, #0x14]
101568f78:     	str	w11, [sp, #0x344]
101568f7c:     	str	x9, [sp, #0x348]
101568f80:     	str	x10, [sp, #0x350]
101568f84:     	ldur	q0, [x8, #0x28]
101568f88:     	stur	q0, [x26, #0x28]
101568f8c:     	ldur	q0, [x8, #0x38]
101568f90:     	stur	q0, [x26, #0x38]
101568f94:     	ldur	q0, [x8, #0x48]
101568f98:     	stur	q0, [x26, #0x48]
101568f9c:     	add	x0, sp, #0x550
101568fa0:     	add	x1, sp, #0x220
101568fa4:     	mov	w2, #0x108              ; =264
101568fa8:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
101568fac:     	mov	w19, #0x0               ; =0
101568fb0:     	add	x24, sp, #0x440
101568fb4:     	add	x8, sp, #0x440
101568fb8:     	add	x0, sp, #0x550
101568fbc:     	add	x1, sp, #0x330
101568fc0:     	bl	0x102d5de74 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix23with_append_preparation>
101568fc4:     	ldr	x8, [sp, #0x440]
101568fc8:     	cbz	x8, 0x10156a098 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33b4>
101568fcc:     	add	x9, sp, #0x220
101568fd0:     	ldr	w10, [sp, #0x448]
101568fd4:     	add	x11, sp, #0x440
101568fd8:     	ldur	q0, [x11, #0x1c]
101568fdc:     	ldur	q1, [x11, #0x2c]
101568fe0:     	ldur	q2, [x11, #0x3c]
101568fe4:     	str	q1, [sp, #0x410]
101568fe8:     	str	q2, [sp, #0x420]
101568fec:     	ldur	q1, [x11, #0x48]
101568ff0:     	stur	q1, [x26, #0xfc]
101568ff4:     	ldur	q1, [x11, #0xc]
101568ff8:     	stp	q1, q0, [sp, #0x3f0]
101568ffc:     	ldur	q0, [x11, #0xc8]
101569000:     	stur	q0, [x9, #0xc8]
101569004:     	ldur	q0, [x11, #0xd8]
101569008:     	stur	q0, [x9, #0xd8]
10156900c:     	ldur	q0, [x11, #0xe8]
101569010:     	stur	q0, [x9, #0xe8]
101569014:     	ldur	q0, [x11, #0xf8]
101569018:     	stur	q0, [x9, #0xf8]
10156901c:     	ldur	q0, [x11, #0x88]
101569020:     	stur	q0, [x9, #0x88]
101569024:     	ldur	q0, [x11, #0x98]
101569028:     	stur	q0, [x9, #0x98]
10156902c:     	ldur	q0, [x11, #0xa8]
101569030:     	stur	q0, [x9, #0xa8]
101569034:     	ldur	q0, [x11, #0xb8]
101569038:     	stur	q0, [x9, #0xb8]
10156903c:     	ldur	q0, [x11, #0x58]
101569040:     	stur	q0, [x9, #0x58]
101569044:     	ldur	q0, [x11, #0x68]
101569048:     	stur	q0, [x9, #0x68]
10156904c:     	ldur	q0, [x11, #0x78]
101569050:     	stur	q0, [x9, #0x78]
101569054:     	ldur	q0, [x26, #0xfc]
101569058:     	stur	q0, [x26, #0xac]
10156905c:     	ldr	q0, [sp, #0x420]
101569060:     	ldr	q1, [sp, #0x410]
101569064:     	stp	q1, q0, [sp, #0x3c0]
101569068:     	ldp	q2, q0, [sp, #0x3f0]
10156906c:     	stp	q2, q0, [sp, #0x3a0]
101569070:     	stur	q0, [x25, #0x1c]
101569074:     	stur	q1, [x25, #0x2c]
101569078:     	stur	q2, [x25, #0xc]
10156907c:     	ldr	q0, [sp, #0x3d0]
101569080:     	stur	q0, [x25, #0x3c]
101569084:     	ldur	q0, [x26, #0xac]
101569088:     	stur	q0, [x25, #0x48]
10156908c:     	str	x8, [sp, #0x220]
101569090:     	str	w10, [sp, #0x228]
101569094:     	ldr	x1, [x23, x22]
101569098:     	mov	w19, #0x1               ; =1
10156909c:     	mov	x0, x20
1015690a0:     	bl	0x1015bfecc <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare16readonly_numericNtB2_5Proof8capacity>
1015690a4:     	cmp	x0, #0x1
1015690a8:     	b.ne	0x10156971c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a38>
1015690ac:     	mov	x20, x1
1015690b0:     	add	x8, sp, #0x550
1015690b4:     	add	x0, sp, #0x220
1015690b8:     	bl	0x102d5dd5c <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix20reserved_native_view>
1015690bc:     	ldr	w8, [sp, #0x550]
1015690c0:     	tbz	w8, #0x0, 0x101569c2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f48>
1015690c4:     	ldr	x8, [sp, #0x58]
1015690c8:     	ldr	x10, [x8, #0x4d0]
1015690cc:     	cbz	x10, 0x101569eb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31d4>
1015690d0:     	ldr	x8, [x23, x22]
1015690d4:     	ldr	x9, [x21, #0xb0]
1015690d8:     	add	x8, x9, x8, lsl #2
1015690dc:     	add	x11, x8, #0x3
1015690e0:     	ldr	x8, [sp, #0x58]
1015690e4:     	ldr	x8, [x8, #0x4d8]
1015690e8:     	cmp	x11, x8
1015690ec:     	b.hs	0x101569eb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31d4>
1015690f0:     	ldr	x19, [sp, #0x558]
1015690f4:     	ldr	x9, [sp, #0x560]
1015690f8:     	ldr	x8, [sp, #0x568]
1015690fc:     	str	x9, [x10, x11, lsl #3]
101569100:     	ldr	x10, [sp, #0x58]
101569104:     	ldr	x10, [x10, #0x4d0]
101569108:     	cbz	x10, 0x101569df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x310c>
10156910c:     	ldr	x11, [x23, x22]
101569110:     	ldr	x12, [x21, #0xb0]
101569114:     	add	x11, x12, x11, lsl #2
101569118:     	add	x11, x11, #0x4
10156911c:     	ldr	x12, [sp, #0x58]
101569120:     	ldr	x12, [x12, #0x4d8]
101569124:     	cmp	x11, x12
101569128:     	b.hs	0x101569df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x310c>
10156912c:     	mov	w12, #0x1               ; =1
101569130:     	str	x12, [x10, x11, lsl #3]
101569134:     	ldr	x10, [sp, #0x58]
101569138:     	ldr	x10, [x10, #0x4d0]
10156913c:     	cbz	x10, 0x101569df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x310c>
101569140:     	ldr	x11, [x23, x22]
101569144:     	ldr	x12, [x21, #0xb0]
101569148:     	add	x11, x12, x11, lsl #2
10156914c:     	add	x11, x11, #0x5
101569150:     	ldr	x12, [sp, #0x58]
101569154:     	ldr	x12, [x12, #0x4d8]
101569158:     	cmp	x11, x12
10156915c:     	b.hs	0x101569df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x310c>
101569160:     	str	x9, [x10, x11, lsl #3]
101569164:     	ldr	x9, [sp, #0x58]
101569168:     	ldr	x9, [x9, #0x4d0]
10156916c:     	cbz	x9, 0x101569df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x310c>
101569170:     	add	x10, x20, #0x2
101569174:     	ldr	x11, [sp, #0x58]
101569178:     	ldr	x11, [x11, #0x4d8]
10156917c:     	cmp	x10, x11
101569180:     	b.hs	0x101569df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x310c>
101569184:     	str	x8, [x9, x10, lsl #3]
101569188:     	b	0x10156972c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a48>
10156918c:     	ldur	w1, [x13, #0x11]
101569190:     	stur	w1, [x27, #0x9]
101569194:     	ldur	w1, [x13, #0x14]
101569198:     	str	w1, [sp, #0x55c]
10156919c:     	str	w0, [sp, #0x550]
1015691a0:     	str	w17, [sp, #0x554]
1015691a4:     	strb	w16, [sp, #0x558]
1015691a8:     	str	x15, [sp, #0x560]
1015691ac:     	str	x14, [sp, #0x568]
1015691b0:     	ldur	q0, [x13, #0x28]
1015691b4:     	ldur	q1, [x13, #0x38]
1015691b8:     	str	q1, [sp, #0x580]
1015691bc:     	str	q0, [sp, #0x570]
1015691c0:     	ldur	q0, [x13, #0x48]
1015691c4:     	ldur	q1, [x13, #0x58]
1015691c8:     	ldur	q2, [x13, #0x68]
1015691cc:     	ldur	q3, [x13, #0x78]
1015691d0:     	ldur	q4, [x13, #0x88]
1015691d4:     	ldur	q5, [x13, #0x98]
1015691d8:     	ldur	q6, [x13, #0xa8]
1015691dc:     	ldur	q7, [x13, #0xb8]
1015691e0:     	str	q7, [sp, #0x600]
1015691e4:     	str	q6, [sp, #0x5f0]
1015691e8:     	str	q5, [sp, #0x5e0]
1015691ec:     	str	q4, [sp, #0x5d0]
1015691f0:     	str	q3, [sp, #0x5c0]
1015691f4:     	str	q2, [sp, #0x5b0]
1015691f8:     	str	q0, [sp, #0x590]
1015691fc:     	str	q1, [sp, #0x5a0]
101569200:     	ldr	x13, [x12, #0x48]
101569204:     	cmn	x13, #0x1
101569208:     	b.eq	0x10156a274 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3590>
10156920c:     	add	x13, x13, #0x1
101569210:     	str	x13, [x12, #0x48]
101569214:     	ldr	x12, [x12, #0x50]
101569218:     	cmp	x13, x12
10156921c:     	b.ne	0x1015693b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26d4>
101569220:     	add	x12, x10, #0x1
101569224:     	cmp	x12, x8
101569228:     	csel	x8, xzr, x8, lo
10156922c:     	sub	x8, x12, x8
101569230:     	str	x8, [x21, #0x3d0]
101569234:     	sub	x28, x9, #0x1
101569238:     	str	x28, [x21, #0x3d8]
10156923c:     	mov	w8, #0x58               ; =88
101569240:     	madd	x8, x10, x8, x11
101569244:     	ldp	q1, q0, [x8]
101569248:     	str	q1, [sp, #0x440]
10156924c:     	str	q0, [sp, #0x450]
101569250:     	ldp	q1, q0, [x8, #0x30]
101569254:     	ldr	x9, [x8, #0x50]
101569258:     	ldr	q2, [x8, #0x20]
10156925c:     	str	x9, [sp, #0x490]
101569260:     	str	q0, [sp, #0x480]
101569264:     	str	q2, [sp, #0x460]
101569268:     	str	q1, [sp, #0x470]
10156926c:     	ldr	x8, [sp, #0x440]
101569270:     	cbz	x8, 0x101569280 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x259c>
101569274:     	mov	w27, #0x1               ; =1
101569278:     	add	x0, sp, #0x440
10156927c:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101569280:     	cmp	x28, #0x0
101569284:     	cset	w8, eq
101569288:     	str	w8, [sp, #0x58]
10156928c:     	b	0x1015693bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26d8>
101569290:     	ldur	w8, [x13, #0x11]
101569294:     	str	w8, [sp, #0xa0]
101569298:     	ldur	w8, [x13, #0x14]
10156929c:     	stur	w8, [sp, #0xa3]
1015692a0:     	ldur	q0, [x13, #0x28]
1015692a4:     	ldur	q1, [x13, #0x38]
1015692a8:     	stp	q0, q1, [sp, #0x110]
1015692ac:     	ldur	q0, [x13, #0x48]
1015692b0:     	str	q0, [sp, #0x330]
1015692b4:     	stp	w0, w17, [x19]
1015692b8:     	strb	w16, [x19, #0x8]
1015692bc:     	mov	w8, w8
1015692c0:     	str	w8, [x19, #0xc]
1015692c4:     	ldr	w8, [sp, #0xa0]
1015692c8:     	stur	w8, [x19, #0x9]
1015692cc:     	stp	x15, x14, [x19, #0x10]
1015692d0:     	ldp	q1, q0, [sp, #0x110]
1015692d4:     	stp	q1, q0, [x19, #0x20]
1015692d8:     	ldr	q0, [sp, #0x330]
1015692dc:     	str	q0, [x19, #0x40]
1015692e0:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015692e4:     	ldr	x1, [x19, #0x378]
1015692e8:     	ldr	x2, [x19, #0x380]
1015692ec:     	add	x0, sp, #0x550
1015692f0:     	add	x4, x8, #0x8
1015692f4:     	ldr	x3, [sp, #0x50]
1015692f8:     	bl	0x10154d8dc <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14numeric_writesNtB6_10Invocation21prepare_numeric_writes1_0Be_>
1015692fc:     	ldr	q0, [sp, #0x570]
101569300:     	ldr	q1, [sp, #0x580]
101569304:     	stp	q0, q1, [x28, #0x20]
101569308:     	ldr	q0, [sp, #0x590]
10156930c:     	str	q0, [x28, #0x40]
101569310:     	ldr	q0, [sp, #0x560]
101569314:     	ldr	q1, [sp, #0x550]
101569318:     	stp	q1, q0, [x28]
10156931c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569320:     	ldr	q0, [sp, #0x550]
101569324:     	ldr	q1, [sp, #0x560]
101569328:     	str	q0, [sp, #0x440]
10156932c:     	str	q1, [sp, #0x450]
101569330:     	ldr	q2, [sp, #0x570]
101569334:     	str	q2, [sp, #0x460]
101569338:     	ldr	x8, [sp, #0x580]
10156933c:     	str	x8, [sp, #0x470]
101569340:     	stur	q0, [x27, #0x4]
101569344:     	stur	q1, [x27, #0x14]
101569348:     	stur	q2, [x27, #0x24]
10156934c:     	stur	x8, [x27, #0x34]
101569350:     	str	wzr, [x28]
101569354:     	ldr	q0, [sp, #0x550]
101569358:     	ldr	q1, [sp, #0x560]
10156935c:     	stur	q0, [x28, #0x4]
101569360:     	stur	q1, [x28, #0x14]
101569364:     	ldr	q0, [sp, #0x570]
101569368:     	stur	q0, [x28, #0x24]
10156936c:     	ldur	q0, [x27, #0x2c]
101569370:     	str	q0, [x28, #0x30]
101569374:     	b	0x10156956c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2888>
101569378:     	cmp	x22, #0x1
10156937c:     	b.gt	0x101569590 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28ac>
101569380:     	cbz	x22, 0x101569610 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x292c>
101569384:     	cmp	x22, #0x1
101569388:     	b.ne	0x101569684 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29a0>
10156938c:     	ldr	x8, [sp, #0x58]
101569390:     	ldr	x8, [x8, #0x490]
101569394:     	ldrb	w8, [x8, #0x460]
101569398:     	tbz	w8, #0x0, 0x101569970 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c8c>
10156939c:     	str	wzr, [x19]
1015693a0:     	mov	w8, #0xc                ; =12
1015693a4:     	strb	w8, [x19, #0x8]
1015693a8:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015693ac:     	add	x8, x8, #0x132
1015693b0:     	mov	w9, #0x16               ; =22
1015693b4:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015693b8:     	str	wzr, [sp, #0x58]
1015693bc:     	ldr	x9, [x22, #0x18]
1015693c0:     	cbz	x9, 0x101569500 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
1015693c4:     	ldr	w0, [sp, #0x608]
1015693c8:     	ldr	x8, [x22, #0x10]
1015693cc:     	cmp	x9, #0x1
1015693d0:     	b.ne	0x1015693fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2718>
1015693d4:     	mov	x10, #0x0               ; =0
1015693d8:     	b	0x101569420 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x273c>
1015693dc:     	str	wzr, [x23]
1015693e0:     	mov	w8, #0xc                ; =12
1015693e4:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
1015693e8:     	add	x9, x9, #0x8b0
1015693ec:     	stp	x8, x9, [x23, #0x8]
1015693f0:     	mov	w8, #0x1a               ; =26
1015693f4:     	str	x8, [x23, #0x18]
1015693f8:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015693fc:     	mov	x10, #0x0               ; =0
101569400:     	lsr	x11, x9, #1
101569404:     	add	x12, x11, x10
101569408:     	ldr	w13, [x8, x12, lsl #2]
10156940c:     	cmp	w13, w0
101569410:     	csel	x10, x10, x12, hi
101569414:     	sub	x9, x9, x11
101569418:     	cmp	x9, #0x1
10156941c:     	b.hi	0x101569400 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x271c>
101569420:     	ldr	w8, [x8, x10, lsl #2]
101569424:     	cmp	w8, w0
101569428:     	b.ne	0x101569500 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
10156942c:     	ldr	x1, [x26, #0x380]
101569430:     	cmp	x1, x0
101569434:     	b.ls	0x10156a9fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d18>
101569438:     	ldr	x8, [x26, #0x378]
10156943c:     	mov	w9, #0x170              ; =368
101569440:     	umaddl	x8, w0, w9, x8
101569444:     	add	x9, x8, #0x15c
101569448:     	ldr	w8, [x8, #0x16c]
10156944c:     	str	w8, [sp, #0x450]
101569450:     	ldr	q0, [x9]
101569454:     	str	q0, [sp, #0x440]
101569458:     	mov	w27, #0x1               ; =1
10156945c:     	add	x8, sp, #0x220
101569460:     	add	x0, sp, #0x440
101569464:     	bl	0x102a7db00 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
101569468:     	ldr	w8, [x22, #0x48]
10156946c:     	ldr	w9, [sp, #0x220]
101569470:     	cmp	w9, #0x1
101569474:     	b.ne	0x101569484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27a0>
101569478:     	ldr	w9, [sp, #0x224]
10156947c:     	cmp	w9, w8
101569480:     	b.eq	0x10156949c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27b8>
101569484:     	ldr	w9, [sp, #0x228]
101569488:     	cmp	w9, #0x1
10156948c:     	b.ne	0x101569500 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
101569490:     	ldr	w9, [sp, #0x22c]
101569494:     	cmp	w9, w8
101569498:     	b.ne	0x101569500 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
10156949c:     	ldr	x28, [sp, #0x550]
1015694a0:     	cmp	x28, #0x0
1015694a4:     	cset	w26, eq
1015694a8:     	cbz	x28, 0x1015696bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29d8>
1015694ac:     	ldr	q0, [sp, #0x550]
1015694b0:     	ldr	q1, [sp, #0x560]
1015694b4:     	str	q0, [sp, #0x440]
1015694b8:     	str	q1, [sp, #0x450]
1015694bc:     	ldr	q0, [sp, #0x570]
1015694c0:     	ldr	q1, [sp, #0x580]
1015694c4:     	str	q0, [sp, #0x460]
1015694c8:     	str	q1, [sp, #0x470]
1015694cc:     	ldr	w1, [x22, #0x4c]
1015694d0:     	add	x8, sp, #0x220
1015694d4:     	add	x0, x20, #0xf0
1015694d8:     	add	x2, sp, #0x440
1015694dc:     	add	x3, x20, #0x2f8
1015694e0:     	bl	0x10156f20c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015694e4:     	ldrb	w8, [sp, #0x220]
1015694e8:     	cmp	w8, #0x14
1015694ec:     	b.ne	0x101569860 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b7c>
1015694f0:     	mov	w27, #0x0               ; =0
1015694f4:     	add	x0, sp, #0x440
1015694f8:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015694fc:     	b	0x1015696d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29f0>
101569500:     	str	wzr, [x19]
101569504:     	mov	w9, #0xc                ; =12
101569508:     	strb	w9, [x19, #0x8]
10156950c:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101569510:     	add	x8, x8, #0x4cc
101569514:     	mov	w9, #0x2d               ; =45
101569518:     	stp	x8, x9, [x19, #0x10]
10156951c:     	ldr	x8, [sp, #0x550]
101569520:     	cbz	x8, 0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569524:     	add	x0, sp, #0x550
101569528:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10156952c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569530:     	ldur	q0, [x27, #0x4]
101569534:     	ldur	q1, [x27, #0x14]
101569538:     	str	q0, [sp, #0x440]
10156953c:     	str	q1, [sp, #0x450]
101569540:     	ldr	w9, [sp, #0x574]
101569544:     	str	w9, [sp, #0x460]
101569548:     	ldr	x10, [sp, #0x578]
10156954c:     	stur	q0, [x28, #0x14]
101569550:     	stur	q1, [x28, #0x24]
101569554:     	str	w9, [x28, #0x34]
101569558:     	str	wzr, [x28]
10156955c:     	mov	w9, #0xd                ; =13
101569560:     	strb	w9, [x28, #0x8]
101569564:     	str	w8, [x28, #0x10]
101569568:     	str	x10, [x28, #0x38]
10156956c:     	ldur	x8, [x29, #-0xb0]
101569570:     	mov	x9, #-0x1               ; =-1
101569574:     	ldaddl	x9, x8, [x8]
101569578:     	cmp	x8, #0x1
10156957c:     	b.ne	0x101569c74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f90>
101569580:     	dmb	ishld
101569584:     	sub	x0, x29, #0xb0
101569588:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10156958c:     	b	0x101569c74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f90>
101569590:     	cmp	x22, #0x2
101569594:     	b.eq	0x10156963c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2958>
101569598:     	cmp	x22, #0x12
10156959c:     	b.ne	0x101569684 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29a0>
1015695a0:     	ldr	x8, [sp, #0x58]
1015695a4:     	ldr	x8, [x8, #0x490]
1015695a8:     	ldrb	w8, [x8, #0x460]
1015695ac:     	tbnz	w8, #0x0, 0x1015695c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28e0>
1015695b0:     	ldp	x8, x9, [x24]
1015695b4:     	ldr	x10, [x24, #0x10]
1015695b8:     	orr	x8, x8, x9
1015695bc:     	orr	x8, x8, x10
1015695c0:     	cbz	x8, 0x101569d04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3020>
1015695c4:     	str	wzr, [x19]
1015695c8:     	mov	w8, #0xc                ; =12
1015695cc:     	strb	w8, [x19, #0x8]
1015695d0:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
1015695d4:     	add	x8, x8, #0x1a8
1015695d8:     	mov	w9, #0x2d               ; =45
1015695dc:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015695e0:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
1015695e4:     	add	x2, x2, #0x3c0
1015695e8:     	mov	x0, x9
1015695ec:     	mov	x1, x10
1015695f0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015695f4:     	str	wzr, [x28]
1015695f8:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015695fc:     	add	x8, x8, #0x44b
101569600:     	mov	w9, #0xc                ; =12
101569604:     	stp	x9, x8, [x28, #0x8]
101569608:     	mov	w8, #0x30               ; =48
10156960c:     	b	0x101569c44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f60>
101569610:     	ldr	x8, [sp, #0x58]
101569614:     	ldr	x8, [x8, #0x490]
101569618:     	ldrb	w8, [x8, #0x460]
10156961c:     	tbz	w8, #0x0, 0x101569aa4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dc0>
101569620:     	str	wzr, [x19]
101569624:     	mov	w8, #0xc                ; =12
101569628:     	strb	w8, [x19, #0x8]
10156962c:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101569630:     	add	x8, x8, #0x190
101569634:     	mov	w9, #0x18               ; =24
101569638:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
10156963c:     	ldr	x8, [sp, #0x58]
101569640:     	ldr	x8, [x8, #0x490]
101569644:     	ldrb	w8, [x8, #0x460]
101569648:     	tbnz	w8, #0x0, 0x101569be8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f04>
10156964c:     	ldr	x8, [x24, #0x10]
101569650:     	cbnz	x8, 0x101569be8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f04>
101569654:     	ldp	x3, x4, [x24]
101569658:     	mov	x0, x19
10156965c:     	ldr	x1, [sp, #0x58]
101569660:     	mov	x2, x20
101569664:     	add	sp, sp, #0x810
101569668:     	ldp	x29, x30, [sp, #0x50]
10156966c:     	ldp	x20, x19, [sp, #0x40]
101569670:     	ldp	x22, x21, [sp, #0x30]
101569674:     	ldp	x24, x23, [sp, #0x20]
101569678:     	ldp	x26, x25, [sp, #0x10]
10156967c:     	ldp	x28, x27, [sp], #0x60
101569680:     	b	0x1015550d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper>
101569684:     	ldr	x5, [x24]
101569688:     	mov	x0, x19
10156968c:     	ldr	x1, [sp, #0x58]
101569690:     	mov	x2, x20
101569694:     	mov	x3, x22
101569698:     	mov	x4, x21
10156969c:     	add	sp, sp, #0x810
1015696a0:     	ldp	x29, x30, [sp, #0x50]
1015696a4:     	ldp	x20, x19, [sp, #0x40]
1015696a8:     	ldp	x22, x21, [sp, #0x30]
1015696ac:     	ldp	x24, x23, [sp, #0x20]
1015696b0:     	ldp	x26, x25, [sp, #0x10]
1015696b4:     	ldp	x28, x27, [sp], #0x60
1015696b8:     	b	0x1015553c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper>
1015696bc:     	ldr	x8, [x21, #0x4d0]
1015696c0:     	cbz	x8, 0x101569c10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f2c>
1015696c4:     	ldr	x9, [x21, #0x4d8]
1015696c8:     	cbz	x9, 0x101569c10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f2c>
1015696cc:     	ldr	x9, [sp, #0x558]
1015696d0:     	str	x9, [x8]
1015696d4:     	ldr	w8, [sp, #0x608]
1015696d8:     	mov	w9, #0x1                ; =1
1015696dc:     	str	w9, [x20, #0x2f0]
1015696e0:     	str	w8, [x20, #0x2f4]
1015696e4:     	strb	w9, [x20, #0x460]
1015696e8:     	ldr	w8, [sp, #0x58]
1015696ec:     	tbz	w8, #0x0, 0x101569cf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3014>
1015696f0:     	cmp	x23, x24
1015696f4:     	b.eq	0x101569ce4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3000>
1015696f8:     	str	wzr, [x19]
1015696fc:     	mov	w8, #0xc                ; =12
101569700:     	strb	w8, [x19, #0x8]
101569704:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101569708:     	add	x8, x8, #0x4f9
10156970c:     	mov	w9, #0x25               ; =37
101569710:     	stp	x8, x9, [x19, #0x10]
101569714:     	cbz	x28, 0x10156951c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2838>
101569718:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156971c:     	add	x8, sp, #0x550
101569720:     	add	x0, sp, #0x220
101569724:     	bl	0x102d58ef0 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix12elements_mut>
101569728:     	ldr	x19, [sp, #0x558]
10156972c:     	add	x0, sp, #0x550
101569730:     	add	x1, sp, #0x220
101569734:     	mov	w2, #0x108              ; =264
101569738:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
10156973c:     	ldr	x8, [sp, #0x58]
101569740:     	ldr	x8, [x8, #0x490]
101569744:     	ldr	x8, [x8, #0x3c0]
101569748:     	cbz	x8, 0x1015698ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc8>
10156974c:     	ldr	x9, [x8, #0x40]
101569750:     	cmp	x9, #0x2
101569754:     	b.eq	0x1015698ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc8>
101569758:     	ldr	x10, [x8, #0xd8]
10156975c:     	ldr	x9, [sp, #0x48]
101569760:     	cmp	x10, x9
101569764:     	b.ne	0x1015698ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc8>
101569768:     	ldr	x9, [x23, x22]
10156976c:     	ldr	x10, [x8, #0x78]
101569770:     	cmp	x9, x10
101569774:     	b.hs	0x1015698ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc8>
101569778:     	ldr	x8, [x8, #0x70]
10156977c:     	mov	w10, #0x108             ; =264
101569780:     	madd	x20, x9, x10, x8
101569784:     	mov	x0, x20
101569788:     	bl	0x101547a88 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
10156978c:     	add	x1, sp, #0x550
101569790:     	mov	x0, x20
101569794:     	mov	w2, #0x108              ; =264
101569798:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
10156979c:     	ldr	x8, [sp, #0x58]
1015697a0:     	ldr	x8, [x8, #0x4d0]
1015697a4:     	cbz	x8, 0x101569eb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31d0>
1015697a8:     	ldr	x9, [x23, x22]
1015697ac:     	ldr	x10, [x21, #0xb0]
1015697b0:     	add	x9, x10, x9, lsl #2
1015697b4:     	add	x9, x9, #0x2
1015697b8:     	ldr	x10, [sp, #0x58]
1015697bc:     	ldr	x10, [x10, #0x4d8]
1015697c0:     	cmp	x9, x10
1015697c4:     	b.hs	0x101569eb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31d0>
1015697c8:     	str	x19, [x8, x9, lsl #3]
1015697cc:     	ldr	x8, [sp, #0x58]
1015697d0:     	ldr	x8, [x8, #0x4d0]
1015697d4:     	cbz	x8, 0x101569eb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31d0>
1015697d8:     	ldr	x9, [x23, x22]
1015697dc:     	ldr	x10, [x21, #0x40]
1015697e0:     	ldr	x11, [x21, #0xb0]
1015697e4:     	add	x9, x9, x10, lsl #2
1015697e8:     	add	x9, x9, x11
1015697ec:     	add	x9, x9, #0x2
1015697f0:     	ldr	x10, [sp, #0x58]
1015697f4:     	ldr	x10, [x10, #0x4d8]
1015697f8:     	cmp	x9, x10
1015697fc:     	b.hs	0x101569eb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31d0>
101569800:     	mov	w10, #0x1               ; =1
101569804:     	str	x10, [x8, x9, lsl #3]
101569808:     	mov	w19, #0x0               ; =0
10156980c:     	add	x0, sp, #0x550
101569810:     	ldp	x3, x1, [sp, #0x50]
101569814:     	ldr	x2, [sp, #0x48]
101569818:     	bl	0x10155a038 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation26resume_numeric_after_write>
10156981c:     	ldr	w8, [sp, #0x550]
101569820:     	cmp	w8, #0x6
101569824:     	b.ne	0x10156a1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3508>
101569828:     	str	xzr, [x28, #0x8]
10156982c:     	str	w8, [x28]
101569830:     	mov	w19, #0x0               ; =0
101569834:     	sub	x0, x29, #0x90
101569838:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156983c:     	ldur	x8, [x29, #-0xb0]
101569840:     	mov	x9, #-0x1               ; =-1
101569844:     	ldaddl	x9, x8, [x8]
101569848:     	cmp	x8, #0x1
10156984c:     	b.ne	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569850:     	dmb	ishld
101569854:     	sub	x0, x29, #0xb0
101569858:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10156985c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569860:     	ldur	w9, [x25, #0x1]
101569864:     	stur	w9, [x19, #0x9]
101569868:     	ldr	w9, [sp, #0x224]
10156986c:     	str	w9, [x19, #0xc]
101569870:     	ldr	q0, [sp, #0x240]
101569874:     	stur	q0, [x19, #0x28]
101569878:     	ldr	x9, [sp, #0x250]
10156987c:     	str	x9, [x19, #0x38]
101569880:     	ldr	d0, [sp, #0x238]
101569884:     	ldur	q1, [x25, #0x8]
101569888:     	mov	w9, #0x2                ; =2
10156988c:     	str	w9, [x19]
101569890:     	strb	w8, [x19, #0x8]
101569894:     	str	q1, [x19, #0x10]
101569898:     	str	d0, [x19, #0x20]
10156989c:     	mov	w27, #0x0               ; =0
1015698a0:     	add	x0, sp, #0x440
1015698a4:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015698a8:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015698ac:     	str	wzr, [x28]
1015698b0:     	mov	w8, #0xc                ; =12
1015698b4:     	adrp	x9, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
1015698b8:     	add	x9, x9, #0x234
1015698bc:     	stp	x8, x9, [x28, #0x8]
1015698c0:     	mov	w8, #0x2b               ; =43
1015698c4:     	str	x8, [x28, #0x18]
1015698c8:     	mov	w19, #0x0               ; =0
1015698cc:     	add	x0, sp, #0x550
1015698d0:     	bl	0x101547a88 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
1015698d4:     	mov	w19, #0x0               ; =0
1015698d8:     	b	0x101569c48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f64>
1015698dc:     	add	x8, sp, #0x550
1015698e0:     	add	x0, x24, #0x3b8
1015698e4:     	bl	0x102368ae4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015698e8:     	ldr	x8, [sp, #0x58]
1015698ec:     	ldr	x8, [x8, #0x20]
1015698f0:     	cmp	x8, #0x1
1015698f4:     	b.ne	0x101569c80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f9c>
1015698f8:     	ldr	x8, [sp, #0x58]
1015698fc:     	ldr	w8, [x8, #0x40]
101569900:     	tbz	w8, #0x0, 0x101569db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30cc>
101569904:     	ldr	x8, [sp, #0x58]
101569908:     	ldr	x1, [x8, #0x28]
10156990c:     	ldr	x2, [x8, #0x48]
101569910:     	add	x8, sp, #0x668
101569914:     	add	x0, sp, #0x550
101569918:     	bl	0x102e34d38 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget11with_limits>
10156991c:     	ldr	x8, [sp, #0x550]
101569920:     	mov	x9, #-0x1               ; =-1
101569924:     	ldaddl	x9, x8, [x8]
101569928:     	cmp	x8, #0x1
10156992c:     	b.ne	0x10156993c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c58>
101569930:     	dmb	ishld
101569934:     	add	x0, sp, #0x550
101569938:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10156993c:     	ldr	x8, [sp, #0x660]
101569940:     	ldr	x9, [x8, #0x6c0]
101569944:     	cmp	x9, #0x100, lsl #12     ; =0x100000
101569948:     	b.ls	0x101569e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3130>
10156994c:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
101569950:     	ldr	q0, [x8]
101569954:     	stur	q0, [x23, #0x8]
101569958:     	mov	w8, #0x6                ; =6
10156995c:     	str	w8, [x23]
101569960:     	b	0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
101569964:     	adrp	x0, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101569968:     	add	x0, x0, #0x4f0
10156996c:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101569970:     	add	x0, sp, #0x550
101569974:     	ldr	x1, [sp, #0x58]
101569978:     	mov	x2, x20
10156997c:     	bl	0x101564c88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
101569980:     	ldr	w8, [sp, #0x550]
101569984:     	tbz	w8, #0x0, 0x101569c98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fb4>
101569988:     	ldr	w21, [sp, #0x554]
10156998c:     	ldr	w22, [sp, #0x558]
101569990:     	add	x0, sp, #0x550
101569994:     	ldr	x1, [sp, #0x58]
101569998:     	mov	x2, x20
10156999c:     	mov	w3, #0x1                ; =1
1015699a0:     	mov	w4, #0x8                ; =8
1015699a4:     	mov	x5, #0x0                ; =0
1015699a8:     	bl	0x10155166c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015699ac:     	ldr	w8, [sp, #0x550]
1015699b0:     	cmp	w8, #0x6
1015699b4:     	b.ne	0x101569d64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3080>
1015699b8:     	ldr	x8, [sp, #0x558]
1015699bc:     	cmp	x8, #0x2
1015699c0:     	b.ne	0x101569a18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d34>
1015699c4:     	add	x0, sp, #0x550
1015699c8:     	ldr	x1, [sp, #0x58]
1015699cc:     	mov	x2, x21
1015699d0:     	mov	x3, x22
1015699d4:     	bl	0x1015750d0 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation15move_joined_map>
1015699d8:     	ldr	w9, [sp, #0x550]
1015699dc:     	ldrb	w8, [sp, #0x554]
1015699e0:     	cmp	w9, #0x6
1015699e4:     	b.ne	0x101569f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3264>
1015699e8:     	tbnz	w8, #0x0, 0x101569a90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dac>
1015699ec:     	ldr	x8, [sp, #0x58]
1015699f0:     	ldr	x8, [x8, #0x490]
1015699f4:     	add	x0, sp, #0x550
1015699f8:     	add	x1, x8, #0xf0
1015699fc:     	add	x4, x8, #0x2f8
101569a00:     	mov	x2, x21
101569a04:     	mov	x3, x22
101569a08:     	bl	0x10156e17c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena15copy_current_to>
101569a0c:     	ldrb	w8, [sp, #0x550]
101569a10:     	cmp	w8, #0x14
101569a14:     	b.ne	0x10156a1ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34c8>
101569a18:     	ldr	x1, [x23, #0x380]
101569a1c:     	cmp	x20, x1
101569a20:     	b.hs	0x10156aba0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ebc>
101569a24:     	ldr	x8, [x23, #0x378]
101569a28:     	mov	w9, #0x170              ; =368
101569a2c:     	madd	x8, x20, x9, x8
101569a30:     	ldp	x10, x9, [x8]
101569a34:     	mov	w11, #0x11              ; =17
101569a38:     	eor	x10, x10, x11
101569a3c:     	orr	x9, x10, x9
101569a40:     	cbnz	x9, 0x101569a90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dac>
101569a44:     	ldr	x1, [x23, #0x390]
101569a48:     	ldr	w2, [x8, #0x10]
101569a4c:     	cmp	x1, x2
101569a50:     	b.ls	0x10156abdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ef8>
101569a54:     	ldr	x8, [x23, #0x388]
101569a58:     	mov	w9, #0x180              ; =384
101569a5c:     	umaddl	x8, w2, w9, x8
101569a60:     	ldp	x8, x9, [x8]
101569a64:     	mov	w10, #0x5               ; =5
101569a68:     	eor	x8, x8, x10
101569a6c:     	orr	x8, x8, x9
101569a70:     	cbnz	x8, 0x101569a90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dac>
101569a74:     	add	x0, sp, #0x550
101569a78:     	ldr	x1, [sp, #0x58]
101569a7c:     	mov	w3, #0x1                ; =1
101569a80:     	bl	0x1015652c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
101569a84:     	ldr	w8, [sp, #0x550]
101569a88:     	cmp	w8, #0x6
101569a8c:     	b.ne	0x10156a188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34a4>
101569a90:     	ldr	x8, [sp, #0x58]
101569a94:     	ldr	x8, [x8, #0x490]
101569a98:     	mov	w9, #0x1                ; =1
101569a9c:     	strb	w9, [x8, #0x460]
101569aa0:     	b	0x101568170 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x148c>
101569aa4:     	ldr	x1, [x23, #0x380]
101569aa8:     	cmp	x20, x1
101569aac:     	b.hs	0x10156aa8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3da8>
101569ab0:     	ldr	x8, [x23, #0x378]
101569ab4:     	mov	w9, #0x170              ; =368
101569ab8:     	madd	x25, x20, x9, x8
101569abc:     	ldp	x9, x8, [x25]
101569ac0:     	cmp	x9, #0x2
101569ac4:     	sbcs	xzr, x8, xzr
101569ac8:     	b.hs	0x101569cb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fd0>
101569acc:     	ldr	x9, [x24]
101569ad0:     	ldr	x8, [sp, #0x58]
101569ad4:     	ldr	x21, [x8, #0x4d0]
101569ad8:     	cmp	x9, x21
101569adc:     	b.ne	0x101569d98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b4>
101569ae0:     	ldr	x22, [x24, #0x8]
101569ae4:     	ldr	x8, [x25, #0x128]
101569ae8:     	cmp	x22, x8
101569aec:     	b.ne	0x101569d98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b4>
101569af0:     	ldr	x9, [x24, #0x10]
101569af4:     	cbnz	x9, 0x101569d98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b4>
101569af8:     	ldr	x9, [sp, #0x58]
101569afc:     	ldr	x9, [x9, #0x4d8]
101569b00:     	cmp	x8, x9
101569b04:     	b.hi	0x101569d98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b4>
101569b08:     	ldr	x23, [x25, #0x120]
101569b0c:     	add	x0, sp, #0x550
101569b10:     	ldr	x1, [sp, #0x58]
101569b14:     	mov	x2, x20
101569b18:     	mov	x3, x21
101569b1c:     	mov	x4, x22
101569b20:     	bl	0x101552b88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14selected_callsNtB4_10Invocation21prepared_library_call>
101569b24:     	ldr	w8, [sp, #0x550]
101569b28:     	cmp	w8, #0x6
101569b2c:     	b.ne	0x101569d64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3080>
101569b30:     	ldr	x8, [sp, #0x558]
101569b34:     	cmp	x8, #0x2
101569b38:     	b.ne	0x101569e9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31b8>
101569b3c:     	add	x0, sp, #0x550
101569b40:     	ldr	x1, [sp, #0x58]
101569b44:     	mov	x2, x20
101569b48:     	mov	x3, x21
101569b4c:     	mov	x4, x22
101569b50:     	bl	0x10155dd60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5lines10line_callsNtNtB6_10invocation10Invocation16line_matrix_call>
101569b54:     	ldr	w8, [sp, #0x550]
101569b58:     	cmp	w8, #0x6
101569b5c:     	b.ne	0x101569d64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3080>
101569b60:     	ldr	x8, [sp, #0x558]
101569b64:     	cmp	x8, #0x2
101569b68:     	b.ne	0x101569e9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31b8>
101569b6c:     	add	x0, sp, #0x550
101569b70:     	ldr	x1, [sp, #0x58]
101569b74:     	mov	x2, x20
101569b78:     	mov	x3, x21
101569b7c:     	mov	x4, x22
101569b80:     	bl	0x101562420 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime7session7capture14captured_callsNtNtB8_10invocation10Invocation26captured_line_element_call>
101569b84:     	ldr	w9, [sp, #0x550]
101569b88:     	ldrb	w8, [sp, #0x554]
101569b8c:     	cmp	w9, #0x6
101569b90:     	b.ne	0x101569f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3264>
101569b94:     	tbnz	w8, #0x0, 0x101569a90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dac>
101569b98:     	add	x0, sp, #0x550
101569b9c:     	ldr	x1, [sp, #0x58]
101569ba0:     	mov	x2, x20
101569ba4:     	mov	x3, x21
101569ba8:     	mov	x4, x22
101569bac:     	bl	0x1015729a4 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation18selected_join_call>
101569bb0:     	ldr	w9, [sp, #0x550]
101569bb4:     	ldrb	w8, [sp, #0x554]
101569bb8:     	cmp	w9, #0x6
101569bbc:     	b.ne	0x101569f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3264>
101569bc0:     	tbz	w8, #0x0, 0x10156a360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x367c>
101569bc4:     	ldr	x8, [sp, #0x58]
101569bc8:     	ldr	x9, [x8, #0x490]
101569bcc:     	mov	w10, #0x1               ; =1
101569bd0:     	strb	w10, [x9, #0x460]
101569bd4:     	ldr	x8, [x8, #0x290]
101569bd8:     	cmp	x8, #0x4
101569bdc:     	cset	w8, eq
101569be0:     	stp	x8, x10, [x19, #0x8]
101569be4:     	b	0x101568174 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1490>
101569be8:     	str	wzr, [x19]
101569bec:     	mov	w8, #0xc                ; =12
101569bf0:     	strb	w8, [x19, #0x8]
101569bf4:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101569bf8:     	add	x8, x8, #0x117
101569bfc:     	mov	w9, #0x1b               ; =27
101569c00:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
101569c04:     	adrp	x0, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101569c08:     	add	x0, x0, #0x4a8
101569c0c:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101569c10:     	str	wzr, [x19]
101569c14:     	mov	w9, #0xc                ; =12
101569c18:     	strb	w9, [x19, #0x8]
101569c1c:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101569c20:     	add	x8, x8, #0xee6
101569c24:     	mov	w9, #0x29               ; =41
101569c28:     	b	0x101569518 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2834>
101569c2c:     	str	wzr, [x28]
101569c30:     	adrp	x8, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101569c34:     	add	x8, x8, #0xbae
101569c38:     	mov	w9, #0xc                ; =12
101569c3c:     	stp	x9, x8, [x28, #0x8]
101569c40:     	mov	w8, #0x28               ; =40
101569c44:     	str	x8, [x28, #0x18]
101569c48:     	sub	x0, x29, #0x90
101569c4c:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101569c50:     	ldur	x8, [x29, #-0xb0]
101569c54:     	mov	x9, #-0x1               ; =-1
101569c58:     	ldaddl	x9, x8, [x8]
101569c5c:     	cmp	x8, #0x1
101569c60:     	b.ne	0x101569c70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f8c>
101569c64:     	dmb	ishld
101569c68:     	sub	x0, x29, #0xb0
101569c6c:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101569c70:     	tbz	w19, #0x0, 0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569c74:     	add	x0, sp, #0x220
101569c78:     	bl	0x10154a790 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
101569c7c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569c80:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101569c84:     	add	x8, x8, #0x8c8
101569c88:     	b	0x101569db8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30d4>
101569c8c:     	adrp	x0, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101569c90:     	add	x0, x0, #0x520
101569c94:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101569c98:     	str	wzr, [x19]
101569c9c:     	mov	w8, #0xc                ; =12
101569ca0:     	str	w8, [x19, #0x8]
101569ca4:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101569ca8:     	add	x8, x8, #0x893
101569cac:     	mov	w9, #0x21               ; =33
101569cb0:     	b	0x101567cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
101569cb4:     	str	wzr, [x19]
101569cb8:     	mov	w8, #0xc                ; =12
101569cbc:     	strb	w8, [x19, #0x8]
101569cc0:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101569cc4:     	add	x8, x8, #0x16c
101569cc8:     	b	0x1015689f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d14>
101569ccc:     	adrp	x0, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101569cd0:     	add	x0, x0, #0x4c0
101569cd4:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101569cd8:     	adrp	x0, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
101569cdc:     	add	x0, x0, #0x4d8
101569ce0:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101569ce4:     	add	x20, x21, #0x3c0
101569ce8:     	mov	x0, x20
101569cec:     	bl	0x101547b00 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
101569cf0:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101569cf4:     	str	x8, [x20]
101569cf8:     	mov	w8, #0x1                ; =1
101569cfc:     	dup.2d	v0, x8
101569d00:     	b	0x10156749c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b8>
101569d04:     	add	x0, sp, #0x550
101569d08:     	ldr	x1, [sp, #0x58]
101569d0c:     	mov	x2, x20
101569d10:     	mov	w3, #0x12               ; =18
101569d14:     	mov	w4, #0x8                ; =8
101569d18:     	mov	x5, #0x0                ; =0
101569d1c:     	bl	0x10155166c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
101569d20:     	ldr	w8, [sp, #0x550]
101569d24:     	cmp	w8, #0x6
101569d28:     	b.ne	0x101569d64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3080>
101569d2c:     	ldr	x8, [sp, #0x558]
101569d30:     	cmp	x8, #0x2
101569d34:     	b.ne	0x101569e9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31b8>
101569d38:     	mov	x0, x19
101569d3c:     	ldr	x1, [sp, #0x58]
101569d40:     	mov	x2, x20
101569d44:     	add	sp, sp, #0x810
101569d48:     	ldp	x29, x30, [sp, #0x50]
101569d4c:     	ldp	x20, x19, [sp, #0x40]
101569d50:     	ldp	x22, x21, [sp, #0x30]
101569d54:     	ldp	x24, x23, [sp, #0x20]
101569d58:     	ldp	x26, x25, [sp, #0x10]
101569d5c:     	ldp	x28, x27, [sp], #0x60
101569d60:     	b	0x101555e64 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation>
101569d64:     	ldr	w9, [sp, #0x554]
101569d68:     	ldur	q0, [x27, #0x18]
101569d6c:     	stur	q0, [x19, #0x18]
101569d70:     	ldur	q0, [x27, #0x28]
101569d74:     	stur	q0, [x19, #0x28]
101569d78:     	ldur	q0, [x27, #0x38]
101569d7c:     	stur	q0, [x19, #0x38]
101569d80:     	ldr	x10, [sp, #0x598]
101569d84:     	str	x10, [x19, #0x48]
101569d88:     	ldur	q0, [x27, #0x8]
101569d8c:     	stp	w8, w9, [x19]
101569d90:     	stur	q0, [x19, #0x8]
101569d94:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569d98:     	str	wzr, [x19]
101569d9c:     	mov	w8, #0xc                ; =12
101569da0:     	strb	w8, [x19, #0x8]
101569da4:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
101569da8:     	add	x8, x8, #0x148
101569dac:     	b	0x1015689f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d14>
101569db0:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101569db4:     	add	x8, x8, #0x8e6
101569db8:     	str	wzr, [x23]
101569dbc:     	mov	w9, #0xc                ; =12
101569dc0:     	stp	x9, x8, [x23, #0x8]
101569dc4:     	mov	w8, #0x1e               ; =30
101569dc8:     	str	x8, [x23, #0x18]
101569dcc:     	ldr	x8, [sp, #0x550]
101569dd0:     	mov	x9, #-0x1               ; =-1
101569dd4:     	ldaddl	x9, x8, [x8]
101569dd8:     	cmp	x8, #0x1
101569ddc:     	b.ne	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569de0:     	dmb	ishld
101569de4:     	add	x0, sp, #0x550
101569de8:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101569dec:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569df0:     	str	wzr, [x28]
101569df4:     	mov	w8, #0xc                ; =12
101569df8:     	strb	w8, [x28, #0x8]
101569dfc:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101569e00:     	add	x8, x8, #0xee6
101569e04:     	mov	w9, #0x29               ; =41
101569e08:     	stp	x8, x9, [x28, #0x10]
101569e0c:     	mov	w19, #0x1               ; =1
101569e10:     	b	0x101569c48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f64>
101569e14:     	str	xzr, [sp, #0x38]
101569e18:     	add	x24, sp, #0x720
101569e1c:     	ldp	x15, x9, [sp, #0x48]
101569e20:     	lsl	x11, x9, #2
101569e24:     	add	x9, x15, x11
101569e28:     	str	x9, [sp, #0x28]
101569e2c:     	ldr	x12, [x8, #0x5a0]
101569e30:     	ldr	x13, [x8, #0x598]
101569e34:     	mov	w8, #0xc                ; =12
101569e38:     	mov	w9, #0x29               ; =41
101569e3c:     	mov	w14, #0x58              ; =88
101569e40:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101569e44:     	add	x10, x10, #0x904
101569e48:     	ldr	x16, [sp, #0x38]
101569e4c:     	cbz	x11, 0x101569ed8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f4>
101569e50:     	ldr	w17, [x15], #0x4
101569e54:     	cmp	x12, x17
101569e58:     	b.ls	0x101569e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31a8>
101569e5c:     	umaddl	x17, w17, w14, x13
101569e60:     	ldr	x17, [x17, #0x8]
101569e64:     	sub	x11, x11, #0x4
101569e68:     	ldr	x0, [sp, #0x38]
101569e6c:     	adds	x0, x17, x0
101569e70:     	str	x0, [sp, #0x38]
101569e74:     	b.lo	0x101569e48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3164>
101569e78:     	and	x8, x16, #0xffffffffffffff00
101569e7c:     	orr	x8, x8, #0xc
101569e80:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101569e84:     	add	x10, x10, #0x92d
101569e88:     	mov	w9, #0x1f               ; =31
101569e8c:     	str	wzr, [x23]
101569e90:     	stp	x8, x10, [x23, #0x8]
101569e94:     	str	x9, [x23, #0x18]
101569e98:     	b	0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
101569e9c:     	ldur	q0, [x27, #0x8]
101569ea0:     	ldr	x8, [sp, #0x58]
101569ea4:     	ldr	x8, [x8, #0x490]
101569ea8:     	mov	w9, #0x1                ; =1
101569eac:     	strb	w9, [x8, #0x460]
101569eb0:     	b	0x10156749c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b8>
101569eb4:     	mov	w19, #0x0               ; =0
101569eb8:     	str	wzr, [x28]
101569ebc:     	mov	w8, #0xc                ; =12
101569ec0:     	strb	w8, [x28, #0x8]
101569ec4:     	adrp	x8, 0x107550000 <_anon.61c4a8641e5b3956ea8870164c4e553f.286+0xb8>
101569ec8:     	add	x8, x8, #0xee6
101569ecc:     	mov	w9, #0x29               ; =41
101569ed0:     	stp	x8, x9, [x28, #0x10]
101569ed4:     	b	0x101569c48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f64>
101569ed8:     	mov	w8, #0x48               ; =72
101569edc:     	mov	x9, #0x48               ; =72
101569ee0:     	madd	x8, x20, x8, x9
101569ee4:     	ldr	x9, [sp, #0x38]
101569ee8:     	umulh	x9, x9, x8
101569eec:     	cmp	xzr, x9
101569ef0:     	b.ne	0x10156a704 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a20>
101569ef4:     	ldr	x9, [sp, #0x38]
101569ef8:     	mul	x8, x9, x8
101569efc:     	mov	w9, #0x580              ; =1408
101569f00:     	mov	x10, #0x400             ; =1024
101569f04:     	madd	x9, x20, x9, x10
101569f08:     	adds	x8, x8, x9
101569f0c:     	str	x8, [sp, #0x30]
101569f10:     	b.hs	0x10156a718 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a34>
101569f14:     	mov	x8, #-0x201             ; =-513
101569f18:     	movk	x8, #0x1fff, lsl #48
101569f1c:     	ldr	x9, [sp, #0x30]
101569f20:     	cmp	x9, x8
101569f24:     	b.ls	0x101569fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32c8>
101569f28:     	str	wzr, [x23]
101569f2c:     	mov	w8, #0xc                ; =12
101569f30:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
101569f34:     	add	x9, x9, #0x966
101569f38:     	stp	x8, x9, [x23, #0x8]
101569f3c:     	mov	w8, #0x17               ; =23
101569f40:     	str	x8, [x23, #0x18]
101569f44:     	b	0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
101569f48:     	ldur	q0, [x27, #0x15]
101569f4c:     	stur	q0, [x19, #0x15]
101569f50:     	ldur	q0, [x27, #0x25]
101569f54:     	stur	q0, [x19, #0x25]
101569f58:     	ldur	q0, [x27, #0x35]
101569f5c:     	stur	q0, [x19, #0x35]
101569f60:     	ldr	q0, [sp, #0x590]
101569f64:     	str	q0, [x19, #0x40]
101569f68:     	ldur	q0, [x27, #0x5]
101569f6c:     	stur	q0, [x19, #0x5]
101569f70:     	str	w9, [x19]
101569f74:     	strb	w8, [x19, #0x4]
101569f78:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101569f7c:     	adrp	x3, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
101569f80:     	add	x3, x3, #0x5d0
101569f84:     	mov	x0, #0x0                ; =0
101569f88:     	bl	0x103a02a54 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101569f8c:     	b	0x10156af3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4258>
101569f90:     	str	wzr, [x28]
101569f94:     	mov	w8, #0xc                ; =12
101569f98:     	strb	w8, [x28, #0x8]
101569f9c:     	adrp	x8, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
101569fa0:     	add	x8, x8, #0xb82
101569fa4:     	mov	w9, #0x2c               ; =44
101569fa8:     	b	0x101569ed0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31ec>
101569fac:     	ldr	x8, [sp, #0x58]
101569fb0:     	ldr	x9, [x8, #0x490]
101569fb4:     	ldr	x8, [sp, #0x30]
101569fb8:     	lsl	x8, x8, #3
101569fbc:     	add	x0, sp, #0x550
101569fc0:     	str	x9, [sp, #0x20]
101569fc4:     	add	x1, x9, #0x2f8
101569fc8:     	add	x2, x8, #0x1, lsl #12   ; =0x1000
101569fcc:     	bl	0x10154e858 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101569fd0:     	ldrb	w8, [sp, #0x550]
101569fd4:     	cmp	w8, #0xe
101569fd8:     	b.ne	0x10156a130 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344c>
101569fdc:     	add	x8, sp, #0x550
101569fe0:     	add	x0, sp, #0x668
101569fe4:     	ldr	x1, [sp, #0x30]
101569fe8:     	bl	0x102e34ea4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101569fec:     	ldr	w8, [sp, #0x550]
101569ff0:     	cmp	w8, #0x1a
101569ff4:     	b.ne	0x10156a254 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3570>
101569ff8:     	ldur	q0, [x27, #0x8]
101569ffc:     	ldur	q1, [x27, #0x18]
10156a000:     	str	q0, [sp, #0x680]
10156a004:     	str	q1, [sp, #0x690]
10156a008:     	add	x8, sp, #0x550
10156a00c:     	mov	x0, x20
10156a010:     	ldr	x1, [sp, #0x50]
10156a014:     	ldr	x2, [sp, #0x38]
10156a018:     	bl	0x10152c0c4 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel15scheduler_nodes>
10156a01c:     	ldr	w8, [sp, #0x550]
10156a020:     	cmp	w8, #0x6
10156a024:     	b.ne	0x10156a290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35ac>
10156a028:     	ldr	x1, [sp, #0x558]
10156a02c:     	add	x8, sp, #0x440
10156a030:     	add	x0, sp, #0x668
10156a034:     	bl	0x102e34d78 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
10156a038:     	ldr	w8, [sp, #0x440]
10156a03c:     	cmp	w8, #0x1a
10156a040:     	b.ne	0x10156a2e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3604>
10156a044:     	add	x8, sp, #0x440
10156a048:     	ldur	q0, [x8, #0x8]
10156a04c:     	ldur	q1, [x8, #0x18]
10156a050:     	str	q0, [sp, #0x6a0]
10156a054:     	str	q1, [sp, #0x6b0]
10156a058:     	ldr	x8, [sp, #0x50]
10156a05c:     	cbnz	x8, 0x10156a3c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36dc>
10156a060:     	mov	w8, #0x8                ; =8
10156a064:     	str	xzr, [sp, #0x6c0]
10156a068:     	str	x8, [sp, #0x6c8]
10156a06c:     	str	xzr, [sp, #0x6d0]
10156a070:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
10156a074:     	ldr	q0, [x8]
10156a078:     	stur	q0, [x23, #0x8]
10156a07c:     	mov	w8, #0x6                ; =6
10156a080:     	str	w8, [x23]
10156a084:     	add	x0, sp, #0x6c0
10156a088:     	bl	0x101548918 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
10156a08c:     	add	x0, sp, #0x6a0
10156a090:     	bl	0x101549acc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10156a094:     	b	0x10156a304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3620>
10156a098:     	mov	w19, #0x0               ; =0
10156a09c:     	ldur	q0, [x24, #0x8]
10156a0a0:     	ldur	q1, [x24, #0x18]
10156a0a4:     	ldur	q2, [x24, #0x28]
10156a0a8:     	ldur	q3, [x24, #0x38]
10156a0ac:     	ldur	x8, [x24, #0x48]
10156a0b0:     	stur	x8, [x27, #0x44]
10156a0b4:     	stur	q0, [x27, #0x4]
10156a0b8:     	stur	q1, [x27, #0x14]
10156a0bc:     	stur	q2, [x27, #0x24]
10156a0c0:     	stur	q3, [x27, #0x34]
10156a0c4:     	ldr	q0, [sp, #0x570]
10156a0c8:     	ldr	q1, [sp, #0x580]
10156a0cc:     	str	q0, [sp, #0x410]
10156a0d0:     	str	q1, [sp, #0x420]
10156a0d4:     	ldur	q0, [x27, #0x3c]
10156a0d8:     	stur	q0, [x26, #0xfc]
10156a0dc:     	ldr	q0, [sp, #0x560]
10156a0e0:     	ldr	q1, [sp, #0x550]
10156a0e4:     	stp	q1, q0, [sp, #0x3f0]
10156a0e8:     	ldp	q0, q1, [sp, #0x3f0]
10156a0ec:     	ldur	q2, [x26, #0xfc]
10156a0f0:     	stur	q2, [x26, #0xac]
10156a0f4:     	ldr	q2, [sp, #0x410]
10156a0f8:     	ldr	q3, [sp, #0x420]
10156a0fc:     	stp	q2, q3, [sp, #0x3c0]
10156a100:     	stp	q0, q1, [sp, #0x3a0]
10156a104:     	ldp	q1, q0, [sp, #0x3a0]
10156a108:     	stur	q0, [x28, #0x14]
10156a10c:     	ldp	q0, q2, [sp, #0x3c0]
10156a110:     	stur	q0, [x28, #0x24]
10156a114:     	stur	q2, [x28, #0x34]
10156a118:     	ldur	q0, [x26, #0xac]
10156a11c:     	str	q0, [x28, #0x40]
10156a120:     	stur	q1, [x28, #0x4]
10156a124:     	mov	w8, #0x5                ; =5
10156a128:     	str	w8, [x28]
10156a12c:     	b	0x101569c48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f64>
10156a130:     	ldr	q0, [sp, #0x550]
10156a134:     	ldr	q1, [sp, #0x560]
10156a138:     	str	q0, [sp, #0x440]
10156a13c:     	str	q1, [sp, #0x450]
10156a140:     	ldr	q2, [sp, #0x570]
10156a144:     	str	q2, [sp, #0x460]
10156a148:     	ldr	x8, [sp, #0x580]
10156a14c:     	str	x8, [sp, #0x470]
10156a150:     	stur	q0, [x27, #0x4]
10156a154:     	stur	q1, [x27, #0x14]
10156a158:     	stur	q2, [x27, #0x24]
10156a15c:     	stur	x8, [x27, #0x34]
10156a160:     	str	wzr, [x23]
10156a164:     	ldr	q0, [sp, #0x550]
10156a168:     	ldr	q1, [sp, #0x560]
10156a16c:     	stur	q0, [x23, #0x4]
10156a170:     	stur	q1, [x23, #0x14]
10156a174:     	ldr	q0, [sp, #0x570]
10156a178:     	stur	q0, [x23, #0x24]
10156a17c:     	ldur	q0, [x27, #0x2c]
10156a180:     	str	q0, [x23, #0x30]
10156a184:     	b	0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
10156a188:     	ldr	q0, [sp, #0x570]
10156a18c:     	ldr	q1, [sp, #0x580]
10156a190:     	stp	q0, q1, [x19, #0x20]
10156a194:     	ldr	q0, [sp, #0x590]
10156a198:     	str	q0, [x19, #0x40]
10156a19c:     	ldr	q0, [sp, #0x560]
10156a1a0:     	ldr	q1, [sp, #0x550]
10156a1a4:     	stp	q1, q0, [x19]
10156a1a8:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156a1ac:     	ldur	w9, [x27, #0x1]
10156a1b0:     	stur	w9, [x19, #0x9]
10156a1b4:     	ldr	w9, [sp, #0x554]
10156a1b8:     	str	w9, [x19, #0xc]
10156a1bc:     	ldr	q0, [sp, #0x570]
10156a1c0:     	stur	q0, [x19, #0x28]
10156a1c4:     	ldr	x9, [sp, #0x580]
10156a1c8:     	str	x9, [x19, #0x38]
10156a1cc:     	ldr	d0, [sp, #0x568]
10156a1d0:     	ldur	q1, [x27, #0x8]
10156a1d4:     	mov	w9, #0x2                ; =2
10156a1d8:     	str	w9, [x19]
10156a1dc:     	strb	w8, [x19, #0x8]
10156a1e0:     	str	q1, [x19, #0x10]
10156a1e4:     	str	d0, [x19, #0x20]
10156a1e8:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156a1ec:     	mov	w19, #0x0               ; =0
10156a1f0:     	ldr	q0, [sp, #0x570]
10156a1f4:     	ldr	q1, [sp, #0x580]
10156a1f8:     	stp	q0, q1, [x28, #0x20]
10156a1fc:     	ldr	q0, [sp, #0x590]
10156a200:     	str	q0, [x28, #0x40]
10156a204:     	ldr	q0, [sp, #0x560]
10156a208:     	ldr	q1, [sp, #0x550]
10156a20c:     	stp	q1, q0, [x28]
10156a210:     	b	0x101569c48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f64>
10156a214:     	str	wzr, [x28]
10156a218:     	mov	w8, #0xc                ; =12
10156a21c:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
10156a220:     	add	x9, x9, #0xb32
10156a224:     	stp	x8, x9, [x28, #0x8]
10156a228:     	mov	w8, #0x2a               ; =42
10156a22c:     	str	x8, [x28, #0x18]
10156a230:     	b	0x10156956c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2888>
10156a234:     	str	wzr, [x28]
10156a238:     	mov	w8, #0xc                ; =12
10156a23c:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
10156a240:     	add	x9, x9, #0xb5c
10156a244:     	stp	x8, x9, [x28, #0x8]
10156a248:     	mov	w8, #0x26               ; =38
10156a24c:     	str	x8, [x28, #0x18]
10156a250:     	b	0x10156956c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2888>
10156a254:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
10156a258:     	ldr	q0, [x8]
10156a25c:     	stur	q0, [x23, #0x8]
10156a260:     	mov	w8, #0x6                ; =6
10156a264:     	str	w8, [x23]
10156a268:     	add	x0, sp, #0x550
10156a26c:     	bl	0x10154808c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
10156a270:     	b	0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
10156a274:     	str	wzr, [x19]
10156a278:     	mov	w9, #0xc                ; =12
10156a27c:     	str	x9, [x19, #0x8]
10156a280:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156a284:     	add	x8, x8, #0x51e
10156a288:     	mov	w9, #0x1e               ; =30
10156a28c:     	b	0x101569518 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2834>
10156a290:     	ldr	w9, [sp, #0x554]
10156a294:     	ldr	x10, [sp, #0x558]
10156a298:     	ldr	q0, [sp, #0x560]
10156a29c:     	ldr	q1, [sp, #0x570]
10156a2a0:     	stp	q0, q1, [x23, #0x10]
10156a2a4:     	ldr	q0, [sp, #0x580]
10156a2a8:     	ldr	q1, [sp, #0x590]
10156a2ac:     	stp	q0, q1, [x23, #0x30]
10156a2b0:     	stp	w8, w9, [x23]
10156a2b4:     	str	x10, [x23, #0x8]
10156a2b8:     	b	0x10156a304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3620>
10156a2bc:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
10156a2c0:     	add	x2, x2, #0x5b8
10156a2c4:     	mov	x0, x8
10156a2c8:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a2cc:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156a2d0:     	add	x2, x2, #0x508
10156a2d4:     	mov	x0, x19
10156a2d8:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a2dc:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156a2e0:     	add	x2, x2, #0x178
10156a2e4:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a2e8:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
10156a2ec:     	ldr	q0, [x8]
10156a2f0:     	stur	q0, [x23, #0x8]
10156a2f4:     	mov	w8, #0x6                ; =6
10156a2f8:     	str	w8, [x23]
10156a2fc:     	add	x0, sp, #0x440
10156a300:     	bl	0x101547fb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
10156a304:     	add	x0, sp, #0x680
10156a308:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156a30c:     	ldr	x8, [sp, #0x668]
10156a310:     	mov	x9, #-0x1               ; =-1
10156a314:     	ldaddl	x9, x8, [x8]
10156a318:     	cmp	x8, #0x1
10156a31c:     	b.ne	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156a320:     	dmb	ishld
10156a324:     	add	x0, sp, #0x668
10156a328:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10156a32c:     	b	0x101566fb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10156a330:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156a334:     	add	x2, x2, #0x220
10156a338:     	mov	x0, x19
10156a33c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a340:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
10156a344:     	add	x2, x2, #0x3d8
10156a348:     	ldr	x0, [sp, #0x50]
10156a34c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a350:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
10156a354:     	add	x2, x2, #0x3f0
10156a358:     	ldr	x0, [sp, #0x50]
10156a35c:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a360:     	ldr	w5, [x25, #0x130]
10156a364:     	mov	x0, x19
10156a368:     	ldr	x1, [sp, #0x58]
10156a36c:     	mov	x2, x20
10156a370:     	mov	x3, x23
10156a374:     	mov	x4, x22
10156a378:     	mov	x6, x21
10156a37c:     	mov	x7, x22
10156a380:     	add	sp, sp, #0x810
10156a384:     	ldp	x29, x30, [sp, #0x50]
10156a388:     	ldp	x20, x19, [sp, #0x40]
10156a38c:     	ldp	x22, x21, [sp, #0x30]
10156a390:     	ldp	x24, x23, [sp, #0x20]
10156a394:     	ldp	x26, x25, [sp, #0x10]
10156a398:     	ldp	x28, x27, [sp], #0x60
10156a39c:     	b	0x10155574c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call>
10156a3a0:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156a3a4:     	add	x2, x2, #0x238
10156a3a8:     	mov	x0, x1
10156a3ac:     	mov	x1, x8
10156a3b0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a3b4:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156a3b8:     	add	x2, x2, #0x1f0
10156a3bc:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a3c0:     	add	x0, sp, #0x550
10156a3c4:     	mov	x1, #0x0                ; =0
10156a3c8:     	mov	w2, #0x8                ; =8
10156a3cc:     	ldr	x3, [sp, #0x50]
10156a3d0:     	mov	w4, #0x8                ; =8
10156a3d4:     	mov	w5, #0x68               ; =104
10156a3d8:     	bl	0x1039dccdc <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
10156a3dc:     	ldr	w8, [sp, #0x550]
10156a3e0:     	tbz	w8, #0x0, 0x10156a414 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3730>
10156a3e4:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156a3e8:     	add	x8, x8, #0x347
10156a3ec:     	mov	w9, #0xc                ; =12
10156a3f0:     	stp	x9, x8, [x23, #0x8]
10156a3f4:     	mov	w8, #0x1a               ; =26
10156a3f8:     	str	x8, [x23, #0x18]
10156a3fc:     	str	wzr, [x23]
10156a400:     	b	0x10156a08c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33a8>
10156a404:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
10156a408:     	add	x2, x2, #0x408
10156a40c:     	ldr	x1, [sp, #0x28]
10156a410:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156a414:     	str	xzr, [sp]
10156a418:     	str	xzr, [sp, #0x18]
10156a41c:     	ldr	x8, [sp, #0x558]
10156a420:     	ldr	x9, [sp, #0x50]
10156a424:     	str	x9, [sp, #0x6c0]
10156a428:     	str	x8, [sp, #0x6c8]
10156a42c:     	str	xzr, [sp, #0x6d0]
10156a430:     	ldr	x8, [sp, #0x48]
10156a434:     	ldr	w9, [x8], #0x4
10156a438:     	str	x8, [sp, #0x48]
10156a43c:     	ldr	x8, [sp, #0x660]
10156a440:     	ldr	x1, [x8, #0x5a0]
10156a444:     	str	x9, [sp, #0x38]
10156a448:     	cmp	x1, x9
10156a44c:     	b.ls	0x10156af08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4224>
10156a450:     	ldr	x8, [x8, #0x598]
10156a454:     	mov	w9, #0x58               ; =88
10156a458:     	ldr	x10, [sp, #0x38]
10156a45c:     	umaddl	x8, w10, w9, x8
10156a460:     	str	x8, [sp, #0x30]
10156a464:     	ldr	w1, [x8, #0x50]
10156a468:     	add	x8, sp, #0x550
10156a46c:     	ldr	x9, [sp, #0x20]
10156a470:     	add	x0, x9, #0xf0
10156a474:     	add	x2, x9, #0x2f8
10156a478:     	bl	0x10156d704 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10156a47c:     	ldr	x8, [sp, #0x550]
10156a480:     	add	x9, sp, #0x550
10156a484:     	ldur	q0, [x9, #0x8]
10156a488:     	ldur	q1, [x9, #0x18]
10156a48c:     	stp	q0, q1, [sp, #0x3f0]
10156a490:     	ldur	q0, [x9, #0x28]
10156a494:     	str	q0, [sp, #0x410]
10156a498:     	ldur	x9, [x9, #0x38]
10156a49c:     	str	x9, [sp, #0x420]
10156a4a0:     	cbz	x8, 0x10156a738 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a54>
10156a4a4:     	ldr	x9, [sp, #0x420]
10156a4a8:     	add	x10, sp, #0x220
10156a4ac:     	stur	x9, [x10, #0x38]
10156a4b0:     	ldr	q0, [sp, #0x410]
10156a4b4:     	stur	q0, [x10, #0x28]
10156a4b8:     	ldp	q1, q0, [sp, #0x3f0]
10156a4bc:     	stur	q0, [x10, #0x18]
10156a4c0:     	stur	q1, [x10, #0x8]
10156a4c4:     	str	x8, [sp, #0x220]
10156a4c8:     	ldr	x8, [sp, #0x228]
10156a4cc:     	ldr	x8, [x8, #0x10]
10156a4d0:     	ldrb	w8, [x8, #0x10]
10156a4d4:     	orr	w8, w8, #0x2
10156a4d8:     	cmp	w8, #0x1b
10156a4dc:     	b.ne	0x10156a9d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cf0>
10156a4e0:     	add	x8, sp, #0x550
10156a4e4:     	add	x0, sp, #0x220
10156a4e8:     	bl	0x1015de6e4 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections12source_count>
10156a4ec:     	ldr	w8, [sp, #0x550]
10156a4f0:     	cmp	w8, #0x6
10156a4f4:     	b.ne	0x10156a780 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a9c>
10156a4f8:     	ldr	x8, [sp, #0x558]
10156a4fc:     	str	x8, [sp, #0x50]
10156a500:     	ldr	x8, [sp, #0x38]
10156a504:     	cmp	x19, x8
10156a508:     	b.ne	0x10156a518 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3834>
10156a50c:     	ldr	x8, [sp, #0x50]
10156a510:     	cmp	x8, x28
10156a514:     	b.ne	0x10156a7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac8>
10156a518:     	ldr	x8, [sp, #0x18]
10156a51c:     	ldr	x9, [sp, #0x50]
10156a520:     	adds	x8, x9, x8
10156a524:     	str	x8, [sp, #0x18]
10156a528:     	b.hs	0x10156ab3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e58>
10156a52c:     	ldr	x8, [sp, #0x50]
10156a530:     	cbz	x8, 0x10156a7c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ae4>
10156a534:     	ldr	x8, [sp, #0x18]
10156a538:     	cmp	x8, x20
10156a53c:     	b.hi	0x10156a7c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ae4>
10156a540:     	ldr	x8, [sp, #0x30]
10156a544:     	ldr	x8, [x8, #0x8]
10156a548:     	str	x8, [sp, #0x8]
10156a54c:     	cbnz	x8, 0x10156a5c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38dc>
10156a550:     	str	xzr, [sp]
10156a554:     	ldr	x9, [sp, #0x8]
10156a558:     	mov	w8, #0x8                ; =8
10156a55c:     	stp	x9, x8, [sp, #0x110]
10156a560:     	str	xzr, [sp, #0x120]
10156a564:     	ldp	q0, q1, [sp, #0x220]
10156a568:     	add	x8, sp, #0x550
10156a56c:     	stur	q0, [x8, #0x18]
10156a570:     	stur	q1, [x8, #0x28]
10156a574:     	ldp	q0, q1, [sp, #0x240]
10156a578:     	stur	q0, [x8, #0x38]
10156a57c:     	stur	q1, [x8, #0x48]
10156a580:     	ldr	q0, [sp, #0x110]
10156a584:     	str	q0, [sp, #0x550]
10156a588:     	ldr	x8, [sp, #0x120]
10156a58c:     	str	x8, [sp, #0x560]
10156a590:     	ldr	x8, [sp, #0x38]
10156a594:     	str	x8, [sp, #0x5a8]
10156a598:     	ldr	x8, [sp, #0x50]
10156a59c:     	str	x8, [sp, #0x5b0]
10156a5a0:     	add	x0, sp, #0x6c0
10156a5a4:     	add	x1, sp, #0x550
10156a5a8:     	bl	0x1015705c0 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionE8push_mutBR_>
10156a5ac:     	ldr	x8, [sp, #0x48]
10156a5b0:     	ldr	x9, [sp, #0x28]
10156a5b4:     	cmp	x8, x9
10156a5b8:     	b.ne	0x10156a430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x374c>
10156a5bc:     	b	0x10156a7e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3afc>
10156a5c0:     	ldr	x8, [sp, #0x30]
10156a5c4:     	ldr	x8, [x8]
10156a5c8:     	str	x8, [sp, #0x10]
10156a5cc:     	add	x0, sp, #0x550
10156a5d0:     	mov	x1, #0x0                ; =0
10156a5d4:     	mov	w2, #0x8                ; =8
10156a5d8:     	ldr	x3, [sp, #0x8]
10156a5dc:     	mov	w4, #0x8                ; =8
10156a5e0:     	mov	w5, #0x48               ; =72
10156a5e4:     	bl	0x1039dccdc <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
10156a5e8:     	ldr	x8, [sp, #0x550]
10156a5ec:     	cmp	x8, #0x1
10156a5f0:     	b.eq	0x10156aa9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3db8>
10156a5f4:     	ldr	x8, [sp, #0x558]
10156a5f8:     	ldr	x10, [sp, #0x8]
10156a5fc:     	and	x9, x10, #0x7fffffffffffff00
10156a600:     	stp	x10, x8, [sp, #0x110]
10156a604:     	str	xzr, [sp, #0x120]
10156a608:     	lsl	x8, x10, #2
10156a60c:     	stp	x9, x8, [sp]
10156a610:     	b	0x10156a648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3964>
10156a614:     	ldr	x8, [x21, #0x28]
10156a618:     	ldr	x9, [sp, #0x30]
10156a61c:     	ldr	x8, [x8, x9, lsl #3]
10156a620:     	str	x8, [sp, #0x558]
10156a624:     	str	w9, [sp, #0x554]
10156a628:     	str	wzr, [sp, #0x550]
10156a62c:     	add	x0, sp, #0x110
10156a630:     	add	x1, sp, #0x550
10156a634:     	bl	0x101570654 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
10156a638:     	ldr	x8, [sp, #0x8]
10156a63c:     	subs	x8, x8, #0x4
10156a640:     	str	x8, [sp, #0x8]
10156a644:     	b.eq	0x10156a564 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3880>
10156a648:     	ldr	x8, [sp, #0x10]
10156a64c:     	ldr	w9, [x8], #0x4
10156a650:     	str	x8, [sp, #0x10]
10156a654:     	ldr	x8, [sp, #0x660]
10156a658:     	ldr	x1, [x8, #0x360]
10156a65c:     	str	x9, [sp, #0x30]
10156a660:     	cmp	x1, x9
10156a664:     	b.ls	0x10156af1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4238>
10156a668:     	ldr	x8, [x8, #0x358]
10156a66c:     	mov	w9, #0x140              ; =320
10156a670:     	ldr	x10, [sp, #0x30]
10156a674:     	umaddl	x8, w10, w9, x8
10156a678:     	ldrb	w8, [x8, #0x124]
10156a67c:     	cmp	w8, #0x7
10156a680:     	b.ne	0x10156a614 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3930>
10156a684:     	add	x8, sp, #0x440
10156a688:     	ldr	x9, [sp, #0x20]
10156a68c:     	add	x0, x9, #0xf0
10156a690:     	add	x2, x9, #0x2f8
10156a694:     	ldr	x1, [sp, #0x30]
10156a698:     	bl	0x10156d704 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10156a69c:     	ldr	x8, [sp, #0x440]
10156a6a0:     	add	x9, sp, #0x440
10156a6a4:     	ldur	q0, [x9, #0x8]
10156a6a8:     	ldur	q1, [x9, #0x18]
10156a6ac:     	stp	q0, q1, [sp, #0xa0]
10156a6b0:     	ldur	q0, [x9, #0x28]
10156a6b4:     	str	q0, [sp, #0xc0]
10156a6b8:     	ldur	x9, [x9, #0x38]
10156a6bc:     	str	x9, [sp, #0xd0]
10156a6c0:     	cbz	x8, 0x10156a980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c9c>
10156a6c4:     	ldp	q0, q1, [sp, #0xa0]
10156a6c8:     	add	x10, sp, #0x550
10156a6cc:     	stp	q0, q1, [x10, #0x10]
10156a6d0:     	ldr	q0, [sp, #0xc0]
10156a6d4:     	stur	q0, [x10, #0x30]
10156a6d8:     	ldr	x9, [sp, #0xd0]
10156a6dc:     	stur	x9, [x10, #0x40]
10156a6e0:     	str	x8, [sp, #0x558]
10156a6e4:     	ldr	x8, [sp, #0x30]
10156a6e8:     	str	w8, [sp, #0x554]
10156a6ec:     	mov	w8, #0x1                ; =1
10156a6f0:     	str	w8, [sp, #0x550]
10156a6f4:     	add	x0, sp, #0x110
10156a6f8:     	add	x1, sp, #0x550
10156a6fc:     	bl	0x101570654 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
10156a700:     	b	0x10156a638 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3954>
10156a704:     	str	wzr, [x23]
10156a708:     	mov	w8, #0xc                ; =12
10156a70c:     	adrp	x9, 0x10754e000 <_anon.0504008e54a1502d122e47b3b8bf1e07.468+0x708>
10156a710:     	add	x9, x9, #0x8b0
10156a714:     	b	0x10156a728 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a44>
10156a718:     	str	wzr, [x23]
10156a71c:     	mov	w8, #0xc                ; =12
10156a720:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156a724:     	add	x9, x9, #0x94c
10156a728:     	stp	x8, x9, [x23, #0x8]
10156a72c:     	mov	w8, #0x1a               ; =26
10156a730:     	str	x8, [x23, #0x18]
10156a734:     	b	0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
10156a738:     	ldp	q0, q1, [sp, #0x3f0]
10156a73c:     	stur	q0, [x27, #0x4]
10156a740:     	stur	q1, [x27, #0x14]
10156a744:     	ldr	q0, [sp, #0x410]
10156a748:     	stur	q0, [x27, #0x24]
10156a74c:     	ldr	x8, [sp, #0x420]
10156a750:     	stur	x8, [x27, #0x34]
10156a754:     	ldr	q0, [sp, #0x550]
10156a758:     	ldr	q1, [sp, #0x560]
10156a75c:     	stur	q0, [x23, #0x4]
10156a760:     	mov	w8, #0x2                ; =2
10156a764:     	str	w8, [x23]
10156a768:     	stur	q1, [x23, #0x14]
10156a76c:     	ldr	q0, [sp, #0x570]
10156a770:     	stur	q0, [x23, #0x24]
10156a774:     	ldur	q0, [x27, #0x2c]
10156a778:     	str	q0, [x23, #0x30]
10156a77c:     	b	0x10156a084 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33a0>
10156a780:     	ldr	w9, [sp, #0x554]
10156a784:     	ldr	x10, [sp, #0x558]
10156a788:     	ldr	q0, [sp, #0x560]
10156a78c:     	ldr	q1, [sp, #0x570]
10156a790:     	stp	q0, q1, [x23, #0x10]
10156a794:     	ldr	q0, [sp, #0x580]
10156a798:     	ldr	q1, [sp, #0x590]
10156a79c:     	stp	q0, q1, [x23, #0x30]
10156a7a0:     	stp	w8, w9, [x23]
10156a7a4:     	str	x10, [x23, #0x8]
10156a7a8:     	b	0x10156a9f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d0c>
10156a7ac:     	str	wzr, [x23]
10156a7b0:     	mov	w8, #0xc                ; =12
10156a7b4:     	strb	w8, [x23, #0x8]
10156a7b8:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156a7bc:     	add	x8, x8, #0x37c
10156a7c0:     	mov	w9, #0x24               ; =36
10156a7c4:     	b	0x10156a9ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d08>
10156a7c8:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
10156a7cc:     	ldr	q0, [x8]
10156a7d0:     	stur	q0, [x23, #0x8]
10156a7d4:     	mov	w8, #0x6                ; =6
10156a7d8:     	str	w8, [x23]
10156a7dc:     	b	0x10156a9f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d0c>
10156a7e0:     	ldr	x8, [sp, #0x18]
10156a7e4:     	cmp	x8, #0x2
10156a7e8:     	b.lo	0x10156a070 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x338c>
10156a7ec:     	ldr	x8, [sp, #0x18]
10156a7f0:     	str	x8, [sp, #0x6d8]
10156a7f4:     	add	x8, x8, x8, lsl #5
10156a7f8:     	lsl	x1, x8, #16
10156a7fc:     	add	x8, sp, #0x550
10156a800:     	add	x0, sp, #0x668
10156a804:     	bl	0x102e34ea4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
10156a808:     	ldr	w8, [sp, #0x550]
10156a80c:     	cmp	w8, #0x1a
10156a810:     	b.ne	0x10156aa28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d44>
10156a814:     	ldur	q0, [x27, #0x8]
10156a818:     	ldur	q1, [x27, #0x18]
10156a81c:     	str	q0, [sp, #0x6e0]
10156a820:     	str	q1, [sp, #0x6f0]
10156a824:     	ldr	x20, [sp, #0x6d0]
10156a828:     	cbnz	x20, 0x10156ab5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e78>
10156a82c:     	mov	x8, #0x0                ; =0
10156a830:     	mov	w9, #0x8                ; =8
10156a834:     	str	x20, [sp, #0x708]
10156a838:     	str	x9, [sp, #0x710]
10156a83c:     	str	xzr, [sp, #0x718]
10156a840:     	ldr	x1, [sp, #0x6c8]
10156a844:     	mov	w9, #0x68               ; =104
10156a848:     	madd	x2, x8, x9, x1
10156a84c:     	mov	w19, #0x1               ; =1
10156a850:     	add	x0, sp, #0x708
10156a854:     	mov	w28, #0x1               ; =1
10156a858:     	bl	0x1014989f4 <__RINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENCNvMs0_B2f_NtB2h_10Invocation12run_parallels9_0EEB2p_>
10156a85c:     	ldr	x2, [sp, #0x710]
10156a860:     	ldr	x3, [sp, #0x718]
10156a864:     	add	x0, sp, #0x550
10156a868:     	ldr	x1, [sp, #0x58]
10156a86c:     	bl	0x10155fd20 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel9admissionNtB6_10Invocation18parallel_admission>
10156a870:     	ldr	w8, [sp, #0x550]
10156a874:     	cmp	w8, #0x6
10156a878:     	b.ne	0x10156aa48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d64>
10156a87c:     	ldr	x8, [sp, #0x558]
10156a880:     	ldr	q0, [sp, #0x560]
10156a884:     	str	q0, [sp, #0x740]
10156a888:     	ldr	x9, [sp, #0x570]
10156a88c:     	str	x9, [sp, #0x750]
10156a890:     	cbz	x8, 0x10156aac0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ddc>
10156a894:     	ldr	q0, [sp, #0x740]
10156a898:     	stur	q0, [x24, #0x8]
10156a89c:     	ldr	x9, [sp, #0x750]
10156a8a0:     	str	x8, [sp, #0x720]
10156a8a4:     	str	x9, [sp, #0x738]
10156a8a8:     	ldr	x0, [sp, #0x660]
10156a8ac:     	add	x8, sp, #0x550
10156a8b0:     	add	x1, sp, #0x668
10156a8b4:     	ldr	x2, [sp, #0x18]
10156a8b8:     	bl	0x10152c1a4 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel17worker_setup_fits>
10156a8bc:     	ldr	w9, [sp, #0x550]
10156a8c0:     	ldrb	w8, [sp, #0x554]
10156a8c4:     	cmp	w9, #0x6
10156a8c8:     	b.ne	0x10156aaf0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e0c>
10156a8cc:     	tbz	w8, #0x0, 0x10156ab24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e40>
10156a8d0:     	ldr	x8, [sp, #0x660]
10156a8d4:     	ldr	x1, [x8, #0x3a0]
10156a8d8:     	ldr	w0, [x22, #0x30]
10156a8dc:     	cmp	x1, x0
10156a8e0:     	b.ls	0x10156af30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x424c>
10156a8e4:     	ldr	x8, [x8, #0x398]
10156a8e8:     	mov	w9, #0x540              ; =1344
10156a8ec:     	umaddl	x8, w0, w9, x8
10156a8f0:     	ldr	w9, [x8, #0x520]
10156a8f4:     	ldr	q0, [x8, #0x510]
10156a8f8:     	stur	q0, [x29, #-0x100]
10156a8fc:     	stur	w9, [x29, #-0xf0]
10156a900:     	add	x8, sp, #0x550
10156a904:     	ldr	x9, [sp, #0x20]
10156a908:     	add	x0, x9, #0x3b8
10156a90c:     	bl	0x102368c08 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
10156a910:     	ldr	x8, [sp, #0x550]
10156a914:     	cmp	x8, #0x1
10156a918:     	b.ne	0x10156abb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ecc>
10156a91c:     	ldr	x1, [sp, #0x558]
10156a920:     	ldr	x2, [sp, #0x560]
10156a924:     	add	x19, sp, #0x550
10156a928:     	add	x8, sp, #0x550
10156a92c:     	ldr	x9, [sp, #0x20]
10156a930:     	add	x0, x9, #0x3b8
10156a934:     	add	x3, sp, #0x668
10156a938:     	bl	0x10236c224 <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget32reserve_worker_group_with_memory>
10156a93c:     	ldrb	w8, [sp, #0x588]
10156a940:     	cmp	w8, #0x2
10156a944:     	b.ne	0x10156abf0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f0c>
10156a948:     	ldr	w8, [sp, #0x550]
10156a94c:     	cmp	w8, #0x1a
10156a950:     	b.ne	0x10156ad9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40b8>
10156a954:     	ldur	w9, [x29, #-0x100]
10156a958:     	ldurb	w8, [x29, #-0xfc]
10156a95c:     	add	x12, sp, #0x720
10156a960:     	ldur	w10, [x12, #0x45]
10156a964:     	str	w10, [sp, #0x110]
10156a968:     	ldur	w11, [x29, #-0xf8]
10156a96c:     	add	x10, sp, #0x110
10156a970:     	stur	w11, [x10, #0x3]
10156a974:     	mov	w10, #0x4               ; =4
10156a978:     	ldur	d0, [x12, #0x4c]
10156a97c:     	b	0x10156ada8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40c4>
10156a980:     	ldp	q0, q1, [sp, #0xa0]
10156a984:     	add	x8, sp, #0x440
10156a988:     	stur	q0, [x8, #0x4]
10156a98c:     	stur	q1, [x8, #0x14]
10156a990:     	ldr	q0, [sp, #0xc0]
10156a994:     	stur	q0, [x8, #0x24]
10156a998:     	ldr	x9, [sp, #0xd0]
10156a99c:     	stur	x9, [x8, #0x34]
10156a9a0:     	ldr	q0, [sp, #0x440]
10156a9a4:     	ldr	q1, [sp, #0x450]
10156a9a8:     	stur	q0, [x23, #0x4]
10156a9ac:     	mov	w9, #0x2                ; =2
10156a9b0:     	str	w9, [x23]
10156a9b4:     	stur	q1, [x23, #0x14]
10156a9b8:     	ldr	q0, [sp, #0x460]
10156a9bc:     	stur	q0, [x23, #0x24]
10156a9c0:     	ldur	q0, [x8, #0x2c]
10156a9c4:     	str	q0, [x23, #0x30]
10156a9c8:     	add	x0, sp, #0x110
10156a9cc:     	bl	0x1015489fc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10156a9d0:     	b	0x10156a9f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d0c>
10156a9d4:     	str	wzr, [x23]
10156a9d8:     	mov	w8, #0xc                ; =12
10156a9dc:     	strb	w8, [x23, #0x8]
10156a9e0:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156a9e4:     	add	x8, x8, #0x3a0
10156a9e8:     	mov	w9, #0x30               ; =48
10156a9ec:     	stp	x8, x9, [x23, #0x10]
10156a9f0:     	add	x0, sp, #0x220
10156a9f4:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10156a9f8:     	b	0x10156a084 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33a0>
10156a9fc:     	mov	w27, #0x1               ; =1
10156aa00:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156aa04:     	add	x2, x2, #0x208
10156aa08:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156aa0c:     	b	0x10156af3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4258>
10156aa10:     	adrp	x2, 0x107f09000 <_anon.61c4a8641e5b3956ea8870164c4e553f.288+0x158>
10156aa14:     	add	x2, x2, #0x420
10156aa18:     	mov	x0, x1
10156aa1c:     	ldr	x1, [sp, #0x28]
10156aa20:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156aa24:     	b	0x10156af3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4258>
10156aa28:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
10156aa2c:     	ldr	q0, [x8]
10156aa30:     	stur	q0, [x23, #0x8]
10156aa34:     	mov	w8, #0x6                ; =6
10156aa38:     	str	w8, [x23]
10156aa3c:     	add	x0, sp, #0x550
10156aa40:     	bl	0x10154808c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
10156aa44:     	b	0x10156a084 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33a0>
10156aa48:     	ldr	w9, [sp, #0x554]
10156aa4c:     	ldr	x10, [sp, #0x558]
10156aa50:     	ldr	q0, [sp, #0x560]
10156aa54:     	str	q0, [sp, #0x740]
10156aa58:     	ldur	q1, [x27, #0x28]
10156aa5c:     	stur	q1, [x23, #0x28]
10156aa60:     	ldur	q1, [x27, #0x38]
10156aa64:     	ldr	x11, [sp, #0x570]
10156aa68:     	ldr	x12, [sp, #0x598]
10156aa6c:     	str	x11, [sp, #0x750]
10156aa70:     	stur	q1, [x23, #0x38]
10156aa74:     	str	x12, [x23, #0x48]
10156aa78:     	str	q0, [x23, #0x10]
10156aa7c:     	str	x11, [x23, #0x20]
10156aa80:     	stp	w8, w9, [x23]
10156aa84:     	str	x10, [x23, #0x8]
10156aa88:     	b	0x10156aad4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3df0>
10156aa8c:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156aa90:     	add	x2, x2, #0x148
10156aa94:     	mov	x0, x20
10156aa98:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156aa9c:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156aaa0:     	add	x8, x8, #0x361
10156aaa4:     	ldr	x9, [sp]
10156aaa8:     	orr	x9, x9, #0xc
10156aaac:     	stp	x9, x8, [x23, #0x8]
10156aab0:     	mov	w8, #0x1b               ; =27
10156aab4:     	str	x8, [x23, #0x18]
10156aab8:     	str	wzr, [x23]
10156aabc:     	b	0x10156a9f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d0c>
10156aac0:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
10156aac4:     	ldr	q0, [x8]
10156aac8:     	stur	q0, [x23, #0x8]
10156aacc:     	mov	w8, #0x6                ; =6
10156aad0:     	str	w8, [x23]
10156aad4:     	ldr	x8, [sp, #0x708]
10156aad8:     	cbz	x8, 0x10156ae48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4164>
10156aadc:     	ldr	x0, [sp, #0x710]
10156aae0:     	lsl	x1, x8, #3
10156aae4:     	mov	w2, #0x8                ; =8
10156aae8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10156aaec:     	b	0x10156ae48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4164>
10156aaf0:     	ldur	q0, [x27, #0x15]
10156aaf4:     	stur	q0, [x23, #0x15]
10156aaf8:     	ldur	q0, [x27, #0x25]
10156aafc:     	stur	q0, [x23, #0x25]
10156ab00:     	ldur	q0, [x27, #0x35]
10156ab04:     	stur	q0, [x23, #0x35]
10156ab08:     	ldr	q0, [sp, #0x590]
10156ab0c:     	str	q0, [x23, #0x40]
10156ab10:     	ldur	q0, [x27, #0x5]
10156ab14:     	stur	q0, [x23, #0x5]
10156ab18:     	str	w9, [x23]
10156ab1c:     	strb	w8, [x23, #0x4]
10156ab20:     	b	0x10156ae20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x413c>
10156ab24:     	adrp	x8, 0x10751a000 <_anon.09ded78d70ea5853fd39a1c0f047bbd7.6+0x303>
10156ab28:     	ldr	q0, [x8]
10156ab2c:     	stur	q0, [x23, #0x8]
10156ab30:     	mov	w8, #0x6                ; =6
10156ab34:     	str	w8, [x23]
10156ab38:     	b	0x10156ae20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x413c>
10156ab3c:     	str	wzr, [x23]
10156ab40:     	mov	w8, #0xc                ; =12
10156ab44:     	adrp	x9, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156ab48:     	add	x9, x9, #0x97d
10156ab4c:     	stp	x8, x9, [x23, #0x8]
10156ab50:     	mov	w8, #0x1c               ; =28
10156ab54:     	str	x8, [x23, #0x18]
10156ab58:     	b	0x10156a9f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d0c>
10156ab5c:     	add	x0, sp, #0x550
10156ab60:     	mov	x1, #0x0                ; =0
10156ab64:     	mov	w2, #0x8                ; =8
10156ab68:     	mov	x3, x20
10156ab6c:     	mov	w4, #0x8                ; =8
10156ab70:     	mov	w5, #0x8                ; =8
10156ab74:     	bl	0x1039dccdc <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
10156ab78:     	ldr	w8, [sp, #0x550]
10156ab7c:     	tbz	w8, #0x0, 0x10156abd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3eec>
10156ab80:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156ab84:     	add	x8, x8, #0x3d0
10156ab88:     	mov	w9, #0xc                ; =12
10156ab8c:     	stp	x9, x8, [x23, #0x8]
10156ab90:     	mov	w8, #0x27               ; =39
10156ab94:     	str	x8, [x23, #0x18]
10156ab98:     	str	wzr, [x23]
10156ab9c:     	b	0x10156ae48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4164>
10156aba0:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156aba4:     	add	x2, x2, #0x118
10156aba8:     	mov	x0, x20
10156abac:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156abb0:     	str	wzr, [x23]
10156abb4:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156abb8:     	add	x8, x8, #0x9dc
10156abbc:     	mov	w9, #0xc                ; =12
10156abc0:     	stp	x9, x8, [x23, #0x8]
10156abc4:     	mov	w8, #0x27               ; =39
10156abc8:     	str	x8, [x23, #0x18]
10156abcc:     	b	0x10156ae20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x413c>
10156abd0:     	ldr	x9, [sp, #0x558]
10156abd4:     	ldr	x8, [sp, #0x6d0]
10156abd8:     	b	0x10156a834 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b50>
10156abdc:     	adrp	x8, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156abe0:     	add	x8, x8, #0x130
10156abe4:     	mov	x0, x2
10156abe8:     	mov	x2, x8
10156abec:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156abf0:     	ldrb	w8, [sp, #0x550]
10156abf4:     	ldr	w9, [sp, #0x554]
10156abf8:     	add	x12, sp, #0x720
10156abfc:     	stur	w9, [x12, #0xb3]
10156ac00:     	ldur	w9, [x27, #0x1]
10156ac04:     	stur	w9, [x29, #-0x90]
10156ac08:     	ldr	q0, [sp, #0x560]
10156ac0c:     	ldr	q1, [sp, #0x570]
10156ac10:     	str	q0, [sp, #0x440]
10156ac14:     	str	q1, [sp, #0x450]
10156ac18:     	ldr	x10, [sp, #0x580]
10156ac1c:     	ldr	x9, [sp, #0x588]
10156ac20:     	sub	x11, x29, #0xe0
10156ac24:     	str	x10, [sp, #0x460]
10156ac28:     	ldr	d0, [sp, #0x558]
10156ac2c:     	ldur	w10, [x12, #0xb3]
10156ac30:     	stur	w10, [x12, #0x93]
10156ac34:     	ldur	w10, [x29, #-0x90]
10156ac38:     	stur	w10, [x29, #-0xb0]
10156ac3c:     	ldr	q1, [sp, #0x440]
10156ac40:     	ldr	q2, [sp, #0x450]
10156ac44:     	ldr	x10, [sp, #0x460]
10156ac48:     	str	x10, [sp, #0x240]
10156ac4c:     	stp	q1, q2, [sp, #0x220]
10156ac50:     	add	x20, sp, #0x720
10156ac54:     	ldur	w10, [x12, #0x93]
10156ac58:     	str	w10, [sp, #0x334]
10156ac5c:     	ldur	w10, [x29, #-0xb0]
10156ac60:     	stur	w10, [x26, #0x1]
10156ac64:     	ldp	q1, q2, [sp, #0x220]
10156ac68:     	ldr	x10, [sp, #0x240]
10156ac6c:     	stp	q1, q2, [sp, #0x340]
10156ac70:     	strb	w8, [sp, #0x330]
10156ac74:     	str	d0, [sp, #0x338]
10156ac78:     	str	x10, [sp, #0x360]
10156ac7c:     	str	x9, [sp, #0x368]
10156ac80:     	ldr	x8, [sp, #0x58]
10156ac84:     	ldr	q0, [x8, #0x4e0]
10156ac88:     	stur	q0, [x27, #0xa8]
10156ac8c:     	ldr	x9, [x8, #0x4f0]
10156ac90:     	ldp	q0, q1, [x8, #0x80]
10156ac94:     	str	q0, [sp, #0x5d0]
10156ac98:     	str	q1, [sp, #0x5e0]
10156ac9c:     	ldr	x10, [x8, #0xa0]
10156aca0:     	str	x9, [sp, #0x608]
10156aca4:     	str	x10, [sp, #0x5f0]
10156aca8:     	ldp	q0, q1, [x8, #0x40]
10156acac:     	str	q0, [sp, #0x590]
10156acb0:     	str	q1, [sp, #0x5a0]
10156acb4:     	ldp	q1, q0, [x8, #0x60]
10156acb8:     	str	q0, [sp, #0x5c0]
10156acbc:     	str	q1, [sp, #0x5b0]
10156acc0:     	ldp	q0, q1, [x8]
10156acc4:     	str	q0, [sp, #0x550]
10156acc8:     	str	q1, [sp, #0x560]
10156accc:     	ldp	q1, q0, [x8, #0x20]
10156acd0:     	str	q0, [sp, #0x580]
10156acd4:     	str	q1, [sp, #0x570]
10156acd8:     	ldr	x8, [sp, #0x40]
10156acdc:     	stp	x8, xzr, [x29, #-0xe8]
10156ace0:     	stur	xzr, [x29, #-0xd8]
10156ace4:     	add	x8, sp, #0x6d8
10156ace8:     	add	x9, sp, #0x6c0
10156acec:     	str	x8, [sp, #0x440]
10156acf0:     	str	x9, [sp, #0x448]
10156acf4:     	add	x8, sp, #0x330
10156acf8:     	add	x9, sp, #0x668
10156acfc:     	str	x8, [sp, #0x450]
10156ad00:     	str	x9, [sp, #0x458]
10156ad04:     	sub	x8, x29, #0x100
10156ad08:     	str	x11, [sp, #0x468]
10156ad0c:     	add	x9, sp, #0x660
10156ad10:     	str	x8, [sp, #0x460]
10156ad14:     	str	x9, [sp, #0x470]
10156ad18:     	sub	x8, x29, #0xe8
10156ad1c:     	add	x9, sp, #0x550
10156ad20:     	str	x8, [sp, #0x478]
10156ad24:     	str	x9, [sp, #0x480]
10156ad28:     	adrp	x1, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156ad2c:     	add	x1, x1, #0x1d8
10156ad30:     	add	x8, sp, #0x110
10156ad34:     	add	x0, sp, #0x440
10156ad38:     	bl	0x1014b2fd4 <__RINvNtNtCsgirOGyZpP7g_3std6thread6scoped5scopeNCNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallelNtBS_10Invocation12run_parallelsc_0INtNtCsgDHHaSskbIF_4core6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIB2P_NtBQ_7ReceiptNtBU_27NativeProgramExecutionErrorEEB4f_EEB10_>
10156ad3c:     	ldp	q0, q1, [sp, #0x330]
10156ad40:     	str	q0, [sp, #0x440]
10156ad44:     	str	q1, [sp, #0x450]
10156ad48:     	ldp	q0, q1, [sp, #0x350]
10156ad4c:     	str	q0, [sp, #0x460]
10156ad50:     	str	q1, [sp, #0x470]
10156ad54:     	mov	w19, #0x1               ; =1
10156ad58:     	add	x8, sp, #0x220
10156ad5c:     	add	x0, sp, #0x440
10156ad60:     	bl	0x10236dc98 <__RNvMs4_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_15NativeWorkGroup29finish_with_credit_statistics>
10156ad64:     	ldr	w8, [sp, #0x220]
10156ad68:     	tbz	w8, #0x0, 0x10156ae54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4170>
10156ad6c:     	ldr	x8, [sp, #0x238]
10156ad70:     	ldr	q0, [sp, #0x240]
10156ad74:     	str	q0, [x23, #0x30]
10156ad78:     	ldur	w10, [x29, #-0x100]
10156ad7c:     	ldur	q0, [x25, #0x8]
10156ad80:     	mov	w11, #0x4               ; =4
10156ad84:     	stp	w11, w10, [x23]
10156ad88:     	ldur	q1, [x20, #0x44]
10156ad8c:     	stur	q1, [x23, #0x8]
10156ad90:     	stur	q0, [x23, #0x18]
10156ad94:     	mov	w9, #0x28               ; =40
10156ad98:     	b	0x10156af8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42a8>
10156ad9c:     	mov	w10, #0x0               ; =0
10156ada0:     	ldr	d0, [sp, #0x550]
10156ada4:     	mov	w8, #0xd                ; =13
10156ada8:     	add	x11, sp, #0x110
10156adac:     	ldur	w11, [x11, #0x3]
10156adb0:     	add	x13, sp, #0x720
10156adb4:     	stur	w11, [x13, #0xb3]
10156adb8:     	ldr	w11, [sp, #0x110]
10156adbc:     	stur	w11, [x29, #-0x90]
10156adc0:     	ldur	q1, [x19, #0x8]
10156adc4:     	ldur	q2, [x19, #0x18]
10156adc8:     	str	q1, [sp, #0x440]
10156adcc:     	str	q2, [sp, #0x450]
10156add0:     	ldur	x11, [x19, #0x28]
10156add4:     	str	x11, [sp, #0x460]
10156add8:     	ldur	w12, [x13, #0xb3]
10156addc:     	stur	w12, [x13, #0x93]
10156ade0:     	ldur	w12, [x29, #-0x90]
10156ade4:     	stur	w12, [x29, #-0xb0]
10156ade8:     	str	x11, [sp, #0x240]
10156adec:     	stp	q1, q2, [sp, #0x220]
10156adf0:     	stur	w12, [x23, #0x9]
10156adf4:     	ldur	w11, [x13, #0x93]
10156adf8:     	str	w11, [x23, #0xc]
10156adfc:     	ldp	q1, q2, [sp, #0x220]
10156ae00:     	stur	q1, [x23, #0x18]
10156ae04:     	stur	q2, [x23, #0x28]
10156ae08:     	ldr	x11, [sp, #0x240]
10156ae0c:     	str	x11, [x23, #0x38]
10156ae10:     	stp	w10, w9, [x23]
10156ae14:     	strb	w8, [x23, #0x8]
10156ae18:     	mov	w19, #0x1               ; =1
10156ae1c:     	str	d0, [x23, #0x10]
10156ae20:     	mov	w28, #0x1               ; =1
10156ae24:     	add	x0, sp, #0x720
10156ae28:     	bl	0x101549acc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10156ae2c:     	ldr	x8, [sp, #0x708]
10156ae30:     	cbz	x8, 0x10156ae44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4160>
10156ae34:     	ldr	x0, [sp, #0x710]
10156ae38:     	lsl	x1, x8, #3
10156ae3c:     	mov	w2, #0x8                ; =8
10156ae40:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10156ae44:     	tbz	w19, #0x0, 0x10156a084 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33a0>
10156ae48:     	add	x0, sp, #0x6e0
10156ae4c:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156ae50:     	b	0x10156a084 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33a0>
10156ae54:     	ldr	x8, [sp, #0x238]
10156ae58:     	ldr	x9, [sp, #0x20]
10156ae5c:     	ldr	x9, [x9, #0x418]
10156ae60:     	adds	x9, x9, x8
10156ae64:     	b.hs	0x10156af40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x425c>
10156ae68:     	ldr	x10, [sp, #0x240]
10156ae6c:     	ldr	x8, [sp, #0x248]
10156ae70:     	ldr	x11, [sp, #0x20]
10156ae74:     	str	x9, [x11, #0x418]
10156ae78:     	ldr	x9, [x11, #0x420]
10156ae7c:     	adds	x9, x9, x10
10156ae80:     	b.hs	0x10156af54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4270>
10156ae84:     	ldr	x10, [sp, #0x20]
10156ae88:     	str	x9, [x10, #0x420]
10156ae8c:     	ldr	x9, [x10, #0x428]
10156ae90:     	adds	x8, x9, x8
10156ae94:     	b.hs	0x10156af70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x428c>
10156ae98:     	ldr	x9, [sp, #0x20]
10156ae9c:     	str	x8, [x9, #0x428]
10156aea0:     	ldr	q0, [sp, #0x6e0]
10156aea4:     	ldr	q1, [sp, #0x6f0]
10156aea8:     	str	q0, [sp, #0x440]
10156aeac:     	str	q1, [sp, #0x450]
10156aeb0:     	mov	w19, #0x0               ; =0
10156aeb4:     	add	x0, sp, #0x440
10156aeb8:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156aebc:     	ldr	w8, [sp, #0x110]
10156aec0:     	cmp	w8, #0x6
10156aec4:     	b.ne	0x10156af9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42b8>
10156aec8:     	mov	x9, #0x0                ; =0
10156aecc:     	add	x8, sp, #0x110
10156aed0:     	ldur	q0, [x8, #0x8]
10156aed4:     	stur	q0, [x29, #-0xd0]
10156aed8:     	ldr	x8, [sp, #0x128]
10156aedc:     	stur	x8, [x29, #-0xc0]
10156aee0:     	ldur	x20, [x29, #-0xc8]
10156aee4:     	mov	w10, #0xc8              ; =200
10156aee8:     	mul	x10, x8, x10
10156aeec:     	add	x21, x20, x10
10156aef0:     	cmp	x10, x9
10156aef4:     	b.eq	0x10156afc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e0>
10156aef8:     	ldr	x11, [x20, x9]
10156aefc:     	add	x9, x9, #0xc8
10156af00:     	cbz	x11, 0x10156aef0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x420c>
10156af04:     	b	0x10156b020 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x433c>
10156af08:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156af0c:     	add	x2, x2, #0x190
10156af10:     	ldr	x0, [sp, #0x38]
10156af14:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156af18:     	b	0x10156af3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4258>
10156af1c:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156af20:     	add	x2, x2, #0x1a8
10156af24:     	ldr	x0, [sp, #0x30]
10156af28:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156af2c:     	b	0x10156af3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4258>
10156af30:     	adrp	x2, 0x107f0a000 <_anon.61c4a8641e5b3956ea8870164c4e553f.664+0x128>
10156af34:     	add	x2, x2, #0x1c0
10156af38:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10156af3c:     	brk	#0x1
10156af40:     	str	wzr, [x23]
10156af44:     	mov	w9, #0xc                ; =12
10156af48:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156af4c:     	add	x10, x10, #0xa03
10156af50:     	b	0x10156af64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4280>
10156af54:     	str	wzr, [x23]
10156af58:     	mov	w9, #0xc                ; =12
10156af5c:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156af60:     	add	x10, x10, #0xa2c
10156af64:     	stp	x9, x10, [x23, #0x8]
10156af68:     	mov	w8, #0x29               ; =41
10156af6c:     	b	0x10156af88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42a4>
10156af70:     	str	wzr, [x23]
10156af74:     	mov	w9, #0xc                ; =12
10156af78:     	adrp	x10, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156af7c:     	add	x10, x10, #0xa55
10156af80:     	stp	x9, x10, [x23, #0x8]
10156af84:     	mov	w8, #0x2b               ; =43
10156af88:     	mov	w9, #0x18               ; =24
10156af8c:     	str	x8, [x23, x9]
10156af90:     	add	x0, sp, #0x110
10156af94:     	bl	0x101547df4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
10156af98:     	b	0x10156ae20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x413c>
10156af9c:     	ldp	q0, q1, [sp, #0x140]
10156afa0:     	stp	q0, q1, [x23, #0x30]
10156afa4:     	add	x9, sp, #0x110
10156afa8:     	ldur	q0, [x9, #0x4]
10156afac:     	stur	q0, [x23, #0x4]
10156afb0:     	ldp	q1, q0, [sp, #0x120]
10156afb4:     	stp	q1, q0, [x23, #0x10]
10156afb8:     	str	w8, [x23]
10156afbc:     	mov	w19, #0x0               ; =0
10156afc0:     	b	0x10156ae20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x413c>
10156afc4:     	ldr	x9, [sp, #0x20]
10156afc8:     	ldr	x9, [x9, #0x440]
10156afcc:     	cmn	x9, #0x1
10156afd0:     	b.eq	0x10156b224 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4540>
10156afd4:     	add	x9, x9, #0x1
10156afd8:     	ldr	x10, [sp, #0x20]
10156afdc:     	str	x9, [x10, #0x440]
10156afe0:     	ldr	x9, [x10, #0x438]
10156afe4:     	ldr	x10, [sp, #0x6d0]
10156afe8:     	adds	x9, x10, x9
10156afec:     	b.hs	0x10156b224 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4540>
10156aff0:     	ldp	x10, x11, [sp, #0x18]
10156aff4:     	str	x9, [x11, #0x438]
10156aff8:     	ldr	x9, [x11, #0x448]
10156affc:     	adds	x9, x9, x10
10156b000:     	b.hs	0x10156b234 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4550>
10156b004:     	ldr	x11, [sp, #0x20]
10156b008:     	str	x9, [x11, #0x448]
10156b00c:     	ldr	x9, [x11, #0x450]
10156b010:     	ldur	x10, [x29, #-0xd8]
10156b014:     	cmp	x10, x9
10156b018:     	csel	x9, x10, x9, hi
10156b01c:     	str	x9, [x11, #0x450]
10156b020:     	mov	w9, #0xc8               ; =200
10156b024:     	mul	x10, x8, x9
10156b028:     	add	x11, x20, #0x60
10156b02c:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b030:     	add	x8, x8, #0xa9d
10156b034:     	mov	w9, #0x17               ; =23
10156b038:     	adrp	x12, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b03c:     	add	x12, x12, #0xab4
10156b040:     	adrp	x13, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b044:     	add	x13, x13, #0xacc
10156b048:     	adrp	x14, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b04c:     	add	x14, x14, #0xae4
10156b050:     	adrp	x15, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b054:     	add	x15, x15, #0xb03
10156b058:     	adrp	x16, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b05c:     	add	x16, x16, #0xb29
10156b060:     	adrp	x17, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b064:     	add	x17, x17, #0xb48
10156b068:     	adrp	x1, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b06c:     	add	x1, x1, #0xb64
10156b070:     	adrp	x2, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b074:     	add	x2, x2, #0xb88
10156b078:     	adrp	x3, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b07c:     	add	x3, x3, #0xbac
10156b080:     	adrp	x4, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b084:     	add	x4, x4, #0xbcb
10156b088:     	adrp	x0, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b08c:     	add	x0, x0, #0xbe8
10156b090:     	adrp	x5, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b094:     	add	x5, x5, #0xc10
10156b098:     	b	0x10156b0a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43c0>
10156b09c:     	sub	x10, x10, #0xc8
10156b0a0:     	add	x11, x11, #0xc8
10156b0a4:     	cbz	x10, 0x10156b244 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4560>
10156b0a8:     	ldur	x6, [x11, #-0x60]
10156b0ac:     	cmp	x6, #0x1
10156b0b0:     	b.eq	0x10156b09c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43b8>
10156b0b4:     	ldr	x6, [sp, #0x20]
10156b0b8:     	ldr	x6, [x6, #0x330]
10156b0bc:     	ldur	x7, [x11, #-0x18]
10156b0c0:     	adds	x6, x7, x6
10156b0c4:     	b.hs	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b0c8:     	ldr	x7, [sp, #0x20]
10156b0cc:     	str	x6, [x7, #0x330]
10156b0d0:     	ldr	x6, [x7, #0x3c8]
10156b0d4:     	ldur	x7, [x11, #-0x10]
10156b0d8:     	adds	x6, x7, x6
10156b0dc:     	b.hs	0x10156b3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4714>
10156b0e0:     	ldr	x7, [sp, #0x20]
10156b0e4:     	str	x6, [x7, #0x3c8]
10156b0e8:     	ldr	x6, [x7, #0x3d0]
10156b0ec:     	ldur	x7, [x11, #-0x8]
10156b0f0:     	adds	x6, x7, x6
10156b0f4:     	b.hs	0x10156b404 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4720>
10156b0f8:     	ldr	x7, [sp, #0x20]
10156b0fc:     	str	x6, [x7, #0x3d0]
10156b100:     	ldr	x6, [x7, #0x3d8]
10156b104:     	ldr	x7, [x11]
10156b108:     	adds	x6, x7, x6
10156b10c:     	b.hs	0x10156b410 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x472c>
10156b110:     	ldr	x7, [sp, #0x20]
10156b114:     	str	x6, [x7, #0x3d8]
10156b118:     	ldr	x6, [x7, #0x3e0]
10156b11c:     	ldr	x7, [x11, #0x8]
10156b120:     	adds	x6, x7, x6
10156b124:     	b.hs	0x10156b41c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4738>
10156b128:     	ldr	x7, [sp, #0x20]
10156b12c:     	str	x6, [x7, #0x3e0]
10156b130:     	ldr	x6, [x7, #0x3e8]
10156b134:     	ldr	x7, [x11, #0x10]
10156b138:     	adds	x6, x7, x6
10156b13c:     	b.hs	0x10156b428 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4744>
10156b140:     	ldr	x7, [sp, #0x20]
10156b144:     	str	x6, [x7, #0x3e8]
10156b148:     	ldr	x6, [x7, #0x3f0]
10156b14c:     	ldr	x7, [x11, #0x18]
10156b150:     	adds	x6, x7, x6
10156b154:     	b.hs	0x10156b434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4750>
10156b158:     	ldr	x7, [sp, #0x20]
10156b15c:     	str	x6, [x7, #0x3f0]
10156b160:     	ldr	x6, [x7, #0x3f8]
10156b164:     	ldr	x7, [x11, #0x20]
10156b168:     	adds	x6, x7, x6
10156b16c:     	b.hs	0x10156b440 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x475c>
10156b170:     	ldr	x7, [sp, #0x20]
10156b174:     	str	x6, [x7, #0x3f8]
10156b178:     	ldr	x6, [x7, #0x400]
10156b17c:     	ldr	x7, [x11, #0x28]
10156b180:     	adds	x6, x7, x6
10156b184:     	b.hs	0x10156b44c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4768>
10156b188:     	ldr	x7, [sp, #0x20]
10156b18c:     	str	x6, [x7, #0x400]
10156b190:     	ldr	x6, [x7, #0x408]
10156b194:     	ldr	x7, [x11, #0x30]
10156b198:     	adds	x6, x7, x6
10156b19c:     	b.hs	0x10156b458 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4774>
10156b1a0:     	ldr	x7, [sp, #0x20]
10156b1a4:     	str	x6, [x7, #0x408]
10156b1a8:     	ldr	x6, [x7, #0x410]
10156b1ac:     	ldr	x7, [x11, #0x38]
10156b1b0:     	adds	x6, x7, x6
10156b1b4:     	b.hs	0x10156b464 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4780>
10156b1b8:     	ldr	x7, [sp, #0x20]
10156b1bc:     	str	x6, [x7, #0x410]
10156b1c0:     	ldr	x6, [x7, #0x418]
10156b1c4:     	ldr	x7, [x11, #0x40]
10156b1c8:     	adds	x6, x7, x6
10156b1cc:     	b.hs	0x10156b470 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x478c>
10156b1d0:     	ldr	x7, [sp, #0x20]
10156b1d4:     	str	x6, [x7, #0x418]
10156b1d8:     	ldr	x6, [x7, #0x420]
10156b1dc:     	ldr	x7, [x11, #0x48]
10156b1e0:     	adds	x6, x7, x6
10156b1e4:     	b.hs	0x10156b470 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x478c>
10156b1e8:     	ldr	x7, [sp, #0x20]
10156b1ec:     	str	x6, [x7, #0x420]
10156b1f0:     	ldr	x6, [x7, #0x428]
10156b1f4:     	ldr	x7, [x11, #0x50]
10156b1f8:     	adds	x6, x7, x6
10156b1fc:     	b.hs	0x10156b470 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x478c>
10156b200:     	ldr	x7, [sp, #0x20]
10156b204:     	str	x6, [x7, #0x428]
10156b208:     	ldr	x6, [x7, #0x430]
10156b20c:     	ldr	x7, [x11, #0x58]
10156b210:     	adds	x6, x7, x6
10156b214:     	b.hs	0x10156b47c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4798>
10156b218:     	ldr	x7, [sp, #0x20]
10156b21c:     	str	x6, [x7, #0x430]
10156b220:     	b	0x10156b09c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43b8>
10156b224:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b228:     	add	x8, x8, #0xa80
10156b22c:     	mov	w9, #0x1d               ; =29
10156b230:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b234:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b238:     	add	x8, x8, #0x97d
10156b23c:     	mov	w9, #0x1c               ; =28
10156b240:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b244:     	stp	xzr, xzr, [x29, #-0xa0]
10156b248:     	mov	w8, #0x8                ; =8
10156b24c:     	stp	xzr, x8, [x29, #-0xb0]
10156b250:     	ldr	x1, [sp, #0x6d0]
10156b254:     	sub	x0, x29, #0xb0
10156b258:     	bl	0x10157024c <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE17try_reserve_exactB1h_>
10156b25c:     	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10156b260:     	cmp	x0, x8
10156b264:     	b.ne	0x10156b498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47b4>
10156b268:     	ldur	x8, [x29, #-0xb0]
10156b26c:     	ldr	x9, [sp, #0x6d0]
10156b270:     	cmp	x8, x9
10156b274:     	b.ne	0x10156b4a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47c4>
10156b278:     	ldr	x9, [sp, #0x6c8]
10156b27c:     	ldr	x10, [sp, #0x6c0]
10156b280:     	mov	w11, #0x68              ; =104
10156b284:     	madd	x22, x8, x11, x9
10156b288:     	stp	x9, x9, [x29, #-0x90]
10156b28c:     	stp	x10, x22, [x29, #-0x80]
10156b290:     	cbz	x8, 0x10156b344 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4660>
10156b294:     	add	x24, sp, #0x440
10156b298:     	add	x19, x9, #0x68
10156b29c:     	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
10156b2a0:     	mov	x26, x19
10156b2a4:     	ldr	x8, [x26, #-0x68]!
10156b2a8:     	cmp	x8, x25
10156b2ac:     	b.eq	0x10156b340 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x465c>
10156b2b0:     	str	x8, [sp, #0x440]
10156b2b4:     	ldur	q0, [x26, #0x58]
10156b2b8:     	stur	q0, [x24, #0x58]
10156b2bc:     	ldur	q0, [x26, #0x28]
10156b2c0:     	stur	q0, [x24, #0x28]
10156b2c4:     	ldur	q0, [x26, #0x38]
10156b2c8:     	stur	q0, [x24, #0x38]
10156b2cc:     	ldur	q0, [x26, #0x48]
10156b2d0:     	stur	q0, [x24, #0x48]
10156b2d4:     	ldur	q0, [x26, #0x8]
10156b2d8:     	stur	q0, [x24, #0x8]
10156b2dc:     	ldur	q0, [x26, #0x18]
10156b2e0:     	stur	q0, [x24, #0x18]
10156b2e4:     	ldr	x8, [sp, #0x498]
10156b2e8:     	ldr	x9, [sp, #0x4a0]
10156b2ec:     	ldur	q0, [x26, #0x18]
10156b2f0:     	str	q0, [sp, #0x220]
10156b2f4:     	ldur	q0, [x26, #0x28]
10156b2f8:     	str	q0, [sp, #0x230]
10156b2fc:     	ldur	q0, [x26, #0x38]
10156b300:     	str	q0, [sp, #0x240]
10156b304:     	ldur	q0, [x26, #0x48]
10156b308:     	str	q0, [sp, #0x250]
10156b30c:     	str	x8, [sp, #0x260]
10156b310:     	str	xzr, [sp, #0x268]
10156b314:     	str	x9, [sp, #0x270]
10156b318:     	sub	x0, x29, #0xb0
10156b31c:     	add	x1, sp, #0x220
10156b320:     	bl	0x1015701b0 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE13push_back_mutB1h_>
10156b324:     	add	x0, sp, #0x440
10156b328:     	bl	0x1015489fc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10156b32c:     	add	x19, x26, #0xd0
10156b330:     	add	x8, x26, #0x68
10156b334:     	cmp	x8, x22
10156b338:     	b.ne	0x10156b2a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x45bc>
10156b33c:     	mov	x19, x22
10156b340:     	stur	x19, [x29, #-0x88]
10156b344:     	sub	x0, x29, #0x90
10156b348:     	bl	0x1014c2bec <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
10156b34c:     	ldp	q0, q1, [x29, #-0xb0]
10156b350:     	str	q0, [sp, #0x440]
10156b354:     	str	q1, [sp, #0x450]
10156b358:     	ldur	x24, [x29, #-0xd0]
10156b35c:     	ldr	q0, [sp, #0x680]
10156b360:     	ldr	q1, [sp, #0x690]
10156b364:     	stp	q0, q1, [sp, #0x220]
10156b368:     	ldr	q0, [sp, #0x6a0]
10156b36c:     	ldr	q1, [sp, #0x6b0]
10156b370:     	stp	q0, q1, [x29, #-0x90]
10156b374:     	ldr	x8, [sp, #0x58]
10156b378:     	add	x0, x8, #0x3c0
10156b37c:     	bl	0x101547b00 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
10156b380:     	ldr	q0, [sp, #0x440]
10156b384:     	ldr	q1, [sp, #0x450]
10156b388:     	ldr	x8, [sp, #0x58]
10156b38c:     	stp	q0, q1, [x8, #0x3c0]
10156b390:     	ldp	q0, q1, [sp, #0x220]
10156b394:     	str	q0, [x8, #0x400]
10156b398:     	str	q1, [x8, #0x410]
10156b39c:     	ldp	q0, q1, [x29, #-0x90]
10156b3a0:     	str	q0, [x8, #0x420]
10156b3a4:     	str	x20, [x8, #0x3e0]
10156b3a8:     	str	x20, [x8, #0x3e8]
10156b3ac:     	str	x24, [x8, #0x3f0]
10156b3b0:     	str	x21, [x8, #0x3f8]
10156b3b4:     	str	q1, [x8, #0x430]
10156b3b8:     	mov	w8, #0x1                ; =1
10156b3bc:     	dup.2d	v0, x8
10156b3c0:     	stur	q0, [x23, #0x8]
10156b3c4:     	mov	w8, #0x6                ; =6
10156b3c8:     	str	w8, [x23]
10156b3cc:     	mov	w19, #0x0               ; =0
10156b3d0:     	mov	w28, #0x0               ; =0
10156b3d4:     	add	x0, sp, #0x720
10156b3d8:     	bl	0x101549acc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10156b3dc:     	ldr	x8, [sp, #0x708]
10156b3e0:     	cbz	x8, 0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
10156b3e4:     	ldr	x0, [sp, #0x710]
10156b3e8:     	lsl	x1, x8, #3
10156b3ec:     	mov	w2, #0x8                ; =8
10156b3f0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10156b3f4:     	b	0x10156a30c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
10156b3f8:     	mov	x8, x12
10156b3fc:     	mov	w9, #0x18               ; =24
10156b400:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b404:     	mov	x8, x13
10156b408:     	mov	w9, #0x18               ; =24
10156b40c:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b410:     	mov	x8, x14
10156b414:     	mov	w9, #0x1f               ; =31
10156b418:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b41c:     	mov	x8, x15
10156b420:     	mov	w9, #0x26               ; =38
10156b424:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b428:     	mov	x8, x16
10156b42c:     	mov	w9, #0x1f               ; =31
10156b430:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b434:     	mov	x8, x17
10156b438:     	mov	w9, #0x1c               ; =28
10156b43c:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b440:     	mov	x8, x1
10156b444:     	mov	w9, #0x24               ; =36
10156b448:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b44c:     	mov	x8, x2
10156b450:     	mov	w9, #0x24               ; =36
10156b454:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b458:     	mov	x8, x3
10156b45c:     	mov	w9, #0x1f               ; =31
10156b460:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b464:     	mov	x8, x4
10156b468:     	mov	w9, #0x1d               ; =29
10156b46c:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b470:     	mov	x8, x0
10156b474:     	mov	w9, #0x28               ; =40
10156b478:     	b	0x10156b484 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
10156b47c:     	mov	x8, x5
10156b480:     	mov	w9, #0x21               ; =33
10156b484:     	str	wzr, [x23]
10156b488:     	mov	w10, #0xc               ; =12
10156b48c:     	stp	x10, x8, [x23, #0x8]
10156b490:     	str	x9, [x23, #0x18]
10156b494:     	b	0x10156b4cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47e8>
10156b498:     	adrp	x8, 0x10754f000 <_anon.61c4a8641e5b3956ea8870164c4e553f.64+0x5de>
10156b49c:     	add	x8, x8, #0x999
10156b4a0:     	mov	w9, #0x21               ; =33
10156b4a4:     	b	0x10156b4b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47d0>
10156b4a8:     	adrp	x8, 0x107552000 <_anon.61c4a8641e5b3956ea8870164c4e553f.582+0x992>
10156b4ac:     	add	x8, x8, #0x3f7
10156b4b0:     	mov	w9, #0x30               ; =48
10156b4b4:     	str	wzr, [x23]
10156b4b8:     	mov	w10, #0xc               ; =12
10156b4bc:     	strb	w10, [x23, #0x8]
10156b4c0:     	stp	x8, x9, [x23, #0x10]
10156b4c4:     	sub	x0, x29, #0xb0
10156b4c8:     	bl	0x101549284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
10156b4cc:     	sub	x0, x29, #0xd0
10156b4d0:     	bl	0x101548780 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
10156b4d4:     	mov	w19, #0x0               ; =0
10156b4d8:     	b	0x10156ae20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x413c>
10156b4dc:     	mov	x22, x0
10156b4e0:     	mov	w19, #0x0               ; =0
10156b4e4:     	b	0x10156b5cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48e8>
10156b4e8:     	mov	x22, x0
10156b4ec:     	mov	w28, #0x1               ; =1
10156b4f0:     	b	0x10156b584 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48a0>
10156b4f4:     	mov	x22, x0
10156b4f8:     	mov	x23, x28
10156b4fc:     	b	0x10156b5dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48f8>
10156b500:     	mov	x22, x0
10156b504:     	mov	w19, #0x0               ; =0
10156b508:     	mov	w28, #0x0               ; =0
10156b50c:     	mov	w23, #0x0               ; =0
10156b510:     	ldr	q0, [sp, #0x440]
10156b514:     	ldr	q1, [sp, #0x450]
10156b518:     	ldr	x8, [sp, #0x58]
10156b51c:     	stp	q0, q1, [x8, #0x3c0]
10156b520:     	ldp	q0, q1, [sp, #0x220]
10156b524:     	str	q0, [x8, #0x400]
10156b528:     	str	q1, [x8, #0x410]
10156b52c:     	ldp	q0, q1, [x29, #-0x90]
10156b530:     	str	q0, [x8, #0x420]
10156b534:     	str	x20, [x8, #0x3e0]
10156b538:     	str	x20, [x8, #0x3e8]
10156b53c:     	str	x24, [x8, #0x3f0]
10156b540:     	str	x21, [x8, #0x3f8]
10156b544:     	str	q1, [x8, #0x430]
10156b548:     	b	0x10156b5d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48f0>
10156b54c:     	mov	x22, x0
10156b550:     	b	0x10156b578 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4894>
10156b554:     	mov	x22, x0
10156b558:     	stur	x19, [x29, #-0x88]
10156b55c:     	b	0x10156b570 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x488c>
10156b560:     	mov	x22, x0
10156b564:     	stur	x19, [x29, #-0x88]
10156b568:     	add	x0, sp, #0x440
10156b56c:     	bl	0x1015489fc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10156b570:     	sub	x0, x29, #0x90
10156b574:     	bl	0x1014c2bec <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
10156b578:     	sub	x0, x29, #0xb0
10156b57c:     	bl	0x101549284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
10156b580:     	mov	w28, #0x0               ; =0
10156b584:     	sub	x0, x29, #0xd0
10156b588:     	bl	0x101548780 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
10156b58c:     	mov	w19, #0x0               ; =0
10156b590:     	b	0x10156b5d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48ec>
10156b594:     	mov	x22, x0
10156b598:     	b	0x10156b5c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48e4>
10156b59c:     	mov	x22, x0
10156b5a0:     	b	0x10156b5c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48e4>
10156b5a4:     	b	0x10156b60c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4928>
10156b5a8:     	b	0x10156b630 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x494c>
10156b5ac:     	mov	x22, x0
10156b5b0:     	add	x0, sp, #0x110
10156b5b4:     	bl	0x101547df4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
10156b5b8:     	b	0x10156b5cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48e8>
10156b5bc:     	mov	x22, x0
10156b5c0:     	add	x0, sp, #0x330
10156b5c4:     	bl	0x10154a570 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers15NativeWorkGroupECs7fdMCt8k5K6_8mech_gpu>
10156b5c8:     	mov	w19, #0x1               ; =1
10156b5cc:     	mov	w28, #0x1               ; =1
10156b5d0:     	mov	w23, #0x1               ; =1
10156b5d4:     	add	x0, sp, #0x720
10156b5d8:     	bl	0x101549acc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10156b5dc:     	ldr	x8, [sp, #0x708]
10156b5e0:     	cbz	x8, 0x10156b5f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4910>
10156b5e4:     	ldr	x0, [sp, #0x710]
10156b5e8:     	lsl	x1, x8, #3
10156b5ec:     	mov	w2, #0x8                ; =8
10156b5f0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10156b5f4:     	tbz	w19, #0x0, 0x10156b600 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x491c>
10156b5f8:     	add	x0, sp, #0x6e0
10156b5fc:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156b600:     	tbnz	w28, #0x0, 0x10156b638 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4954>
10156b604:     	b	0x10156b640 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x495c>
10156b608:     	b	0x10156b620 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x493c>
10156b60c:     	mov	x22, x0
10156b610:     	add	x0, sp, #0x110
10156b614:     	bl	0x1015489fc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10156b618:     	b	0x10156b624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4940>
10156b61c:     	b	0x10156b630 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x494c>
10156b620:     	mov	x22, x0
10156b624:     	add	x0, sp, #0x220
10156b628:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10156b62c:     	b	0x10156b634 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4950>
10156b630:     	mov	x22, x0
10156b634:     	mov	w23, #0x1               ; =1
10156b638:     	add	x0, sp, #0x6c0
10156b63c:     	bl	0x101548918 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
10156b640:     	tbnz	w23, #0x0, 0x10156b64c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4968>
10156b644:     	b	0x10156b688 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49a4>
10156b648:     	mov	x22, x0
10156b64c:     	add	x0, sp, #0x6a0
10156b650:     	bl	0x101549acc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10156b654:     	b	0x10156b65c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4978>
10156b658:     	mov	x22, x0
10156b65c:     	add	x0, sp, #0x680
10156b660:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156b664:     	b	0x10156b688 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49a4>
10156b668:     	mov	x22, x0
10156b66c:     	add	x1, sp, #0x550
10156b670:     	mov	x0, x20
10156b674:     	mov	w2, #0x108              ; =264
10156b678:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
10156b67c:     	mov	w19, #0x0               ; =0
10156b680:     	b	0x10156b708 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a24>
10156b684:     	mov	x22, x0
10156b688:     	ldr	x8, [sp, #0x668]
10156b68c:     	mov	x9, #-0x1               ; =-1
10156b690:     	ldaddl	x9, x8, [x8]
10156b694:     	cmp	x8, #0x1
10156b698:     	b.ne	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b69c:     	dmb	ishld
10156b6a0:     	add	x0, sp, #0x668
10156b6a4:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10156b6a8:     	b	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b6ac:     	mov	x22, x0
10156b6b0:     	ldr	x8, [sp, #0x550]
10156b6b4:     	mov	x9, #-0x1               ; =-1
10156b6b8:     	ldaddl	x9, x8, [x8]
10156b6bc:     	cmp	x8, #0x1
10156b6c0:     	b.ne	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b6c4:     	dmb	ishld
10156b6c8:     	add	x0, sp, #0x550
10156b6cc:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10156b6d0:     	b	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b6d4:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10156b6d8:     	mov	x22, x0
10156b6dc:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10156b6e0:     	str	x8, [x20]
10156b6e4:     	b	0x10156b71c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a38>
10156b6e8:     	mov	x22, x0
10156b6ec:     	add	x0, sp, #0x440
10156b6f0:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10156b6f4:     	b	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b6f8:     	mov	x22, x0
10156b6fc:     	tbnz	w19, #0x0, 0x10156b768 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
10156b700:     	b	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b704:     	mov	x22, x0
10156b708:     	sub	x0, x29, #0x90
10156b70c:     	bl	0x101549b44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10156b710:     	b	0x10156b744 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a60>
10156b714:     	mov	x22, x0
10156b718:     	mov	x26, x27
10156b71c:     	cbz	w26, 0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b720:     	ldr	x8, [sp, #0x550]
10156b724:     	cbz	x8, 0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b728:     	add	x0, sp, #0x550
10156b72c:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10156b730:     	b	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b734:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10156b738:     	mov	x22, x0
10156b73c:     	b	0x10156b768 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a84>
10156b740:     	mov	x22, x0
10156b744:     	ldur	x8, [x29, #-0xb0]
10156b748:     	mov	x9, #-0x1               ; =-1
10156b74c:     	ldaddl	x9, x8, [x8]
10156b750:     	cmp	x8, #0x1
10156b754:     	b.ne	0x10156b764 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a80>
10156b758:     	dmb	ishld
10156b75c:     	sub	x0, x29, #0xb0
10156b760:     	bl	0x102d65de0 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10156b764:     	tbz	w19, #0x0, 0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b768:     	add	x0, sp, #0x220
10156b76c:     	bl	0x10154a790 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
10156b770:     	b	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b774:     	mov	x22, x0
10156b778:     	add	x0, sp, #0x60
10156b77c:     	bl	0x101549d6c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10156b780:     	b	0x10156b7b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4acc>
10156b784:     	bl	0x103a02888 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10156b788:     	mov	w8, #0x2                ; =2
10156b78c:     	str	x8, [x20, #0x220]
10156b790:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
10156b794:     	mov	w8, #0x2                ; =2
10156b798:     	str	x8, [x20, #0x220]
10156b79c:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
10156b7a0:     	mov	x22, x0
10156b7a4:     	ldr	w8, [sp, #0x550]
10156b7a8:     	cmp	w8, #0x6
10156b7ac:     	b.ne	0x10156b7b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ad4>
10156b7b0:     	mov	x0, x22
10156b7b4:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
10156b7b8:     	add	x0, sp, #0x550
10156b7bc:     	bl	0x10154a66c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10156b7c0:     	mov	x0, x22
10156b7c4:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
