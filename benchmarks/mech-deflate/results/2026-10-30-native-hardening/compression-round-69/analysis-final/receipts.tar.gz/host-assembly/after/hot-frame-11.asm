
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010160d474 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>:
10160d474:     	sub	sp, sp, #0x1d0
10160d478:     	stp	x28, x27, [sp, #0x170]
10160d47c:     	stp	x26, x25, [sp, #0x180]
10160d480:     	stp	x24, x23, [sp, #0x190]
10160d484:     	stp	x22, x21, [sp, #0x1a0]
10160d488:     	stp	x20, x19, [sp, #0x1b0]
10160d48c:     	stp	x29, x30, [sp, #0x1c0]
10160d490:     	add	x29, sp, #0x1c0
10160d494:     	mov	x25, x6
10160d498:     	mov	x26, x4
10160d49c:     	mov	x23, x3
10160d4a0:     	mov	x22, x2
10160d4a4:     	mov	x24, x1
10160d4a8:     	mov	x20, x0
10160d4ac:     	mov	x19, x8
10160d4b0:     	ldr	x21, [x29, #0x10]
10160d4b4:     	stp	x5, x6, [sp]
10160d4b8:     	str	x7, [sp, #0x10]
10160d4bc:     	add	x27, sp, #0x80
10160d4c0:     	ldr	w0, [x0, #0x110]
10160d4c4:     	add	x8, sp, #0xc8
10160d4c8:     	mov	x1, x21
10160d4cc:     	bl	0x1026c6724 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
10160d4d0:     	ldrb	w8, [sp, #0xc8]
10160d4d4:     	cmp	w8, #0x29
10160d4d8:     	b.ne	0x10160d61c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1a8>
10160d4dc:     	ldr	x28, [x20, #0x1d8]
10160d4e0:     	cbz	x28, 0x10160d644 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1d0>
10160d4e4:     	mov	w27, #0x2c              ; =44
10160d4e8:     	strb	w27, [sp, #0xc8]
10160d4ec:     	add	x0, sp, #0xc8
10160d4f0:     	bl	0x10160fd10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10160d4f4:     	cmp	x22, x26
10160d4f8:     	b.ne	0x10160d63c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1c8>
10160d4fc:     	ldr	x8, [x20, #0x78]
10160d500:     	cmp	x22, x8
10160d504:     	b.ne	0x10160d63c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1c8>
10160d508:     	cmp	x25, #0x0
10160d50c:     	cset	w8, eq
10160d510:     	ldr	x9, [x20, #0x10]
10160d514:     	cmp	x9, #0xb
10160d518:     	cset	w9, eq
10160d51c:     	cmp	w8, w9
10160d520:     	b.eq	0x10160d63c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1c8>
10160d524:     	ldp	x8, x9, [x28, #0x10]
10160d528:     	stp	x8, x9, [sp, #0x18]
10160d52c:     	stp	x24, x22, [sp, #0x28]
10160d530:     	stp	x23, x22, [sp, #0x38]
10160d534:     	mov	x10, sp
10160d538:     	str	x10, [sp, #0x48]
10160d53c:     	ldr	x10, [x21, #0x60]
10160d540:     	cmp	x10, #0x1
10160d544:     	b.ne	0x10160d6a4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x230>
10160d548:     	ldr	w10, [x21, #0x50]
10160d54c:     	add	x22, sp, #0x80
10160d550:     	tbz	w10, #0x0, 0x10160d6b0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x23c>
10160d554:     	ldp	x11, x10, [x29, #0x18]
10160d558:     	ldr	x12, [x21, #0x68]
10160d55c:     	ldr	x13, [x21, #0x58]
10160d560:     	ldp	x14, x15, [x28, #0x20]
10160d564:     	add	x16, x28, #0x50
10160d568:     	add	x17, x28, #0x30
10160d56c:     	add	x0, x28, #0x38
10160d570:     	add	x1, x28, #0x40
10160d574:     	add	x2, x28, #0x48
10160d578:     	stp	x12, x13, [sp, #0xb8]
10160d57c:     	add	x12, sp, #0xb8
10160d580:     	stp	x11, x12, [sp, #0xc8]
10160d584:     	add	x12, sp, #0xc0
10160d588:     	stp	x12, x11, [sp, #0xd8]
10160d58c:     	stp	x21, x10, [sp, #0xe8]
10160d590:     	stp	x8, x9, [sp, #0xf8]
10160d594:     	stp	x14, x15, [sp, #0x108]
10160d598:     	stp	x16, x28, [sp, #0x118]
10160d59c:     	stp	x17, x0, [sp, #0x128]
10160d5a0:     	stp	x1, x2, [sp, #0x138]
10160d5a4:     	add	x8, sp, #0x8
10160d5a8:     	stp	x8, x20, [sp, #0x148]
10160d5ac:     	add	x8, sp, #0x18
10160d5b0:     	str	x8, [sp, #0x158]
10160d5b4:     	adrp	x0, 0x107f06000 <_anon.682fd0544a42ca3c24ee8b869371118d.262+0x2b0>
10160d5b8:     	add	x0, x0, #0x918
10160d5bc:     	add	x8, sp, #0x80
10160d5c0:     	add	x1, sp, #0xc8
10160d5c4:     	bl	0x10158fabc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
10160d5c8:     	ldrb	w8, [sp, #0x80]
10160d5cc:     	cmp	w8, #0x2f
10160d5d0:     	b.ne	0x10160d66c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1f8>
10160d5d4:     	ldur	q0, [x22, #0x8]
10160d5d8:     	stur	q0, [sp, #0x57]
10160d5dc:     	ldur	q1, [x22, #0x18]
10160d5e0:     	stur	q1, [sp, #0x67]
10160d5e4:     	ldr	x8, [sp, #0xa8]
10160d5e8:     	stur	x8, [sp, #0x77]
10160d5ec:     	stur	q0, [x22, #0x4f]
10160d5f0:     	stur	q1, [x22, #0x5f]
10160d5f4:     	stur	x8, [x22, #0x6f]
10160d5f8:     	mov	w8, #0x29               ; =41
10160d5fc:     	strb	w8, [x19]
10160d600:     	ldur	q0, [x22, #0x48]
10160d604:     	stur	q0, [x19, #0x1]
10160d608:     	ldur	q0, [x22, #0x58]
10160d60c:     	stur	q0, [x19, #0x11]
10160d610:     	ldur	q0, [x22, #0x67]
10160d614:     	str	q0, [x19, #0x20]
10160d618:     	b	0x10160d64c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1d8>
10160d61c:     	ldur	q0, [x27, #0x48]
10160d620:     	ldur	q1, [x27, #0x58]
10160d624:     	stp	q0, q1, [x19]
10160d628:     	ldur	q0, [x27, #0x68]
10160d62c:     	str	q0, [x19, #0x20]
10160d630:     	ldr	x8, [sp, #0xf8]
10160d634:     	str	x8, [x19, #0x30]
10160d638:     	b	0x10160d64c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1d8>
10160d63c:     	strb	w27, [x19]
10160d640:     	b	0x10160d64c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1d8>
10160d644:     	mov	w8, #0x2c               ; =44
10160d648:     	strb	w8, [x19]
10160d64c:     	ldp	x29, x30, [sp, #0x1c0]
10160d650:     	ldp	x20, x19, [sp, #0x1b0]
10160d654:     	ldp	x22, x21, [sp, #0x1a0]
10160d658:     	ldp	x24, x23, [sp, #0x190]
10160d65c:     	ldp	x26, x25, [sp, #0x180]
10160d660:     	ldp	x28, x27, [sp, #0x170]
10160d664:     	add	sp, sp, #0x1d0
10160d668:     	ret
10160d66c:     	ldr	q0, [sp, #0xa0]
10160d670:     	stur	q0, [sp, #0x6f]
10160d674:     	ldur	q0, [x22, #0x11]
10160d678:     	ldur	q1, [x22, #0x1]
10160d67c:     	stp	q1, q0, [sp, #0x50]
10160d680:     	ldr	x9, [sp, #0xb0]
10160d684:     	strb	w8, [x19]
10160d688:     	stur	q1, [x19, #0x1]
10160d68c:     	ldr	q0, [sp, #0x60]
10160d690:     	stur	q0, [x19, #0x11]
10160d694:     	ldur	q0, [sp, #0x6f]
10160d698:     	str	q0, [x19, #0x20]
10160d69c:     	str	x9, [x19, #0x30]
10160d6a0:     	b	0x10160d64c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1d8>
10160d6a4:     	adrp	x0, 0x107f0f000 <_anon.a02778dc867cb483339b5a31950e5a45.359+0x58>
10160d6a8:     	add	x0, x0, #0x3d8
10160d6ac:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10160d6b0:     	adrp	x0, 0x107f0f000 <_anon.a02778dc867cb483339b5a31950e5a45.359+0x58>
10160d6b4:     	add	x0, x0, #0x3f0
10160d6b8:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
