
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014c3b88 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_>:
1014c3b88:     	sub	sp, sp, #0x150
1014c3b8c:     	stp	x28, x27, [sp, #0xf0]
1014c3b90:     	stp	x26, x25, [sp, #0x100]
1014c3b94:     	stp	x24, x23, [sp, #0x110]
1014c3b98:     	stp	x22, x21, [sp, #0x120]
1014c3b9c:     	stp	x20, x19, [sp, #0x130]
1014c3ba0:     	stp	x29, x30, [sp, #0x140]
1014c3ba4:     	add	x29, sp, #0x140
1014c3ba8:     	mov	x21, x2
1014c3bac:     	mov	x24, x1
1014c3bb0:     	str	x8, [sp, #0x40]
1014c3bb4:     	ldr	x8, [x0, #0x8]
1014c3bb8:     	str	x0, [sp, #0x50]
1014c3bbc:     	cbz	x8, 0x1014c3d4c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1c4>
1014c3bc0:     	ldr	x20, [x0]
1014c3bc4:     	lsl	x22, x8, #2
1014c3bc8:     	ldp	x8, x19, [x24, #0x10]
1014c3bcc:     	add	x10, x8, #0x10
1014c3bd0:     	ldp	x25, x8, [x21]
1014c3bd4:     	ldp	x9, x11, [x21, #0x28]
1014c3bd8:     	stp	x11, x9, [sp, #0x28]
1014c3bdc:     	ldp	x9, x11, [x21, #0x10]
1014c3be0:     	str	x11, [sp, #0x38]
1014c3be4:     	stp	x10, x9, [sp, #0x18]
1014c3be8:     	stp	x8, x19, [sp, #0x8]
1014c3bec:     	add	x26, x8, #0x1
1014c3bf0:     	mov	w8, #0x2c               ; =44
1014c3bf4:     	ldr	w23, [x20], #0x4
1014c3bf8:     	cmp	x19, x23
1014c3bfc:     	b.ls	0x1014c40b4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c3c00:     	strb	w8, [sp, #0x90]
1014c3c04:     	add	x0, sp, #0x90
1014c3c08:     	bl	0x1014c709c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c3c0c:     	sub	x26, x26, #0x1
1014c3c10:     	cbz	x26, 0x1014c4138 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5b0>
1014c3c14:     	ldrb	w8, [x25]
1014c3c18:     	cmp	w8, #0x3
1014c3c1c:     	b.ne	0x1014c3c50 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0xc8>
1014c3c20:     	ldr	x0, [x25, #0x8]
1014c3c24:     	ldr	x8, [sp, #0x38]
1014c3c28:     	cmp	x0, x8
1014c3c2c:     	b.hs	0x1014c417c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5f4>
1014c3c30:     	ldr	x8, [sp, #0x30]
1014c3c34:     	cmp	x0, x8
1014c3c38:     	b.hs	0x1014c418c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x604>
1014c3c3c:     	lsl	x8, x0, #6
1014c3c40:     	ldr	x9, [sp, #0x20]
1014c3c44:     	ldr	x8, [x9, x8]
1014c3c48:     	cbnz	x8, 0x1014c3c88 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x100>
1014c3c4c:     	b	0x1014c3c90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014c3c50:     	ldp	q0, q1, [x25]
1014c3c54:     	stp	q0, q1, [sp, #0x90]
1014c3c58:     	ldr	x8, [sp, #0x28]
1014c3c5c:     	ldr	x8, [x8]
1014c3c60:     	ldr	x1, [x8]
1014c3c64:     	add	x0, sp, #0x68
1014c3c68:     	add	x2, sp, #0x90
1014c3c6c:     	bl	0x1014cb71c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c3c70:     	ldr	x8, [sp, #0x68]
1014c3c74:     	cmp	x8, #0x1
1014c3c78:     	b.ne	0x1014c3c90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014c3c7c:     	ldr	x8, [sp, #0x70]
1014c3c80:     	cbz	x8, 0x1014c3c90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014c3c84:     	ldr	x8, [x8]
1014c3c88:     	ldp	x19, x28, [x8, #0x10]
1014c3c8c:     	b	0x1014c3c98 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x110>
1014c3c90:     	mov	x28, #0x0               ; =0
1014c3c94:     	mov	w19, #0x8               ; =8
1014c3c98:     	mov	x1, x27
1014c3c9c:     	lsl	x27, x28, #3
1014c3ca0:     	lsr	x8, x28, #61
1014c3ca4:     	cmp	x8, #0x0
1014c3ca8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1014c3cac:     	ccmp	x27, x8, #0x2, eq
1014c3cb0:     	b.hi	0x1014c3d78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1f0>
1014c3cb4:     	str	x24, [sp, #0x48]
1014c3cb8:     	cbz	x27, 0x1014c3cf0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x168>
1014c3cbc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014c3cc0:     	mov	x0, x27
1014c3cc4:     	mov	w1, #0x8                ; =8
1014c3cc8:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1014c3ccc:     	cbz	x0, 0x1014c419c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x614>
1014c3cd0:     	mov	x24, x0
1014c3cd4:     	cbz	x28, 0x1014c3ce8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x160>
1014c3cd8:     	mov	x0, x24
1014c3cdc:     	mov	x1, x19
1014c3ce0:     	mov	x2, x27
1014c3ce4:     	bl	0x103a03e58 <dyld_stub_binder+0x103a03e58>
1014c3ce8:     	mov	x27, x24
1014c3cec:     	b	0x1014c3cf8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x170>
1014c3cf0:     	mov	w27, #0x8               ; =8
1014c3cf4:     	mov	w24, #0x8               ; =8
1014c3cf8:     	ldr	x8, [sp, #0x18]
1014c3cfc:     	add	x0, x8, x23, lsl #7
1014c3d00:     	add	x8, sp, #0x90
1014c3d04:     	mov	x1, x24
1014c3d08:     	mov	x2, x28
1014c3d0c:     	bl	0x102d91090 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
1014c3d10:     	ldr	x8, [sp, #0x90]
1014c3d14:     	cmp	x8, #0x1e
1014c3d18:     	b.ne	0x1014c4094 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x50c>
1014c3d1c:     	ldr	x8, [sp, #0xa0]
1014c3d20:     	cbz	x8, 0x1014c3d34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1ac>
1014c3d24:     	ldr	x0, [sp, #0x98]
1014c3d28:     	lsl	x1, x8, #3
1014c3d2c:     	mov	w2, #0x8                ; =8
1014c3d30:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c3d34:     	add	x25, x25, #0x20
1014c3d38:     	sub	x22, x22, #0x4
1014c3d3c:     	ldp	x24, x0, [sp, #0x48]
1014c3d40:     	ldr	x19, [sp, #0x10]
1014c3d44:     	mov	w8, #0x2c               ; =44
1014c3d48:     	cbnz	x22, 0x1014c3bf4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x6c>
1014c3d4c:     	ldr	x25, [x0, #0x30]
1014c3d50:     	lsl	x19, x25, #3
1014c3d54:     	lsr	x8, x25, #61
1014c3d58:     	cmp	x8, #0x0
1014c3d5c:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1014c3d60:     	ccmp	x19, x8, #0x2, eq
1014c3d64:     	b.ls	0x1014c3d80 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1f8>
1014c3d68:     	mov	x24, #0x0               ; =0
1014c3d6c:     	mov	x0, x24
1014c3d70:     	mov	x1, x19
1014c3d74:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014c3d78:     	mov	x0, #0x0                ; =0
1014c3d7c:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014c3d80:     	str	x24, [sp, #0x48]
1014c3d84:     	cbz	x19, 0x1014c3dc0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x238>
1014c3d88:     	mov	x20, x0
1014c3d8c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014c3d90:     	mov	w24, #0x8               ; =8
1014c3d94:     	mov	x0, x19
1014c3d98:     	mov	w1, #0x8                ; =8
1014c3d9c:     	bl	0x1000096b8 <__RNvCsfBzVIH1HIC6_7___rustc19___rust_alloc_zeroed>
1014c3da0:     	str	x0, [sp, #0x38]
1014c3da4:     	cbz	x0, 0x1014c3d6c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1e4>
1014c3da8:     	ldp	x24, x8, [x20, #0x10]
1014c3dac:     	lsl	x9, x8, #6
1014c3db0:     	sub	x9, x9, x8, lsl #3
1014c3db4:     	stp	x25, x9, [sp, #0x18]
1014c3db8:     	cbnz	x8, 0x1014c3ddc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x254>
1014c3dbc:     	b	0x1014c3ee8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014c3dc0:     	mov	w8, #0x8                ; =8
1014c3dc4:     	str	x8, [sp, #0x38]
1014c3dc8:     	ldp	x24, x8, [x0, #0x10]
1014c3dcc:     	lsl	x9, x8, #6
1014c3dd0:     	sub	x9, x9, x8, lsl #3
1014c3dd4:     	stp	xzr, x9, [sp, #0x18]
1014c3dd8:     	cbz	x8, 0x1014c3ee8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014c3ddc:     	ldp	x22, x26, [x21]
1014c3de0:     	add	x28, x24, #0x18
1014c3de4:     	adrp	x8, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c3de8:     	add	x8, x8, #0x728
1014c3dec:     	str	x8, [sp, #0x10]
1014c3df0:     	ldp	x8, x9, [x21, #0x28]
1014c3df4:     	stp	x9, x8, [sp, #0x28]
1014c3df8:     	ldr	x20, [sp, #0x20]
1014c3dfc:     	ldp	x23, x27, [x21, #0x10]
1014c3e00:     	b	0x1014c3e18 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x290>
1014c3e04:     	ldr	x8, [sp, #0x38]
1014c3e08:     	str	x1, [x8, x0, lsl #3]
1014c3e0c:     	add	x28, x28, #0x38
1014c3e10:     	subs	x20, x20, #0x38
1014c3e14:     	b.eq	0x1014c3ee8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014c3e18:     	ldr	x0, [x28, #0x18]
1014c3e1c:     	cmp	x0, x26
1014c3e20:     	b.hs	0x1014c416c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5e4>
1014c3e24:     	add	x8, x22, x0, lsl #5
1014c3e28:     	ldrb	w9, [x8]
1014c3e2c:     	cmp	w9, #0x3
1014c3e30:     	b.ne	0x1014c3e5c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x2d4>
1014c3e34:     	ldr	x0, [x8, #0x8]
1014c3e38:     	cmp	x0, x27
1014c3e3c:     	b.hs	0x1014c414c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5c4>
1014c3e40:     	ldr	x8, [sp, #0x30]
1014c3e44:     	cmp	x0, x8
1014c3e48:     	b.hs	0x1014c415c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5d4>
1014c3e4c:     	lsl	x8, x0, #6
1014c3e50:     	ldr	x19, [x23, x8]
1014c3e54:     	cbnz	x19, 0x1014c3e90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x308>
1014c3e58:     	b	0x1014c4050 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c3e5c:     	ldp	q0, q1, [x8]
1014c3e60:     	stp	q0, q1, [sp, #0x90]
1014c3e64:     	ldr	x8, [sp, #0x28]
1014c3e68:     	ldr	x8, [x8]
1014c3e6c:     	ldr	x1, [x8]
1014c3e70:     	add	x0, sp, #0x68
1014c3e74:     	add	x2, sp, #0x90
1014c3e78:     	bl	0x1014cb71c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c3e7c:     	ldp	x9, x8, [sp, #0x68]
1014c3e80:     	cmp	x9, #0x1
1014c3e84:     	ccmp	x8, #0x0, #0x4, eq
1014c3e88:     	b.eq	0x1014c4050 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c3e8c:     	ldr	x19, [x8]
1014c3e90:     	mov	w8, #0x2c               ; =44
1014c3e94:     	strb	w8, [sp, #0x90]
1014c3e98:     	add	x0, sp, #0x90
1014c3e9c:     	bl	0x1014c709c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c3ea0:     	add	x8, sp, #0x90
1014c3ea4:     	add	x0, x19, #0x10
1014c3ea8:     	mov	x1, x28
1014c3eac:     	bl	0x102d644bc <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c3eb0:     	ldp	x8, x1, [sp, #0x90]
1014c3eb4:     	cmp	x8, #0x1e
1014c3eb8:     	b.ne	0x1014c4034 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4ac>
1014c3ebc:     	ldur	w8, [x28, #-0x18]
1014c3ec0:     	cmp	w8, #0x2
1014c3ec4:     	b.ne	0x1014c3e0c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x284>
1014c3ec8:     	ldur	w0, [x28, #-0x14]
1014c3ecc:     	cmp	x25, x0
1014c3ed0:     	b.hi	0x1014c3e04 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x27c>
1014c3ed4:     	adrp	x2, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c3ed8:     	add	x2, x2, #0x6e0
1014c3edc:     	mov	x1, x25
1014c3ee0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c3ee4:     	b	0x1014c41e4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x65c>
1014c3ee8:     	ldp	x9, x8, [sp, #0x48]
1014c3eec:     	ldr	w19, [x8, #0x38]
1014c3ef0:     	ldr	x8, [x9, #0x18]
1014c3ef4:     	cmp	x8, x19
1014c3ef8:     	b.ls	0x1014c4050 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c3efc:     	ldr	x20, [x9, #0x10]
1014c3f00:     	mov	w8, #0x2c               ; =44
1014c3f04:     	strb	w8, [sp, #0x90]
1014c3f08:     	add	x0, sp, #0x90
1014c3f0c:     	bl	0x1014c709c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c3f10:     	add	x9, x20, x19, lsl #7
1014c3f14:     	add	x8, sp, #0x68
1014c3f18:     	add	x0, x9, #0x10
1014c3f1c:     	ldr	x1, [sp, #0x38]
1014c3f20:     	mov	x2, x25
1014c3f24:     	bl	0x102d91090 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
1014c3f28:     	ldr	x8, [sp, #0x68]
1014c3f2c:     	cmp	x8, #0x1e
1014c3f30:     	b.ne	0x1014c4078 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4f0>
1014c3f34:     	ldp	x8, x20, [sp, #0x70]
1014c3f38:     	str	x8, [sp, #0x38]
1014c3f3c:     	stp	x8, x20, [sp, #0x58]
1014c3f40:     	ldp	x25, x22, [x21]
1014c3f44:     	ldp	x28, x9, [x21, #0x28]
1014c3f48:     	ldp	x21, x26, [x21, #0x10]
1014c3f4c:     	adrp	x8, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c3f50:     	add	x8, x8, #0x728
1014c3f54:     	stp	x8, x9, [sp, #0x48]
1014c3f58:     	ldr	x27, [sp, #0x20]
1014c3f5c:     	cbz	x27, 0x1014c40e0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x558>
1014c3f60:     	ldr	x0, [x24, #0x30]
1014c3f64:     	cmp	x0, x22
1014c3f68:     	b.hs	0x1014c41a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x620>
1014c3f6c:     	add	x8, x25, x0, lsl #5
1014c3f70:     	ldrb	w9, [x8]
1014c3f74:     	cmp	w9, #0x3
1014c3f78:     	b.ne	0x1014c3fa0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x418>
1014c3f7c:     	ldr	x0, [x8, #0x8]
1014c3f80:     	cmp	x0, x26
1014c3f84:     	b.hs	0x1014c41b0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x628>
1014c3f88:     	cmp	x0, x28
1014c3f8c:     	b.hs	0x1014c41c4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x63c>
1014c3f90:     	lsl	x8, x0, #6
1014c3f94:     	ldr	x19, [x21, x8]
1014c3f98:     	cbnz	x19, 0x1014c3fd8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x450>
1014c3f9c:     	b	0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c3fa0:     	ldp	q0, q1, [x8]
1014c3fa4:     	stp	q0, q1, [sp, #0x90]
1014c3fa8:     	ldr	x8, [sp, #0x50]
1014c3fac:     	ldr	x8, [x8]
1014c3fb0:     	ldr	x1, [x8]
1014c3fb4:     	sub	x0, x29, #0x70
1014c3fb8:     	add	x2, sp, #0x90
1014c3fbc:     	bl	0x1014cb71c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c3fc0:     	ldur	x8, [x29, #-0x70]
1014c3fc4:     	cmp	x8, #0x1
1014c3fc8:     	b.ne	0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c3fcc:     	ldur	x8, [x29, #-0x68]
1014c3fd0:     	cbz	x8, 0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c3fd4:     	ldr	x19, [x8]
1014c3fd8:     	mov	w8, #0x2c               ; =44
1014c3fdc:     	strb	w8, [sp, #0x90]
1014c3fe0:     	add	x0, sp, #0x90
1014c3fe4:     	bl	0x1014c709c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c3fe8:     	add	x8, sp, #0x68
1014c3fec:     	add	x0, x19, #0x10
1014c3ff0:     	add	x1, x24, #0x18
1014c3ff4:     	bl	0x102d644bc <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c3ff8:     	ldp	x8, x23, [sp, #0x68]
1014c3ffc:     	cmp	x8, #0x1e
1014c4000:     	b.ne	0x1014c40e8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x560>
1014c4004:     	add	x8, sp, #0x90
1014c4008:     	add	x0, sp, #0x58
1014c400c:     	mov	x1, x24
1014c4010:     	bl	0x102d644bc <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c4014:     	ldp	x8, x1, [sp, #0x90]
1014c4018:     	cmp	x8, #0x1e
1014c401c:     	b.ne	0x1014c4104 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x57c>
1014c4020:     	add	x24, x24, #0x38
1014c4024:     	sub	x27, x27, #0x38
1014c4028:     	cmp	x1, x23
1014c402c:     	b.eq	0x1014c3f5c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x3d4>
1014c4030:     	b	0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c4034:     	and	x8, x8, #0x1e
1014c4038:     	cmp	x8, #0x14
1014c403c:     	b.ne	0x1014c4050 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c4040:     	cbz	x1, 0x1014c4050 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c4044:     	ldr	x0, [sp, #0xa0]
1014c4048:     	mov	w2, #0x1                ; =1
1014c404c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c4050:     	mov	w8, #0x2c               ; =44
1014c4054:     	ldr	x9, [sp, #0x40]
1014c4058:     	strb	w8, [x9]
1014c405c:     	ldr	x8, [sp, #0x18]
1014c4060:     	cbz	x8, 0x1014c40c0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014c4064:     	lsl	x1, x8, #3
1014c4068:     	ldr	x0, [sp, #0x38]
1014c406c:     	mov	w2, #0x8                ; =8
1014c4070:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c4074:     	b	0x1014c40c0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014c4078:     	and	x8, x8, #0x1e
1014c407c:     	cmp	x8, #0x14
1014c4080:     	b.ne	0x1014c40b4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c4084:     	ldr	x1, [sp, #0x70]
1014c4088:     	cbz	x1, 0x1014c40b4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c408c:     	ldr	x0, [sp, #0x78]
1014c4090:     	b	0x1014c40ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x524>
1014c4094:     	and	x8, x8, #0x1e
1014c4098:     	cmp	x8, #0x14
1014c409c:     	b.ne	0x1014c40b4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c40a0:     	ldr	x1, [sp, #0x98]
1014c40a4:     	cbz	x1, 0x1014c40b4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c40a8:     	ldr	x0, [sp, #0xa0]
1014c40ac:     	mov	w2, #0x1                ; =1
1014c40b0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c40b4:     	mov	w8, #0x2c               ; =44
1014c40b8:     	ldr	x9, [sp, #0x40]
1014c40bc:     	strb	w8, [x9]
1014c40c0:     	ldp	x29, x30, [sp, #0x140]
1014c40c4:     	ldp	x20, x19, [sp, #0x130]
1014c40c8:     	ldp	x22, x21, [sp, #0x120]
1014c40cc:     	ldp	x24, x23, [sp, #0x110]
1014c40d0:     	ldp	x26, x25, [sp, #0x100]
1014c40d4:     	ldp	x28, x27, [sp, #0xf0]
1014c40d8:     	add	sp, sp, #0x150
1014c40dc:     	ret
1014c40e0:     	mov	w8, #0x2e               ; =46
1014c40e4:     	b	0x1014c4124 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x59c>
1014c40e8:     	and	x8, x8, #0x1e
1014c40ec:     	cmp	x8, #0x14
1014c40f0:     	b.ne	0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c40f4:     	cbz	x23, 0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c40f8:     	ldr	x0, [sp, #0x78]
1014c40fc:     	mov	x1, x23
1014c4100:     	b	0x1014c4118 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x590>
1014c4104:     	and	x8, x8, #0x1e
1014c4108:     	cmp	x8, #0x14
1014c410c:     	b.ne	0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c4110:     	cbz	x1, 0x1014c4120 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c4114:     	ldr	x0, [sp, #0xa0]
1014c4118:     	mov	w2, #0x1                ; =1
1014c411c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c4120:     	mov	w8, #0x2c               ; =44
1014c4124:     	ldr	x9, [sp, #0x40]
1014c4128:     	strb	w8, [x9]
1014c412c:     	cbz	x20, 0x1014c40c0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014c4130:     	lsl	x1, x20, #3
1014c4134:     	b	0x1014c4068 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4e0>
1014c4138:     	adrp	x2, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c413c:     	add	x2, x2, #0x728
1014c4140:     	ldr	x0, [sp, #0x8]
1014c4144:     	mov	x1, x0
1014c4148:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c414c:     	mov	x26, x27
1014c4150:     	adrp	x8, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c4154:     	add	x8, x8, #0x740
1014c4158:     	b	0x1014c4168 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5e0>
1014c415c:     	ldr	x26, [sp, #0x30]
1014c4160:     	adrp	x8, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c4164:     	add	x8, x8, #0x758
1014c4168:     	str	x8, [sp, #0x10]
1014c416c:     	mov	x1, x26
1014c4170:     	ldr	x2, [sp, #0x10]
1014c4174:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c4178:     	b	0x1014c41e4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x65c>
1014c417c:     	adrp	x2, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c4180:     	add	x2, x2, #0x740
1014c4184:     	ldr	x1, [sp, #0x38]
1014c4188:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c418c:     	adrp	x2, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c4190:     	add	x2, x2, #0x758
1014c4194:     	ldr	x1, [sp, #0x30]
1014c4198:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c419c:     	mov	x1, x27
1014c41a0:     	mov	w0, #0x8                ; =8
1014c41a4:     	bl	0x103a02650 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014c41a8:     	str	x20, [sp, #0x18]
1014c41ac:     	b	0x1014c41d8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x650>
1014c41b0:     	str	x20, [sp, #0x18]
1014c41b4:     	mov	x22, x26
1014c41b8:     	adrp	x8, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c41bc:     	add	x8, x8, #0x740
1014c41c0:     	b	0x1014c41d4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x64c>
1014c41c4:     	str	x20, [sp, #0x18]
1014c41c8:     	mov	x22, x28
1014c41cc:     	adrp	x8, 0x107f05000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c41d0:     	add	x8, x8, #0x758
1014c41d4:     	str	x8, [sp, #0x48]
1014c41d8:     	mov	x1, x22
1014c41dc:     	ldr	x2, [sp, #0x48]
1014c41e0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c41e4:     	brk	#0x1
1014c41e8:     	b	0x1014c4200 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x678>
1014c41ec:     	mov	x21, x0
1014c41f0:     	str	x20, [sp, #0x18]
1014c41f4:     	cbnz	x20, 0x1014c420c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x684>
1014c41f8:     	b	0x1014c4220 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x698>
1014c41fc:     	b	0x1014c4200 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x678>
1014c4200:     	mov	x21, x0
1014c4204:     	ldr	x8, [sp, #0x18]
1014c4208:     	cbz	x8, 0x1014c4220 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x698>
1014c420c:     	ldr	x8, [sp, #0x18]
1014c4210:     	lsl	x1, x8, #3
1014c4214:     	ldr	x0, [sp, #0x38]
1014c4218:     	mov	w2, #0x8                ; =8
1014c421c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c4220:     	mov	x0, x21
1014c4224:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
