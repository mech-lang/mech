
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010160d6bc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>:
10160d6bc:     	sub	sp, sp, #0x1d0
10160d6c0:     	stp	x28, x27, [sp, #0x170]
10160d6c4:     	stp	x26, x25, [sp, #0x180]
10160d6c8:     	stp	x24, x23, [sp, #0x190]
10160d6cc:     	stp	x22, x21, [sp, #0x1a0]
10160d6d0:     	stp	x20, x19, [sp, #0x1b0]
10160d6d4:     	stp	x29, x30, [sp, #0x1c0]
10160d6d8:     	add	x29, sp, #0x1c0
10160d6dc:     	mov	x25, x6
10160d6e0:     	mov	x26, x4
10160d6e4:     	mov	x23, x3
10160d6e8:     	mov	x22, x2
10160d6ec:     	mov	x24, x1
10160d6f0:     	mov	x20, x0
10160d6f4:     	mov	x19, x8
10160d6f8:     	ldr	x21, [x29, #0x10]
10160d6fc:     	stp	x5, x6, [sp]
10160d700:     	str	x7, [sp, #0x10]
10160d704:     	add	x27, sp, #0x80
10160d708:     	ldr	w0, [x0, #0x110]
10160d70c:     	add	x8, sp, #0xc8
10160d710:     	mov	x1, x21
10160d714:     	bl	0x1026c6724 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
10160d718:     	ldrb	w8, [sp, #0xc8]
10160d71c:     	cmp	w8, #0x29
10160d720:     	b.ne	0x10160d864 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1a8>
10160d724:     	ldr	x28, [x20, #0x1d8]
10160d728:     	cbz	x28, 0x10160d88c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1d0>
10160d72c:     	mov	w27, #0x2c              ; =44
10160d730:     	strb	w27, [sp, #0xc8]
10160d734:     	add	x0, sp, #0xc8
10160d738:     	bl	0x10160fd10 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10160d73c:     	cmp	x22, x26
10160d740:     	b.ne	0x10160d884 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1c8>
10160d744:     	ldr	x8, [x20, #0x78]
10160d748:     	cmp	x22, x8
10160d74c:     	b.ne	0x10160d884 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1c8>
10160d750:     	cmp	x25, #0x0
10160d754:     	cset	w8, eq
10160d758:     	ldr	x9, [x20, #0x10]
10160d75c:     	cmp	x9, #0xb
10160d760:     	cset	w9, eq
10160d764:     	cmp	w8, w9
10160d768:     	b.eq	0x10160d884 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1c8>
10160d76c:     	ldp	x8, x9, [x28, #0x10]
10160d770:     	stp	x8, x9, [sp, #0x18]
10160d774:     	stp	x24, x22, [sp, #0x28]
10160d778:     	stp	x23, x22, [sp, #0x38]
10160d77c:     	mov	x10, sp
10160d780:     	str	x10, [sp, #0x48]
10160d784:     	ldr	x10, [x21, #0x60]
10160d788:     	cmp	x10, #0x1
10160d78c:     	b.ne	0x10160d8ec <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x230>
10160d790:     	ldr	w10, [x21, #0x50]
10160d794:     	add	x22, sp, #0x80
10160d798:     	tbz	w10, #0x0, 0x10160d8f8 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x23c>
10160d79c:     	ldp	x11, x10, [x29, #0x18]
10160d7a0:     	ldr	x12, [x21, #0x68]
10160d7a4:     	ldr	x13, [x21, #0x58]
10160d7a8:     	ldp	x14, x15, [x28, #0x20]
10160d7ac:     	add	x16, x28, #0x50
10160d7b0:     	add	x17, x28, #0x30
10160d7b4:     	add	x0, x28, #0x38
10160d7b8:     	add	x1, x28, #0x40
10160d7bc:     	add	x2, x28, #0x48
10160d7c0:     	stp	x12, x13, [sp, #0xb8]
10160d7c4:     	add	x12, sp, #0xb8
10160d7c8:     	stp	x11, x12, [sp, #0xc8]
10160d7cc:     	add	x12, sp, #0xc0
10160d7d0:     	stp	x12, x11, [sp, #0xd8]
10160d7d4:     	stp	x21, x10, [sp, #0xe8]
10160d7d8:     	stp	x8, x9, [sp, #0xf8]
10160d7dc:     	stp	x14, x15, [sp, #0x108]
10160d7e0:     	stp	x16, x28, [sp, #0x118]
10160d7e4:     	stp	x17, x0, [sp, #0x128]
10160d7e8:     	stp	x1, x2, [sp, #0x138]
10160d7ec:     	add	x8, sp, #0x8
10160d7f0:     	stp	x8, x20, [sp, #0x148]
10160d7f4:     	add	x8, sp, #0x18
10160d7f8:     	str	x8, [sp, #0x158]
10160d7fc:     	adrp	x0, 0x107f06000 <_anon.682fd0544a42ca3c24ee8b869371118d.262+0x2b0>
10160d800:     	add	x0, x0, #0x918
10160d804:     	add	x8, sp, #0x80
10160d808:     	add	x1, sp, #0xc8
10160d80c:     	bl	0x101590760 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
10160d810:     	ldrb	w8, [sp, #0x80]
10160d814:     	cmp	w8, #0x2f
10160d818:     	b.ne	0x10160d8b4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1f8>
10160d81c:     	ldur	q0, [x22, #0x8]
10160d820:     	stur	q0, [sp, #0x57]
10160d824:     	ldur	q1, [x22, #0x18]
10160d828:     	stur	q1, [sp, #0x67]
10160d82c:     	ldr	x8, [sp, #0xa8]
10160d830:     	stur	x8, [sp, #0x77]
10160d834:     	stur	q0, [x22, #0x4f]
10160d838:     	stur	q1, [x22, #0x5f]
10160d83c:     	stur	x8, [x22, #0x6f]
10160d840:     	mov	w8, #0x29               ; =41
10160d844:     	strb	w8, [x19]
10160d848:     	ldur	q0, [x22, #0x48]
10160d84c:     	stur	q0, [x19, #0x1]
10160d850:     	ldur	q0, [x22, #0x58]
10160d854:     	stur	q0, [x19, #0x11]
10160d858:     	ldur	q0, [x22, #0x67]
10160d85c:     	str	q0, [x19, #0x20]
10160d860:     	b	0x10160d894 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1d8>
10160d864:     	ldur	q0, [x27, #0x48]
10160d868:     	ldur	q1, [x27, #0x58]
10160d86c:     	stp	q0, q1, [x19]
10160d870:     	ldur	q0, [x27, #0x68]
10160d874:     	str	q0, [x19, #0x20]
10160d878:     	ldr	x8, [sp, #0xf8]
10160d87c:     	str	x8, [x19, #0x30]
10160d880:     	b	0x10160d894 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1d8>
10160d884:     	strb	w27, [x19]
10160d888:     	b	0x10160d894 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1d8>
10160d88c:     	mov	w8, #0x2c               ; =44
10160d890:     	strb	w8, [x19]
10160d894:     	ldp	x29, x30, [sp, #0x1c0]
10160d898:     	ldp	x20, x19, [sp, #0x1b0]
10160d89c:     	ldp	x22, x21, [sp, #0x1a0]
10160d8a0:     	ldp	x24, x23, [sp, #0x190]
10160d8a4:     	ldp	x26, x25, [sp, #0x180]
10160d8a8:     	ldp	x28, x27, [sp, #0x170]
10160d8ac:     	add	sp, sp, #0x1d0
10160d8b0:     	ret
10160d8b4:     	ldr	q0, [sp, #0xa0]
10160d8b8:     	stur	q0, [sp, #0x6f]
10160d8bc:     	ldur	q0, [x22, #0x11]
10160d8c0:     	ldur	q1, [x22, #0x1]
10160d8c4:     	stp	q1, q0, [sp, #0x50]
10160d8c8:     	ldr	x9, [sp, #0xb0]
10160d8cc:     	strb	w8, [x19]
10160d8d0:     	stur	q1, [x19, #0x1]
10160d8d4:     	ldr	q0, [sp, #0x60]
10160d8d8:     	stur	q0, [x19, #0x11]
10160d8dc:     	ldur	q0, [sp, #0x6f]
10160d8e0:     	str	q0, [x19, #0x20]
10160d8e4:     	str	x9, [x19, #0x30]
10160d8e8:     	b	0x10160d894 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1d8>
10160d8ec:     	adrp	x0, 0x107f0f000 <_anon.a02778dc867cb483339b5a31950e5a45.359+0x58>
10160d8f0:     	add	x0, x0, #0x3d8
10160d8f4:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10160d8f8:     	adrp	x0, 0x107f0f000 <_anon.a02778dc867cb483339b5a31950e5a45.359+0x58>
10160d8fc:     	add	x0, x0, #0x3f0
10160d900:     	bl	0x103a02804 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
