
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010154d848 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>:
10154d848:     	stp	x20, x19, [sp, #-0x20]!
10154d84c:     	stp	x29, x30, [sp, #0x10]
10154d850:     	add	x29, sp, #0x10
10154d854:     	mov	x19, x4
10154d858:     	cmp	x3, x2
10154d85c:     	b.hs	0x10154d8ac <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_+0x64>
10154d860:     	mov	w8, #0x170              ; =368
10154d864:     	madd	x8, x3, x8, x1
10154d868:     	add	x9, x8, #0x148
10154d86c:     	ldr	q0, [x9]
10154d870:     	stur	q0, [x0, #0x4]
10154d874:     	ldp	q0, q1, [x19]
10154d878:     	stur	q0, [x0, #0x18]
10154d87c:     	ldr	w8, [x8, #0x158]
10154d880:     	str	w8, [x0, #0x14]
10154d884:     	stur	q1, [x0, #0x28]
10154d888:     	ldr	q0, [x19, #0x20]
10154d88c:     	stur	q0, [x0, #0x38]
10154d890:     	ldr	x8, [x19, #0x30]
10154d894:     	str	x8, [x0, #0x48]
10154d898:     	mov	w8, #0x3                ; =3
10154d89c:     	str	w8, [x0]
10154d8a0:     	ldp	x29, x30, [sp, #0x10]
10154d8a4:     	ldp	x20, x19, [sp], #0x20
10154d8a8:     	ret
10154d8ac:     	adrp	x8, 0x107f08000 <_anon.0504008e54a1502d122e47b3b8bf1e07.436+0x1e8>
10154d8b0:     	add	x8, x8, #0xb78
10154d8b4:     	mov	x0, x3
10154d8b8:     	mov	x1, x2
10154d8bc:     	mov	x2, x8
10154d8c0:     	bl	0x103a028a0 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154d8c4:     	brk	#0x1
10154d8c8:     	mov	x20, x0
10154d8cc:     	mov	x0, x19
10154d8d0:     	bl	0x10154a800 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10154d8d4:     	mov	x0, x20
10154d8d8:     	bl	0x103a03c6c <dyld_stub_binder+0x103a03c6c>
