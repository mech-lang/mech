
/private/tmp/mech-call-array-audit-round69-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010299f6a8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
10299f6a8:     	stp	x28, x27, [sp, #-0x60]!
10299f6ac:     	stp	x26, x25, [sp, #0x10]
10299f6b0:     	stp	x24, x23, [sp, #0x20]
10299f6b4:     	stp	x22, x21, [sp, #0x30]
10299f6b8:     	stp	x20, x19, [sp, #0x40]
10299f6bc:     	stp	x29, x30, [sp, #0x50]
10299f6c0:     	add	x29, sp, #0x50
10299f6c4:     	sub	sp, sp, #0x1a0
10299f6c8:     	ldr	x9, [x0, #0xd0]
10299f6cc:     	adds	x13, x9, x1
10299f6d0:     	b.hs	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f6d4:     	ldr	x21, [x0, #0xc8]
10299f6d8:     	ldr	x26, [x0, #0xe8]
10299f6dc:     	ldr	x28, [x0, #0xf8]
10299f6e0:     	ldr	x25, [x0, #0x108]
10299f6e4:     	ldp	x22, x23, [x0, #0x118]
10299f6e8:     	ldr	x9, [x0]
10299f6ec:     	cmp	x9, #0x1
10299f6f0:     	b.ne	0x10299f75c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
10299f6f4:     	cmp	x23, #0x10, lsl #12     ; =0x10000
10299f6f8:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f6fc:     	mov	w9, #0x1000000          ; =16777216
10299f700:     	cmp	x26, x9
10299f704:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f708:     	mov	w9, #0x1000000          ; =16777216
10299f70c:     	cmp	x13, x9
10299f710:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f714:     	mov	w9, #0x1000000          ; =16777216
10299f718:     	cmp	x28, x9
10299f71c:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f720:     	mov	w9, #0x1000000          ; =16777216
10299f724:     	cmp	x25, x9
10299f728:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f72c:     	cmp	x22, #0x10, lsl #12     ; =0x10000
10299f730:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f734:     	cmp	x21, #0x10, lsl #12     ; =0x10000
10299f738:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f73c:     	ldr	x9, [x0, #0x8]
10299f740:     	cmp	x13, x9
10299f744:     	b.hi	0x10299f754 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10299f748:     	ldr	x9, [x0, #0x10]
10299f74c:     	cmp	x21, x9
10299f750:     	b.ls	0x10299f894 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10299f754:     	mov	w9, #0x2                ; =2
10299f758:     	b	0x10299f89c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f4>
10299f75c:     	ldp	x24, x2, [x0, #0xd8]
10299f760:     	ldr	x20, [x0, #0xf0]
10299f764:     	ldr	x9, [x0, #0x100]
10299f768:     	ldr	x1, [x0, #0x110]
10299f76c:     	ldr	x15, [x0, #0x128]
10299f770:     	ldr	x27, [x0, #0x18]
10299f774:     	cmp	x27, #0x2
10299f778:     	b.ne	0x10299f7ec <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x144>
10299f77c:     	mov	x19, x0
10299f780:     	mov	x27, x8
10299f784:     	stp	x21, x13, [x29, #-0xf0]
10299f788:     	mov	x21, x13
10299f78c:     	stp	x24, x2, [x29, #-0xe0]
10299f790:     	stp	x26, x20, [x29, #-0xd0]
10299f794:     	stp	x28, x9, [x29, #-0xc0]
10299f798:     	stp	x25, x1, [x29, #-0xb0]
10299f79c:     	stp	x22, x23, [x29, #-0xa0]
10299f7a0:     	stur	x15, [x29, #-0x90]
10299f7a4:     	sub	x8, x29, #0x88
10299f7a8:     	sub	x0, x29, #0xf0
10299f7ac:     	bl	0x1029ae150 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
10299f7b0:     	ldurb	w8, [x29, #-0x88]
10299f7b4:     	cmp	w8, #0x8
10299f7b8:     	b.ne	0x10299f868 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1c0>
10299f7bc:     	add	x0, sp, #0xd0
10299f7c0:     	sub	x1, x29, #0xf0
10299f7c4:     	bl	0x10299bcd0 <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
10299f7c8:     	mov	x8, x27
10299f7cc:     	ldrb	w9, [sp, #0xd0]
10299f7d0:     	cmp	w9, #0x8
10299f7d4:     	b.eq	0x10299f88c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e4>
10299f7d8:     	ldp	q0, q1, [sp, #0xd0]
10299f7dc:     	stp	q0, q1, [x8]
10299f7e0:     	ldr	x9, [sp, #0xf0]
10299f7e4:     	str	x9, [x8, #0x20]
10299f7e8:     	b	0x10299f8a0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10299f7ec:     	str	x9, [sp, #0xc0]
10299f7f0:     	ldr	x10, [x0, #0x20]
10299f7f4:     	ldp	x11, x9, [x0, #0x38]
10299f7f8:     	stp	x9, x10, [sp, #0xb0]
10299f7fc:     	ldp	x10, x9, [x0, #0x48]
10299f800:     	stp	x9, x11, [sp, #0xa0]
10299f804:     	ldr	x9, [x0, #0x58]
10299f808:     	stp	x9, x10, [sp, #0x90]
10299f80c:     	ldp	x10, x9, [x0, #0x60]
10299f810:     	str	x9, [sp, #0x88]
10299f814:     	ldp	x11, x9, [x0, #0x70]
10299f818:     	stp	x0, x9, [sp, #0x78]
10299f81c:     	ldp	x6, x12, [x0, #0x80]
10299f820:     	ldp	x4, x7, [x0, #0x90]
10299f824:     	ldr	x3, [x0, #0xa0]
10299f828:     	ldp	w5, w14, [x0, #0xb8]
10299f82c:     	ldr	x9, [x0, #0xc0]
10299f830:     	str	x9, [sp, #0xc8]
10299f834:     	adrp	x0, 0x108073000 <__mi_heap_main+0xb28>
10299f838:     	add	x0, x0, #0x550
10299f83c:     	ldr	x9, [x0]
10299f840:     	blr	x9
10299f844:     	mov	x19, x0
10299f848:     	ldrb	w9, [x0, #0x48]
10299f84c:     	cmp	w9, #0x1
10299f850:     	b.eq	0x10299f91c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x274>
10299f854:     	cmp	w9, #0x2
10299f858:     	b.ne	0x10299f8c0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x218>
10299f85c:     	adrp	x0, 0x10804f000 <_anon.5245c210884fd18e01c7938c721b2e18.255+0x6698>
10299f860:     	add	x0, x0, #0xc20
10299f864:     	bl	0x103a05f64 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10299f868:     	sub	x8, x29, #0x88
10299f86c:     	ldp	q0, q1, [x8]
10299f870:     	stp	q0, q1, [sp, #0xd0]
10299f874:     	ldur	x8, [x29, #-0x68]
10299f878:     	str	x8, [sp, #0xf0]
10299f87c:     	mov	x8, x27
10299f880:     	ldrb	w9, [sp, #0xd0]
10299f884:     	cmp	w9, #0x8
10299f888:     	b.ne	0x10299f7d8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x130>
10299f88c:     	mov	x0, x19
10299f890:     	mov	x13, x21
10299f894:     	str	x13, [x0, #0xd0]
10299f898:     	mov	w9, #0x8                ; =8
10299f89c:     	strb	w9, [x8]
10299f8a0:     	add	sp, sp, #0x1a0
10299f8a4:     	ldp	x29, x30, [sp, #0x50]
10299f8a8:     	ldp	x20, x19, [sp, #0x40]
10299f8ac:     	ldp	x22, x21, [sp, #0x30]
10299f8b0:     	ldp	x24, x23, [sp, #0x20]
10299f8b4:     	ldp	x26, x25, [sp, #0x10]
10299f8b8:     	ldp	x28, x27, [sp], #0x60
10299f8bc:     	ret
10299f8c0:     	stp	x1, x15, [sp, #0x10]
10299f8c4:     	adrp	x1, 0x102335000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x68>
10299f8c8:     	add	x1, x1, #0xc30
10299f8cc:     	mov	x0, x19
10299f8d0:     	str	x8, [sp, #0x20]
10299f8d4:     	stp	x6, x13, [sp, #0x50]
10299f8d8:     	stp	x14, x7, [sp, #0x30]
10299f8dc:     	str	x2, [sp, #0x8]
10299f8e0:     	stp	x3, x4, [sp, #0x40]
10299f8e4:     	str	w5, [sp, #0x2c]
10299f8e8:     	stp	x12, x11, [sp, #0x60]
10299f8ec:     	str	x10, [sp, #0x70]
10299f8f0:     	bl	0x102e73214 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10299f8f4:     	ldp	x11, x10, [sp, #0x68]
10299f8f8:     	ldp	x13, x12, [sp, #0x58]
10299f8fc:     	ldp	x7, x3, [sp, #0x38]
10299f900:     	ldp	x4, x6, [sp, #0x48]
10299f904:     	ldr	w5, [sp, #0x2c]
10299f908:     	ldp	x2, x1, [sp, #0x8]
10299f90c:     	ldp	x15, x8, [sp, #0x18]
10299f910:     	ldr	x14, [sp, #0x30]
10299f914:     	mov	w9, #0x1                ; =1
10299f918:     	strb	w9, [x19, #0x48]
10299f91c:     	str	x10, [sp, #0x70]
10299f920:     	ldr	x9, [x19]
10299f924:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10299f928:     	cmp	x9, x10
10299f92c:     	b.hs	0x10299fb3c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x494>
10299f930:     	add	x10, x9, #0x1
10299f934:     	str	x10, [x19]
10299f938:     	ldr	x10, [x19, #0x8]
10299f93c:     	cbz	x10, 0x10299f9e4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x33c>
10299f940:     	stp	x12, x11, [sp, #0x60]
10299f944:     	ldr	x11, [x10, #0x10]
10299f948:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
10299f94c:     	cmp	x11, x12
10299f950:     	b.hs	0x10299fb48 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x4a0>
10299f954:     	ldr	x10, [x10, #0x58]
10299f958:     	str	x9, [x19]
10299f95c:     	ldr	x9, [sp, #0xc8]
10299f960:     	cmp	x10, x9
10299f964:     	b.ne	0x10299f9e8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x340>
10299f968:     	stp	x7, x3, [sp, #0x38]
10299f96c:     	stp	x4, x6, [sp, #0x48]
10299f970:     	str	w5, [sp, #0x2c]
10299f974:     	str	x14, [sp, #0x30]
10299f978:     	mov	x19, x8
10299f97c:     	stp	x21, x13, [x29, #-0xf0]
10299f980:     	str	x13, [sp, #0x58]
10299f984:     	stp	x24, x2, [x29, #-0xe0]
10299f988:     	mov	x24, x2
10299f98c:     	stp	x26, x20, [x29, #-0xd0]
10299f990:     	ldr	x8, [sp, #0xc0]
10299f994:     	stp	x28, x8, [x29, #-0xc0]
10299f998:     	stp	x25, x1, [x29, #-0xb0]
10299f99c:     	mov	x26, x1
10299f9a0:     	stp	x22, x23, [x29, #-0xa0]
10299f9a4:     	mov	x20, x15
10299f9a8:     	stur	x15, [x29, #-0x90]
10299f9ac:     	sub	x8, x29, #0x88
10299f9b0:     	sub	x0, x29, #0xf0
10299f9b4:     	bl	0x1029ae150 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
10299f9b8:     	ldurb	w8, [x29, #-0x88]
10299f9bc:     	cmp	w8, #0x8
10299f9c0:     	b.ne	0x10299f9f0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
10299f9c4:     	cmp	x27, #0x1
10299f9c8:     	mov	x8, x19
10299f9cc:     	ldr	x11, [sp, #0xb8]
10299f9d0:     	b.ne	0x10299fa08 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
10299f9d4:     	cmp	x23, x11
10299f9d8:     	b.ls	0x10299fa08 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
10299f9dc:     	mov	w9, #0x0                ; =0
10299f9e0:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299f9e4:     	str	x9, [x19]
10299f9e8:     	strb	wzr, [x8]
10299f9ec:     	b	0x10299f8a0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10299f9f0:     	sub	x8, x29, #0x88
10299f9f4:     	ldp	q0, q1, [x8]
10299f9f8:     	stp	q0, q1, [x19]
10299f9fc:     	ldur	x8, [x29, #-0x68]
10299fa00:     	str	x8, [x19, #0x20]
10299fa04:     	b	0x10299f8a0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10299fa08:     	ldp	x9, x11, [sp, #0xa8]
10299fa0c:     	cmp	x9, #0x1
10299fa10:     	b.ne	0x10299fa28 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
10299fa14:     	cmp	x28, x11
10299fa18:     	b.ls	0x10299fa28 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
10299fa1c:     	mov	w9, #0x2                ; =2
10299fa20:     	mov	x23, x28
10299fa24:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299fa28:     	ldp	x9, x11, [sp, #0x98]
10299fa2c:     	cmp	x9, #0x1
10299fa30:     	b.ne	0x10299fa48 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
10299fa34:     	cmp	x25, x11
10299fa38:     	b.ls	0x10299fa48 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
10299fa3c:     	mov	w9, #0x3                ; =3
10299fa40:     	mov	x23, x25
10299fa44:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299fa48:     	ldr	x9, [sp, #0x90]
10299fa4c:     	cmp	x9, #0x1
10299fa50:     	ldr	x11, [sp, #0x70]
10299fa54:     	b.ne	0x10299fa6c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
10299fa58:     	cmp	x22, x11
10299fa5c:     	b.ls	0x10299fa6c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
10299fa60:     	mov	w9, #0x4                ; =4
10299fa64:     	mov	x23, x22
10299fa68:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299fa6c:     	ldr	x9, [sp, #0x88]
10299fa70:     	cmp	x9, #0x1
10299fa74:     	ldr	x11, [sp, #0x68]
10299fa78:     	b.ne	0x10299fa90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
10299fa7c:     	cmp	x21, x11
10299fa80:     	b.ls	0x10299fa90 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
10299fa84:     	mov	w9, #0x5                ; =5
10299fa88:     	mov	x23, x21
10299fa8c:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299fa90:     	ldr	x9, [sp, #0x80]
10299fa94:     	cmp	x9, #0x1
10299fa98:     	ldp	x11, x13, [sp, #0x50]
10299fa9c:     	b.ne	0x10299fab4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
10299faa0:     	cmp	x13, x11
10299faa4:     	b.ls	0x10299fab4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
10299faa8:     	mov	w9, #0x6                ; =6
10299faac:     	mov	x23, x13
10299fab0:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299fab4:     	ldr	x9, [sp, #0x60]
10299fab8:     	cmp	x9, #0x1
10299fabc:     	ldr	x11, [sp, #0x48]
10299fac0:     	b.ne	0x10299fad8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
10299fac4:     	cmp	x24, x11
10299fac8:     	b.ls	0x10299fad8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
10299facc:     	mov	w9, #0x7                ; =7
10299fad0:     	mov	x23, x24
10299fad4:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299fad8:     	ldp	x9, x11, [sp, #0x38]
10299fadc:     	cmp	x9, #0x1
10299fae0:     	b.ne	0x10299fafc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
10299fae4:     	mov	x24, x26
10299fae8:     	cmp	x26, x11
10299faec:     	b.ls	0x10299fafc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
10299faf0:     	mov	w9, #0x8                ; =8
10299faf4:     	mov	x23, x24
10299faf8:     	b	0x10299fb20 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10299fafc:     	ldr	w9, [sp, #0x2c]
10299fb00:     	cmp	w9, #0x1
10299fb04:     	ldr	x0, [sp, #0x78]
10299fb08:     	ldr	x11, [sp, #0x30]
10299fb0c:     	b.ne	0x10299f894 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10299fb10:     	cmp	w11, w20
10299fb14:     	b.hs	0x10299f894 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10299fb18:     	mov	w23, w20
10299fb1c:     	mov	w9, #0xa                ; =10
10299fb20:     	mov	w10, #0x6               ; =6
10299fb24:     	strb	w10, [x8]
10299fb28:     	strb	w9, [x8, #0x1]
10299fb2c:     	mov	w9, #0x1                ; =1
10299fb30:     	strb	w9, [x8, #0x2]
10299fb34:     	stp	x23, x11, [x8, #0x8]
10299fb38:     	b	0x10299f8a0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10299fb3c:     	adrp	x0, 0x108051000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.310+0x148>
10299fb40:     	add	x0, x0, #0x2c0
10299fb44:     	bl	0x103a06618 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10299fb48:     	adrp	x0, 0x108051000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.310+0x148>
10299fb4c:     	add	x0, x0, #0x2d8
10299fb50:     	bl	0x103a06618 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10299fb54:     	brk	#0x1
10299fb58:     	ldr	x8, [x19]
10299fb5c:     	sub	x8, x8, #0x1
10299fb60:     	str	x8, [x19]
10299fb64:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
