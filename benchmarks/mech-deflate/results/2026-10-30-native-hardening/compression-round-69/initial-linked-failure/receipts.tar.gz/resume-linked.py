"""Retry only the exact space-denied link; preserve fresh emission and failure."""
from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'linked-primary/after';failed=r/'initial-linked-failure';failed.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads((p/'worker-build.json').read_text());assert base['exit']==1 and 'errno=28' in (p/'worker-build.stderr').read_text()
for name in ['object-build.json','object-build.stdout','object-build.stderr','emit.json','emit.stdout','emit.stderr','worker-build.json','worker-build.stdout','worker-build.stderr','worker.rs','inspect.rs']:
 shutil.copy2(p/name,failed/name)
pins={name:{'sha256':sha(p/name),'bytes':(p/name).stat().st_size} for name in ['object.o','descriptor.json','metadata.json']}
before=json.loads((r/'linked-primary/before/binding.json').read_text());assert pins==before['pins']
(failed/'artifact-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
failures=json.loads((r/'prior-failures.json').read_text());failures.append({'receipt':'initial-linked-failure/worker-build.json','command':base['command'],'exit':1,'classification':'environmental','evidence':'Linker reports write() failed, errno=28 (no space). Coherent release libraries and fresh Object/image emission already succeeded. No benchmark timing was collected.','disposition':'Remove only completed historical build/test outputs, preserve source and raw receipts, retry the exact same worker command and current emitted image. No compiler, feature, quota, workload, allocator or timing change.'});(r/'prior-failures.json').write_text(json.dumps(failures,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'initial-linked-failure',str(failed),str(r/'prior-failures.json'),str(r/'resume-linked.py'),str(r/'linked-build.py'),str(r/'historical-library-storage.json'),str(r/'historical-executable-storage.json')],check=True)
def run(name,cmd):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={**base,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'retry_of':'initial-linked-failure/worker-build.json','scope':'Exact unchanged worker link and generated Object/image after storage cleanup.'};(p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 if q.returncode:print(q.stdout[-2000:]+q.stderr[-7000:],flush=True)
 q.check_returncode()
run('worker-build',base['command']);run('smoke',[str(p/'worker'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','0'])
rows=[json.loads(x) for x in (p/'smoke.stdout').read_text().splitlines() if x.startswith('{')];assert len(rows)==2 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==60260219686 for x in rows);assert (p/'smoke.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
meta=json.loads((p/'metadata.json').read_text());source=(p/'worker.rs').read_text();normalized=source.replace(meta['identity_symbol'],'<IDENTITY>').replace(str(p/'descriptor.json'),'<IMAGE>');old=Path('/private/tmp/mech-scalar-child-round39-20261030/workers/session.rs')
binding={'compiler_source':base['compiler_source'],'expected_work':60260219686,'pins':pins,'worker_sha256':sha(p/'worker'),'worker_source_sha256':sha(p/'worker.rs'),'original_worker_sha256':sha(old),'normalized_source_sha256':hashlib.sha256(normalized.encode()).hexdigest(),'libraries':base['libraries'],'auxiliary_dependencies':base['auxiliary_dependencies'],'scope':'Fresh exact R69 emission and coherent twelve-crate build. Only the disk-denied worker link was repeated. Same respective linked image/libraries in all primary/counter/profile consumers; unchanged timer/source/bytecode/allocator/output reuse.'}
assert binding['normalized_source_sha256']==before['normalized_source_sha256'] and binding['original_worker_sha256']==before['original_worker_sha256'];(p/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
files=[f for f in p.iterdir() if f.is_file() and f.suffix in {'.json','.stdout','.stderr','.rs'}]
subprocess.run(['python3',str(r/'archive.py'),'linked-build-after',*map(str,files),str(r/'resume-linked.py'),str(r/'linked-build.py')],check=True);print('EXACT_LINK_RETRY_PASSED',flush=True)
