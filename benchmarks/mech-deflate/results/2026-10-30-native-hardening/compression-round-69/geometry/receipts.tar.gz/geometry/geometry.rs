use mech_core::{BoundCall,ResolvedValueDescriptor,CallMemoryPlan};
fn main(){println!("{:?}", [std::mem::size_of::<BoundCall>(),std::mem::align_of::<BoundCall>(),std::mem::size_of::<ResolvedValueDescriptor>(),std::mem::align_of::<ResolvedValueDescriptor>(),std::mem::size_of::<CallMemoryPlan>(),std::mem::align_of::<CallMemoryPlan>()]);}
