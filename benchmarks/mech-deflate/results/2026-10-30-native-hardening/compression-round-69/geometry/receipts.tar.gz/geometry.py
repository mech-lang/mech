"""Compare actual shared certificate/descriptor geometry in both coherent release graphs."""
from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'geometry';p.mkdir();rows={}
source='''use mech_core::{BoundCall,ResolvedValueDescriptor,CallMemoryPlan};
fn main(){println!("{:?}", [std::mem::size_of::<BoundCall>(),std::mem::align_of::<BoundCall>(),std::mem::size_of::<ResolvedValueDescriptor>(),std::mem::align_of::<ResolvedValueDescriptor>(),std::mem::size_of::<CallMemoryPlan>(),std::mem::align_of::<CallMemoryPlan>()]);}
''';(p/'geometry.rs').write_text(source)
rustc=json.loads((r/'final-release.json').read_text())['command'][0]
for label,root in [('before',Path(json.loads((r/'configuration.json').read_text())['baseline_directory'])),('after',r)]:
 libs=json.loads((root/'final-libraries.json').read_text());core=libs['mech_core'];assert hashlib.sha256(Path(core['path']).read_bytes()).hexdigest()==core['sha256']
 cmd=[rustc,'--edition=2024','-O','-D','warnings','-L','dependency='+str(root/'variants/after/dependency'),'--extern','mech_core='+core['path'],str(p/'geometry.rs'),'-o',str(p/label)]
 for kind,command in [('build',cmd),('run',[cmd[-1]])]:
  at=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(label+'-'+kind+'.'+stream)).write_text(getattr(q,stream))
  (p/(label+'-'+kind+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'library':core},indent=2)+'\n');q.check_returncode()
  if kind=='run':rows[label]=json.loads(q.stdout)
 Path(cmd[-1]).unlink()
assert rows['before']==rows['after'],rows
(p/'summary.json').write_text(json.dumps({'command':['python3',str(r/'geometry.py')],'exit':0,'geometry':rows,'fields':['BoundCall size','BoundCall alignment','ResolvedValueDescriptor size','ResolvedValueDescriptor alignment','CallMemoryPlan size','CallMemoryPlan alignment'],'scope':'Actual same-target optimized releases. These certificate/descriptor and call-plan outer sizes and alignments stay identical; no claim that reachable heap bytes are equal. Current charges and error prefixes are independently tested.'},indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'geometry',str(p),str(r/'geometry.py')],check=True);print(json.dumps(rows),flush=True)
