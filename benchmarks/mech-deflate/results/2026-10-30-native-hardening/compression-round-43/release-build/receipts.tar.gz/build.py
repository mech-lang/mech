from pathlib import Path
import hashlib,json,shutil,subprocess,time,os
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-record-lookup-round42-20261030');p=r/'variants';p.mkdir()
source=old/'diagnostic-libs/after';libs=json.loads((source/'libraries.json').read_text());common=r/'frozen-compute';common.mkdir()
aux=[]
for f in source.glob('libmech_compute*'):
 target=common/f.name;shutil.copy2(f,target);aux.append({'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
(r/'auxiliary-dependencies.json').write_text(json.dumps({'scope':'Freeze the transitive Compute artifact as well as every direct dependency. No Cargo mutation during this round.','files':aux},indent=2)+'\n')
before=p/'before';before.mkdir();shutil.copy2(source/'gpu-build.json',before/'gpu-build-origin.json');(before/'libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'before-library-pins',str(before/'libraries.json'),str(r/'auxiliary-dependencies.json'),str(before/'gpu-build-origin.json')],cwd=w,check=True)
after=p/'after';after.mkdir();base=json.loads((source/'gpu-build.json').read_text());cmd=base['command'].copy();cmd[-1]=str(after/'libmech_gpu.rlib')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern' and a.startswith('mech_compute='):cmd[i]='mech_compute='+str(common/'libmech_compute-84cb0ef1d137eee3.rlib')
 if a=='dependency='+str(source):cmd[i]='dependency='+str(common)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
at=time.monotonic();q=subprocess.run(cmd,cwd=base['cwd'],env={**os.environ,**base['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(after/('build.'+stream)).write_text(getattr(q,stream))
receipt={'command':cmd,'environment':base['environment'],'cwd':base['cwd'],'source_head':head,'exit':q.returncode,'seconds':time.monotonic()-at,'profile':'opt3, warnings as errors; same features/flags as frozen baseline GPU; every non-GPU library hash unchanged'}
(after/'build.json').write_text(json.dumps(receipt,indent=2)+'\n');print('GPU BUILD',q.returncode,receipt['seconds'],flush=True)
if q.returncode:print(q.stderr[-6000:],flush=True)
q.check_returncode()
new={**libs,'mech_gpu':{**libs['mech_gpu'],'path':str(after/'libmech_gpu.rlib'),'sha256':hashlib.sha256((after/'libmech_gpu.rlib').read_bytes()).hexdigest()}}
for name,b in new.items():assert hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256']
(after/'libraries.json').write_text(json.dumps(new,indent=2)+'\n');(r/'final-libraries.json').write_text(json.dumps(new,indent=2)+'\n');(r/'final-release.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-build',str(after/'build.json'),str(after/'build.stdout'),str(after/'build.stderr'),str(after/'libraries.json'),str(r/'final-release.json'),str(r/'final-libraries.json'),str(r/'build.py')],cwd=w,check=True)
