from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'linked-acceptance';p.mkdir()
base=json.loads((r/'linked-primary/after/worker-build.json').read_text());libs=json.loads((r/'final-libraries.json').read_text());base['libraries']=libs;worker=(r/'linked-primary/after/worker.rs').read_text()
source_fn=worker[worker.index('fn source('):worker.index('fn words(')]
import_fn=worker[worker.index('fn import('):worker.index('fn rebind(')]
imports='''use mech_core::{ManagedMemoryBudget,Value,ValueDataDraft as Data,snapshot::{SnapshotValidationContext,ValueDraft}};
use mech_engine::{CanonicalSourceFrontend,ProgramArtifact};
use mech_gpu::native_artifact::NativeProgramLimitMode;
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
use std::sync::Arc;
'''
fixture=w/'hosts/gpu/tests/fixtures/native/prepared-record-lookup.mec';(p/'source.mec').write_bytes(fixture.read_bytes())
def run(label,cmd):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr);(p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':base['compiler_source'],'libraries':base['libraries']},indent=2)+'\n')
 if q.returncode:print(q.stdout[-2500:]+q.stderr[-5000:],flush=True)
 q.check_returncode();print(label,'COMPLETE',flush=True)
cmd_base=base['command'].copy()
for j,a in enumerate(cmd_base):
 if j and cmd_base[j-1]=='--extern':key=a.split('=')[0];cmd_base[j]=key+'='+libs[key]['path']
cmd_base[-3:-3]=['-L','dependency='+str(r/'frozen-compute'),'-L','dependency='+str(Path(libs['mech_engine']['path']).parent)]
cmd_base[-3:-3]=['-L','dependency='+str(Path(libs['mech_gpu']['path']).parent)]
at=cmd_base.index('-C',cmd_base.index('--extern')) if False else None
# Remove only the full-compressor Object argument; every other dependency and flag remains pinned.
i=cmd_base.index('link-arg='+str(r/'linked-primary/after/object.o'));assert cmd_base[i-1]=='-C';del cmd_base[i-1:i+1]
source='''use mech_engine::CanonicalSourceFrontend;use mech_engine::ProgramArtifact;
use mech_gpu::native_artifact::{NativeProgramLimitMode,emit_program_object_with_limits};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
'''+source_fn+'''fn main(){let artifact=source(include_str!("'''+str(p/'source.mec')+'''"));let object=emit_program_object_with_limits(&artifact,&mech_stdlib::source_catalog(),NativeProgramLimitMode::NoLimits.compilation()).unwrap();let p=std::path::Path::new("'''+str(p)+'''");std::fs::write(p.join("object.o"),object.bytes()).unwrap();std::fs::write(p.join("descriptor.json"),object.descriptor().encode_build_owned_image().unwrap()).unwrap();std::fs::write(p.join("metadata.json"),serde_json::to_vec_pretty(&object.metadata()).unwrap()).unwrap();}'''
(p/'emit.rs').write_text(source);cmd=cmd_base.copy();cmd[-3]=str(p/'emit.rs');cmd[-1]=str(p/'emit');run('emit-build',cmd);run('emit',[str(p/'emit')])
meta=json.loads((p/'metadata.json').read_text());identity=meta['identity_symbol'];entry=meta['entry_symbol']
prefix='unsafe extern "C" { #[link_name="'+identity+'"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES]; #[link_name="'+entry+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64; }\n'
body='fn main(){let original=source(include_str!("SOURCE_PATH"));let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();let mode=NativeProgramLimitMode::NoLimits;let catalog=mech_stdlib::source_catalog();let mut receipts=Vec::new();for artifact in [original,decoded]{\n // SAFETY: this exact same-build Object and unchanged image are pinned before link; entry and identity live throughout execution.\n let jit=unsafe{mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("IMAGE_PATH"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();let memory=mode.memory_budget();let mut published=vec![None;artifact.outputs().len()];\n for (word,number,flag,signed,ratio,left,allowed,divisor,empty,expected,error) in [(3u8,2u64,true,-2i64,1.5f64,2u64,true,1u64,false,Some(36u64),None),(11,20,false,2,0.5,3,true,2,false,Some(30),None),(3,2,true,-2,1.5,2,false,0,true,None,Some("Integrity")),(3,2,true,-2,1.5,2,true,1,true,None,Some("Library")),(3,2,true,-2,1.5,2,true,0,false,None,Some("Arithmetic")),(5,2,false,0,2.5,1,true,1,false,Some(17),None)]{\n  let args=import(&artifact,&[("xs".into(),Data::Matrix(if empty{vec![]}else{vec![Data::U8(word)]}.into())),("number".into(),Data::U64(number)),("flag".into(),Data::Bool(flag)),("signed".into(),Data::I64(signed)),("ratio".into(),Data::F64(mech_core::snapshot::F64Bits::from_f64(ratio))),("left".into(),Data::U64(left)),("allowed".into(),Data::Bool(allowed)),("divisor".into(),Data::U64(divisor))],&memory);let aliases=args.clone();let before=args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>();let prior=published.clone();let retained=(memory.used_bytes(),memory.retained_snapshot_nodes());\n  let result=jit.evaluate_into(&args,&mut published,mode.execution(),&memory);\n  if let Some(expected)=expected{let report=result.unwrap();assert_eq!(published[0].as_ref().unwrap().canonical_data_draft().unwrap(),Data::U64(expected));receipts.push(serde_json::json!({"generated_success":expected,"work":report.work}));}else{let error_text=format!("{:?}",result.unwrap_err());assert!(error_text.contains(error.unwrap()),"{error_text}");assert!(published.iter().zip(&prior).all(|(a,b)|a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),retained);receipts.push(serde_json::json!({"generated_failure":error_text}));}\n  assert_eq!(args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>(),before);assert!(args.iter().zip(&aliases).all(|(a,b)|a.shares_frozen_storage(b)));\n }\n drop(published);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));\n}\nprintln!("{}",serde_json::to_string_pretty(&receipts).unwrap());}\n'.replace('SOURCE_PATH',str(p/'source.mec')).replace('IMAGE_PATH',str(p/'descriptor.json'))
(p/'worker.rs').write_text(prefix+imports+source_fn+import_fn+body);cmd=cmd_base.copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'object.o')];run('worker-build',cmd);run('run',[str(p/'worker')]);rows=json.loads((p/'run.stdout').read_text());assert len(rows)==12;assert [x.get('generated_success') for x in rows]==[36,30,None,None,None,17]*2
(p/'pins.json').write_text(json.dumps({name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['source.mec','object.o','descriptor.json','metadata.json','worker']},indent=2)+'\n')
files=[f for f in p.iterdir() if f.is_file() and f.name not in {'emit','worker','object.o','descriptor.json'}]
subprocess.run(['python3',str(r/'archive.py'),'linked-acceptance',*map(str,files),str(r/'linked-acceptance.py')],cwd=w,check=True)
