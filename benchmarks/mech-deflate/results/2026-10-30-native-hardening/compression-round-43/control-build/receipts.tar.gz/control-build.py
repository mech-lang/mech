from pathlib import Path
import os,json,subprocess,time,hashlib
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'primary';p.mkdir();base=json.loads(Path('/private/tmp/mech-scalar-child-round39-20261030/primary/current-build.json').read_text())
for label in ['before','after']:
 libs=json.loads((r/'variants'/label/'libraries.json').read_text());cmd=base['command'].copy()
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern':key=a.split('=')[0];cmd[i]=key+'='+libs[key]['path']
 cmd[-3]=str(w/'hosts/gpu/examples/native_frame_transport.rs');cmd[-1]=str(p/('frame-'+label));cmd[-3:-3]=['--extern','sha2=/private/tmp/mech-live-control-target/release/deps/libsha2-f9316069bed82edc.rlib','-L','dependency='+str(r/'frozen-compute'),'-L','dependency='+str(Path(libs['mech_gpu']['path']).parent),'-L','dependency='+str(Path(libs['mech_engine']['path']).parent)]
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/('frame-'+label+'-build.'+stream)).write_text(getattr(q,stream))
 (p/('frame-'+label+'-build.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'libraries':libs},indent=2)+'\n');print(label,'FRAME_BUILD',q.returncode,flush=True)
 if q.returncode:print(q.stderr[-4500:],flush=True)
 q.check_returncode();(p/('frame-'+label+'.json')).write_text(json.dumps({'path':str(p/('frame-'+label)),'sha256':hashlib.sha256((p/('frame-'+label)).read_bytes()).hexdigest(),'scope':'Fresh matched frame control with same production libraries as primary.'},indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'control-build',*map(str,[f for f in p.iterdir() if f.suffix in ['.json','.stdout','.stderr']]),str(r/'control-build.py')],cwd=w,check=True)
