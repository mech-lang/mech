from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
subprocess.run(['python3',str(r/'units-final.py'),'verified'],check=True)
for name in ['controls.py','workflow-checks.py','ci.py','architecture.py','inspect-host.py']:
 print('RESUME',name,flush=True)
 subprocess.run(['python3',str(r/name)],check=True)
