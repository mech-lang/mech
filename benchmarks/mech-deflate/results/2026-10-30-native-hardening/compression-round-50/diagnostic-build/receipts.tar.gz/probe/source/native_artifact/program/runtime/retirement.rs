//! Original ordered lexical cleanup, shared by ordinary tail boundaries.
use super::*;
use crate::native_artifact::program::prepare::cleanup_effects::Boundary;
use crate::native_artifact::program::prepare::frame_retirement::FrameRetirements;

pub(super) fn run(
    slots: &[u64],
    recipes: &FrameRetirements,
    frames: &mut buffer_frames::BufferFrames,
    arena: &mut NativeValueArena<'_>,
    work: &mut NativeWorkMeter,
    prepared: Option<&Boundary>,
) -> Result<bool, NativeProgramExecutionError> {
    work.charge(NativeExecutionPhase::Setup, amount(slots.len(), 16, 64)?)?;
    // The original scan price is paid first. Preview only current validity and
    // immutable recipe costs; an unsupported or denied group stays ordered.
    let effects = prepared.map_or(slots, |prepared| &prepared.effects);
    let available = match prepared {
        Some(prepared) => prepared_preview(slots, prepared, recipes, frames, arena, work),
        None => preview(slots, recipes, frames, arena, work),
    };
    if let Some((total, charges)) = available
        && charges > 1
        && let Some(mut paid) = work.try_retirement_batch(total)
    {
        child_probe_add(0, 1); child_probe_add(1, slots.len() as u64); child_probe_add(4, effects.len() as u64);
        if prepared.is_some() {
            child_probe_add(2, 1);
            for &slot in slots.iter().filter(|s| effects.binary_search(s).is_err()) {
                child_probe_add(3, 1);
                child_probe_add(if recipes.get(slot as usize).is_some() {7} else {8}, 1);
                if !frames.retirement_is_empty(recipes, slot as u32) || arena.native_entry_preview(slot as u32, paid.meter())?.is_some() { child_probe_add(6, 1); }
            }
        }
        #[cfg(all(test, feature = "canonical-native-program"))]
        if prepared.is_some() {
            for &slot in slots.iter().filter(|s| !effects.contains(s)) {
                assert!(frames.retirement_is_empty(recipes, slot as u32));
                assert!(
                    arena
                        .native_entry_preview(slot as u32, paid.meter())?
                        .is_none()
                );
            }
        }
        // Empty completed-child storage has no owner, generation or visit
        // effect. Consume its ORIGINAL prices on this same exclusive receipt.
        paid.pay(prepared.map_or(0, |prepared| prepared.omitted_work))?;
        for &slot in effects {
            if frames.retire_prepaid(recipes, slot as u32, &mut paid)? {
                // The same batch preview checked this selected container's
                // canonical slot is empty. Only its frame can hold storage;
                // retain the original arena price on the existing paid loan.
                paid.pay(32)?;
            } else {
                arena.retire_current_prepaid(slot as u32, &mut paid)?;
            }
        }
        paid.finish()?;
        #[cfg(all(test, feature = "canonical-native-program"))]
        BATCHES.with(|count| count.set(count.get() + 1));
        #[cfg(all(test, feature = "canonical-native-program"))]
        CHILD_EFFECTS.with(|count| count.set(count.get() + (slots.len() - effects.len()) as u64));
        return Ok(true);
    }
    child_probe_add(5, 1);
    for &slot in slots {
        frames.retire(recipes, slot as u32, work)?;
        arena.retire_current(slot as u32, work)?;
    }
    Ok(false)
}

fn prepared_preview(
    slots: &[u64],
    prepared: &Boundary,
    recipes: &FrameRetirements,
    frames: &buffer_frames::BufferFrames,
    arena: &NativeValueArena<'_>,
    work: &NativeWorkMeter,
) -> Option<(u64, usize)> {
    if prepared.has_frames && !frames.has_retirement_backing() {
        return None;
    }
    // Even an entirely omitted inventory retains the original arena/account
    // validity requirement. Every prepared ordinal is in this exact plan.
    arena
        .native_entry_preview(u32::try_from(*slots.first()?).ok()?, work)
        .ok()?;
    for &slot in &prepared.effects {
        let slot = u32::try_from(slot).ok()?;
        if recipes.get(slot as usize).is_some() {
            if arena.native_entry_preview(slot, work).ok()?.is_some() {
                return None;
            }
        } else if !arena.native_retirement_available(slot, work).ok()? {
            return None;
        }
    }
    Some((prepared.total, prepared.charges))
}

fn preview(
    slots: &[u64],
    recipes: &FrameRetirements,
    frames: &buffer_frames::BufferFrames,
    arena: &NativeValueArena<'_>,
    work: &NativeWorkMeter,
) -> Option<(u64, usize)> {
    let mut total = 0u64;
    let mut charges = slots.len();
    for &slot in slots {
        let slot = u32::try_from(slot).ok()?;
        if let Some((charge, _)) = recipes.get(slot as usize) {
            // This recipe is derived only for selected frame containers, not
            // their projected canonical fields. An unexpected canonical
            // definition conservatively keeps the entire original ordered path.
            if !frames.has_retirement_backing()
                || arena.native_entry_preview(slot, work).ok()?.is_some()
            {
                return None;
            }
            total = total.checked_add(charge)?;
            charges = charges.checked_add(1)?;
        } else if !arena.native_retirement_available(slot, work).ok()? {
            return None;
        }
        total = total.checked_add(32)?;
    }
    Some((total, charges))
}

#[cfg(all(test, feature = "canonical-native-program"))]
thread_local! {
    static BATCHES: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
    static CHILD_EFFECTS: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
}

#[cfg(all(test, feature = "canonical-native-program"))]
pub(super) fn take_observation() -> u64 {
    BATCHES.with(|count| count.replace(0))
}

#[cfg(all(test, feature = "canonical-native-program"))]
pub(super) fn take_child_observation() -> u64 {
    CHILD_EFFECTS.with(|count| count.replace(0))
}

static CHILD_PROBE: [std::sync::atomic::AtomicU64; 9] = [const { std::sync::atomic::AtomicU64::new(0) }; 9];
fn child_probe_add(at: usize, value: u64) { CHILD_PROBE[at].fetch_add(value, std::sync::atomic::Ordering::Relaxed); }
#[unsafe(no_mangle)] pub extern "C" fn mech_child_cleanup_probe_reset() { for x in &CHILD_PROBE { x.store(0, std::sync::atomic::Ordering::Relaxed); } }
#[unsafe(no_mangle)] pub extern "C" fn mech_child_cleanup_probe_get(at: u32) -> u64 { CHILD_PROBE[at as usize].load(std::sync::atomic::Ordering::Relaxed) }
