from pathlib import Path
import datetime,fcntl,hashlib,json,subprocess,sys,tarfile
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack')
# Serialize the short Git write phase across independent build/check receipts.
archive_lock=(r/'.archive.lock').open('a');fcntl.flock(archive_lock,fcntl.LOCK_EX)
stage=sys.argv[1];paths=[Path(x) for x in sys.argv[2:]]
assert all(p.exists() for p in paths), [str(p) for p in paths if not p.exists()]
files=sorted({f for p in paths for f in ([p] if p.is_file() else p.rglob('*')) if f.is_file() and f.suffix not in {'.rlib'}})
# Executable payloads stay private; all source, commands, stdout, stderr and receipts remain archived.
files=[f for f in files if not f.name in {'gpu-unit-tests','before','after','current','frame-before','frame-after','tests','engine-tests','inspect'}]
p=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-50'/stage;p.mkdir(parents=True,exist_ok=False)
with tarfile.open(p/'receipts.tar.gz','w:gz') as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'files':[{'path':str(f.relative_to(r)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]}
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['git','add',str(p)],cwd=w,check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Record completed child cleanup experiment '+stage+' evidence immediately'],cwd=w,check=True)
print('ARCHIVED',stage,len(files),flush=True)
