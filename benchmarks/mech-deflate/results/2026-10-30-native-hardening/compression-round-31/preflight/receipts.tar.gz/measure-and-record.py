from pathlib import Path
import subprocess,json,hashlib,tarfile,datetime
r=Path('/private/tmp/mech-retirement-round31-20261030');p=r/'primary';w=Path('/private/tmp/mech-deflate-linear-stack')
q=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-31/timing';assert not q.exists()
code=1
try:
 process=subprocess.run(['python3',str(p/'run.py')],cwd=w);code=process.returncode
finally:
 q.mkdir(parents=True)
 files=sorted(f for f in p.iterdir() if f.is_file() and f.suffix in ['.json','.stdout','.stderr','.py','.rs','.log'])
 with tarfile.open(q/'receipts.tar.gz','w:gz') as archive:
  for f in files:archive.add(f,arcname=str(f.relative_to(r)),recursive=False)
 manifest={'command':['python3',str(p/'run.py')],'exit':code,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Immediately archived complete primary campaign, or all partial evidence on failure; no profile or scalar observations mixed in','files':[{'path':str(f.relative_to(r)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]}
 (q/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 if (p/'results.json').exists():
  results=json.loads((p/'results.json').read_text())
  # Keep all raw rows in the archive, and a concise independent summary here.
  summary={k:v for k,v in results.items() if k!='controls'};summary['controls']={label:{k:v for k,v in control.items() if k not in ['primary','all_observations','pairs']} for label,control in results['controls'].items()}
  (q/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 subprocess.run(['git','add',str(q)],cwd=w,check=True);subprocess.run(['git','commit','-m','Record balanced retirement-only timing immediately'],cwd=w,check=True)
raise SystemExit(code)
