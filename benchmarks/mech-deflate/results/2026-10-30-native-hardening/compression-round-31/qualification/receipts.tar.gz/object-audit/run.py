from pathlib import Path
import subprocess,json,hashlib,time
r=Path('/private/tmp/mech-retirement-round31-20261030/object-audit');parent=r.parent
for label,meta in [('before','before-build.json'),('after','current-build.json')]:
 b=json.loads((parent/'primary'/meta).read_text());c=b['command'][:-3];i=c.index('-C',c.index('-C')+2);del c[i:i+2];c += [str(r/'object-evidence.rs'),'-o',str(r/('object-'+label))]
 for stage,cmd in [('build',c),('run',[str(r/('object-'+label)),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc',str(r/label)])]:
  t=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
  (r/(label+'-'+stage+'.stdout')).write_text(p.stdout);(r/(label+'-'+stage+'.stderr')).write_text(p.stderr);(r/(label+'-'+stage+'.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'libraries':b['libraries']},indent=2)+'\n');print(label,stage,p.returncode,flush=True);p.check_returncode()
assert (r/'before.o').read_bytes()==(r/'after.o').read_bytes()
assert (r/'before.json').read_bytes()==(r/'after.json').read_bytes()
(r/'comparison.json').write_text(json.dumps({'object_bytes_equal':True,'metadata_bytes_equal':True,'object_bytes':(r/'after.o').stat().st_size,'object_sha256':hashlib.sha256((r/'after.o').read_bytes()).hexdigest(),'metadata_sha256':hashlib.sha256((r/'after.json').read_bytes()).hexdigest(),'scope':'Fresh emission through both frozen production libraries; no timings'},indent=2)+'\n')
print((r/'comparison.json').read_text(),flush=True)
