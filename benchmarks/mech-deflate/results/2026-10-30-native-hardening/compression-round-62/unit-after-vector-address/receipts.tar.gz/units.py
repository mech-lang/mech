"""Compile current GPU unit source against frozen dependencies; parent first."""
from pathlib import Path
import json,os,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-first-change-spill-round61-20261031')
phase=sys.argv[1] if len(sys.argv)>1 else 'after';assert phase=='after';p=r/'units-after';p.mkdir()
scope=json.loads((r/'source-scope.json').read_text())
import hashlib
patch=subprocess.check_output(['git','diff',scope['baseline_build_source'],'--','hosts/gpu/src'],cwd=w);assert hashlib.sha256(patch).hexdigest()==scope['production_diff_sha256']
b=json.loads((old/'units-after/build.json').read_text());libs=json.loads((r/'final-libraries.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'gpu-unit-tests')
for i,arg in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=arg.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
cmd[1:1]=['-L','dependency='+str(r/'variants/after/dependency')]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
if phase=='after':
 release=json.loads((r/'final-release.json').read_text())['source_head'];assert source==release or subprocess.check_output(['git','diff',release,'HEAD','--','hosts/gpu/src'],cwd=w,text=True)==''
snapshots=[]
target=p/'control-source.rs';target.write_bytes((w/'hosts/gpu/src/native_artifact/codegen/control/mod.rs').read_bytes());snapshots.append(target)
for name,relative in [('numeric-boundary-source.rs','codegen/numeric_boundary.rs'),('numeric-first-change-source.rs','runtime/numeric_first_change_tests.rs'),('runtime-tests-source.rs','runtime/tests.rs')]:
 target=p/name;target.write_bytes((w/'hosts/gpu/src/native_artifact/program'/relative).read_bytes());snapshots.append(target)
def run(label,command,expected=None):
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':source,'phase':phase,'libraries':libs,'scope':'Current GPU unit source, retained opt1 warnings-as-errors flags; all non-GPU dependencies are frozen R61 artifacts. Existing unchanged regressions run against the pinned pointer-locality candidate; no new parent test is claimed.'}
 if label.endswith('inventory'):row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M))
 match=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)
 if match:row.update(executed_tests=int(match[1])+int(match[2]),passed_tests=int(match[1]),failed_tests=int(match[2]))
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 files=[p/(label+'.'+x) for x in ['json','stdout','stderr']]+[r/'units.py',*snapshots,r/'findings-packet/production.patch',r/'source-scope.json']
 subprocess.run(['python3',str(r/'archive.py'),'unit-'+phase+('-fixed-' if phase=='parent' else '-')+label,*map(str,files)],cwd=w,check=True)
 print(phase,label,q.returncode,row.get('listed_tests',row.get('executed_tests')),flush=True)
 if q.returncode:print(q.stdout[-5000:]+q.stderr[-5000:],flush=True)
 q.check_returncode()
 if expected is not None:assert row.get('listed_tests',row.get('executed_tests'))==expected,(label,row)
run('build',cmd)
for label,selection in [('vector-address','native_artifact::program::codegen::numeric_words::tests::unit_dimension_addresses_emit_no_division_and_keep_general_geometry'),('first-change','delayed_numeric_first_changes_preserve_current_scalars_two_arrays_and_retry')]:
 exact=['--exact'] if label=='vector-address' else []
 run(label+'-inventory',[str(p/'gpu-unit-tests'),selection,*exact,'--list'],1)
 run(label,[str(p/'gpu-unit-tests'),selection,*exact,'--nocapture','--test-threads=1'],1)

selection=['native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map']
run('runtime-inventory',[str(p/'gpu-unit-tests'),*selection,'--list'],328)
run('runtime',[str(p/'gpu-unit-tests'),*selection,'--nocapture','--test-threads=1'],328)
