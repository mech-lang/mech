from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');label=sys.argv[1];p=r/'linked-primary'/label;p.mkdir(parents=True)
old=Path('/private/tmp/mech-scalar-child-round39-20261030');base=json.loads((old/'primary/current-build.json').read_text());original=(old/'workers/session.rs').read_text();needle='let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();';assert original.count(needle)==1
variant=r/'variants'/label;libs=json.loads((variant/'libraries.json').read_text());revision=json.loads((variant/'host.json').read_text())['source_head'];aux=json.loads((r/'auxiliary-dependencies.json').read_text());dep=variant/'dependency';cmd_base=base['command'].copy()
for i,a in enumerate(cmd_base):
 if i and cmd_base[i-1]=='--extern':key=a.split('=')[0];cmd_base[i]=key+'='+libs[key]['path']
cmd_base[1:1]=['-L','dependency='+str(dep),'-L','dependency='+str(variant)]
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc');assert sha(artifact)=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7';assert sha(artifact.with_suffix('.mec'))=='331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9'
def run(name,command):
 at=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 (p/(name+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':revision,'libraries':libs,'auxiliary_dependencies':aux},indent=2)+'\n');print(label,name,q.returncode,flush=True)
 if q.returncode:print(q.stderr[-5000:],flush=True)
 q.check_returncode()
source=Path('/private/tmp/mech-retirement-round36-20261030/object/inspect.rs').read_text().replace('/private/tmp/mech-retirement-round36-20261030/object',str(p));(p/'inspect.rs').write_text(source)
cmd=cmd_base.copy();cmd[-3]=str(p/'inspect.rs');cmd[-1]=str(p/'inspect');run('object-build',cmd);run('emit',[str(p/'inspect')]);(p/'inspect').unlink()
meta=json.loads((p/'metadata.json').read_text());identity=meta['identity_symbol'];entry=meta['entry_symbol'];prefix='unsafe extern "C" {\n #[link_name="'+identity+'"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES];\n #[link_name="'+entry+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64;\n}\n'
replacement='// SAFETY: exact same-build Object, unchanged image and matching frozen dependencies are pinned before linking; symbols outlive every call.\n let jit=unsafe {mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("'+str(p/'descriptor.json')+'"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();'
source=prefix+original.replace(needle,replacement).replace('"phase":"compiled"','"phase":"linked-compressor-image-restored"');(p/'worker.rs').write_text(source);normalized=source.replace(identity,'<IDENTITY>').replace(str(p/'descriptor.json'),'<IMAGE>')
cmd=cmd_base.copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'object.o')];run('worker-build',cmd);run('smoke',[str(p/'worker'),str(artifact),'0'])
rows=[json.loads(x) for x in (p/'smoke.stdout').read_text().splitlines() if x.startswith('{')];assert len(rows)==2 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==60260219686 for x in rows);assert (p/'smoke.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
pins={name:{'sha256':sha(p/name),'bytes':(p/name).stat().st_size} for name in ['object.o','descriptor.json','metadata.json']}
binding={'compiler_source':revision,'expected_work':60260219686,'pins':pins,'worker_sha256':sha(p/'worker'),'worker_source_sha256':sha(p/'worker.rs'),'original_worker_sha256':sha(old/'workers/session.rs'),'normalized_source_sha256':hashlib.sha256(normalized.encode()).hexdigest(),'libraries':libs,'auxiliary_dependencies':aux,'scope':'Frozen identical R61 Core/Engine/Stdlib/Runtime/Compute/math/syntax/common dependencies; only GPU rebuilt for candidate. Same respective image/Object for primary and counter/profile consumers; unchanged timer/source/bytecode/allocator/output reuse.'};(p/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
assert meta['typed_ir_version']==132
if label=='after':assert binding['normalized_source_sha256']==json.loads((r/'linked-primary/before/binding.json').read_text())['normalized_source_sha256']
files=[f for f in p.iterdir() if f.is_file() and f.name not in {'object.o','descriptor.json','worker','inspect'}]
subprocess.run(['python3',str(r/'archive.py'),'linked-build-'+label,*map(str,files),str(r/'linked-build.py')],cwd=w,check=True)
