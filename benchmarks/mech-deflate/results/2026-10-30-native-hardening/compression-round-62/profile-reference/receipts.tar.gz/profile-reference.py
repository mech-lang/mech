from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'reference-profile';p.mkdir();binary=Path('/private/tmp/mech-deflate-profiling-20261028/roc-profile')
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='3941ef59b2c9343d0493cc6b6d14ca4803e6bd27acfe520b1fb59d9b63026324'
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [x for x in active if Path(x.strip()).name in {'rustc','cargo','worker','gpu-unit-tests','tests','native_frame_transport'}]
cmd=[str(binary),'12'];sample_command=None
with (p/'run.stdout').open('w') as out,(p/'run.stderr').open('w') as err:
 process=subprocess.Popen(cmd,cwd=w,stdout=out,stderr=err)
 try:
  while process.poll() is None:
   if (p/'run.stdout').stat().st_size>4096:
    sample_command=['sample',str(process.pid),'2','-file',str(p/'sample.txt')];q=subprocess.run(sample_command,capture_output=True,text=True);(p/'sampler.stdout').write_text(q.stdout);(p/'sampler.stderr').write_text(q.stderr);q.check_returncode();break
   time.sleep(.005)
  code=process.wait()
 finally:
  if process.poll() is None:process.terminate();process.wait()
assert sample_command is not None and code==0
assert (p/'run.stdout').read_text().count('rep\troc-deflate\t')==20000
(p/'run.json').write_text(json.dumps({'command':cmd,'exit':code,'sample_command':sample_command,'sample_exit':q.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'reference_observations':20000,'all_observations_excluded_from_primary':True,'scope':'Fresh serial sampling of the exact reference executable and level; includes surrounding harness/printing, not timer percentages.'},indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'profile-reference',str(p),str(r/'profile-reference.py')],cwd=w,check=True)
