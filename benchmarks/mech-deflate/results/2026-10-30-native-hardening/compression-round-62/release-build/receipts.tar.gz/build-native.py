"""Rebuild only GPU against the exact frozen optimized R61 dependency graph."""
from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-first-change-spill-round61-20261031');p=r/'variants/after'
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
base=json.loads((old/'final-release.json').read_text());libs=json.loads((old/'final-libraries.json').read_text());aux=json.loads((old/'auxiliary-dependencies.json').read_text())
for name,pin in libs.items():assert sha(pin['path'])==pin['sha256'],name
for pin in aux['files']:assert sha(pin['path'])==pin['sha256'],pin['path']
scope=json.loads((r/'source-scope.json').read_text());patch=subprocess.check_output(['git','diff',scope['baseline_build_source'],'--','hosts/gpu/src'],cwd=w);assert hashlib.sha256(patch).hexdigest()==scope['production_diff_sha256'],'Production GPU delta changed after the R62 gate was frozen'
assert subprocess.check_output(['git','diff',scope['baseline_build_source'],'--','src'],cwd=w)==b'','Frozen non-GPU source must remain unchanged'
assert not (p/'libmech_gpu.rlib').exists(),'Refuse to overwrite a measured candidate'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True);assert not status.strip(),status
cmd=base['command'].copy();assert cmd[-3]==str(w/'hosts/gpu/src/lib.rs') and cmd[-2]=='-o';cmd[-1]=str(p/'libmech_gpu.rlib')
at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('host.'+stream)).write_text(getattr(q,stream))
row={'command':cmd,'environment':base['environment'],'source_head':head,'status_before':status,'exit':q.returncode,'seconds':time.monotonic()-at,'profile':'Exact retained opt3 warnings-as-errors native host flags. Frozen R61 Core/Engine/Stdlib/Runtime/Compute/math/syntax/common dependencies; only GPU source is rebuilt.'}
(p/'host.json').write_text(json.dumps(row,indent=2)+'\n')
if q.returncode:print(q.stderr[-6000:],flush=True)
subprocess.run(['python3',str(r/'archive.py'),'release-build',str(p/'host.json'),str(p/'host.stdout'),str(p/'host.stderr'),str(r/'build-native.py')],cwd=w,check=True)
q.check_returncode();libs['mech_gpu']={**libs['mech_gpu'],'path':str(p/'libmech_gpu.rlib'),'sha256':sha(p/'libmech_gpu.rlib')}
for target in [p/'libraries.json',r/'final-libraries.json']:target.write_text(json.dumps(libs,indent=2)+'\n')
(r/'final-release.json').write_text(json.dumps(row,indent=2)+'\n')
implementation={'candidate_build_source':head,'baseline_build_source':base['source_head'],'baseline_directory':str(old),'scope':'Keep the captured program locals pointer in an invocation-owned stack home and reload it per source block; unchanged source program, bytecode, resource pricing, runtime admission, dependency graph, allocator and evaluate_into timing. Candidate Object/image/metadata are freshly emitted and independently pinned; Object identity equality with baseline is not required.','unchanged_libraries':[name for name in libs if name!='mech_gpu'],'expected_allocation_requests_before':8173,'expected_allocation_requests_after':8173}
(r/'implementation.json').write_text(json.dumps(implementation,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'release-frozen',str(p/'libraries.json'),str(r/'final-release.json'),str(r/'implementation.json'),str(r/'auxiliary-dependencies.json'),str(r/'allocation-target.json'),str(r/'source-scope.json'),str(r/'findings-packet/production.patch'),str(r/'build-native.py')],cwd=w,check=True)
print('OPTIMIZED_GPU_BUILT',row['seconds'],flush=True)
