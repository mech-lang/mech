"""Qualify the entry-pointer snapshot on parent and candidate production."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time
r=Path(__file__).resolve().parent
w=Path('/private/tmp/mech-deflate-linear-stack')
p=r/'snapshot-controls';p.mkdir(exist_ok=True)
control=w/'hosts/gpu/src/native_artifact/codegen/control/mod.rs'
candidate=control.read_bytes()
parent_source='6f412525daf0f7284d4ef6bc2bd8e21f95d22e96'
parent=subprocess.check_output(['git','show',parent_source+':hosts/gpu/src/native_artifact/codegen/control/mod.rs'],cwd=w)
base=json.loads((r/'units-after/build.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
# Formatting is the only production change after the measured compiler build.
measured=subprocess.check_output(['git','show','ded89a9c0014fe66734be22ee6a3170e7ec10448:hosts/gpu/src/native_artifact/codegen/control/mod.rs'],cwd=w)
formatted=subprocess.run(['/Users/coreymontella/.rustup/toolchains/nightly-2026-03-03-aarch64-apple-darwin/bin/rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=measured,capture_output=True,check=True)
assert formatted.stdout==candidate,'The measured producer may only be changed by the pinned formatter'
selection='native_artifact::program::runtime::tests::locals_snapshot::entry_locals_snapshot_survives_callback_pointer_change_and_fresh_invocations'
sha=lambda data:hashlib.sha256(data).hexdigest()
for label,source in [('parent',parent),('after',candidate)]:
 qdir=p/label;qdir.mkdir()
 cmd=base['command'].copy();cmd[-1]=str(qdir/'gpu-unit-tests')
 def run(name,command,count=None,inventory=False):
  started=time.monotonic()
  q=subprocess.run(command,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
  for stream in ['stdout','stderr']:(qdir/(name+'.'+stream)).write_text(getattr(q,stream))
  row={'command':command,'exit':q.returncode,'seconds':time.monotonic()-started,'environment':base['environment'],'test_source_head':head,'production_control_sha256':sha(source),'baseline_build_source':parent_source,'candidate_build_source':'ded89a9c0014fe66734be22ee6a3170e7ec10448','phase':label,'scope':'Current regression source with parent/candidate control emitter; identical frozen non-GPU dependencies and retained opt1 warnings-as-errors feature profile. No performance claim.'}
  if count is not None:
   if inventory:row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
   else:
    m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)
    row['executed_tests']=int(m[1])+int(m[2]) if m else None
    row['passed_tests']=int(m[1]) if m else None
    row['failed_tests']=int(m[2]) if m else None
    observed=row['executed_tests']
   row['expected_tests']=count
  (qdir/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  files=[qdir/(name+'.'+s) for s in ['json','stdout','stderr']]+[qdir/'control-source.rs',r/'snapshot-controls.py']
  files += [p/'runtime-tests-source.rs',p/'locals-snapshot-source.rs']
  subprocess.run(['python3',str(r/'archive.py'),'snapshot-'+label+'-'+name,*map(str,files)],cwd=w,check=True)
  print(label,name,q.returncode,flush=True)
  if q.returncode:print(q.stdout[-4000:]+q.stderr[-5000:],flush=True)
  q.check_returncode()
  if count is not None:assert observed==count,(name,row)
 (qdir/'control-source.rs').write_bytes(source)
 for name,path in [('runtime-tests-source.rs','tests.rs'),('locals-snapshot-source.rs','locals_snapshot_tests.rs')]:
  (p/name).write_bytes((w/'hosts/gpu/src/native_artifact/program/runtime'/path).read_bytes())
 try:
  control.write_bytes(source)
  run('build',cmd)
 finally:control.write_bytes(candidate)
 run('inventory',[cmd[-1],selection,'--exact','--list'],1,True)
 run('run',[cmd[-1],selection,'--exact','--nocapture','--test-threads=1'],1)
 if label=='after':
  run('runtime-inventory',[cmd[-1],'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--list'],329,True)
  selected=['composition_tests','parent_continuation_is_single_use','native_runtime_consolidation','buffer_frames::tests::batching','buffer_frames::tests::transfer','work::retirement::tests','exhausted_retirement_generation','cleanup_effects::tests','numeric_shadow','numeric_words::tests','numeric_first_change','entry_locals_snapshot']
  run('ci-inventory',[cmd[-1],*selected,'--list'],35,True)
  run('ci-run',[cmd[-1],*selected,'--nocapture','--test-threads=1'],35)
 Path(cmd[-1]).unlink()
print('SNAPSHOT_PARENT_AND_CANDIDATE_PASS',flush=True)
