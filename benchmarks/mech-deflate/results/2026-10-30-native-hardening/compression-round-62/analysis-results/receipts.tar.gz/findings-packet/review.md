# Independent source review: captured locals-pointer home

Reviewed commits: 282aad36624d72ad6f9ee430ed4ed063c9f12c35 and ded89a9c0014fe66734be22ee6a3170e7ec10448 against retained R61 production 6f412525daf0f7284d4ef6bc2bd8e21f95d22e96. Read-only source review; this document does not claim execution or replace external review.

No introduced semantic defect found in this bounded change.

The prologue reads and checks the entry locals pointer before storing it in one eight-byte, eight-aligned explicit stack slot. This is a snapshot of the originally admitted invocation pointer. It does not reread mutable callback-visible Frame memory, allocate a managed owner, acquire new admission, or capture another invocation's frame. The slot address is never passed to a helper. Nested calls have their own machine frames.

Every reachable ordinary source block loads the same slot before lowering that block's specialized regions and actions. The prologue store dominates these paths. Early ABI rejection reaches the error return without reading the slot. Existing prefix resume and shared abort still use the original captured SSA pointer, which has the same value. The block-local shadow is passed consistently to subsequent loads, stores, callbacks and specialization emitters; no carrier/value data is cached by this change. Non-program compilation does not create or load the slot.

The one additional per-block load is included in the existing conservative visit-template verification. The allowance itself is unchanged. Compiled stack size is measured from the real compiled buffer, and compile-time stack limits plus runtime descriptor stack checks remain in place. All algorithmic charges, arguments, owners, account authority, publication, failure cleanup and retry paths remain unchanged.

Performance remains an empirical question. The original SSA pointer is still used by prefix resume and shared abort; that may preserve some long-lived register allocation pressure. A per-block load can itself add work where register allocation previously retained the pointer. The retained decision must follow the fresh elapsed, retired-instruction and actual Object audits, including adverse directions.

Key source locations: hosts/gpu/src/native_artifact/codegen/control/mod.rs prologue around 469–505, per-block lowering around 800, visit audit around 1537, shared abort around 1560, actual stack measurement around 1614–1643; hosts/gpu/src/native_artifact/program/runtime/session/mod.rs around 586–591 enforces descriptor stack limits. Exact source is pinned by the production patch receipt.
