#!/usr/bin/env python3
"""Static ARM64 pointer-home audit; never runs the generated program.

Infer early entry-pointer stack homes by conservative straight-line provenance
before the first call, retaining every supporting instruction. A reviewer must
check this bounded prologue evidence. Whole-Object counts are static, not visits.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess

INSN = re.compile(r'^\s*([0-9a-f]+):\s+([^\s]+)\s*(.*?)\s*$')
REG = re.compile(r'^[xw](\d+)$')
FIELDS = {0x20: 'inputs', 0x28: 'locals', 0x30: 'outputs',
          0x38: 'context', 0x40: 'admit_callback', 0x50: 'helper',
          0x58: 'result', 0x60: 'arguments', 0x68: 'argument_capacity'}


def integer(text):
    return int(text.removeprefix('#').strip(), 0)


def reg(text):
    match = REG.fullmatch(text.strip())
    return 'x' + match[1] if match else None


def stack_offset(operand, x16):
    if '[sp, x16, sxtx]' in operand:
        return x16
    match = re.search(r'\[sp(?:, #(0x[0-9a-f]+|\d+))?\]', operand)
    return integer(match[1] or '0') if match else None


def audit(path, destination):
    destination.mkdir(parents=True, exist_ok=True)
    command = ['xcrun', 'llvm-objdump', '-d', '--disassemble-zeroes', '--no-show-raw-insn', str(path)]
    registers = {'x0': 'frame'}
    homes = {}
    stores = []
    # This is an early, straight-line provenance map, not a CFG dataflow proof.
    # No inference survives a call, return or unconditional branch.
    tracking = True
    x16 = None
    counts = {kind: collections.Counter() for kind in [
        'stack_load', 'stack_store', 'indexed_stack_load', 'indexed_stack_store']}
    previous = collections.deque(maxlen=100)
    windows, pending, prologue = [], [], []
    opcode_counts = collections.Counter()
    with (destination / 'objdump.stderr').open('w') as errors:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=errors, text=True)
        for line in process.stdout:
            match = INSN.match(line)
            if not match:
                continue
            address_text, opcode, operand = match.groups()
            address = int(address_text, 16)
            opcode_counts[opcode] += 1
            if address < 0x1800:
                prologue.append(line)
            for window in pending:
                window['lines'].append(line)
                window['remaining'] -= 1
            pending = [window for window in pending if window['remaining'] > 0]
            anchor = re.match(r'^x1,\s*#(0x31c|0x31d|796|797)(?:\s|;|$)', operand)
            if opcode == 'mov' and anchor:
                window = {'anchor': hex(address), 'site': integer(anchor[1]),
                          'lines': list(previous) + [line], 'remaining': 100}
                windows.append(window)
                pending.append(window)
            previous.append(line)

            arguments = operand.split(';', 1)[0].strip()
            first = reg(arguments.split(',', 1)[0])
            # Loads may overwrite x16 itself; the effective address uses its
            # value before that destination write.
            memory_x16 = x16
            if opcode == 'mov' and (m := re.match(r'[wx]16, #(0x[0-9a-f]+|\d+)$', arguments)):
                x16 = integer(m[1])
            elif opcode == 'movk' and (m := re.match(r'[wx]16, #(0x[0-9a-f]+|\d+), lsl #16$', arguments)) and x16 is not None:
                x16 = (x16 & 0xffff) | (integer(m[1]) << 16)
            elif first == 'x16' and opcode not in ('cmp', 'cmn', 'tst', 'str', 'stur', 'stp'):
                x16 = None

            if opcode in ('ldr', 'ldur', 'str', 'stur', 'ldrb', 'strb'):
                offset = stack_offset(arguments, memory_x16)
                if offset is not None:
                    kind = 'load' if opcode.startswith('ld') else 'store'
                    counts['stack_' + kind][hex(offset)] += 1
                    if '[sp, x16, sxtx]' in arguments:
                        counts['indexed_stack_' + kind][hex(offset)] += 1

            if not tracking:
                continue
            if opcode in ('bl', 'blr', 'ret', 'retab', 'b'):
                tracking = False
                continue
            # Conditional guards do not update registers on the successful edge.
            if opcode.startswith('b.') or opcode in ('cbz', 'cbnz', 'tbz', 'tbnz', 'cmp', 'cmn', 'tst', 'pacibsp'):
                continue
            if opcode in ('str', 'stur'):
                offset = stack_offset(arguments, memory_x16)
                if offset is not None and first in registers:
                    role = registers[first]
                    homes[offset] = role
                    stores.append({'role': role, 'slot': hex(offset), 'instruction': line.strip()})
                elif offset is not None:
                    homes.pop(offset, None)
                continue
            if opcode in ('stp', 'strb', 'strh'):
                continue
            value = None
            if opcode == 'mov':
                parts = arguments.split(',')
                value = registers.get(reg(parts[1])) if len(parts) == 2 else None
            elif opcode in ('ldr', 'ldur'):
                offset = stack_offset(arguments, memory_x16)
                if offset is not None:
                    value = homes.get(offset)
                else:
                    m = re.search(r'\[(x\d+)(?:, #(0x[0-9a-f]+|\d+))?\]', arguments)
                    if m and registers.get(m[1]) == 'frame':
                        value = FIELDS.get(integer(m[2] or '0'))
            if first:
                registers.pop(first, None)
                if value is not None:
                    registers[first] = value

        if process.wait() != 0:
            raise RuntimeError('objdump failed; see ' + str(destination / 'objdump.stderr'))
    role_slots = collections.defaultdict(set)
    for store in stores:
        role_slots[store['role']].add(store['slot'])
    roles = {}
    for role, slots in sorted(role_slots.items()):
        roles[role] = {slot: {kind: counts[kind][slot] for kind in counts}
                       for slot in sorted(slots, key=lambda value: int(value, 16))}
    report = {
        'scope': 'Static Object counts, not dynamic visits or instruction-retirement counts.',
        'limitation': 'Roles inferred on successful straight-line entry before first call/branch; inspect evidence. Additional short-lived copies spilled later are not attributed by this bounded provenance pass.',
        'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'command': command, 'role_stores': stores, 'roles': roles,
        'totals': {kind: sum(counter.values()) for kind, counter in counts.items()},
        'counts': {kind: dict(counter.most_common()) for kind, counter in counts.items()},
        'opcodes': dict(opcode_counts),
        'source_anchors': {str(site): [window['anchor'] for window in windows if window['site'] == site]
                           for site in (796, 797)},
    }
    (destination / 'prologue.asm').write_text(''.join(prologue))
    for site in (796, 797):
        (destination / f'source{site}-context.asm').write_text(
            '; Helper site argument anchors; manually verify matching source action.\n' +
            ''.join('; Anchor ' + window['anchor'] + '\n' + ''.join(window['lines']) + '\n'
                    for window in windows if window['site'] == site))
    (destination / 'pointer-homes.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before', type=Path, required=True)
    parser.add_argument('--after', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    before = audit(args.before, args.out / 'before')
    after = audit(args.after, args.out / 'after')
    report = {'scope': before['scope'], 'inputs': {name: {key: value[key] for key in ('path', 'sha256')}
              for name, value in [('before', before), ('after', after)]},
              'roles': {name: value['roles'] for name, value in [('before', before), ('after', after)]},
              'totals': {kind: {'before': before['totals'][kind], 'after': after['totals'][kind],
                                 'delta': after['totals'][kind] - before['totals'][kind]}
                         for kind in before['totals']}}
    (args.out / 'pointer-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
