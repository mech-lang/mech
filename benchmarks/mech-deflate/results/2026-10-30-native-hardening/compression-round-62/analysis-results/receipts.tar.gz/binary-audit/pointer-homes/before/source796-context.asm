; Helper site argument anchors; manually verify matching source action.
; Anchor 0x20368
   201d8:      	b.ne	0xf278c <_mech_canonical_program_entry_v1+0xf278c>
   201dc:      	ldur	x0, [sp]
   201e0:      	mov	w16, #0x9a58            ; =39512
   201e4:      	movk	w16, #0x1, lsl #16
   201e8:      	ldr	x1, [sp, x16, sxtx]
   201ec:      	mov	w16, #0x3748            ; =14152
   201f0:      	movk	w16, #0x1, lsl #16
   201f4:      	str	x1, [sp, x16, sxtx]
   201f8:      	b	0xc790f4 <_mech_canonical_program_entry_v1+0xc790f4>
   201fc:      	mov	x7, #0x321              ; =801
   20200:      	ldur	x0, [sp]
   20204:      	str	x7, [x0, #0x48]
   20208:      	mov	w7, #0xd870             ; =55408
   2020c:      	movk	w7, #0x2, lsl #16
   20210:      	mov	w16, #0x9bd0            ; =39888
   20214:      	movk	w16, #0x1, lsl #16
   20218:      	ldr	x0, [sp, x16, sxtx]
   2021c:      	ldr	x10, [x0, x7]
   20220:      	cmp	x10, #0x0
   20224:      	b.ne	0x20260 <_mech_canonical_program_entry_v1+0x20260>
   20228:      	mov	x1, #0x321              ; =801
   2022c:      	mov	w16, #0x9bc0            ; =39872
   20230:      	movk	w16, #0x1, lsl #16
   20234:      	ldr	x2, [sp, x16, sxtx]
   20238:      	mov	w16, #0x9bc8            ; =39880
   2023c:      	movk	w16, #0x1, lsl #16
   20240:      	ldr	x0, [sp, x16, sxtx]
   20244:      	blr	x2
   20248:      	mov	x4, #0x2                ; =2
   2024c:      	mov	w16, #0x3748            ; =14152
   20250:      	movk	w16, #0x1, lsl #16
   20254:      	str	x4, [sp, x16, sxtx]
   20258:      	cmp	x0, #0x0
   2025c:      	b.ne	0xf2834 <_mech_canonical_program_entry_v1+0xf2834>
   20260:      	mov	x0, #0x322              ; =802
   20264:      	ldur	x1, [sp]
   20268:      	str	x0, [x1, #0x48]
   2026c:      	mov	w0, #0xd870             ; =55408
   20270:      	movk	w0, #0x2, lsl #16
   20274:      	mov	w16, #0x9bd0            ; =39888
   20278:      	movk	w16, #0x1, lsl #16
   2027c:      	ldr	x1, [sp, x16, sxtx]
   20280:      	ldr	x0, [x1, x0]
   20284:      	cmp	x0, #0x0
   20288:      	b.ne	0x202d4 <_mech_canonical_program_entry_v1+0x202d4>
   2028c:      	mov	x1, #0x322              ; =802
   20290:      	mov	w16, #0x9bc0            ; =39872
   20294:      	movk	w16, #0x1, lsl #16
   20298:      	ldr	x2, [sp, x16, sxtx]
   2029c:      	mov	w16, #0x9bc8            ; =39880
   202a0:      	movk	w16, #0x1, lsl #16
   202a4:      	ldr	x0, [sp, x16, sxtx]
   202a8:      	blr	x2
   202ac:      	mov	x1, #0x2                ; =2
   202b0:      	mov	w16, #0x3748            ; =14152
   202b4:      	movk	w16, #0x1, lsl #16
   202b8:      	str	x1, [sp, x16, sxtx]
   202bc:      	cmp	x0, #0x0
   202c0:      	b.ne	0xf2838 <_mech_canonical_program_entry_v1+0xf2838>
   202c4:      	mov	w16, #0x9bd0            ; =39888
   202c8:      	movk	w16, #0x1, lsl #16
   202cc:      	ldr	x0, [sp, x16, sxtx]
   202d0:      	b	0x202e0 <_mech_canonical_program_entry_v1+0x202e0>
   202d4:      	mov	w16, #0x9bd0            ; =39888
   202d8:      	movk	w16, #0x1, lsl #16
   202dc:      	ldr	x0, [sp, x16, sxtx]
   202e0:      	mov	w16, #0x9bd0            ; =39888
   202e4:      	movk	w16, #0x1, lsl #16
   202e8:      	ldr	x0, [sp, x16, sxtx]
   202ec:      	ldr	x0, [x0, #0x218]
   202f0:      	mov	w16, #0x9bd0            ; =39888
   202f4:      	movk	w16, #0x1, lsl #16
   202f8:      	ldr	x1, [sp, x16, sxtx]
   202fc:      	str	x0, [x1, #0x1af8]
   20300:      	b	0x206ac <_mech_canonical_program_entry_v1+0x206ac>
   20304:      	mov	x0, #0x31b              ; =795
   20308:      	ldur	x4, [sp]
   2030c:      	str	x0, [x4, #0x48]
   20310:      	mov	w0, #0xd870             ; =55408
   20314:      	movk	w0, #0x2, lsl #16
   20318:      	mov	w16, #0x9bd0            ; =39888
   2031c:      	movk	w16, #0x1, lsl #16
   20320:      	ldr	x1, [sp, x16, sxtx]
   20324:      	ldr	x0, [x1, x0]
   20328:      	cmp	x0, #0x0
   2032c:      	b.ne	0x20368 <_mech_canonical_program_entry_v1+0x20368>
   20330:      	mov	x1, #0x31b              ; =795
   20334:      	mov	w16, #0x9bc0            ; =39872
   20338:      	movk	w16, #0x1, lsl #16
   2033c:      	ldr	x13, [sp, x16, sxtx]
   20340:      	mov	w16, #0x9bc8            ; =39880
   20344:      	movk	w16, #0x1, lsl #16
   20348:      	ldr	x0, [sp, x16, sxtx]
   2034c:      	blr	x13
   20350:      	mov	x1, #0x2                ; =2
   20354:      	mov	w16, #0x3748            ; =14152
   20358:      	movk	w16, #0x1, lsl #16
   2035c:      	str	x1, [sp, x16, sxtx]
   20360:      	cmp	x0, #0x0
   20364:      	b.ne	0xf2880 <_mech_canonical_program_entry_v1+0xf2880>
   20368:      	mov	x1, #0x31c              ; =796
   2036c:      	ldur	x0, [sp]
   20370:      	str	x1, [x0, #0x48]
   20374:      	mov	w0, #0xd870             ; =55408
   20378:      	movk	w0, #0x2, lsl #16
   2037c:      	mov	w16, #0x9bd0            ; =39888
   20380:      	movk	w16, #0x1, lsl #16
   20384:      	ldr	x6, [sp, x16, sxtx]
   20388:      	ldr	x0, [x6, x0]
   2038c:      	cmp	x0, #0x0
   20390:      	b.ne	0x203d8 <_mech_canonical_program_entry_v1+0x203d8>
   20394:      	mov	w16, #0x9bc0            ; =39872
   20398:      	movk	w16, #0x1, lsl #16
   2039c:      	ldr	x2, [sp, x16, sxtx]
   203a0:      	mov	w16, #0x9bc8            ; =39880
   203a4:      	movk	w16, #0x1, lsl #16
   203a8:      	ldr	x0, [sp, x16, sxtx]
   203ac:      	blr	x2
   203b0:      	mov	x1, #0x2                ; =2
   203b4:      	mov	w16, #0x3748            ; =14152
   203b8:      	movk	w16, #0x1, lsl #16
   203bc:      	str	x1, [sp, x16, sxtx]
   203c0:      	cmp	x0, #0x0
   203c4:      	b.ne	0xf2884 <_mech_canonical_program_entry_v1+0xf2884>
   203c8:      	mov	w16, #0x9bd0            ; =39888
   203cc:      	movk	w16, #0x1, lsl #16
   203d0:      	ldr	x0, [sp, x16, sxtx]
   203d4:      	b	0x203e4 <_mech_canonical_program_entry_v1+0x203e4>
   203d8:      	mov	w16, #0x9bd0            ; =39888
   203dc:      	movk	w16, #0x1, lsl #16
   203e0:      	ldr	x0, [sp, x16, sxtx]
   203e4:      	mov	w16, #0x9bd0            ; =39888
   203e8:      	movk	w16, #0x1, lsl #16
   203ec:      	ldr	x0, [sp, x16, sxtx]
   203f0:      	ldr	x0, [x0, #0x1ac0]
   203f4:      	mov	w16, #0x9bd0            ; =39888
   203f8:      	movk	w16, #0x1, lsl #16
   203fc:      	ldr	x1, [sp, x16, sxtx]
   20400:      	ldr	x1, [x1, #0x278]
   20404:      	adds	x0, x0, x1
   20408:      	cset	x1, hs
   2040c:      	mov	x4, #0x1                ; =1
   20410:      	mov	w16, #0x3748            ; =14152
   20414:      	movk	w16, #0x1, lsl #16
   20418:      	str	x4, [sp, x16, sxtx]
   2041c:      	uxtb	w1, w1
   20420:      	cmp	w1, #0x0
   20424:      	b.ne	0xf29a0 <_mech_canonical_program_entry_v1+0xf29a0>
   20428:      	mov	w16, #0x9bd0            ; =39888
   2042c:      	movk	w16, #0x1, lsl #16
   20430:      	ldr	x1, [sp, x16, sxtx]
   20434:      	str	x0, [x1, #0x1b00]
   20438:      	mov	x1, #0x31d              ; =797
   2043c:      	ldur	x0, [sp]
   20440:      	str	x1, [x0, #0x48]
   20444:      	mov	x19, x1
   20448:      	mov	w0, #0xd870             ; =55408
   2044c:      	movk	w0, #0x2, lsl #16
   20450:      	mov	w16, #0x9bd0            ; =39888
   20454:      	movk	w16, #0x1, lsl #16
   20458:      	ldr	x1, [sp, x16, sxtx]
   2045c:      	ldr	x0, [x1, x0]
   20460:      	cmp	x0, #0x0
   20464:      	b.ne	0x204a0 <_mech_canonical_program_entry_v1+0x204a0>
   20468:      	mov	w16, #0x9bc0            ; =39872
   2046c:      	movk	w16, #0x1, lsl #16
   20470:      	ldr	x2, [sp, x16, sxtx]
   20474:      	mov	w16, #0x9bc8            ; =39880
   20478:      	movk	w16, #0x1, lsl #16
   2047c:      	ldr	x0, [sp, x16, sxtx]
   20480:      	mov	x1, x19
   20484:      	blr	x2
   20488:      	mov	x1, #0x2                ; =2
   2048c:      	mov	w16, #0x3748            ; =14152
   20490:      	movk	w16, #0x1, lsl #16
   20494:      	str	x1, [sp, x16, sxtx]
   20498:      	cmp	x0, #0x0
   2049c:      	b.ne	0xf29a4 <_mech_canonical_program_entry_v1+0xf29a4>
   204a0:      	mov	x0, #0x3                ; =3
   204a4:      	mov	w16, #0x3748            ; =14152
   204a8:      	movk	w16, #0x1, lsl #16
   204ac:      	str	x0, [sp, x16, sxtx]
   204b0:      	mov	w16, #0x9ba0            ; =39840
   204b4:      	movk	w16, #0x1, lsl #16
   204b8:      	ldr	x0, [sp, x16, sxtx]
   204bc:      	cmp	x0, #0x2
   204c0:      	b.lo	0xf29ec <_mech_canonical_program_entry_v1+0xf29ec>
   204c4:      	mov	x5, #0x0                ; =0
   204c8:      	mov	w16, #0x9ba8            ; =39848
   204cc:      	movk	w16, #0x1, lsl #16
   204d0:      	ldr	x0, [sp, x16, sxtx]
   204d4:      	str	x5, [x0]
   204d8:      	mov	w16, #0x9bd0            ; =39888
   204dc:      	movk	w16, #0x1, lsl #16
   204e0:      	ldr	x0, [sp, x16, sxtx]
   204e4:      	ldr	x0, [x0, #0x1b00]
   204e8:      	mov	w16, #0x9ba8            ; =39848
   204ec:      	movk	w16, #0x1, lsl #16
   204f0:      	ldr	x1, [sp, x16, sxtx]
   204f4:      	str	x0, [x1, #0x8]
   204f8:      	mov	x0, #0x2                ; =2

