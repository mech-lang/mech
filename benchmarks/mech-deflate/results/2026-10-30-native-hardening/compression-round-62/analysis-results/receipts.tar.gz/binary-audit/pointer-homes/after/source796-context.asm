; Helper site argument anchors; manually verify matching source action.
; Anchor 0x1b1e8
   1b058:      	str	x1, [x15, #0x48]
   1b05c:      	mov	w2, #0xd870             ; =55408
   1b060:      	movk	w2, #0x2, lsl #16
   1b064:      	ldr	x0, [x0, x2]
   1b068:      	cmp	x0, #0x0
   1b06c:      	b.ne	0x1b0a4 <_mech_canonical_program_entry_v1+0x1b0a4>
   1b070:      	mov	w16, #0xa2c8            ; =41672
   1b074:      	movk	w16, #0x1, lsl #16
   1b078:      	ldr	x2, [sp, x16, sxtx]
   1b07c:      	mov	w16, #0xa2d0            ; =41680
   1b080:      	movk	w16, #0x1, lsl #16
   1b084:      	ldr	x0, [sp, x16, sxtx]
   1b088:      	blr	x2
   1b08c:      	mov	x1, #0x2                ; =2
   1b090:      	mov	w16, #0x3698            ; =13976
   1b094:      	movk	w16, #0x1, lsl #16
   1b098:      	str	x1, [sp, x16, sxtx]
   1b09c:      	cmp	x0, #0x0
   1b0a0:      	b.ne	0xe7df8 <_mech_canonical_program_entry_v1+0xe7df8>
   1b0a4:      	ldur	x0, [sp, #0x8]
   1b0a8:      	mov	w16, #0xa158            ; =41304
   1b0ac:      	movk	w16, #0x1, lsl #16
   1b0b0:      	ldr	x1, [sp, x16, sxtx]
   1b0b4:      	mov	w16, #0x3698            ; =13976
   1b0b8:      	movk	w16, #0x1, lsl #16
   1b0bc:      	str	x1, [sp, x16, sxtx]
   1b0c0:      	b	0xb400b0 <_mech_canonical_program_entry_v1+0xb400b0>
   1b0c4:      	ldur	x0, [sp]
   1b0c8:      	mov	x1, #0x321              ; =801
   1b0cc:      	ldur	x2, [sp, #0x8]
   1b0d0:      	str	x1, [x2, #0x48]
   1b0d4:      	mov	w1, #0xd870             ; =55408
   1b0d8:      	movk	w1, #0x2, lsl #16
   1b0dc:      	ldr	x1, [x0, x1]
   1b0e0:      	cmp	x1, #0x0
   1b0e4:      	b.ne	0x1b120 <_mech_canonical_program_entry_v1+0x1b120>
   1b0e8:      	mov	x1, #0x321              ; =801
   1b0ec:      	mov	w16, #0xa2c8            ; =41672
   1b0f0:      	movk	w16, #0x1, lsl #16
   1b0f4:      	ldr	x2, [sp, x16, sxtx]
   1b0f8:      	mov	w16, #0xa2d0            ; =41680
   1b0fc:      	movk	w16, #0x1, lsl #16
   1b100:      	ldr	x0, [sp, x16, sxtx]
   1b104:      	blr	x2
   1b108:      	mov	x6, #0x2                ; =2
   1b10c:      	mov	w16, #0x3698            ; =13976
   1b110:      	movk	w16, #0x1, lsl #16
   1b114:      	str	x6, [sp, x16, sxtx]
   1b118:      	cmp	x0, #0x0
   1b11c:      	b.ne	0xe7e60 <_mech_canonical_program_entry_v1+0xe7e60>
   1b120:      	ldur	x19, [sp]
   1b124:      	mov	x7, #0x322              ; =802
   1b128:      	ldur	x0, [sp, #0x8]
   1b12c:      	str	x7, [x0, #0x48]
   1b130:      	mov	w7, #0xd870             ; =55408
   1b134:      	movk	w7, #0x2, lsl #16
   1b138:      	ldr	x10, [x19, x7]
   1b13c:      	cmp	x10, #0x0
   1b140:      	b.ne	0x1b17c <_mech_canonical_program_entry_v1+0x1b17c>
   1b144:      	mov	x1, #0x322              ; =802
   1b148:      	mov	w16, #0xa2c8            ; =41672
   1b14c:      	movk	w16, #0x1, lsl #16
   1b150:      	ldr	x2, [sp, x16, sxtx]
   1b154:      	mov	w16, #0xa2d0            ; =41680
   1b158:      	movk	w16, #0x1, lsl #16
   1b15c:      	ldr	x0, [sp, x16, sxtx]
   1b160:      	blr	x2
   1b164:      	mov	x1, #0x2                ; =2
   1b168:      	mov	w16, #0x3698            ; =13976
   1b16c:      	movk	w16, #0x1, lsl #16
   1b170:      	str	x1, [sp, x16, sxtx]
   1b174:      	cmp	x0, #0x0
   1b178:      	b.ne	0xe7e84 <_mech_canonical_program_entry_v1+0xe7e84>
   1b17c:      	ldr	x15, [x19, #0x218]
   1b180:      	str	x15, [x19, #0x1af8]
   1b184:      	b	0x1b448 <_mech_canonical_program_entry_v1+0x1b448>
   1b188:      	ldur	x0, [sp]
   1b18c:      	mov	x1, #0x31b              ; =795
   1b190:      	ldur	x7, [sp, #0x8]
   1b194:      	str	x1, [x7, #0x48]
   1b198:      	mov	w1, #0xd870             ; =55408
   1b19c:      	movk	w1, #0x2, lsl #16
   1b1a0:      	ldr	x0, [x0, x1]
   1b1a4:      	cmp	x0, #0x0
   1b1a8:      	b.ne	0x1b1e4 <_mech_canonical_program_entry_v1+0x1b1e4>
   1b1ac:      	mov	x1, #0x31b              ; =795
   1b1b0:      	mov	w16, #0xa2c8            ; =41672
   1b1b4:      	movk	w16, #0x1, lsl #16
   1b1b8:      	ldr	x13, [sp, x16, sxtx]
   1b1bc:      	mov	w16, #0xa2d0            ; =41680
   1b1c0:      	movk	w16, #0x1, lsl #16
   1b1c4:      	ldr	x0, [sp, x16, sxtx]
   1b1c8:      	blr	x13
   1b1cc:      	mov	x1, #0x2                ; =2
   1b1d0:      	mov	w16, #0x3698            ; =13976
   1b1d4:      	movk	w16, #0x1, lsl #16
   1b1d8:      	str	x1, [sp, x16, sxtx]
   1b1dc:      	cmp	x0, #0x0
   1b1e0:      	b.ne	0xe7eb0 <_mech_canonical_program_entry_v1+0xe7eb0>
   1b1e4:      	ldur	x26, [sp]
   1b1e8:      	mov	x1, #0x31c              ; =796
   1b1ec:      	ldur	x0, [sp, #0x8]
   1b1f0:      	str	x1, [x0, #0x48]
   1b1f4:      	mov	w0, #0xd870             ; =55408
   1b1f8:      	movk	w0, #0x2, lsl #16
   1b1fc:      	ldr	x0, [x26, x0]
   1b200:      	cmp	x0, #0x0
   1b204:      	b.ne	0x1b23c <_mech_canonical_program_entry_v1+0x1b23c>
   1b208:      	mov	w16, #0xa2c8            ; =41672
   1b20c:      	movk	w16, #0x1, lsl #16
   1b210:      	ldr	x2, [sp, x16, sxtx]
   1b214:      	mov	w16, #0xa2d0            ; =41680
   1b218:      	movk	w16, #0x1, lsl #16
   1b21c:      	ldr	x0, [sp, x16, sxtx]
   1b220:      	blr	x2
   1b224:      	mov	x1, #0x2                ; =2
   1b228:      	mov	w16, #0x3698            ; =13976
   1b22c:      	movk	w16, #0x1, lsl #16
   1b230:      	str	x1, [sp, x16, sxtx]
   1b234:      	cmp	x0, #0x0
   1b238:      	b.ne	0xe7f08 <_mech_canonical_program_entry_v1+0xe7f08>
   1b23c:      	ldr	x0, [x26, #0x1ac0]
   1b240:      	ldr	x1, [x26, #0x278]
   1b244:      	adds	x0, x0, x1
   1b248:      	cset	x1, hs
   1b24c:      	mov	x9, #0x1                ; =1
   1b250:      	mov	w16, #0x3698            ; =13976
   1b254:      	movk	w16, #0x1, lsl #16
   1b258:      	str	x9, [sp, x16, sxtx]
   1b25c:      	uxtb	w1, w1
   1b260:      	cmp	w1, #0x0
   1b264:      	b.ne	0xe7f0c <_mech_canonical_program_entry_v1+0xe7f0c>
   1b268:      	str	x0, [x26, #0x1b00]
   1b26c:      	ldur	x19, [sp]
   1b270:      	mov	x1, #0x31d              ; =797
   1b274:      	ldur	x0, [sp, #0x8]
   1b278:      	str	x1, [x0, #0x48]
   1b27c:      	mov	x21, x1
   1b280:      	mov	w0, #0xd870             ; =55408
   1b284:      	movk	w0, #0x2, lsl #16
   1b288:      	ldr	x0, [x19, x0]
   1b28c:      	cmp	x0, #0x0
   1b290:      	b.ne	0x1b2cc <_mech_canonical_program_entry_v1+0x1b2cc>
   1b294:      	mov	w16, #0xa2c8            ; =41672
   1b298:      	movk	w16, #0x1, lsl #16
   1b29c:      	ldr	x2, [sp, x16, sxtx]
   1b2a0:      	mov	w16, #0xa2d0            ; =41680
   1b2a4:      	movk	w16, #0x1, lsl #16
   1b2a8:      	ldr	x0, [sp, x16, sxtx]
   1b2ac:      	mov	x1, x21
   1b2b0:      	blr	x2
   1b2b4:      	mov	x1, #0x2                ; =2
   1b2b8:      	mov	w16, #0x3698            ; =13976
   1b2bc:      	movk	w16, #0x1, lsl #16
   1b2c0:      	str	x1, [sp, x16, sxtx]
   1b2c4:      	cmp	x0, #0x0
   1b2c8:      	b.ne	0xe7f70 <_mech_canonical_program_entry_v1+0xe7f70>
   1b2cc:      	mov	x0, #0x3                ; =3
   1b2d0:      	mov	w16, #0x3698            ; =13976
   1b2d4:      	movk	w16, #0x1, lsl #16
   1b2d8:      	str	x0, [sp, x16, sxtx]
   1b2dc:      	mov	w16, #0xa2a8            ; =41640
   1b2e0:      	movk	w16, #0x1, lsl #16
   1b2e4:      	ldr	x0, [sp, x16, sxtx]
   1b2e8:      	cmp	x0, #0x2
   1b2ec:      	b.lo	0xe7f74 <_mech_canonical_program_entry_v1+0xe7f74>
   1b2f0:      	mov	x5, #0x0                ; =0
   1b2f4:      	mov	w16, #0xa2b0            ; =41648
   1b2f8:      	movk	w16, #0x1, lsl #16
   1b2fc:      	ldr	x12, [sp, x16, sxtx]
   1b300:      	str	x5, [x12]
   1b304:      	ldr	x0, [x19, #0x1b00]
   1b308:      	str	x0, [x12, #0x8]
   1b30c:      	mov	x0, #0x2                ; =2
   1b310:      	mov	x1, x21
   1b314:      	mov	w16, #0xa2c0            ; =41664
   1b318:      	movk	w16, #0x1, lsl #16
   1b31c:      	ldr	x12, [sp, x16, sxtx]
   1b320:      	mov	w16, #0x3698            ; =13976
   1b324:      	movk	w16, #0x1, lsl #16
   1b328:      	str	x0, [sp, x16, sxtx]
   1b32c:      	mov	w16, #0xa2d0            ; =41680
   1b330:      	movk	w16, #0x1, lsl #16
   1b334:      	ldr	x0, [sp, x16, sxtx]
   1b338:      	mov	w16, #0xa2b0            ; =41648
   1b33c:      	movk	w16, #0x1, lsl #16
   1b340:      	ldr	x3, [sp, x16, sxtx]
   1b344:      	mov	w16, #0x3698            ; =13976
   1b348:      	movk	w16, #0x1, lsl #16
   1b34c:      	ldr	x4, [sp, x16, sxtx]
   1b350:      	mov	w16, #0xa2b8            ; =41656
   1b354:      	movk	w16, #0x1, lsl #16
   1b358:      	ldr	x6, [sp, x16, sxtx]
   1b35c:      	mov	x2, x5
   1b360:      	blr	x12
   1b364:      	cmp	x0, #0x0
   1b368:      	b.ne	0xe7fa8 <_mech_canonical_program_entry_v1+0xe7fa8>
   1b36c:      	mov	w16, #0xa2b8            ; =41656
   1b370:      	movk	w16, #0x1, lsl #16
   1b374:      	ldr	x6, [sp, x16, sxtx]
   1b378:      	ldr	x0, [x6]

