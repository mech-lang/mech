# Short-lived locals-pointer placement: R62 experiment

Baseline revalidated at clean `25018ce73654ea4fed40173bededdace9e3a3794`. Parent implemented the bounded locals-only experiment as `282aad366`. This agent reviewed the source change and prepared static audits; it did not build or run the compressor.

The R61 Object still contains139,076 static reloads of the original locals pointer from offset0x19bd0. Each high-offset reload normally needs a constant-low instruction, constant-high instruction and indexed stack load. These are encoded instructions, not executed visits. The previous arithmetic simplification perturbed this global allocation considerably; the exact allocator event is still unproven.

## Implemented experiment and correctness review

`codegen/control/mod.rs` saves the original, entry-checked locals pointer into an eight-byte explicit stack slot for managed programs. Every reachable source block loads that immutable snapshot and passes the short-lived value to the existing emitters. Scalar plans take the existing path. No new source construct, compiler proof, serialized authority, callback protocol or runtime permission is introduced.

The store follows the existing pointer guards and precedes the ordinary/resume phase branch. Therefore it dominates every source-block reload, including resumed invocation paths. This is invocation-local automatic storage, never passed to a callback. Nested calls receive their own machine frame. The original pointer remains the one used even if a callback modifies a visible frame header; re-reading `Frame.locals` would have required a stronger immutability premise and was deliberately avoided.

Prologue initialization, prefix resume and cold `tail::abort` retain their original pointer SSA. Thus a global pointer live range may still exist, but hot source blocks no longer all demand that same SSA value. The code does not promise that every new short value remains in a register. Existing exceptions, error precedence, admission, publication and cleanup logic are unchanged. The extra source-block load occurs before the existing emitted-visit count marker; qualification must retain the original work envelopes and confirm the existing conservative margin covers this instruction, rather than increasing work allowances.

Pinned Cranelift0.131.3 source supports the intended mechanism:

- `machinst/abi.rs:1233–1258` places explicit stack slots in the low fixed-slot area, and `spillslot_offset` adds fixed-slot size before register-allocation spill slots. The actual Object must verify the final offset.
- `legalizer/mod.rs:371–396` expands stack loads into ordinary notrap loads, without readonly/can_move. `inst_predicates.rs:46–68` requires all three flags before treating a load as movable egraph-pure.
- `alias_analysis.rs:94–126,270–365` can fold a load when the same address and last-store memory version are known. Stores in the ordinary region and calls/fences invalidate that version. Therefore immediate reloads can legitimately coalesce, but loads do not become globally invariant across ordinary memory effects merely because the slot is private.

Those source facts establish legality and a plausible shorter-live-range mechanism, not an expected speedup. Actual post-optimization CLIF, machine code, instructions and elapsed pairs decide the result. If few homes survive or short values still spill heavily, the next experiment is near-use reload placement within a source action, especially before ordinary scalar loads/stores. That would be measured separately, not added to the first candidate blindly.

## Prepared static audit

`audit-pointer-homes.py` compares the R61 and R62 Objects, streams static scalar stack-access counts, tracks entry pointer provenance to all early stack homes, and saves the exact supporting prologue plus source796 helper-site windows. It explicitly distinguishes the low snapshot home from any surviving high original-pointer spill. This matters because the old native-frame home atSP0 can move when a fixed slot is added; previous hardcoded role offsets must not be reused.

Run only after parent confirms measurement isolation:

```
python3 /private/tmp/mech-astra-audit-20261031/audit-pointer-homes.py \
  --before /private/tmp/mech-first-change-spill-round61-20261031/linked-primary/after/object.o \
  --after /private/tmp/mech-pointer-locality-round62-20261031/linked-primary/after/object.o \
  --out /private/tmp/mech-pointer-locality-round62-20261031/binary-audit/pointer-homes
```

The existing `compare-native-objects.py` supplies full opcode, generated text, stack descriptor and source797 evidence. Read the prologue manually before accepting inferred role counts. The bounded provenance pass intentionally does not claim to attribute additional short-lived copies spilled after the first callback.

## Filtered allocator diagnosis, if still needed

Full logging for a40,000-block generated function is unnecessary. Diagnostic-only CLIF ValueLabels on the original locals and argument pointers provide a maintained mapping through optimization and lowering. Call `func.dfg.collect_debug_info()` and `FunctionBuilder::set_val_label` for exactly those two values. Cranelift `machinst/lower.rs:913–950` follows value aliases, and `vcode.rs:490–509` resolves VReg aliases. `Function::debug_value_labels()` then provides the exact final VRegs at the regalloc interface.

A diagnostic regalloc hook can inspect only bundles containing those VRegs at `ion/process.rs:410–440` and report spill-set ID, current split count, requested split point, conflict reason and whether `split_into_minimal_bundles` is chosen. Emit bounded first-event records and aggregate counts; do not dump every live range or every function instruction. Preserve target identity across bundle/spill-set merges by checking the actual ranges' VReg identities, not just remembering one initial bundle number. Record final physical allocations and stack ranges through `Output.debug_locations`, which the existing `ion/moves.rs:579–621` constructs after allocation.

Regalloc2 is no_std, so an environment-variable lookup should not be added inside the allocator. Pass selection from existing labels or a diagnostic option, and use a bounded existing log target/counter sink. Enabling ordinary trace-log globally would recreate the unnecessary huge trace. Verify diagnostic `.text` byte identity before using its events to explain production allocation. The two-split threshold remains a hypothesis until the selected spill sets' events establish it.

Dependencies must be rebuilt consistently if this diagnostic changes their Rust API or implementations. Directly substituting a hand-built rlib into an old dependent graph risks Rust metadata/hash mismatch; a narrowly scoped Cargo rebuild reuses all unaffected artifacts and is safer than claiming a source change can be injected into the existing executable without rebuilding dependents. No dependency patch or build was performed here.
