       0:      	pacibsp
       4:      	stp	x29, x30, [sp, #-0x10]!
       8:      	mov	x29, sp
       c:      	stp	x27, x28, [sp, #-0x10]!
      10:      	stp	x25, x26, [sp, #-0x10]!
      14:      	stp	x23, x24, [sp, #-0x10]!
      18:      	stp	x21, x22, [sp, #-0x10]!
      1c:      	stp	x19, x20, [sp, #-0x10]!
      20:      	mov	w16, #0x9bf0            ; =39920
      24:      	movk	w16, #0x1, lsl #16
      28:      	sub	sp, sp, x16
      2c:      	stur	x0, [sp]
      30:      	mov	x15, #0x3               ; =3
      34:      	cmp	x0, #0x0
      38:      	b.eq	0xc075c <_mech_canonical_program_entry_v1+0xc075c>
      3c:      	mov	x0, #-0x1               ; =-1
      40:      	ldur	x1, [sp]
      44:      	str	x0, [x1, #0x48]
      48:      	ldur	x0, [sp]
      4c:      	ldr	x1, [x0]
      50:      	mov	x15, #0x3               ; =3
      54:      	cmp	x1, #0x25
      58:      	b.ne	0xc0760 <_mech_canonical_program_entry_v1+0xc0760>
      5c:      	ldur	x0, [sp]
      60:      	ldr	x1, [x0, #0x8]
      64:      	mov	x15, #0x3               ; =3
      68:      	cmp	x1, #0x2
      6c:      	b.ne	0xc0764 <_mech_canonical_program_entry_v1+0xc0764>
      70:      	ldur	x0, [sp]
      74:      	ldr	x1, [x0, #0x10]
      78:      	mov	x15, #0x3               ; =3
      7c:      	mov	x0, #0x5e0c             ; =24076
      80:      	cmp	x1, x0
      84:      	b.ne	0xc0768 <_mech_canonical_program_entry_v1+0xc0768>
      88:      	ldur	x0, [sp]
      8c:      	ldr	x1, [x0, #0x18]
      90:      	mov	x15, #0x3               ; =3
      94:      	cmp	x1, #0x1
      98:      	b.ne	0xc076c <_mech_canonical_program_entry_v1+0xc076c>
      9c:      	ldur	x0, [sp]
      a0:      	ldr	x5, [x0, #0x20]
      a4:      	ldr	x1, [x0, #0x28]
      a8:      	ldr	x4, [x0, #0x30]
      ac:      	ldr	x3, [x0, #0x38]
      b0:      	ldr	x2, [x0, #0x40]
      b4:      	mov	x15, #0x3               ; =3
      b8:      	cmp	x5, #0x0
      bc:      	b.eq	0xc0770 <_mech_canonical_program_entry_v1+0xc0770>
      c0:      	mov	x15, #0x3               ; =3
      c4:      	cmp	x1, #0x0
      c8:      	b.eq	0xc0774 <_mech_canonical_program_entry_v1+0xc0774>
      cc:      	mov	x15, #0x3               ; =3
      d0:      	cmp	x4, #0x0
      d4:      	b.eq	0xc0778 <_mech_canonical_program_entry_v1+0xc0778>
      d8:      	mov	x15, #0x3               ; =3
      dc:      	cmp	x3, #0x0
      e0:      	mov	w16, #0x9bc8            ; =39880
      e4:      	movk	w16, #0x1, lsl #16
      e8:      	str	x3, [sp, x16, sxtx]
      ec:      	b.eq	0xc077c <_mech_canonical_program_entry_v1+0xc077c>
      f0:      	mov	x15, #0x3               ; =3
      f4:      	cmp	x2, #0x0
      f8:      	mov	w16, #0x9bc0            ; =39872
      fc:      	movk	w16, #0x1, lsl #16
     100:      	str	x2, [sp, x16, sxtx]
     104:      	b.eq	0xc0780 <_mech_canonical_program_entry_v1+0xc0780>
     108:      	ldur	x0, [sp]
     10c:      	ldr	x3, [x0, #0x50]
     110:      	ldr	x6, [x0, #0x58]
     114:      	ldr	x2, [x0, #0x60]
     118:      	ldr	x0, [x0, #0x68]
     11c:      	mov	w16, #0x9ba0            ; =39840
     120:      	movk	w16, #0x1, lsl #16
     124:      	str	x0, [sp, x16, sxtx]
     128:      	mov	x15, #0x3               ; =3
     12c:      	cmp	x3, #0x0
     130:      	mov	w16, #0x9bb8            ; =39864
     134:      	movk	w16, #0x1, lsl #16
     138:      	str	x3, [sp, x16, sxtx]
     13c:      	b.eq	0xc0784 <_mech_canonical_program_entry_v1+0xc0784>
     140:      	mov	x15, #0x3               ; =3
     144:      	cmp	x6, #0x0
     148:      	mov	w16, #0x9bb0            ; =39856
     14c:      	movk	w16, #0x1, lsl #16
     150:      	str	x6, [sp, x16, sxtx]
     154:      	b.eq	0xc0788 <_mech_canonical_program_entry_v1+0xc0788>
     158:      	mov	x15, #0x3               ; =3
     15c:      	cmp	x2, #0x0
     160:      	mov	w16, #0x9ba8            ; =39848
     164:      	movk	w16, #0x1, lsl #16
     168:      	str	x2, [sp, x16, sxtx]
     16c:      	b.eq	0xc078c <_mech_canonical_program_entry_v1+0xc078c>
     170:      	ldur	x0, [sp]
     174:      	ldr	x4, [x0, #0x70]
     178:      	mov	x15, #0x3               ; =3
     17c:      	cmp	x4, #0x1
     180:      	b.hi	0xc0790 <_mech_canonical_program_entry_v1+0xc0790>
     184:      	cmp	x4, #0x0
     188:      	stur	x4, [sp, #0xf0]
     18c:      	b.ne	0xe10 <_mech_canonical_program_entry_v1+0xe10>
     190:      	mov	x11, #0x0               ; =0
     194:      	str	x11, [x1, #0x28]
     198:      	str	x11, [x1, #0x40]
     19c:      	stur	x11, [sp, #0xe8]
     1a0:      	mov	x6, #0x1                ; =1
     1a4:      	str	x6, [x1, #0x48]
     1a8:      	stur	x6, [sp, #0xe0]
     1ac:      	mov	x23, #0x101             ; =257
     1b0:      	str	x23, [x1, #0x50]
     1b4:      	mov	x24, #0x201             ; =513
     1b8:      	str	x24, [x1, #0x58]
     1bc:      	mov	x0, #0x301              ; =769
     1c0:      	str	x0, [x1, #0x60]
     1c4:      	mov	x0, #0x401              ; =1025
     1c8:      	str	x0, [x1, #0x68]
     1cc:      	mov	x0, #0x601              ; =1537
     1d0:      	str	x0, [x1, #0x70]
     1d4:      	mov	x0, #0x801              ; =2049
     1d8:      	str	x0, [x1, #0x78]
     1dc:      	mov	x0, #0xc01              ; =3073
     1e0:      	str	x0, [x1, #0x80]
     1e4:      	mov	x0, #0x1001             ; =4097
     1e8:      	str	x0, [x1, #0x88]
     1ec:      	mov	x0, #0x1801             ; =6145
     1f0:      	str	x0, [x1, #0x90]
     1f4:      	mov	x0, #0x2001             ; =8193
     1f8:      	str	x0, [x1, #0x98]
     1fc:      	mov	x0, #0x3001             ; =12289
     200:      	str	x0, [x1, #0xa0]
     204:      	mov	x0, #0x4001             ; =16385
     208:      	str	x0, [x1, #0xa8]
     20c:      	mov	x0, #0x6001             ; =24577
     210:      	str	x0, [x1, #0xb0]
     214:      	mov	x28, #0x2               ; =2
     218:      	str	x28, [x1, #0xb8]
     21c:      	mov	x2, #0x102              ; =258
     220:      	str	x2, [x1, #0xc0]
     224:      	mov	x4, #0x3                ; =3
     228:      	str	x4, [x1, #0xc8]
     22c:      	stur	x4, [sp, #0xd8]
     230:      	mov	x13, #0x4               ; =4
     234:      	str	x13, [x1, #0xd0]
     238:      	mov	x0, #0x5                ; =5
     23c:      	str	x0, [x1, #0xd8]
     240:      	mov	x10, #0x6               ; =6
     244:      	str	x10, [x1, #0xe0]
     248:      	mov	x9, #0x7                ; =7
     24c:      	str	x9, [x1, #0xe8]
     250:      	mov	x8, #0x8                ; =8
     254:      	str	x8, [x1, #0xf0]
     258:      	mov	x14, #0x9               ; =9
     25c:      	str	x14, [x1, #0xf8]
     260:      	mov	x11, #0xa               ; =10
     264:      	str	x11, [x1, #0x100]
     268:      	mov	x22, #0xb               ; =11
     26c:      	str	x22, [x1, #0x108]
     270:      	mov	x12, #0xd               ; =13
     274:      	str	x12, [x1, #0x110]
     278:      	mov	x15, #0xf               ; =15
     27c:      	str	x15, [x1, #0x118]
     280:      	mov	x20, #0x11              ; =17
     284:      	str	x20, [x1, #0x120]
     288:      	mov	x21, #0x13              ; =19
     28c:      	str	x21, [x1, #0x128]
     290:      	mov	x6, #0x17               ; =23
     294:      	str	x6, [x1, #0x130]
     298:      	mov	x3, #0x19               ; =25
     29c:      	str	x3, [x1, #0x138]
     2a0:      	stur	x3, [sp, #0xd0]
     2a4:      	mov	x7, #0x1b               ; =27
     2a8:      	str	x7, [x1, #0x140]
     2ac:      	stur	x7, [sp, #0xc8]
     2b0:      	mov	x4, #0x1f               ; =31
     2b4:      	str	x4, [x1, #0x148]
     2b8:      	mov	x19, #0x21              ; =33
     2bc:      	str	x19, [x1, #0x150]
     2c0:      	stur	x19, [sp, #0xc0]
     2c4:      	mov	x5, #0x23               ; =35
     2c8:      	str	x5, [x1, #0x158]
     2cc:      	stur	x5, [sp, #0xb8]
     2d0:      	mov	x3, #0x2b               ; =43
     2d4:      	str	x3, [x1, #0x160]
     2d8:      	stur	x3, [sp, #0xb0]
     2dc:      	mov	x27, #0x31              ; =49
     2e0:      	str	x27, [x1, #0x168]
     2e4:      	stur	x27, [sp, #0xa8]
     2e8:      	mov	x26, #0x33              ; =51
     2ec:      	str	x26, [x1, #0x170]
     2f0:      	stur	x26, [sp, #0xa0]
     2f4:      	mov	x5, #0x3b               ; =59
     2f8:      	str	x5, [x1, #0x178]
     2fc:      	stur	x5, [sp, #0x98]
     300:      	mov	x3, #0x41               ; =65
     304:      	str	x3, [x1, #0x180]
     308:      	stur	x3, [sp, #0x90]
     30c:      	mov	x3, #0x43               ; =67
     310:      	str	x3, [x1, #0x188]
     314:      	stur	x3, [sp, #0x88]
     318:      	mov	x5, #0x53               ; =83
     31c:      	str	x5, [x1, #0x190]
     320:      	stur	x5, [sp, #0x80]
     324:      	mov	x3, #0x61               ; =97
     328:      	str	x3, [x1, #0x198]
     32c:      	stur	x3, [sp, #0x78]
     330:      	mov	x3, #0x63               ; =99
     334:      	str	x3, [x1, #0x1a0]
     338:      	stur	x3, [sp, #0x70]
     33c:      	mov	x3, #0x73               ; =115
     340:      	str	x3, [x1, #0x1a8]
     344:      	stur	x3, [sp, #0x68]
     348:      	mov	x7, #0x81               ; =129
     34c:      	str	x7, [x1, #0x1b0]
     350:      	stur	x7, [sp, #0x60]
     354:      	mov	x3, #0x181              ; =385
     358:      	str	x3, [x1, #0x1b8]
     35c:      	mov	x5, #0x83               ; =131
     360:      	str	x5, [x1, #0x1c0]
     364:      	stur	x5, [sp, #0x58]
     368:      	mov	x3, #0xa3               ; =163
     36c:      	str	x3, [x1, #0x1c8]
     370:      	stur	x3, [sp, #0x50]
     374:      	mov	x5, #0xc1               ; =193
     378:      	str	x5, [x1, #0x1d0]
     37c:      	stur	x5, [sp, #0x48]
     380:      	mov	x5, #0xc3               ; =195
     384:      	str	x5, [x1, #0x1d8]
     388:      	stur	x5, [sp, #0x40]
     38c:      	mov	x5, #0xe3               ; =227
     390:      	mov	x3, x5
     394:      	str	x3, [x1, #0x1e0]
     398:      	stur	x3, [sp, #0x38]
     39c:      	ldur	x3, [sp, #0xe8]
     3a0:      	str	x3, [x1, #0x1e8]
     3a4:      	ldur	x3, [sp, #0xe0]
     3a8:      	str	x3, [x1, #0x1f0]
     3ac:      	mov	x7, #-0x7fffffffffffffff ; =-9223372036854775807
     3b0:      	str	x7, [x1, #0x1f8]
     3b4:      	str	x13, [x1, #0x200]
     3b8:      	ldur	x3, [sp, #0xe8]
     3bc:      	str	x3, [x1, #0x218]
     3c0:      	mov	x3, #0x80000000         ; =2147483648
     3c4:      	str	x3, [x1, #0x220]
     3c8:      	mov	x3, #0x10000            ; =65536
     3cc:      	str	x3, [x1, #0x228]
     3d0:      	mov	x3, #0x20000            ; =131072
     3d4:      	str	x3, [x1, #0x230]
     3d8:      	mov	x3, #0x40000            ; =262144
     3dc:      	str	x3, [x1, #0x238]
     3e0:      	mov	x3, #0xffff0000         ; =4294901760
     3e4:      	str	x3, [x1, #0x240]
     3e8:      	mov	x3, #0x100              ; =256
     3ec:      	str	x3, [x1, #0x248]
     3f0:      	mov	x3, #0x200              ; =512
     3f4:      	str	x3, [x1, #0x250]
     3f8:      	mov	x3, #0x1000             ; =4096
     3fc:      	str	x3, [x1, #0x258]
     400:      	mov	x3, #0x2000             ; =8192
     404:      	str	x3, [x1, #0x260]
     408:      	mov	x3, #0x8000             ; =32768
     40c:      	str	x3, [x1, #0x268]
     410:      	mov	x3, #0xfffffc00         ; =4294966272
     414:      	str	x3, [x1, #0x270]
     418:      	ldur	x3, [sp, #0xe0]
     41c:      	str	x3, [x1, #0x278]
     420:      	str	x23, [x1, #0x280]
     424:      	str	x24, [x1, #0x288]
     428:      	str	x28, [x1, #0x290]
     42c:      	str	x2, [x1, #0x298]
     430:      	ldur	x2, [sp, #0xd8]
     434:      	str	x2, [x1, #0x2a0]
     438:      	mov	x2, #0x103              ; =259
     43c:      	str	x2, [x1, #0x2a8]
     440:      	str	x13, [x1, #0x2b0]
     444:      	str	x0, [x1, #0x2b8]
     448:      	str	x10, [x1, #0x2c0]
     44c:      	str	x9, [x1, #0x2c8]
     450:      	str	x8, [x1, #0x2d0]
     454:      	str	x14, [x1, #0x2d8]
     458:      	str	x11, [x1, #0x2e0]
     45c:      	str	x22, [x1, #0x2e8]
     460:      	str	x12, [x1, #0x2f0]
     464:      	mov	x19, #0xe               ; =14
     468:      	str	x19, [x1, #0x2f8]
     46c:      	mov	x2, #0x10e              ; =270
     470:      	str	x2, [x1, #0x300]
     474:      	str	x15, [x1, #0x308]
     478:      	mov	x23, #0x10              ; =16
     47c:      	str	x23, [x1, #0x310]
     480:      	mov	x2, #0x2710             ; =10000
     484:      	str	x2, [x1, #0x318]
     488:      	str	x20, [x1, #0x320]
     48c:      	mov	x24, #0x12              ; =18
     490:      	str	x24, [x1, #0x328]
     494:      	str	x21, [x1, #0x330]
     498:      	str	x6, [x1, #0x338]
     49c:      	mov	x5, #0x18               ; =24
     4a0:      	str	x5, [x1, #0x340]
     4a4:      	mov	x2, #0x118              ; =280
     4a8:      	str	x2, [x1, #0x348]
     4ac:      	mov	x27, #0x1d              ; =29
     4b0:      	str	x27, [x1, #0x350]
     4b4:      	mov	x2, #0x1e               ; =30
     4b8:      	str	x2, [x1, #0x358]
     4bc:      	mov	x3, #0x11e              ; =286
     4c0:      	str	x3, [x1, #0x360]
     4c4:      	str	x4, [x1, #0x368]
     4c8:      	mov	x7, #0x20               ; =32
     4cc:      	str	x7, [x1, #0x370]
     4d0:      	mov	x3, #0x120              ; =288
     4d4:      	str	x3, [x1, #0x378]
     4d8:      	mov	x3, #0x320              ; =800
     4dc:      	str	x3, [x1, #0x380]
     4e0:      	mov	x26, #0x28              ; =40
     4e4:      	str	x26, [x1, #0x388]
     4e8:      	mov	x3, #0x12c              ; =300
     4ec:      	str	x3, [x1, #0x390]
     4f0:      	mov	x25, #0x30              ; =48
     4f4:      	str	x25, [x1, #0x398]
     4f8:      	mov	x3, #0x140              ; =320
     4fc:      	str	x3, [x1, #0x3a0]
     500:      	mov	x3, #0x340              ; =832
     504:      	str	x3, [x1, #0x3a8]
     508:      	mov	x3, #0x4e               ; =78
     50c:      	str	x3, [x1, #0x3b0]
     510:      	stur	x3, [sp, #0x30]
     514:      	mov	x3, #0x50               ; =80
     518:      	str	x3, [x1, #0x3b8]
     51c:      	stur	x3, [sp, #0x28]
     520:      	mov	w3, #0xe360             ; =58208
     524:      	movk	w3, #0x16, lsl #16
     528:      	str	x3, [x1, #0x3c0]
     52c:      	mov	w3, #0xe561             ; =58721
     530:      	movk	w3, #0x16, lsl #16
     534:      	str	x3, [x1, #0x3c8]
     538:      	mov	w3, #0xa768             ; =42856
     53c:      	movk	w3, #0x4, lsl #16
     540:      	str	x3, [x1, #0x3d0]
     544:      	mov	w3, #0xa869             ; =43113
     548:      	movk	w3, #0x4, lsl #16
     54c:      	str	x3, [x1, #0x3d8]
     550:      	mov	x3, #0x7f               ; =127
     554:      	str	x3, [x1, #0x3e0]
     558:      	stur	x3, [sp, #0x20]
     55c:      	mov	x3, #0x1387             ; =4999
     560:      	str	x3, [x1, #0x3e8]
     564:      	mov	x3, #0x1388             ; =5000
     568:      	str	x3, [x1, #0x3f0]
     56c:      	mov	x3, #0x90               ; =144
     570:      	str	x3, [x1, #0x3f8]
     574:      	stur	x3, [sp, #0x18]
     578:      	mov	x3, #0x190              ; =400
     57c:      	str	x3, [x1, #0x400]
     580:      	mov	w3, #0xa7bd             ; =42941
     584:      	movk	w3, #0x1e35, lsl #16
     588:      	str	x3, [x1, #0x408]
     58c:      	mov	x3, #0xc0               ; =192
     590:      	str	x3, [x1, #0x410]
     594:      	stur	x3, [sp, #0x10]
     598:      	mov	x3, #0xc8               ; =200
     59c:      	str	x3, [x1, #0x418]
     5a0:      	stur	x3, [sp, #0x8]
     5a4:      	mov	w3, #0x93e0             ; =37856
     5a8:      	movk	w3, #0x4, lsl #16
     5ac:      	str	x3, [x1, #0x420]
     5b0:      	mov	x3, #0xfffe             ; =65534
     5b4:      	str	x3, [x1, #0x428]
     5b8:      	mov	x3, #0xff               ; =255
     5bc:      	str	x3, [x1, #0x430]
     5c0:      	mov	w16, #0x9b98            ; =39832
     5c4:      	movk	w16, #0x1, lsl #16
     5c8:      	str	x3, [sp, x16, sxtx]
     5cc:      	mov	x3, #0x1ff              ; =511
     5d0:      	str	x3, [x1, #0x438]
     5d4:      	mov	x3, #0x3ff              ; =1023
     5d8:      	str	x3, [x1, #0x440]
     5dc:      	mov	x3, #0x7fff             ; =32767
     5e0:      	str	x3, [x1, #0x448]
     5e4:      	mov	x3, #0xffff             ; =65535
     5e8:      	str	x3, [x1, #0x450]
     5ec:      	mov	x3, #0x7fffff           ; =8388607
     5f0:      	str	x3, [x1, #0x458]
     5f4:      	mov	x3, #0xffffff           ; =16777215
     5f8:      	str	x3, [x1, #0x460]
     5fc:      	mov	x3, #0xffffffff         ; =4294967295
     600:      	str	x3, [x1, #0x468]
     604:      	mov	x3, #0x7fffffffffffffff ; =9223372036854775807
     608:      	str	x3, [x1, #0x470]
     60c:      	mov	x3, #-0x1               ; =-1
     610:      	str	x3, [x1, #0x478]
     614:      	ldur	x3, [sp, #0xe8]
     618:      	str	x3, [x1, #0x488]
     61c:      	ldur	x3, [sp, #0xe0]
     620:      	str	x3, [x1, #0x490]
     624:      	str	x28, [x1, #0x498]
     628:      	ldur	x3, [sp, #0xd8]
     62c:      	str	x3, [x1, #0x4a0]
     630:      	str	x13, [x1, #0x4a8]
     634:      	str	x0, [x1, #0x4b0]
     638:      	str	x10, [x1, #0x4b8]
     63c:      	str	x9, [x1, #0x4c0]
     640:      	str	x8, [x1, #0x4c8]
     644:      	str	x14, [x1, #0x4d0]
     648:      	str	x11, [x1, #0x4d8]
     64c:      	str	x22, [x1, #0x4e0]
     650:      	mov	x0, #0xc                ; =12
     654:      	str	x0, [x1, #0x4e8]
     658:      	str	x12, [x1, #0x4f0]
     65c:      	str	x19, [x1, #0x4f8]
     660:      	str	x15, [x1, #0x500]
     664:      	str	x23, [x1, #0x508]
     668:      	str	x20, [x1, #0x510]
     66c:      	str	x24, [x1, #0x518]
     670:      	str	x21, [x1, #0x520]
     674:      	mov	x0, #0x14               ; =20
     678:      	str	x0, [x1, #0x528]
     67c:      	mov	x0, #0x15               ; =21
     680:      	str	x0, [x1, #0x530]
     684:      	mov	x0, #0x16               ; =22
     688:      	str	x0, [x1, #0x538]
     68c:      	str	x6, [x1, #0x540]
     690:      	str	x5, [x1, #0x548]
     694:      	ldur	x3, [sp, #0xd0]
     698:      	str	x3, [x1, #0x550]
     69c:      	mov	x0, #0x1a               ; =26
     6a0:      	str	x0, [x1, #0x558]
     6a4:      	ldur	x6, [sp, #0xc8]
     6a8:      	str	x6, [x1, #0x560]
     6ac:      	mov	x0, #0x1c               ; =28
     6b0:      	str	x0, [x1, #0x568]
     6b4:      	str	x27, [x1, #0x570]
     6b8:      	str	x2, [x1, #0x578]
     6bc:      	str	x4, [x1, #0x580]
     6c0:      	str	x7, [x1, #0x588]
     6c4:      	ldur	x19, [sp, #0xc0]
     6c8:      	str	x19, [x1, #0x590]
     6cc:      	mov	x0, #0x22               ; =34
     6d0:      	str	x0, [x1, #0x598]
     6d4:      	ldur	x5, [sp, #0xb8]
     6d8:      	str	x5, [x1, #0x5a0]
     6dc:      	mov	x0, #0x24               ; =36
     6e0:      	str	x0, [x1, #0x5a8]
     6e4:      	mov	x0, #0x25               ; =37
     6e8:      	str	x0, [x1, #0x5b0]
     6ec:      	mov	x0, #0x26               ; =38
     6f0:      	str	x0, [x1, #0x5b8]
     6f4:      	mov	x0, #0x27               ; =39
     6f8:      	str	x0, [x1, #0x5c0]
     6fc:      	str	x26, [x1, #0x5c8]
     700:      	mov	x2, #0x29               ; =41
     704:      	str	x2, [x1, #0x5d0]
     708:      	mov	x2, #0x2a               ; =42
     70c:      	str	x2, [x1, #0x5d8]
     710:      	ldur	x2, [sp, #0xb0]
     714:      	str	x2, [x1, #0x5e0]
     718:      	mov	x4, #0x2c               ; =44
     71c:      	str	x4, [x1, #0x5e8]
     720:      	mov	x5, #0x2d               ; =45
     724:      	str	x5, [x1, #0x5f0]
     728:      	mov	x6, #0x2e               ; =46
     72c:      	str	x6, [x1, #0x5f8]
     730:      	mov	x7, #0x2f               ; =47
     734:      	str	x7, [x1, #0x600]
     738:      	str	x25, [x1, #0x608]
     73c:      	ldur	x27, [sp, #0xa8]
     740:      	str	x27, [x1, #0x610]
     744:      	mov	x10, #0x32              ; =50
     748:      	str	x10, [x1, #0x618]
     74c:      	ldur	x26, [sp, #0xa0]
     750:      	str	x26, [x1, #0x620]
     754:      	mov	x12, #0x34              ; =52
     758:      	str	x12, [x1, #0x628]
     75c:      	mov	x13, #0x35              ; =53
     760:      	str	x13, [x1, #0x630]
     764:      	mov	x14, #0x36              ; =54
     768:      	str	x14, [x1, #0x638]
     76c:      	mov	x15, #0x37              ; =55
     770:      	str	x15, [x1, #0x640]
     774:      	mov	x0, #0x38               ; =56
     778:      	str	x0, [x1, #0x648]
     77c:      	mov	x0, #0x39               ; =57
     780:      	str	x0, [x1, #0x650]
     784:      	mov	x0, #0x3a               ; =58
     788:      	str	x0, [x1, #0x658]
     78c:      	ldur	x24, [sp, #0x98]
     790:      	str	x24, [x1, #0x660]
     794:      	mov	x0, #0x3c               ; =60
     798:      	str	x0, [x1, #0x668]
     79c:      	mov	x0, #0x3d               ; =61
     7a0:      	str	x0, [x1, #0x670]
     7a4:      	mov	x0, #0x3e               ; =62
     7a8:      	str	x0, [x1, #0x678]
     7ac:      	mov	x0, #0x3f               ; =63
     7b0:      	str	x0, [x1, #0x680]
     7b4:      	mov	x0, #0x40               ; =64
     7b8:      	str	x0, [x1, #0x688]
     7bc:      	ldur	x23, [sp, #0x90]
     7c0:      	str	x23, [x1, #0x690]
     7c4:      	mov	x0, #0x42               ; =66
     7c8:      	str	x0, [x1, #0x698]
     7cc:      	ldur	x22, [sp, #0x88]
     7d0:      	str	x22, [x1, #0x6a0]
     7d4:      	mov	x0, #0x44               ; =68
     7d8:      	str	x0, [x1, #0x6a8]
     7dc:      	mov	x0, #0x45               ; =69
     7e0:      	str	x0, [x1, #0x6b0]
     7e4:      	mov	x0, #0x46               ; =70
     7e8:      	str	x0, [x1, #0x6b8]
     7ec:      	mov	x0, #0x47               ; =71
     7f0:      	str	x0, [x1, #0x6c0]
     7f4:      	mov	x0, #0x48               ; =72
     7f8:      	str	x0, [x1, #0x6c8]
     7fc:      	mov	x0, #0x49               ; =73
     800:      	str	x0, [x1, #0x6d0]
     804:      	mov	x0, #0x4a               ; =74
     808:      	str	x0, [x1, #0x6d8]
     80c:      	mov	x0, #0x4b               ; =75
     810:      	str	x0, [x1, #0x6e0]
     814:      	mov	x0, #0x4c               ; =76
     818:      	str	x0, [x1, #0x6e8]
     81c:      	mov	x0, #0x4d               ; =77
     820:      	str	x0, [x1, #0x6f0]
     824:      	ldur	x3, [sp, #0x30]
     828:      	str	x3, [x1, #0x6f8]
     82c:      	mov	x0, #0x4f               ; =79
     830:      	str	x0, [x1, #0x700]
     834:      	ldur	x24, [sp, #0x28]
     838:      	str	x24, [x1, #0x708]
     83c:      	mov	x0, #0x51               ; =81
     840:      	str	x0, [x1, #0x710]
     844:      	mov	x0, #0x52               ; =82
     848:      	str	x0, [x1, #0x718]
     84c:      	ldur	x20, [sp, #0x80]
     850:      	str	x20, [x1, #0x720]
     854:      	mov	x0, #0x54               ; =84
     858:      	str	x0, [x1, #0x728]
     85c:      	mov	x0, #0x55               ; =85
     860:      	str	x0, [x1, #0x730]
     864:      	mov	x0, #0x56               ; =86
     868:      	str	x0, [x1, #0x738]
     86c:      	mov	x0, #0x57               ; =87
     870:      	str	x0, [x1, #0x740]
     874:      	mov	x0, #0x58               ; =88
     878:      	str	x0, [x1, #0x748]
     87c:      	mov	x0, #0x59               ; =89
     880:      	str	x0, [x1, #0x750]
     884:      	mov	x0, #0x5a               ; =90
     888:      	str	x0, [x1, #0x758]
     88c:      	mov	x0, #0x5b               ; =91
     890:      	str	x0, [x1, #0x760]
     894:      	mov	x0, #0x5c               ; =92
     898:      	str	x0, [x1, #0x768]
     89c:      	mov	x0, #0x5d               ; =93
     8a0:      	str	x0, [x1, #0x770]
     8a4:      	mov	x0, #0x5e               ; =94
     8a8:      	str	x0, [x1, #0x778]
     8ac:      	mov	x0, #0x5f               ; =95
     8b0:      	str	x0, [x1, #0x780]
     8b4:      	mov	x0, #0x60               ; =96
     8b8:      	str	x0, [x1, #0x788]
     8bc:      	ldur	x15, [sp, #0x78]
     8c0:      	str	x15, [x1, #0x790]
     8c4:      	mov	x0, #0x62               ; =98
     8c8:      	str	x0, [x1, #0x798]
     8cc:      	ldur	x12, [sp, #0x70]
     8d0:      	str	x12, [x1, #0x7a0]
     8d4:      	mov	x0, #0x64               ; =100
     8d8:      	str	x0, [x1, #0x7a8]
     8dc:      	mov	x0, #0x65               ; =101
     8e0:      	str	x0, [x1, #0x7b0]
     8e4:      	mov	x0, #0x66               ; =102
     8e8:      	str	x0, [x1, #0x7b8]
     8ec:      	mov	x0, #0x67               ; =103
     8f0:      	str	x0, [x1, #0x7c0]
     8f4:      	mov	x2, #0x68               ; =104
     8f8:      	str	x2, [x1, #0x7c8]
     8fc:      	mov	x2, #0x69               ; =105
     900:      	str	x2, [x1, #0x7d0]
     904:      	mov	x3, #0x6a               ; =106
     908:      	str	x3, [x1, #0x7d8]
     90c:      	mov	x4, #0x6b               ; =107
     910:      	str	x4, [x1, #0x7e0]
     914:      	mov	x5, #0x6c               ; =108
     918:      	str	x5, [x1, #0x7e8]
     91c:      	mov	x6, #0x6d               ; =109
     920:      	str	x6, [x1, #0x7f0]
     924:      	mov	x7, #0x6e               ; =110
     928:      	str	x7, [x1, #0x7f8]
     92c:      	mov	x8, #0x6f               ; =111
     930:      	str	x8, [x1, #0x800]
     934:      	mov	x9, #0x70               ; =112
     938:      	str	x9, [x1, #0x808]
     93c:      	mov	x10, #0x71              ; =113
     940:      	str	x10, [x1, #0x810]
     944:      	mov	x11, #0x72              ; =114
     948:      	str	x11, [x1, #0x818]
     94c:      	ldur	x14, [sp, #0x68]
     950:      	str	x14, [x1, #0x820]
     954:      	mov	x13, #0x74              ; =116
     958:      	str	x13, [x1, #0x828]
     95c:      	mov	x14, #0x75              ; =117
     960:      	str	x14, [x1, #0x830]
     964:      	mov	x15, #0x76              ; =118
     968:      	str	x15, [x1, #0x838]
     96c:      	mov	x0, #0x77               ; =119
     970:      	str	x0, [x1, #0x840]
     974:      	mov	x0, #0x78               ; =120
     978:      	str	x0, [x1, #0x848]
     97c:      	mov	x0, #0x79               ; =121
     980:      	str	x0, [x1, #0x850]
     984:      	mov	x0, #0x7a               ; =122
     988:      	str	x0, [x1, #0x858]
     98c:      	mov	x0, #0x7b               ; =123
     990:      	str	x0, [x1, #0x860]
     994:      	mov	x0, #0x7c               ; =124
     998:      	str	x0, [x1, #0x868]
     99c:      	mov	x0, #0x7d               ; =125
     9a0:      	str	x0, [x1, #0x870]
     9a4:      	mov	x0, #0x7e               ; =126
     9a8:      	str	x0, [x1, #0x878]
     9ac:      	ldur	x25, [sp, #0x20]
     9b0:      	str	x25, [x1, #0x880]
     9b4:      	mov	x0, #0x80               ; =128
     9b8:      	str	x0, [x1, #0x888]
     9bc:      	ldur	x7, [sp, #0x60]
     9c0:      	str	x7, [x1, #0x890]
     9c4:      	mov	x0, #0x82               ; =130
     9c8:      	str	x0, [x1, #0x898]
     9cc:      	ldur	x10, [sp, #0x58]
     9d0:      	str	x10, [x1, #0x8a0]
     9d4:      	mov	x0, #0x84               ; =132
     9d8:      	str	x0, [x1, #0x8a8]
     9dc:      	mov	x0, #0x85               ; =133
     9e0:      	str	x0, [x1, #0x8b0]
     9e4:      	mov	x0, #0x86               ; =134
     9e8:      	str	x0, [x1, #0x8b8]
     9ec:      	mov	x0, #0x87               ; =135
     9f0:      	str	x0, [x1, #0x8c0]
     9f4:      	mov	x0, #0x88               ; =136
     9f8:      	str	x0, [x1, #0x8c8]
     9fc:      	mov	x0, #0x89               ; =137
     a00:      	str	x0, [x1, #0x8d0]
     a04:      	mov	x0, #0x8a               ; =138
     a08:      	str	x0, [x1, #0x8d8]
     a0c:      	mov	x0, #0x8b               ; =139
     a10:      	str	x0, [x1, #0x8e0]
     a14:      	mov	x0, #0x8c               ; =140
     a18:      	str	x0, [x1, #0x8e8]
     a1c:      	mov	x0, #0x8d               ; =141
     a20:      	str	x0, [x1, #0x8f0]
     a24:      	mov	x0, #0x8e               ; =142
     a28:      	str	x0, [x1, #0x8f8]
     a2c:      	mov	x0, #0x8f               ; =143
     a30:      	str	x0, [x1, #0x900]
     a34:      	ldur	x21, [sp, #0x18]
     a38:      	str	x21, [x1, #0x908]
     a3c:      	mov	x0, #0x91               ; =145
     a40:      	str	x0, [x1, #0x910]
     a44:      	mov	x0, #0x92               ; =146
     a48:      	str	x0, [x1, #0x918]
     a4c:      	mov	x0, #0x93               ; =147
     a50:      	str	x0, [x1, #0x920]
     a54:      	mov	x0, #0x94               ; =148
     a58:      	str	x0, [x1, #0x928]
     a5c:      	mov	x0, #0x95               ; =149
     a60:      	str	x0, [x1, #0x930]
     a64:      	mov	x0, #0x96               ; =150
     a68:      	str	x0, [x1, #0x938]
     a6c:      	mov	x0, #0x97               ; =151
     a70:      	str	x0, [x1, #0x940]
     a74:      	mov	x0, #0x98               ; =152
     a78:      	str	x0, [x1, #0x948]
     a7c:      	mov	x0, #0x99               ; =153
     a80:      	str	x0, [x1, #0x950]
     a84:      	mov	x0, #0x9a               ; =154
     a88:      	str	x0, [x1, #0x958]
     a8c:      	mov	x0, #0x9b               ; =155
     a90:      	str	x0, [x1, #0x960]
     a94:      	mov	x0, #0x9c               ; =156
     a98:      	str	x0, [x1, #0x968]
     a9c:      	mov	x0, #0x9d               ; =157
     aa0:      	str	x0, [x1, #0x970]
     aa4:      	mov	x0, #0x9e               ; =158
     aa8:      	str	x0, [x1, #0x978]
     aac:      	mov	x0, #0x9f               ; =159
     ab0:      	str	x0, [x1, #0x980]
     ab4:      	mov	x0, #0xa0               ; =160
     ab8:      	str	x0, [x1, #0x988]
     abc:      	mov	x0, #0xa1               ; =161
     ac0:      	str	x0, [x1, #0x990]
     ac4:      	mov	x0, #0xa2               ; =162
     ac8:      	str	x0, [x1, #0x998]
     acc:      	ldur	x0, [sp, #0x50]
     ad0:      	str	x0, [x1, #0x9a0]
     ad4:      	mov	x0, #0xa4               ; =164
     ad8:      	str	x0, [x1, #0x9a8]
     adc:      	mov	x0, #0xa5               ; =165
     ae0:      	str	x0, [x1, #0x9b0]
     ae4:      	mov	x0, #0xa6               ; =166
     ae8:      	str	x0, [x1, #0x9b8]
     aec:      	mov	x2, #0xa7               ; =167
     af0:      	str	x2, [x1, #0x9c0]
     af4:      	mov	x2, #0xa8               ; =168
     af8:      	str	x2, [x1, #0x9c8]
     afc:      	mov	x3, #0xa9               ; =169
     b00:      	str	x3, [x1, #0x9d0]
     b04:      	mov	x4, #0xaa               ; =170
     b08:      	str	x4, [x1, #0x9d8]
     b0c:      	mov	x5, #0xab               ; =171
     b10:      	str	x5, [x1, #0x9e0]
     b14:      	mov	x6, #0xac               ; =172
     b18:      	str	x6, [x1, #0x9e8]
     b1c:      	mov	x7, #0xad               ; =173
     b20:      	str	x7, [x1, #0x9f0]
     b24:      	mov	x8, #0xae               ; =174
     b28:      	str	x8, [x1, #0x9f8]
     b2c:      	mov	x9, #0xaf               ; =175
     b30:      	str	x9, [x1, #0xa00]
     b34:      	mov	x10, #0xb0              ; =176
     b38:      	str	x10, [x1, #0xa08]
     b3c:      	mov	x11, #0xb1              ; =177
     b40:      	str	x11, [x1, #0xa10]
     b44:      	mov	x12, #0xb2              ; =178
     b48:      	str	x12, [x1, #0xa18]
     b4c:      	mov	x13, #0xb3              ; =179
     b50:      	str	x13, [x1, #0xa20]
     b54:      	mov	x14, #0xb4              ; =180
     b58:      	str	x14, [x1, #0xa28]
     b5c:      	mov	x15, #0xb5              ; =181
     b60:      	str	x15, [x1, #0xa30]
     b64:      	mov	x0, #0xb6               ; =182
     b68:      	str	x0, [x1, #0xa38]
     b6c:      	mov	x0, #0xb7               ; =183
     b70:      	str	x0, [x1, #0xa40]
     b74:      	mov	x0, #0xb8               ; =184
     b78:      	str	x0, [x1, #0xa48]
     b7c:      	mov	x0, #0xb9               ; =185
     b80:      	str	x0, [x1, #0xa50]
     b84:      	mov	x0, #0xba               ; =186
     b88:      	str	x0, [x1, #0xa58]
     b8c:      	mov	x0, #0xbb               ; =187
     b90:      	str	x0, [x1, #0xa60]
     b94:      	mov	x0, #0xbc               ; =188
     b98:      	str	x0, [x1, #0xa68]
     b9c:      	mov	x0, #0xbd               ; =189
     ba0:      	str	x0, [x1, #0xa70]
     ba4:      	mov	x0, #0xbe               ; =190
     ba8:      	str	x0, [x1, #0xa78]
     bac:      	mov	x0, #0xbf               ; =191
     bb0:      	str	x0, [x1, #0xa80]
     bb4:      	ldur	x8, [sp, #0x10]
     bb8:      	str	x8, [x1, #0xa88]
     bbc:      	ldur	x3, [sp, #0x48]
     bc0:      	str	x3, [x1, #0xa90]
     bc4:      	mov	x0, #0xc2               ; =194
     bc8:      	str	x0, [x1, #0xa98]
     bcc:      	ldur	x13, [sp, #0x40]
     bd0:      	str	x13, [x1, #0xaa0]
     bd4:      	mov	x0, #0xc4               ; =196
     bd8:      	str	x0, [x1, #0xaa8]
     bdc:      	mov	x0, #0xc5               ; =197
     be0:      	str	x0, [x1, #0xab0]
     be4:      	mov	x0, #0xc6               ; =198
     be8:      	str	x0, [x1, #0xab8]
     bec:      	mov	x0, #0xc7               ; =199
     bf0:      	str	x0, [x1, #0xac0]
     bf4:      	ldur	x9, [sp, #0x8]
     bf8:      	str	x9, [x1, #0xac8]
     bfc:      	mov	x0, #0xc9               ; =201
     c00:      	str	x0, [x1, #0xad0]
     c04:      	mov	x0, #0xca               ; =202
     c08:      	str	x0, [x1, #0xad8]
     c0c:      	mov	x0, #0xcb               ; =203
     c10:      	str	x0, [x1, #0xae0]
     c14:      	mov	x0, #0xcc               ; =204
     c18:      	str	x0, [x1, #0xae8]
     c1c:      	mov	x0, #0xcd               ; =205
     c20:      	str	x0, [x1, #0xaf0]
     c24:      	mov	x0, #0xce               ; =206
     c28:      	str	x0, [x1, #0xaf8]
     c2c:      	mov	x0, #0xcf               ; =207
     c30:      	str	x0, [x1, #0xb00]
     c34:      	mov	x0, #0xd0               ; =208
     c38:      	str	x0, [x1, #0xb08]
     c3c:      	mov	x0, #0xd1               ; =209
     c40:      	str	x0, [x1, #0xb10]
     c44:      	mov	x0, #0xd2               ; =210
     c48:      	str	x0, [x1, #0xb18]
     c4c:      	mov	x0, #0xd3               ; =211
     c50:      	str	x0, [x1, #0xb20]
     c54:      	mov	x0, #0xd4               ; =212
     c58:      	str	x0, [x1, #0xb28]
     c5c:      	mov	x0, #0xd5               ; =213
     c60:      	str	x0, [x1, #0xb30]
     c64:      	mov	x0, #0xd6               ; =214
     c68:      	str	x0, [x1, #0xb38]
     c6c:      	mov	x0, #0xd7               ; =215
     c70:      	str	x0, [x1, #0xb40]
     c74:      	mov	x0, #0xd8               ; =216
     c78:      	str	x0, [x1, #0xb48]
     c7c:      	mov	x0, #0xd9               ; =217
     c80:      	str	x0, [x1, #0xb50]
     c84:      	mov	x0, #0xda               ; =218
     c88:      	str	x0, [x1, #0xb58]
     c8c:      	mov	x0, #0xdb               ; =219
     c90:      	str	x0, [x1, #0xb60]
     c94:      	mov	x0, #0xdc               ; =220
     c98:      	str	x0, [x1, #0xb68]
     c9c:      	mov	x0, #0xdd               ; =221
     ca0:      	str	x0, [x1, #0xb70]
     ca4:      	mov	x0, #0xde               ; =222
     ca8:      	str	x0, [x1, #0xb78]
     cac:      	mov	x0, #0xdf               ; =223
     cb0:      	str	x0, [x1, #0xb80]
     cb4:      	mov	x0, #0xe0               ; =224
     cb8:      	str	x0, [x1, #0xb88]
     cbc:      	mov	x0, #0xe1               ; =225
     cc0:      	str	x0, [x1, #0xb90]
     cc4:      	mov	x0, #0xe2               ; =226
     cc8:      	str	x0, [x1, #0xb98]
     ccc:      	ldur	x2, [sp, #0x38]
     cd0:      	str	x2, [x1, #0xba0]
     cd4:      	mov	x0, #0xe4               ; =228
     cd8:      	str	x0, [x1, #0xba8]
     cdc:      	mov	x0, #0xe5               ; =229
     ce0:      	str	x0, [x1, #0xbb0]
     ce4:      	mov	x2, #0xe6               ; =230
     ce8:      	str	x2, [x1, #0xbb8]
     cec:      	mov	x2, #0xe7               ; =231
     cf0:      	str	x2, [x1, #0xbc0]
     cf4:      	mov	x3, #0xe8               ; =232
     cf8:      	str	x3, [x1, #0xbc8]
     cfc:      	mov	x4, #0xe9               ; =233
     d00:      	str	x4, [x1, #0xbd0]
     d04:      	mov	x5, #0xea               ; =234
     d08:      	str	x5, [x1, #0xbd8]
     d0c:      	mov	x6, #0xeb               ; =235
     d10:      	str	x6, [x1, #0xbe0]
     d14:      	mov	x7, #0xec               ; =236
     d18:      	str	x7, [x1, #0xbe8]
     d1c:      	mov	x8, #0xed               ; =237
     d20:      	str	x8, [x1, #0xbf0]
     d24:      	mov	x9, #0xee               ; =238
     d28:      	str	x9, [x1, #0xbf8]
     d2c:      	mov	x10, #0xef              ; =239
     d30:      	str	x10, [x1, #0xc00]
     d34:      	mov	x11, #0xf0              ; =240
     d38:      	str	x11, [x1, #0xc08]
     d3c:      	mov	x12, #0xf1              ; =241
     d40:      	str	x12, [x1, #0xc10]
     d44:      	mov	x13, #0xf2              ; =242
     d48:      	str	x13, [x1, #0xc18]
     d4c:      	mov	x14, #0xf3              ; =243
     d50:      	str	x14, [x1, #0xc20]
     d54:      	mov	x15, #0xf4              ; =244
     d58:      	str	x15, [x1, #0xc28]
     d5c:      	mov	x0, #0xf5               ; =245
     d60:      	str	x0, [x1, #0xc30]
     d64:      	mov	x0, #0xf6               ; =246
     d68:      	str	x0, [x1, #0xc38]
     d6c:      	mov	x0, #0xf7               ; =247
     d70:      	str	x0, [x1, #0xc40]
     d74:      	mov	x0, #0xf8               ; =248
     d78:      	str	x0, [x1, #0xc48]
     d7c:      	mov	x0, #0xf9               ; =249
     d80:      	str	x0, [x1, #0xc50]
     d84:      	mov	x0, #0xfa               ; =250
     d88:      	str	x0, [x1, #0xc58]
     d8c:      	mov	x0, #0xfb               ; =251
     d90:      	str	x0, [x1, #0xc60]
     d94:      	mov	x0, #0xfc               ; =252
     d98:      	str	x0, [x1, #0xc68]
     d9c:      	mov	x0, #0xfd               ; =253
     da0:      	str	x0, [x1, #0xc70]
     da4:      	mov	x0, #0xfe               ; =254
     da8:      	str	x0, [x1, #0xc78]
     dac:      	mov	w16, #0x9b98            ; =39832
     db0:      	movk	w16, #0x1, lsl #16
     db4:      	ldr	x5, [sp, x16, sxtx]
     db8:      	str	x5, [x1, #0xc80]
     dbc:      	ldur	x11, [sp, #0xe8]
     dc0:      	str	x11, [x1, #0xcf8]
     dc4:      	ldur	x6, [sp, #0xe0]
     dc8:      	str	x6, [x1, #0xd00]
     dcc:      	mov	w16, #0x9bd0            ; =39888
     dd0:      	movk	w16, #0x1, lsl #16
     dd4:      	str	x1, [sp, x16, sxtx]
     dd8:      	mov	x1, #0x0                ; =0
     ddc:      	ldur	x0, [sp]
     de0:      	str	x1, [x0, #0x48]
     de4:      	mov	w16, #0x9bc0            ; =39872
     de8:      	movk	w16, #0x1, lsl #16
     dec:      	ldr	x19, [sp, x16, sxtx]
     df0:      	mov	w16, #0x9bc8            ; =39880
     df4:      	movk	w16, #0x1, lsl #16
     df8:      	ldr	x0, [sp, x16, sxtx]
     dfc:      	blr	x19
     e00:      	mov	x1, #0x2                ; =2
     e04:      	cmp	x0, #0x0
     e08:      	b.ne	0xd7320 <_mech_canonical_program_entry_v1+0xd7320>
     e0c:      	b	0xe1c <_mech_canonical_program_entry_v1+0xe1c>
     e10:      	mov	w16, #0x9bd0            ; =39888
     e14:      	movk	w16, #0x1, lsl #16
     e18:      	str	x1, [sp, x16, sxtx]
     e1c:      	mov	x1, #0x1                ; =1
     e20:      	ldur	x0, [sp]
     e24:      	str	x1, [x0, #0x48]
     e28:      	ldur	x4, [sp, #0xf0]
     e2c:      	cmp	x4, #0x0
     e30:      	b.eq	0xd7324 <_mech_canonical_program_entry_v1+0xd7324>
     e34:      	mov	x1, #0x1                ; =1
     e38:      	mov	w16, #0x9bc0            ; =39872
     e3c:      	movk	w16, #0x1, lsl #16
     e40:      	ldr	x2, [sp, x16, sxtx]
     e44:      	mov	w16, #0x9bc8            ; =39880
     e48:      	movk	w16, #0x1, lsl #16
     e4c:      	ldr	x0, [sp, x16, sxtx]
     e50:      	blr	x2
     e54:      	mov	x1, #0x2                ; =2
     e58:      	cmp	x0, #0x0
     e5c:      	b.ne	0xd7328 <_mech_canonical_program_entry_v1+0xd7328>
     e60:      	mov	x1, #0x2                ; =2
     e64:      	ldur	x0, [sp]
     e68:      	str	x1, [x0, #0x48]
     e6c:      	mov	w16, #0x9bc0            ; =39872
     e70:      	movk	w16, #0x1, lsl #16
     e74:      	ldr	x9, [sp, x16, sxtx]
     e78:      	mov	w16, #0x3748            ; =14152
     e7c:      	movk	w16, #0x1, lsl #16
     e80:      	str	x1, [sp, x16, sxtx]
     e84:      	mov	w16, #0x9bc8            ; =39880
     e88:      	movk	w16, #0x1, lsl #16
     e8c:      	ldr	x0, [sp, x16, sxtx]
     e90:      	blr	x9
     e94:      	cmp	x0, #0x0
     e98:      	b.ne	0xd732c <_mech_canonical_program_entry_v1+0xd732c>
     e9c:      	mov	x0, #0x5                ; =5
     ea0:      	ldur	x2, [sp]
     ea4:      	str	x0, [x2, #0x48]
     ea8:      	mov	w16, #0x9bb0            ; =39856
     eac:      	movk	w16, #0x1, lsl #16
     eb0:      	ldr	x6, [sp, x16, sxtx]
     eb4:      	mov	w16, #0x9b98            ; =39832
     eb8:      	movk	w16, #0x1, lsl #16
     ebc:      	str	x0, [sp, x16, sxtx]
     ec0:      	ldr	x0, [x6]
     ec4:      	cmp	x0, #0x0
     ec8:      	b.ne	0xf0c <_mech_canonical_program_entry_v1+0xf0c>
     ecc:      	mov	w16, #0x9bc0            ; =39872
     ed0:      	movk	w16, #0x1, lsl #16
     ed4:      	ldr	x2, [sp, x16, sxtx]
     ed8:      	mov	w16, #0x9bc8            ; =39880
     edc:      	movk	w16, #0x1, lsl #16
     ee0:      	ldr	x0, [sp, x16, sxtx]
     ee4:      	mov	w16, #0x9b98            ; =39832
     ee8:      	movk	w16, #0x1, lsl #16
     eec:      	ldr	x1, [sp, x16, sxtx]
     ef0:      	blr	x2
     ef4:      	mov	x1, #0x2                ; =2
     ef8:      	mov	w16, #0x3748            ; =14152
     efc:      	movk	w16, #0x1, lsl #16
     f00:      	str	x1, [sp, x16, sxtx]
     f04:      	cmp	x0, #0x0
     f08:      	b.ne	0xd9a60 <_mech_canonical_program_entry_v1+0xd9a60>
     f0c:      	mov	x0, #0x6                ; =6
     f10:      	ldur	x1, [sp]
     f14:      	str	x0, [x1, #0x48]
     f18:      	mov	w16, #0x9bc0            ; =39872
     f1c:      	movk	w16, #0x1, lsl #16
     f20:      	ldr	x2, [sp, x16, sxtx]
     f24:      	mov	w16, #0x9b90            ; =39824
     f28:      	movk	w16, #0x1, lsl #16
     f2c:      	str	x0, [sp, x16, sxtx]
     f30:      	mov	w16, #0x9bc8            ; =39880
     f34:      	movk	w16, #0x1, lsl #16
     f38:      	ldr	x0, [sp, x16, sxtx]
     f3c:      	mov	w16, #0x9b90            ; =39824
     f40:      	movk	w16, #0x1, lsl #16
     f44:      	ldr	x1, [sp, x16, sxtx]
     f48:      	blr	x2
     f4c:      	mov	x9, #0x2                ; =2
     f50:      	mov	w16, #0x3748            ; =14152
     f54:      	movk	w16, #0x1, lsl #16
     f58:      	str	x9, [sp, x16, sxtx]
     f5c:      	cmp	x0, #0x0
     f60:      	b.ne	0xd9d1c <_mech_canonical_program_entry_v1+0xd9d1c>
     f64:      	mov	x0, #0x3                ; =3
     f68:      	mov	w16, #0x3748            ; =14152
     f6c:      	movk	w16, #0x1, lsl #16
     f70:      	str	x0, [sp, x16, sxtx]
     f74:      	mov	w16, #0x9ba0            ; =39840
     f78:      	movk	w16, #0x1, lsl #16
     f7c:      	ldr	x0, [sp, x16, sxtx]
     f80:      	cmp	x0, #0x0
     f84:      	b.eq	0xd9d20 <_mech_canonical_program_entry_v1+0xd9d20>
     f88:      	mov	x5, #0x0                ; =0
     f8c:      	mov	w16, #0x9ba8            ; =39848
     f90:      	movk	w16, #0x1, lsl #16
     f94:      	ldr	x0, [sp, x16, sxtx]
     f98:      	str	x5, [x0]
     f9c:      	mov	x4, #0x1                ; =1
     fa0:      	mov	w16, #0x9bb8            ; =39864
     fa4:      	movk	w16, #0x1, lsl #16
     fa8:      	ldr	x19, [sp, x16, sxtx]
     fac:      	mov	w16, #0x9bc8            ; =39880
     fb0:      	movk	w16, #0x1, lsl #16
     fb4:      	ldr	x0, [sp, x16, sxtx]
     fb8:      	mov	w16, #0x9b90            ; =39824
     fbc:      	movk	w16, #0x1, lsl #16
     fc0:      	ldr	x1, [sp, x16, sxtx]
     fc4:      	mov	w16, #0x9ba8            ; =39848
     fc8:      	movk	w16, #0x1, lsl #16
     fcc:      	ldr	x3, [sp, x16, sxtx]
     fd0:      	mov	w16, #0x9bb0            ; =39856
     fd4:      	movk	w16, #0x1, lsl #16
     fd8:      	ldr	x6, [sp, x16, sxtx]
     fdc:      	mov	x2, x5
     fe0:      	blr	x19
     fe4:      	mov	x1, #0x2                ; =2
     fe8:      	mov	w16, #0x3748            ; =14152
     fec:      	movk	w16, #0x1, lsl #16
     ff0:      	str	x1, [sp, x16, sxtx]
     ff4:      	cmp	x0, #0x0
     ff8:      	b.ne	0xd9d24 <_mech_canonical_program_entry_v1+0xd9d24>
     ffc:      	mov	w16, #0x9bb0            ; =39856
    1000:      	movk	w16, #0x1, lsl #16
    1004:      	ldr	x6, [sp, x16, sxtx]
    1008:      	ldr	x5, [x6]
    100c:      	mov	w16, #0x9bd0            ; =39888
    1010:      	movk	w16, #0x1, lsl #16
    1014:      	ldr	x0, [sp, x16, sxtx]
    1018:      	str	x5, [x0, #0xfb8]
    101c:      	mov	x19, #0x7               ; =7
    1020:      	ldur	x0, [sp]
    1024:      	str	x19, [x0, #0x48]
    1028:      	mov	w16, #0x9bc0            ; =39872
    102c:      	movk	w16, #0x1, lsl #16
    1030:      	ldr	x2, [sp, x16, sxtx]
    1034:      	mov	w16, #0x9bc8            ; =39880
    1038:      	movk	w16, #0x1, lsl #16
    103c:      	ldr	x0, [sp, x16, sxtx]
    1040:      	mov	x1, x19
    1044:      	blr	x2
    1048:      	mov	w16, #0x9b88            ; =39816
    104c:      	movk	w16, #0x1, lsl #16
    1050:      	str	x19, [sp, x16, sxtx]
    1054:      	mov	x1, #0x2                ; =2
    1058:      	mov	w16, #0x3748            ; =14152
    105c:      	movk	w16, #0x1, lsl #16
    1060:      	str	x1, [sp, x16, sxtx]
    1064:      	cmp	x0, #0x0
    1068:      	b.ne	0xd9eac <_mech_canonical_program_entry_v1+0xd9eac>
    106c:      	mov	w16, #0x9bd0            ; =39888
    1070:      	movk	w16, #0x1, lsl #16
    1074:      	ldr	x0, [sp, x16, sxtx]
    1078:      	ldr	x11, [x0, #0xfb8]
    107c:      	ldr	x12, [x0, #0x2c8]
    1080:      	cmp	x11, x12
    1084:      	cset	x12, ls
    1088:      	uxtb	w12, w12
    108c:      	str	x12, [x0, #0xfc0]
    1090:      	mov	x19, #0x8               ; =8
    1094:      	ldur	x0, [sp]
    1098:      	str	x19, [x0, #0x48]
    109c:      	mov	w16, #0x9bb0            ; =39856
    10a0:      	movk	w16, #0x1, lsl #16
    10a4:      	ldr	x6, [sp, x16, sxtx]
    10a8:      	ldr	x15, [x6]
    10ac:      	cmp	x15, #0x0
    10b0:      	b.eq	0x10d0 <_mech_canonical_program_entry_v1+0x10d0>
    10b4:      	mov	w16, #0x9bd0            ; =39888
    10b8:      	movk	w16, #0x1, lsl #16
    10bc:      	ldr	x0, [sp, x16, sxtx]
    10c0:      	mov	w16, #0x9b80            ; =39808
    10c4:      	movk	w16, #0x1, lsl #16
    10c8:      	str	x19, [sp, x16, sxtx]
    10cc:      	b	0x1120 <_mech_canonical_program_entry_v1+0x1120>
    10d0:      	mov	w16, #0x9bc0            ; =39872
    10d4:      	movk	w16, #0x1, lsl #16
    10d8:      	ldr	x10, [sp, x16, sxtx]
    10dc:      	mov	w16, #0x9bc8            ; =39880
    10e0:      	movk	w16, #0x1, lsl #16
    10e4:      	ldr	x0, [sp, x16, sxtx]
    10e8:      	mov	x1, x19
    10ec:      	blr	x10
    10f0:      	mov	w16, #0x9b80            ; =39808
    10f4:      	movk	w16, #0x1, lsl #16
    10f8:      	str	x19, [sp, x16, sxtx]
    10fc:      	mov	x1, #0x2                ; =2
    1100:      	mov	w16, #0x3748            ; =14152
    1104:      	movk	w16, #0x1, lsl #16
    1108:      	str	x1, [sp, x16, sxtx]
    110c:      	cmp	x0, #0x0
    1110:      	b.ne	0xd9eb0 <_mech_canonical_program_entry_v1+0xd9eb0>
    1114:      	mov	w16, #0x9bd0            ; =39888
    1118:      	movk	w16, #0x1, lsl #16
    111c:      	ldr	x0, [sp, x16, sxtx]
    1120:      	mov	w16, #0x9bd0            ; =39888
    1124:      	movk	w16, #0x1, lsl #16
    1128:      	ldr	x0, [sp, x16, sxtx]
    112c:      	ldr	x0, [x0, #0xfc0]
    1130:      	mov	w16, #0x9bd0            ; =39888
    1134:      	movk	w16, #0x1, lsl #16
    1138:      	ldr	x1, [sp, x16, sxtx]
    113c:      	ldr	x1, [x1, #0xd00]
    1140:      	cmp	x0, x1
    1144:      	b.eq	0xd9f24 <_mech_canonical_program_entry_v1+0xd9f24>
    1148:      	mov	x0, #0xa                ; =10
    114c:      	ldur	x8, [sp]
    1150:      	str	x0, [x8, #0x48]
    1154:      	mov	w16, #0x9bb0            ; =39856
    1158:      	movk	w16, #0x1, lsl #16
    115c:      	ldr	x6, [sp, x16, sxtx]
    1160:      	mov	w16, #0x9b78            ; =39800
    1164:      	movk	w16, #0x1, lsl #16
    1168:      	str	x0, [sp, x16, sxtx]
    116c:      	ldr	x0, [x6]
    1170:      	cmp	x0, #0x0
    1174:      	b.eq	0x1188 <_mech_canonical_program_entry_v1+0x1188>
    1178:      	mov	w16, #0x9bd0            ; =39888
    117c:      	movk	w16, #0x1, lsl #16
    1180:      	ldr	x0, [sp, x16, sxtx]
    1184:      	b	0x11d4 <_mech_canonical_program_entry_v1+0x11d4>
    1188:      	mov	w16, #0x9bc0            ; =39872
    118c:      	movk	w16, #0x1, lsl #16
    1190:      	ldr	x2, [sp, x16, sxtx]
    1194:      	mov	w16, #0x9bc8            ; =39880
    1198:      	movk	w16, #0x1, lsl #16
    119c:      	ldr	x0, [sp, x16, sxtx]
    11a0:      	mov	w16, #0x9b78            ; =39800
    11a4:      	movk	w16, #0x1, lsl #16
    11a8:      	ldr	x1, [sp, x16, sxtx]
    11ac:      	blr	x2
    11b0:      	mov	x7, #0x2                ; =2
    11b4:      	mov	w16, #0x3748            ; =14152
    11b8:      	movk	w16, #0x1, lsl #16
    11bc:      	str	x7, [sp, x16, sxtx]
    11c0:      	cmp	x0, #0x0
    11c4:      	b.ne	0xd9fa4 <_mech_canonical_program_entry_v1+0xd9fa4>
    11c8:      	mov	w16, #0x9bd0            ; =39888
    11cc:      	movk	w16, #0x1, lsl #16
    11d0:      	ldr	x0, [sp, x16, sxtx]
    11d4:      	mov	w16, #0x9bd0            ; =39888
    11d8:      	movk	w16, #0x1, lsl #16
    11dc:      	ldr	x0, [sp, x16, sxtx]
    11e0:      	ldr	x0, [x0, #0xfc0]
    11e4:      	mov	w16, #0x9bd0            ; =39888
    11e8:      	movk	w16, #0x1, lsl #16
    11ec:      	ldr	x1, [sp, x16, sxtx]
    11f0:      	ldr	x1, [x1, #0xcf8]
    11f4:      	cmp	x0, x1
    11f8:      	b.eq	0x1254 <_mech_canonical_program_entry_v1+0x1254>
    11fc:      	mov	x1, #0x65               ; =101
    1200:      	ldur	x0, [sp]
    1204:      	str	x1, [x0, #0x48]
    1208:      	mov	w16, #0x9bc0            ; =39872
    120c:      	movk	w16, #0x1, lsl #16
    1210:      	ldr	x2, [sp, x16, sxtx]
    1214:      	mov	w16, #0x9bc8            ; =39880
    1218:      	movk	w16, #0x1, lsl #16
    121c:      	ldr	x0, [sp, x16, sxtx]
    1220:      	blr	x2
    1224:      	mov	x1, #0x2                ; =2
    1228:      	mov	w16, #0x3748            ; =14152
    122c:      	movk	w16, #0x1, lsl #16
    1230:      	str	x1, [sp, x16, sxtx]
    1234:      	cmp	x0, #0x0
    1238:      	b.ne	0xd9fdc <_mech_canonical_program_entry_v1+0xd9fdc>
    123c:      	mov	x0, #0x4                ; =4
    1240:      	mov	w16, #0x3748            ; =14152
    1244:      	movk	w16, #0x1, lsl #16
    1248:      	str	x0, [sp, x16, sxtx]
    124c:      	ldur	x0, [sp]
    1250:      	b	0xc790f4 <_mech_canonical_program_entry_v1+0xc790f4>
    1254:      	mov	x1, #0x66               ; =102
    1258:      	ldur	x0, [sp]
    125c:      	str	x1, [x0, #0x48]
    1260:      	mov	w16, #0x9bb0            ; =39856
    1264:      	movk	w16, #0x1, lsl #16
    1268:      	ldr	x6, [sp, x16, sxtx]
    126c:      	ldr	x0, [x6]
    1270:      	cmp	x0, #0x0
    1274:      	b.ne	0x12ac <_mech_canonical_program_entry_v1+0x12ac>
    1278:      	mov	w16, #0x9bc0            ; =39872
    127c:      	movk	w16, #0x1, lsl #16
    1280:      	ldr	x2, [sp, x16, sxtx]
    1284:      	mov	w16, #0x9bc8            ; =39880
    1288:      	movk	w16, #0x1, lsl #16
    128c:      	ldr	x0, [sp, x16, sxtx]
    1290:      	blr	x2
    1294:      	mov	x1, #0x2                ; =2
    1298:      	mov	w16, #0x3748            ; =14152
    129c:      	movk	w16, #0x1, lsl #16
    12a0:      	str	x1, [sp, x16, sxtx]
    12a4:      	cmp	x0, #0x0
    12a8:      	b.ne	0xda044 <_mech_canonical_program_entry_v1+0xda044>
    12ac:      	mov	x1, #0x67               ; =103
    12b0:      	ldur	x0, [sp]
    12b4:      	str	x1, [x0, #0x48]
    12b8:      	mov	w16, #0x9bc0            ; =39872
    12bc:      	movk	w16, #0x1, lsl #16
    12c0:      	ldr	x2, [sp, x16, sxtx]
    12c4:      	mov	x19, x1
    12c8:      	mov	w16, #0x9bc8            ; =39880
    12cc:      	movk	w16, #0x1, lsl #16
    12d0:      	ldr	x0, [sp, x16, sxtx]
    12d4:      	blr	x2
    12d8:      	mov	x1, #0x2                ; =2
    12dc:      	mov	w16, #0x3748            ; =14152
    12e0:      	movk	w16, #0x1, lsl #16
    12e4:      	str	x1, [sp, x16, sxtx]
    12e8:      	cmp	x0, #0x0
    12ec:      	b.ne	0xda07c <_mech_canonical_program_entry_v1+0xda07c>
    12f0:      	mov	x0, #0x3                ; =3
    12f4:      	mov	w16, #0x3748            ; =14152
    12f8:      	movk	w16, #0x1, lsl #16
    12fc:      	str	x0, [sp, x16, sxtx]
    1300:      	mov	w16, #0x9ba0            ; =39840
    1304:      	movk	w16, #0x1, lsl #16
    1308:      	ldr	x0, [sp, x16, sxtx]
    130c:      	cmp	x0, #0x0
    1310:      	b.eq	0xda080 <_mech_canonical_program_entry_v1+0xda080>
    1314:      	mov	x5, #0x0                ; =0
    1318:      	mov	w16, #0x9ba8            ; =39848
    131c:      	movk	w16, #0x1, lsl #16
    1320:      	ldr	x0, [sp, x16, sxtx]
    1324:      	str	x5, [x0]
    1328:      	mov	x4, #0x1                ; =1
    132c:      	mov	x1, x19
    1330:      	mov	w16, #0x9bb8            ; =39864
    1334:      	movk	w16, #0x1, lsl #16
    1338:      	ldr	x7, [sp, x16, sxtx]
    133c:      	mov	w16, #0x9bc8            ; =39880
    1340:      	movk	w16, #0x1, lsl #16
    1344:      	ldr	x0, [sp, x16, sxtx]
    1348:      	mov	w16, #0x9ba8            ; =39848
    134c:      	movk	w16, #0x1, lsl #16
    1350:      	ldr	x3, [sp, x16, sxtx]
    1354:      	mov	w16, #0x9bb0            ; =39856
    1358:      	movk	w16, #0x1, lsl #16
    135c:      	ldr	x6, [sp, x16, sxtx]
    1360:      	mov	x2, x5
    1364:      	blr	x7
    1368:      	mov	x1, #0x2                ; =2
    136c:      	mov	w16, #0x3748            ; =14152
    1370:      	movk	w16, #0x1, lsl #16
    1374:      	str	x1, [sp, x16, sxtx]
    1378:      	cmp	x0, #0x0
    137c:      	b.ne	0xda0f4 <_mech_canonical_program_entry_v1+0xda0f4>
    1380:      	mov	w16, #0x9bb0            ; =39856
    1384:      	movk	w16, #0x1, lsl #16
    1388:      	ldr	x6, [sp, x16, sxtx]
    138c:      	ldr	x0, [x6]
    1390:      	mov	w16, #0x9bd0            ; =39888
    1394:      	movk	w16, #0x1, lsl #16
    1398:      	ldr	x1, [sp, x16, sxtx]
    139c:      	str	x0, [x1, #0x1150]
    13a0:      	mov	x1, #0x68               ; =104
    13a4:      	ldur	x0, [sp]
    13a8:      	str	x1, [x0, #0x48]
    13ac:      	mov	w16, #0x9bc0            ; =39872
    13b0:      	movk	w16, #0x1, lsl #16
    13b4:      	ldr	x2, [sp, x16, sxtx]
    13b8:      	mov	x19, x1
    13bc:      	mov	w16, #0x9bc8            ; =39880
    13c0:      	movk	w16, #0x1, lsl #16
    13c4:      	ldr	x0, [sp, x16, sxtx]
    13c8:      	blr	x2
    13cc:      	mov	x7, #0x2                ; =2
    13d0:      	mov	w16, #0x3748            ; =14152
    13d4:      	movk	w16, #0x1, lsl #16
    13d8:      	str	x7, [sp, x16, sxtx]
    13dc:      	cmp	x0, #0x0
    13e0:      	b.ne	0xda0f8 <_mech_canonical_program_entry_v1+0xda0f8>
    13e4:      	mov	x0, #0x2                ; =2
    13e8:      	mov	w16, #0x3748            ; =14152
    13ec:      	movk	w16, #0x1, lsl #16
    13f0:      	str	x0, [sp, x16, sxtx]
    13f4:      	mov	x5, #0x0                ; =0
    13f8:      	mov	x1, x19
    13fc:      	mov	w16, #0x9bb8            ; =39864
    1400:      	movk	w16, #0x1, lsl #16
    1404:      	ldr	x7, [sp, x16, sxtx]
    1408:      	mov	w16, #0x9bc8            ; =39880
    140c:      	movk	w16, #0x1, lsl #16
    1410:      	ldr	x0, [sp, x16, sxtx]
    1414:      	mov	w16, #0x3748            ; =14152
    1418:      	movk	w16, #0x1, lsl #16
    141c:      	ldr	x2, [sp, x16, sxtx]
    1420:      	mov	w16, #0x9bb0            ; =39856
    1424:      	movk	w16, #0x1, lsl #16
    1428:      	ldr	x6, [sp, x16, sxtx]
    142c:      	mov	x3, x5
    1430:      	mov	x4, x5
    1434:      	blr	x7
    1438:      	cmp	x0, #0x0
    143c:      	b.ne	0xda0fc <_mech_canonical_program_entry_v1+0xda0fc>
    1440:      	mov	x1, #0x6a               ; =106
    1444:      	ldur	x0, [sp]
    1448:      	str	x1, [x0, #0x48]
    144c:      	mov	w16, #0x9bc0            ; =39872
    1450:      	movk	w16, #0x1, lsl #16
    1454:      	ldr	x2, [sp, x16, sxtx]
    1458:      	mov	w16, #0x9bc8            ; =39880
    145c:      	movk	w16, #0x1, lsl #16
    1460:      	ldr	x0, [sp, x16, sxtx]
    1464:      	blr	x2
    1468:      	mov	x1, #0x2                ; =2
    146c:      	mov	w16, #0x3748            ; =14152
    1470:      	movk	w16, #0x1, lsl #16
    1474:      	str	x1, [sp, x16, sxtx]
    1478:      	cmp	x0, #0x0
    147c:      	b.ne	0xda188 <_mech_canonical_program_entry_v1+0xda188>
    1480:      	mov	x1, #0x6b               ; =107
    1484:      	ldur	x0, [sp]
    1488:      	str	x1, [x0, #0x48]
    148c:      	mov	w16, #0x9bc0            ; =39872
    1490:      	movk	w16, #0x1, lsl #16
    1494:      	ldr	x2, [sp, x16, sxtx]
    1498:      	mov	x19, x1
    149c:      	mov	w16, #0x9bc8            ; =39880
    14a0:      	movk	w16, #0x1, lsl #16
    14a4:      	ldr	x0, [sp, x16, sxtx]
    14a8:      	blr	x2
    14ac:      	mov	x1, #0x2                ; =2
    14b0:      	mov	w16, #0x3748            ; =14152
    14b4:      	movk	w16, #0x1, lsl #16
    14b8:      	str	x1, [sp, x16, sxtx]
    14bc:      	cmp	x0, #0x0
    14c0:      	b.ne	0xda18c <_mech_canonical_program_entry_v1+0xda18c>
    14c4:      	mov	w16, #0x9bd0            ; =39888
    14c8:      	movk	w16, #0x1, lsl #16
    14cc:      	ldr	x0, [sp, x16, sxtx]
    14d0:      	ldr	x3, [x0, #0x218]
    14d4:      	ldr	x4, [x0, #0x378]
    14d8:      	mov	x0, #0x2                ; =2
    14dc:      	mov	w16, #0x3748            ; =14152
    14e0:      	movk	w16, #0x1, lsl #16
    14e4:      	str	x0, [sp, x16, sxtx]
    14e8:      	mov	x5, #0x0                ; =0
    14ec:      	mov	x1, x19
    14f0:      	mov	w16, #0x9bb8            ; =39864
    14f4:      	movk	w16, #0x1, lsl #16
    14f8:      	ldr	x14, [sp, x16, sxtx]
    14fc:      	mov	w16, #0x9bc8            ; =39880
    1500:      	movk	w16, #0x1, lsl #16
    1504:      	ldr	x0, [sp, x16, sxtx]
    1508:      	mov	w16, #0x3748            ; =14152
    150c:      	movk	w16, #0x1, lsl #16
    1510:      	ldr	x2, [sp, x16, sxtx]
    1514:      	mov	w16, #0x9bb0            ; =39856
    1518:      	movk	w16, #0x1, lsl #16
    151c:      	ldr	x6, [sp, x16, sxtx]
    1520:      	blr	x14
    1524:      	cmp	x0, #0x0
    1528:      	b.ne	0xda1cc <_mech_canonical_program_entry_v1+0xda1cc>
    152c:      	mov	x1, #0x6c               ; =108
    1530:      	ldur	x0, [sp]
    1534:      	str	x1, [x0, #0x48]
    1538:      	mov	w16, #0x9bc0            ; =39872
    153c:      	movk	w16, #0x1, lsl #16
    1540:      	ldr	x2, [sp, x16, sxtx]
    1544:      	mov	x28, x1
    1548:      	mov	w16, #0x9bc8            ; =39880
    154c:      	movk	w16, #0x1, lsl #16
    1550:      	ldr	x0, [sp, x16, sxtx]
    1554:      	blr	x2
    1558:      	mov	x1, #0x2                ; =2
    155c:      	mov	w16, #0x3748            ; =14152
    1560:      	movk	w16, #0x1, lsl #16
    1564:      	str	x1, [sp, x16, sxtx]
    1568:      	cmp	x0, #0x0
    156c:      	b.ne	0xda204 <_mech_canonical_program_entry_v1+0xda204>
    1570:      	mov	x0, #0x2                ; =2
    1574:      	mov	w16, #0x3748            ; =14152
    1578:      	movk	w16, #0x1, lsl #16
    157c:      	str	x0, [sp, x16, sxtx]
    1580:      	mov	x5, #0x0                ; =0
    1584:      	mov	x1, x28
    1588:      	mov	w16, #0x9bb8            ; =39864
    158c:      	movk	w16, #0x1, lsl #16
    1590:      	ldr	x7, [sp, x16, sxtx]
    1594:      	mov	w16, #0x9bc8            ; =39880
    1598:      	movk	w16, #0x1, lsl #16
    159c:      	ldr	x0, [sp, x16, sxtx]
    15a0:      	mov	w16, #0x3748            ; =14152
    15a4:      	movk	w16, #0x1, lsl #16
    15a8:      	ldr	x2, [sp, x16, sxtx]
    15ac:      	mov	w16, #0x9bb0            ; =39856
    15b0:      	movk	w16, #0x1, lsl #16
    15b4:      	ldr	x6, [sp, x16, sxtx]
    15b8:      	mov	x3, x5
    15bc:      	mov	x4, x5
    15c0:      	blr	x7
    15c4:      	cmp	x0, #0x0
    15c8:      	b.ne	0xda270 <_mech_canonical_program_entry_v1+0xda270>
    15cc:      	mov	w16, #0x9bb0            ; =39856
    15d0:      	movk	w16, #0x1, lsl #16
    15d4:      	ldr	x6, [sp, x16, sxtx]
    15d8:      	ldr	x0, [x6]
    15dc:      	mov	w1, #0xbde8             ; =48616
    15e0:      	movk	w1, #0x2, lsl #16
    15e4:      	mov	w16, #0x9bd0            ; =39888
    15e8:      	movk	w16, #0x1, lsl #16
    15ec:      	ldr	x2, [sp, x16, sxtx]
    15f0:      	str	x0, [x2, x1]
    15f4:      	mov	x27, #0x6d              ; =109
    15f8:      	ldur	x0, [sp]
    15fc:      	ldur	x0, [sp]
    1600:      	str	x27, [x0, #0x48]
    1604:      	mov	w16, #0x9bc0            ; =39872
    1608:      	movk	w16, #0x1, lsl #16
    160c:      	ldr	x2, [sp, x16, sxtx]
    1610:      	mov	w16, #0x9bc8            ; =39880
    1614:      	movk	w16, #0x1, lsl #16
    1618:      	ldr	x0, [sp, x16, sxtx]
    161c:      	mov	x1, x27
    1620:      	blr	x2
    1624:      	mov	x7, #0x2                ; =2
    1628:      	mov	w16, #0x3748            ; =14152
    162c:      	movk	w16, #0x1, lsl #16
    1630:      	str	x7, [sp, x16, sxtx]
    1634:      	cmp	x0, #0x0
    1638:      	b.ne	0xda29c <_mech_canonical_program_entry_v1+0xda29c>
    163c:      	mov	w16, #0x9bd0            ; =39888
    1640:      	movk	w16, #0x1, lsl #16
    1644:      	ldr	x0, [sp, x16, sxtx]
    1648:      	ldr	x4, [x0, #0x378]
    164c:      	mov	w0, #0xbde8             ; =48616
    1650:      	movk	w0, #0x2, lsl #16
    1654:      	mov	w16, #0x9bd0            ; =39888
    1658:      	movk	w16, #0x1, lsl #16
    165c:      	ldr	x11, [sp, x16, sxtx]
    1660:      	ldr	x0, [x11, x0]
    1664:      	add	x1, x4, #0x1
    1668:      	cmp	x0, x1
    166c:      	b.ne	0x1700 <_mech_canonical_program_entry_v1+0x1700>
    1670:      	mov	w16, #0x9bd0            ; =39888
    1674:      	movk	w16, #0x1, lsl #16
    1678:      	ldr	x0, [sp, x16, sxtx]
    167c:      	ldr	x3, [x0, #0x488]
    1680:      	mov	x0, #0x2                ; =2
    1684:      	mov	w16, #0x3748            ; =14152
    1688:      	movk	w16, #0x1, lsl #16
    168c:      	str	x0, [sp, x16, sxtx]
    1690:      	mov	x5, #0x0                ; =0
    1694:      	mov	w16, #0x9bb8            ; =39864
    1698:      	movk	w16, #0x1, lsl #16
    169c:      	ldr	x7, [sp, x16, sxtx]
    16a0:      	mov	w16, #0x9bc8            ; =39880
    16a4:      	movk	w16, #0x1, lsl #16
    16a8:      	ldr	x0, [sp, x16, sxtx]
    16ac:      	mov	x1, x27
    16b0:      	mov	w16, #0x3748            ; =14152
    16b4:      	movk	w16, #0x1, lsl #16
    16b8:      	ldr	x2, [sp, x16, sxtx]
    16bc:      	mov	w16, #0x9bb0            ; =39856
    16c0:      	movk	w16, #0x1, lsl #16
    16c4:      	ldr	x6, [sp, x16, sxtx]
    16c8:      	blr	x7
    16cc:      	cmp	x0, #0x0
    16d0:      	b.ne	0xda2dc <_mech_canonical_program_entry_v1+0xda2dc>
    16d4:      	mov	w16, #0x9bb0            ; =39856
    16d8:      	movk	w16, #0x1, lsl #16
    16dc:      	ldr	x6, [sp, x16, sxtx]
    16e0:      	ldr	x0, [x6]
    16e4:      	mov	x1, #0x3                ; =3
    16e8:      	mov	w16, #0x3748            ; =14152
    16ec:      	movk	w16, #0x1, lsl #16
    16f0:      	str	x1, [sp, x16, sxtx]
    16f4:      	cmp	x0, #0x1
    16f8:      	b.hi	0xda314 <_mech_canonical_program_entry_v1+0xda314>
    16fc:      	cbnz	x0, 0x1a58 <_mech_canonical_program_entry_v1+0x1a58>
    1700:      	mov	w0, #0xbde8             ; =48616
    1704:      	movk	w0, #0x2, lsl #16
    1708:      	mov	w16, #0x9bd0            ; =39888
    170c:      	movk	w16, #0x1, lsl #16
    1710:      	ldr	x1, [sp, x16, sxtx]
    1714:      	ldr	x0, [x1, x0]
    1718:      	cmp	x0, #0x0
    171c:      	b.eq	0x1a74 <_mech_canonical_program_entry_v1+0x1a74>
    1720:      	mov	x1, #0x6e               ; =110
    1724:      	ldur	x0, [sp]
    1728:      	str	x1, [x0, #0x48]
    172c:      	mov	w16, #0x9bc0            ; =39872
    1730:      	movk	w16, #0x1, lsl #16
    1734:      	ldr	x2, [sp, x16, sxtx]
    1738:      	mov	x26, x1
    173c:      	mov	w16, #0x9bc8            ; =39880
    1740:      	movk	w16, #0x1, lsl #16
    1744:      	ldr	x0, [sp, x16, sxtx]
    1748:      	blr	x2
    174c:      	mov	x1, #0x2                ; =2
    1750:      	mov	w16, #0x3748            ; =14152
    1754:      	movk	w16, #0x1, lsl #16
    1758:      	str	x1, [sp, x16, sxtx]
    175c:      	cmp	x0, #0x0
    1760:      	b.ne	0xda318 <_mech_canonical_program_entry_v1+0xda318>
    1764:      	mov	x0, #0x2                ; =2
    1768:      	mov	w16, #0x3748            ; =14152
    176c:      	movk	w16, #0x1, lsl #16
    1770:      	str	x0, [sp, x16, sxtx]
    1774:      	mov	x5, #0x0                ; =0
    1778:      	mov	x1, x26
    177c:      	mov	w16, #0x9bb8            ; =39864
    1780:      	movk	w16, #0x1, lsl #16
    1784:      	ldr	x7, [sp, x16, sxtx]
    1788:      	mov	w16, #0x9bc8            ; =39880
    178c:      	movk	w16, #0x1, lsl #16
    1790:      	ldr	x0, [sp, x16, sxtx]
    1794:      	mov	w16, #0x3748            ; =14152
    1798:      	movk	w16, #0x1, lsl #16
    179c:      	ldr	x2, [sp, x16, sxtx]
    17a0:      	mov	w16, #0x9bb0            ; =39856
    17a4:      	movk	w16, #0x1, lsl #16
    17a8:      	ldr	x6, [sp, x16, sxtx]
    17ac:      	mov	x3, x5
    17b0:      	mov	x4, x5
    17b4:      	blr	x7
    17b8:      	cmp	x0, #0x0
    17bc:      	b.ne	0xda384 <_mech_canonical_program_entry_v1+0xda384>
    17c0:      	mov	w16, #0x9bb0            ; =39856
    17c4:      	movk	w16, #0x1, lsl #16
    17c8:      	ldr	x6, [sp, x16, sxtx]
    17cc:      	ldr	x0, [x6]
    17d0:      	mov	w16, #0x9bd0            ; =39888
    17d4:      	movk	w16, #0x1, lsl #16
    17d8:      	ldr	x1, [sp, x16, sxtx]
    17dc:      	str	x0, [x1, #0x1168]
    17e0:      	mov	x1, #0x70               ; =112
    17e4:      	ldur	x0, [sp]
    17e8:      	str	x1, [x0, #0x48]
    17ec:      	mov	w16, #0x9bc0            ; =39872
    17f0:      	movk	w16, #0x1, lsl #16
    17f4:      	ldr	x11, [sp, x16, sxtx]
    17f8:      	mov	w16, #0x9bc8            ; =39880
    17fc:      	movk	w16, #0x1, lsl #16
