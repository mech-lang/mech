#!/usr/bin/env python3
"""Combine retained static pointer/opcode census with canonical artifact receipts."""
import argparse
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def delta(before, after):
    return {'before': before, 'after': after, 'delta': after - before}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--round', type=Path, required=True)
    args = parser.parse_args()
    root = args.round / 'binary-audit'
    reports = {side: read(root / 'pointer-homes' / side / 'pointer-homes.json')
               for side in ('before', 'after')}
    artifacts = {}
    for side, report in reports.items():
        base = Path(report['path']).parent
        metadata, descriptor = read(base / 'metadata.json'), read(base / 'descriptor.json')
        assert metadata['code_bytes'] == descriptor['descriptor']['code']
        assert metadata['stack_bytes'] == descriptor['descriptor']['stack']
        assert sum(report['opcodes'].values()) * 4 == metadata['code_bytes']
        artifacts[side] = {
            'metadata': metadata,
            'files': {name: {'path': str(base / name),
                             'sha256': hashlib.sha256((base / name).read_bytes()).hexdigest()}
                      for name in ('object.o', 'metadata.json', 'descriptor.json')},
            'source796_action': descriptor['descriptor']['plan']['blocks'][796],
            'source797_action': descriptor['descriptor']['plan']['blocks'][797],
        }
    before, after = reports['before'], reports['after']
    mb, ma = artifacts['before']['metadata'], artifacts['after']['metadata']
    assert before['totals']['stack_load'] == 593954
    assert before['totals']['stack_store'] == 137100
    roles = {}
    for role in sorted(set(before['roles']) | set(after['roles'])):
        b, a = before['roles'].get(role, {}), after['roles'].get(role, {})
        roles[role] = {
            'before_slots': b, 'after_slots': a,
            'loads': delta(sum(v['stack_load'] for v in b.values()),
                           sum(v['stack_load'] for v in a.values())),
            'indexed_loads': delta(sum(v['indexed_stack_load'] for v in b.values()),
                                   sum(v['indexed_stack_load'] for v in a.values())),
        }
    opcodes = sorted(set(before['opcodes']) | set(after['opcodes']))
    report = {
        'scope': 'Static encoded instruction and scalar stack-access comparison; not dynamic visits, retired instructions or elapsed measurements.',
        'historical_role_count_correction': 'Prior audit-stack-reloads.py omitted mov x16 immediate updates, misattributing some spills to a stale pointer offset. Role-specific counts here supersede prior R61165897 locals and31199 arguments figures. Whole stack-access totals and opcode counts were unaffected.',
        'before': artifacts['before']['files'], 'after': artifacts['after']['files'],
        'code_bytes': delta(mb['code_bytes'], ma['code_bytes']),
        'stack_bytes': delta(mb['stack_bytes'], ma['stack_bytes']),
        'static_instructions': delta(sum(before['opcodes'].values()), sum(after['opcodes'].values())),
        'opcode_delta': {opcode: after['opcodes'].get(opcode, 0) - before['opcodes'].get(opcode, 0)
                         for opcode in opcodes},
        'UDIV': delta(before['opcodes'].get('udiv', 0), after['opcodes'].get('udiv', 0)),
        'MSUB': delta(before['opcodes'].get('msub', 0), after['opcodes'].get('msub', 0)),
        'same_typed_ir': mb['typed_ir_sha256'] == ma['typed_ir_sha256'],
        'same_program_revision': mb['program_revision'] == ma['program_revision'],
        'metadata_descriptor_agree': True,
        'stack_accesses': {kind: delta(before['totals'][kind], after['totals'][kind]) for kind in before['totals']},
        'pointer_roles': roles,
        'source796_action': artifacts['after']['source796_action'],
        'source797_action': artifacts['after']['source797_action'],
        'source_anchors': {side: report['source_anchors'] for side, report in reports.items()},
        'limitations': [before['limitation'], 'The verified operand/window offsets identify the same source action; source callback anchors are not per-instruction debug maps.'],
    }
    (args.round / 'binary-audit.json').write_text(json.dumps(report, indent=2) + '\n')
    (root / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ('code_bytes', 'stack_bytes', 'static_instructions', 'stack_accesses', 'pointer_roles')}, indent=2))


if __name__ == '__main__':
    main()
