; Helper site argument anchors; manually verify matching source action.
; Anchor 0x20438
   202a8:      	blr	x2
   202ac:      	mov	x1, #0x2                ; =2
   202b0:      	mov	w16, #0x3748            ; =14152
   202b4:      	movk	w16, #0x1, lsl #16
   202b8:      	str	x1, [sp, x16, sxtx]
   202bc:      	cmp	x0, #0x0
   202c0:      	b.ne	0xf2838 <_mech_canonical_program_entry_v1+0xf2838>
   202c4:      	mov	w16, #0x9bd0            ; =39888
   202c8:      	movk	w16, #0x1, lsl #16
   202cc:      	ldr	x0, [sp, x16, sxtx]
   202d0:      	b	0x202e0 <_mech_canonical_program_entry_v1+0x202e0>
   202d4:      	mov	w16, #0x9bd0            ; =39888
   202d8:      	movk	w16, #0x1, lsl #16
   202dc:      	ldr	x0, [sp, x16, sxtx]
   202e0:      	mov	w16, #0x9bd0            ; =39888
   202e4:      	movk	w16, #0x1, lsl #16
   202e8:      	ldr	x0, [sp, x16, sxtx]
   202ec:      	ldr	x0, [x0, #0x218]
   202f0:      	mov	w16, #0x9bd0            ; =39888
   202f4:      	movk	w16, #0x1, lsl #16
   202f8:      	ldr	x1, [sp, x16, sxtx]
   202fc:      	str	x0, [x1, #0x1af8]
   20300:      	b	0x206ac <_mech_canonical_program_entry_v1+0x206ac>
   20304:      	mov	x0, #0x31b              ; =795
   20308:      	ldur	x4, [sp]
   2030c:      	str	x0, [x4, #0x48]
   20310:      	mov	w0, #0xd870             ; =55408
   20314:      	movk	w0, #0x2, lsl #16
   20318:      	mov	w16, #0x9bd0            ; =39888
   2031c:      	movk	w16, #0x1, lsl #16
   20320:      	ldr	x1, [sp, x16, sxtx]
   20324:      	ldr	x0, [x1, x0]
   20328:      	cmp	x0, #0x0
   2032c:      	b.ne	0x20368 <_mech_canonical_program_entry_v1+0x20368>
   20330:      	mov	x1, #0x31b              ; =795
   20334:      	mov	w16, #0x9bc0            ; =39872
   20338:      	movk	w16, #0x1, lsl #16
   2033c:      	ldr	x13, [sp, x16, sxtx]
   20340:      	mov	w16, #0x9bc8            ; =39880
   20344:      	movk	w16, #0x1, lsl #16
   20348:      	ldr	x0, [sp, x16, sxtx]
   2034c:      	blr	x13
   20350:      	mov	x1, #0x2                ; =2
   20354:      	mov	w16, #0x3748            ; =14152
   20358:      	movk	w16, #0x1, lsl #16
   2035c:      	str	x1, [sp, x16, sxtx]
   20360:      	cmp	x0, #0x0
   20364:      	b.ne	0xf2880 <_mech_canonical_program_entry_v1+0xf2880>
   20368:      	mov	x1, #0x31c              ; =796
   2036c:      	ldur	x0, [sp]
   20370:      	str	x1, [x0, #0x48]
   20374:      	mov	w0, #0xd870             ; =55408
   20378:      	movk	w0, #0x2, lsl #16
   2037c:      	mov	w16, #0x9bd0            ; =39888
   20380:      	movk	w16, #0x1, lsl #16
   20384:      	ldr	x6, [sp, x16, sxtx]
   20388:      	ldr	x0, [x6, x0]
   2038c:      	cmp	x0, #0x0
   20390:      	b.ne	0x203d8 <_mech_canonical_program_entry_v1+0x203d8>
   20394:      	mov	w16, #0x9bc0            ; =39872
   20398:      	movk	w16, #0x1, lsl #16
   2039c:      	ldr	x2, [sp, x16, sxtx]
   203a0:      	mov	w16, #0x9bc8            ; =39880
   203a4:      	movk	w16, #0x1, lsl #16
   203a8:      	ldr	x0, [sp, x16, sxtx]
   203ac:      	blr	x2
   203b0:      	mov	x1, #0x2                ; =2
   203b4:      	mov	w16, #0x3748            ; =14152
   203b8:      	movk	w16, #0x1, lsl #16
   203bc:      	str	x1, [sp, x16, sxtx]
   203c0:      	cmp	x0, #0x0
   203c4:      	b.ne	0xf2884 <_mech_canonical_program_entry_v1+0xf2884>
   203c8:      	mov	w16, #0x9bd0            ; =39888
   203cc:      	movk	w16, #0x1, lsl #16
   203d0:      	ldr	x0, [sp, x16, sxtx]
   203d4:      	b	0x203e4 <_mech_canonical_program_entry_v1+0x203e4>
   203d8:      	mov	w16, #0x9bd0            ; =39888
   203dc:      	movk	w16, #0x1, lsl #16
   203e0:      	ldr	x0, [sp, x16, sxtx]
   203e4:      	mov	w16, #0x9bd0            ; =39888
   203e8:      	movk	w16, #0x1, lsl #16
   203ec:      	ldr	x0, [sp, x16, sxtx]
   203f0:      	ldr	x0, [x0, #0x1ac0]
   203f4:      	mov	w16, #0x9bd0            ; =39888
   203f8:      	movk	w16, #0x1, lsl #16
   203fc:      	ldr	x1, [sp, x16, sxtx]
   20400:      	ldr	x1, [x1, #0x278]
   20404:      	adds	x0, x0, x1
   20408:      	cset	x1, hs
   2040c:      	mov	x4, #0x1                ; =1
   20410:      	mov	w16, #0x3748            ; =14152
   20414:      	movk	w16, #0x1, lsl #16
   20418:      	str	x4, [sp, x16, sxtx]
   2041c:      	uxtb	w1, w1
   20420:      	cmp	w1, #0x0
   20424:      	b.ne	0xf29a0 <_mech_canonical_program_entry_v1+0xf29a0>
   20428:      	mov	w16, #0x9bd0            ; =39888
   2042c:      	movk	w16, #0x1, lsl #16
   20430:      	ldr	x1, [sp, x16, sxtx]
   20434:      	str	x0, [x1, #0x1b00]
   20438:      	mov	x1, #0x31d              ; =797
   2043c:      	ldur	x0, [sp]
   20440:      	str	x1, [x0, #0x48]
   20444:      	mov	x19, x1
   20448:      	mov	w0, #0xd870             ; =55408
   2044c:      	movk	w0, #0x2, lsl #16
   20450:      	mov	w16, #0x9bd0            ; =39888
   20454:      	movk	w16, #0x1, lsl #16
   20458:      	ldr	x1, [sp, x16, sxtx]
   2045c:      	ldr	x0, [x1, x0]
   20460:      	cmp	x0, #0x0
   20464:      	b.ne	0x204a0 <_mech_canonical_program_entry_v1+0x204a0>
   20468:      	mov	w16, #0x9bc0            ; =39872
   2046c:      	movk	w16, #0x1, lsl #16
   20470:      	ldr	x2, [sp, x16, sxtx]
   20474:      	mov	w16, #0x9bc8            ; =39880
   20478:      	movk	w16, #0x1, lsl #16
   2047c:      	ldr	x0, [sp, x16, sxtx]
   20480:      	mov	x1, x19
   20484:      	blr	x2
   20488:      	mov	x1, #0x2                ; =2
   2048c:      	mov	w16, #0x3748            ; =14152
   20490:      	movk	w16, #0x1, lsl #16
   20494:      	str	x1, [sp, x16, sxtx]
   20498:      	cmp	x0, #0x0
   2049c:      	b.ne	0xf29a4 <_mech_canonical_program_entry_v1+0xf29a4>
   204a0:      	mov	x0, #0x3                ; =3
   204a4:      	mov	w16, #0x3748            ; =14152
   204a8:      	movk	w16, #0x1, lsl #16
   204ac:      	str	x0, [sp, x16, sxtx]
   204b0:      	mov	w16, #0x9ba0            ; =39840
   204b4:      	movk	w16, #0x1, lsl #16
   204b8:      	ldr	x0, [sp, x16, sxtx]
   204bc:      	cmp	x0, #0x2
   204c0:      	b.lo	0xf29ec <_mech_canonical_program_entry_v1+0xf29ec>
   204c4:      	mov	x5, #0x0                ; =0
   204c8:      	mov	w16, #0x9ba8            ; =39848
   204cc:      	movk	w16, #0x1, lsl #16
   204d0:      	ldr	x0, [sp, x16, sxtx]
   204d4:      	str	x5, [x0]
   204d8:      	mov	w16, #0x9bd0            ; =39888
   204dc:      	movk	w16, #0x1, lsl #16
   204e0:      	ldr	x0, [sp, x16, sxtx]
   204e4:      	ldr	x0, [x0, #0x1b00]
   204e8:      	mov	w16, #0x9ba8            ; =39848
   204ec:      	movk	w16, #0x1, lsl #16
   204f0:      	ldr	x1, [sp, x16, sxtx]
   204f4:      	str	x0, [x1, #0x8]
   204f8:      	mov	x0, #0x2                ; =2
   204fc:      	mov	x1, x19
   20500:      	mov	w16, #0x9bb8            ; =39864
   20504:      	movk	w16, #0x1, lsl #16
   20508:      	ldr	x7, [sp, x16, sxtx]
   2050c:      	mov	w16, #0x3748            ; =14152
   20510:      	movk	w16, #0x1, lsl #16
   20514:      	str	x0, [sp, x16, sxtx]
   20518:      	mov	w16, #0x9bc8            ; =39880
   2051c:      	movk	w16, #0x1, lsl #16
   20520:      	ldr	x0, [sp, x16, sxtx]
   20524:      	mov	w16, #0x9ba8            ; =39848
   20528:      	movk	w16, #0x1, lsl #16
   2052c:      	ldr	x3, [sp, x16, sxtx]
   20530:      	mov	w16, #0x3748            ; =14152
   20534:      	movk	w16, #0x1, lsl #16
   20538:      	ldr	x4, [sp, x16, sxtx]
   2053c:      	mov	w16, #0x9bb0            ; =39856
   20540:      	movk	w16, #0x1, lsl #16
   20544:      	ldr	x6, [sp, x16, sxtx]
   20548:      	mov	x2, x5
   2054c:      	blr	x7
   20550:      	cmp	x0, #0x0
   20554:      	b.ne	0xf2a34 <_mech_canonical_program_entry_v1+0xf2a34>
   20558:      	mov	w16, #0x9bb0            ; =39856
   2055c:      	movk	w16, #0x1, lsl #16
   20560:      	ldr	x6, [sp, x16, sxtx]
   20564:      	ldr	x1, [x6]
   20568:      	mov	w16, #0x9bd0            ; =39888
   2056c:      	movk	w16, #0x1, lsl #16
   20570:      	ldr	x0, [sp, x16, sxtx]
   20574:      	str	x1, [x0, #0x1b08]
   20578:      	mov	x3, #0x31e              ; =798
   2057c:      	ldur	x0, [sp]
   20580:      	str	x3, [x0, #0x48]
   20584:      	mov	w3, #0xd870             ; =55408
   20588:      	movk	w3, #0x2, lsl #16
   2058c:      	mov	w16, #0x9bd0            ; =39888
   20590:      	movk	w16, #0x1, lsl #16
   20594:      	ldr	x0, [sp, x16, sxtx]
   20598:      	ldr	x6, [x0, x3]
   2059c:      	cmp	x6, #0x0
   205a0:      	b.ne	0x205ec <_mech_canonical_program_entry_v1+0x205ec>
   205a4:      	mov	x1, #0x31e              ; =798
   205a8:      	mov	w16, #0x9bc0            ; =39872
   205ac:      	movk	w16, #0x1, lsl #16
   205b0:      	ldr	x2, [sp, x16, sxtx]
   205b4:      	mov	w16, #0x9bc8            ; =39880
   205b8:      	movk	w16, #0x1, lsl #16
   205bc:      	ldr	x0, [sp, x16, sxtx]
   205c0:      	blr	x2
   205c4:      	mov	x1, #0x2                ; =2
   205c8:      	mov	w16, #0x3748            ; =14152

; Anchor 0x21b40
   219b0:      	ldr	x0, [x6]
   219b4:      	cmp	x0, #0x0
   219b8:      	b.eq	0x219cc <_mech_canonical_program_entry_v1+0x219cc>
   219bc:      	mov	w16, #0x9bd0            ; =39888
   219c0:      	movk	w16, #0x1, lsl #16
   219c4:      	ldr	x0, [sp, x16, sxtx]
   219c8:      	b	0x21a10 <_mech_canonical_program_entry_v1+0x21a10>
   219cc:      	mov	x1, #0x341              ; =833
   219d0:      	mov	w16, #0x9bc0            ; =39872
   219d4:      	movk	w16, #0x1, lsl #16
   219d8:      	ldr	x2, [sp, x16, sxtx]
   219dc:      	mov	w16, #0x9bc8            ; =39880
   219e0:      	movk	w16, #0x1, lsl #16
   219e4:      	ldr	x0, [sp, x16, sxtx]
   219e8:      	blr	x2
   219ec:      	mov	x1, #0x2                ; =2
   219f0:      	mov	w16, #0x3748            ; =14152
   219f4:      	movk	w16, #0x1, lsl #16
   219f8:      	str	x1, [sp, x16, sxtx]
   219fc:      	cmp	x0, #0x0
   21a00:      	b.ne	0xf3938 <_mech_canonical_program_entry_v1+0xf3938>
   21a04:      	mov	w16, #0x9bd0            ; =39888
   21a08:      	movk	w16, #0x1, lsl #16
   21a0c:      	ldr	x0, [sp, x16, sxtx]
   21a10:      	mov	w16, #0x9bd0            ; =39888
   21a14:      	movk	w16, #0x1, lsl #16
   21a18:      	ldr	x0, [sp, x16, sxtx]
   21a1c:      	ldr	x0, [x0, #0x1b30]
   21a20:      	mov	w16, #0x9bd0            ; =39888
   21a24:      	movk	w16, #0x1, lsl #16
   21a28:      	ldr	x1, [sp, x16, sxtx]
   21a2c:      	str	x0, [x1, #0x1990]
   21a30:      	b	0x21eb8 <_mech_canonical_program_entry_v1+0x21eb8>
   21a34:      	mov	w16, #0x99d0            ; =39376
   21a38:      	movk	w16, #0x1, lsl #16
   21a3c:      	str	x1, [sp, x16, sxtx]
   21a40:      	mov	x1, #0x1                ; =1
   21a44:      	adds	x1, x7, x1
   21a48:      	cset	x4, hs
   21a4c:      	uxtb	w4, w4
   21a50:      	cmp	w4, #0x0
   21a54:      	b.ne	0xf393c <_mech_canonical_program_entry_v1+0xf393c>
   21a58:      	cmp	x7, x2
   21a5c:      	cset	x21, lo
   21a60:      	cmp	x7, x2
   21a64:      	b.lo	0x21a88 <_mech_canonical_program_entry_v1+0x21a88>
   21a68:      	cmp	x7, x2
   21a6c:      	b.lo	0xf3984 <_mech_canonical_program_entry_v1+0xf3984>
   21a70:      	mov	x15, #0x0               ; =0
   21a74:      	mov	w16, #0x99e0            ; =39392
   21a78:      	movk	w16, #0x1, lsl #16
   21a7c:      	ldr	x4, [sp, x16, sxtx]
   21a80:      	mov	x28, x8
   21a84:      	b	0x21c94 <_mech_canonical_program_entry_v1+0x21c94>
   21a88:      	mov	x4, #0x1                ; =1
   21a8c:      	adds	x22, x7, x4
   21a90:      	cset	x4, hs
   21a94:      	uxtb	w4, w4
   21a98:      	cmp	w4, #0x0
   21a9c:      	b.ne	0xf3988 <_mech_canonical_program_entry_v1+0xf3988>
   21aa0:      	sub	x20, x22, #0x1
   21aa4:      	cmp	x20, x2
   21aa8:      	b.lo	0x21c70 <_mech_canonical_program_entry_v1+0x21c70>
   21aac:      	b	0x92c658 <_mech_canonical_program_entry_v1+0x92c658>
   21ab0:      	mov	x0, #0x0                ; =0
   21ab4:      	mov	w1, #0xd870             ; =55408
   21ab8:      	movk	w1, #0x2, lsl #16
   21abc:      	mov	w16, #0x9bd0            ; =39888
   21ac0:      	movk	w16, #0x1, lsl #16
   21ac4:      	ldr	x2, [sp, x16, sxtx]
   21ac8:      	str	x0, [x2, x1]
   21acc:      	mov	x0, #0x3                ; =3
   21ad0:      	mov	w16, #0x3748            ; =14152
   21ad4:      	movk	w16, #0x1, lsl #16
   21ad8:      	str	x0, [sp, x16, sxtx]
   21adc:      	mov	w16, #0x9ba0            ; =39840
   21ae0:      	movk	w16, #0x1, lsl #16
   21ae4:      	ldr	x0, [sp, x16, sxtx]
   21ae8:      	cmp	x0, #0xc
   21aec:      	b.lo	0xf398c <_mech_canonical_program_entry_v1+0xf398c>
   21af0:      	mov	w0, #0xee78             ; =61048
   21af4:      	movk	w0, #0x2, lsl #16
   21af8:      	mov	w16, #0x9bd0            ; =39888
   21afc:      	movk	w16, #0x1, lsl #16
   21b00:      	ldr	x1, [sp, x16, sxtx]
   21b04:      	ldr	x0, [x1, x0]
   21b08:      	mov	w16, #0x9ba8            ; =39848
   21b0c:      	movk	w16, #0x1, lsl #16
   21b10:      	ldr	x1, [sp, x16, sxtx]
   21b14:      	str	x0, [x1, #0x10]
   21b18:      	mov	w0, #0xee80             ; =61056
   21b1c:      	movk	w0, #0x2, lsl #16
   21b20:      	mov	w16, #0x9bd0            ; =39888
   21b24:      	movk	w16, #0x1, lsl #16
   21b28:      	ldr	x1, [sp, x16, sxtx]
   21b2c:      	ldr	x0, [x1, x0]
   21b30:      	mov	w16, #0x9ba8            ; =39848
   21b34:      	movk	w16, #0x1, lsl #16
   21b38:      	ldr	x1, [sp, x16, sxtx]
   21b3c:      	str	x0, [x1, #0x18]
   21b40:      	mov	x1, #0x31d              ; =797
   21b44:      	mov	x2, #-0x9               ; =-9
   21b48:      	mov	x0, #0x2                ; =2
   21b4c:      	mov	w16, #0x99e0            ; =39392
   21b50:      	movk	w16, #0x1, lsl #16
   21b54:      	ldr	x4, [sp, x16, sxtx]
   21b58:      	mov	w16, #0x9bb8            ; =39864
   21b5c:      	movk	w16, #0x1, lsl #16
   21b60:      	ldr	x7, [sp, x16, sxtx]
   21b64:      	mov	w16, #0x3748            ; =14152
   21b68:      	movk	w16, #0x1, lsl #16
   21b6c:      	str	x0, [sp, x16, sxtx]
   21b70:      	mov	w16, #0x9bc8            ; =39880
   21b74:      	movk	w16, #0x1, lsl #16
   21b78:      	ldr	x0, [sp, x16, sxtx]
   21b7c:      	mov	w16, #0x3748            ; =14152
   21b80:      	movk	w16, #0x1, lsl #16
   21b84:      	ldr	x5, [sp, x16, sxtx]
   21b88:      	mov	w16, #0x9bb0            ; =39856
   21b8c:      	movk	w16, #0x1, lsl #16
   21b90:      	ldr	x6, [sp, x16, sxtx]
   21b94:      	blr	x7
   21b98:      	cmp	x0, #0x0
   21b9c:      	b.ne	0xf3aa8 <_mech_canonical_program_entry_v1+0xf3aa8>
   21ba0:      	mov	x0, #0x3                ; =3
   21ba4:      	mov	w16, #0x3748            ; =14152
   21ba8:      	movk	w16, #0x1, lsl #16
   21bac:      	str	x0, [sp, x16, sxtx]
   21bb0:      	mov	w16, #0x9ba0            ; =39840
   21bb4:      	movk	w16, #0x1, lsl #16
   21bb8:      	ldr	x0, [sp, x16, sxtx]
   21bbc:      	cmp	x0, #0x2
   21bc0:      	b.lo	0xf3aac <_mech_canonical_program_entry_v1+0xf3aac>
   21bc4:      	mov	x5, #0x0                ; =0
   21bc8:      	mov	w16, #0x9ba8            ; =39848
   21bcc:      	movk	w16, #0x1, lsl #16
   21bd0:      	ldr	x0, [sp, x16, sxtx]
   21bd4:      	str	x5, [x0]
   21bd8:      	mov	w16, #0x9bd0            ; =39888
   21bdc:      	movk	w16, #0x1, lsl #16
   21be0:      	ldr	x0, [sp, x16, sxtx]
   21be4:      	ldr	x0, [x0, #0x1b00]
   21be8:      	mov	w16, #0x9ba8            ; =39848
   21bec:      	movk	w16, #0x1, lsl #16
   21bf0:      	ldr	x13, [sp, x16, sxtx]
   21bf4:      	str	x0, [x13, #0x8]
   21bf8:      	mov	x1, #0x31d              ; =797
   21bfc:      	mov	x0, #0x2                ; =2
   21c00:      	mov	w16, #0x9bb8            ; =39864
   21c04:      	movk	w16, #0x1, lsl #16
   21c08:      	ldr	x7, [sp, x16, sxtx]
   21c0c:      	mov	w16, #0x3748            ; =14152
   21c10:      	movk	w16, #0x1, lsl #16
   21c14:      	str	x0, [sp, x16, sxtx]
   21c18:      	mov	w16, #0x9bc8            ; =39880
   21c1c:      	movk	w16, #0x1, lsl #16
   21c20:      	ldr	x0, [sp, x16, sxtx]
   21c24:      	mov	w16, #0x9ba8            ; =39848
   21c28:      	movk	w16, #0x1, lsl #16
   21c2c:      	ldr	x3, [sp, x16, sxtx]
   21c30:      	mov	w16, #0x3748            ; =14152
   21c34:      	movk	w16, #0x1, lsl #16
   21c38:      	ldr	x4, [sp, x16, sxtx]
   21c3c:      	mov	w16, #0x9bb0            ; =39856
   21c40:      	movk	w16, #0x1, lsl #16
   21c44:      	ldr	x6, [sp, x16, sxtx]
   21c48:      	mov	x2, x5
   21c4c:      	blr	x7
   21c50:      	cmp	x0, #0x0
   21c54:      	b.ne	0xf3ab0 <_mech_canonical_program_entry_v1+0xf3ab0>
   21c58:      	mov	x0, #0x3                ; =3
   21c5c:      	mov	w16, #0x3748            ; =14152
   21c60:      	movk	w16, #0x1, lsl #16
   21c64:      	str	x0, [sp, x16, sxtx]
   21c68:      	ldur	x0, [sp]
   21c6c:      	b	0xc790f4 <_mech_canonical_program_entry_v1+0xc790f4>
   21c70:      	mov	w16, #0x99e0            ; =39392
   21c74:      	movk	w16, #0x1, lsl #16
   21c78:      	ldr	x4, [sp, x16, sxtx]
   21c7c:      	ldrb	w12, [x26, x20]
   21c80:      	uxtb	w15, w12
   21c84:      	mov	x12, x15
   21c88:      	mov	x14, x15
   21c8c:      	mov	x20, x22
   21c90:      	mov	x28, x8
   21c94:      	adds	x22, x28, x15
   21c98:      	cset	x23, hs
   21c9c:      	uxtb	w23, w23
   21ca0:      	cmp	w23, #0x0
   21ca4:      	b.ne	0xf3af8 <_mech_canonical_program_entry_v1+0xf3af8>
   21ca8:      	mov	x0, #0x6d30             ; =27952
   21cac:      	sub	x19, x19, x0
   21cb0:      	uxtb	w27, w27
   21cb4:      	uxtb	w21, w21
   21cb8:      	mov	w16, #0x99e8            ; =39400
   21cbc:      	movk	w16, #0x1, lsl #16
   21cc0:      	str	x3, [sp, x16, sxtx]
   21cc4:      	mov	w16, #0x99e0            ; =39392
   21cc8:      	movk	w16, #0x1, lsl #16
   21ccc:      	str	x4, [sp, x16, sxtx]
   21cd0:      	str	x22, [sp, #0x320]

; Anchor 0x21bf8
   21a68:      	cmp	x7, x2
   21a6c:      	b.lo	0xf3984 <_mech_canonical_program_entry_v1+0xf3984>
   21a70:      	mov	x15, #0x0               ; =0
   21a74:      	mov	w16, #0x99e0            ; =39392
   21a78:      	movk	w16, #0x1, lsl #16
   21a7c:      	ldr	x4, [sp, x16, sxtx]
   21a80:      	mov	x28, x8
   21a84:      	b	0x21c94 <_mech_canonical_program_entry_v1+0x21c94>
   21a88:      	mov	x4, #0x1                ; =1
   21a8c:      	adds	x22, x7, x4
   21a90:      	cset	x4, hs
   21a94:      	uxtb	w4, w4
   21a98:      	cmp	w4, #0x0
   21a9c:      	b.ne	0xf3988 <_mech_canonical_program_entry_v1+0xf3988>
   21aa0:      	sub	x20, x22, #0x1
   21aa4:      	cmp	x20, x2
   21aa8:      	b.lo	0x21c70 <_mech_canonical_program_entry_v1+0x21c70>
   21aac:      	b	0x92c658 <_mech_canonical_program_entry_v1+0x92c658>
   21ab0:      	mov	x0, #0x0                ; =0
   21ab4:      	mov	w1, #0xd870             ; =55408
   21ab8:      	movk	w1, #0x2, lsl #16
   21abc:      	mov	w16, #0x9bd0            ; =39888
   21ac0:      	movk	w16, #0x1, lsl #16
   21ac4:      	ldr	x2, [sp, x16, sxtx]
   21ac8:      	str	x0, [x2, x1]
   21acc:      	mov	x0, #0x3                ; =3
   21ad0:      	mov	w16, #0x3748            ; =14152
   21ad4:      	movk	w16, #0x1, lsl #16
   21ad8:      	str	x0, [sp, x16, sxtx]
   21adc:      	mov	w16, #0x9ba0            ; =39840
   21ae0:      	movk	w16, #0x1, lsl #16
   21ae4:      	ldr	x0, [sp, x16, sxtx]
   21ae8:      	cmp	x0, #0xc
   21aec:      	b.lo	0xf398c <_mech_canonical_program_entry_v1+0xf398c>
   21af0:      	mov	w0, #0xee78             ; =61048
   21af4:      	movk	w0, #0x2, lsl #16
   21af8:      	mov	w16, #0x9bd0            ; =39888
   21afc:      	movk	w16, #0x1, lsl #16
   21b00:      	ldr	x1, [sp, x16, sxtx]
   21b04:      	ldr	x0, [x1, x0]
   21b08:      	mov	w16, #0x9ba8            ; =39848
   21b0c:      	movk	w16, #0x1, lsl #16
   21b10:      	ldr	x1, [sp, x16, sxtx]
   21b14:      	str	x0, [x1, #0x10]
   21b18:      	mov	w0, #0xee80             ; =61056
   21b1c:      	movk	w0, #0x2, lsl #16
   21b20:      	mov	w16, #0x9bd0            ; =39888
   21b24:      	movk	w16, #0x1, lsl #16
   21b28:      	ldr	x1, [sp, x16, sxtx]
   21b2c:      	ldr	x0, [x1, x0]
   21b30:      	mov	w16, #0x9ba8            ; =39848
   21b34:      	movk	w16, #0x1, lsl #16
   21b38:      	ldr	x1, [sp, x16, sxtx]
   21b3c:      	str	x0, [x1, #0x18]
   21b40:      	mov	x1, #0x31d              ; =797
   21b44:      	mov	x2, #-0x9               ; =-9
   21b48:      	mov	x0, #0x2                ; =2
   21b4c:      	mov	w16, #0x99e0            ; =39392
   21b50:      	movk	w16, #0x1, lsl #16
   21b54:      	ldr	x4, [sp, x16, sxtx]
   21b58:      	mov	w16, #0x9bb8            ; =39864
   21b5c:      	movk	w16, #0x1, lsl #16
   21b60:      	ldr	x7, [sp, x16, sxtx]
   21b64:      	mov	w16, #0x3748            ; =14152
   21b68:      	movk	w16, #0x1, lsl #16
   21b6c:      	str	x0, [sp, x16, sxtx]
   21b70:      	mov	w16, #0x9bc8            ; =39880
   21b74:      	movk	w16, #0x1, lsl #16
   21b78:      	ldr	x0, [sp, x16, sxtx]
   21b7c:      	mov	w16, #0x3748            ; =14152
   21b80:      	movk	w16, #0x1, lsl #16
   21b84:      	ldr	x5, [sp, x16, sxtx]
   21b88:      	mov	w16, #0x9bb0            ; =39856
   21b8c:      	movk	w16, #0x1, lsl #16
   21b90:      	ldr	x6, [sp, x16, sxtx]
   21b94:      	blr	x7
   21b98:      	cmp	x0, #0x0
   21b9c:      	b.ne	0xf3aa8 <_mech_canonical_program_entry_v1+0xf3aa8>
   21ba0:      	mov	x0, #0x3                ; =3
   21ba4:      	mov	w16, #0x3748            ; =14152
   21ba8:      	movk	w16, #0x1, lsl #16
   21bac:      	str	x0, [sp, x16, sxtx]
   21bb0:      	mov	w16, #0x9ba0            ; =39840
   21bb4:      	movk	w16, #0x1, lsl #16
   21bb8:      	ldr	x0, [sp, x16, sxtx]
   21bbc:      	cmp	x0, #0x2
   21bc0:      	b.lo	0xf3aac <_mech_canonical_program_entry_v1+0xf3aac>
   21bc4:      	mov	x5, #0x0                ; =0
   21bc8:      	mov	w16, #0x9ba8            ; =39848
   21bcc:      	movk	w16, #0x1, lsl #16
   21bd0:      	ldr	x0, [sp, x16, sxtx]
   21bd4:      	str	x5, [x0]
   21bd8:      	mov	w16, #0x9bd0            ; =39888
   21bdc:      	movk	w16, #0x1, lsl #16
   21be0:      	ldr	x0, [sp, x16, sxtx]
   21be4:      	ldr	x0, [x0, #0x1b00]
   21be8:      	mov	w16, #0x9ba8            ; =39848
   21bec:      	movk	w16, #0x1, lsl #16
   21bf0:      	ldr	x13, [sp, x16, sxtx]
   21bf4:      	str	x0, [x13, #0x8]
   21bf8:      	mov	x1, #0x31d              ; =797
   21bfc:      	mov	x0, #0x2                ; =2
   21c00:      	mov	w16, #0x9bb8            ; =39864
   21c04:      	movk	w16, #0x1, lsl #16
   21c08:      	ldr	x7, [sp, x16, sxtx]
   21c0c:      	mov	w16, #0x3748            ; =14152
   21c10:      	movk	w16, #0x1, lsl #16
   21c14:      	str	x0, [sp, x16, sxtx]
   21c18:      	mov	w16, #0x9bc8            ; =39880
   21c1c:      	movk	w16, #0x1, lsl #16
   21c20:      	ldr	x0, [sp, x16, sxtx]
   21c24:      	mov	w16, #0x9ba8            ; =39848
   21c28:      	movk	w16, #0x1, lsl #16
   21c2c:      	ldr	x3, [sp, x16, sxtx]
   21c30:      	mov	w16, #0x3748            ; =14152
   21c34:      	movk	w16, #0x1, lsl #16
   21c38:      	ldr	x4, [sp, x16, sxtx]
   21c3c:      	mov	w16, #0x9bb0            ; =39856
   21c40:      	movk	w16, #0x1, lsl #16
   21c44:      	ldr	x6, [sp, x16, sxtx]
   21c48:      	mov	x2, x5
   21c4c:      	blr	x7
   21c50:      	cmp	x0, #0x0
   21c54:      	b.ne	0xf3ab0 <_mech_canonical_program_entry_v1+0xf3ab0>
   21c58:      	mov	x0, #0x3                ; =3
   21c5c:      	mov	w16, #0x3748            ; =14152
   21c60:      	movk	w16, #0x1, lsl #16
   21c64:      	str	x0, [sp, x16, sxtx]
   21c68:      	ldur	x0, [sp]
   21c6c:      	b	0xc790f4 <_mech_canonical_program_entry_v1+0xc790f4>
   21c70:      	mov	w16, #0x99e0            ; =39392
   21c74:      	movk	w16, #0x1, lsl #16
   21c78:      	ldr	x4, [sp, x16, sxtx]
   21c7c:      	ldrb	w12, [x26, x20]
   21c80:      	uxtb	w15, w12
   21c84:      	mov	x12, x15
   21c88:      	mov	x14, x15
   21c8c:      	mov	x20, x22
   21c90:      	mov	x28, x8
   21c94:      	adds	x22, x28, x15
   21c98:      	cset	x23, hs
   21c9c:      	uxtb	w23, w23
   21ca0:      	cmp	w23, #0x0
   21ca4:      	b.ne	0xf3af8 <_mech_canonical_program_entry_v1+0xf3af8>
   21ca8:      	mov	x0, #0x6d30             ; =27952
   21cac:      	sub	x19, x19, x0
   21cb0:      	uxtb	w27, w27
   21cb4:      	uxtb	w21, w21
   21cb8:      	mov	w16, #0x99e8            ; =39400
   21cbc:      	movk	w16, #0x1, lsl #16
   21cc0:      	str	x3, [sp, x16, sxtx]
   21cc4:      	mov	w16, #0x99e0            ; =39392
   21cc8:      	movk	w16, #0x1, lsl #16
   21ccc:      	str	x4, [sp, x16, sxtx]
   21cd0:      	str	x22, [sp, #0x320]
   21cd4:      	str	x1, [sp, #0x318]
   21cd8:      	mov	x23, x1
   21cdc:      	mov	x11, x22
   21ce0:      	mov	x9, x22
   21ce4:      	mov	x8, x22
   21ce8:      	mov	x22, x2
   21cec:      	mov	x6, x1
   21cf0:      	mov	x0, x7
   21cf4:      	mov	x7, x1
   21cf8:      	mov	w16, #0x99d8            ; =39384
   21cfc:      	movk	w16, #0x1, lsl #16
   21d00:      	ldr	x1, [sp, x16, sxtx]
   21d04:      	b	0x1f0b0 <_mech_canonical_program_entry_v1+0x1f0b0>
   21d08:      	str	x2, [sp, #0x308]
   21d0c:      	ldr	x21, [sp, #0x2e8]
   21d10:      	mov	w16, #0x99f0            ; =39408
   21d14:      	movk	w16, #0x1, lsl #16
   21d18:      	ldr	x14, [sp, x16, sxtx]
   21d1c:      	ldr	x13, [sp, #0x2f0]
   21d20:      	mov	x12, x19
   21d24:      	ldr	x11, [sp, #0x2b8]
   21d28:      	ldr	x10, [sp, #0x2c8]
   21d2c:      	ldr	x5, [sp, #0x2d0]
   21d30:      	ldr	x2, [sp, #0x2d8]
   21d34:      	ldr	x0, [sp, #0x2e0]
   21d38:      	mov	x19, #0x1               ; =1
   21d3c:      	adds	x26, x28, x19
   21d40:      	cset	x19, hs
   21d44:      	uxtb	w19, w19
   21d48:      	cmp	w19, #0x0
   21d4c:      	b.ne	0xf3b40 <_mech_canonical_program_entry_v1+0xf3b40>
   21d50:      	mov	w16, #0x9a08            ; =39432
   21d54:      	movk	w16, #0x1, lsl #16
   21d58:      	ldr	x0, [sp, x16, sxtx]
   21d5c:      	mov	w16, #0x9a10            ; =39440
   21d60:      	movk	w16, #0x1, lsl #16
   21d64:      	ldr	x12, [sp, x16, sxtx]
   21d68:      	uxtb	w13, w14
   21d6c:      	uxtb	w8, w8
   21d70:      	str	x26, [sp, #0x2f0]
   21d74:      	str	x23, [sp, #0x2e8]
   21d78:      	str	x27, [sp, #0x2e0]
   21d7c:      	str	x26, [sp, #0x2d8]
   21d80:      	str	x27, [sp, #0x2c8]
   21d84:      	str	x24, [sp, #0x2c0]
   21d88:      	str	x22, [sp, #0x2b0]

