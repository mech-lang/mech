; Helper site argument anchors; manually verify matching source action.
; Anchor 0x1b270
   1b0e0:      	cmp	x1, #0x0
   1b0e4:      	b.ne	0x1b120 <_mech_canonical_program_entry_v1+0x1b120>
   1b0e8:      	mov	x1, #0x321              ; =801
   1b0ec:      	mov	w16, #0xa2c8            ; =41672
   1b0f0:      	movk	w16, #0x1, lsl #16
   1b0f4:      	ldr	x2, [sp, x16, sxtx]
   1b0f8:      	mov	w16, #0xa2d0            ; =41680
   1b0fc:      	movk	w16, #0x1, lsl #16
   1b100:      	ldr	x0, [sp, x16, sxtx]
   1b104:      	blr	x2
   1b108:      	mov	x6, #0x2                ; =2
   1b10c:      	mov	w16, #0x3698            ; =13976
   1b110:      	movk	w16, #0x1, lsl #16
   1b114:      	str	x6, [sp, x16, sxtx]
   1b118:      	cmp	x0, #0x0
   1b11c:      	b.ne	0xe7e60 <_mech_canonical_program_entry_v1+0xe7e60>
   1b120:      	ldur	x19, [sp]
   1b124:      	mov	x7, #0x322              ; =802
   1b128:      	ldur	x0, [sp, #0x8]
   1b12c:      	str	x7, [x0, #0x48]
   1b130:      	mov	w7, #0xd870             ; =55408
   1b134:      	movk	w7, #0x2, lsl #16
   1b138:      	ldr	x10, [x19, x7]
   1b13c:      	cmp	x10, #0x0
   1b140:      	b.ne	0x1b17c <_mech_canonical_program_entry_v1+0x1b17c>
   1b144:      	mov	x1, #0x322              ; =802
   1b148:      	mov	w16, #0xa2c8            ; =41672
   1b14c:      	movk	w16, #0x1, lsl #16
   1b150:      	ldr	x2, [sp, x16, sxtx]
   1b154:      	mov	w16, #0xa2d0            ; =41680
   1b158:      	movk	w16, #0x1, lsl #16
   1b15c:      	ldr	x0, [sp, x16, sxtx]
   1b160:      	blr	x2
   1b164:      	mov	x1, #0x2                ; =2
   1b168:      	mov	w16, #0x3698            ; =13976
   1b16c:      	movk	w16, #0x1, lsl #16
   1b170:      	str	x1, [sp, x16, sxtx]
   1b174:      	cmp	x0, #0x0
   1b178:      	b.ne	0xe7e84 <_mech_canonical_program_entry_v1+0xe7e84>
   1b17c:      	ldr	x15, [x19, #0x218]
   1b180:      	str	x15, [x19, #0x1af8]
   1b184:      	b	0x1b448 <_mech_canonical_program_entry_v1+0x1b448>
   1b188:      	ldur	x0, [sp]
   1b18c:      	mov	x1, #0x31b              ; =795
   1b190:      	ldur	x7, [sp, #0x8]
   1b194:      	str	x1, [x7, #0x48]
   1b198:      	mov	w1, #0xd870             ; =55408
   1b19c:      	movk	w1, #0x2, lsl #16
   1b1a0:      	ldr	x0, [x0, x1]
   1b1a4:      	cmp	x0, #0x0
   1b1a8:      	b.ne	0x1b1e4 <_mech_canonical_program_entry_v1+0x1b1e4>
   1b1ac:      	mov	x1, #0x31b              ; =795
   1b1b0:      	mov	w16, #0xa2c8            ; =41672
   1b1b4:      	movk	w16, #0x1, lsl #16
   1b1b8:      	ldr	x13, [sp, x16, sxtx]
   1b1bc:      	mov	w16, #0xa2d0            ; =41680
   1b1c0:      	movk	w16, #0x1, lsl #16
   1b1c4:      	ldr	x0, [sp, x16, sxtx]
   1b1c8:      	blr	x13
   1b1cc:      	mov	x1, #0x2                ; =2
   1b1d0:      	mov	w16, #0x3698            ; =13976
   1b1d4:      	movk	w16, #0x1, lsl #16
   1b1d8:      	str	x1, [sp, x16, sxtx]
   1b1dc:      	cmp	x0, #0x0
   1b1e0:      	b.ne	0xe7eb0 <_mech_canonical_program_entry_v1+0xe7eb0>
   1b1e4:      	ldur	x26, [sp]
   1b1e8:      	mov	x1, #0x31c              ; =796
   1b1ec:      	ldur	x0, [sp, #0x8]
   1b1f0:      	str	x1, [x0, #0x48]
   1b1f4:      	mov	w0, #0xd870             ; =55408
   1b1f8:      	movk	w0, #0x2, lsl #16
   1b1fc:      	ldr	x0, [x26, x0]
   1b200:      	cmp	x0, #0x0
   1b204:      	b.ne	0x1b23c <_mech_canonical_program_entry_v1+0x1b23c>
   1b208:      	mov	w16, #0xa2c8            ; =41672
   1b20c:      	movk	w16, #0x1, lsl #16
   1b210:      	ldr	x2, [sp, x16, sxtx]
   1b214:      	mov	w16, #0xa2d0            ; =41680
   1b218:      	movk	w16, #0x1, lsl #16
   1b21c:      	ldr	x0, [sp, x16, sxtx]
   1b220:      	blr	x2
   1b224:      	mov	x1, #0x2                ; =2
   1b228:      	mov	w16, #0x3698            ; =13976
   1b22c:      	movk	w16, #0x1, lsl #16
   1b230:      	str	x1, [sp, x16, sxtx]
   1b234:      	cmp	x0, #0x0
   1b238:      	b.ne	0xe7f08 <_mech_canonical_program_entry_v1+0xe7f08>
   1b23c:      	ldr	x0, [x26, #0x1ac0]
   1b240:      	ldr	x1, [x26, #0x278]
   1b244:      	adds	x0, x0, x1
   1b248:      	cset	x1, hs
   1b24c:      	mov	x9, #0x1                ; =1
   1b250:      	mov	w16, #0x3698            ; =13976
   1b254:      	movk	w16, #0x1, lsl #16
   1b258:      	str	x9, [sp, x16, sxtx]
   1b25c:      	uxtb	w1, w1
   1b260:      	cmp	w1, #0x0
   1b264:      	b.ne	0xe7f0c <_mech_canonical_program_entry_v1+0xe7f0c>
   1b268:      	str	x0, [x26, #0x1b00]
   1b26c:      	ldur	x19, [sp]
   1b270:      	mov	x1, #0x31d              ; =797
   1b274:      	ldur	x0, [sp, #0x8]
   1b278:      	str	x1, [x0, #0x48]
   1b27c:      	mov	x21, x1
   1b280:      	mov	w0, #0xd870             ; =55408
   1b284:      	movk	w0, #0x2, lsl #16
   1b288:      	ldr	x0, [x19, x0]
   1b28c:      	cmp	x0, #0x0
   1b290:      	b.ne	0x1b2cc <_mech_canonical_program_entry_v1+0x1b2cc>
   1b294:      	mov	w16, #0xa2c8            ; =41672
   1b298:      	movk	w16, #0x1, lsl #16
   1b29c:      	ldr	x2, [sp, x16, sxtx]
   1b2a0:      	mov	w16, #0xa2d0            ; =41680
   1b2a4:      	movk	w16, #0x1, lsl #16
   1b2a8:      	ldr	x0, [sp, x16, sxtx]
   1b2ac:      	mov	x1, x21
   1b2b0:      	blr	x2
   1b2b4:      	mov	x1, #0x2                ; =2
   1b2b8:      	mov	w16, #0x3698            ; =13976
   1b2bc:      	movk	w16, #0x1, lsl #16
   1b2c0:      	str	x1, [sp, x16, sxtx]
   1b2c4:      	cmp	x0, #0x0
   1b2c8:      	b.ne	0xe7f70 <_mech_canonical_program_entry_v1+0xe7f70>
   1b2cc:      	mov	x0, #0x3                ; =3
   1b2d0:      	mov	w16, #0x3698            ; =13976
   1b2d4:      	movk	w16, #0x1, lsl #16
   1b2d8:      	str	x0, [sp, x16, sxtx]
   1b2dc:      	mov	w16, #0xa2a8            ; =41640
   1b2e0:      	movk	w16, #0x1, lsl #16
   1b2e4:      	ldr	x0, [sp, x16, sxtx]
   1b2e8:      	cmp	x0, #0x2
   1b2ec:      	b.lo	0xe7f74 <_mech_canonical_program_entry_v1+0xe7f74>
   1b2f0:      	mov	x5, #0x0                ; =0
   1b2f4:      	mov	w16, #0xa2b0            ; =41648
   1b2f8:      	movk	w16, #0x1, lsl #16
   1b2fc:      	ldr	x12, [sp, x16, sxtx]
   1b300:      	str	x5, [x12]
   1b304:      	ldr	x0, [x19, #0x1b00]
   1b308:      	str	x0, [x12, #0x8]
   1b30c:      	mov	x0, #0x2                ; =2
   1b310:      	mov	x1, x21
   1b314:      	mov	w16, #0xa2c0            ; =41664
   1b318:      	movk	w16, #0x1, lsl #16
   1b31c:      	ldr	x12, [sp, x16, sxtx]
   1b320:      	mov	w16, #0x3698            ; =13976
   1b324:      	movk	w16, #0x1, lsl #16
   1b328:      	str	x0, [sp, x16, sxtx]
   1b32c:      	mov	w16, #0xa2d0            ; =41680
   1b330:      	movk	w16, #0x1, lsl #16
   1b334:      	ldr	x0, [sp, x16, sxtx]
   1b338:      	mov	w16, #0xa2b0            ; =41648
   1b33c:      	movk	w16, #0x1, lsl #16
   1b340:      	ldr	x3, [sp, x16, sxtx]
   1b344:      	mov	w16, #0x3698            ; =13976
   1b348:      	movk	w16, #0x1, lsl #16
   1b34c:      	ldr	x4, [sp, x16, sxtx]
   1b350:      	mov	w16, #0xa2b8            ; =41656
   1b354:      	movk	w16, #0x1, lsl #16
   1b358:      	ldr	x6, [sp, x16, sxtx]
   1b35c:      	mov	x2, x5
   1b360:      	blr	x12
   1b364:      	cmp	x0, #0x0
   1b368:      	b.ne	0xe7fa8 <_mech_canonical_program_entry_v1+0xe7fa8>
   1b36c:      	mov	w16, #0xa2b8            ; =41656
   1b370:      	movk	w16, #0x1, lsl #16
   1b374:      	ldr	x6, [sp, x16, sxtx]
   1b378:      	ldr	x0, [x6]
   1b37c:      	str	x0, [x19, #0x1b08]
   1b380:      	ldur	x19, [sp]
   1b384:      	mov	x0, #0x31e              ; =798
   1b388:      	ldur	x1, [sp, #0x8]
   1b38c:      	str	x0, [x1, #0x48]
   1b390:      	mov	w0, #0xd870             ; =55408
   1b394:      	movk	w0, #0x2, lsl #16
   1b398:      	ldr	x0, [x19, x0]
   1b39c:      	cmp	x0, #0x0
   1b3a0:      	b.ne	0x1b3dc <_mech_canonical_program_entry_v1+0x1b3dc>
   1b3a4:      	mov	x1, #0x31e              ; =798
   1b3a8:      	mov	w16, #0xa2c8            ; =41672
   1b3ac:      	movk	w16, #0x1, lsl #16
   1b3b0:      	ldr	x2, [sp, x16, sxtx]
   1b3b4:      	mov	w16, #0xa2d0            ; =41680
   1b3b8:      	movk	w16, #0x1, lsl #16
   1b3bc:      	ldr	x0, [sp, x16, sxtx]
   1b3c0:      	blr	x2
   1b3c4:      	mov	x1, #0x2                ; =2
   1b3c8:      	mov	w16, #0x3698            ; =13976
   1b3cc:      	movk	w16, #0x1, lsl #16
   1b3d0:      	str	x1, [sp, x16, sxtx]
   1b3d4:      	cmp	x0, #0x0
   1b3d8:      	b.ne	0xe8010 <_mech_canonical_program_entry_v1+0xe8010>
   1b3dc:      	ldr	x2, [x19, #0x1b08]
   1b3e0:      	str	x2, [x19, #0x1b10]
   1b3e4:      	ldur	x19, [sp]
   1b3e8:      	mov	x4, #0x31f              ; =799
   1b3ec:      	ldur	x0, [sp, #0x8]
   1b3f0:      	str	x4, [x0, #0x48]
   1b3f4:      	mov	w4, #0xd870             ; =55408
   1b3f8:      	movk	w4, #0x2, lsl #16
   1b3fc:      	ldr	x7, [x19, x4]
   1b400:      	cmp	x7, #0x0

; Anchor 0x1c528
   1c398:      	ldr	x2, [sp, x16, sxtx]
   1c39c:      	mov	w16, #0xa2d0            ; =41680
   1c3a0:      	movk	w16, #0x1, lsl #16
   1c3a4:      	ldr	x0, [sp, x16, sxtx]
   1c3a8:      	blr	x2
   1c3ac:      	mov	x1, #0x2                ; =2
   1c3b0:      	mov	w16, #0x3698            ; =13976
   1c3b4:      	movk	w16, #0x1, lsl #16
   1c3b8:      	str	x1, [sp, x16, sxtx]
   1c3bc:      	cmp	x0, #0x0
   1c3c0:      	b.ne	0xe8c0c <_mech_canonical_program_entry_v1+0xe8c0c>
   1c3c4:      	ldur	x19, [sp]
   1c3c8:      	mov	x0, #0x341              ; =833
   1c3cc:      	ldur	x8, [sp, #0x8]
   1c3d0:      	str	x0, [x8, #0x48]
   1c3d4:      	mov	w16, #0xa2b8            ; =41656
   1c3d8:      	movk	w16, #0x1, lsl #16
   1c3dc:      	ldr	x6, [sp, x16, sxtx]
   1c3e0:      	ldr	x0, [x6]
   1c3e4:      	cmp	x0, #0x0
   1c3e8:      	b.ne	0x1c424 <_mech_canonical_program_entry_v1+0x1c424>
   1c3ec:      	mov	x1, #0x341              ; =833
   1c3f0:      	mov	w16, #0xa2c8            ; =41672
   1c3f4:      	movk	w16, #0x1, lsl #16
   1c3f8:      	ldr	x12, [sp, x16, sxtx]
   1c3fc:      	mov	w16, #0xa2d0            ; =41680
   1c400:      	movk	w16, #0x1, lsl #16
   1c404:      	ldr	x0, [sp, x16, sxtx]
   1c408:      	blr	x12
   1c40c:      	mov	x1, #0x2                ; =2
   1c410:      	mov	w16, #0x3698            ; =13976
   1c414:      	movk	w16, #0x1, lsl #16
   1c418:      	str	x1, [sp, x16, sxtx]
   1c41c:      	cmp	x0, #0x0
   1c420:      	b.ne	0xe8c10 <_mech_canonical_program_entry_v1+0xe8c10>
   1c424:      	ldr	x0, [x19, #0x1b30]
   1c428:      	str	x0, [x19, #0x1990]
   1c42c:      	b	0x1c880 <_mech_canonical_program_entry_v1+0x1c880>
   1c430:      	mov	w16, #0xa0c8            ; =41160
   1c434:      	movk	w16, #0x1, lsl #16
   1c438:      	str	x1, [sp, x16, sxtx]
   1c43c:      	mov	x0, #0x1                ; =1
   1c440:      	adds	x0, x9, x0
   1c444:      	mov	w16, #0xa0c0            ; =41152
   1c448:      	movk	w16, #0x1, lsl #16
   1c44c:      	str	x0, [sp, x16, sxtx]
   1c450:      	cset	x0, hs
   1c454:      	uxtb	w0, w0
   1c458:      	cmp	w0, #0x0
   1c45c:      	b.ne	0xe8c88 <_mech_canonical_program_entry_v1+0xe8c88>
   1c460:      	cmp	x9, x2
   1c464:      	cset	x24, lo
   1c468:      	cmp	x9, x2
   1c46c:      	b.lo	0x1c4a0 <_mech_canonical_program_entry_v1+0x1c4a0>
   1c470:      	cmp	x9, x2
   1c474:      	b.lo	0xe8c8c <_mech_canonical_program_entry_v1+0xe8c8c>
   1c478:      	mov	x15, #0x0               ; =0
   1c47c:      	mov	x0, x10
   1c480:      	mov	x1, x6
   1c484:      	mov	w16, #0xa0e0            ; =41184
   1c488:      	movk	w16, #0x1, lsl #16
   1c48c:      	ldr	x4, [sp, x16, sxtx]
   1c490:      	mov	w16, #0xa0c0            ; =41152
   1c494:      	movk	w16, #0x1, lsl #16
   1c498:      	ldr	x25, [sp, x16, sxtx]
   1c49c:      	b	0x1c674 <_mech_canonical_program_entry_v1+0x1c674>
   1c4a0:      	mov	x0, #0x1                ; =1
   1c4a4:      	adds	x0, x9, x0
   1c4a8:      	cset	x1, hs
   1c4ac:      	uxtb	w1, w1
   1c4b0:      	cmp	w1, #0x0
   1c4b4:      	b.ne	0xe8c90 <_mech_canonical_program_entry_v1+0xe8c90>
   1c4b8:      	sub	x20, x0, #0x1
   1c4bc:      	cmp	x20, x2
   1c4c0:      	b.lo	0x1c640 <_mech_canonical_program_entry_v1+0x1c640>
   1c4c4:      	b	0x8138fc <_mech_canonical_program_entry_v1+0x8138fc>
   1c4c8:      	mov	x0, #0x0                ; =0
   1c4cc:      	mov	w1, #0xd870             ; =55408
   1c4d0:      	movk	w1, #0x2, lsl #16
   1c4d4:      	str	x0, [x19, x1]
   1c4d8:      	mov	x0, #0x3                ; =3
   1c4dc:      	mov	w16, #0x3698            ; =13976
   1c4e0:      	movk	w16, #0x1, lsl #16
   1c4e4:      	str	x0, [sp, x16, sxtx]
   1c4e8:      	mov	w16, #0xa2a8            ; =41640
   1c4ec:      	movk	w16, #0x1, lsl #16
   1c4f0:      	ldr	x0, [sp, x16, sxtx]
   1c4f4:      	cmp	x0, #0xc
   1c4f8:      	b.lo	0xe8c94 <_mech_canonical_program_entry_v1+0xe8c94>
   1c4fc:      	mov	w0, #0xee78             ; =61048
   1c500:      	movk	w0, #0x2, lsl #16
   1c504:      	ldr	x0, [x19, x0]
   1c508:      	mov	w16, #0xa2b0            ; =41648
   1c50c:      	movk	w16, #0x1, lsl #16
   1c510:      	ldr	x12, [sp, x16, sxtx]
   1c514:      	str	x0, [x12, #0x10]
   1c518:      	mov	w0, #0xee80             ; =61056
   1c51c:      	movk	w0, #0x2, lsl #16
   1c520:      	ldr	x0, [x19, x0]
   1c524:      	str	x0, [x12, #0x18]
   1c528:      	mov	x1, #0x31d              ; =797
   1c52c:      	mov	x2, #-0x9               ; =-9
   1c530:      	mov	x0, #0x2                ; =2
   1c534:      	mov	w16, #0xa0e0            ; =41184
   1c538:      	movk	w16, #0x1, lsl #16
   1c53c:      	ldr	x4, [sp, x16, sxtx]
   1c540:      	mov	w16, #0xa2c0            ; =41664
   1c544:      	movk	w16, #0x1, lsl #16
   1c548:      	ldr	x12, [sp, x16, sxtx]
   1c54c:      	mov	w16, #0x3698            ; =13976
   1c550:      	movk	w16, #0x1, lsl #16
   1c554:      	str	x0, [sp, x16, sxtx]
   1c558:      	mov	w16, #0xa2d0            ; =41680
   1c55c:      	movk	w16, #0x1, lsl #16
   1c560:      	ldr	x0, [sp, x16, sxtx]
   1c564:      	mov	w16, #0x3698            ; =13976
   1c568:      	movk	w16, #0x1, lsl #16
   1c56c:      	ldr	x5, [sp, x16, sxtx]
   1c570:      	mov	w16, #0xa2b8            ; =41656
   1c574:      	movk	w16, #0x1, lsl #16
   1c578:      	ldr	x6, [sp, x16, sxtx]
   1c57c:      	blr	x12
   1c580:      	cmp	x0, #0x0
   1c584:      	b.ne	0xe8d10 <_mech_canonical_program_entry_v1+0xe8d10>
   1c588:      	mov	x0, #0x3                ; =3
   1c58c:      	mov	w16, #0x3698            ; =13976
   1c590:      	movk	w16, #0x1, lsl #16
   1c594:      	str	x0, [sp, x16, sxtx]
   1c598:      	mov	w16, #0xa2a8            ; =41640
   1c59c:      	movk	w16, #0x1, lsl #16
   1c5a0:      	ldr	x0, [sp, x16, sxtx]
   1c5a4:      	cmp	x0, #0x2
   1c5a8:      	b.lo	0xe8d14 <_mech_canonical_program_entry_v1+0xe8d14>
   1c5ac:      	mov	x5, #0x0                ; =0
   1c5b0:      	mov	w16, #0xa2b0            ; =41648
   1c5b4:      	movk	w16, #0x1, lsl #16
   1c5b8:      	ldr	x12, [sp, x16, sxtx]
   1c5bc:      	str	x5, [x12]
   1c5c0:      	ldr	x0, [x19, #0x1b00]
   1c5c4:      	str	x0, [x12, #0x8]
   1c5c8:      	mov	x1, #0x31d              ; =797
   1c5cc:      	mov	x0, #0x2                ; =2
   1c5d0:      	mov	w16, #0xa2c0            ; =41664
   1c5d4:      	movk	w16, #0x1, lsl #16
   1c5d8:      	ldr	x12, [sp, x16, sxtx]
   1c5dc:      	mov	w16, #0x3698            ; =13976
   1c5e0:      	movk	w16, #0x1, lsl #16
   1c5e4:      	str	x0, [sp, x16, sxtx]
   1c5e8:      	mov	w16, #0xa2d0            ; =41680
   1c5ec:      	movk	w16, #0x1, lsl #16
   1c5f0:      	ldr	x0, [sp, x16, sxtx]
   1c5f4:      	mov	w16, #0xa2b0            ; =41648
   1c5f8:      	movk	w16, #0x1, lsl #16
   1c5fc:      	ldr	x3, [sp, x16, sxtx]
   1c600:      	mov	w16, #0x3698            ; =13976
   1c604:      	movk	w16, #0x1, lsl #16
   1c608:      	ldr	x4, [sp, x16, sxtx]
   1c60c:      	mov	w16, #0xa2b8            ; =41656
   1c610:      	movk	w16, #0x1, lsl #16
   1c614:      	ldr	x6, [sp, x16, sxtx]
   1c618:      	mov	x2, x5
   1c61c:      	blr	x12
   1c620:      	cmp	x0, #0x0
   1c624:      	b.ne	0xe8d78 <_mech_canonical_program_entry_v1+0xe8d78>
   1c628:      	mov	x0, #0x3                ; =3
   1c62c:      	mov	w16, #0x3698            ; =13976
   1c630:      	movk	w16, #0x1, lsl #16
   1c634:      	str	x0, [sp, x16, sxtx]
   1c638:      	ldur	x0, [sp, #0x8]
   1c63c:      	b	0xb400b0 <_mech_canonical_program_entry_v1+0xb400b0>
   1c640:      	mov	x1, x6
   1c644:      	mov	w16, #0xa0e0            ; =41184
   1c648:      	movk	w16, #0x1, lsl #16
   1c64c:      	ldr	x4, [sp, x16, sxtx]
   1c650:      	mov	w16, #0xa0c0            ; =41152
   1c654:      	movk	w16, #0x1, lsl #16
   1c658:      	ldr	x25, [sp, x16, sxtx]
   1c65c:      	ldrb	w13, [x7, x20]
   1c660:      	uxtb	w15, w13
   1c664:      	mov	x20, x0
   1c668:      	mov	x14, x15
   1c66c:      	mov	x13, x15
   1c670:      	mov	x0, x10
   1c674:      	adds	x26, x0, x15
   1c678:      	cset	x6, hs
   1c67c:      	uxtb	w6, w6
   1c680:      	cmp	w6, #0x0
   1c684:      	b.ne	0xe8de8 <_mech_canonical_program_entry_v1+0xe8de8>
   1c688:      	mov	x1, #0x6d30             ; =27952
   1c68c:      	sub	x28, x28, x1
   1c690:      	uxtb	w27, w27
   1c694:      	uxtb	w24, w24
   1c698:      	mov	w16, #0xa0e8            ; =41192
   1c69c:      	movk	w16, #0x1, lsl #16
   1c6a0:      	str	x3, [sp, x16, sxtx]
   1c6a4:      	mov	w16, #0xa0e0            ; =41184
   1c6a8:      	movk	w16, #0x1, lsl #16
   1c6ac:      	str	x4, [sp, x16, sxtx]
   1c6b0:      	mov	w16, #0xa0d8            ; =41176
   1c6b4:      	movk	w16, #0x1, lsl #16
   1c6b8:      	str	x7, [sp, x16, sxtx]

; Anchor 0x1c5c8
   1c438:      	str	x1, [sp, x16, sxtx]
   1c43c:      	mov	x0, #0x1                ; =1
   1c440:      	adds	x0, x9, x0
   1c444:      	mov	w16, #0xa0c0            ; =41152
   1c448:      	movk	w16, #0x1, lsl #16
   1c44c:      	str	x0, [sp, x16, sxtx]
   1c450:      	cset	x0, hs
   1c454:      	uxtb	w0, w0
   1c458:      	cmp	w0, #0x0
   1c45c:      	b.ne	0xe8c88 <_mech_canonical_program_entry_v1+0xe8c88>
   1c460:      	cmp	x9, x2
   1c464:      	cset	x24, lo
   1c468:      	cmp	x9, x2
   1c46c:      	b.lo	0x1c4a0 <_mech_canonical_program_entry_v1+0x1c4a0>
   1c470:      	cmp	x9, x2
   1c474:      	b.lo	0xe8c8c <_mech_canonical_program_entry_v1+0xe8c8c>
   1c478:      	mov	x15, #0x0               ; =0
   1c47c:      	mov	x0, x10
   1c480:      	mov	x1, x6
   1c484:      	mov	w16, #0xa0e0            ; =41184
   1c488:      	movk	w16, #0x1, lsl #16
   1c48c:      	ldr	x4, [sp, x16, sxtx]
   1c490:      	mov	w16, #0xa0c0            ; =41152
   1c494:      	movk	w16, #0x1, lsl #16
   1c498:      	ldr	x25, [sp, x16, sxtx]
   1c49c:      	b	0x1c674 <_mech_canonical_program_entry_v1+0x1c674>
   1c4a0:      	mov	x0, #0x1                ; =1
   1c4a4:      	adds	x0, x9, x0
   1c4a8:      	cset	x1, hs
   1c4ac:      	uxtb	w1, w1
   1c4b0:      	cmp	w1, #0x0
   1c4b4:      	b.ne	0xe8c90 <_mech_canonical_program_entry_v1+0xe8c90>
   1c4b8:      	sub	x20, x0, #0x1
   1c4bc:      	cmp	x20, x2
   1c4c0:      	b.lo	0x1c640 <_mech_canonical_program_entry_v1+0x1c640>
   1c4c4:      	b	0x8138fc <_mech_canonical_program_entry_v1+0x8138fc>
   1c4c8:      	mov	x0, #0x0                ; =0
   1c4cc:      	mov	w1, #0xd870             ; =55408
   1c4d0:      	movk	w1, #0x2, lsl #16
   1c4d4:      	str	x0, [x19, x1]
   1c4d8:      	mov	x0, #0x3                ; =3
   1c4dc:      	mov	w16, #0x3698            ; =13976
   1c4e0:      	movk	w16, #0x1, lsl #16
   1c4e4:      	str	x0, [sp, x16, sxtx]
   1c4e8:      	mov	w16, #0xa2a8            ; =41640
   1c4ec:      	movk	w16, #0x1, lsl #16
   1c4f0:      	ldr	x0, [sp, x16, sxtx]
   1c4f4:      	cmp	x0, #0xc
   1c4f8:      	b.lo	0xe8c94 <_mech_canonical_program_entry_v1+0xe8c94>
   1c4fc:      	mov	w0, #0xee78             ; =61048
   1c500:      	movk	w0, #0x2, lsl #16
   1c504:      	ldr	x0, [x19, x0]
   1c508:      	mov	w16, #0xa2b0            ; =41648
   1c50c:      	movk	w16, #0x1, lsl #16
   1c510:      	ldr	x12, [sp, x16, sxtx]
   1c514:      	str	x0, [x12, #0x10]
   1c518:      	mov	w0, #0xee80             ; =61056
   1c51c:      	movk	w0, #0x2, lsl #16
   1c520:      	ldr	x0, [x19, x0]
   1c524:      	str	x0, [x12, #0x18]
   1c528:      	mov	x1, #0x31d              ; =797
   1c52c:      	mov	x2, #-0x9               ; =-9
   1c530:      	mov	x0, #0x2                ; =2
   1c534:      	mov	w16, #0xa0e0            ; =41184
   1c538:      	movk	w16, #0x1, lsl #16
   1c53c:      	ldr	x4, [sp, x16, sxtx]
   1c540:      	mov	w16, #0xa2c0            ; =41664
   1c544:      	movk	w16, #0x1, lsl #16
   1c548:      	ldr	x12, [sp, x16, sxtx]
   1c54c:      	mov	w16, #0x3698            ; =13976
   1c550:      	movk	w16, #0x1, lsl #16
   1c554:      	str	x0, [sp, x16, sxtx]
   1c558:      	mov	w16, #0xa2d0            ; =41680
   1c55c:      	movk	w16, #0x1, lsl #16
   1c560:      	ldr	x0, [sp, x16, sxtx]
   1c564:      	mov	w16, #0x3698            ; =13976
   1c568:      	movk	w16, #0x1, lsl #16
   1c56c:      	ldr	x5, [sp, x16, sxtx]
   1c570:      	mov	w16, #0xa2b8            ; =41656
   1c574:      	movk	w16, #0x1, lsl #16
   1c578:      	ldr	x6, [sp, x16, sxtx]
   1c57c:      	blr	x12
   1c580:      	cmp	x0, #0x0
   1c584:      	b.ne	0xe8d10 <_mech_canonical_program_entry_v1+0xe8d10>
   1c588:      	mov	x0, #0x3                ; =3
   1c58c:      	mov	w16, #0x3698            ; =13976
   1c590:      	movk	w16, #0x1, lsl #16
   1c594:      	str	x0, [sp, x16, sxtx]
   1c598:      	mov	w16, #0xa2a8            ; =41640
   1c59c:      	movk	w16, #0x1, lsl #16
   1c5a0:      	ldr	x0, [sp, x16, sxtx]
   1c5a4:      	cmp	x0, #0x2
   1c5a8:      	b.lo	0xe8d14 <_mech_canonical_program_entry_v1+0xe8d14>
   1c5ac:      	mov	x5, #0x0                ; =0
   1c5b0:      	mov	w16, #0xa2b0            ; =41648
   1c5b4:      	movk	w16, #0x1, lsl #16
   1c5b8:      	ldr	x12, [sp, x16, sxtx]
   1c5bc:      	str	x5, [x12]
   1c5c0:      	ldr	x0, [x19, #0x1b00]
   1c5c4:      	str	x0, [x12, #0x8]
   1c5c8:      	mov	x1, #0x31d              ; =797
   1c5cc:      	mov	x0, #0x2                ; =2
   1c5d0:      	mov	w16, #0xa2c0            ; =41664
   1c5d4:      	movk	w16, #0x1, lsl #16
   1c5d8:      	ldr	x12, [sp, x16, sxtx]
   1c5dc:      	mov	w16, #0x3698            ; =13976
   1c5e0:      	movk	w16, #0x1, lsl #16
   1c5e4:      	str	x0, [sp, x16, sxtx]
   1c5e8:      	mov	w16, #0xa2d0            ; =41680
   1c5ec:      	movk	w16, #0x1, lsl #16
   1c5f0:      	ldr	x0, [sp, x16, sxtx]
   1c5f4:      	mov	w16, #0xa2b0            ; =41648
   1c5f8:      	movk	w16, #0x1, lsl #16
   1c5fc:      	ldr	x3, [sp, x16, sxtx]
   1c600:      	mov	w16, #0x3698            ; =13976
   1c604:      	movk	w16, #0x1, lsl #16
   1c608:      	ldr	x4, [sp, x16, sxtx]
   1c60c:      	mov	w16, #0xa2b8            ; =41656
   1c610:      	movk	w16, #0x1, lsl #16
   1c614:      	ldr	x6, [sp, x16, sxtx]
   1c618:      	mov	x2, x5
   1c61c:      	blr	x12
   1c620:      	cmp	x0, #0x0
   1c624:      	b.ne	0xe8d78 <_mech_canonical_program_entry_v1+0xe8d78>
   1c628:      	mov	x0, #0x3                ; =3
   1c62c:      	mov	w16, #0x3698            ; =13976
   1c630:      	movk	w16, #0x1, lsl #16
   1c634:      	str	x0, [sp, x16, sxtx]
   1c638:      	ldur	x0, [sp, #0x8]
   1c63c:      	b	0xb400b0 <_mech_canonical_program_entry_v1+0xb400b0>
   1c640:      	mov	x1, x6
   1c644:      	mov	w16, #0xa0e0            ; =41184
   1c648:      	movk	w16, #0x1, lsl #16
   1c64c:      	ldr	x4, [sp, x16, sxtx]
   1c650:      	mov	w16, #0xa0c0            ; =41152
   1c654:      	movk	w16, #0x1, lsl #16
   1c658:      	ldr	x25, [sp, x16, sxtx]
   1c65c:      	ldrb	w13, [x7, x20]
   1c660:      	uxtb	w15, w13
   1c664:      	mov	x20, x0
   1c668:      	mov	x14, x15
   1c66c:      	mov	x13, x15
   1c670:      	mov	x0, x10
   1c674:      	adds	x26, x0, x15
   1c678:      	cset	x6, hs
   1c67c:      	uxtb	w6, w6
   1c680:      	cmp	w6, #0x0
   1c684:      	b.ne	0xe8de8 <_mech_canonical_program_entry_v1+0xe8de8>
   1c688:      	mov	x1, #0x6d30             ; =27952
   1c68c:      	sub	x28, x28, x1
   1c690:      	uxtb	w27, w27
   1c694:      	uxtb	w24, w24
   1c698:      	mov	w16, #0xa0e8            ; =41192
   1c69c:      	movk	w16, #0x1, lsl #16
   1c6a0:      	str	x3, [sp, x16, sxtx]
   1c6a4:      	mov	w16, #0xa0e0            ; =41184
   1c6a8:      	movk	w16, #0x1, lsl #16
   1c6ac:      	str	x4, [sp, x16, sxtx]
   1c6b0:      	mov	w16, #0xa0d8            ; =41176
   1c6b4:      	movk	w16, #0x1, lsl #16
   1c6b8:      	str	x7, [sp, x16, sxtx]
   1c6bc:      	str	x26, [sp, #0x338]
   1c6c0:      	mov	x23, x25
   1c6c4:      	mov	x12, x26
   1c6c8:      	mov	x10, x26
   1c6cc:      	mov	x8, x26
   1c6d0:      	mov	x26, x25
   1c6d4:      	mov	x6, x25
   1c6d8:      	mov	x3, x9
   1c6dc:      	mov	x9, x25
   1c6e0:      	mov	x25, x2
   1c6e4:      	mov	w16, #0xa0d0            ; =41168
   1c6e8:      	movk	w16, #0x1, lsl #16
   1c6ec:      	ldr	x1, [sp, x16, sxtx]
   1c6f0:      	b	0x1a324 <_mech_canonical_program_entry_v1+0x1a324>
   1c6f4:      	str	x1, [sp, #0x330]
   1c6f8:      	ldr	x28, [sp, #0x318]
   1c6fc:      	mov	w16, #0xa0f0            ; =41200
   1c700:      	movk	w16, #0x1, lsl #16
   1c704:      	ldr	x14, [sp, x16, sxtx]
   1c708:      	ldr	x13, [sp, #0x2f8]
   1c70c:      	ldr	x12, [sp, #0x2f0]
   1c710:      	ldr	x10, [sp, #0x2d8]
   1c714:      	ldr	x7, [sp, #0x2e8]
   1c718:      	ldr	x5, [sp, #0x300]
   1c71c:      	ldr	x1, [sp, #0x308]
   1c720:      	ldr	x0, [sp, #0x310]
   1c724:      	mov	x15, #0x1               ; =1
   1c728:      	adds	x15, x26, x15
   1c72c:      	cset	x27, hs
   1c730:      	uxtb	w27, w27
   1c734:      	cmp	w27, #0x0
   1c738:      	b.ne	0xe8e4c <_mech_canonical_program_entry_v1+0xe8e4c>
   1c73c:      	mov	w16, #0xa110            ; =41232
   1c740:      	movk	w16, #0x1, lsl #16
   1c744:      	ldr	x7, [sp, x16, sxtx]
   1c748:      	mov	w16, #0xa108            ; =41224
   1c74c:      	movk	w16, #0x1, lsl #16
   1c750:      	ldr	x12, [sp, x16, sxtx]
   1c754:      	uxtb	w0, w14
   1c758:      	uxtb	w9, w9

