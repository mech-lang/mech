       0:      	pacibsp
       4:      	stp	x29, x30, [sp, #-0x10]!
       8:      	mov	x29, sp
       c:      	stp	x27, x28, [sp, #-0x10]!
      10:      	stp	x25, x26, [sp, #-0x10]!
      14:      	stp	x23, x24, [sp, #-0x10]!
      18:      	stp	x21, x22, [sp, #-0x10]!
      1c:      	stp	x19, x20, [sp, #-0x10]!
      20:      	mov	w16, #0xa2f0            ; =41712
      24:      	movk	w16, #0x1, lsl #16
      28:      	sub	sp, sp, x16
      2c:      	stur	x0, [sp, #0x8]
      30:      	mov	x15, #0x3               ; =3
      34:      	cmp	x0, #0x0
      38:      	b.eq	0xbf0e0 <_mech_canonical_program_entry_v1+0xbf0e0>
      3c:      	mov	x0, #-0x1               ; =-1
      40:      	ldur	x1, [sp, #0x8]
      44:      	str	x0, [x1, #0x48]
      48:      	ldur	x0, [sp, #0x8]
      4c:      	ldr	x1, [x0]
      50:      	mov	x15, #0x3               ; =3
      54:      	cmp	x1, #0x25
      58:      	b.ne	0xbf0e4 <_mech_canonical_program_entry_v1+0xbf0e4>
      5c:      	ldur	x0, [sp, #0x8]
      60:      	ldr	x1, [x0, #0x8]
      64:      	mov	x15, #0x3               ; =3
      68:      	cmp	x1, #0x2
      6c:      	b.ne	0xbf0e8 <_mech_canonical_program_entry_v1+0xbf0e8>
      70:      	ldur	x0, [sp, #0x8]
      74:      	ldr	x1, [x0, #0x10]
      78:      	mov	x15, #0x3               ; =3
      7c:      	mov	x0, #0x5e0c             ; =24076
      80:      	cmp	x1, x0
      84:      	b.ne	0xbf0ec <_mech_canonical_program_entry_v1+0xbf0ec>
      88:      	ldur	x0, [sp, #0x8]
      8c:      	ldr	x1, [x0, #0x18]
      90:      	mov	x15, #0x3               ; =3
      94:      	cmp	x1, #0x1
      98:      	b.ne	0xbf0f0 <_mech_canonical_program_entry_v1+0xbf0f0>
      9c:      	ldur	x0, [sp, #0x8]
      a0:      	ldr	x5, [x0, #0x20]
      a4:      	ldr	x1, [x0, #0x28]
      a8:      	ldr	x4, [x0, #0x30]
      ac:      	ldr	x3, [x0, #0x38]
      b0:      	ldr	x2, [x0, #0x40]
      b4:      	mov	x15, #0x3               ; =3
      b8:      	cmp	x5, #0x0
      bc:      	b.eq	0xd0914 <_mech_canonical_program_entry_v1+0xd0914>
      c0:      	mov	x15, #0x3               ; =3
      c4:      	cmp	x1, #0x0
      c8:      	b.eq	0xd0918 <_mech_canonical_program_entry_v1+0xd0918>
      cc:      	mov	x15, #0x3               ; =3
      d0:      	cmp	x4, #0x0
      d4:      	b.eq	0xd091c <_mech_canonical_program_entry_v1+0xd091c>
      d8:      	mov	x15, #0x3               ; =3
      dc:      	cmp	x3, #0x0
      e0:      	mov	w16, #0xa2d0            ; =41680
      e4:      	movk	w16, #0x1, lsl #16
      e8:      	str	x3, [sp, x16, sxtx]
      ec:      	b.eq	0xd0920 <_mech_canonical_program_entry_v1+0xd0920>
      f0:      	mov	x15, #0x3               ; =3
      f4:      	cmp	x2, #0x0
      f8:      	mov	w16, #0xa2c8            ; =41672
      fc:      	movk	w16, #0x1, lsl #16
     100:      	str	x2, [sp, x16, sxtx]
     104:      	b.eq	0xd21c8 <_mech_canonical_program_entry_v1+0xd21c8>
     108:      	stur	x1, [sp]
     10c:      	ldur	x0, [sp, #0x8]
     110:      	ldr	x3, [x0, #0x50]
     114:      	ldr	x6, [x0, #0x58]
     118:      	ldr	x2, [x0, #0x60]
     11c:      	ldr	x0, [x0, #0x68]
     120:      	mov	w16, #0xa2a8            ; =41640
     124:      	movk	w16, #0x1, lsl #16
     128:      	str	x0, [sp, x16, sxtx]
     12c:      	mov	x15, #0x3               ; =3
     130:      	cmp	x3, #0x0
     134:      	mov	w16, #0xa2c0            ; =41664
     138:      	movk	w16, #0x1, lsl #16
     13c:      	str	x3, [sp, x16, sxtx]
     140:      	b.eq	0xd21cc <_mech_canonical_program_entry_v1+0xd21cc>
     144:      	mov	x15, #0x3               ; =3
     148:      	cmp	x6, #0x0
     14c:      	mov	w16, #0xa2b8            ; =41656
     150:      	movk	w16, #0x1, lsl #16
     154:      	str	x6, [sp, x16, sxtx]
     158:      	b.eq	0xd21d0 <_mech_canonical_program_entry_v1+0xd21d0>
     15c:      	mov	x15, #0x3               ; =3
     160:      	cmp	x2, #0x0
     164:      	mov	w16, #0xa2b0            ; =41648
     168:      	movk	w16, #0x1, lsl #16
     16c:      	str	x2, [sp, x16, sxtx]
     170:      	b.eq	0xd21d4 <_mech_canonical_program_entry_v1+0xd21d4>
     174:      	ldur	x0, [sp, #0x8]
     178:      	ldr	x2, [x0, #0x70]
     17c:      	mov	x15, #0x3               ; =3
     180:      	cmp	x2, #0x1
     184:      	b.hi	0xd21d8 <_mech_canonical_program_entry_v1+0xd21d8>
     188:      	cmp	x2, #0x0
     18c:      	stur	x2, [sp, #0xf8]
     190:      	b.ne	0xe24 <_mech_canonical_program_entry_v1+0xe24>
     194:      	mov	x13, #0x0               ; =0
     198:      	str	x13, [x1, #0x28]
     19c:      	str	x13, [x1, #0x40]
     1a0:      	stur	x13, [sp, #0xf0]
     1a4:      	mov	x23, #0x1               ; =1
     1a8:      	str	x23, [x1, #0x48]
     1ac:      	mov	x24, #0x101             ; =257
     1b0:      	str	x24, [x1, #0x50]
     1b4:      	mov	x25, #0x201             ; =513
     1b8:      	str	x25, [x1, #0x58]
     1bc:      	mov	x10, #0x301             ; =769
     1c0:      	str	x10, [x1, #0x60]
     1c4:      	mov	x11, #0x401             ; =1025
     1c8:      	str	x11, [x1, #0x68]
     1cc:      	mov	x12, #0x601             ; =1537
     1d0:      	str	x12, [x1, #0x70]
     1d4:      	mov	x13, #0x801             ; =2049
     1d8:      	str	x13, [x1, #0x78]
     1dc:      	mov	x14, #0xc01             ; =3073
     1e0:      	str	x14, [x1, #0x80]
     1e4:      	mov	x15, #0x1001            ; =4097
     1e8:      	str	x15, [x1, #0x88]
     1ec:      	mov	x0, #0x1801             ; =6145
     1f0:      	str	x0, [x1, #0x90]
     1f4:      	mov	x0, #0x2001             ; =8193
     1f8:      	str	x0, [x1, #0x98]
     1fc:      	mov	x0, #0x3001             ; =12289
     200:      	str	x0, [x1, #0xa0]
     204:      	mov	x0, #0x4001             ; =16385
     208:      	str	x0, [x1, #0xa8]
     20c:      	mov	x0, #0x6001             ; =24577
     210:      	str	x0, [x1, #0xb0]
     214:      	mov	x28, #0x2               ; =2
     218:      	str	x28, [x1, #0xb8]
     21c:      	mov	x2, #0x102              ; =258
     220:      	str	x2, [x1, #0xc0]
     224:      	mov	x3, #0x3                ; =3
     228:      	str	x3, [x1, #0xc8]
     22c:      	mov	x4, #0x4                ; =4
     230:      	str	x4, [x1, #0xd0]
     234:      	mov	x7, #0x5                ; =5
     238:      	str	x7, [x1, #0xd8]
     23c:      	mov	x10, #0x6               ; =6
     240:      	str	x10, [x1, #0xe0]
     244:      	mov	x11, #0x7               ; =7
     248:      	str	x11, [x1, #0xe8]
     24c:      	mov	x12, #0x8               ; =8
     250:      	str	x12, [x1, #0xf0]
     254:      	mov	x5, #0x9                ; =9
     258:      	str	x5, [x1, #0xf8]
     25c:      	mov	x13, #0xa               ; =10
     260:      	str	x13, [x1, #0x100]
     264:      	mov	x22, #0xb               ; =11
     268:      	str	x22, [x1, #0x108]
     26c:      	mov	x14, #0xd               ; =13
     270:      	str	x14, [x1, #0x110]
     274:      	mov	x15, #0xf               ; =15
     278:      	str	x15, [x1, #0x118]
     27c:      	mov	x20, #0x11              ; =17
     280:      	str	x20, [x1, #0x120]
     284:      	mov	x21, #0x13              ; =19
     288:      	str	x21, [x1, #0x128]
     28c:      	mov	x8, #0x17               ; =23
     290:      	str	x8, [x1, #0x130]
     294:      	mov	x0, #0x19               ; =25
     298:      	str	x0, [x1, #0x138]
     29c:      	stur	x0, [sp, #0xe0]
     2a0:      	mov	x9, #0x1b               ; =27
     2a4:      	str	x9, [x1, #0x140]
     2a8:      	stur	x9, [sp, #0xd8]
     2ac:      	mov	x0, #0x1f               ; =31
     2b0:      	str	x0, [x1, #0x148]
     2b4:      	stur	x0, [sp, #0xd0]
     2b8:      	mov	x19, #0x21              ; =33
     2bc:      	str	x19, [x1, #0x150]
     2c0:      	stur	x19, [sp, #0xc8]
     2c4:      	mov	x6, #0x23               ; =35
     2c8:      	str	x6, [x1, #0x158]
     2cc:      	stur	x6, [sp, #0xc0]
     2d0:      	mov	x0, #0x2b               ; =43
     2d4:      	mov	x6, x0
     2d8:      	str	x6, [x1, #0x160]
     2dc:      	stur	x6, [sp, #0xb8]
     2e0:      	mov	x27, #0x31              ; =49
     2e4:      	str	x27, [x1, #0x168]
     2e8:      	stur	x27, [sp, #0xb0]
     2ec:      	mov	x26, #0x33              ; =51
     2f0:      	str	x26, [x1, #0x170]
     2f4:      	stur	x26, [sp, #0xa8]
     2f8:      	mov	x6, #0x3b               ; =59
     2fc:      	str	x6, [x1, #0x178]
     300:      	stur	x6, [sp, #0xa0]
     304:      	mov	x0, #0x41               ; =65
     308:      	str	x0, [x1, #0x180]
     30c:      	stur	x0, [sp, #0x98]
     310:      	mov	x0, #0x43               ; =67
     314:      	mov	x9, x0
     318:      	str	x9, [x1, #0x188]
     31c:      	stur	x9, [sp, #0x90]
     320:      	mov	x6, #0x53               ; =83
     324:      	str	x6, [x1, #0x190]
     328:      	stur	x6, [sp, #0x88]
     32c:      	mov	x0, #0x61               ; =97
     330:      	mov	x6, x0
     334:      	str	x6, [x1, #0x198]
     338:      	stur	x6, [sp, #0x80]
     33c:      	mov	x0, #0x63               ; =99
     340:      	mov	x6, x0
     344:      	str	x6, [x1, #0x1a0]
     348:      	stur	x6, [sp, #0x78]
     34c:      	mov	x0, #0x73               ; =115
     350:      	str	x0, [x1, #0x1a8]
     354:      	stur	x0, [sp, #0x70]
     358:      	mov	x6, #0x81               ; =129
     35c:      	str	x6, [x1, #0x1b0]
     360:      	stur	x6, [sp, #0x68]
     364:      	mov	x0, #0x181              ; =385
     368:      	str	x0, [x1, #0x1b8]
     36c:      	mov	x6, #0x83               ; =131
     370:      	str	x6, [x1, #0x1c0]
     374:      	stur	x6, [sp, #0x60]
     378:      	mov	x0, #0xa3               ; =163
     37c:      	str	x0, [x1, #0x1c8]
     380:      	stur	x0, [sp, #0x58]
     384:      	mov	x6, #0xc1               ; =193
     388:      	str	x6, [x1, #0x1d0]
     38c:      	stur	x6, [sp, #0x50]
     390:      	mov	x0, #0xc3               ; =195
     394:      	mov	x6, x0
     398:      	str	x6, [x1, #0x1d8]
     39c:      	stur	x6, [sp, #0x48]
     3a0:      	mov	x0, #0xe3               ; =227
     3a4:      	mov	x6, x0
     3a8:      	str	x6, [x1, #0x1e0]
     3ac:      	ldur	x0, [sp, #0xf0]
     3b0:      	stur	x6, [sp, #0x40]
     3b4:      	str	x0, [x1, #0x1e8]
     3b8:      	str	x23, [x1, #0x1f0]
     3bc:      	mov	x0, #-0x7fffffffffffffff ; =-9223372036854775807
     3c0:      	str	x0, [x1, #0x1f8]
     3c4:      	str	x4, [x1, #0x200]
     3c8:      	ldur	x0, [sp, #0xf0]
     3cc:      	str	x0, [x1, #0x218]
     3d0:      	mov	x6, #0x80000000         ; =2147483648
     3d4:      	str	x6, [x1, #0x220]
     3d8:      	mov	x6, #0x10000            ; =65536
     3dc:      	str	x6, [x1, #0x228]
     3e0:      	mov	x6, #0x20000            ; =131072
     3e4:      	str	x6, [x1, #0x230]
     3e8:      	mov	x6, #0x40000            ; =262144
     3ec:      	str	x6, [x1, #0x238]
     3f0:      	mov	x6, #0xffff0000         ; =4294901760
     3f4:      	str	x6, [x1, #0x240]
     3f8:      	mov	x6, #0x100              ; =256
     3fc:      	str	x6, [x1, #0x248]
     400:      	mov	x9, #0x200              ; =512
     404:      	str	x9, [x1, #0x250]
     408:      	mov	x9, #0x1000             ; =4096
     40c:      	str	x9, [x1, #0x258]
     410:      	mov	x9, #0x2000             ; =8192
     414:      	str	x9, [x1, #0x260]
     418:      	mov	x0, #0x8000             ; =32768
     41c:      	str	x0, [x1, #0x268]
     420:      	mov	x0, #0xfffffc00         ; =4294966272
     424:      	str	x0, [x1, #0x270]
     428:      	str	x23, [x1, #0x278]
     42c:      	stur	x23, [sp, #0xe8]
     430:      	str	x24, [x1, #0x280]
     434:      	str	x25, [x1, #0x288]
     438:      	str	x28, [x1, #0x290]
     43c:      	str	x2, [x1, #0x298]
     440:      	str	x3, [x1, #0x2a0]
     444:      	mov	x0, #0x103              ; =259
     448:      	str	x0, [x1, #0x2a8]
     44c:      	str	x4, [x1, #0x2b0]
     450:      	str	x7, [x1, #0x2b8]
     454:      	str	x10, [x1, #0x2c0]
     458:      	str	x11, [x1, #0x2c8]
     45c:      	str	x12, [x1, #0x2d0]
     460:      	str	x5, [x1, #0x2d8]
     464:      	str	x13, [x1, #0x2e0]
     468:      	str	x22, [x1, #0x2e8]
     46c:      	str	x14, [x1, #0x2f0]
     470:      	mov	x19, #0xe               ; =14
     474:      	str	x19, [x1, #0x2f8]
     478:      	mov	x0, #0x10e              ; =270
     47c:      	str	x0, [x1, #0x300]
     480:      	str	x15, [x1, #0x308]
     484:      	mov	x23, #0x10              ; =16
     488:      	str	x23, [x1, #0x310]
     48c:      	mov	x0, #0x2710             ; =10000
     490:      	str	x0, [x1, #0x318]
     494:      	str	x20, [x1, #0x320]
     498:      	mov	x24, #0x12              ; =18
     49c:      	str	x24, [x1, #0x328]
     4a0:      	str	x21, [x1, #0x330]
     4a4:      	str	x8, [x1, #0x338]
     4a8:      	mov	x6, #0x18               ; =24
     4ac:      	str	x6, [x1, #0x340]
     4b0:      	mov	x0, #0x118              ; =280
     4b4:      	str	x0, [x1, #0x348]
     4b8:      	mov	x27, #0x1d              ; =29
     4bc:      	str	x27, [x1, #0x350]
     4c0:      	mov	x2, #0x1e               ; =30
     4c4:      	str	x2, [x1, #0x358]
     4c8:      	mov	x0, #0x11e              ; =286
     4cc:      	str	x0, [x1, #0x360]
     4d0:      	ldur	x0, [sp, #0xd0]
     4d4:      	str	x0, [x1, #0x368]
     4d8:      	mov	x9, #0x20               ; =32
     4dc:      	str	x9, [x1, #0x370]
     4e0:      	mov	x0, #0x120              ; =288
     4e4:      	str	x0, [x1, #0x378]
     4e8:      	mov	x0, #0x320              ; =800
     4ec:      	str	x0, [x1, #0x380]
     4f0:      	mov	x26, #0x28              ; =40
     4f4:      	str	x26, [x1, #0x388]
     4f8:      	mov	x0, #0x12c              ; =300
     4fc:      	str	x0, [x1, #0x390]
     500:      	mov	x25, #0x30              ; =48
     504:      	str	x25, [x1, #0x398]
     508:      	mov	x0, #0x140              ; =320
     50c:      	str	x0, [x1, #0x3a0]
     510:      	mov	x0, #0x340              ; =832
     514:      	str	x0, [x1, #0x3a8]
     518:      	mov	x0, #0x4e               ; =78
     51c:      	str	x0, [x1, #0x3b0]
     520:      	stur	x0, [sp, #0x38]
     524:      	mov	x0, #0x50               ; =80
     528:      	str	x0, [x1, #0x3b8]
     52c:      	stur	x0, [sp, #0x30]
     530:      	mov	w0, #0xe360             ; =58208
     534:      	movk	w0, #0x16, lsl #16
     538:      	str	x0, [x1, #0x3c0]
     53c:      	mov	w0, #0xe561             ; =58721
     540:      	movk	w0, #0x16, lsl #16
     544:      	str	x0, [x1, #0x3c8]
     548:      	mov	w0, #0xa768             ; =42856
     54c:      	movk	w0, #0x4, lsl #16
     550:      	str	x0, [x1, #0x3d0]
     554:      	mov	w0, #0xa869             ; =43113
     558:      	movk	w0, #0x4, lsl #16
     55c:      	str	x0, [x1, #0x3d8]
     560:      	mov	x0, #0x7f               ; =127
     564:      	str	x0, [x1, #0x3e0]
     568:      	stur	x0, [sp, #0x28]
     56c:      	mov	x0, #0x1387             ; =4999
     570:      	str	x0, [x1, #0x3e8]
     574:      	mov	x0, #0x1388             ; =5000
     578:      	str	x0, [x1, #0x3f0]
     57c:      	mov	x0, #0x90               ; =144
     580:      	str	x0, [x1, #0x3f8]
     584:      	stur	x0, [sp, #0x20]
     588:      	mov	x0, #0x190              ; =400
     58c:      	str	x0, [x1, #0x400]
     590:      	mov	w0, #0xa7bd             ; =42941
     594:      	movk	w0, #0x1e35, lsl #16
     598:      	str	x0, [x1, #0x408]
     59c:      	mov	x0, #0xc0               ; =192
     5a0:      	str	x0, [x1, #0x410]
     5a4:      	stur	x0, [sp, #0x18]
     5a8:      	mov	x0, #0xc8               ; =200
     5ac:      	str	x0, [x1, #0x418]
     5b0:      	stur	x0, [sp, #0x10]
     5b4:      	mov	w0, #0x93e0             ; =37856
     5b8:      	movk	w0, #0x4, lsl #16
     5bc:      	str	x0, [x1, #0x420]
     5c0:      	mov	x0, #0xfffe             ; =65534
     5c4:      	str	x0, [x1, #0x428]
     5c8:      	mov	x0, #0xff               ; =255
     5cc:      	str	x0, [x1, #0x430]
     5d0:      	mov	w16, #0xa2a0            ; =41632
     5d4:      	movk	w16, #0x1, lsl #16
     5d8:      	str	x0, [sp, x16, sxtx]
     5dc:      	mov	x0, #0x1ff              ; =511
     5e0:      	str	x0, [x1, #0x438]
     5e4:      	mov	x0, #0x3ff              ; =1023
     5e8:      	str	x0, [x1, #0x440]
     5ec:      	mov	x0, #0x7fff             ; =32767
     5f0:      	str	x0, [x1, #0x448]
     5f4:      	mov	x0, #0xffff             ; =65535
     5f8:      	str	x0, [x1, #0x450]
     5fc:      	mov	x0, #0x7fffff           ; =8388607
     600:      	str	x0, [x1, #0x458]
     604:      	mov	x0, #0xffffff           ; =16777215
     608:      	str	x0, [x1, #0x460]
     60c:      	mov	x0, #0xffffffff         ; =4294967295
     610:      	str	x0, [x1, #0x468]
     614:      	mov	x0, #0x7fffffffffffffff ; =9223372036854775807
     618:      	str	x0, [x1, #0x470]
     61c:      	mov	x0, #-0x1               ; =-1
     620:      	str	x0, [x1, #0x478]
     624:      	ldur	x0, [sp, #0xf0]
     628:      	str	x0, [x1, #0x488]
     62c:      	ldur	x0, [sp, #0xe8]
     630:      	str	x0, [x1, #0x490]
     634:      	str	x28, [x1, #0x498]
     638:      	str	x3, [x1, #0x4a0]
     63c:      	str	x4, [x1, #0x4a8]
     640:      	str	x7, [x1, #0x4b0]
     644:      	str	x10, [x1, #0x4b8]
     648:      	str	x11, [x1, #0x4c0]
     64c:      	str	x12, [x1, #0x4c8]
     650:      	str	x5, [x1, #0x4d0]
     654:      	str	x13, [x1, #0x4d8]
     658:      	str	x22, [x1, #0x4e0]
     65c:      	mov	x0, #0xc                ; =12
     660:      	str	x0, [x1, #0x4e8]
     664:      	str	x14, [x1, #0x4f0]
     668:      	str	x19, [x1, #0x4f8]
     66c:      	str	x15, [x1, #0x500]
     670:      	str	x23, [x1, #0x508]
     674:      	str	x20, [x1, #0x510]
     678:      	str	x24, [x1, #0x518]
     67c:      	str	x21, [x1, #0x520]
     680:      	mov	x0, #0x14               ; =20
     684:      	str	x0, [x1, #0x528]
     688:      	mov	x0, #0x15               ; =21
     68c:      	str	x0, [x1, #0x530]
     690:      	mov	x0, #0x16               ; =22
     694:      	str	x0, [x1, #0x538]
     698:      	str	x8, [x1, #0x540]
     69c:      	str	x6, [x1, #0x548]
     6a0:      	ldur	x0, [sp, #0xe0]
     6a4:      	str	x0, [x1, #0x550]
     6a8:      	mov	x0, #0x1a               ; =26
     6ac:      	str	x0, [x1, #0x558]
     6b0:      	ldur	x11, [sp, #0xd8]
     6b4:      	str	x11, [x1, #0x560]
     6b8:      	mov	x0, #0x1c               ; =28
     6bc:      	str	x0, [x1, #0x568]
     6c0:      	str	x27, [x1, #0x570]
     6c4:      	str	x2, [x1, #0x578]
     6c8:      	ldur	x3, [sp, #0xd0]
     6cc:      	str	x3, [x1, #0x580]
     6d0:      	str	x9, [x1, #0x588]
     6d4:      	ldur	x19, [sp, #0xc8]
     6d8:      	str	x19, [x1, #0x590]
     6dc:      	mov	x0, #0x22               ; =34
     6e0:      	str	x0, [x1, #0x598]
     6e4:      	ldur	x6, [sp, #0xc0]
     6e8:      	str	x6, [x1, #0x5a0]
     6ec:      	mov	x0, #0x24               ; =36
     6f0:      	str	x0, [x1, #0x5a8]
     6f4:      	mov	x0, #0x25               ; =37
     6f8:      	str	x0, [x1, #0x5b0]
     6fc:      	mov	x0, #0x26               ; =38
     700:      	str	x0, [x1, #0x5b8]
     704:      	mov	x0, #0x27               ; =39
     708:      	str	x0, [x1, #0x5c0]
     70c:      	str	x26, [x1, #0x5c8]
     710:      	mov	x0, #0x29               ; =41
     714:      	str	x0, [x1, #0x5d0]
     718:      	mov	x0, #0x2a               ; =42
     71c:      	str	x0, [x1, #0x5d8]
     720:      	ldur	x2, [sp, #0xb8]
     724:      	str	x2, [x1, #0x5e0]
     728:      	mov	x0, #0x2c               ; =44
     72c:      	str	x0, [x1, #0x5e8]
     730:      	mov	x0, #0x2d               ; =45
     734:      	str	x0, [x1, #0x5f0]
     738:      	mov	x0, #0x2e               ; =46
     73c:      	str	x0, [x1, #0x5f8]
     740:      	mov	x0, #0x2f               ; =47
     744:      	str	x0, [x1, #0x600]
     748:      	str	x25, [x1, #0x608]
     74c:      	ldur	x27, [sp, #0xb0]
     750:      	str	x27, [x1, #0x610]
     754:      	mov	x2, #0x32               ; =50
     758:      	str	x2, [x1, #0x618]
     75c:      	ldur	x26, [sp, #0xa8]
     760:      	str	x26, [x1, #0x620]
     764:      	mov	x3, #0x34               ; =52
     768:      	str	x3, [x1, #0x628]
     76c:      	mov	x4, #0x35               ; =53
     770:      	str	x4, [x1, #0x630]
     774:      	mov	x5, #0x36               ; =54
     778:      	str	x5, [x1, #0x638]
     77c:      	mov	x6, #0x37               ; =55
     780:      	str	x6, [x1, #0x640]
     784:      	mov	x7, #0x38               ; =56
     788:      	str	x7, [x1, #0x648]
     78c:      	mov	x8, #0x39               ; =57
     790:      	str	x8, [x1, #0x650]
     794:      	mov	x9, #0x3a               ; =58
     798:      	str	x9, [x1, #0x658]
     79c:      	ldur	x24, [sp, #0xa0]
     7a0:      	str	x24, [x1, #0x660]
     7a4:      	mov	x11, #0x3c              ; =60
     7a8:      	str	x11, [x1, #0x668]
     7ac:      	mov	x12, #0x3d              ; =61
     7b0:      	str	x12, [x1, #0x670]
     7b4:      	mov	x13, #0x3e              ; =62
     7b8:      	str	x13, [x1, #0x678]
     7bc:      	mov	x14, #0x3f              ; =63
     7c0:      	str	x14, [x1, #0x680]
     7c4:      	mov	x15, #0x40              ; =64
     7c8:      	str	x15, [x1, #0x688]
     7cc:      	ldur	x23, [sp, #0x98]
     7d0:      	str	x23, [x1, #0x690]
     7d4:      	mov	x0, #0x42               ; =66
     7d8:      	str	x0, [x1, #0x698]
     7dc:      	ldur	x22, [sp, #0x90]
     7e0:      	str	x22, [x1, #0x6a0]
     7e4:      	mov	x0, #0x44               ; =68
     7e8:      	str	x0, [x1, #0x6a8]
     7ec:      	mov	x0, #0x45               ; =69
     7f0:      	str	x0, [x1, #0x6b0]
     7f4:      	mov	x0, #0x46               ; =70
     7f8:      	str	x0, [x1, #0x6b8]
     7fc:      	mov	x0, #0x47               ; =71
     800:      	str	x0, [x1, #0x6c0]
     804:      	mov	x0, #0x48               ; =72
     808:      	str	x0, [x1, #0x6c8]
     80c:      	mov	x0, #0x49               ; =73
     810:      	str	x0, [x1, #0x6d0]
     814:      	mov	x0, #0x4a               ; =74
     818:      	str	x0, [x1, #0x6d8]
     81c:      	mov	x0, #0x4b               ; =75
     820:      	str	x0, [x1, #0x6e0]
     824:      	mov	x0, #0x4c               ; =76
     828:      	str	x0, [x1, #0x6e8]
     82c:      	mov	x0, #0x4d               ; =77
     830:      	str	x0, [x1, #0x6f0]
     834:      	ldur	x0, [sp, #0x38]
     838:      	str	x0, [x1, #0x6f8]
     83c:      	mov	x0, #0x4f               ; =79
     840:      	str	x0, [x1, #0x700]
     844:      	ldur	x24, [sp, #0x30]
     848:      	str	x24, [x1, #0x708]
     84c:      	mov	x0, #0x51               ; =81
     850:      	str	x0, [x1, #0x710]
     854:      	mov	x0, #0x52               ; =82
     858:      	str	x0, [x1, #0x718]
     85c:      	ldur	x20, [sp, #0x88]
     860:      	str	x20, [x1, #0x720]
     864:      	mov	x0, #0x54               ; =84
     868:      	str	x0, [x1, #0x728]
     86c:      	mov	x0, #0x55               ; =85
     870:      	str	x0, [x1, #0x730]
     874:      	mov	x0, #0x56               ; =86
     878:      	str	x0, [x1, #0x738]
     87c:      	mov	x0, #0x57               ; =87
     880:      	str	x0, [x1, #0x740]
     884:      	mov	x0, #0x58               ; =88
     888:      	str	x0, [x1, #0x748]
     88c:      	mov	x0, #0x59               ; =89
     890:      	str	x0, [x1, #0x750]
     894:      	mov	x0, #0x5a               ; =90
     898:      	str	x0, [x1, #0x758]
     89c:      	mov	x0, #0x5b               ; =91
     8a0:      	str	x0, [x1, #0x760]
     8a4:      	mov	x0, #0x5c               ; =92
     8a8:      	str	x0, [x1, #0x768]
     8ac:      	mov	x0, #0x5d               ; =93
     8b0:      	str	x0, [x1, #0x770]
     8b4:      	mov	x0, #0x5e               ; =94
     8b8:      	str	x0, [x1, #0x778]
     8bc:      	mov	x0, #0x5f               ; =95
     8c0:      	str	x0, [x1, #0x780]
     8c4:      	mov	x0, #0x60               ; =96
     8c8:      	str	x0, [x1, #0x788]
     8cc:      	ldur	x15, [sp, #0x80]
     8d0:      	str	x15, [x1, #0x790]
     8d4:      	mov	x0, #0x62               ; =98
     8d8:      	str	x0, [x1, #0x798]
     8dc:      	ldur	x14, [sp, #0x78]
     8e0:      	str	x14, [x1, #0x7a0]
     8e4:      	mov	x0, #0x64               ; =100
     8e8:      	str	x0, [x1, #0x7a8]
     8ec:      	mov	x0, #0x65               ; =101
     8f0:      	str	x0, [x1, #0x7b0]
     8f4:      	mov	x0, #0x66               ; =102
     8f8:      	str	x0, [x1, #0x7b8]
     8fc:      	mov	x0, #0x67               ; =103
     900:      	str	x0, [x1, #0x7c0]
     904:      	mov	x0, #0x68               ; =104
     908:      	str	x0, [x1, #0x7c8]
     90c:      	mov	x0, #0x69               ; =105
     910:      	str	x0, [x1, #0x7d0]
     914:      	mov	x0, #0x6a               ; =106
     918:      	str	x0, [x1, #0x7d8]
     91c:      	mov	x0, #0x6b               ; =107
     920:      	str	x0, [x1, #0x7e0]
     924:      	mov	x0, #0x6c               ; =108
     928:      	str	x0, [x1, #0x7e8]
     92c:      	mov	x0, #0x6d               ; =109
     930:      	str	x0, [x1, #0x7f0]
     934:      	mov	x0, #0x6e               ; =110
     938:      	str	x0, [x1, #0x7f8]
     93c:      	mov	x0, #0x6f               ; =111
     940:      	str	x0, [x1, #0x800]
     944:      	mov	x0, #0x70               ; =112
     948:      	str	x0, [x1, #0x808]
     94c:      	mov	x2, #0x71               ; =113
     950:      	str	x2, [x1, #0x810]
     954:      	mov	x2, #0x72               ; =114
     958:      	str	x2, [x1, #0x818]
     95c:      	ldur	x5, [sp, #0x70]
     960:      	str	x5, [x1, #0x820]
     964:      	mov	x4, #0x74               ; =116
     968:      	str	x4, [x1, #0x828]
     96c:      	mov	x5, #0x75               ; =117
     970:      	str	x5, [x1, #0x830]
     974:      	mov	x6, #0x76               ; =118
     978:      	str	x6, [x1, #0x838]
     97c:      	mov	x7, #0x77               ; =119
     980:      	str	x7, [x1, #0x840]
     984:      	mov	x8, #0x78               ; =120
     988:      	str	x8, [x1, #0x848]
     98c:      	mov	x9, #0x79               ; =121
     990:      	str	x9, [x1, #0x850]
     994:      	mov	x10, #0x7a              ; =122
     998:      	str	x10, [x1, #0x858]
     99c:      	mov	x11, #0x7b              ; =123
     9a0:      	str	x11, [x1, #0x860]
     9a4:      	mov	x12, #0x7c              ; =124
     9a8:      	str	x12, [x1, #0x868]
     9ac:      	mov	x13, #0x7d              ; =125
     9b0:      	str	x13, [x1, #0x870]
     9b4:      	mov	x14, #0x7e              ; =126
     9b8:      	str	x14, [x1, #0x878]
     9bc:      	ldur	x25, [sp, #0x28]
     9c0:      	str	x25, [x1, #0x880]
     9c4:      	mov	x0, #0x80               ; =128
     9c8:      	str	x0, [x1, #0x888]
     9cc:      	ldur	x10, [sp, #0x68]
     9d0:      	str	x10, [x1, #0x890]
     9d4:      	mov	x0, #0x82               ; =130
     9d8:      	str	x0, [x1, #0x898]
     9dc:      	ldur	x11, [sp, #0x60]
     9e0:      	str	x11, [x1, #0x8a0]
     9e4:      	mov	x0, #0x84               ; =132
     9e8:      	str	x0, [x1, #0x8a8]
     9ec:      	mov	x0, #0x85               ; =133
     9f0:      	str	x0, [x1, #0x8b0]
     9f4:      	mov	x0, #0x86               ; =134
     9f8:      	str	x0, [x1, #0x8b8]
     9fc:      	mov	x0, #0x87               ; =135
     a00:      	str	x0, [x1, #0x8c0]
     a04:      	mov	x0, #0x88               ; =136
     a08:      	str	x0, [x1, #0x8c8]
     a0c:      	mov	x0, #0x89               ; =137
     a10:      	str	x0, [x1, #0x8d0]
     a14:      	mov	x0, #0x8a               ; =138
     a18:      	str	x0, [x1, #0x8d8]
     a1c:      	mov	x0, #0x8b               ; =139
     a20:      	str	x0, [x1, #0x8e0]
     a24:      	mov	x0, #0x8c               ; =140
     a28:      	str	x0, [x1, #0x8e8]
     a2c:      	mov	x0, #0x8d               ; =141
     a30:      	str	x0, [x1, #0x8f0]
     a34:      	mov	x0, #0x8e               ; =142
     a38:      	str	x0, [x1, #0x8f8]
     a3c:      	mov	x0, #0x8f               ; =143
     a40:      	str	x0, [x1, #0x900]
     a44:      	ldur	x21, [sp, #0x20]
     a48:      	str	x21, [x1, #0x908]
     a4c:      	mov	x0, #0x91               ; =145
     a50:      	str	x0, [x1, #0x910]
     a54:      	mov	x0, #0x92               ; =146
     a58:      	str	x0, [x1, #0x918]
     a5c:      	mov	x0, #0x93               ; =147
     a60:      	str	x0, [x1, #0x920]
     a64:      	mov	x0, #0x94               ; =148
     a68:      	str	x0, [x1, #0x928]
     a6c:      	mov	x0, #0x95               ; =149
     a70:      	str	x0, [x1, #0x930]
     a74:      	mov	x0, #0x96               ; =150
     a78:      	str	x0, [x1, #0x938]
     a7c:      	mov	x0, #0x97               ; =151
     a80:      	str	x0, [x1, #0x940]
     a84:      	mov	x0, #0x98               ; =152
     a88:      	str	x0, [x1, #0x948]
     a8c:      	mov	x0, #0x99               ; =153
     a90:      	str	x0, [x1, #0x950]
     a94:      	mov	x0, #0x9a               ; =154
     a98:      	str	x0, [x1, #0x958]
     a9c:      	mov	x0, #0x9b               ; =155
     aa0:      	str	x0, [x1, #0x960]
     aa4:      	mov	x0, #0x9c               ; =156
     aa8:      	str	x0, [x1, #0x968]
     aac:      	mov	x0, #0x9d               ; =157
     ab0:      	str	x0, [x1, #0x970]
     ab4:      	mov	x0, #0x9e               ; =158
     ab8:      	str	x0, [x1, #0x978]
     abc:      	mov	x0, #0x9f               ; =159
     ac0:      	str	x0, [x1, #0x980]
     ac4:      	mov	x0, #0xa0               ; =160
     ac8:      	str	x0, [x1, #0x988]
     acc:      	mov	x0, #0xa1               ; =161
     ad0:      	str	x0, [x1, #0x990]
     ad4:      	mov	x0, #0xa2               ; =162
     ad8:      	str	x0, [x1, #0x998]
     adc:      	ldur	x7, [sp, #0x58]
     ae0:      	str	x7, [x1, #0x9a0]
     ae4:      	mov	x0, #0xa4               ; =164
     ae8:      	str	x0, [x1, #0x9a8]
     aec:      	mov	x0, #0xa5               ; =165
     af0:      	str	x0, [x1, #0x9b0]
     af4:      	mov	x0, #0xa6               ; =166
     af8:      	str	x0, [x1, #0x9b8]
     afc:      	mov	x0, #0xa7               ; =167
     b00:      	str	x0, [x1, #0x9c0]
     b04:      	mov	x0, #0xa8               ; =168
     b08:      	str	x0, [x1, #0x9c8]
     b0c:      	mov	x0, #0xa9               ; =169
     b10:      	str	x0, [x1, #0x9d0]
     b14:      	mov	x0, #0xaa               ; =170
     b18:      	str	x0, [x1, #0x9d8]
     b1c:      	mov	x0, #0xab               ; =171
     b20:      	str	x0, [x1, #0x9e0]
     b24:      	mov	x0, #0xac               ; =172
     b28:      	str	x0, [x1, #0x9e8]
     b2c:      	mov	x0, #0xad               ; =173
     b30:      	str	x0, [x1, #0x9f0]
     b34:      	mov	x0, #0xae               ; =174
     b38:      	str	x0, [x1, #0x9f8]
     b3c:      	mov	x0, #0xaf               ; =175
     b40:      	str	x0, [x1, #0xa00]
     b44:      	mov	x2, #0xb0               ; =176
     b48:      	str	x2, [x1, #0xa08]
     b4c:      	mov	x2, #0xb1               ; =177
     b50:      	str	x2, [x1, #0xa10]
     b54:      	mov	x3, #0xb2               ; =178
     b58:      	str	x3, [x1, #0xa18]
     b5c:      	mov	x4, #0xb3               ; =179
     b60:      	str	x4, [x1, #0xa20]
     b64:      	mov	x5, #0xb4               ; =180
     b68:      	str	x5, [x1, #0xa28]
     b6c:      	mov	x6, #0xb5               ; =181
     b70:      	str	x6, [x1, #0xa30]
     b74:      	mov	x7, #0xb6               ; =182
     b78:      	str	x7, [x1, #0xa38]
     b7c:      	mov	x8, #0xb7               ; =183
     b80:      	str	x8, [x1, #0xa40]
     b84:      	mov	x9, #0xb8               ; =184
     b88:      	str	x9, [x1, #0xa48]
     b8c:      	mov	x10, #0xb9              ; =185
     b90:      	str	x10, [x1, #0xa50]
     b94:      	mov	x11, #0xba              ; =186
     b98:      	str	x11, [x1, #0xa58]
     b9c:      	mov	x12, #0xbb              ; =187
     ba0:      	str	x12, [x1, #0xa60]
     ba4:      	mov	x13, #0xbc              ; =188
     ba8:      	str	x13, [x1, #0xa68]
     bac:      	mov	x14, #0xbd              ; =189
     bb0:      	str	x14, [x1, #0xa70]
     bb4:      	mov	x15, #0xbe              ; =190
     bb8:      	str	x15, [x1, #0xa78]
     bbc:      	mov	x0, #0xbf               ; =191
     bc0:      	str	x0, [x1, #0xa80]
     bc4:      	ldur	x12, [sp, #0x18]
     bc8:      	str	x12, [x1, #0xa88]
     bcc:      	ldur	x4, [sp, #0x50]
     bd0:      	str	x4, [x1, #0xa90]
     bd4:      	mov	x0, #0xc2               ; =194
     bd8:      	str	x0, [x1, #0xa98]
     bdc:      	ldur	x3, [sp, #0x48]
     be0:      	str	x3, [x1, #0xaa0]
     be4:      	mov	x0, #0xc4               ; =196
     be8:      	str	x0, [x1, #0xaa8]
     bec:      	mov	x0, #0xc5               ; =197
     bf0:      	str	x0, [x1, #0xab0]
     bf4:      	mov	x0, #0xc6               ; =198
     bf8:      	str	x0, [x1, #0xab8]
     bfc:      	mov	x0, #0xc7               ; =199
     c00:      	str	x0, [x1, #0xac0]
     c04:      	ldur	x9, [sp, #0x10]
     c08:      	str	x9, [x1, #0xac8]
     c0c:      	mov	x0, #0xc9               ; =201
     c10:      	str	x0, [x1, #0xad0]
     c14:      	mov	x0, #0xca               ; =202
     c18:      	str	x0, [x1, #0xad8]
     c1c:      	mov	x0, #0xcb               ; =203
     c20:      	str	x0, [x1, #0xae0]
     c24:      	mov	x0, #0xcc               ; =204
     c28:      	str	x0, [x1, #0xae8]
     c2c:      	mov	x0, #0xcd               ; =205
     c30:      	str	x0, [x1, #0xaf0]
     c34:      	mov	x0, #0xce               ; =206
     c38:      	str	x0, [x1, #0xaf8]
     c3c:      	mov	x0, #0xcf               ; =207
     c40:      	str	x0, [x1, #0xb00]
     c44:      	mov	x0, #0xd0               ; =208
     c48:      	str	x0, [x1, #0xb08]
     c4c:      	mov	x0, #0xd1               ; =209
     c50:      	str	x0, [x1, #0xb10]
     c54:      	mov	x0, #0xd2               ; =210
     c58:      	str	x0, [x1, #0xb18]
     c5c:      	mov	x0, #0xd3               ; =211
     c60:      	str	x0, [x1, #0xb20]
     c64:      	mov	x0, #0xd4               ; =212
     c68:      	str	x0, [x1, #0xb28]
     c6c:      	mov	x0, #0xd5               ; =213
     c70:      	str	x0, [x1, #0xb30]
     c74:      	mov	x0, #0xd6               ; =214
     c78:      	str	x0, [x1, #0xb38]
     c7c:      	mov	x0, #0xd7               ; =215
     c80:      	str	x0, [x1, #0xb40]
     c84:      	mov	x0, #0xd8               ; =216
     c88:      	str	x0, [x1, #0xb48]
     c8c:      	mov	x0, #0xd9               ; =217
     c90:      	str	x0, [x1, #0xb50]
     c94:      	mov	x0, #0xda               ; =218
     c98:      	str	x0, [x1, #0xb58]
     c9c:      	mov	x0, #0xdb               ; =219
     ca0:      	str	x0, [x1, #0xb60]
     ca4:      	mov	x0, #0xdc               ; =220
     ca8:      	str	x0, [x1, #0xb68]
     cac:      	mov	x0, #0xdd               ; =221
     cb0:      	str	x0, [x1, #0xb70]
     cb4:      	mov	x0, #0xde               ; =222
     cb8:      	str	x0, [x1, #0xb78]
     cbc:      	mov	x0, #0xdf               ; =223
     cc0:      	str	x0, [x1, #0xb80]
     cc4:      	mov	x0, #0xe0               ; =224
     cc8:      	str	x0, [x1, #0xb88]
     ccc:      	mov	x0, #0xe1               ; =225
     cd0:      	str	x0, [x1, #0xb90]
     cd4:      	mov	x0, #0xe2               ; =226
     cd8:      	str	x0, [x1, #0xb98]
     cdc:      	ldur	x2, [sp, #0x40]
     ce0:      	str	x2, [x1, #0xba0]
     ce4:      	mov	x0, #0xe4               ; =228
     ce8:      	str	x0, [x1, #0xba8]
     cec:      	mov	x0, #0xe5               ; =229
     cf0:      	str	x0, [x1, #0xbb0]
     cf4:      	mov	x0, #0xe6               ; =230
     cf8:      	str	x0, [x1, #0xbb8]
     cfc:      	mov	x0, #0xe7               ; =231
     d00:      	str	x0, [x1, #0xbc0]
     d04:      	mov	x0, #0xe8               ; =232
     d08:      	str	x0, [x1, #0xbc8]
     d0c:      	mov	x0, #0xe9               ; =233
     d10:      	str	x0, [x1, #0xbd0]
     d14:      	mov	x0, #0xea               ; =234
     d18:      	str	x0, [x1, #0xbd8]
     d1c:      	mov	x0, #0xeb               ; =235
     d20:      	str	x0, [x1, #0xbe0]
     d24:      	mov	x0, #0xec               ; =236
     d28:      	str	x0, [x1, #0xbe8]
     d2c:      	mov	x0, #0xed               ; =237
     d30:      	str	x0, [x1, #0xbf0]
     d34:      	mov	x0, #0xee               ; =238
     d38:      	str	x0, [x1, #0xbf8]
     d3c:      	mov	x2, #0xef               ; =239
     d40:      	str	x2, [x1, #0xc00]
     d44:      	mov	x2, #0xf0               ; =240
     d48:      	str	x2, [x1, #0xc08]
     d4c:      	mov	x3, #0xf1               ; =241
     d50:      	str	x3, [x1, #0xc10]
     d54:      	mov	x4, #0xf2               ; =242
     d58:      	str	x4, [x1, #0xc18]
     d5c:      	mov	x5, #0xf3               ; =243
     d60:      	str	x5, [x1, #0xc20]
     d64:      	mov	x6, #0xf4               ; =244
     d68:      	str	x6, [x1, #0xc28]
     d6c:      	mov	x7, #0xf5               ; =245
     d70:      	str	x7, [x1, #0xc30]
     d74:      	mov	x8, #0xf6               ; =246
     d78:      	str	x8, [x1, #0xc38]
     d7c:      	mov	x9, #0xf7               ; =247
     d80:      	str	x9, [x1, #0xc40]
     d84:      	mov	x10, #0xf8              ; =248
     d88:      	str	x10, [x1, #0xc48]
     d8c:      	mov	x11, #0xf9              ; =249
     d90:      	str	x11, [x1, #0xc50]
     d94:      	mov	x12, #0xfa              ; =250
     d98:      	str	x12, [x1, #0xc58]
     d9c:      	mov	x13, #0xfb              ; =251
     da0:      	str	x13, [x1, #0xc60]
     da4:      	mov	x14, #0xfc              ; =252
     da8:      	str	x14, [x1, #0xc68]
     dac:      	mov	x15, #0xfd              ; =253
     db0:      	str	x15, [x1, #0xc70]
     db4:      	mov	x0, #0xfe               ; =254
     db8:      	str	x0, [x1, #0xc78]
     dbc:      	mov	w16, #0xa2a0            ; =41632
     dc0:      	movk	w16, #0x1, lsl #16
     dc4:      	ldr	x6, [sp, x16, sxtx]
     dc8:      	str	x6, [x1, #0xc80]
     dcc:      	ldur	x13, [sp, #0xf0]
     dd0:      	str	x13, [x1, #0xcf8]
     dd4:      	ldur	x8, [sp, #0xe8]
     dd8:      	str	x8, [x1, #0xd00]
     ddc:      	mov	w16, #0xa2d8            ; =41688
     de0:      	movk	w16, #0x1, lsl #16
     de4:      	str	x1, [sp, x16, sxtx]
     de8:      	ldur	x0, [sp]
     dec:      	mov	x1, #0x0                ; =0
     df0:      	ldur	x0, [sp, #0x8]
     df4:      	str	x1, [x0, #0x48]
     df8:      	mov	w16, #0xa2c8            ; =41672
     dfc:      	movk	w16, #0x1, lsl #16
     e00:      	ldr	x19, [sp, x16, sxtx]
     e04:      	mov	w16, #0xa2d0            ; =41680
     e08:      	movk	w16, #0x1, lsl #16
     e0c:      	ldr	x0, [sp, x16, sxtx]
     e10:      	blr	x19
     e14:      	mov	x1, #0x2                ; =2
     e18:      	cmp	x0, #0x0
     e1c:      	b.ne	0xd2c48 <_mech_canonical_program_entry_v1+0xd2c48>
     e20:      	b	0xe30 <_mech_canonical_program_entry_v1+0xe30>
     e24:      	mov	w16, #0xa2d8            ; =41688
     e28:      	movk	w16, #0x1, lsl #16
     e2c:      	str	x1, [sp, x16, sxtx]
     e30:      	ldur	x0, [sp]
     e34:      	mov	x1, #0x1                ; =1
     e38:      	ldur	x0, [sp, #0x8]
     e3c:      	str	x1, [x0, #0x48]
     e40:      	ldur	x2, [sp, #0xf8]
     e44:      	cmp	x2, #0x0
     e48:      	b.eq	0xd2c4c <_mech_canonical_program_entry_v1+0xd2c4c>
     e4c:      	mov	x1, #0x1                ; =1
     e50:      	mov	w16, #0xa2c8            ; =41672
     e54:      	movk	w16, #0x1, lsl #16
     e58:      	ldr	x5, [sp, x16, sxtx]
     e5c:      	mov	w16, #0xa2d0            ; =41680
     e60:      	movk	w16, #0x1, lsl #16
     e64:      	ldr	x0, [sp, x16, sxtx]
     e68:      	blr	x5
     e6c:      	mov	x1, #0x2                ; =2
     e70:      	cmp	x0, #0x0
     e74:      	b.ne	0xd2c50 <_mech_canonical_program_entry_v1+0xd2c50>
     e78:      	ldur	x0, [sp]
     e7c:      	mov	x1, #0x2                ; =2
     e80:      	ldur	x0, [sp, #0x8]
     e84:      	str	x1, [x0, #0x48]
     e88:      	mov	w16, #0xa2c8            ; =41672
     e8c:      	movk	w16, #0x1, lsl #16
     e90:      	ldr	x15, [sp, x16, sxtx]
     e94:      	mov	w16, #0x3698            ; =13976
     e98:      	movk	w16, #0x1, lsl #16
     e9c:      	str	x1, [sp, x16, sxtx]
     ea0:      	mov	w16, #0xa2d0            ; =41680
     ea4:      	movk	w16, #0x1, lsl #16
     ea8:      	ldr	x0, [sp, x16, sxtx]
     eac:      	blr	x15
     eb0:      	cmp	x0, #0x0
     eb4:      	b.ne	0xd2c54 <_mech_canonical_program_entry_v1+0xd2c54>
     eb8:      	ldur	x0, [sp]
     ebc:      	mov	x0, #0x5                ; =5
     ec0:      	ldur	x12, [sp, #0x8]
     ec4:      	str	x0, [x12, #0x48]
     ec8:      	mov	w16, #0xa2b8            ; =41656
     ecc:      	movk	w16, #0x1, lsl #16
     ed0:      	ldr	x6, [sp, x16, sxtx]
     ed4:      	mov	w16, #0xa2a0            ; =41632
     ed8:      	movk	w16, #0x1, lsl #16
     edc:      	str	x0, [sp, x16, sxtx]
     ee0:      	ldr	x0, [x6]
     ee4:      	cmp	x0, #0x0
     ee8:      	b.ne	0xf2c <_mech_canonical_program_entry_v1+0xf2c>
     eec:      	mov	w16, #0xa2c8            ; =41672
     ef0:      	movk	w16, #0x1, lsl #16
     ef4:      	ldr	x2, [sp, x16, sxtx]
     ef8:      	mov	w16, #0xa2d0            ; =41680
     efc:      	movk	w16, #0x1, lsl #16
     f00:      	ldr	x0, [sp, x16, sxtx]
     f04:      	mov	w16, #0xa2a0            ; =41632
     f08:      	movk	w16, #0x1, lsl #16
     f0c:      	ldr	x1, [sp, x16, sxtx]
     f10:      	blr	x2
     f14:      	mov	x10, #0x2               ; =2
     f18:      	mov	w16, #0x3698            ; =13976
     f1c:      	movk	w16, #0x1, lsl #16
     f20:      	str	x10, [sp, x16, sxtx]
     f24:      	cmp	x0, #0x0
     f28:      	b.ne	0xd2c58 <_mech_canonical_program_entry_v1+0xd2c58>
     f2c:      	ldur	x19, [sp]
     f30:      	mov	x0, #0x6                ; =6
     f34:      	ldur	x1, [sp, #0x8]
     f38:      	str	x0, [x1, #0x48]
     f3c:      	mov	w16, #0xa2c8            ; =41672
     f40:      	movk	w16, #0x1, lsl #16
     f44:      	ldr	x2, [sp, x16, sxtx]
     f48:      	mov	w16, #0xa298            ; =41624
     f4c:      	movk	w16, #0x1, lsl #16
     f50:      	str	x0, [sp, x16, sxtx]
     f54:      	mov	w16, #0xa2d0            ; =41680
     f58:      	movk	w16, #0x1, lsl #16
     f5c:      	ldr	x0, [sp, x16, sxtx]
     f60:      	mov	w16, #0xa298            ; =41624
     f64:      	movk	w16, #0x1, lsl #16
     f68:      	ldr	x1, [sp, x16, sxtx]
     f6c:      	blr	x2
     f70:      	mov	x1, #0x2                ; =2
     f74:      	mov	w16, #0x3698            ; =13976
     f78:      	movk	w16, #0x1, lsl #16
     f7c:      	str	x1, [sp, x16, sxtx]
     f80:      	cmp	x0, #0x0
     f84:      	b.ne	0xd2c5c <_mech_canonical_program_entry_v1+0xd2c5c>
     f88:      	mov	x0, #0x3                ; =3
     f8c:      	mov	w16, #0x3698            ; =13976
     f90:      	movk	w16, #0x1, lsl #16
     f94:      	str	x0, [sp, x16, sxtx]
     f98:      	mov	w16, #0xa2a8            ; =41640
     f9c:      	movk	w16, #0x1, lsl #16
     fa0:      	ldr	x0, [sp, x16, sxtx]
     fa4:      	cmp	x0, #0x0
     fa8:      	b.eq	0xd2c60 <_mech_canonical_program_entry_v1+0xd2c60>
     fac:      	mov	x5, #0x0                ; =0
     fb0:      	mov	w16, #0xa2b0            ; =41648
     fb4:      	movk	w16, #0x1, lsl #16
     fb8:      	ldr	x20, [sp, x16, sxtx]
     fbc:      	str	x5, [x20]
     fc0:      	mov	x4, #0x1                ; =1
     fc4:      	mov	w16, #0xa2c0            ; =41664
     fc8:      	movk	w16, #0x1, lsl #16
     fcc:      	ldr	x21, [sp, x16, sxtx]
     fd0:      	mov	w16, #0xa2d0            ; =41680
     fd4:      	movk	w16, #0x1, lsl #16
     fd8:      	ldr	x0, [sp, x16, sxtx]
     fdc:      	mov	w16, #0xa298            ; =41624
     fe0:      	movk	w16, #0x1, lsl #16
     fe4:      	ldr	x1, [sp, x16, sxtx]
     fe8:      	mov	x3, x20
     fec:      	mov	w16, #0xa2b8            ; =41656
     ff0:      	movk	w16, #0x1, lsl #16
     ff4:      	ldr	x6, [sp, x16, sxtx]
     ff8:      	mov	x2, x5
     ffc:      	blr	x21
    1000:      	mov	x1, #0x2                ; =2
    1004:      	mov	w16, #0x3698            ; =13976
    1008:      	movk	w16, #0x1, lsl #16
    100c:      	str	x1, [sp, x16, sxtx]
    1010:      	cmp	x0, #0x0
    1014:      	b.ne	0xd2c64 <_mech_canonical_program_entry_v1+0xd2c64>
    1018:      	mov	w16, #0xa2b8            ; =41656
    101c:      	movk	w16, #0x1, lsl #16
    1020:      	ldr	x6, [sp, x16, sxtx]
    1024:      	ldr	x0, [x6]
    1028:      	str	x0, [x19, #0xfb8]
    102c:      	ldur	x19, [sp]
    1030:      	mov	x0, #0x7                ; =7
    1034:      	ldur	x1, [sp, #0x8]
    1038:      	str	x0, [x1, #0x48]
    103c:      	mov	w16, #0xa2c8            ; =41672
    1040:      	movk	w16, #0x1, lsl #16
    1044:      	ldr	x2, [sp, x16, sxtx]
    1048:      	mov	w16, #0xa290            ; =41616
    104c:      	movk	w16, #0x1, lsl #16
    1050:      	str	x0, [sp, x16, sxtx]
    1054:      	mov	w16, #0xa2d0            ; =41680
    1058:      	movk	w16, #0x1, lsl #16
    105c:      	ldr	x0, [sp, x16, sxtx]
    1060:      	mov	w16, #0xa290            ; =41616
    1064:      	movk	w16, #0x1, lsl #16
    1068:      	ldr	x1, [sp, x16, sxtx]
    106c:      	blr	x2
    1070:      	mov	x1, #0x2                ; =2
    1074:      	mov	w16, #0x3698            ; =13976
    1078:      	movk	w16, #0x1, lsl #16
    107c:      	str	x1, [sp, x16, sxtx]
    1080:      	cmp	x0, #0x0
    1084:      	b.ne	0xd2c68 <_mech_canonical_program_entry_v1+0xd2c68>
    1088:      	ldr	x2, [x19, #0xfb8]
    108c:      	ldr	x3, [x19, #0x2c8]
    1090:      	cmp	x2, x3
    1094:      	cset	x3, ls
    1098:      	uxtb	w3, w3
    109c:      	str	x3, [x19, #0xfc0]
    10a0:      	ldur	x19, [sp]
    10a4:      	mov	x20, #0x8               ; =8
    10a8:      	ldur	x0, [sp, #0x8]
    10ac:      	str	x20, [x0, #0x48]
    10b0:      	mov	w16, #0xa2b8            ; =41656
    10b4:      	movk	w16, #0x1, lsl #16
    10b8:      	ldr	x6, [sp, x16, sxtx]
    10bc:      	ldr	x6, [x6]
    10c0:      	cmp	x6, #0x0
    10c4:      	b.eq	0x10d8 <_mech_canonical_program_entry_v1+0x10d8>
    10c8:      	mov	w16, #0xa288            ; =41608
    10cc:      	movk	w16, #0x1, lsl #16
    10d0:      	str	x20, [sp, x16, sxtx]
    10d4:      	b	0x111c <_mech_canonical_program_entry_v1+0x111c>
    10d8:      	mov	w16, #0xa2c8            ; =41672
    10dc:      	movk	w16, #0x1, lsl #16
    10e0:      	ldr	x2, [sp, x16, sxtx]
    10e4:      	mov	w16, #0xa2d0            ; =41680
    10e8:      	movk	w16, #0x1, lsl #16
    10ec:      	ldr	x0, [sp, x16, sxtx]
    10f0:      	mov	x1, x20
    10f4:      	blr	x2
    10f8:      	mov	w16, #0xa288            ; =41608
    10fc:      	movk	w16, #0x1, lsl #16
    1100:      	str	x20, [sp, x16, sxtx]
    1104:      	mov	x4, #0x2                ; =2
    1108:      	mov	w16, #0x3698            ; =13976
    110c:      	movk	w16, #0x1, lsl #16
    1110:      	str	x4, [sp, x16, sxtx]
    1114:      	cmp	x0, #0x0
    1118:      	b.ne	0xd2c6c <_mech_canonical_program_entry_v1+0xd2c6c>
    111c:      	ldr	x13, [x19, #0xfc0]
    1120:      	ldr	x14, [x19, #0xd00]
    1124:      	cmp	x13, x14
    1128:      	b.eq	0xd2c70 <_mech_canonical_program_entry_v1+0xd2c70>
    112c:      	ldur	x19, [sp]
    1130:      	mov	x20, #0xa               ; =10
    1134:      	ldur	x0, [sp, #0x8]
    1138:      	str	x20, [x0, #0x48]
    113c:      	mov	w16, #0xa2b8            ; =41656
    1140:      	movk	w16, #0x1, lsl #16
    1144:      	ldr	x6, [sp, x16, sxtx]
    1148:      	ldr	x0, [x6]
    114c:      	cmp	x0, #0x0
    1150:      	b.eq	0x1164 <_mech_canonical_program_entry_v1+0x1164>
    1154:      	mov	w16, #0xa280            ; =41600
    1158:      	movk	w16, #0x1, lsl #16
    115c:      	str	x20, [sp, x16, sxtx]
    1160:      	b	0x11a8 <_mech_canonical_program_entry_v1+0x11a8>
    1164:      	mov	w16, #0xa2c8            ; =41672
    1168:      	movk	w16, #0x1, lsl #16
    116c:      	ldr	x2, [sp, x16, sxtx]
    1170:      	mov	w16, #0xa2d0            ; =41680
    1174:      	movk	w16, #0x1, lsl #16
    1178:      	ldr	x0, [sp, x16, sxtx]
    117c:      	mov	x1, x20
    1180:      	blr	x2
    1184:      	mov	w16, #0xa280            ; =41600
    1188:      	movk	w16, #0x1, lsl #16
    118c:      	str	x20, [sp, x16, sxtx]
    1190:      	mov	x1, #0x2                ; =2
    1194:      	mov	w16, #0x3698            ; =13976
    1198:      	movk	w16, #0x1, lsl #16
    119c:      	str	x1, [sp, x16, sxtx]
    11a0:      	cmp	x0, #0x0
    11a4:      	b.ne	0xd2c74 <_mech_canonical_program_entry_v1+0xd2c74>
    11a8:      	ldr	x0, [x19, #0xfc0]
    11ac:      	ldr	x1, [x19, #0xcf8]
    11b0:      	cmp	x0, x1
    11b4:      	b.eq	0x1214 <_mech_canonical_program_entry_v1+0x1214>
    11b8:      	ldur	x0, [sp]
    11bc:      	mov	x1, #0x65               ; =101
    11c0:      	ldur	x0, [sp, #0x8]
    11c4:      	str	x1, [x0, #0x48]
    11c8:      	mov	w16, #0xa2c8            ; =41672
    11cc:      	movk	w16, #0x1, lsl #16
    11d0:      	ldr	x2, [sp, x16, sxtx]
    11d4:      	mov	w16, #0xa2d0            ; =41680
    11d8:      	movk	w16, #0x1, lsl #16
    11dc:      	ldr	x0, [sp, x16, sxtx]
    11e0:      	blr	x2
    11e4:      	mov	x1, #0x2                ; =2
    11e8:      	mov	w16, #0x3698            ; =13976
    11ec:      	movk	w16, #0x1, lsl #16
    11f0:      	str	x1, [sp, x16, sxtx]
    11f4:      	cmp	x0, #0x0
    11f8:      	b.ne	0xd2c78 <_mech_canonical_program_entry_v1+0xd2c78>
    11fc:      	mov	x0, #0x4                ; =4
    1200:      	mov	w16, #0x3698            ; =13976
    1204:      	movk	w16, #0x1, lsl #16
    1208:      	str	x0, [sp, x16, sxtx]
    120c:      	ldur	x0, [sp, #0x8]
    1210:      	b	0xb400b0 <_mech_canonical_program_entry_v1+0xb400b0>
    1214:      	ldur	x0, [sp]
    1218:      	mov	x1, #0x66               ; =102
    121c:      	ldur	x0, [sp, #0x8]
    1220:      	str	x1, [x0, #0x48]
    1224:      	mov	w16, #0xa2b8            ; =41656
    1228:      	movk	w16, #0x1, lsl #16
    122c:      	ldr	x6, [sp, x16, sxtx]
    1230:      	ldr	x0, [x6]
    1234:      	cmp	x0, #0x0
    1238:      	b.ne	0x1270 <_mech_canonical_program_entry_v1+0x1270>
    123c:      	mov	w16, #0xa2c8            ; =41672
    1240:      	movk	w16, #0x1, lsl #16
    1244:      	ldr	x4, [sp, x16, sxtx]
    1248:      	mov	w16, #0xa2d0            ; =41680
    124c:      	movk	w16, #0x1, lsl #16
    1250:      	ldr	x0, [sp, x16, sxtx]
    1254:      	blr	x4
    1258:      	mov	x1, #0x2                ; =2
    125c:      	mov	w16, #0x3698            ; =13976
    1260:      	movk	w16, #0x1, lsl #16
    1264:      	str	x1, [sp, x16, sxtx]
    1268:      	cmp	x0, #0x0
    126c:      	b.ne	0xd2c7c <_mech_canonical_program_entry_v1+0xd2c7c>
    1270:      	ldur	x19, [sp]
    1274:      	mov	x1, #0x67               ; =103
    1278:      	ldur	x0, [sp, #0x8]
    127c:      	str	x1, [x0, #0x48]
    1280:      	mov	w16, #0xa2c8            ; =41672
    1284:      	movk	w16, #0x1, lsl #16
    1288:      	ldr	x15, [sp, x16, sxtx]
    128c:      	mov	x20, x1
    1290:      	mov	w16, #0xa2d0            ; =41680
    1294:      	movk	w16, #0x1, lsl #16
    1298:      	ldr	x0, [sp, x16, sxtx]
    129c:      	blr	x15
    12a0:      	mov	x1, #0x2                ; =2
    12a4:      	mov	w16, #0x3698            ; =13976
    12a8:      	movk	w16, #0x1, lsl #16
    12ac:      	str	x1, [sp, x16, sxtx]
    12b0:      	cmp	x0, #0x0
    12b4:      	b.ne	0xd2c80 <_mech_canonical_program_entry_v1+0xd2c80>
    12b8:      	mov	x0, #0x3                ; =3
    12bc:      	mov	w16, #0x3698            ; =13976
    12c0:      	movk	w16, #0x1, lsl #16
    12c4:      	str	x0, [sp, x16, sxtx]
    12c8:      	mov	w16, #0xa2a8            ; =41640
    12cc:      	movk	w16, #0x1, lsl #16
    12d0:      	ldr	x0, [sp, x16, sxtx]
    12d4:      	cmp	x0, #0x0
    12d8:      	b.eq	0xd2c84 <_mech_canonical_program_entry_v1+0xd2c84>
    12dc:      	mov	x5, #0x0                ; =0
    12e0:      	mov	w16, #0xa2b0            ; =41648
    12e4:      	movk	w16, #0x1, lsl #16
    12e8:      	ldr	x12, [sp, x16, sxtx]
    12ec:      	str	x5, [x12]
    12f0:      	mov	x4, #0x1                ; =1
    12f4:      	mov	x1, x20
    12f8:      	mov	w16, #0xa2c0            ; =41664
    12fc:      	movk	w16, #0x1, lsl #16
    1300:      	ldr	x12, [sp, x16, sxtx]
    1304:      	mov	w16, #0xa2d0            ; =41680
    1308:      	movk	w16, #0x1, lsl #16
    130c:      	ldr	x0, [sp, x16, sxtx]
    1310:      	mov	w16, #0xa2b0            ; =41648
    1314:      	movk	w16, #0x1, lsl #16
    1318:      	ldr	x3, [sp, x16, sxtx]
    131c:      	mov	w16, #0xa2b8            ; =41656
    1320:      	movk	w16, #0x1, lsl #16
    1324:      	ldr	x6, [sp, x16, sxtx]
    1328:      	mov	x2, x5
    132c:      	blr	x12
    1330:      	mov	x14, #0x2               ; =2
    1334:      	mov	w16, #0x3698            ; =13976
    1338:      	movk	w16, #0x1, lsl #16
    133c:      	str	x14, [sp, x16, sxtx]
    1340:      	cmp	x0, #0x0
    1344:      	b.ne	0xd2c88 <_mech_canonical_program_entry_v1+0xd2c88>
    1348:      	mov	w16, #0xa2b8            ; =41656
    134c:      	movk	w16, #0x1, lsl #16
    1350:      	ldr	x6, [sp, x16, sxtx]
    1354:      	ldr	x0, [x6]
    1358:      	str	x0, [x19, #0x1150]
    135c:      	ldur	x0, [sp]
    1360:      	mov	x1, #0x68               ; =104
    1364:      	ldur	x0, [sp, #0x8]
    1368:      	str	x1, [x0, #0x48]
    136c:      	mov	w16, #0xa2c8            ; =41672
    1370:      	movk	w16, #0x1, lsl #16
    1374:      	ldr	x2, [sp, x16, sxtx]
    1378:      	mov	x19, x1
    137c:      	mov	w16, #0xa2d0            ; =41680
    1380:      	movk	w16, #0x1, lsl #16
    1384:      	ldr	x0, [sp, x16, sxtx]
    1388:      	blr	x2
    138c:      	mov	x1, #0x2                ; =2
    1390:      	mov	w16, #0x3698            ; =13976
    1394:      	movk	w16, #0x1, lsl #16
    1398:      	str	x1, [sp, x16, sxtx]
    139c:      	cmp	x0, #0x0
    13a0:      	b.ne	0xd2c8c <_mech_canonical_program_entry_v1+0xd2c8c>
    13a4:      	mov	x0, #0x2                ; =2
    13a8:      	mov	w16, #0x3698            ; =13976
    13ac:      	movk	w16, #0x1, lsl #16
    13b0:      	str	x0, [sp, x16, sxtx]
    13b4:      	mov	x5, #0x0                ; =0
    13b8:      	mov	x1, x19
    13bc:      	mov	w16, #0xa2c0            ; =41664
    13c0:      	movk	w16, #0x1, lsl #16
    13c4:      	ldr	x12, [sp, x16, sxtx]
    13c8:      	mov	w16, #0xa2d0            ; =41680
    13cc:      	movk	w16, #0x1, lsl #16
    13d0:      	ldr	x0, [sp, x16, sxtx]
    13d4:      	mov	w16, #0x3698            ; =13976
    13d8:      	movk	w16, #0x1, lsl #16
    13dc:      	ldr	x2, [sp, x16, sxtx]
    13e0:      	mov	w16, #0xa2b8            ; =41656
    13e4:      	movk	w16, #0x1, lsl #16
    13e8:      	ldr	x6, [sp, x16, sxtx]
    13ec:      	mov	x3, x5
    13f0:      	mov	x4, x5
    13f4:      	blr	x12
    13f8:      	cmp	x0, #0x0
    13fc:      	b.ne	0xd2c90 <_mech_canonical_program_entry_v1+0xd2c90>
    1400:      	ldur	x0, [sp]
    1404:      	mov	x1, #0x6a               ; =106
    1408:      	ldur	x0, [sp, #0x8]
    140c:      	str	x1, [x0, #0x48]
    1410:      	mov	w16, #0xa2c8            ; =41672
    1414:      	movk	w16, #0x1, lsl #16
    1418:      	ldr	x2, [sp, x16, sxtx]
    141c:      	mov	w16, #0xa2d0            ; =41680
    1420:      	movk	w16, #0x1, lsl #16
    1424:      	ldr	x0, [sp, x16, sxtx]
    1428:      	blr	x2
    142c:      	mov	x1, #0x2                ; =2
    1430:      	mov	w16, #0x3698            ; =13976
    1434:      	movk	w16, #0x1, lsl #16
    1438:      	str	x1, [sp, x16, sxtx]
    143c:      	cmp	x0, #0x0
    1440:      	b.ne	0xd2c94 <_mech_canonical_program_entry_v1+0xd2c94>
    1444:      	ldur	x19, [sp]
    1448:      	mov	x1, #0x6b               ; =107
    144c:      	ldur	x0, [sp, #0x8]
    1450:      	str	x1, [x0, #0x48]
    1454:      	mov	w16, #0xa2c8            ; =41672
    1458:      	movk	w16, #0x1, lsl #16
    145c:      	ldr	x2, [sp, x16, sxtx]
    1460:      	mov	x20, x1
    1464:      	mov	w16, #0xa2d0            ; =41680
    1468:      	movk	w16, #0x1, lsl #16
    146c:      	ldr	x0, [sp, x16, sxtx]
    1470:      	blr	x2
    1474:      	mov	x1, #0x2                ; =2
    1478:      	mov	w16, #0x3698            ; =13976
    147c:      	movk	w16, #0x1, lsl #16
    1480:      	str	x1, [sp, x16, sxtx]
    1484:      	cmp	x0, #0x0
    1488:      	b.ne	0xd2c98 <_mech_canonical_program_entry_v1+0xd2c98>
    148c:      	ldr	x3, [x19, #0x218]
    1490:      	ldr	x4, [x19, #0x378]
    1494:      	mov	x0, #0x2                ; =2
    1498:      	mov	w16, #0x3698            ; =13976
    149c:      	movk	w16, #0x1, lsl #16
    14a0:      	str	x0, [sp, x16, sxtx]
    14a4:      	mov	x5, #0x0                ; =0
    14a8:      	mov	x1, x20
    14ac:      	mov	w16, #0xa2c0            ; =41664
    14b0:      	movk	w16, #0x1, lsl #16
    14b4:      	ldr	x12, [sp, x16, sxtx]
    14b8:      	mov	w16, #0xa2d0            ; =41680
    14bc:      	movk	w16, #0x1, lsl #16
    14c0:      	ldr	x0, [sp, x16, sxtx]
    14c4:      	mov	w16, #0x3698            ; =13976
    14c8:      	movk	w16, #0x1, lsl #16
    14cc:      	ldr	x2, [sp, x16, sxtx]
    14d0:      	mov	w16, #0xa2b8            ; =41656
    14d4:      	movk	w16, #0x1, lsl #16
    14d8:      	ldr	x6, [sp, x16, sxtx]
    14dc:      	blr	x12
    14e0:      	cmp	x0, #0x0
    14e4:      	b.ne	0xd2c9c <_mech_canonical_program_entry_v1+0xd2c9c>
    14e8:      	ldur	x19, [sp]
    14ec:      	mov	x1, #0x6c               ; =108
    14f0:      	ldur	x0, [sp, #0x8]
    14f4:      	str	x1, [x0, #0x48]
    14f8:      	mov	w16, #0xa2c8            ; =41672
    14fc:      	movk	w16, #0x1, lsl #16
    1500:      	ldr	x2, [sp, x16, sxtx]
    1504:      	mov	x20, x1
    1508:      	mov	w16, #0xa2d0            ; =41680
    150c:      	movk	w16, #0x1, lsl #16
    1510:      	ldr	x0, [sp, x16, sxtx]
    1514:      	blr	x2
    1518:      	mov	x9, #0x2                ; =2
    151c:      	mov	w16, #0x3698            ; =13976
    1520:      	movk	w16, #0x1, lsl #16
    1524:      	str	x9, [sp, x16, sxtx]
    1528:      	cmp	x0, #0x0
    152c:      	b.ne	0xd2ca0 <_mech_canonical_program_entry_v1+0xd2ca0>
    1530:      	mov	x0, #0x2                ; =2
    1534:      	mov	w16, #0x3698            ; =13976
    1538:      	movk	w16, #0x1, lsl #16
    153c:      	str	x0, [sp, x16, sxtx]
    1540:      	mov	x5, #0x0                ; =0
    1544:      	mov	x1, x20
    1548:      	mov	w16, #0xa2c0            ; =41664
    154c:      	movk	w16, #0x1, lsl #16
    1550:      	ldr	x12, [sp, x16, sxtx]
    1554:      	mov	w16, #0xa2d0            ; =41680
    1558:      	movk	w16, #0x1, lsl #16
    155c:      	ldr	x0, [sp, x16, sxtx]
    1560:      	mov	w16, #0x3698            ; =13976
    1564:      	movk	w16, #0x1, lsl #16
    1568:      	ldr	x2, [sp, x16, sxtx]
    156c:      	mov	w16, #0xa2b8            ; =41656
    1570:      	movk	w16, #0x1, lsl #16
    1574:      	ldr	x6, [sp, x16, sxtx]
    1578:      	mov	x3, x5
    157c:      	mov	x4, x5
    1580:      	blr	x12
    1584:      	cmp	x0, #0x0
    1588:      	b.ne	0xd2ca4 <_mech_canonical_program_entry_v1+0xd2ca4>
    158c:      	mov	w16, #0xa2b8            ; =41656
    1590:      	movk	w16, #0x1, lsl #16
    1594:      	ldr	x6, [sp, x16, sxtx]
    1598:      	ldr	x0, [x6]
    159c:      	mov	w1, #0xbde8             ; =48616
    15a0:      	movk	w1, #0x2, lsl #16
    15a4:      	str	x0, [x19, x1]
    15a8:      	mov	x19, #0x6d              ; =109
    15ac:      	ldur	x20, [sp]
    15b0:      	ldur	x0, [sp, #0x8]
    15b4:      	str	x19, [x0, #0x48]
    15b8:      	mov	w16, #0xa2c8            ; =41672
    15bc:      	movk	w16, #0x1, lsl #16
    15c0:      	ldr	x2, [sp, x16, sxtx]
    15c4:      	mov	w16, #0xa2d0            ; =41680
    15c8:      	movk	w16, #0x1, lsl #16
    15cc:      	ldr	x0, [sp, x16, sxtx]
    15d0:      	mov	x1, x19
    15d4:      	blr	x2
    15d8:      	mov	x1, #0x2                ; =2
    15dc:      	mov	w16, #0x3698            ; =13976
    15e0:      	movk	w16, #0x1, lsl #16
    15e4:      	str	x1, [sp, x16, sxtx]
    15e8:      	cmp	x0, #0x0
    15ec:      	b.ne	0xd2ca8 <_mech_canonical_program_entry_v1+0xd2ca8>
    15f0:      	ldr	x4, [x20, #0x378]
    15f4:      	mov	w0, #0xbde8             ; =48616
    15f8:      	movk	w0, #0x2, lsl #16
    15fc:      	ldr	x0, [x20, x0]
    1600:      	add	x1, x4, #0x1
    1604:      	cmp	x0, x1
    1608:      	b.ne	0x1690 <_mech_canonical_program_entry_v1+0x1690>
    160c:      	ldr	x3, [x20, #0x488]
    1610:      	mov	x0, #0x2                ; =2
    1614:      	mov	w16, #0x3698            ; =13976
    1618:      	movk	w16, #0x1, lsl #16
    161c:      	str	x0, [sp, x16, sxtx]
    1620:      	mov	x5, #0x0                ; =0
    1624:      	mov	w16, #0xa2c0            ; =41664
    1628:      	movk	w16, #0x1, lsl #16
    162c:      	ldr	x12, [sp, x16, sxtx]
    1630:      	mov	w16, #0xa2d0            ; =41680
    1634:      	movk	w16, #0x1, lsl #16
    1638:      	ldr	x0, [sp, x16, sxtx]
    163c:      	mov	x1, x19
    1640:      	mov	w16, #0x3698            ; =13976
    1644:      	movk	w16, #0x1, lsl #16
    1648:      	ldr	x2, [sp, x16, sxtx]
    164c:      	mov	w16, #0xa2b8            ; =41656
    1650:      	movk	w16, #0x1, lsl #16
    1654:      	ldr	x6, [sp, x16, sxtx]
    1658:      	blr	x12
    165c:      	cmp	x0, #0x0
    1660:      	b.ne	0xd2cac <_mech_canonical_program_entry_v1+0xd2cac>
    1664:      	mov	w16, #0xa2b8            ; =41656
    1668:      	movk	w16, #0x1, lsl #16
    166c:      	ldr	x6, [sp, x16, sxtx]
    1670:      	ldr	x0, [x6]
    1674:      	mov	x1, #0x3                ; =3
    1678:      	mov	w16, #0x3698            ; =13976
    167c:      	movk	w16, #0x1, lsl #16
    1680:      	str	x1, [sp, x16, sxtx]
    1684:      	cmp	x0, #0x1
    1688:      	b.hi	0xd2cb0 <_mech_canonical_program_entry_v1+0xd2cb0>
    168c:      	cbnz	x0, 0x1998 <_mech_canonical_program_entry_v1+0x1998>
    1690:      	mov	w0, #0xbde8             ; =48616
    1694:      	movk	w0, #0x2, lsl #16
    1698:      	ldr	x0, [x20, x0]
    169c:      	cmp	x0, #0x0
    16a0:      	b.eq	0x19a8 <_mech_canonical_program_entry_v1+0x19a8>
    16a4:      	ldur	x20, [sp]
    16a8:      	mov	x1, #0x6e               ; =110
    16ac:      	ldur	x0, [sp, #0x8]
    16b0:      	str	x1, [x0, #0x48]
    16b4:      	mov	w16, #0xa2c8            ; =41672
    16b8:      	movk	w16, #0x1, lsl #16
    16bc:      	ldr	x14, [sp, x16, sxtx]
    16c0:      	mov	x21, x1
    16c4:      	mov	w16, #0xa2d0            ; =41680
    16c8:      	movk	w16, #0x1, lsl #16
    16cc:      	ldr	x0, [sp, x16, sxtx]
    16d0:      	blr	x14
    16d4:      	mov	x6, #0x2                ; =2
    16d8:      	mov	w16, #0x3698            ; =13976
    16dc:      	movk	w16, #0x1, lsl #16
    16e0:      	str	x6, [sp, x16, sxtx]
    16e4:      	cmp	x0, #0x0
    16e8:      	b.ne	0xd2cb4 <_mech_canonical_program_entry_v1+0xd2cb4>
    16ec:      	mov	x0, #0x2                ; =2
    16f0:      	mov	w16, #0x3698            ; =13976
    16f4:      	movk	w16, #0x1, lsl #16
    16f8:      	str	x0, [sp, x16, sxtx]
    16fc:      	mov	x5, #0x0                ; =0
    1700:      	mov	x1, x21
    1704:      	mov	w16, #0xa2c0            ; =41664
    1708:      	movk	w16, #0x1, lsl #16
    170c:      	ldr	x12, [sp, x16, sxtx]
    1710:      	mov	w16, #0xa2d0            ; =41680
    1714:      	movk	w16, #0x1, lsl #16
    1718:      	ldr	x0, [sp, x16, sxtx]
    171c:      	mov	w16, #0x3698            ; =13976
    1720:      	movk	w16, #0x1, lsl #16
    1724:      	ldr	x2, [sp, x16, sxtx]
    1728:      	mov	w16, #0xa2b8            ; =41656
    172c:      	movk	w16, #0x1, lsl #16
    1730:      	ldr	x6, [sp, x16, sxtx]
    1734:      	mov	x3, x5
    1738:      	mov	x4, x5
    173c:      	blr	x12
    1740:      	cmp	x0, #0x0
    1744:      	b.ne	0xd2cb8 <_mech_canonical_program_entry_v1+0xd2cb8>
    1748:      	mov	w16, #0xa2b8            ; =41656
    174c:      	movk	w16, #0x1, lsl #16
    1750:      	ldr	x6, [sp, x16, sxtx]
    1754:      	ldr	x0, [x6]
    1758:      	str	x0, [x20, #0x1168]
    175c:      	ldur	x0, [sp]
    1760:      	mov	x1, #0x70               ; =112
    1764:      	ldur	x0, [sp, #0x8]
    1768:      	str	x1, [x0, #0x48]
    176c:      	mov	w16, #0xa2c8            ; =41672
    1770:      	movk	w16, #0x1, lsl #16
    1774:      	ldr	x2, [sp, x16, sxtx]
    1778:      	mov	w16, #0xa2d0            ; =41680
    177c:      	movk	w16, #0x1, lsl #16
    1780:      	ldr	x0, [sp, x16, sxtx]
    1784:      	blr	x2
    1788:      	mov	x1, #0x2                ; =2
    178c:      	mov	w16, #0x3698            ; =13976
    1790:      	movk	w16, #0x1, lsl #16
    1794:      	str	x1, [sp, x16, sxtx]
    1798:      	cmp	x0, #0x0
    179c:      	b.ne	0xd2cbc <_mech_canonical_program_entry_v1+0xd2cbc>
    17a0:      	ldur	x20, [sp]
    17a4:      	mov	x1, #0x71               ; =113
    17a8:      	ldur	x0, [sp, #0x8]
    17ac:      	str	x1, [x0, #0x48]
    17b0:      	mov	w16, #0xa2b8            ; =41656
    17b4:      	movk	w16, #0x1, lsl #16
    17b8:      	ldr	x6, [sp, x16, sxtx]
    17bc:      	ldr	x0, [x6]
    17c0:      	cmp	x0, #0x0
    17c4:      	b.ne	0x17fc <_mech_canonical_program_entry_v1+0x17fc>
    17c8:      	mov	w16, #0xa2c8            ; =41672
    17cc:      	movk	w16, #0x1, lsl #16
    17d0:      	ldr	x2, [sp, x16, sxtx]
    17d4:      	mov	w16, #0xa2d0            ; =41680
    17d8:      	movk	w16, #0x1, lsl #16
    17dc:      	ldr	x0, [sp, x16, sxtx]
    17e0:      	blr	x2
    17e4:      	mov	x1, #0x2                ; =2
    17e8:      	mov	w16, #0x3698            ; =13976
    17ec:      	movk	w16, #0x1, lsl #16
    17f0:      	str	x1, [sp, x16, sxtx]
    17f4:      	cmp	x0, #0x0
    17f8:      	b.ne	0xd2cc0 <_mech_canonical_program_entry_v1+0xd2cc0>
    17fc:      	ldr	x0, [x20, #0x1168]
