"""Root-authorized candidate tests and serial fresh cohorts after accepted parent tests."""
from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;c=json.loads((r/'configuration.json').read_text());assert c['initialized']
for path,count in [('engine-parent/projection.json',12),('engine-parent/shape.json',6),('core-focused/selected.json',2),('engine-parent/borrowed-turn.json',4)]:
 receipt=json.loads((r/path).read_text());assert receipt['exit']==0 and receipt.get('executed_tests',receipt.get('passed_tests'))==count,(path,receipt)
for name,args in [('engine-focused.py',['after']),('units.py',[]),('run-cohorts.py',[]),('qualify-all.py',[])]:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name),*args],check=True);print('DONE',name,flush=True)
