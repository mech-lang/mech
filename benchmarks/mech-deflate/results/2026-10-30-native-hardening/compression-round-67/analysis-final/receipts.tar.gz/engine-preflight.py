"""Compile current tests with parent/candidate meter code in scratch; never rewrite the checkout."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-private-numeric-lifetime-round66-20261031')
phase=sys.argv[1];assert phase in ['parent','after'];c=json.loads((r/'configuration.json').read_text());assert c['initialized']
p=r/'engine-preflight';p.mkdir();base=json.loads((old/'engine-after/build.json').read_text())
libs=json.loads((old/'final-libraries.json').read_text());dep=old/'variants/after/dependency'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only',c['baseline_checkpoint'],'--','src','hosts/gpu/src'],cwd=w,text=True).splitlines();assert set(changed)<=set(c['production_files']+c['test_files']),(changed,c)
# Stage the complete Engine source so lexical module/include paths stay valid.
# Root fixtures are retained through a read-only symlink. No production file is
# temporarily replaced, and no simultaneous build sees a parent/candidate mix.
checkout=p/'source';stage=checkout/'src/engine';stage.parent.mkdir(parents=True)
shutil.copytree(w/'src/engine',stage,ignore=shutil.ignore_patterns('target','.git'))
(checkout/'tests').symlink_to(w/'tests',target_is_directory=True)
if phase=='parent':
 for relative in c['production_files']:
  target=checkout/relative;target.write_bytes(subprocess.check_output(['git','show',c['baseline_checkpoint']+':'+relative],cwd=w))
if phase=='parent':
 target=checkout/'src/engine/src/memory_planner/turn.rs'
 target.write_text(target.read_text()+"\n#[cfg(all(test, feature = \"string\"))]\npub(crate) fn plan_single_call_turn_memory(original: &mech_core::CallMemoryPlan, node: NodeId, facts: &TurnMemoryFacts) -> Result<TurnMemoryPlan, MemoryPlanError> {\n let mut call=original.clone(); for allocation in &mut call.allocations { if let MemoryObjectOwner::NodeScratch { node: owner, .. }=&mut allocation.owner { *owner=node; } }\n let plan=ProgramMemoryPlan { call_nodes: Box::new([node]), allocations: call.allocations.clone(), budget_limits: call.target.limits, calls: Box::new([call]), ..Default::default() }; plan_turn_memory(&plan,node,facts)\n}\n")
source_pins={relative:hashlib.sha256((checkout/relative).read_bytes()).hexdigest() for relative in c['production_files']+c['test_files']}
for relative in c['production_files']+c['test_files']:(p/Path(relative).name).write_bytes((checkout/relative).read_bytes())
cmd=base['command'].copy();assert cmd[-2]=='-o';cmd[-3]=str(stage/'src/lib.rs');cmd[-1]=str(p/'engine-tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  name,path=a.split('=',1);target=Path(libs[name]['path']) if name in libs else dep/Path(path).name;assert target.exists(),target;cmd[i]=name+'='+str(target)
for i in range(len(cmd)-1,0,-1):
 if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
cmd[1:1]=['-L','dependency='+str(dep)];env=base['environment'].copy();env['CARGO_MANIFEST_DIR']=str(w/'src/engine')
def run(label,command,count=None,inventory=False):
 started=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':env,'exit':q.returncode,'seconds':time.monotonic()-started,'phase':phase,'test_source_head':head,'baseline_checkpoint':c['baseline_checkpoint'],'production_source_sha256':source_pins,'libraries':libs,'scope':'Current tests in scratch Engine source. Parent production files are exact R66 source; a test-only shim exposes the former owned one-call adapter to the new parity tests. Candidate uses its real borrowed projection. Current candidate Engine unit crate against unchanged Core/Syntax and external dependencies from R66, before release compilation. This does not link the old Engine library into itself. No benchmark observations.'}
 if count is not None:
  if inventory:row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout);row['passed_tests']=int(m[1]) if m else None;row['failed_tests']=int(m[2]) if m else None;row['executed_tests']=int(m[1])+int(m[2]) if m else None;observed=row['executed_tests']
  row['expected_tests']=count
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),p.name+'-'+label,*map(str,[p/(label+'.'+ext) for ext in ['json','stdout','stderr']]),str(r/'engine-preflight.py'),*map(str,[p/Path(relative).name for relative in c['production_files']+c['test_files']])],cwd=w,check=True)
 print(phase,label,q.returncode,row.get('executed_tests',row.get('listed_tests')),flush=True)
 if q.returncode:print(q.stdout[-5000:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if count is not None:assert observed==count,(label,row)
run('build',cmd)
selections=[('borrowed-turn','memory_planner::turn::tests::',4)]
for label,selection,count in selections:
 run(label+'-inventory',[cmd[-1],selection,'--list'],count,True)
 run(label,[cmd[-1],selection,'--nocapture','--test-threads=1'],count)
print('ENGINE_FOCUSED_COMPLETE',phase,flush=True)
