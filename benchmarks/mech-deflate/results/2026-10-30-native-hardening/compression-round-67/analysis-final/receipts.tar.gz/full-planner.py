"""Execute the complete retained Engine planner inventory on parent and candidate."""
from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent
for phase in ['parent','after']:
 p=r/('engine-'+phase);base=json.loads((p/'build.json').read_text());unit=p/'engine-tests'
 for label,flags in [('full-planner-inventory',['--list']),('full-planner',['--nocapture','--test-threads=1'])]:
  command=[str(unit),'memory_planner::',*flags];at=time.monotonic();q=subprocess.run(command,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
  row={key:base[key] for key in ['test_source_head','baseline_checkpoint','phase','production_source_sha256','libraries']}
  row.update(command=command,exit=q.returncode,seconds=time.monotonic()-at,expected_tests=19,scope='Actual complete Engine memory_planner inventory and execution. Same freshly built executable/dependencies as focused tests; not merely a filter count.')
  if label.endswith('inventory'):row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));count=row['listed_tests']
  else:
   m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;count=row['executed_tests']
  (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  print(phase,label,q.returncode,count,flush=True);q.check_returncode();assert count==19,row
