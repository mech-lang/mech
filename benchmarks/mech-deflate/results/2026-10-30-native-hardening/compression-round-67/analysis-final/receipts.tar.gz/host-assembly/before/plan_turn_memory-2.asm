
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010254dfa4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_>:
10254dfa4:     	sub	sp, sp, #0xd0
10254dfa8:     	stp	x22, x21, [sp, #0xa0]
10254dfac:     	stp	x20, x19, [sp, #0xb0]
10254dfb0:     	stp	x29, x30, [sp, #0xc0]
10254dfb4:     	add	x29, sp, #0xc0
10254dfb8:     	mov	x19, x8
10254dfbc:     	ldp	q0, q1, [x0, #0x20]
10254dfc0:     	stp	q0, q1, [sp, #0x50]
10254dfc4:     	ldr	q0, [x0, #0x40]
10254dfc8:     	str	q0, [sp, #0x70]
10254dfcc:     	ldp	q1, q0, [x0]
10254dfd0:     	stp	q1, q0, [sp, #0x30]
10254dfd4:     	mov	x8, sp
10254dfd8:     	add	x0, sp, #0x30
10254dfdc:     	bl	0x102a0c878 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_>
10254dfe0:     	ldr	x21, [sp, #0x10]
10254dfe4:     	cbz	x21, 0x10254e05c <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0xb8>
10254dfe8:     	ldr	x20, [sp, #0x8]
10254dfec:     	sub	x8, x29, #0x21
10254dff0:     	str	x8, [sp, #0x30]
10254dff4:     	cmp	x21, #0x1
10254dff8:     	b.ne	0x10254e090 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0xec>
10254dffc:     	ldr	x22, [sp]
10254e000:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10254e004:     	mov	w0, #0x2a0              ; =672
10254e008:     	mov	w1, #0x8                ; =8
10254e00c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
10254e010:     	cbz	x0, 0x10254e0b0 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0x10c>
10254e014:     	str	xzr, [x0]
10254e018:     	strh	wzr, [x0, #0x29e]
10254e01c:     	stp	x0, xzr, [sp, #0x18]
10254e020:     	str	xzr, [sp, #0x28]
10254e024:     	add	x8, x20, x21, lsl #6
10254e028:     	mov	w9, #0x3                ; =3
10254e02c:     	strb	w9, [sp, #0x30]
10254e030:     	stp	x20, x20, [sp, #0x70]
10254e034:     	stp	x22, x8, [sp, #0x80]
10254e038:     	add	x0, sp, #0x18
10254e03c:     	add	x1, sp, #0x30
10254e040:     	add	x2, sp, #0x28
10254e044:     	bl	0x1024e8bd0 <__RINvMNtNtNtCsgKscDXrlV49_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBW_6marker5OwnedTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1F_11memory_plan5model22CurrentMemoryFootprintNtB1g_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterB1y_B2Q_INtNtNtB9_3vec9into_iter8IntoIterTB1y_B2Q_EEENtNtB9_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
10254e048:     	ldp	x8, x9, [sp, #0x18]
10254e04c:     	ldr	x10, [sp, #0x28]
10254e050:     	stp	x8, x9, [x19]
10254e054:     	str	x10, [x19, #0x10]
10254e058:     	b	0x10254e07c <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0xd8>
10254e05c:     	str	xzr, [x19]
10254e060:     	str	xzr, [x19, #0x10]
10254e064:     	ldr	x8, [sp]
10254e068:     	cbz	x8, 0x10254e07c <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0xd8>
10254e06c:     	ldr	x0, [sp, #0x8]
10254e070:     	lsl	x1, x8, #6
10254e074:     	mov	w2, #0x8                ; =8
10254e078:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10254e07c:     	ldp	x29, x30, [sp, #0xc0]
10254e080:     	ldp	x20, x19, [sp, #0xb0]
10254e084:     	ldp	x22, x21, [sp, #0xa0]
10254e088:     	add	sp, sp, #0xd0
10254e08c:     	ret
10254e090:     	cmp	x21, #0x15
10254e094:     	b.hs	0x10254e0c0 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0x11c>
10254e098:     	add	x3, sp, #0x30
10254e09c:     	mov	x0, x20
10254e0a0:     	mov	x1, x21
10254e0a4:     	mov	w2, #0x1                ; =1
10254e0a8:     	bl	0x1028ee808 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_>
10254e0ac:     	b	0x10254dffc <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0x58>
10254e0b0:     	mov	w0, #0x8                ; =8
10254e0b4:     	mov	w1, #0x2a0              ; =672
10254e0b8:     	bl	0x103a03a70 <__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error>
10254e0bc:     	brk	#0x1
10254e0c0:     	add	x2, sp, #0x30
10254e0c4:     	mov	x0, x20
10254e0c8:     	mov	x1, x21
10254e0cc:     	bl	0x1029e25d8 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>
10254e0d0:     	b	0x10254dffc <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0x58>
10254e0d4:     	ldr	x22, [sp]
10254e0d8:     	cbnz	x22, 0x10254e0e4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0x140>
10254e0dc:     	b	0x10254e0fc <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0x158>
10254e0e0:     	cbz	x22, 0x10254e0fc <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_+0x158>
10254e0e4:     	lsl	x1, x22, #6
10254e0e8:     	mov	x19, x0
10254e0ec:     	mov	x0, x20
10254e0f0:     	mov	w2, #0x8                ; =8
10254e0f4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10254e0f8:     	mov	x0, x19
10254e0fc:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
