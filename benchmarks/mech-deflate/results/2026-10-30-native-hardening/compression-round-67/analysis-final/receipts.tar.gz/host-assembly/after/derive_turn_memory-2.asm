
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102788834 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>:
102788834:     	stp	x26, x25, [sp, #-0x50]!
102788838:     	stp	x24, x23, [sp, #0x10]
10278883c:     	stp	x22, x21, [sp, #0x20]
102788840:     	stp	x20, x19, [sp, #0x30]
102788844:     	stp	x29, x30, [sp, #0x40]
102788848:     	add	x29, sp, #0x40
10278884c:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
102788850:     	str	xzr, [sp]
102788854:     	mov	x19, x2
102788858:     	sub	x8, x1, x1, lsr #1
10278885c:     	mov	w9, #0xe848             ; =59464
102788860:     	movk	w9, #0x1, lsl #16
102788864:     	cmp	x1, x9
102788868:     	csel	x9, x1, x9, lo
10278886c:     	cmp	x9, x8
102788870:     	csel	x24, x9, x8, hi
102788874:     	mov	w9, #0x30               ; =48
102788878:     	cmp	x24, #0x30
10278887c:     	csel	x23, x24, x9, hi
102788880:     	cmp	x24, #0x41
102788884:     	b.lo	0x1027888d8 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xa4>
102788888:     	mov	x22, #0x0               ; =0
10278888c:     	lsl	x21, x23, #6
102788890:     	lsr	x8, x8, #58
102788894:     	cbnz	x8, 0x102788928 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
102788898:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
10278889c:     	cmp	x21, x8
1027888a0:     	b.hi	0x102788928 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1027888a4:     	mov	x20, x1
1027888a8:     	mov	x25, x0
1027888ac:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027888b0:     	mov	w22, #0x8               ; =8
1027888b4:     	mov	x0, x21
1027888b8:     	mov	w1, #0x8                ; =8
1027888bc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027888c0:     	mov	x1, x20
1027888c4:     	mov	x20, x0
1027888c8:     	cbz	x0, 0x102788928 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1027888cc:     	mov	x0, x25
1027888d0:     	mov	x3, x23
1027888d4:     	b	0x1027888e0 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xac>
1027888d8:     	mov	x20, sp
1027888dc:     	mov	w3, #0x40               ; =64
1027888e0:     	cmp	x1, #0x41
1027888e4:     	cset	w4, lo
1027888e8:     	mov	x2, x20
1027888ec:     	mov	x5, x19
1027888f0:     	bl	0x1029eae7c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_>
1027888f4:     	cmp	x24, #0x40
1027888f8:     	b.ls	0x10278890c <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xd8>
1027888fc:     	lsl	x1, x23, #6
102788900:     	mov	x0, x20
102788904:     	mov	w2, #0x8                ; =8
102788908:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10278890c:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
102788910:     	ldp	x29, x30, [sp, #0x40]
102788914:     	ldp	x20, x19, [sp, #0x30]
102788918:     	ldp	x22, x21, [sp, #0x20]
10278891c:     	ldp	x24, x23, [sp, #0x10]
102788920:     	ldp	x26, x25, [sp], #0x50
102788924:     	ret
102788928:     	mov	x0, x22
10278892c:     	mov	x1, x21
102788930:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102788934:     	mov	x19, x0
102788938:     	cmp	x24, #0x40
10278893c:     	b.ls	0x102788950 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0x11c>
102788940:     	lsl	x1, x23, #6
102788944:     	mov	x0, x20
102788948:     	mov	w2, #0x8                ; =8
10278894c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102788950:     	mov	x0, x19
102788954:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
