
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027bdb1c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_>:
1027bdb1c:     	sub	sp, sp, #0x70
1027bdb20:     	stp	x26, x25, [sp, #0x20]
1027bdb24:     	stp	x24, x23, [sp, #0x30]
1027bdb28:     	stp	x22, x21, [sp, #0x40]
1027bdb2c:     	stp	x20, x19, [sp, #0x50]
1027bdb30:     	stp	x29, x30, [sp, #0x60]
1027bdb34:     	add	x29, sp, #0x60
1027bdb38:     	mov	x19, x8
1027bdb3c:     	ldp	x8, x21, [x0]
1027bdb40:     	cmp	x8, x21
1027bdb44:     	b.eq	0x1027bdc84 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x168>
1027bdb48:     	ldr	x22, [x0, #0x10]
1027bdb4c:     	add	x23, x8, #0x1c0
1027bdb50:     	b	0x1027bdb68 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x4c>
1027bdb54:     	sub	x8, x23, #0x1c0
1027bdb58:     	add	x23, x23, #0x1c0
1027bdb5c:     	add	x8, x8, #0x1c0
1027bdb60:     	cmp	x8, x21
1027bdb64:     	b.eq	0x1027bdc84 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x168>
1027bdb68:     	ldur	w20, [x23, #-0x30]
1027bdb6c:     	cbz	w20, 0x1027bdb54 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
1027bdb70:     	ldurb	w8, [x23, #-0x10]
1027bdb74:     	and	w8, w8, #0x6
1027bdb78:     	cmp	w8, #0x2
1027bdb7c:     	b.ne	0x1027bdb54 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
1027bdb80:     	ldur	w8, [x23, #-0x48]
1027bdb84:     	cmp	w8, #0x1
1027bdb88:     	b.ne	0x1027bdb54 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
1027bdb8c:     	ldr	w8, [x22]
1027bdb90:     	ldur	w9, [x23, #-0x44]
1027bdb94:     	cmp	w9, w8
1027bdb98:     	b.ne	0x1027bdb54 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
1027bdb9c:     	str	x23, [x0]
1027bdba0:     	ldur	x24, [x23, #-0x2c]
1027bdba4:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027bdba8:     	mov	w0, #0x30               ; =48
1027bdbac:     	mov	w1, #0x4                ; =4
1027bdbb0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027bdbb4:     	cbz	x0, 0x1027bdcac <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x190>
1027bdbb8:     	str	w20, [x0]
1027bdbbc:     	stur	x24, [x0, #0x4]
1027bdbc0:     	mov	w8, #0x4                ; =4
1027bdbc4:     	stp	x8, x0, [sp, #0x8]
1027bdbc8:     	mov	w8, #0x1                ; =1
1027bdbcc:     	str	x8, [sp, #0x18]
1027bdbd0:     	cmp	x23, x21
1027bdbd4:     	b.eq	0x1027bdc70 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x154>
1027bdbd8:     	mov	w20, #0x1               ; =1
1027bdbdc:     	mov	w24, #0xc               ; =12
1027bdbe0:     	add	x23, x23, #0x1c0
1027bdbe4:     	b	0x1027bdbf4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xd8>
1027bdbe8:     	cmp	x23, x21
1027bdbec:     	add	x23, x23, #0x1c0
1027bdbf0:     	b.eq	0x1027bdc70 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x154>
1027bdbf4:     	ldur	w25, [x23, #-0x30]
1027bdbf8:     	cbz	w25, 0x1027bdbe8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
1027bdbfc:     	ldurb	w8, [x23, #-0x10]
1027bdc00:     	and	w8, w8, #0x6
1027bdc04:     	cmp	w8, #0x2
1027bdc08:     	b.ne	0x1027bdbe8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
1027bdc0c:     	ldur	w8, [x23, #-0x48]
1027bdc10:     	cmp	w8, #0x1
1027bdc14:     	b.ne	0x1027bdbe8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
1027bdc18:     	ldr	w8, [x22]
1027bdc1c:     	ldur	w9, [x23, #-0x44]
1027bdc20:     	cmp	w9, w8
1027bdc24:     	b.ne	0x1027bdbe8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
1027bdc28:     	ldur	x26, [x23, #-0x2c]
1027bdc2c:     	ldr	x8, [sp, #0x8]
1027bdc30:     	cmp	x20, x8
1027bdc34:     	b.ne	0x1027bdc54 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x138>
1027bdc38:     	add	x0, sp, #0x8
1027bdc3c:     	mov	x1, x20
1027bdc40:     	mov	w2, #0x1                ; =1
1027bdc44:     	mov	w3, #0x4                ; =4
1027bdc48:     	mov	w4, #0xc                ; =12
1027bdc4c:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027bdc50:     	ldr	x0, [sp, #0x10]
1027bdc54:     	madd	x8, x20, x24, x0
1027bdc58:     	str	w25, [x8]
1027bdc5c:     	stur	x26, [x8, #0x4]
1027bdc60:     	add	x20, x20, #0x1
1027bdc64:     	str	x20, [sp, #0x18]
1027bdc68:     	cmp	x23, x21
1027bdc6c:     	b.ne	0x1027bdbe0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xc4>
1027bdc70:     	ldur	q0, [sp, #0x8]
1027bdc74:     	str	q0, [x19]
1027bdc78:     	ldr	x8, [sp, #0x18]
1027bdc7c:     	str	x8, [x19, #0x10]
1027bdc80:     	b	0x1027bdc90 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x174>
1027bdc84:     	mov	w8, #0x4                ; =4
1027bdc88:     	stp	xzr, x8, [x19]
1027bdc8c:     	str	xzr, [x19, #0x10]
1027bdc90:     	ldp	x29, x30, [sp, #0x60]
1027bdc94:     	ldp	x20, x19, [sp, #0x50]
1027bdc98:     	ldp	x22, x21, [sp, #0x40]
1027bdc9c:     	ldp	x24, x23, [sp, #0x30]
1027bdca0:     	ldp	x26, x25, [sp, #0x20]
1027bdca4:     	add	sp, sp, #0x70
1027bdca8:     	ret
1027bdcac:     	mov	w0, #0x4                ; =4
1027bdcb0:     	mov	w1, #0x30               ; =48
1027bdcb4:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027bdcb8:     	mov	x19, x0
1027bdcbc:     	ldr	x8, [sp, #0x8]
1027bdcc0:     	cbz	x8, 0x1027bdcd8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x1bc>
1027bdcc4:     	ldr	x0, [sp, #0x10]
1027bdcc8:     	add	x8, x8, x8, lsl #1
1027bdccc:     	lsl	x1, x8, #2
1027bdcd0:     	mov	w2, #0x4                ; =4
1027bdcd4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027bdcd8:     	mov	x0, x19
1027bdcdc:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
