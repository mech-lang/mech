
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a1ebe0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_>:
102a1ebe0:     	sub	sp, sp, #0x70
102a1ebe4:     	stp	x24, x23, [sp, #0x30]
102a1ebe8:     	stp	x22, x21, [sp, #0x40]
102a1ebec:     	stp	x20, x19, [sp, #0x50]
102a1ebf0:     	stp	x29, x30, [sp, #0x60]
102a1ebf4:     	add	x29, sp, #0x60
102a1ebf8:     	ldr	x23, [x0]
102a1ebfc:     	ldr	x22, [x1]
102a1ec00:     	ldr	x20, [x23]
102a1ec04:     	ldrb	w8, [x22, #0x10]
102a1ec08:     	add	x19, x22, #0x14
102a1ec0c:     	add	x21, x20, #0xac
102a1ec10:     	sub	w9, w8, #0x2
102a1ec14:     	cmp	w9, #0x3
102a1ec18:     	b.hi	0x102a1ec60 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x80>
102a1ec1c:     	cmp	w8, #0x4
102a1ec20:     	cset	w9, eq
102a1ec24:     	ldr	w10, [x20, #0xa8]
102a1ec28:     	tst	w9, w10
102a1ec2c:     	csel	x9, x21, x19, ne
102a1ec30:     	ldr	w9, [x9]
102a1ec34:     	ldr	x10, [x23, #0x8]
102a1ec38:     	ldr	w10, [x10]
102a1ec3c:     	cmp	w9, w10
102a1ec40:     	b.ne	0x102a1ec60 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x80>
102a1ec44:     	mov	w0, #0x1                ; =1
102a1ec48:     	ldp	x29, x30, [sp, #0x60]
102a1ec4c:     	ldp	x20, x19, [sp, #0x50]
102a1ec50:     	ldp	x22, x21, [sp, #0x40]
102a1ec54:     	ldp	x24, x23, [sp, #0x30]
102a1ec58:     	add	sp, sp, #0x70
102a1ec5c:     	ret
102a1ec60:     	ldr	x10, [x23, #0x10]
102a1ec64:     	ldr	x9, [x10]
102a1ec68:     	cbz	x9, 0x102a1eccc <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xec>
102a1ec6c:     	ldr	x10, [x10, #0x8]
102a1ec70:     	ldr	w11, [x22, #0x50]
102a1ec74:     	add	x13, x9, #0x8
102a1ec78:     	ldrh	w14, [x9, #0x36]
102a1ec7c:     	lsl	x15, x14, #2
102a1ec80:     	mov	x12, #-0x1              ; =-1
102a1ec84:     	cbz	x15, 0x102a1ecb4 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xd4>
102a1ec88:     	ldr	w16, [x13], #0x4
102a1ec8c:     	cmp	w11, w16
102a1ec90:     	cset	w16, hi
102a1ec94:     	csinv	w16, w16, wzr, hs
102a1ec98:     	add	x12, x12, #0x1
102a1ec9c:     	sub	x15, x15, #0x4
102a1eca0:     	and	w16, w16, #0xff
102a1eca4:     	cmp	w16, #0x1
102a1eca8:     	b.eq	0x102a1ec84 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xa4>
102a1ecac:     	cbz	w16, 0x102a1ec44 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x64>
102a1ecb0:     	b	0x102a1ecb8 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xd8>
102a1ecb4:     	mov	x12, x14
102a1ecb8:     	cbz	x10, 0x102a1eccc <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xec>
102a1ecbc:     	add	x9, x9, x12, lsl #3
102a1ecc0:     	ldr	x9, [x9, #0x38]
102a1ecc4:     	sub	x10, x10, #0x1
102a1ecc8:     	b	0x102a1ec74 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x94>
102a1eccc:     	ldrb	w9, [x22, #0x58]
102a1ecd0:     	cmp	w9, #0x1
102a1ecd4:     	b.ne	0x102a1ed2c <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x14c>
102a1ecd8:     	ldr	x9, [x23, #0x18]
102a1ecdc:     	ldrb	w10, [x22, #0x13]
102a1ece0:     	strb	w10, [sp, #0xb]
102a1ece4:     	ldurh	w10, [x22, #0x11]
102a1ece8:     	sturh	w10, [sp, #0x9]
102a1ecec:     	ldr	w10, [x20, #0xa8]
102a1ecf0:     	cmp	w8, #0x4
102a1ecf4:     	cset	w11, eq
102a1ecf8:     	tst	w11, w10
102a1ecfc:     	csel	x10, x21, x19, ne
102a1ed00:     	ldr	w10, [x10]
102a1ed04:     	strb	w8, [sp, #0x8]
102a1ed08:     	str	w10, [sp, #0xc]
102a1ed0c:     	ldr	x0, [x9]
102a1ed10:     	cbz	x0, 0x102a1ed2c <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x14c>
102a1ed14:     	ldr	x1, [x9, #0x8]
102a1ed18:     	add	x8, sp, #0x10
102a1ed1c:     	add	x2, sp, #0x8
102a1ed20:     	bl	0x10254c704 <__RINvMs_NtNtNtCsgKscDXrlV49_5alloc11collections5btree6searchINtNtB7_4node7NodeRefNtNtBY_6marker5ImmutNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB7_7set_val9SetValZSTNtB1i_14LeafOrInternalE11search_treeB1A_ECs1qJAwyMG1lC_11mech_engine>
102a1ed24:     	ldr	w8, [sp, #0x10]
102a1ed28:     	tbz	w8, #0x0, 0x102a1ec44 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x64>
102a1ed2c:     	ldr	x9, [x23, #0x20]
102a1ed30:     	ldr	x8, [x9]
102a1ed34:     	cbz	x8, 0x102a1ed98 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x1b8>
102a1ed38:     	ldr	x9, [x9, #0x8]
102a1ed3c:     	ldr	w10, [x22, #0x50]
102a1ed40:     	add	x12, x8, #0x8
102a1ed44:     	ldrh	w13, [x8, #0x36]
102a1ed48:     	lsl	x14, x13, #2
102a1ed4c:     	mov	x11, #-0x1              ; =-1
102a1ed50:     	cbz	x14, 0x102a1ed80 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x1a0>
102a1ed54:     	ldr	w15, [x12], #0x4
102a1ed58:     	cmp	w10, w15
102a1ed5c:     	cset	w15, hi
102a1ed60:     	csinv	w15, w15, wzr, hs
102a1ed64:     	add	x11, x11, #0x1
102a1ed68:     	sub	x14, x14, #0x4
102a1ed6c:     	and	w15, w15, #0xff
102a1ed70:     	cmp	w15, #0x1
102a1ed74:     	b.eq	0x102a1ed50 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x170>
102a1ed78:     	cbz	w15, 0x102a1ec44 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x64>
102a1ed7c:     	b	0x102a1ed84 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x1a4>
102a1ed80:     	mov	x11, x13
102a1ed84:     	cbz	x9, 0x102a1ed98 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x1b8>
102a1ed88:     	add	x8, x8, x11, lsl #3
102a1ed8c:     	ldr	x8, [x8, #0x38]
102a1ed90:     	sub	x9, x9, #0x1
102a1ed94:     	b	0x102a1ed40 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x160>
102a1ed98:     	ldrb	w8, [x22, #0x58]
102a1ed9c:     	cmp	w8, #0x6
102a1eda0:     	b.ne	0x102a1ee04 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x224>
102a1eda4:     	ldr	x8, [x23, #0x28]
102a1eda8:     	ldrb	w9, [x22, #0x10]
102a1edac:     	and	w10, w9, #0xff
102a1edb0:     	ldrb	w11, [x22, #0x13]
102a1edb4:     	strb	w11, [sp, #0xb]
102a1edb8:     	ldurh	w11, [x22, #0x11]
102a1edbc:     	sturh	w11, [sp, #0x9]
102a1edc0:     	ldr	w11, [x20, #0xa8]
102a1edc4:     	cmp	w10, #0x4
102a1edc8:     	cset	w10, eq
102a1edcc:     	tst	w11, w10
102a1edd0:     	csel	x10, x21, x19, ne
102a1edd4:     	ldr	w10, [x10]
102a1edd8:     	strb	w9, [sp, #0x8]
102a1eddc:     	str	w10, [sp, #0xc]
102a1ede0:     	ldr	x0, [x8]
102a1ede4:     	cbz	x0, 0x102a1ec48 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x68>
102a1ede8:     	ldr	x1, [x8, #0x8]
102a1edec:     	add	x8, sp, #0x10
102a1edf0:     	add	x2, sp, #0x8
102a1edf4:     	bl	0x10254c704 <__RINvMs_NtNtNtCsgKscDXrlV49_5alloc11collections5btree6searchINtNtB7_4node7NodeRefNtNtBY_6marker5ImmutNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB7_7set_val9SetValZSTNtB1i_14LeafOrInternalE11search_treeB1A_ECs1qJAwyMG1lC_11mech_engine>
102a1edf8:     	ldr	w8, [sp, #0x10]
102a1edfc:     	eor	w0, w8, #0x1
102a1ee00:     	b	0x102a1ec48 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x68>
102a1ee04:     	mov	w0, #0x0                ; =0
102a1ee08:     	b	0x102a1ec48 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x68>
