
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027dcd58 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_>:
1027dcd58:     	stp	x28, x27, [sp, #-0x60]!
1027dcd5c:     	stp	x26, x25, [sp, #0x10]
1027dcd60:     	stp	x24, x23, [sp, #0x20]
1027dcd64:     	stp	x22, x21, [sp, #0x30]
1027dcd68:     	stp	x20, x19, [sp, #0x40]
1027dcd6c:     	stp	x29, x30, [sp, #0x50]
1027dcd70:     	add	x29, sp, #0x50
1027dcd74:     	sub	sp, sp, #0x2e0
1027dcd78:     	str	w4, [sp, #0x1c]
1027dcd7c:     	str	x0, [sp, #0x60]
1027dcd80:     	cmp	x1, #0x2
1027dcd84:     	b.lo	0x1027dd2f4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x59c>
1027dcd88:     	mov	x26, x5
1027dcd8c:     	mov	x19, x1
1027dcd90:     	mov	x8, #0x4000000000000000 ; =4611686018427387904
1027dcd94:     	udiv	x9, x8, x1
1027dcd98:     	mul	x10, x9, x1
1027dcd9c:     	cmp	x10, x8
1027dcda0:     	cinc	x8, x9, ne
1027dcda4:     	str	x8, [sp, #0x28]
1027dcda8:     	cmp	x1, #0x1, lsl #12       ; =0x1000
1027dcdac:     	str	x3, [sp, #0x78]
1027dcdb0:     	str	x2, [sp, #0x68]
1027dcdb4:     	b.hi	0x1027dcdd0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x78>
1027dcdb8:     	sub	x8, x19, x19, lsr #1
1027dcdbc:     	mov	w9, #0x40               ; =64
1027dcdc0:     	cmp	x8, #0x40
1027dcdc4:     	csel	x8, x8, x9, lo
1027dcdc8:     	str	x8, [sp, #0x38]
1027dcdcc:     	b	0x1027dcde0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x88>
1027dcdd0:     	mov	x0, x19
1027dcdd4:     	bl	0x102e89d24 <__RNvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift11sqrt_approx>
1027dcdd8:     	ldr	x3, [sp, #0x78]
1027dcddc:     	str	x0, [sp, #0x38]
1027dcde0:     	mov	x23, #0x0               ; =0
1027dcde4:     	mov	x20, #0x0               ; =0
1027dcde8:     	ldr	x8, [sp, #0x60]
1027dcdec:     	add	x10, x8, #0x82
1027dcdf0:     	sub	x9, x8, #0x20
1027dcdf4:     	stp	x9, x10, [sp, #0x8]
1027dcdf8:     	add	x9, x8, #0x20
1027dcdfc:     	str	x9, [sp]
1027dce00:     	sub	x8, x8, #0x40
1027dce04:     	str	x8, [sp, #0x20]
1027dce08:     	mov	w24, #0x1               ; =1
1027dce0c:     	str	x26, [sp, #0x50]
1027dce10:     	str	x19, [sp, #0x30]
1027dce14:     	subs	x9, x19, x23
1027dce18:     	b.ls	0x1027dce74 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x11c>
1027dce1c:     	ldr	x8, [sp, #0x60]
1027dce20:     	add	x0, x8, x23, lsl #6
1027dce24:     	ldr	x8, [sp, #0x38]
1027dce28:     	cmp	x9, x8
1027dce2c:     	b.hs	0x1027dce88 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x130>
1027dce30:     	ldr	w8, [sp, #0x1c]
1027dce34:     	tbz	w8, #0x0, 0x1027dce98 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x140>
1027dce38:     	cmp	x9, #0x20
1027dce3c:     	mov	w8, #0x20               ; =32
1027dce40:     	csel	x26, x9, x8, lo
1027dce44:     	mov	x1, x26
1027dce48:     	ldr	x2, [sp, #0x68]
1027dce4c:     	ldr	x3, [sp, #0x78]
1027dce50:     	mov	w4, #0x0                ; =0
1027dce54:     	mov	x5, #0x0                ; =0
1027dce58:     	ldr	x6, [sp, #0x50]
1027dce5c:     	bl	0x10235af60 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_>
1027dce60:     	ldr	x3, [sp, #0x78]
1027dce64:     	mov	w8, #0x1                ; =1
1027dce68:     	orr	x11, x8, x26, lsl #1
1027dce6c:     	ldr	x26, [sp, #0x50]
1027dce70:     	b	0x1027dd030 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x2d8>
1027dce74:     	mov	w10, #0x0               ; =0
1027dce78:     	mov	w11, #0x1               ; =1
1027dce7c:     	cmp	x20, #0x2
1027dce80:     	b.hs	0x1027dd058 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x300>
1027dce84:     	b	0x1027dd29c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x544>
1027dce88:     	cmp	x9, #0x2
1027dce8c:     	b.hs	0x1027dceac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x154>
1027dce90:     	mov	x8, x9
1027dce94:     	b	0x1027dd028 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x2d0>
1027dce98:     	ldr	x8, [sp, #0x38]
1027dce9c:     	cmp	x9, x8
1027dcea0:     	csel	x8, x9, x8, lo
1027dcea4:     	lsl	x11, x8, #1
1027dcea8:     	b	0x1027dd030 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x2d8>
1027dceac:     	ldrb	w11, [x0, #0x40]
1027dceb0:     	ldrh	w12, [x0, #0x42]
1027dceb4:     	ldrb	w8, [x0]
1027dceb8:     	ldrh	w10, [x0, #0x2]
1027dcebc:     	cmp	w12, w10
1027dcec0:     	cset	w10, lo
1027dcec4:     	subs	w13, w11, w8
1027dcec8:     	mov	w14, #0xff              ; =255
1027dcecc:     	bics	wzr, w14, w13
1027dced0:     	cset	w13, eq
1027dced4:     	cmp	w11, w8
1027dced8:     	csel	w10, w10, w13, eq
1027dcedc:     	tbz	w10, #0x0, 0x1027dcef4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x19c>
1027dcee0:     	cmp	x9, #0x2
1027dcee4:     	b.ne	0x1027dcf04 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x1ac>
1027dcee8:     	mov	w9, #0x1                ; =1
1027dceec:     	mov	w8, #0x2                ; =2
1027dcef0:     	b	0x1027dcfc4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x26c>
1027dcef4:     	cmp	x9, #0x2
1027dcef8:     	b.ne	0x1027dcf58 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x200>
1027dcefc:     	mov	w8, #0x2                ; =2
1027dcf00:     	b	0x1027dd028 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x2d0>
1027dcf04:     	ldr	x8, [sp, #0x10]
1027dcf08:     	add	x13, x8, x23, lsl #6
1027dcf0c:     	mov	w8, #0x2                ; =2
1027dcf10:     	ldurb	w14, [x13, #-0x2]
1027dcf14:     	ldrh	w15, [x13], #0x40
1027dcf18:     	sub	w16, w14, w11
1027dcf1c:     	cmp	w15, w12
1027dcf20:     	cset	w12, lo
1027dcf24:     	mov	w17, #0xff              ; =255
1027dcf28:     	bics	wzr, w17, w16
1027dcf2c:     	cset	w16, eq
1027dcf30:     	cmp	w14, w11, uxtb
1027dcf34:     	csel	w11, w12, w16, eq
1027dcf38:     	cmp	w11, #0x1
1027dcf3c:     	b.ne	0x1027dcfa8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x250>
1027dcf40:     	add	x8, x8, #0x1
1027dcf44:     	mov	x12, x15
1027dcf48:     	mov	x11, x14
1027dcf4c:     	cmp	x9, x8
1027dcf50:     	b.ne	0x1027dcf10 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x1b8>
1027dcf54:     	b	0x1027dcfa4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x24c>
1027dcf58:     	ldr	x8, [sp, #0x10]
1027dcf5c:     	add	x13, x8, x23, lsl #6
1027dcf60:     	mov	w8, #0x2                ; =2
1027dcf64:     	ldurb	w14, [x13, #-0x2]
1027dcf68:     	ldrh	w15, [x13], #0x40
1027dcf6c:     	sub	w16, w14, w11
1027dcf70:     	cmp	w15, w12
1027dcf74:     	cset	w12, lo
1027dcf78:     	mov	w17, #0xff              ; =255
1027dcf7c:     	bics	wzr, w17, w16
1027dcf80:     	cset	w16, eq
1027dcf84:     	cmp	w14, w11, uxtb
1027dcf88:     	csel	w11, w12, w16, eq
1027dcf8c:     	tbnz	w11, #0x0, 0x1027dcfa8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x250>
1027dcf90:     	add	x8, x8, #0x1
1027dcf94:     	mov	x12, x15
1027dcf98:     	mov	x11, x14
1027dcf9c:     	cmp	x9, x8
1027dcfa0:     	b.ne	0x1027dcf64 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x20c>
1027dcfa4:     	mov	x8, x9
1027dcfa8:     	ldr	x11, [sp, #0x38]
1027dcfac:     	cmp	x8, x11
1027dcfb0:     	b.lo	0x1027dce30 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0xd8>
1027dcfb4:     	lsr	x9, x8, #1
1027dcfb8:     	cmp	x9, #0x0
1027dcfbc:     	csel	w10, wzr, w10, eq
1027dcfc0:     	tbz	w10, #0x0, 0x1027dd028 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x2d0>
1027dcfc4:     	lsl	x11, x23, #6
1027dcfc8:     	add	x10, x11, x8, lsl #6
1027dcfcc:     	ldp	x12, x13, [sp]
1027dcfd0:     	add	x10, x13, x10
1027dcfd4:     	add	x11, x12, x11
1027dcfd8:     	ldur	q0, [x11, #-0x20]
1027dcfdc:     	ldur	q1, [x10, #-0x20]
1027dcfe0:     	stur	q1, [x11, #-0x20]
1027dcfe4:     	stur	q0, [x10, #-0x20]
1027dcfe8:     	ldur	q0, [x11, #-0x10]
1027dcfec:     	ldur	q1, [x10, #-0x10]
1027dcff0:     	stur	q1, [x11, #-0x10]
1027dcff4:     	stur	q0, [x10, #-0x10]
1027dcff8:     	ldr	q0, [x11]
1027dcffc:     	ldr	q1, [x10]
1027dd000:     	str	q1, [x11]
1027dd004:     	str	q0, [x10]
1027dd008:     	ldr	q0, [x11, #0x10]
1027dd00c:     	ldr	q1, [x10, #0x10]
1027dd010:     	str	q1, [x11, #0x10]
1027dd014:     	str	q0, [x10, #0x10]
1027dd018:     	sub	x10, x10, #0x40
1027dd01c:     	add	x11, x11, #0x40
1027dd020:     	sub	x9, x9, #0x1
1027dd024:     	cbnz	x9, 0x1027dcfd8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x280>
1027dd028:     	mov	w9, #0x1                ; =1
1027dd02c:     	orr	x11, x9, x8, lsl #1
1027dd030:     	lsl	x8, x23, #1
1027dd034:     	sub	x9, x8, x24, lsr #1
1027dd038:     	add	x8, x8, x11, lsr #1
1027dd03c:     	ldr	x10, [sp, #0x28]
1027dd040:     	mul	x9, x9, x10
1027dd044:     	mul	x8, x8, x10
1027dd048:     	eor	x8, x8, x9
1027dd04c:     	clz	x10, x8
1027dd050:     	cmp	x20, #0x2
1027dd054:     	b.lo	0x1027dd29c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x544>
1027dd058:     	lsl	x8, x23, #6
1027dd05c:     	ldr	x9, [sp, #0x60]
1027dd060:     	add	x25, x9, x8
1027dd064:     	ldr	x9, [sp, #0x20]
1027dd068:     	add	x8, x9, x8
1027dd06c:     	stp	x8, x11, [sp, #0x40]
1027dd070:     	str	x23, [sp, #0x58]
1027dd074:     	str	x10, [sp, #0x70]
1027dd078:     	b	0x1027dd0a8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x350>
1027dd07c:     	sub	x2, x8, x21
1027dd080:     	mov	x0, x23
1027dd084:     	mov	x1, x21
1027dd088:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027dd08c:     	ldr	x26, [sp, #0x50]
1027dd090:     	ldp	x10, x3, [sp, #0x70]
1027dd094:     	mov	w8, #0x1                ; =1
1027dd098:     	orr	x24, x8, x19, lsl #1
1027dd09c:     	ldr	x23, [sp, #0x58]
1027dd0a0:     	cmp	x22, #0x1
1027dd0a4:     	b.ls	0x1027dd290 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x538>
1027dd0a8:     	sub	x22, x20, #0x1
1027dd0ac:     	sub	x8, x29, #0x9a
1027dd0b0:     	ldrb	w8, [x8, x22]
1027dd0b4:     	cmp	w8, w10
1027dd0b8:     	b.lo	0x1027dd294 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x53c>
1027dd0bc:     	mov	x20, x22
1027dd0c0:     	add	x8, sp, #0x80
1027dd0c4:     	ldr	x8, [x8, x22, lsl #3]
1027dd0c8:     	lsr	x27, x8, #1
1027dd0cc:     	lsr	x28, x24, #1
1027dd0d0:     	orr	w9, w8, w24
1027dd0d4:     	and	x9, x9, #0x1
1027dd0d8:     	add	x19, x27, x28
1027dd0dc:     	cmp	x19, x3
1027dd0e0:     	ccmp	x9, #0x0, #0x0, ls
1027dd0e4:     	b.eq	0x1027dd108 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x3b0>
1027dd0e8:     	sub	x9, x23, x19
1027dd0ec:     	ldr	x10, [sp, #0x60]
1027dd0f0:     	add	x23, x10, x9, lsl #6
1027dd0f4:     	tbz	w8, #0x0, 0x1027dd118 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x3c0>
1027dd0f8:     	tbz	w24, #0x0, 0x1027dd14c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x3f4>
1027dd0fc:     	ldr	x10, [sp, #0x70]
1027dd100:     	cbnz	x28, 0x1027dd180 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x428>
1027dd104:     	b	0x1027dd094 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x33c>
1027dd108:     	lsl	x24, x19, #1
1027dd10c:     	cmp	x22, #0x1
1027dd110:     	b.hi	0x1027dd0a8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x350>
1027dd114:     	b	0x1027dd290 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x538>
1027dd118:     	orr	x8, x27, #0x1
1027dd11c:     	clz	x8, x8
1027dd120:     	lsl	w8, w8, #1
1027dd124:     	eor	w4, w8, #0x7e
1027dd128:     	mov	x0, x23
1027dd12c:     	mov	x1, x27
1027dd130:     	ldr	x2, [sp, #0x68]
1027dd134:     	ldr	x3, [sp, #0x78]
1027dd138:     	mov	x5, #0x0                ; =0
1027dd13c:     	mov	x6, x26
1027dd140:     	bl	0x10235af60 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_>
1027dd144:     	ldr	x3, [sp, #0x78]
1027dd148:     	tbnz	w24, #0x0, 0x1027dd0fc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x3a4>
1027dd14c:     	add	x0, x23, x27, lsl #6
1027dd150:     	orr	x8, x28, #0x1
1027dd154:     	clz	x8, x8
1027dd158:     	lsl	w8, w8, #1
1027dd15c:     	eor	w4, w8, #0x7e
1027dd160:     	mov	x1, x28
1027dd164:     	ldr	x2, [sp, #0x68]
1027dd168:     	ldr	x3, [sp, #0x78]
1027dd16c:     	mov	x5, #0x0                ; =0
1027dd170:     	mov	x6, x26
1027dd174:     	bl	0x10235af60 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_>
1027dd178:     	ldp	x10, x3, [sp, #0x70]
1027dd17c:     	cbz	x28, 0x1027dd094 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x33c>
1027dd180:     	cbz	x27, 0x1027dd094 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x33c>
1027dd184:     	cmp	x28, x27
1027dd188:     	csel	x8, x28, x27, lo
1027dd18c:     	cmp	x3, x8
1027dd190:     	b.lo	0x1027dd094 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x33c>
1027dd194:     	add	x26, x23, x27, lsl #6
1027dd198:     	cmp	x27, x28
1027dd19c:     	csel	x1, x26, x23, hi
1027dd1a0:     	lsl	x24, x8, #6
1027dd1a4:     	ldr	x21, [sp, #0x68]
1027dd1a8:     	mov	x0, x21
1027dd1ac:     	mov	x2, x24
1027dd1b0:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027dd1b4:     	add	x8, x21, x24
1027dd1b8:     	cmp	x27, x28
1027dd1bc:     	b.ls	0x1027dd22c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x4d4>
1027dd1c0:     	ldr	x9, [sp, #0x40]
1027dd1c4:     	mov	w14, #0xff              ; =255
1027dd1c8:     	ldrb	w10, [x8, #-0x40]!
1027dd1cc:     	ldrh	w11, [x8, #0x2]
1027dd1d0:     	ldrb	w12, [x26, #-0x40]!
1027dd1d4:     	ldrh	w13, [x26, #0x2]
1027dd1d8:     	cmp	w11, w13
1027dd1dc:     	cset	w11, lo
1027dd1e0:     	subs	w13, w10, w12
1027dd1e4:     	bics	wzr, w14, w13
1027dd1e8:     	cset	w13, eq
1027dd1ec:     	cmp	w10, w12
1027dd1f0:     	csel	w10, w11, w13, eq
1027dd1f4:     	cmp	w10, #0x0
1027dd1f8:     	csel	x11, x26, x8, ne
1027dd1fc:     	ldp	q0, q1, [x11, #0x20]
1027dd200:     	ldp	q3, q2, [x11]
1027dd204:     	stp	q0, q1, [x9, #0x20]
1027dd208:     	stp	q3, q2, [x9], #-0x40
1027dd20c:     	eor	w11, w10, #0x1
1027dd210:     	add	x26, x26, x11, lsl #6
1027dd214:     	add	x8, x8, x10, lsl #6
1027dd218:     	cmp	x26, x23
1027dd21c:     	ccmp	x8, x21, #0x4, ne
1027dd220:     	b.ne	0x1027dd1c8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x470>
1027dd224:     	mov	x23, x26
1027dd228:     	b	0x1027dd07c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x324>
1027dd22c:     	mov	w13, #0xff              ; =255
1027dd230:     	ldrb	w9, [x26]
1027dd234:     	ldrh	w10, [x26, #0x2]
1027dd238:     	ldrb	w11, [x21]
1027dd23c:     	ldrh	w12, [x21, #0x2]
1027dd240:     	cmp	w10, w12
1027dd244:     	cset	w10, lo
1027dd248:     	subs	w12, w9, w11
1027dd24c:     	bics	wzr, w13, w12
1027dd250:     	cset	w12, eq
1027dd254:     	cmp	w9, w11
1027dd258:     	csel	w9, w10, w12, eq
1027dd25c:     	eor	w10, w9, #0x1
1027dd260:     	cmp	w9, #0x0
1027dd264:     	csel	x11, x26, x21, ne
1027dd268:     	ldp	q0, q1, [x11, #0x20]
1027dd26c:     	ldp	q3, q2, [x11]
1027dd270:     	stp	q0, q1, [x23, #0x20]
1027dd274:     	stp	q3, q2, [x23], #0x40
1027dd278:     	add	x21, x21, x10, lsl #6
1027dd27c:     	add	x26, x26, x9, lsl #6
1027dd280:     	cmp	x21, x8
1027dd284:     	ccmp	x26, x25, #0x4, ne
1027dd288:     	b.ne	0x1027dd230 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x4d8>
1027dd28c:     	b	0x1027dd07c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x324>
1027dd290:     	mov	w20, #0x1               ; =1
1027dd294:     	ldr	x19, [sp, #0x30]
1027dd298:     	ldr	x11, [sp, #0x48]
1027dd29c:     	add	x8, sp, #0x80
1027dd2a0:     	str	x24, [x8, x20, lsl #3]
1027dd2a4:     	sub	x8, x29, #0x9a
1027dd2a8:     	strb	w10, [x8, x20]
1027dd2ac:     	cmp	x19, x23
1027dd2b0:     	b.ls	0x1027dd2cc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x574>
1027dd2b4:     	add	x20, x20, #0x1
1027dd2b8:     	add	x23, x23, x11, lsr #1
1027dd2bc:     	mov	x24, x11
1027dd2c0:     	subs	x9, x19, x23
1027dd2c4:     	b.ls	0x1027dce74 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x11c>
1027dd2c8:     	b	0x1027dce1c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0xc4>
1027dd2cc:     	tbnz	w24, #0x0, 0x1027dd2f4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_+0x59c>
1027dd2d0:     	orr	x8, x19, #0x1
1027dd2d4:     	clz	x8, x8
1027dd2d8:     	lsl	w8, w8, #1
1027dd2dc:     	eor	w4, w8, #0x7e
1027dd2e0:     	ldp	x0, x2, [sp, #0x60]
1027dd2e4:     	mov	x1, x19
1027dd2e8:     	mov	x5, #0x0                ; =0
1027dd2ec:     	mov	x6, x26
1027dd2f0:     	bl	0x10235af60 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_>
1027dd2f4:     	add	sp, sp, #0x2e0
1027dd2f8:     	ldp	x29, x30, [sp, #0x50]
1027dd2fc:     	ldp	x20, x19, [sp, #0x40]
1027dd300:     	ldp	x22, x21, [sp, #0x30]
1027dd304:     	ldp	x24, x23, [sp, #0x20]
1027dd308:     	ldp	x26, x25, [sp, #0x10]
1027dd30c:     	ldp	x28, x27, [sp], #0x60
1027dd310:     	ret
