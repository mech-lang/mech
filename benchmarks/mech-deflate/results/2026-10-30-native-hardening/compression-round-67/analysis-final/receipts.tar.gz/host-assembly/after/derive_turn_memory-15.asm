
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102991da8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_>:
102991da8:     	sub	sp, sp, #0xb0
102991dac:     	stp	x28, x27, [sp, #0x50]
102991db0:     	stp	x26, x25, [sp, #0x60]
102991db4:     	stp	x24, x23, [sp, #0x70]
102991db8:     	stp	x22, x21, [sp, #0x80]
102991dbc:     	stp	x20, x19, [sp, #0x90]
102991dc0:     	stp	x29, x30, [sp, #0xa0]
102991dc4:     	add	x29, sp, #0xa0
102991dc8:     	stp	x6, x3, [sp]
102991dcc:     	mov	x21, x2
102991dd0:     	mov	x27, x1
102991dd4:     	mov	x22, x0
102991dd8:     	cmp	x1, #0x21
102991ddc:     	b.hs	0x102991df8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x50>
102991de0:     	mov	x0, x22
102991de4:     	mov	x1, x27
102991de8:     	mov	x2, x21
102991dec:     	ldp	x4, x3, [sp]
102991df0:     	bl	0x10290f3f4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_>
102991df4:     	b	0x10299217c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x3d4>
102991df8:     	mov	x25, x5
102991dfc:     	mov	x23, x4
102991e00:     	mov	w28, #0xff              ; =255
102991e04:     	mov	x24, x27
102991e08:     	cbz	w23, 0x102992164 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x3bc>
102991e0c:     	lsr	x3, x24, #3
102991e10:     	add	x1, x22, x3, lsl #8
102991e14:     	mov	w8, #0x1c0              ; =448
102991e18:     	madd	x2, x3, x8, x22
102991e1c:     	cmp	x24, #0x40
102991e20:     	b.hs	0x102991eac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x104>
102991e24:     	ldrb	w12, [x22]
102991e28:     	ldrh	w13, [x22, #0x2]
102991e2c:     	ldrb	w8, [x2]
102991e30:     	ldrh	w9, [x2, #0x2]
102991e34:     	cmp	w13, w9
102991e38:     	cset	w14, lo
102991e3c:     	subs	w10, w12, w8
102991e40:     	bics	wzr, w28, w10
102991e44:     	cset	w15, eq
102991e48:     	ldrb	w10, [x1]
102991e4c:     	ldrh	w11, [x1, #0x2]
102991e50:     	cmp	w12, w8
102991e54:     	csel	w14, w14, w15, eq
102991e58:     	cmp	w13, w11
102991e5c:     	cset	w13, lo
102991e60:     	subs	w15, w12, w10
102991e64:     	bics	wzr, w28, w15
102991e68:     	cset	w15, eq
102991e6c:     	cmp	w12, w10
102991e70:     	csel	w12, w13, w15, eq
102991e74:     	mov	x26, x22
102991e78:     	cmp	w12, w14
102991e7c:     	b.ne	0x102991eb8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x110>
102991e80:     	cmp	w11, w9
102991e84:     	cset	w9, lo
102991e88:     	subs	w11, w10, w8
102991e8c:     	cmn	w11, #0x1
102991e90:     	cset	w11, eq
102991e94:     	cmp	w10, w8
102991e98:     	csel	w8, w9, w11, eq
102991e9c:     	eor	w8, w12, w8
102991ea0:     	cmp	w8, #0x0
102991ea4:     	csel	x26, x2, x1, ne
102991ea8:     	b	0x102991eb8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x110>
102991eac:     	mov	x0, x22
102991eb0:     	bl	0x1029807ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_>
102991eb4:     	mov	x26, x0
102991eb8:     	sub	w23, w23, #0x1
102991ebc:     	sub	x8, x26, x22
102991ec0:     	lsr	x20, x8, #6
102991ec4:     	ldp	q0, q1, [x26]
102991ec8:     	stp	q0, q1, [sp, #0x10]
102991ecc:     	ldp	q0, q1, [x26, #0x20]
102991ed0:     	stp	q0, q1, [sp, #0x30]
102991ed4:     	add	x19, x21, x24, lsl #6
102991ed8:     	cbz	x25, 0x102991f10 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x168>
102991edc:     	ldrb	w8, [x25]
102991ee0:     	ldrh	w9, [x25, #0x2]
102991ee4:     	ldrb	w10, [x26]
102991ee8:     	ldrh	w11, [x26, #0x2]
102991eec:     	cmp	w9, w11
102991ef0:     	cset	w9, lo
102991ef4:     	subs	w11, w8, w10
102991ef8:     	bics	wzr, w28, w11
102991efc:     	cset	w11, eq
102991f00:     	cmp	w8, w10
102991f04:     	csel	w8, w9, w11, eq
102991f08:     	cmp	w8, #0x1
102991f0c:     	b.ne	0x102992048 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x2a0>
102991f10:     	ldr	x8, [sp, #0x8]
102991f14:     	cmp	x8, x24
102991f18:     	b.lo	0x1029921a4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x3fc>
102991f1c:     	mov	x27, #0x0               ; =0
102991f20:     	mov	x8, x22
102991f24:     	mov	x9, x19
102991f28:     	mov	x10, x20
102991f2c:     	add	x11, x22, x20, lsl #6
102991f30:     	cmp	x22, x11
102991f34:     	b.hs	0x102991f94 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x1ec>
102991f38:     	ldrb	w12, [x8]
102991f3c:     	ldrh	w13, [x8, #0x2]
102991f40:     	ldrb	w14, [x26]
102991f44:     	ldrh	w15, [x26, #0x2]
102991f48:     	cmp	w13, w15
102991f4c:     	cset	w13, lo
102991f50:     	subs	w15, w12, w14
102991f54:     	bics	wzr, w28, w15
102991f58:     	cset	w15, eq
102991f5c:     	cmp	w12, w14
102991f60:     	csel	w12, w13, w15, eq
102991f64:     	sub	x9, x9, #0x40
102991f68:     	cmp	w12, #0x0
102991f6c:     	csel	x13, x21, x9, ne
102991f70:     	add	x13, x13, x27, lsl #6
102991f74:     	ldp	q0, q1, [x8]
102991f78:     	ldp	q2, q3, [x8, #0x20]
102991f7c:     	stp	q2, q3, [x13, #0x20]
102991f80:     	stp	q0, q1, [x13]
102991f84:     	add	x27, x27, x12
102991f88:     	add	x8, x8, #0x40
102991f8c:     	cmp	x8, x11
102991f90:     	b.lo	0x102991f38 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x190>
102991f94:     	cmp	x10, x24
102991f98:     	b.eq	0x102991fcc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x224>
102991f9c:     	sub	x9, x9, #0x40
102991fa0:     	add	x10, x9, x27, lsl #6
102991fa4:     	ldp	q0, q1, [x8]
102991fa8:     	stp	q0, q1, [x10]
102991fac:     	ldp	q0, q1, [x8, #0x20]
102991fb0:     	stp	q0, q1, [x10, #0x20]
102991fb4:     	add	x8, x8, #0x40
102991fb8:     	mov	x10, x24
102991fbc:     	add	x11, x22, x24, lsl #6
102991fc0:     	cmp	x8, x11
102991fc4:     	b.lo	0x102991f38 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x190>
102991fc8:     	b	0x102991f94 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x1ec>
102991fcc:     	lsl	x2, x27, #6
102991fd0:     	mov	x0, x22
102991fd4:     	mov	x1, x21
102991fd8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102991fdc:     	add	x0, x22, x27, lsl #6
102991fe0:     	subs	x1, x24, x27
102991fe4:     	b.eq	0x102992018 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x270>
102991fe8:     	sub	x8, x21, #0x40
102991fec:     	add	x8, x8, x24, lsl #6
102991ff0:     	mov	x9, x1
102991ff4:     	mov	x10, x0
102991ff8:     	ldp	q0, q1, [x8]
102991ffc:     	stp	q0, q1, [x10]
102992000:     	ldp	q0, q1, [x8, #0x20]
102992004:     	stp	q0, q1, [x10, #0x20]
102992008:     	add	x10, x10, #0x40
10299200c:     	sub	x8, x8, #0x40
102992010:     	subs	x9, x9, #0x1
102992014:     	b.ne	0x102991ff8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x250>
102992018:     	cbz	x27, 0x102992048 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x2a0>
10299201c:     	cmp	x24, x27
102992020:     	b.lo	0x1029921a8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x400>
102992024:     	add	x5, sp, #0x10
102992028:     	mov	x2, x21
10299202c:     	ldp	x6, x3, [sp]
102992030:     	mov	x4, x23
102992034:     	bl	0x102991da8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_>
102992038:     	mov	x24, x27
10299203c:     	cmp	x27, #0x21
102992040:     	b.hs	0x102991e08 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x60>
102992044:     	b	0x102991de0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x38>
102992048:     	ldr	x8, [sp, #0x8]
10299204c:     	cmp	x8, x24
102992050:     	b.lo	0x1029921a4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x3fc>
102992054:     	mov	x25, #0x0               ; =0
102992058:     	mov	x8, x22
10299205c:     	add	x9, x22, x20, lsl #6
102992060:     	cmp	x22, x9
102992064:     	b.hs	0x1029920c4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x31c>
102992068:     	ldrb	w10, [x8]
10299206c:     	ldrh	w11, [x8, #0x2]
102992070:     	ldrb	w12, [x26]
102992074:     	ldrh	w13, [x26, #0x2]
102992078:     	cmp	w13, w11
10299207c:     	cset	w11, hs
102992080:     	subs	w13, w12, w10
102992084:     	bics	wzr, w28, w13
102992088:     	cset	w13, ne
10299208c:     	cmp	w12, w10
102992090:     	csel	w10, w11, w13, eq
102992094:     	sub	x19, x19, #0x40
102992098:     	cmp	w10, #0x0
10299209c:     	csel	x11, x21, x19, ne
1029920a0:     	add	x11, x11, x25, lsl #6
1029920a4:     	ldp	q0, q1, [x8]
1029920a8:     	ldp	q2, q3, [x8, #0x20]
1029920ac:     	stp	q2, q3, [x11, #0x20]
1029920b0:     	stp	q0, q1, [x11]
1029920b4:     	add	x25, x25, x10
1029920b8:     	add	x8, x8, #0x40
1029920bc:     	cmp	x8, x9
1029920c0:     	b.lo	0x102992068 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x2c0>
1029920c4:     	cmp	x20, x24
1029920c8:     	b.eq	0x102992100 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x358>
1029920cc:     	sub	x19, x19, #0x40
1029920d0:     	add	x9, x21, x25, lsl #6
1029920d4:     	ldp	q0, q1, [x8]
1029920d8:     	ldp	q2, q3, [x8, #0x20]
1029920dc:     	stp	q2, q3, [x9, #0x20]
1029920e0:     	stp	q0, q1, [x9]
1029920e4:     	add	x25, x25, #0x1
1029920e8:     	add	x8, x8, #0x40
1029920ec:     	mov	x20, x24
1029920f0:     	add	x9, x22, x24, lsl #6
1029920f4:     	cmp	x8, x9
1029920f8:     	b.lo	0x102992068 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x2c0>
1029920fc:     	b	0x1029920c4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x31c>
102992100:     	lsl	x2, x25, #6
102992104:     	mov	x0, x22
102992108:     	mov	x1, x21
10299210c:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102992110:     	subs	x27, x24, x25
102992114:     	b.eq	0x10299219c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x3f4>
102992118:     	add	x22, x22, x25, lsl #6
10299211c:     	sub	x8, x21, #0x40
102992120:     	add	x8, x8, x24, lsl #6
102992124:     	mov	x9, x27
102992128:     	mov	x10, x22
10299212c:     	ldp	q0, q1, [x8]
102992130:     	stp	q0, q1, [x10]
102992134:     	ldp	q0, q1, [x8, #0x20]
102992138:     	stp	q0, q1, [x10, #0x20]
10299213c:     	add	x10, x10, #0x40
102992140:     	sub	x8, x8, #0x40
102992144:     	subs	x9, x9, #0x1
102992148:     	b.ne	0x10299212c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x384>
10299214c:     	cmp	x24, x25
102992150:     	b.lo	0x1029921c0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x418>
102992154:     	mov	x25, #0x0               ; =0
102992158:     	cmp	x27, #0x21
10299215c:     	b.hs	0x102991e04 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x5c>
102992160:     	b	0x102991de0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x38>
102992164:     	mov	x0, x22
102992168:     	mov	x1, x24
10299216c:     	mov	x2, x21
102992170:     	ldp	x5, x3, [sp]
102992174:     	mov	w4, #0x1                ; =1
102992178:     	bl	0x1029eae7c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_>
10299217c:     	ldp	x29, x30, [sp, #0xa0]
102992180:     	ldp	x20, x19, [sp, #0x90]
102992184:     	ldp	x22, x21, [sp, #0x80]
102992188:     	ldp	x24, x23, [sp, #0x70]
10299218c:     	ldp	x26, x25, [sp, #0x60]
102992190:     	ldp	x28, x27, [sp, #0x50]
102992194:     	add	sp, sp, #0xb0
102992198:     	ret
10299219c:     	add	x22, x22, x24, lsl #6
1029921a0:     	b	0x102991de0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_+0x38>
1029921a4:     	brk	#0x1
1029921a8:     	adrp	x0, 0x1076e0000 <_anon.5245c210884fd18e01c7938c721b2e18.935+0x96c>
1029921ac:     	add	x0, x0, #0xdbe
1029921b0:     	adrp	x2, 0x108050000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.71+0x18>
1029921b4:     	add	x2, x2, #0x200
1029921b8:     	mov	w1, #0x13               ; =19
1029921bc:     	bl	0x103a06884 <__RNvNtCsgDHHaSskbIF_4core9panicking9panic_fmt>
1029921c0:     	adrp	x3, 0x108050000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.71+0x18>
1029921c4:     	add	x3, x3, #0x218
1029921c8:     	mov	x0, x25
1029921cc:     	mov	x1, x24
1029921d0:     	mov	x2, x24
1029921d4:     	bl	0x103a068c8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
