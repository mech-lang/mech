
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a03c4c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_>:
102a03c4c:     	sub	sp, sp, #0x70
102a03c50:     	stp	x26, x25, [sp, #0x20]
102a03c54:     	stp	x24, x23, [sp, #0x30]
102a03c58:     	stp	x22, x21, [sp, #0x40]
102a03c5c:     	stp	x20, x19, [sp, #0x50]
102a03c60:     	stp	x29, x30, [sp, #0x60]
102a03c64:     	add	x29, sp, #0x60
102a03c68:     	mov	x21, x0
102a03c6c:     	mov	x19, x8
102a03c70:     	ldr	x22, [x0]
102a03c74:     	cbz	x22, 0x102a03d68 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x11c>
102a03c78:     	ldr	x8, [x21, #0x8]
102a03c7c:     	cmp	x22, x8
102a03c80:     	b.eq	0x102a03d64 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x118>
102a03c84:     	ldr	w9, [x22], #0xc
102a03c88:     	str	x22, [x21]
102a03c8c:     	cbz	w9, 0x102a03c7c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x30>
102a03c90:     	sub	x8, x22, #0xc
102a03c94:     	ldr	w20, [x8, #0x8]
102a03c98:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a03c9c:     	mov	w0, #0x10               ; =16
102a03ca0:     	mov	w1, #0x4                ; =4
102a03ca4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a03ca8:     	cbz	x0, 0x102a03da8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x15c>
102a03cac:     	str	w20, [x0]
102a03cb0:     	mov	w8, #0x4                ; =4
102a03cb4:     	stp	x8, x0, [sp, #0x8]
102a03cb8:     	mov	w20, #0x1               ; =1
102a03cbc:     	str	x20, [sp, #0x18]
102a03cc0:     	ldp	x23, x24, [x21, #0x8]
102a03cc4:     	ldr	x21, [x21, #0x18]
102a03cc8:     	b	0x102a03cd8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x8c>
102a03ccc:     	str	w25, [x0, x20, lsl #2]
102a03cd0:     	add	x20, x20, #0x1
102a03cd4:     	str	x20, [sp, #0x18]
102a03cd8:     	cbz	x22, 0x102a03d04 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0xb8>
102a03cdc:     	cmp	x22, x23
102a03ce0:     	b.eq	0x102a03d04 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0xb8>
102a03ce4:     	ldr	w8, [x22], #0xc
102a03ce8:     	cbz	w8, 0x102a03cdc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x90>
102a03cec:     	sub	x8, x22, #0xc
102a03cf0:     	ldr	w25, [x8, #0x8]
102a03cf4:     	ldr	x8, [sp, #0x8]
102a03cf8:     	cmp	x20, x8
102a03cfc:     	b.ne	0x102a03ccc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x80>
102a03d00:     	b	0x102a03d30 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0xe4>
102a03d04:     	cbz	x24, 0x102a03d50 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x104>
102a03d08:     	cmp	x24, x21
102a03d0c:     	b.eq	0x102a03d50 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x104>
102a03d10:     	ldr	w8, [x24], #0xc
102a03d14:     	cbz	w8, 0x102a03d08 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0xbc>
102a03d18:     	mov	x22, #0x0               ; =0
102a03d1c:     	sub	x8, x24, #0xc
102a03d20:     	ldr	w25, [x8, #0x8]
102a03d24:     	ldr	x8, [sp, #0x8]
102a03d28:     	cmp	x20, x8
102a03d2c:     	b.ne	0x102a03ccc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x80>
102a03d30:     	add	x0, sp, #0x8
102a03d34:     	mov	x1, x20
102a03d38:     	mov	w2, #0x1                ; =1
102a03d3c:     	mov	w3, #0x4                ; =4
102a03d40:     	mov	w4, #0x4                ; =4
102a03d44:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a03d48:     	ldr	x0, [sp, #0x10]
102a03d4c:     	b	0x102a03ccc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x80>
102a03d50:     	ldur	q0, [sp, #0x8]
102a03d54:     	str	q0, [x19]
102a03d58:     	ldr	x8, [sp, #0x18]
102a03d5c:     	str	x8, [x19, #0x10]
102a03d60:     	b	0x102a03dc0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x174>
102a03d64:     	str	xzr, [x21]
102a03d68:     	ldr	x8, [x21, #0x10]
102a03d6c:     	cbz	x8, 0x102a03db4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x168>
102a03d70:     	ldr	x9, [x21, #0x18]
102a03d74:     	cmp	x8, x9
102a03d78:     	b.eq	0x102a03db4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x168>
102a03d7c:     	ldr	w10, [x8], #0xc
102a03d80:     	str	x8, [x21, #0x10]
102a03d84:     	cbz	w10, 0x102a03d74 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x128>
102a03d88:     	mov	x22, #0x0               ; =0
102a03d8c:     	sub	x8, x8, #0xc
102a03d90:     	ldr	w20, [x8, #0x8]
102a03d94:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a03d98:     	mov	w0, #0x10               ; =16
102a03d9c:     	mov	w1, #0x4                ; =4
102a03da0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a03da4:     	cbnz	x0, 0x102a03cac <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x60>
102a03da8:     	mov	w0, #0x4                ; =4
102a03dac:     	mov	w1, #0x10               ; =16
102a03db0:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a03db4:     	mov	w8, #0x4                ; =4
102a03db8:     	stp	xzr, x8, [x19]
102a03dbc:     	str	xzr, [x19, #0x10]
102a03dc0:     	ldp	x29, x30, [sp, #0x60]
102a03dc4:     	ldp	x20, x19, [sp, #0x50]
102a03dc8:     	ldp	x22, x21, [sp, #0x40]
102a03dcc:     	ldp	x24, x23, [sp, #0x30]
102a03dd0:     	ldp	x26, x25, [sp, #0x20]
102a03dd4:     	add	sp, sp, #0x70
102a03dd8:     	ret
102a03ddc:     	mov	x19, x0
102a03de0:     	ldr	x8, [sp, #0x8]
102a03de4:     	cbz	x8, 0x102a03df8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_+0x1ac>
102a03de8:     	ldr	x0, [sp, #0x10]
102a03dec:     	lsl	x1, x8, #2
102a03df0:     	mov	w2, #0x4                ; =4
102a03df4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a03df8:     	mov	x0, x19
102a03dfc:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
