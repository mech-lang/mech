
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a15ff0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_>:
102a15ff0:     	sub	sp, sp, #0x140
102a15ff4:     	stp	d9, d8, [sp, #0xd0]
102a15ff8:     	stp	x28, x27, [sp, #0xe0]
102a15ffc:     	stp	x26, x25, [sp, #0xf0]
102a16000:     	stp	x24, x23, [sp, #0x100]
102a16004:     	stp	x22, x21, [sp, #0x110]
102a16008:     	stp	x20, x19, [sp, #0x120]
102a1600c:     	stp	x29, x30, [sp, #0x130]
102a16010:     	add	x29, sp, #0x130
102a16014:     	mov	x22, x0
102a16018:     	mov	x19, x8
102a1601c:     	add	x8, x0, #0x10
102a16020:     	str	x8, [sp, #0x38]
102a16024:     	ldp	x8, x21, [x0]
102a16028:     	sub	x8, x8, #0x60
102a1602c:     	add	x20, x8, #0x60
102a16030:     	cmp	x20, x21
102a16034:     	b.eq	0x102a161fc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x20c>
102a16038:     	add	x8, x8, #0xc0
102a1603c:     	str	x8, [x22]
102a16040:     	str	x20, [sp, #0x50]
102a16044:     	add	x0, sp, #0x38
102a16048:     	add	x1, sp, #0x50
102a1604c:     	bl	0x1028147d0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_>
102a16050:     	mov	x8, x20
102a16054:     	cbz	w0, 0x102a1602c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x3c>
102a16058:     	cbz	x20, 0x102a161fc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x20c>
102a1605c:     	ldrb	w21, [x20, #0x58]
102a16060:     	ldrh	w23, [x20, #0x4c]
102a16064:     	ldrh	w24, [x20, #0x4e]
102a16068:     	ldp	q0, q1, [x20, #0x10]
102a1606c:     	stp	q0, q1, [sp, #0x10]
102a16070:     	ldr	d8, [x20, #0x50]
102a16074:     	ldr	x8, [x20, #0x40]
102a16078:     	stur	x8, [sp, #0x94]
102a1607c:     	ldr	w8, [x20, #0x48]
102a16080:     	str	w8, [sp, #0x9c]
102a16084:     	ldr	x25, [x20, #0x30]
102a16088:     	ldr	w26, [x20, #0x38]
102a1608c:     	ldr	q0, [x20]
102a16090:     	str	q0, [sp]
102a16094:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a16098:     	mov	w0, #0x180              ; =384
102a1609c:     	mov	w1, #0x8                ; =8
102a160a0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a160a4:     	cbz	x0, 0x102a16240 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x250>
102a160a8:     	mov	x20, x0
102a160ac:     	ldp	q1, q0, [sp]
102a160b0:     	stp	q1, q0, [x0]
102a160b4:     	ldr	q0, [sp, #0x20]
102a160b8:     	str	q0, [x0, #0x20]
102a160bc:     	str	x25, [x0, #0x30]
102a160c0:     	str	w26, [x0, #0x38]
102a160c4:     	ldr	q0, [sp, #0x90]
102a160c8:     	stur	q0, [x0, #0x3c]
102a160cc:     	strh	w23, [x0, #0x4c]
102a160d0:     	strh	w24, [x0, #0x4e]
102a160d4:     	str	d8, [x0, #0x50]
102a160d8:     	strb	w21, [x0, #0x58]
102a160dc:     	mov	w8, #0x4                ; =4
102a160e0:     	stp	x8, x0, [sp, #0x38]
102a160e4:     	mov	w21, #0x1               ; =1
102a160e8:     	str	x21, [sp, #0x48]
102a160ec:     	ldp	q0, q1, [x22]
102a160f0:     	stp	q0, q1, [sp, #0x50]
102a160f4:     	ldr	q0, [x22, #0x20]
102a160f8:     	str	q0, [sp, #0x70]
102a160fc:     	add	x8, sp, #0x50
102a16100:     	ldr	x9, [x22, #0x30]
102a16104:     	add	x22, x8, #0x10
102a16108:     	sub	x24, x29, #0x80
102a1610c:     	str	x9, [sp, #0x80]
102a16110:     	stur	x22, [x29, #-0x70]
102a16114:     	ldp	x8, x23, [sp, #0x50]
102a16118:     	sub	x28, x8, #0x60
102a1611c:     	add	x8, x28, #0x60
102a16120:     	cmp	x8, x23
102a16124:     	b.eq	0x102a1620c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x21c>
102a16128:     	add	x9, x28, #0xc0
102a1612c:     	str	x9, [sp, #0x50]
102a16130:     	stur	x8, [x29, #-0x80]
102a16134:     	sub	x0, x29, #0x70
102a16138:     	sub	x1, x29, #0x80
102a1613c:     	bl	0x1028147d0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_>
102a16140:     	add	x28, x28, #0x60
102a16144:     	cbz	w0, 0x102a1611c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x12c>
102a16148:     	cbz	x28, 0x102a1620c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x21c>
102a1614c:     	ldrb	w25, [x28, #0x58]
102a16150:     	ldrh	w26, [x28, #0x4c]
102a16154:     	ldrh	w27, [x28, #0x4e]
102a16158:     	ldp	q0, q1, [x28, #0x10]
102a1615c:     	stp	q0, q1, [sp, #0x10]
102a16160:     	ldr	d8, [x28, #0x50]
102a16164:     	ldr	x8, [x28, #0x40]
102a16168:     	stur	x8, [x24, #0x4]
102a1616c:     	ldr	w8, [x28, #0x48]
102a16170:     	stur	w8, [x24, #0xc]
102a16174:     	ldr	x24, [x28, #0x30]
102a16178:     	ldr	w23, [x28, #0x38]
102a1617c:     	ldr	q0, [x28]
102a16180:     	str	q0, [sp]
102a16184:     	ldur	q0, [x29, #-0x80]
102a16188:     	stur	q0, [x29, #-0x90]
102a1618c:     	ldr	x8, [sp, #0x38]
102a16190:     	cmp	x21, x8
102a16194:     	b.ne	0x102a161b4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x1c4>
102a16198:     	add	x0, sp, #0x38
102a1619c:     	mov	x1, x21
102a161a0:     	mov	w2, #0x1                ; =1
102a161a4:     	mov	w3, #0x8                ; =8
102a161a8:     	mov	w4, #0x60               ; =96
102a161ac:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a161b0:     	ldr	x20, [sp, #0x40]
102a161b4:     	mov	w8, #0x60               ; =96
102a161b8:     	madd	x8, x21, x8, x20
102a161bc:     	ldp	q1, q0, [sp]
102a161c0:     	stp	q1, q0, [x8]
102a161c4:     	ldr	q0, [sp, #0x20]
102a161c8:     	str	q0, [x8, #0x20]
102a161cc:     	str	x24, [x8, #0x30]
102a161d0:     	str	w23, [x8, #0x38]
102a161d4:     	ldur	q0, [x29, #-0x90]
102a161d8:     	stur	q0, [x8, #0x3c]
102a161dc:     	strh	w26, [x8, #0x4c]
102a161e0:     	strh	w27, [x8, #0x4e]
102a161e4:     	str	d8, [x8, #0x50]
102a161e8:     	strb	w25, [x8, #0x58]
102a161ec:     	add	x21, x21, #0x1
102a161f0:     	str	x21, [sp, #0x48]
102a161f4:     	sub	x24, x29, #0x80
102a161f8:     	b	0x102a16110 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x120>
102a161fc:     	mov	w8, #0x8                ; =8
102a16200:     	stp	xzr, x8, [x19]
102a16204:     	str	xzr, [x19, #0x10]
102a16208:     	b	0x102a1621c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x22c>
102a1620c:     	ldur	q0, [sp, #0x38]
102a16210:     	str	q0, [x19]
102a16214:     	ldr	x8, [sp, #0x48]
102a16218:     	str	x8, [x19, #0x10]
102a1621c:     	ldp	x29, x30, [sp, #0x130]
102a16220:     	ldp	x20, x19, [sp, #0x120]
102a16224:     	ldp	x22, x21, [sp, #0x110]
102a16228:     	ldp	x24, x23, [sp, #0x100]
102a1622c:     	ldp	x26, x25, [sp, #0xf0]
102a16230:     	ldp	x28, x27, [sp, #0xe0]
102a16234:     	ldp	d9, d8, [sp, #0xd0]
102a16238:     	add	sp, sp, #0x140
102a1623c:     	ret
102a16240:     	mov	w0, #0x8                ; =8
102a16244:     	mov	w1, #0x180              ; =384
102a16248:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a1624c:     	b	0x102a16250 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x260>
102a16250:     	mov	x19, x0
102a16254:     	ldr	x8, [sp, #0x38]
102a16258:     	cbz	x8, 0x102a16270 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_+0x280>
102a1625c:     	ldr	x0, [sp, #0x40]
102a16260:     	add	x8, x8, x8, lsl #1
102a16264:     	lsl	x1, x8, #5
102a16268:     	mov	w2, #0x8                ; =8
102a1626c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a16270:     	mov	x0, x19
102a16274:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
