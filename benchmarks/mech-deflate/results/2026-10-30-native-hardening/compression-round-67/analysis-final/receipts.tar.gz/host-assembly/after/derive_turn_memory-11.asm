
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027d5f84 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0EE9from_iterB48_>:
1027d5f84:     	sub	sp, sp, #0x70
1027d5f88:     	stp	x24, x23, [sp, #0x30]
1027d5f8c:     	stp	x22, x21, [sp, #0x40]
1027d5f90:     	stp	x20, x19, [sp, #0x50]
1027d5f94:     	stp	x29, x30, [sp, #0x60]
1027d5f98:     	add	x29, sp, #0x60
1027d5f9c:     	mov	x19, x8
1027d5fa0:     	mov	x21, #0x0               ; =0
1027d5fa4:     	ldp	x8, x9, [x0, #0x18]
1027d5fa8:     	subs	x8, x9, x8
1027d5fac:     	csel	x22, xzr, x8, lo
1027d5fb0:     	lsl	x8, x22, #6
1027d5fb4:     	sub	x20, x8, x22, lsl #3
1027d5fb8:     	mov	x8, #0x9249             ; =37449
1027d5fbc:     	movk	x8, #0x4924, lsl #16
1027d5fc0:     	movk	x8, #0x2492, lsl #32
1027d5fc4:     	movk	x8, #0x249, lsl #48
1027d5fc8:     	cmp	x22, x8
1027d5fcc:     	b.ls	0x1027d5fdc <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0EE9from_iterB48_+0x58>
1027d5fd0:     	mov	x0, x21
1027d5fd4:     	mov	x1, x20
1027d5fd8:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027d5fdc:     	cbz	x20, 0x1027d6008 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0EE9from_iterB48_+0x84>
1027d5fe0:     	mov	x23, x0
1027d5fe4:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027d5fe8:     	mov	w21, #0x8               ; =8
1027d5fec:     	mov	x0, x20
1027d5ff0:     	mov	w1, #0x8                ; =8
1027d5ff4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027d5ff8:     	mov	x8, x0
1027d5ffc:     	cbz	x0, 0x1027d5fd0 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0EE9from_iterB48_+0x4c>
1027d6000:     	mov	x0, x23
1027d6004:     	b	0x1027d6010 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0EE9from_iterB48_+0x8c>
1027d6008:     	mov	x22, #0x0               ; =0
1027d600c:     	mov	w8, #0x8                ; =8
1027d6010:     	stp	x22, x8, [sp]
1027d6014:     	mov	x9, sp
1027d6018:     	add	x9, x9, #0x10
1027d601c:     	stp	xzr, x9, [sp, #0x10]
1027d6020:     	stp	xzr, x8, [sp, #0x20]
1027d6024:     	add	x1, sp, #0x18
1027d6028:     	bl	0x1027278fc <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_>
1027d602c:     	ldr	q0, [sp]
1027d6030:     	str	q0, [x19]
1027d6034:     	ldr	x8, [sp, #0x10]
1027d6038:     	str	x8, [x19, #0x10]
1027d603c:     	ldp	x29, x30, [sp, #0x60]
1027d6040:     	ldp	x20, x19, [sp, #0x50]
1027d6044:     	ldp	x22, x21, [sp, #0x40]
1027d6048:     	ldp	x24, x23, [sp, #0x30]
1027d604c:     	add	sp, sp, #0x70
1027d6050:     	ret
1027d6054:     	mov	x19, x0
1027d6058:     	ldr	x8, [sp]
1027d605c:     	cbz	x8, 0x1027d6074 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0EE9from_iterB48_+0xf0>
1027d6060:     	ldr	x0, [sp, #0x8]
1027d6064:     	lsl	x9, x8, #6
1027d6068:     	sub	x1, x9, x8, lsl #3
1027d606c:     	mov	w2, #0x8                ; =8
1027d6070:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027d6074:     	mov	x0, x19
1027d6078:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
