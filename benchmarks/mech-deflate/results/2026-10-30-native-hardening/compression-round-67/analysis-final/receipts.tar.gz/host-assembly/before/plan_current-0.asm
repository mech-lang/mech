
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001028adcd8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current>:
1028adcd8:     	stp	x28, x27, [sp, #-0x60]!
1028adcdc:     	stp	x26, x25, [sp, #0x10]
1028adce0:     	stp	x24, x23, [sp, #0x20]
1028adce4:     	stp	x22, x21, [sp, #0x30]
1028adce8:     	stp	x20, x19, [sp, #0x40]
1028adcec:     	stp	x29, x30, [sp, #0x50]
1028adcf0:     	add	x29, sp, #0x50
1028adcf4:     	sub	sp, sp, #0xe40
1028adcf8:     	str	xzr, [sp]
1028adcfc:     	mov	x28, x1
1028add00:     	mov	x19, x0
1028add04:     	mov	x27, x8
1028add08:     	ldr	w21, [x0, #0x110]
1028add0c:     	add	x0, sp, #0x7b0
1028add10:     	add	x1, x19, #0x388
1028add14:     	bl	0x1028d1344 <__RNvXsK_NtNtCskIfnrfrMWVM_9mech_core8function14specializationNtB5_9BoundCallNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1028add18:     	add	x0, x19, #0x428
1028add1c:     	bl	0x102aaded4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1028add20:     	mov	x22, x0
1028add24:     	mov	x25, x1
1028add28:     	add	x0, x19, #0x438
1028add2c:     	bl	0x102aaded4 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1028add30:     	mov	x20, x0
1028add34:     	mov	x24, x1
1028add38:     	add	x0, x19, #0x448
1028add3c:     	bl	0x102aae2a0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1028add40:     	str	w21, [sp, #0xcc]
1028add44:     	stp	x0, x1, [sp, #0xe8]
1028add48:     	str	x20, [sp, #0xe0]
1028add4c:     	add	x0, x19, #0x458
1028add50:     	bl	0x102aae2a0 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1028add54:     	stp	x0, x1, [sp, #0xd0]
1028add58:     	mov	x20, #0x0               ; =0
1028add5c:     	ldr	x23, [x19, #0x470]
1028add60:     	lsl	x21, x23, #6
1028add64:     	lsr	x8, x23, #58
1028add68:     	cbnz	x8, 0x1028addd0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xf8>
1028add6c:     	str	x28, [sp, #0xa0]
1028add70:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1028add74:     	cmp	x21, x8
1028add78:     	b.hi	0x1028addd0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xf8>
1028add7c:     	stp	x24, x22, [sp, #0xb8]
1028add80:     	cbz	x21, 0x1028adde0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x108>
1028add84:     	ldr	x28, [x19, #0x468]
1028add88:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028add8c:     	mov	w20, #0x8               ; =8
1028add90:     	mov	x0, x21
1028add94:     	mov	w1, #0x8                ; =8
1028add98:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028add9c:     	str	x0, [sp, #0xa8]
1028adda0:     	cbz	x0, 0x1028addd0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xf8>
1028adda4:     	cbz	x23, 0x1028addb8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xe0>
1028adda8:     	ldr	x0, [sp, #0xa8]
1028addac:     	mov	x1, x28
1028addb0:     	mov	x2, x21
1028addb4:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028addb8:     	mov	x20, #0x0               ; =0
1028addbc:     	ldr	x24, [x19, #0x480]
1028addc0:     	lsl	x28, x24, #6
1028addc4:     	lsr	x8, x24, #58
1028addc8:     	cbz	x8, 0x1028addfc <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x124>
1028addcc:     	b	0x1028ade44 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x16c>
1028addd0:     	mov	x0, x20
1028addd4:     	mov	x1, x21
1028addd8:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028adddc:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028adde0:     	mov	w8, #0x8                ; =8
1028adde4:     	str	x8, [sp, #0xa8]
1028adde8:     	mov	x20, #0x0               ; =0
1028addec:     	ldr	x24, [x19, #0x480]
1028addf0:     	lsl	x28, x24, #6
1028addf4:     	lsr	x8, x24, #58
1028addf8:     	cbnz	x8, 0x1028ade44 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x16c>
1028addfc:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1028ade00:     	cmp	x28, x8
1028ade04:     	b.hi	0x1028ade44 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x16c>
1028ade08:     	cbz	x28, 0x1028ade54 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x17c>
1028ade0c:     	ldr	x22, [x19, #0x478]
1028ade10:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028ade14:     	mov	w20, #0x8               ; =8
1028ade18:     	mov	x0, x28
1028ade1c:     	mov	w1, #0x8                ; =8
1028ade20:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028ade24:     	str	x0, [sp, #0x98]
1028ade28:     	cbz	x0, 0x1028ade44 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x16c>
1028ade2c:     	cbz	x24, 0x1028ade5c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x184>
1028ade30:     	ldr	x0, [sp, #0x98]
1028ade34:     	mov	x1, x22
1028ade38:     	mov	x2, x28
1028ade3c:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ade40:     	b	0x1028ade5c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x184>
1028ade44:     	mov	x0, x20
1028ade48:     	mov	x1, x28
1028ade4c:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028ade50:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028ade54:     	mov	w8, #0x8                ; =8
1028ade58:     	str	x8, [sp, #0x98]
1028ade5c:     	ldr	x9, [x19, #0x490]
1028ade60:     	add	x8, x9, x9, lsl #1
1028ade64:     	lsl	x20, x8, #4
1028ade68:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1028ade6c:     	movk	x8, #0x2aa, lsl #48
1028ade70:     	cmp	x9, x8
1028ade74:     	b.ls	0x1028ade90 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x1b8>
1028ade78:     	mov	x26, x25
1028ade7c:     	mov	x22, #0x0               ; =0
1028ade80:     	mov	x0, x22
1028ade84:     	mov	x1, x20
1028ade88:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028ade8c:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028ade90:     	str	x9, [sp, #0x90]
1028ade94:     	cbz	x20, 0x1028adf08 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x230>
1028ade98:     	str	x27, [sp, #0x80]
1028ade9c:     	mov	x26, x25
1028adea0:     	ldr	x25, [x19, #0x488]
1028adea4:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028adea8:     	mov	w22, #0x8               ; =8
1028adeac:     	mov	x0, x20
1028adeb0:     	mov	w1, #0x8                ; =8
1028adeb4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028adeb8:     	str	x0, [sp, #0xb0]
1028adebc:     	cbz	x0, 0x1028ade80 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x1a8>
1028adec0:     	ldr	x9, [sp, #0x90]
1028adec4:     	cbz	x9, 0x1028adefc <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x224>
1028adec8:     	mov	x8, #0x0                ; =0
1028adecc:     	cmp	x20, x8
1028aded0:     	b.eq	0x1028adefc <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x224>
1028aded4:     	add	x10, x25, x8
1028aded8:     	ldr	x11, [sp, #0xb0]
1028adedc:     	add	x11, x11, x8
1028adee0:     	ldp	q0, q1, [x10]
1028adee4:     	ldr	q2, [x10, #0x20]
1028adee8:     	stp	q1, q2, [x11, #0x10]
1028adeec:     	str	q0, [x11]
1028adef0:     	add	x8, x8, #0x30
1028adef4:     	subs	x9, x9, #0x1
1028adef8:     	b.ne	0x1028adecc <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x1f4>
1028adefc:     	mov	x25, x26
1028adf00:     	ldr	x27, [sp, #0x80]
1028adf04:     	b	0x1028adf10 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x238>
1028adf08:     	mov	w8, #0x8                ; =8
1028adf0c:     	str	x8, [sp, #0xb0]
1028adf10:     	mov	x10, #-0x5555555555555556 ; =-6148914691236517206
1028adf14:     	movk	x10, #0xaaa, lsl #48
1028adf18:     	ldr	x9, [x19, #0x4a0]
1028adf1c:     	add	x8, x9, x9, lsl #1
1028adf20:     	lsl	x1, x8, #2
1028adf24:     	str	x9, [sp, #0x88]
1028adf28:     	cmp	x9, x10
1028adf2c:     	b.ls	0x1028adf40 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x268>
1028adf30:     	mov	x22, #0x0               ; =0
1028adf34:     	mov	x0, x22
1028adf38:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028adf3c:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028adf40:     	str	x1, [sp, #0x70]
1028adf44:     	cbz	x1, 0x1028adf90 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x2b8>
1028adf48:     	mov	x26, x1
1028adf4c:     	ldr	x8, [x19, #0x498]
1028adf50:     	str	x8, [sp, #0x80]
1028adf54:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028adf58:     	mov	w22, #0x4               ; =4
1028adf5c:     	mov	x0, x26
1028adf60:     	mov	w1, #0x4                ; =4
1028adf64:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028adf68:     	str	x0, [sp, #0x78]
1028adf6c:     	mov	x1, x26
1028adf70:     	cbz	x0, 0x1028adf34 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x25c>
1028adf74:     	ldr	x8, [sp, #0x88]
1028adf78:     	mov	x22, x27
1028adf7c:     	cbz	x8, 0x1028adf9c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x2c4>
1028adf80:     	ldp	x0, x1, [sp, #0x78]
1028adf84:     	ldr	x2, [sp, #0x70]
1028adf88:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028adf8c:     	b	0x1028adf9c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x2c4>
1028adf90:     	mov	w8, #0x4                ; =4
1028adf94:     	str	x8, [sp, #0x78]
1028adf98:     	mov	x22, x27
1028adf9c:     	ldr	x27, [x19, #0x4b0]
1028adfa0:     	add	x8, x27, x27, lsl #1
1028adfa4:     	lsl	x26, x8, #2
1028adfa8:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1028adfac:     	movk	x8, #0xaaa, lsl #48
1028adfb0:     	cmp	x27, x8
1028adfb4:     	b.ls	0x1028adfcc <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x2f4>
1028adfb8:     	mov	x22, #0x0               ; =0
1028adfbc:     	mov	x0, x22
1028adfc0:     	mov	x1, x26
1028adfc4:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028adfc8:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028adfcc:     	str	x22, [sp, #0x80]
1028adfd0:     	str	x26, [sp, #0x58]
1028adfd4:     	cbz	x26, 0x1028ae010 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x338>
1028adfd8:     	ldr	x8, [x19, #0x4a8]
1028adfdc:     	str	x8, [sp, #0x68]
1028adfe0:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028adfe4:     	mov	w22, #0x4               ; =4
1028adfe8:     	mov	x0, x26
1028adfec:     	mov	w1, #0x4                ; =4
1028adff0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028adff4:     	str	x0, [sp, #0x60]
1028adff8:     	cbz	x0, 0x1028adfbc <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x2e4>
1028adffc:     	cbz	x27, 0x1028ae018 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x340>
1028ae000:     	ldp	x0, x1, [sp, #0x60]
1028ae004:     	mov	x2, x26
1028ae008:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae00c:     	b	0x1028ae018 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x340>
1028ae010:     	mov	w8, #0x4                ; =4
1028ae014:     	str	x8, [sp, #0x60]
1028ae018:     	add	x0, x19, #0x4b8
1028ae01c:     	bl	0x102aadddc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1028ae020:     	str	x0, [sp, #0x48]
1028ae024:     	str	x1, [sp, #0x68]
1028ae028:     	mov	x9, #0x0                ; =0
1028ae02c:     	ldr	x8, [x19, #0x4d0]
1028ae030:     	lsl	x26, x8, #2
1028ae034:     	str	x8, [sp, #0x50]
1028ae038:     	lsr	x8, x8, #62
1028ae03c:     	cbnz	x8, 0x1028ae090 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x3b8>
1028ae040:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
1028ae044:     	cmp	x26, x8
1028ae048:     	b.hi	0x1028ae090 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x3b8>
1028ae04c:     	str	x26, [sp, #0x30]
1028ae050:     	cbz	x26, 0x1028ae0a0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x3c8>
1028ae054:     	ldr	x22, [x19, #0x4c8]
1028ae058:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028ae05c:     	mov	x0, x26
1028ae060:     	mov	w1, #0x2                ; =2
1028ae064:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028ae068:     	mov	w9, #0x2                ; =2
1028ae06c:     	str	x0, [sp, #0x40]
1028ae070:     	cbz	x0, 0x1028ae090 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x3b8>
1028ae074:     	ldr	x8, [sp, #0x50]
1028ae078:     	cbz	x8, 0x1028ae0a8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x3d0>
1028ae07c:     	ldr	x0, [sp, #0x40]
1028ae080:     	mov	x1, x22
1028ae084:     	ldr	x2, [sp, #0x30]
1028ae088:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae08c:     	b	0x1028ae0a8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x3d0>
1028ae090:     	mov	x0, x9
1028ae094:     	mov	x1, x26
1028ae098:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028ae09c:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028ae0a0:     	mov	w8, #0x2                ; =2
1028ae0a4:     	str	x8, [sp, #0x40]
1028ae0a8:     	ldr	x9, [x19, #0x4e0]
1028ae0ac:     	add	x8, x9, x9, lsl #1
1028ae0b0:     	lsl	x26, x8, #2
1028ae0b4:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1028ae0b8:     	movk	x8, #0xaaa, lsl #48
1028ae0bc:     	str	x9, [sp, #0x28]
1028ae0c0:     	cmp	x9, x8
1028ae0c4:     	str	x26, [sp, #0x38]
1028ae0c8:     	b.ls	0x1028ae0e0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x408>
1028ae0cc:     	mov	x22, #0x0               ; =0
1028ae0d0:     	mov	x0, x22
1028ae0d4:     	ldr	x1, [sp, #0x38]
1028ae0d8:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028ae0dc:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028ae0e0:     	cbz	x26, 0x1028ae120 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x448>
1028ae0e4:     	ldr	x8, [x19, #0x4d8]
1028ae0e8:     	str	x8, [sp, #0x18]
1028ae0ec:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028ae0f0:     	mov	w22, #0x4               ; =4
1028ae0f4:     	mov	x0, x26
1028ae0f8:     	mov	w1, #0x4                ; =4
1028ae0fc:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028ae100:     	str	x0, [sp, #0x20]
1028ae104:     	cbz	x0, 0x1028ae0d0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x3f8>
1028ae108:     	ldr	x26, [sp, #0x28]
1028ae10c:     	cbz	x26, 0x1028ae12c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x454>
1028ae110:     	ldp	x1, x0, [sp, #0x18]
1028ae114:     	ldr	x2, [sp, #0x38]
1028ae118:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae11c:     	b	0x1028ae12c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x454>
1028ae120:     	mov	w8, #0x4                ; =4
1028ae124:     	str	x8, [sp, #0x20]
1028ae128:     	ldr	x26, [sp, #0x28]
1028ae12c:     	mov	x9, #0x0                ; =0
1028ae130:     	ldr	x22, [x19, #0x4f0]
1028ae134:     	lsl	x2, x22, #2
1028ae138:     	lsr	x8, x22, #62
1028ae13c:     	cbnz	x8, 0x1028ae1a8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x4d0>
1028ae140:     	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
1028ae144:     	cmp	x2, x8
1028ae148:     	b.hi	0x1028ae1a8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x4d0>
1028ae14c:     	ldrh	w9, [x19, #0x564]
1028ae150:     	ldr	w10, [x19, #0x560]
1028ae154:     	cbz	x2, 0x1028ae1b8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x4e0>
1028ae158:     	stp	x10, x9, [sp, #0x8]
1028ae15c:     	ldr	x8, [x19, #0x4e8]
1028ae160:     	str	x8, [sp]
1028ae164:     	str	x22, [sp, #0x18]
1028ae168:     	mov	x22, x2
1028ae16c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028ae170:     	mov	x0, x22
1028ae174:     	mov	w1, #0x2                ; =2
1028ae178:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028ae17c:     	mov	w9, #0x2                ; =2
1028ae180:     	mov	x2, x22
1028ae184:     	ldr	x22, [sp, #0x18]
1028ae188:     	cbz	x0, 0x1028ae1a8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x4d0>
1028ae18c:     	str	x0, [sp, #0x28]
1028ae190:     	mov	x21, x26
1028ae194:     	cbz	x22, 0x1028ae1a0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x4c8>
1028ae198:     	ldr	x1, [sp]
1028ae19c:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae1a0:     	ldp	x10, x9, [sp, #0x8]
1028ae1a4:     	b	0x1028ae1c4 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x4ec>
1028ae1a8:     	mov	x0, x9
1028ae1ac:     	mov	x1, x2
1028ae1b0:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1028ae1b4:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028ae1b8:     	mov	x21, x26
1028ae1bc:     	mov	w8, #0x2                ; =2
1028ae1c0:     	str	x8, [sp, #0x28]
1028ae1c4:     	add	x28, sp, #0x4e0
1028ae1c8:     	ldp	q0, q1, [x28, #0x330]
1028ae1cc:     	orr	x8, x10, x9, lsl #32
1028ae1d0:     	add	x20, x19, #0x4f8
1028ae1d4:     	add	x9, sp, #0xf8
1028ae1d8:     	add	x9, x9, #0x208
1028ae1dc:     	stp	q0, q1, [x9, #0x60]
1028ae1e0:     	ldp	q0, q1, [x28, #0x350]
1028ae1e4:     	stp	q0, q1, [x9, #0x80]
1028ae1e8:     	ldp	q0, q1, [x28, #0x2f0]
1028ae1ec:     	stp	q0, q1, [x9, #0x20]
1028ae1f0:     	ldp	q0, q1, [x28, #0x310]
1028ae1f4:     	stp	q0, q1, [x9, #0x40]
1028ae1f8:     	ldp	q0, q1, [x28, #0x2d0]
1028ae1fc:     	stp	q0, q1, [x9]
1028ae200:     	ldr	x9, [sp, #0xc0]
1028ae204:     	str	x9, [sp, #0x3a0]
1028ae208:     	str	x25, [sp, #0x3a8]
1028ae20c:     	ldr	x9, [sp, #0xe0]
1028ae210:     	str	x9, [sp, #0x3b0]
1028ae214:     	ldr	x9, [sp, #0xb8]
1028ae218:     	str	x9, [sp, #0x3b8]
1028ae21c:     	ldp	x10, x9, [sp, #0xe8]
1028ae220:     	str	x10, [sp, #0x3c0]
1028ae224:     	str	x9, [sp, #0x3c8]
1028ae228:     	ldp	x10, x9, [sp, #0xd0]
1028ae22c:     	str	x10, [sp, #0x3d0]
1028ae230:     	str	x9, [sp, #0x3d8]
1028ae234:     	ldr	x9, [sp, #0xa8]
1028ae238:     	str	x9, [sp, #0x3e0]
1028ae23c:     	str	x23, [sp, #0x3e8]
1028ae240:     	ldr	x9, [sp, #0x98]
1028ae244:     	str	x9, [sp, #0x3f0]
1028ae248:     	str	x24, [sp, #0x3f8]
1028ae24c:     	ldr	x9, [sp, #0xb0]
1028ae250:     	str	x9, [sp, #0x400]
1028ae254:     	ldr	x9, [sp, #0x90]
1028ae258:     	str	x9, [sp, #0x408]
1028ae25c:     	ldr	x9, [sp, #0x78]
1028ae260:     	str	x9, [sp, #0x410]
1028ae264:     	ldr	x9, [sp, #0x88]
1028ae268:     	str	x9, [sp, #0x418]
1028ae26c:     	ldp	x9, x26, [sp, #0x60]
1028ae270:     	str	x9, [sp, #0x420]
1028ae274:     	str	x27, [sp, #0x428]
1028ae278:     	ldp	x9, x25, [sp, #0x40]
1028ae27c:     	str	x25, [sp, #0x430]
1028ae280:     	str	x26, [sp, #0x438]
1028ae284:     	str	x9, [sp, #0x440]
1028ae288:     	ldr	x9, [sp, #0x50]
1028ae28c:     	str	x9, [sp, #0x448]
1028ae290:     	ldr	x9, [sp, #0x20]
1028ae294:     	str	x9, [sp, #0x450]
1028ae298:     	str	x21, [sp, #0x458]
1028ae29c:     	add	x21, sp, #0xf8
1028ae2a0:     	lsr	x9, x8, #32
1028ae2a4:     	strh	w9, [sp, #0x4dc]
1028ae2a8:     	str	w8, [sp, #0x4d8]
1028ae2ac:     	add	x0, sp, #0xf8
1028ae2b0:     	add	x1, x19, #0x180
1028ae2b4:     	mov	w2, #0x208              ; =520
1028ae2b8:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae2bc:     	add	x8, x21, #0x378
1028ae2c0:     	ldp	q0, q1, [x20, #0x40]
1028ae2c4:     	stp	q0, q1, [x8, #0x40]
1028ae2c8:     	ldp	q0, q1, [x20]
1028ae2cc:     	stp	q0, q1, [x8]
1028ae2d0:     	ldp	q1, q0, [x20, #0x20]
1028ae2d4:     	stp	q1, q0, [x8, #0x20]
1028ae2d8:     	ldr	x8, [x19, #0x558]
1028ae2dc:     	str	x8, [sp, #0x4d0]
1028ae2e0:     	ldr	x8, [sp, #0x28]
1028ae2e4:     	str	x8, [sp, #0x460]
1028ae2e8:     	str	x22, [sp, #0x468]
1028ae2ec:     	ldr	w23, [sp, #0xcc]
1028ae2f0:     	ldr	x24, [sp, #0x80]
1028ae2f4:     	cbz	x26, 0x1028ae328 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x650>
1028ae2f8:     	add	x8, x26, x26, lsl #1
1028ae2fc:     	lsl	x8, x8, #5
1028ae300:     	add	x9, x25, #0x14
1028ae304:     	b	0x1028ae314 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x63c>
1028ae308:     	add	x9, x9, #0x60
1028ae30c:     	subs	x8, x8, #0x60
1028ae310:     	b.eq	0x1028ae328 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x650>
1028ae314:     	ldurb	w10, [x9, #-0x4]
1028ae318:     	cmp	w10, #0x4
1028ae31c:     	b.ne	0x1028ae308 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x630>
1028ae320:     	str	w23, [x9]
1028ae324:     	b	0x1028ae308 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x630>
1028ae328:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028ae32c:     	mov	w0, #0x4                ; =4
1028ae330:     	mov	w1, #0x4                ; =4
1028ae334:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028ae338:     	cbz	x0, 0x1028ae558 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x880>
1028ae33c:     	mov	x20, x0
1028ae340:     	str	w23, [x0]
1028ae344:     	add	x0, x21, #0x338
1028ae348:     	bl	0x102aadddc <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1028ae34c:     	mov	x21, x0
1028ae350:     	mov	x22, x1
1028ae354:     	add	x8, sp, #0x79
1028ae358:     	ldur	q0, [x8, #0xff]
1028ae35c:     	add	x8, sp, #0x89
1028ae360:     	ldur	q1, [x8, #0xff]
1028ae364:     	stp	q0, q1, [x28, #0x270]
1028ae368:     	ldr	x8, [sp, #0x198]
1028ae36c:     	str	x8, [sp, #0x770]
1028ae370:     	add	x8, sp, #0x39
1028ae374:     	ldur	q0, [x8, #0xff]
1028ae378:     	add	x8, sp, #0x49
1028ae37c:     	ldur	q1, [x8, #0xff]
1028ae380:     	stp	q0, q1, [x28, #0x230]
1028ae384:     	add	x8, sp, #0x69
1028ae388:     	ldur	q0, [x8, #0xff]
1028ae38c:     	add	x8, sp, #0x59
1028ae390:     	ldur	q1, [x8, #0xff]
1028ae394:     	stp	q1, q0, [x28, #0x250]
1028ae398:     	ldur	q0, [sp, #0xf8]
1028ae39c:     	add	x8, sp, #0x9
1028ae3a0:     	ldur	q1, [x8, #0xff]
1028ae3a4:     	stp	q0, q1, [x28, #0x1f0]
1028ae3a8:     	add	x8, sp, #0x29
1028ae3ac:     	ldur	q0, [x8, #0xff]
1028ae3b0:     	add	x8, sp, #0x19
1028ae3b4:     	ldur	q1, [x8, #0xff]
1028ae3b8:     	stp	q1, q0, [x28, #0x210]
1028ae3bc:     	add	x0, sp, #0x7b0
1028ae3c0:     	add	x1, sp, #0xf8
1028ae3c4:     	mov	w2, #0x3e8              ; =1000
1028ae3c8:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae3cc:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1028ae3d0:     	mov	w0, #0x3e8              ; =1000
1028ae3d4:     	mov	w1, #0x8                ; =8
1028ae3d8:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1028ae3dc:     	cbz	x0, 0x1028ae568 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x890>
1028ae3e0:     	mov	x19, x0
1028ae3e4:     	add	x1, sp, #0x7b0
1028ae3e8:     	mov	w2, #0x3e8              ; =1000
1028ae3ec:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae3f0:     	add	x8, sp, #0x4e0
1028ae3f4:     	add	x8, x8, #0x118
1028ae3f8:     	movi.2d	v0, #0000000000000000
1028ae3fc:     	stp	q0, q0, [x8]
1028ae400:     	stp	q0, q0, [x8, #0x20]
1028ae404:     	stp	q0, q0, [x8, #0x40]
1028ae408:     	str	wzr, [sp, #0x658]
1028ae40c:     	stp	q0, q0, [x28, #0x180]
1028ae410:     	stp	q0, q0, [x28, #0x1a0]
1028ae414:     	stp	q0, q0, [x28, #0x1c0]
1028ae418:     	str	wzr, [sp, #0x6c0]
1028ae41c:     	mov	w8, #0x10               ; =16
1028ae420:     	str	xzr, [sp, #0x590]
1028ae424:     	str	x20, [sp, #0x598]
1028ae428:     	mov	w9, #0x1                ; =1
1028ae42c:     	str	x9, [sp, #0x5a0]
1028ae430:     	str	x19, [sp, #0x5a8]
1028ae434:     	str	x9, [sp, #0x5b0]
1028ae438:     	str	x21, [sp, #0x5b8]
1028ae43c:     	mov	w9, #0x8                ; =8
1028ae440:     	str	x22, [sp, #0x5c0]
1028ae444:     	str	x9, [sp, #0x5c8]
1028ae448:     	str	xzr, [sp, #0x5d0]
1028ae44c:     	str	x9, [sp, #0x5d8]
1028ae450:     	ldr	x10, [sp, #0x770]
1028ae454:     	str	x8, [sp, #0x588]
1028ae458:     	str	x10, [sp, #0x580]
1028ae45c:     	ldp	q1, q0, [x28, #0x270]
1028ae460:     	stp	q1, q0, [x28, #0x80]
1028ae464:     	ldp	q1, q0, [x28, #0x250]
1028ae468:     	stp	q1, q0, [x28, #0x60]
1028ae46c:     	ldp	q1, q0, [x28, #0x230]
1028ae470:     	stp	q1, q0, [x28, #0x40]
1028ae474:     	ldp	q1, q0, [x28, #0x210]
1028ae478:     	stp	q1, q0, [x28, #0x20]
1028ae47c:     	ldp	q1, q0, [x28, #0x1f0]
1028ae480:     	stp	q1, q0, [x28]
1028ae484:     	str	xzr, [sp, #0x5e0]
1028ae488:     	str	x9, [sp, #0x5e8]
1028ae48c:     	str	xzr, [sp, #0x5f0]
1028ae490:     	add	x8, sp, #0x7b0
1028ae494:     	add	x0, sp, #0x4e0
1028ae498:     	mov	x1, x23
1028ae49c:     	ldr	x2, [sp, #0xa0]
1028ae4a0:     	bl	0x1027fdac0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory>
1028ae4a4:     	add	x8, sp, #0x7b0
1028ae4a8:     	ldr	x19, [sp, #0x7b0]
1028ae4ac:     	ldur	q0, [x8, #0x8]
1028ae4b0:     	ldur	q1, [x8, #0x18]
1028ae4b4:     	stp	q0, q1, [x28, #0x2a0]
1028ae4b8:     	ldur	q0, [x8, #0x28]
1028ae4bc:     	str	q0, [x28, #0x2c0]
1028ae4c0:     	cmp	x19, #0x2
1028ae4c4:     	b.ne	0x1028ae504 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x82c>
1028ae4c8:     	ldp	q0, q1, [x28, #0x2a0]
1028ae4cc:     	stur	q0, [x8, #0x7]
1028ae4d0:     	stur	q1, [x8, #0x17]
1028ae4d4:     	ldr	q0, [x28, #0x2c0]
1028ae4d8:     	stur	q0, [x8, #0x27]
1028ae4dc:     	ldp	q0, q1, [x8]
1028ae4e0:     	stur	q0, [x24, #0x9]
1028ae4e4:     	mov	w9, #0x2a               ; =42
1028ae4e8:     	strb	w9, [x24, #0x8]
1028ae4ec:     	stur	q1, [x24, #0x19]
1028ae4f0:     	ldr	q0, [x8, #0x20]
1028ae4f4:     	stur	q0, [x24, #0x29]
1028ae4f8:     	ldur	x8, [x8, #0x2f]
1028ae4fc:     	str	x8, [x24, #0x38]
1028ae500:     	b	0x1028ae52c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x854>
1028ae504:     	add	x8, sp, #0x7b0
1028ae508:     	add	x0, x24, #0x38
1028ae50c:     	add	x1, x8, #0x38
1028ae510:     	mov	w2, #0x648              ; =1608
1028ae514:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028ae518:     	ldp	q0, q1, [x28, #0x2a0]
1028ae51c:     	stur	q0, [x24, #0x8]
1028ae520:     	stur	q1, [x24, #0x18]
1028ae524:     	ldr	q0, [x28, #0x2c0]
1028ae528:     	stur	q0, [x24, #0x28]
1028ae52c:     	str	x19, [x24]
1028ae530:     	add	x0, sp, #0x4e0
1028ae534:     	bl	0x102827680 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program17ProgramMemoryPlanEBM_>
1028ae538:     	add	sp, sp, #0xe40
1028ae53c:     	ldp	x29, x30, [sp, #0x50]
1028ae540:     	ldp	x20, x19, [sp, #0x40]
1028ae544:     	ldp	x22, x21, [sp, #0x30]
1028ae548:     	ldp	x24, x23, [sp, #0x20]
1028ae54c:     	ldp	x26, x25, [sp, #0x10]
1028ae550:     	ldp	x28, x27, [sp], #0x60
1028ae554:     	ret
1028ae558:     	mov	w0, #0x4                ; =4
1028ae55c:     	mov	w1, #0x4                ; =4
1028ae560:     	bl	0x103a03a70 <__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error>
1028ae564:     	b	0x1028ae574 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x89c>
1028ae568:     	mov	w0, #0x8                ; =8
1028ae56c:     	mov	w1, #0x3e8              ; =1000
1028ae570:     	bl	0x103a03a70 <__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error>
1028ae574:     	brk	#0x1
1028ae578:     	mov	x19, x0
1028ae57c:     	add	x0, sp, #0x4e0
1028ae580:     	bl	0x102827680 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program17ProgramMemoryPlanEBM_>
1028ae584:     	b	0x1028ae768 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa90>
1028ae588:     	mov	x19, x0
1028ae58c:     	mov	x0, x20
1028ae590:     	mov	w1, #0x4                ; =4
1028ae594:     	mov	w2, #0x4                ; =4
1028ae598:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae59c:     	b	0x1028ae618 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x940>
1028ae5a0:     	mov	x19, x0
1028ae5a4:     	ldr	x22, [sp, #0x90]
1028ae5a8:     	b	0x1028ae690 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x9b8>
1028ae5ac:     	mov	x19, x0
1028ae5b0:     	ldp	x20, x23, [sp, #0xe0]
1028ae5b4:     	ldr	x21, [sp, #0xf0]
1028ae5b8:     	b	0x1028ae73c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa64>
1028ae5bc:     	mov	x19, x0
1028ae5c0:     	b	0x1028ae748 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa70>
1028ae5c4:     	mov	x19, x0
1028ae5c8:     	b	0x1028ae754 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa7c>
1028ae5cc:     	mov	x19, x0
1028ae5d0:     	b	0x1028ae760 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa88>
1028ae5d4:     	mov	x19, x0
1028ae5d8:     	add	x0, sp, #0x7b0
1028ae5dc:     	bl	0x10282a938 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1028ae5e0:     	cbz	x22, 0x1028ae5f8 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x920>
1028ae5e4:     	add	x8, x22, x22, lsl #1
1028ae5e8:     	lsl	x1, x8, #5
1028ae5ec:     	mov	x0, x21
1028ae5f0:     	mov	w2, #0x8                ; =8
1028ae5f4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae5f8:     	mov	x0, x20
1028ae5fc:     	mov	w1, #0x4                ; =4
1028ae600:     	mov	w2, #0x4                ; =4
1028ae604:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae608:     	mov	x0, x19
1028ae60c:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
1028ae610:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1028ae614:     	mov	x19, x0
1028ae618:     	add	x0, sp, #0xf8
1028ae61c:     	bl	0x10282a938 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1028ae620:     	b	0x1028ae768 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa90>
1028ae624:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1028ae628:     	mov	x19, x0
1028ae62c:     	ldr	x22, [sp, #0x90]
1028ae630:     	cbz	x26, 0x1028ae650 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x978>
1028ae634:     	ldr	x0, [sp, #0x20]
1028ae638:     	ldr	x1, [sp, #0x38]
1028ae63c:     	mov	w2, #0x4                ; =4
1028ae640:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae644:     	b	0x1028ae650 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x978>
1028ae648:     	mov	x19, x0
1028ae64c:     	ldr	x22, [sp, #0x90]
1028ae650:     	ldr	x8, [sp, #0x50]
1028ae654:     	cbz	x8, 0x1028ae674 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x99c>
1028ae658:     	ldr	x0, [sp, #0x40]
1028ae65c:     	ldr	x1, [sp, #0x30]
1028ae660:     	mov	w2, #0x2                ; =2
1028ae664:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae668:     	b	0x1028ae674 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x99c>
1028ae66c:     	mov	x19, x0
1028ae670:     	ldr	x22, [sp, #0x90]
1028ae674:     	ldr	x26, [sp, #0x68]
1028ae678:     	cbz	x26, 0x1028ae690 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x9b8>
1028ae67c:     	add	x8, x26, x26, lsl #1
1028ae680:     	lsl	x1, x8, #5
1028ae684:     	ldr	x0, [sp, #0x48]
1028ae688:     	mov	w2, #0x8                ; =8
1028ae68c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae690:     	ldr	x1, [sp, #0x58]
1028ae694:     	cbz	x27, 0x1028ae6b0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x9d8>
1028ae698:     	ldr	x0, [sp, #0x60]
1028ae69c:     	mov	w2, #0x4                ; =4
1028ae6a0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae6a4:     	b	0x1028ae6b0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x9d8>
1028ae6a8:     	mov	x19, x0
1028ae6ac:     	ldr	x22, [sp, #0x90]
1028ae6b0:     	ldr	x8, [sp, #0x88]
1028ae6b4:     	cbz	x8, 0x1028ae6d0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x9f8>
1028ae6b8:     	ldp	x1, x0, [sp, #0x70]
1028ae6bc:     	mov	w2, #0x4                ; =4
1028ae6c0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae6c4:     	b	0x1028ae6d0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x9f8>
1028ae6c8:     	mov	x19, x0
1028ae6cc:     	ldr	x22, [sp, #0x90]
1028ae6d0:     	cbz	x22, 0x1028ae6f0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa18>
1028ae6d4:     	ldr	x0, [sp, #0xb0]
1028ae6d8:     	mov	x1, x20
1028ae6dc:     	mov	w2, #0x8                ; =8
1028ae6e0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae6e4:     	b	0x1028ae6f0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa18>
1028ae6e8:     	mov	x19, x0
1028ae6ec:     	mov	x25, x26
1028ae6f0:     	cbz	x24, 0x1028ae70c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa34>
1028ae6f4:     	ldr	x0, [sp, #0x98]
1028ae6f8:     	mov	x1, x28
1028ae6fc:     	mov	w2, #0x8                ; =8
1028ae700:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae704:     	b	0x1028ae70c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa34>
1028ae708:     	mov	x19, x0
1028ae70c:     	ldp	x24, x22, [sp, #0xb8]
1028ae710:     	cbz	x23, 0x1028ae72c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa54>
1028ae714:     	ldr	x0, [sp, #0xa8]
1028ae718:     	mov	x1, x21
1028ae71c:     	mov	w2, #0x8                ; =8
1028ae720:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1028ae724:     	b	0x1028ae72c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0xa54>
1028ae728:     	mov	x19, x0
1028ae72c:     	ldp	x20, x23, [sp, #0xe0]
1028ae730:     	ldr	x21, [sp, #0xf0]
1028ae734:     	ldp	x0, x1, [sp, #0xd0]
1028ae738:     	bl	0x102825a44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
1028ae73c:     	mov	x0, x23
1028ae740:     	mov	x1, x21
1028ae744:     	bl	0x102825a44 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model25PhysicalStorageDescriptorEECs1qJAwyMG1lC_11mech_engine>
1028ae748:     	mov	x0, x20
1028ae74c:     	mov	x1, x24
1028ae750:     	bl	0x102825940 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
1028ae754:     	mov	x0, x22
1028ae758:     	mov	x1, x25
1028ae75c:     	bl	0x102825940 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14PortMemoryPlanEECs1qJAwyMG1lC_11mech_engine>
1028ae760:     	add	x0, sp, #0x7b0
1028ae764:     	bl	0x10282b8f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8function14specialization9BoundCallECs1qJAwyMG1lC_11mech_engine>
1028ae768:     	mov	x0, x19
1028ae76c:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
1028ae770:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
