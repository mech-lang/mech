
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a1643c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_>:
102a1643c:     	sub	sp, sp, #0xa0
102a16440:     	stp	x24, x23, [sp, #0x60]
102a16444:     	stp	x22, x21, [sp, #0x70]
102a16448:     	stp	x20, x19, [sp, #0x80]
102a1644c:     	stp	x29, x30, [sp, #0x90]
102a16450:     	add	x29, sp, #0x90
102a16454:     	mov	x19, x8
102a16458:     	ldp	x8, x21, [x0]
102a1645c:     	cmp	x8, x21
102a16460:     	b.eq	0x102a165a4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x168>
102a16464:     	ldr	x22, [x0, #0x10]
102a16468:     	mov	x9, x8
102a1646c:     	b	0x102a1647c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x40>
102a16470:     	mov	x8, x9
102a16474:     	cmp	x9, x21
102a16478:     	b.eq	0x102a165a4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x168>
102a1647c:     	ldrb	w20, [x9], #0x20
102a16480:     	sub	w10, w20, #0x2
102a16484:     	cmp	w10, #0x3
102a16488:     	b.hi	0x102a16470 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x34>
102a1648c:     	ldr	w10, [x8, #0x4]
102a16490:     	ldr	w11, [x22]
102a16494:     	cmp	w10, w11
102a16498:     	b.ne	0x102a16470 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x34>
102a1649c:     	add	x23, x8, #0x20
102a164a0:     	str	x23, [x0]
102a164a4:     	ldur	q0, [x8, #0x1]
102a164a8:     	str	q0, [sp, #0x20]
102a164ac:     	ldr	q0, [x8, #0x10]
102a164b0:     	stur	q0, [sp, #0x2f]
102a164b4:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a164b8:     	mov	w0, #0x80               ; =128
102a164bc:     	mov	w1, #0x8                ; =8
102a164c0:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a164c4:     	cbz	x0, 0x102a165c8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x18c>
102a164c8:     	strb	w20, [x0]
102a164cc:     	ldr	q0, [sp, #0x20]
102a164d0:     	stur	q0, [x0, #0x1]
102a164d4:     	ldur	q0, [sp, #0x2f]
102a164d8:     	str	q0, [x0, #0x10]
102a164dc:     	mov	w8, #0x4                ; =4
102a164e0:     	stp	x8, x0, [sp, #0x8]
102a164e4:     	mov	w8, #0x1                ; =1
102a164e8:     	str	x8, [sp, #0x18]
102a164ec:     	cmp	x23, x21
102a164f0:     	b.eq	0x102a16590 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x154>
102a164f4:     	mov	w20, #0x1               ; =1
102a164f8:     	mov	x8, x23
102a164fc:     	b	0x102a1650c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0xd0>
102a16500:     	mov	x23, x8
102a16504:     	cmp	x8, x21
102a16508:     	b.eq	0x102a16590 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x154>
102a1650c:     	ldrb	w24, [x8], #0x20
102a16510:     	sub	w9, w24, #0x2
102a16514:     	cmp	w9, #0x3
102a16518:     	b.hi	0x102a16500 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0xc4>
102a1651c:     	ldr	w9, [x23, #0x4]
102a16520:     	ldr	w10, [x22]
102a16524:     	cmp	w9, w10
102a16528:     	b.ne	0x102a16500 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0xc4>
102a1652c:     	ldur	q0, [x23, #0x1]
102a16530:     	ldr	q1, [x23, #0x10]
102a16534:     	stur	q1, [sp, #0x4f]
102a16538:     	str	q0, [sp, #0x40]
102a1653c:     	ldr	x8, [sp, #0x8]
102a16540:     	cmp	x20, x8
102a16544:     	b.ne	0x102a16564 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x128>
102a16548:     	add	x0, sp, #0x8
102a1654c:     	mov	x1, x20
102a16550:     	mov	w2, #0x1                ; =1
102a16554:     	mov	w3, #0x8                ; =8
102a16558:     	mov	w4, #0x20               ; =32
102a1655c:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a16560:     	ldr	x0, [sp, #0x10]
102a16564:     	add	x23, x23, #0x20
102a16568:     	add	x8, x0, x20, lsl #5
102a1656c:     	strb	w24, [x8]
102a16570:     	ldur	q0, [sp, #0x4f]
102a16574:     	ldr	q1, [sp, #0x40]
102a16578:     	stur	q1, [x8, #0x1]
102a1657c:     	str	q0, [x8, #0x10]
102a16580:     	add	x20, x20, #0x1
102a16584:     	str	x20, [sp, #0x18]
102a16588:     	cmp	x23, x21
102a1658c:     	b.ne	0x102a164f8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0xbc>
102a16590:     	ldur	q0, [sp, #0x8]
102a16594:     	str	q0, [x19]
102a16598:     	ldr	x8, [sp, #0x18]
102a1659c:     	str	x8, [x19, #0x10]
102a165a0:     	b	0x102a165b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x174>
102a165a4:     	mov	w8, #0x8                ; =8
102a165a8:     	stp	xzr, x8, [x19]
102a165ac:     	str	xzr, [x19, #0x10]
102a165b0:     	ldp	x29, x30, [sp, #0x90]
102a165b4:     	ldp	x20, x19, [sp, #0x80]
102a165b8:     	ldp	x22, x21, [sp, #0x70]
102a165bc:     	ldp	x24, x23, [sp, #0x60]
102a165c0:     	add	sp, sp, #0xa0
102a165c4:     	ret
102a165c8:     	mov	w0, #0x8                ; =8
102a165cc:     	mov	w1, #0x80               ; =128
102a165d0:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a165d4:     	mov	x19, x0
102a165d8:     	ldr	x8, [sp, #0x8]
102a165dc:     	cbz	x8, 0x102a165f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_+0x1b4>
102a165e0:     	ldr	x0, [sp, #0x10]
102a165e4:     	lsl	x1, x8, #5
102a165e8:     	mov	w2, #0x8                ; =8
102a165ec:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a165f0:     	mov	x0, x19
102a165f4:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
