
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023a969c <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current>:
1023a969c:     	stp	x22, x21, [sp, #-0x30]!
1023a96a0:     	stp	x20, x19, [sp, #0x10]
1023a96a4:     	stp	x29, x30, [sp, #0x20]
1023a96a8:     	add	x29, sp, #0x20
1023a96ac:     	sub	sp, sp, #0x7a0
1023a96b0:     	str	xzr, [sp]
1023a96b4:     	mov	x3, x1
1023a96b8:     	mov	x19, x8
1023a96bc:     	ldr	w2, [x0, #0x110]
1023a96c0:     	ldr	x8, [x0, #0x4b8]
1023a96c4:     	add	x9, x0, #0x180
1023a96c8:     	ldr	x10, [x0, #0x4c0]
1023a96cc:     	mov	w11, #0x10              ; =16
1023a96d0:     	str	x11, [sp, #0x760]
1023a96d4:     	str	xzr, [sp, #0x768]
1023a96d8:     	str	x9, [sp, #0x790]
1023a96dc:     	str	x8, [sp, #0x770]
1023a96e0:     	str	x10, [sp, #0x778]
1023a96e4:     	ldp	q0, q1, [x0, #0x200]
1023a96e8:     	str	q0, [sp, #0x730]
1023a96ec:     	str	q1, [sp, #0x740]
1023a96f0:     	ldr	x8, [x0, #0x220]
1023a96f4:     	str	x8, [sp, #0x750]
1023a96f8:     	ldp	q0, q1, [x0, #0x1c0]
1023a96fc:     	str	q0, [sp, #0x6f0]
1023a9700:     	str	q1, [sp, #0x700]
1023a9704:     	ldp	q1, q0, [x0, #0x1e0]
1023a9708:     	str	q0, [sp, #0x720]
1023a970c:     	str	q1, [sp, #0x710]
1023a9710:     	ldp	q0, q1, [x0, #0x180]
1023a9714:     	str	q0, [sp, #0x6b0]
1023a9718:     	str	q1, [sp, #0x6c0]
1023a971c:     	ldp	q1, q0, [x0, #0x1a0]
1023a9720:     	str	q0, [sp, #0x6e0]
1023a9724:     	str	q1, [sp, #0x6d0]
1023a9728:     	mov	w8, #0x8                ; =8
1023a972c:     	str	x8, [sp, #0x780]
1023a9730:     	str	xzr, [sp, #0x788]
1023a9734:     	mov	w8, #0x1                ; =1
1023a9738:     	str	w8, [sp, #0x758]
1023a973c:     	str	w2, [sp, #0x75c]
1023a9740:     	add	x21, sp, #0x30
1023a9744:     	add	x0, sp, #0x30
1023a9748:     	add	x1, sp, #0x6b0
1023a974c:     	bl	0x102a047c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory>
1023a9750:     	ldr	x20, [sp, #0x30]
1023a9754:     	ldur	q0, [sp, #0x38]
1023a9758:     	ldur	q1, [sp, #0x48]
1023a975c:     	stp	q0, q1, [sp]
1023a9760:     	ldur	q0, [sp, #0x58]
1023a9764:     	str	q0, [sp, #0x20]
1023a9768:     	cmp	x20, #0x2
1023a976c:     	b.ne	0x1023a97ac <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x110>
1023a9770:     	ldp	q0, q1, [sp]
1023a9774:     	stur	q0, [sp, #0x37]
1023a9778:     	stur	q1, [sp, #0x47]
1023a977c:     	ldp	q1, q0, [sp, #0x20]
1023a9780:     	stur	q1, [sp, #0x57]
1023a9784:     	ldr	q1, [sp, #0x40]
1023a9788:     	stur	q0, [x19, #0x9]
1023a978c:     	mov	w8, #0x2a               ; =42
1023a9790:     	strb	w8, [x19, #0x8]
1023a9794:     	stur	q1, [x19, #0x19]
1023a9798:     	ldr	q0, [sp, #0x50]
1023a979c:     	stur	q0, [x19, #0x29]
1023a97a0:     	ldur	x8, [sp, #0x5f]
1023a97a4:     	str	x8, [x19, #0x38]
1023a97a8:     	b	0x1023a97d0 <__RNvMs4_NtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocationNtB7_20NativeCollectionCall12plan_current+0x134>
1023a97ac:     	add	x0, x19, #0x38
1023a97b0:     	add	x1, x21, #0x38
1023a97b4:     	mov	w2, #0x648              ; =1608
1023a97b8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1023a97bc:     	ldp	q0, q1, [sp]
1023a97c0:     	stur	q0, [x19, #0x8]
1023a97c4:     	stur	q1, [x19, #0x18]
1023a97c8:     	ldr	q0, [sp, #0x20]
1023a97cc:     	stur	q0, [x19, #0x28]
1023a97d0:     	str	x20, [x19]
1023a97d4:     	add	sp, sp, #0x7a0
1023a97d8:     	ldp	x29, x30, [sp, #0x20]
1023a97dc:     	ldp	x20, x19, [sp, #0x10]
1023a97e0:     	ldp	x22, x21, [sp], #0x30
1023a97e4:     	ret
