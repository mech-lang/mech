
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001029807ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_>:
1029807ac:     	stp	x24, x23, [sp, #-0x40]!
1029807b0:     	stp	x22, x21, [sp, #0x10]
1029807b4:     	stp	x20, x19, [sp, #0x20]
1029807b8:     	stp	x29, x30, [sp, #0x30]
1029807bc:     	add	x29, sp, #0x30
1029807c0:     	mov	x19, x2
1029807c4:     	mov	x20, x1
1029807c8:     	cmp	x3, #0x8
1029807cc:     	b.lo	0x102980828 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_+0x7c>
1029807d0:     	lsr	x21, x3, #3
1029807d4:     	lsl	x23, x21, #8
1029807d8:     	lsl	x8, x21, #9
1029807dc:     	sub	x24, x8, x21, lsl #6
1029807e0:     	add	x1, x0, x23
1029807e4:     	add	x2, x0, x24
1029807e8:     	mov	x3, x21
1029807ec:     	bl	0x1029807ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_>
1029807f0:     	mov	x22, x0
1029807f4:     	add	x1, x20, x23
1029807f8:     	add	x2, x20, x24
1029807fc:     	mov	x0, x20
102980800:     	mov	x3, x21
102980804:     	bl	0x1029807ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_>
102980808:     	mov	x20, x0
10298080c:     	add	x1, x19, x23
102980810:     	add	x2, x19, x24
102980814:     	mov	x0, x19
102980818:     	mov	x3, x21
10298081c:     	bl	0x1029807ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_>
102980820:     	mov	x19, x0
102980824:     	mov	x0, x22
102980828:     	ldrb	w12, [x0]
10298082c:     	ldrh	w13, [x0, #0x2]
102980830:     	ldrb	w8, [x19]
102980834:     	ldrh	w9, [x19, #0x2]
102980838:     	cmp	w13, w9
10298083c:     	cset	w14, lo
102980840:     	subs	w10, w12, w8
102980844:     	mov	w15, #0xff              ; =255
102980848:     	bics	wzr, w15, w10
10298084c:     	cset	w16, eq
102980850:     	ldrb	w10, [x20]
102980854:     	ldrh	w11, [x20, #0x2]
102980858:     	cmp	w12, w8
10298085c:     	csel	w14, w14, w16, eq
102980860:     	cmp	w13, w11
102980864:     	cset	w13, lo
102980868:     	subs	w16, w12, w10
10298086c:     	bics	wzr, w15, w16
102980870:     	cset	w15, eq
102980874:     	cmp	w12, w10
102980878:     	csel	w12, w13, w15, eq
10298087c:     	cmp	w12, w14
102980880:     	b.ne	0x1029808ac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7P_+0x100>
102980884:     	cmp	w11, w9
102980888:     	cset	w9, lo
10298088c:     	subs	w11, w10, w8
102980890:     	cmn	w11, #0x1
102980894:     	cset	w11, eq
102980898:     	cmp	w10, w8
10298089c:     	csel	w8, w9, w11, eq
1029808a0:     	eor	w8, w12, w8
1029808a4:     	cmp	w8, #0x0
1029808a8:     	csel	x0, x19, x20, ne
1029808ac:     	ldp	x29, x30, [sp, #0x30]
1029808b0:     	ldp	x20, x19, [sp, #0x20]
1029808b4:     	ldp	x22, x21, [sp, #0x10]
1029808b8:     	ldp	x24, x23, [sp], #0x40
1029808bc:     	ret
