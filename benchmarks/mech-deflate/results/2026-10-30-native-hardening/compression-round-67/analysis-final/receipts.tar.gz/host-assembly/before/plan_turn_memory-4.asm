
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027fdac0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory>:
1027fdac0:     	stp	x28, x27, [sp, #-0x60]!
1027fdac4:     	stp	x26, x25, [sp, #0x10]
1027fdac8:     	stp	x24, x23, [sp, #0x20]
1027fdacc:     	stp	x22, x21, [sp, #0x30]
1027fdad0:     	stp	x20, x19, [sp, #0x40]
1027fdad4:     	stp	x29, x30, [sp, #0x50]
1027fdad8:     	add	x29, sp, #0x50
1027fdadc:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
1027fdae0:     	str	xzr, [sp]
1027fdae4:     	sub	sp, sp, #0xc50
1027fdae8:     	str	xzr, [sp]
1027fdaec:     	mov	x26, x2
1027fdaf0:     	mov	x21, x0
1027fdaf4:     	mov	x22, x8
1027fdaf8:     	str	w1, [sp, #0xc4]
1027fdafc:     	ldp	x8, x9, [x0, #0xa8]
1027fdb00:     	mov	w10, #0x1c0             ; =448
1027fdb04:     	madd	x9, x9, x10, x8
1027fdb08:     	stp	x8, x9, [sp, #0xe0]
1027fdb0c:     	add	x8, sp, #0xc4
1027fdb10:     	str	x8, [sp, #0xf0]
1027fdb14:     	add	x8, sp, #0xc8
1027fdb18:     	add	x0, sp, #0xe0
1027fdb1c:     	bl	0x102a16278 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_>
1027fdb20:     	ldp	x27, x24, [x21, #0xb8]
1027fdb24:     	str	x22, [sp, #0x40]
1027fdb28:     	cbz	x24, 0x1027fdbc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x104>
1027fdb2c:     	ldr	w9, [sp, #0xc4]
1027fdb30:     	cmp	x24, #0x1
1027fdb34:     	b.ne	0x1027fdb40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x80>
1027fdb38:     	mov	x8, #0x0                ; =0
1027fdb3c:     	b	0x1027fdb68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xa8>
1027fdb40:     	mov	x8, #0x0                ; =0
1027fdb44:     	mov	x10, x24
1027fdb48:     	lsr	x11, x10, #1
1027fdb4c:     	add	x12, x11, x8
1027fdb50:     	ldr	w13, [x27, x12, lsl #2]
1027fdb54:     	cmp	w13, w9
1027fdb58:     	csel	x8, x8, x12, hi
1027fdb5c:     	sub	x10, x10, x11
1027fdb60:     	cmp	x10, #0x1
1027fdb64:     	b.hi	0x1027fdb48 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x88>
1027fdb68:     	ldr	w10, [x27, x8, lsl #2]
1027fdb6c:     	cmp	w10, w9
1027fdb70:     	b.ne	0x1027fdbc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x104>
1027fdb74:     	ldp	x11, x9, [x21, #0xc8]
1027fdb78:     	str	x9, [sp, #0xb8]
1027fdb7c:     	cmp	x8, x9
1027fdb80:     	b.hs	0x1027fe55c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xa9c>
1027fdb84:     	mov	w9, #0x3e8              ; =1000
1027fdb88:     	madd	x8, x8, x9, x11
1027fdb8c:     	ldr	x10, [x8, #0x360]
1027fdb90:     	add	x9, x10, x10, lsl #1
1027fdb94:     	lsl	x20, x9, #2
1027fdb98:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
1027fdb9c:     	movk	x9, #0xaaab
1027fdba0:     	movk	x9, #0xaaa, lsl #48
1027fdba4:     	sub	x9, x9, #0x1
1027fdba8:     	cmp	x10, x9
1027fdbac:     	b.ls	0x1027fe56c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xaac>
1027fdbb0:     	mov	x25, #0x0               ; =0
1027fdbb4:     	mov	x0, x25
1027fdbb8:     	mov	x1, x20
1027fdbbc:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027fdbc0:     	b	0x1027ffa40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f80>
1027fdbc4:     	str	xzr, [sp, #0x30]
1027fdbc8:     	mov	x11, #0x0               ; =0
1027fdbcc:     	ldp	x8, x9, [x21, #0xc8]
1027fdbd0:     	str	x9, [sp, #0xb8]
1027fdbd4:     	str	x8, [sp, #0x48]
1027fdbd8:     	mov	w23, #0x4               ; =4
1027fdbdc:     	add	x22, sp, #0x1, lsl #12  ; =0x1000
1027fdbe0:     	add	x22, x22, #0x1e0
1027fdbe4:     	ldp	x8, x9, [sp, #0xd0]
1027fdbe8:     	mov	w10, #0xc               ; =12
1027fdbec:     	madd	x9, x9, x10, x8
1027fdbf0:     	str	x8, [x22, #0x400]
1027fdbf4:     	str	x9, [x22, #0x408]
1027fdbf8:     	stp	x11, x23, [sp, #0x20]
1027fdbfc:     	madd	x8, x11, x10, x23
1027fdc00:     	str	x23, [x22, #0x410]
1027fdc04:     	str	x8, [x22, #0x418]
1027fdc08:     	mov	w25, #0x1               ; =1
1027fdc0c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fdc10:     	add	x8, x8, #0x1e0
1027fdc14:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fdc18:     	add	x0, x0, #0x5e0
1027fdc1c:     	bl	0x102a03c4c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys1_0EE9from_iterB4Q_>
1027fdc20:     	add	x23, sp, #0xdd0
1027fdc24:     	ldr	x19, [x23, #0x420]
1027fdc28:     	str	x26, [sp, #0xb0]
1027fdc2c:     	cbz	x19, 0x1027fdc6c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ac>
1027fdc30:     	ldr	x20, [x23, #0x418]
1027fdc34:     	cmp	x19, #0x1
1027fdc38:     	b.ne	0x1027ff6fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c3c>
1027fdc3c:     	ldr	x8, [x23, #0x410]
1027fdc40:     	str	x20, [x22, #0x400]
1027fdc44:     	add	x9, x20, x19, lsl #2
1027fdc48:     	str	x20, [x22, #0x408]
1027fdc4c:     	str	x8, [x22, #0x410]
1027fdc50:     	str	x9, [x22, #0x418]
1027fdc54:     	mov	w25, #0x1               ; =1
1027fdc58:     	add	x8, sp, #0xf8
1027fdc5c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fdc60:     	add	x0, x0, #0x5e0
1027fdc64:     	bl	0x10250da5c <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4D_8BTreeSetB18_E16from_sorted_iterB3S_E0EECs1qJAwyMG1lC_11mech_engine>
1027fdc68:     	b	0x1027fdc8c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1cc>
1027fdc6c:     	str	xzr, [sp, #0xf8]
1027fdc70:     	str	xzr, [sp, #0x108]
1027fdc74:     	ldr	x8, [x23, #0x410]
1027fdc78:     	cbz	x8, 0x1027fdc8c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1cc>
1027fdc7c:     	ldr	x0, [x23, #0x418]
1027fdc80:     	lsl	x1, x8, #2
1027fdc84:     	mov	w2, #0x4                ; =4
1027fdc88:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fdc8c:     	ldp	x28, x8, [x21, #0xd8]
1027fdc90:     	mov	w9, #0x60               ; =96
1027fdc94:     	madd	x26, x8, x9, x28
1027fdc98:     	str	x28, [x22, #0x400]
1027fdc9c:     	str	x26, [x22, #0x408]
1027fdca0:     	add	x8, sp, #0xf8
1027fdca4:     	str	x8, [x22, #0x410]
1027fdca8:     	mov	w25, #0x1               ; =1
1027fdcac:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fdcb0:     	add	x8, x8, #0x1e0
1027fdcb4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fdcb8:     	add	x0, x0, #0x5e0
1027fdcbc:     	bl	0x102a04420 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_>
1027fdcc0:     	ldr	x25, [x23, #0x420]
1027fdcc4:     	cbz	x25, 0x1027fdd0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x24c>
1027fdcc8:     	ldr	x20, [x23, #0x418]
1027fdccc:     	cmp	x25, #0x1
1027fdcd0:     	add	x23, sp, #0xdd0
1027fdcd4:     	b.ne	0x1027ff764 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ca4>
1027fdcd8:     	ldr	x8, [x23, #0x410]
1027fdcdc:     	str	x20, [x22, #0x400]
1027fdce0:     	add	x9, x20, x25, lsl #3
1027fdce4:     	str	x20, [x22, #0x408]
1027fdce8:     	str	x8, [x22, #0x410]
1027fdcec:     	str	x9, [x22, #0x418]
1027fdcf0:     	mov	w25, #0x1               ; =1
1027fdcf4:     	add	x8, sp, #0x110
1027fdcf8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fdcfc:     	add	x0, x0, #0x5e0
1027fdd00:     	bl	0x10250db28 <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4G_8BTreeSetB18_E16from_sorted_iterB3V_E0EECs1qJAwyMG1lC_11mech_engine>
1027fdd04:     	add	x23, sp, #0xdd0
1027fdd08:     	b	0x1027fdd2c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x26c>
1027fdd0c:     	str	xzr, [sp, #0x110]
1027fdd10:     	str	xzr, [sp, #0x120]
1027fdd14:     	ldr	x8, [x23, #0x410]
1027fdd18:     	cbz	x8, 0x1027fdd2c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x26c>
1027fdd1c:     	ldr	x0, [x23, #0x418]
1027fdd20:     	lsl	x1, x8, #3
1027fdd24:     	mov	w2, #0x4                ; =4
1027fdd28:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fdd2c:     	cbz	x24, 0x1027fdd44 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x284>
1027fdd30:     	ldr	w8, [sp, #0xc4]
1027fdd34:     	cmp	x24, #0x1
1027fdd38:     	b.ne	0x1027fdd50 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x290>
1027fdd3c:     	mov	x9, #0x0                ; =0
1027fdd40:     	b	0x1027fdd78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2b8>
1027fdd44:     	mov	w8, #0x0                ; =0
1027fdd48:     	mov	x9, x24
1027fdd4c:     	b	0x1027fdd8c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2cc>
1027fdd50:     	mov	x9, #0x0                ; =0
1027fdd54:     	mov	x10, x24
1027fdd58:     	lsr	x11, x10, #1
1027fdd5c:     	add	x12, x11, x9
1027fdd60:     	ldr	w13, [x27, x12, lsl #2]
1027fdd64:     	cmp	w13, w8
1027fdd68:     	csel	x9, x9, x12, hi
1027fdd6c:     	sub	x10, x10, x11
1027fdd70:     	cmp	x10, #0x1
1027fdd74:     	b.hi	0x1027fdd58 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x298>
1027fdd78:     	ldr	w10, [x27, x9, lsl #2]
1027fdd7c:     	cmp	w10, w8
1027fdd80:     	cinc	x8, x9, lo
1027fdd84:     	csel	x9, x9, x8, eq
1027fdd88:     	cset	w8, eq
1027fdd8c:     	ldr	x10, [sp, #0xb8]
1027fdd90:     	cmp	x9, x10
1027fdd94:     	cset	w10, lo
1027fdd98:     	mov	w11, #0x3e8             ; =1000
1027fdd9c:     	ldr	x12, [sp, #0x48]
1027fdda0:     	madd	x9, x9, x11, x12
1027fdda4:     	tst	w8, w10
1027fdda8:     	mov	w25, #0x1               ; =1
1027fddac:     	str	x25, [x22, #0x400]
1027fddb0:     	csel	x8, x9, xzr, ne
1027fddb4:     	str	x8, [x22, #0x408]
1027fddb8:     	str	xzr, [x22, #0x410]
1027fddbc:     	str	xzr, [x22, #0x438]
1027fddc0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fddc4:     	add	x8, x8, #0x1e0
1027fddc8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fddcc:     	add	x0, x0, #0x5e0
1027fddd0:     	bl	0x102a03e00 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_>
1027fddd4:     	ldr	x19, [x23, #0x420]
1027fddd8:     	cbz	x19, 0x1027fde18 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x358>
1027fdddc:     	ldr	x20, [x23, #0x418]
1027fdde0:     	cmp	x19, #0x1
1027fdde4:     	b.ne	0x1027ff7a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ce0>
1027fdde8:     	ldr	x8, [x23, #0x410]
1027fddec:     	str	x20, [x22, #0x400]
1027fddf0:     	add	x9, x20, x19, lsl #2
1027fddf4:     	str	x20, [x22, #0x408]
1027fddf8:     	str	x8, [x22, #0x410]
1027fddfc:     	str	x9, [x22, #0x418]
1027fde00:     	mov	w25, #0x1               ; =1
1027fde04:     	add	x8, sp, #0x128
1027fde08:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fde0c:     	add	x0, x0, #0x5e0
1027fde10:     	bl	0x10250da5c <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4D_8BTreeSetB18_E16from_sorted_iterB3S_E0EECs1qJAwyMG1lC_11mech_engine>
1027fde14:     	b	0x1027fde38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x378>
1027fde18:     	str	xzr, [sp, #0x128]
1027fde1c:     	str	xzr, [sp, #0x138]
1027fde20:     	ldr	x8, [x23, #0x410]
1027fde24:     	cbz	x8, 0x1027fde38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x378>
1027fde28:     	ldr	x0, [x23, #0x418]
1027fde2c:     	lsl	x1, x8, #2
1027fde30:     	mov	w2, #0x4                ; =4
1027fde34:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fde38:     	str	x28, [x22, #0x400]
1027fde3c:     	str	x26, [x22, #0x408]
1027fde40:     	add	x8, sp, #0x128
1027fde44:     	str	x8, [x22, #0x410]
1027fde48:     	mov	w25, #0x1               ; =1
1027fde4c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fde50:     	add	x8, x8, #0x1e0
1027fde54:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fde58:     	add	x0, x0, #0x5e0
1027fde5c:     	bl	0x102a04420 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_>
1027fde60:     	add	x20, sp, #0x140
1027fde64:     	ldr	x25, [x23, #0x420]
1027fde68:     	cbz	x25, 0x1027fdeac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x3ec>
1027fde6c:     	add	x19, sp, #0xdd0
1027fde70:     	ldr	x23, [x19, #0x418]
1027fde74:     	cmp	x25, #0x1
1027fde78:     	b.ne	0x1027ff808 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d48>
1027fde7c:     	ldr	x8, [x19, #0x410]
1027fde80:     	str	x23, [x22, #0x400]
1027fde84:     	add	x9, x23, x25, lsl #3
1027fde88:     	str	x23, [x22, #0x408]
1027fde8c:     	str	x8, [x22, #0x410]
1027fde90:     	str	x9, [x22, #0x418]
1027fde94:     	mov	w25, #0x1               ; =1
1027fde98:     	add	x8, sp, #0x140
1027fde9c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fdea0:     	add	x0, x0, #0x5e0
1027fdea4:     	bl	0x10250db28 <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4G_8BTreeSetB18_E16from_sorted_iterB3V_E0EECs1qJAwyMG1lC_11mech_engine>
1027fdea8:     	b	0x1027fdecc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x40c>
1027fdeac:     	str	xzr, [sp, #0x140]
1027fdeb0:     	str	xzr, [x20, #0x10]
1027fdeb4:     	ldr	x8, [x23, #0x410]
1027fdeb8:     	cbz	x8, 0x1027fdecc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x40c>
1027fdebc:     	ldr	x0, [x23, #0x418]
1027fdec0:     	lsl	x1, x8, #3
1027fdec4:     	mov	w2, #0x4                ; =4
1027fdec8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fdecc:     	stp	x28, x26, [x20, #0x30]
1027fded0:     	add	x8, sp, #0xc4
1027fded4:     	add	x9, sp, #0x128
1027fded8:     	stp	x8, x9, [x20, #0x40]
1027fdedc:     	add	x8, sp, #0xf8
1027fdee0:     	stp	x20, x8, [x20, #0x50]
1027fdee4:     	add	x8, sp, #0x110
1027fdee8:     	str	x8, [x20, #0x60]
1027fdeec:     	add	x8, sp, #0x158
1027fdef0:     	add	x0, sp, #0x170
1027fdef4:     	bl	0x102a15ff0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0EEE9from_iterB4u_>
1027fdef8:     	ldr	x28, [sp, #0xb0]
1027fdefc:     	mov	x23, x28
1027fdf00:     	ldr	x9, [x23, #0xb8]!
1027fdf04:     	mov	w8, #0x4                ; =4
1027fdf08:     	stp	xzr, x8, [x20, #0x68]
1027fdf0c:     	ldp	x10, x11, [x23, #0x8]
1027fdf10:     	stp	x10, x9, [sp, #0x60]
1027fdf14:     	ldp	x9, x10, [x23, #0x18]
1027fdf18:     	stp	x9, x11, [sp, #0x50]
1027fdf1c:     	ldp	x9, x8, [x23, #0x28]
1027fdf20:     	stp	x9, x10, [sp, #0xa0]
1027fdf24:     	str	x8, [sp, #0x38]
1027fdf28:     	ldp	x9, x8, [x23, #0x38]
1027fdf2c:     	stp	x8, x9, [sp, #0x90]
1027fdf30:     	ldp	x9, x8, [x23, #0x48]
1027fdf34:     	stp	x8, x9, [sp, #0x80]
1027fdf38:     	ldr	x8, [x23, #0x58]
1027fdf3c:     	str	x8, [sp, #0x78]
1027fdf40:     	ldp	w8, w12, [x23, #0x60]
1027fdf44:     	str	w8, [sp, #0x74]
1027fdf48:     	mov	w8, #0x2                ; =2
1027fdf4c:     	stp	xzr, x8, [x20, #0x78]
1027fdf50:     	cbz	x24, 0x1027fe49c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x9dc>
1027fdf54:     	mov	x26, #0x0               ; =0
1027fdf58:     	ldr	w8, [sp, #0xc4]
1027fdf5c:     	cmp	x24, #0x1
1027fdf60:     	b.eq	0x1027fdf88 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x4c8>
1027fdf64:     	mov	x26, #0x0               ; =0
1027fdf68:     	lsr	x9, x24, #1
1027fdf6c:     	add	x10, x9, x26
1027fdf70:     	ldr	w11, [x27, x10, lsl #2]
1027fdf74:     	cmp	w11, w8
1027fdf78:     	csel	x26, x26, x10, hi
1027fdf7c:     	sub	x24, x24, x9
1027fdf80:     	cmp	x24, #0x1
1027fdf84:     	b.hi	0x1027fdf68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x4a8>
1027fdf88:     	ldr	w9, [x27, x26, lsl #2]
1027fdf8c:     	cmp	w9, w8
1027fdf90:     	b.ne	0x1027fe248 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x788>
1027fdf94:     	ldr	x8, [sp, #0xb8]
1027fdf98:     	cmp	x26, x8
1027fdf9c:     	b.hs	0x1027fe248 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x788>
1027fdfa0:     	ldp	x19, x27, [x28, #0x88]
1027fdfa4:     	ldr	x8, [x28, #0x98]
1027fdfa8:     	cmp	x19, #0x0
1027fdfac:     	csel	x8, x8, xzr, ne
1027fdfb0:     	cset	w9, ne
1027fdfb4:     	str	x9, [x22, #0x400]
1027fdfb8:     	str	xzr, [x22, #0x408]
1027fdfbc:     	str	x19, [x22, #0x410]
1027fdfc0:     	str	x27, [x22, #0x418]
1027fdfc4:     	str	x9, [x22, #0x420]
1027fdfc8:     	str	xzr, [x22, #0x428]
1027fdfcc:     	str	x19, [x22, #0x430]
1027fdfd0:     	str	x27, [x22, #0x438]
1027fdfd4:     	str	x8, [x22, #0x440]
1027fdfd8:     	add	x8, sp, #0xc4
1027fdfdc:     	str	x8, [x22, #0x448]
1027fdfe0:     	mov	w25, #0x1               ; =1
1027fdfe4:     	add	x8, sp, #0x5a8
1027fdfe8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fdfec:     	add	x0, x0, #0x5e0
1027fdff0:     	bl	0x10254dfa4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EEB6n_>
1027fdff4:     	mov	w8, #0x3e8              ; =1000
1027fdff8:     	ldr	x9, [sp, #0x48]
1027fdffc:     	madd	x25, x26, x8, x9
1027fe000:     	add	x0, sp, #0x5c0
1027fe004:     	mov	x1, x25
1027fe008:     	bl	0x1028173b4 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
1027fe00c:     	ldr	x10, [x20, #0x790]
1027fe010:     	cbz	x10, 0x1027fe0e0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x620>
1027fe014:     	ldr	x8, [x28, #0x70]
1027fe018:     	cbz	x8, 0x1027fe0e0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x620>
1027fe01c:     	mov	x13, #0x0               ; =0
1027fe020:     	ldr	x9, [x20, #0x788]
1027fe024:     	mov	w11, #0x30              ; =48
1027fe028:     	madd	x10, x10, x11, x9
1027fe02c:     	ldr	w11, [sp, #0xc4]
1027fe030:     	ldr	x12, [x28, #0x78]
1027fe034:     	mov	x14, x9
1027fe038:     	add	x9, x9, #0x30
1027fe03c:     	and	w15, w13, #0xffff
1027fe040:     	add	x13, x13, #0x1
1027fe044:     	mov	x16, x12
1027fe048:     	mov	x17, x8
1027fe04c:     	add	x4, x17, #0x218
1027fe050:     	ldrh	w2, [x17, #0x272]
1027fe054:     	sub	x1, x17, #0x30
1027fe058:     	lsl	x3, x2, #3
1027fe05c:     	mov	x0, #-0x1               ; =-1
1027fe060:     	cbz	x3, 0x1027fe0b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x5f0>
1027fe064:     	ldr	w5, [x4]
1027fe068:     	ldrh	w6, [x4, #0x4]
1027fe06c:     	add	x4, x4, #0x8
1027fe070:     	cmp	w15, w6
1027fe074:     	cset	w6, hi
1027fe078:     	csinv	w6, w6, wzr, hs
1027fe07c:     	cmp	w11, w5
1027fe080:     	cset	w5, hi
1027fe084:     	csinv	w5, w5, wzr, hs
1027fe088:     	csel	w5, w6, w5, eq
1027fe08c:     	add	x1, x1, #0x30
1027fe090:     	add	x0, x0, #0x1
1027fe094:     	sub	x3, x3, #0x8
1027fe098:     	and	w5, w5, #0xff
1027fe09c:     	cmp	w5, #0x1
1027fe0a0:     	b.eq	0x1027fe060 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x5a0>
1027fe0a4:     	cbz	w5, 0x1027fe0c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x608>
1027fe0a8:     	cbnz	x16, 0x1027fe0b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x5f8>
1027fe0ac:     	b	0x1027fe0d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x618>
1027fe0b0:     	mov	x0, x2
1027fe0b4:     	cbz	x16, 0x1027fe0d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x618>
1027fe0b8:     	add	x17, x17, x0, lsl #3
1027fe0bc:     	ldr	x17, [x17, #0x278]
1027fe0c0:     	sub	x16, x16, #0x1
1027fe0c4:     	b	0x1027fe04c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x58c>
1027fe0c8:     	ldp	q0, q1, [x1]
1027fe0cc:     	ldr	q2, [x1, #0x20]
1027fe0d0:     	stp	q1, q2, [x14, #0x10]
1027fe0d4:     	str	q0, [x14]
1027fe0d8:     	cmp	x9, x10
1027fe0dc:     	b.ne	0x1027fe034 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x574>
1027fe0e0:     	ldr	x8, [x20, #0x740]
1027fe0e4:     	str	xzr, [x20, #0x898]
1027fe0e8:     	str	x8, [x20, #0x8a0]
1027fe0ec:     	str	x28, [x20, #0x880]
1027fe0f0:     	add	x8, sp, #0xc4
1027fe0f4:     	str	x8, [x20, #0x888]
1027fe0f8:     	add	x8, sp, #0x5a8
1027fe0fc:     	str	x8, [x20, #0x890]
1027fe100:     	add	x8, sp, #0x9a8
1027fe104:     	add	x0, sp, #0x9c0
1027fe108:     	bl	0x102a2cda8 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0EE9from_iterB48_>
1027fe10c:     	ldr	x24, [x20, #0x870]
1027fe110:     	ldr	x4, [x20, #0x878]
1027fe114:     	ldr	q0, [x20, #0x4f0]
1027fe118:     	add	x26, sp, #0x1, lsl #12  ; =0x1000
1027fe11c:     	add	x26, x26, #0x5e0
1027fe120:     	str	q0, [x26, #0x620]
1027fe124:     	ldr	q0, [x20, #0x500]
1027fe128:     	str	q0, [x26, #0x630]
1027fe12c:     	ldr	q0, [x20, #0x510]
1027fe130:     	str	q0, [x26, #0x640]
1027fe134:     	ldr	x8, [x20, #0x520]
1027fe138:     	str	x8, [x26, #0x650]
1027fe13c:     	ldr	q0, [x20, #0x4b0]
1027fe140:     	str	q0, [x26, #0x5e0]
1027fe144:     	ldr	q0, [x20, #0x4c0]
1027fe148:     	str	q0, [x26, #0x5f0]
1027fe14c:     	ldr	q0, [x20, #0x4d0]
1027fe150:     	str	q0, [x26, #0x600]
1027fe154:     	ldr	q0, [x20, #0x4e0]
1027fe158:     	str	q0, [x26, #0x610]
1027fe15c:     	ldr	q0, [x20, #0x480]
1027fe160:     	str	q0, [x26, #0x5b0]
1027fe164:     	ldr	q0, [x20, #0x490]
1027fe168:     	str	q0, [x26, #0x5c0]
1027fe16c:     	ldr	q0, [x20, #0x4a0]
1027fe170:     	str	q0, [x26, #0x5d0]
1027fe174:     	str	xzr, [x20, #0x480]
1027fe178:     	str	xzr, [x20, #0x490]
1027fe17c:     	str	xzr, [x20, #0x4a0]
1027fe180:     	str	xzr, [x20, #0x4b0]
1027fe184:     	str	xzr, [x20, #0x4c0]
1027fe188:     	str	xzr, [x20, #0x4d0]
1027fe18c:     	str	xzr, [x20, #0x4e0]
1027fe190:     	str	xzr, [x20, #0x4f0]
1027fe194:     	str	xzr, [x20, #0x500]
1027fe198:     	str	xzr, [x20, #0x510]
1027fe19c:     	add	x9, sp, #0x5c0
1027fe1a0:     	str	wzr, [sp, #0x660]
1027fe1a4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fe1a8:     	add	x8, x8, #0x5e0
1027fe1ac:     	add	x0, sp, #0x5c0
1027fe1b0:     	add	x1, x9, #0x208
1027fe1b4:     	add	x2, sp, #0x5a8
1027fe1b8:     	mov	x3, x24
1027fe1bc:     	bl	0x102d71504 <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6derive27resolve_current_call_memory>
1027fe1c0:     	ldr	q0, [x26, #0x620]
1027fe1c4:     	str	q0, [x20, #0x4f0]
1027fe1c8:     	ldr	q0, [x26, #0x630]
1027fe1cc:     	str	q0, [x20, #0x500]
1027fe1d0:     	ldr	q0, [x26, #0x640]
1027fe1d4:     	str	q0, [x20, #0x510]
1027fe1d8:     	ldr	x8, [x26, #0x650]
1027fe1dc:     	str	x8, [x20, #0x520]
1027fe1e0:     	ldr	q0, [x26, #0x5e0]
1027fe1e4:     	str	q0, [x20, #0x4b0]
1027fe1e8:     	ldr	q0, [x26, #0x5f0]
1027fe1ec:     	str	q0, [x20, #0x4c0]
1027fe1f0:     	ldr	q0, [x26, #0x600]
1027fe1f4:     	str	q0, [x20, #0x4d0]
1027fe1f8:     	ldr	q0, [x26, #0x610]
1027fe1fc:     	str	q0, [x20, #0x4e0]
1027fe200:     	ldr	q0, [x26, #0x5b0]
1027fe204:     	str	q0, [x20, #0x480]
1027fe208:     	ldr	q0, [x26, #0x5c0]
1027fe20c:     	str	q0, [x20, #0x490]
1027fe210:     	ldr	q0, [x26, #0x5d0]
1027fe214:     	str	q0, [x20, #0x4a0]
1027fe218:     	ldr	x8, [x22, #0x400]
1027fe21c:     	cmp	x8, #0x2
1027fe220:     	b.ne	0x1027fe5c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xb00>
1027fe224:     	ldur	q0, [x26, #0x8]
1027fe228:     	ldur	q1, [x26, #0x18]
1027fe22c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fe230:     	add	x8, x8, #0x5e0
1027fe234:     	add	x28, sp, #0xdd0
1027fe238:     	stp	q0, q1, [x28, #0x3e0]
1027fe23c:     	ldur	q0, [x8, #0x28]
1027fe240:     	str	q0, [x28, #0x400]
1027fe244:     	b	0x1027fe634 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xb74>
1027fe248:     	str	w12, [sp, #0x48]
1027fe24c:     	mov	x24, #0x0               ; =0
1027fe250:     	mov	x26, #0x0               ; =0
1027fe254:     	str	xzr, [sp, #0xb8]
1027fe258:     	ldp	x27, x25, [sp, #0xc8]
1027fe25c:     	ldr	x19, [sp, #0xd8]
1027fe260:     	sub	x8, x24, x26
1027fe264:     	cmp	x19, x8
1027fe268:     	b.hi	0x1027fe4bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x9fc>
1027fe26c:     	cbz	x19, 0x1027fe28c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x7cc>
1027fe270:     	add	x8, x19, x19, lsl #1
1027fe274:     	lsl	x2, x8, #2
1027fe278:     	ldr	x8, [x20, #0x70]
1027fe27c:     	mov	w9, #0xc                ; =12
1027fe280:     	madd	x0, x26, x9, x8
1027fe284:     	mov	x1, x25
1027fe288:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027fe28c:     	add	x1, x26, x19
1027fe290:     	str	x1, [x20, #0x78]
1027fe294:     	cbz	x27, 0x1027fe2b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x7f0>
1027fe298:     	add	x8, x27, x27, lsl #1
1027fe29c:     	lsl	x1, x8, #2
1027fe2a0:     	mov	x0, x25
1027fe2a4:     	mov	w2, #0x4                ; =4
1027fe2a8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fe2ac:     	ldr	x1, [x20, #0x78]
1027fe2b0:     	ldr	x19, [x20, #0x70]
1027fe2b4:     	sub	x8, x29, #0x61
1027fe2b8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1027fe2bc:     	add	x9, x9, #0x5e0
1027fe2c0:     	str	x8, [x9]
1027fe2c4:     	cmp	x1, #0x2
1027fe2c8:     	b.hs	0x1027ff6b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1bf4>
1027fe2cc:     	mov	w25, #0x0               ; =0
1027fe2d0:     	add	x0, sp, #0x1a8
1027fe2d4:     	bl	0x1029c7488 <__RINvMs_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementE8dedup_byNCNvMs4_B5_Bv_5dedup0ECs1qJAwyMG1lC_11mech_engine>
1027fe2d8:     	ldr	w8, [x28]
1027fe2dc:     	tbz	w8, #0x0, 0x1027fe3ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x92c>
1027fe2e0:     	ldp	x3, x8, [x28, #0x28]
1027fe2e4:     	ldp	x9, x11, [sp, #0xa0]
1027fe2e8:     	cmp	x3, x11
1027fe2ec:     	csel	x10, x3, x11, hi
1027fe2f0:     	cmp	x8, x9
1027fe2f4:     	csel	x9, x8, x9, hi
1027fe2f8:     	stp	x9, x10, [sp, #0xa0]
1027fe2fc:     	ldp	x8, x9, [x28, #0x38]
1027fe300:     	ldr	x10, [sp, #0x38]
1027fe304:     	cmp	x8, x10
1027fe308:     	csel	x10, x8, x10, hi
1027fe30c:     	str	x10, [sp, #0x38]
1027fe310:     	ldp	x13, x8, [sp, #0x90]
1027fe314:     	cmp	x9, x8
1027fe318:     	csel	x8, x9, x8, hi
1027fe31c:     	str	x8, [sp, #0x98]
1027fe320:     	ldp	x8, x9, [x28, #0x48]
1027fe324:     	ldp	x10, x11, [x28, #0x58]
1027fe328:     	ldr	w12, [x28, #0x68]
1027fe32c:     	cmp	x8, x13
1027fe330:     	csel	x13, x8, x13, hi
1027fe334:     	ldr	x8, [sp, #0x88]
1027fe338:     	cmp	x9, x8
1027fe33c:     	csel	x8, x9, x8, hi
1027fe340:     	stp	x8, x13, [sp, #0x88]
1027fe344:     	ldr	x8, [sp, #0x80]
1027fe348:     	cmp	x10, x8
1027fe34c:     	csel	x9, x10, x8, hi
1027fe350:     	ldr	x8, [sp, #0x78]
1027fe354:     	cmp	x11, x8
1027fe358:     	csel	x8, x11, x8, hi
1027fe35c:     	stp	x8, x9, [sp, #0x78]
1027fe360:     	ldr	w8, [sp, #0x74]
1027fe364:     	cmp	w12, w8
1027fe368:     	csel	w8, w12, w8, hi
1027fe36c:     	str	w8, [sp, #0x74]
1027fe370:     	ldp	x8, x9, [x28, #0x8]
1027fe374:     	ldr	x10, [sp, #0x68]
1027fe378:     	cmp	x8, x10
1027fe37c:     	csel	x10, x8, x10, hi
1027fe380:     	ldr	x8, [sp, #0x60]
1027fe384:     	cmp	x9, x8
1027fe388:     	csel	x8, x9, x8, hi
1027fe38c:     	stp	x8, x10, [sp, #0x60]
1027fe390:     	ldp	x8, x9, [x28, #0x18]
1027fe394:     	ldr	x10, [sp, #0x58]
1027fe398:     	cmp	x8, x10
1027fe39c:     	csel	x10, x8, x10, hi
1027fe3a0:     	ldr	x8, [sp, #0x50]
1027fe3a4:     	cmp	x9, x8
1027fe3a8:     	csel	x8, x9, x8, hi
1027fe3ac:     	stp	x8, x10, [sp, #0x50]
1027fe3b0:     	ldr	x8, [sp, #0xb8]
1027fe3b4:     	cmp	x3, x8
1027fe3b8:     	csel	x8, x3, x8, hi
1027fe3bc:     	str	x8, [sp, #0xb8]
1027fe3c0:     	ldp	x1, x2, [x20, #0x20]
1027fe3c4:     	mov	w25, #0x0               ; =0
1027fe3c8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fe3cc:     	add	x0, x0, #0x5e0
1027fe3d0:     	mov	x4, x3
1027fe3d4:     	bl	0x102801f40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn28grow_transaction_stage_total>
1027fe3d8:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1027fe3dc:     	add	x10, x10, #0x5e0
1027fe3e0:     	ldrb	w8, [x10]
1027fe3e4:     	cmp	w8, #0x16
1027fe3e8:     	b.ne	0x1027fe528 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xa68>
1027fe3ec:     	ldp	x1, x2, [x20, #0x20]
1027fe3f0:     	mov	w25, #0x0               ; =0
1027fe3f4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fe3f8:     	add	x0, x0, #0x5e0
1027fe3fc:     	bl	0x10280250c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program17place_allocations>
1027fe400:     	add	x28, sp, #0x1, lsl #12  ; =0x1000
1027fe404:     	add	x28, x28, #0x5e0
1027fe408:     	ldrb	w8, [x28]
1027fe40c:     	cmp	w8, #0x16
1027fe410:     	b.ne	0x1027fe4dc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xa1c>
1027fe414:     	ldp	x9, x24, [x28, #0x8]
1027fe418:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fe41c:     	add	x8, x8, #0xb90
1027fe420:     	str	x9, [sp, #0x20]
1027fe424:     	stp	x9, x24, [x8]
1027fe428:     	ldr	x8, [x20, #0x80]
1027fe42c:     	cmp	x8, #0x2
1027fe430:     	b.eq	0x1027fe68c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xbcc>
1027fe434:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fe438:     	add	x8, x8, #0x5e0
1027fe43c:     	add	x0, sp, #0x158
1027fe440:     	bl	0x102a30e24 <__RNvXsa_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1027fe444:     	mov	x27, x24
1027fe448:     	ldr	x8, [x28]
1027fe44c:     	ldr	x24, [x28, #0x10]
1027fe450:     	cmp	x8, x24
1027fe454:     	b.ls	0x1027fe660 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xba0>
1027fe458:     	ldr	x19, [x28, #0x8]
1027fe45c:     	add	x8, x8, x8, lsl #1
1027fe460:     	lsl	x25, x8, #5
1027fe464:     	cbz	x24, 0x1027fecd4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1214>
1027fe468:     	add	x8, x24, x24, lsl #1
1027fe46c:     	lsl	x3, x8, #5
1027fe470:     	mov	x0, x19
1027fe474:     	mov	x1, x25
1027fe478:     	mov	w2, #0x8                ; =8
1027fe47c:     	str	x3, [sp, #0x10]
1027fe480:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
1027fe484:     	mov	x26, x0
1027fe488:     	cbnz	x0, 0x1027fe664 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xba4>
1027fe48c:     	mov	w0, #0x8                ; =8
1027fe490:     	ldr	x1, [sp, #0x10]
1027fe494:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027fe498:     	b	0x1027ffa40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f80>
1027fe49c:     	str	w12, [sp, #0x48]
1027fe4a0:     	mov	x26, x24
1027fe4a4:     	str	x24, [sp, #0xb8]
1027fe4a8:     	ldp	x27, x25, [sp, #0xc8]
1027fe4ac:     	ldr	x19, [sp, #0xd8]
1027fe4b0:     	sub	x8, x24, x24
1027fe4b4:     	cmp	x19, x8
1027fe4b8:     	b.ls	0x1027fe26c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x7ac>
1027fe4bc:     	add	x0, sp, #0x1a8
1027fe4c0:     	mov	x1, x26
1027fe4c4:     	mov	x2, x19
1027fe4c8:     	mov	w3, #0x4                ; =4
1027fe4cc:     	mov	w4, #0xc                ; =12
1027fe4d0:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027fe4d4:     	ldr	x26, [x20, #0x78]
1027fe4d8:     	b	0x1027fe270 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x7b0>
1027fe4dc:     	ldur	w9, [x28, #0x1]
1027fe4e0:     	ldr	x12, [sp, #0x40]
1027fe4e4:     	stur	w9, [x12, #0x9]
1027fe4e8:     	ldr	w9, [sp, #0x15e4]
1027fe4ec:     	str	w9, [x12, #0xc]
1027fe4f0:     	ldp	x9, x10, [x28, #0x8]
1027fe4f4:     	ldur	q0, [x28, #0x18]
1027fe4f8:     	str	q0, [x12, #0x20]
1027fe4fc:     	ldr	x11, [x28, #0x28]
1027fe500:     	str	x11, [x12, #0x30]
1027fe504:     	strb	w8, [x12, #0x8]
1027fe508:     	stp	x9, x10, [x12, #0x10]
1027fe50c:     	mov	w8, #0x2                ; =2
1027fe510:     	str	x8, [x12]
1027fe514:     	mov	w25, #0x0               ; =0
1027fe518:     	ldr	x8, [x20, #0x80]
1027fe51c:     	cmp	x8, #0x2
1027fe520:     	b.ne	0x1027ff5f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b34>
1027fe524:     	b	0x1027ff5fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b3c>
1027fe528:     	mov	w25, #0x0               ; =0
1027fe52c:     	ldp	q0, q1, [x10]
1027fe530:     	ldr	x9, [sp, #0x40]
1027fe534:     	stur	q0, [x9, #0x8]
1027fe538:     	stur	q1, [x9, #0x18]
1027fe53c:     	ldr	q0, [x10, #0x20]
1027fe540:     	stur	q0, [x9, #0x28]
1027fe544:     	mov	w8, #0x2                ; =2
1027fe548:     	str	x8, [x9]
1027fe54c:     	ldr	x8, [x20, #0x80]
1027fe550:     	cmp	x8, #0x2
1027fe554:     	b.ne	0x1027ff5f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b34>
1027fe558:     	b	0x1027ff5fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b3c>
1027fe55c:     	str	x11, [sp, #0x48]
1027fe560:     	str	xzr, [sp, #0x30]
1027fe564:     	mov	x11, #0x0               ; =0
1027fe568:     	b	0x1027fdbd8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x118>
1027fe56c:     	str	x11, [sp, #0x48]
1027fe570:     	ldr	x19, [x8, #0x358]
1027fe574:     	cbz	x20, 0x1027fecbc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x11fc>
1027fe578:     	mov	x28, x10
1027fe57c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027fe580:     	mov	w25, #0x4               ; =4
1027fe584:     	mov	x0, x20
1027fe588:     	mov	w1, #0x4                ; =4
1027fe58c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027fe590:     	cbz	x0, 0x1027fdbb4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xf4>
1027fe594:     	mov	x23, x0
1027fe598:     	mov	x10, x28
1027fe59c:     	str	x28, [sp, #0x30]
1027fe5a0:     	cbz	x28, 0x1027feccc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x120c>
1027fe5a4:     	mov	x0, x23
1027fe5a8:     	mov	x1, x19
1027fe5ac:     	mov	x19, x10
1027fe5b0:     	mov	x2, x20
1027fe5b4:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027fe5b8:     	mov	x11, x19
1027fe5bc:     	b	0x1027fdbdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x11c>
1027fe5c0:     	add	x28, sp, #0x5c0
1027fe5c4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fe5c8:     	add	x8, x8, #0x5e0
1027fe5cc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fe5d0:     	add	x0, x0, #0x1e0
1027fe5d4:     	add	x1, x8, #0x38
1027fe5d8:     	mov	w2, #0x3b0              ; =944
1027fe5dc:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027fe5e0:     	ldr	x26, [x20, #0x480]
1027fe5e4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fe5e8:     	add	x0, x0, #0x1e0
1027fe5ec:     	add	x1, x28, #0x38
1027fe5f0:     	mov	w2, #0x1d0              ; =464
1027fe5f4:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027fe5f8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027fe5fc:     	add	x8, x8, #0xb90
1027fe600:     	ldur	q0, [x8, #0x8]
1027fe604:     	ldur	q1, [x8, #0x18]
1027fe608:     	add	x28, sp, #0xdd0
1027fe60c:     	stp	q0, q1, [x28, #0x3e0]
1027fe610:     	ldur	q0, [x8, #0x28]
1027fe614:     	str	q0, [x28, #0x400]
1027fe618:     	add	x0, sp, #0xe00
1027fe61c:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
1027fe620:     	add	x1, x1, #0x1e0
1027fe624:     	mov	w2, #0x3b0              ; =944
1027fe628:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027fe62c:     	cmp	x26, #0x2
1027fe630:     	b.ne	0x1027fe9c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xf04>
1027fe634:     	ldp	q0, q1, [x28, #0x3e0]
1027fe638:     	stp	q0, q1, [x28]
1027fe63c:     	ldr	q2, [x28, #0x400]
1027fe640:     	str	q2, [x28, #0x20]
1027fe644:     	ldr	x9, [sp, #0x40]
1027fe648:     	stur	q0, [x9, #0x8]
1027fe64c:     	stur	q1, [x9, #0x18]
1027fe650:     	stur	q2, [x9, #0x28]
1027fe654:     	mov	w8, #0x2                ; =2
1027fe658:     	str	x8, [x9]
1027fe65c:     	b	0x1027ff5b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1af4>
1027fe660:     	ldr	x26, [x28, #0x8]
1027fe664:     	ldr	x8, [x20, #0x3c0]
1027fe668:     	cbz	x8, 0x1027fe680 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xbc0>
1027fe66c:     	ldr	x0, [x20, #0x3b8]
1027fe670:     	add	x8, x8, x8, lsl #1
1027fe674:     	lsl	x1, x8, #5
1027fe678:     	mov	w2, #0x8                ; =8
1027fe67c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fe680:     	str	x26, [x20, #0x3b8]
1027fe684:     	str	x24, [x20, #0x3c0]
1027fe688:     	mov	x24, x27
1027fe68c:     	ldp	x26, x19, [x20, #0x20]
1027fe690:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fe694:     	add	x0, x0, #0x5e0
1027fe698:     	mov	x1, x26
1027fe69c:     	mov	x2, x19
1027fe6a0:     	bl	0x1027ffe50 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn17turn_storage_peak>
1027fe6a4:     	ldrb	w8, [x28]
1027fe6a8:     	cmp	w8, #0x16
1027fe6ac:     	b.ne	0x1027fe750 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xc90>
1027fe6b0:     	ldr	x8, [x28, #0x8]
1027fe6b4:     	ldr	x9, [sp, #0x38]
1027fe6b8:     	cmp	x8, x9
1027fe6bc:     	csel	x27, x8, x9, hi
1027fe6c0:     	ldp	x8, x9, [x21, #0x108]
1027fe6c4:     	add	x9, x8, x9, lsl #5
1027fe6c8:     	str	x8, [x22, #0x3e8]
1027fe6cc:     	str	x9, [x22, #0x3f0]
1027fe6d0:     	add	x8, sp, #0xc4
1027fe6d4:     	str	x8, [x22, #0x3f8]
1027fe6d8:     	add	x8, sp, #0xe00
1027fe6dc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fe6e0:     	add	x0, x0, #0x5c8
1027fe6e4:     	bl	0x102a1643c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memoryse_0EEE9from_iterB4C_>
1027fe6e8:     	mov	x8, #0x0                ; =0
1027fe6ec:     	add	x9, x19, x19, lsl #1
1027fe6f0:     	lsl	x9, x9, #5
1027fe6f4:     	ldr	w14, [sp, #0x48]
1027fe6f8:     	str	x24, [sp, #0x18]
1027fe6fc:     	cmp	x9, x8
1027fe700:     	b.eq	0x1027fe7e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xd28>
1027fe704:     	add	x10, x26, x8
1027fe708:     	ldr	w10, [x10, #0x8]
1027fe70c:     	add	x8, x8, #0x60
1027fe710:     	cmp	w10, #0x2
1027fe714:     	b.ne	0x1027fe6fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xc3c>
1027fe718:     	add	x10, x26, x8
1027fe71c:     	ldur	x25, [x10, #-0x40]
1027fe720:     	subs	x9, x9, x8
1027fe724:     	b.eq	0x1027fe7ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xd2c>
1027fe728:     	mov	x11, #-0x5555555555555556 ; =-6148914691236517206
1027fe72c:     	movk	x11, #0xaaab
1027fe730:     	umulh	x12, x9, x11
1027fe734:     	lsr	x9, x12, #6
1027fe738:     	sub	x11, x9, #0x1
1027fe73c:     	ubfx	x9, x12, #6, #3
1027fe740:     	cmp	x11, #0x7
1027fe744:     	b.hs	0x1027fecf4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1234>
1027fe748:     	mov	x10, #0x0               ; =0
1027fe74c:     	b	0x1027fee38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1378>
1027fe750:     	ldur	w9, [x28, #0x1]
1027fe754:     	ldr	x10, [sp, #0x40]
1027fe758:     	stur	w9, [x10, #0x9]
1027fe75c:     	ldr	w9, [sp, #0x15e4]
1027fe760:     	str	w9, [x10, #0xc]
1027fe764:     	ldr	x9, [x28, #0x8]
1027fe768:     	ldp	q0, q1, [x28, #0x10]
1027fe76c:     	stur	q0, [x10, #0x18]
1027fe770:     	stur	q1, [x10, #0x28]
1027fe774:     	strb	w8, [x10, #0x8]
1027fe778:     	str	x9, [x10, #0x10]
1027fe77c:     	mov	w8, #0x2                ; =2
1027fe780:     	str	x8, [x10]
1027fe784:     	cbz	x24, 0x1027fe514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xa54>
1027fe788:     	ldr	x8, [sp, #0x20]
1027fe78c:     	add	x19, x8, #0x10
1027fe790:     	mov	x21, x24
1027fe794:     	b	0x1027fe7a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xce4>
1027fe798:     	add	x19, x19, #0x30
1027fe79c:     	subs	x21, x21, #0x1
1027fe7a0:     	b.eq	0x1027fe7c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xd00>
1027fe7a4:     	ldr	x8, [x19]
1027fe7a8:     	cbz	x8, 0x1027fe798 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xcd8>
1027fe7ac:     	ldur	x0, [x19, #-0x8]
1027fe7b0:     	lsl	x1, x8, #2
1027fe7b4:     	mov	w2, #0x4                ; =4
1027fe7b8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fe7bc:     	b	0x1027fe798 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xcd8>
1027fe7c0:     	add	x8, x24, x24, lsl #1
1027fe7c4:     	lsl	x1, x8, #4
1027fe7c8:     	ldr	x0, [sp, #0x20]
1027fe7cc:     	mov	w2, #0x8                ; =8
1027fe7d0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fe7d4:     	mov	w25, #0x0               ; =0
1027fe7d8:     	ldr	x8, [x20, #0x80]
1027fe7dc:     	cmp	x8, #0x2
1027fe7e0:     	b.ne	0x1027ff5f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b34>
1027fe7e4:     	b	0x1027ff5fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b3c>
1027fe7e8:     	mov	x25, #0x0               ; =0
1027fe7ec:     	ldr	w8, [sp, #0xc4]
1027fe7f0:     	add	x9, sp, #0xdd0
1027fe7f4:     	ldp	x10, x11, [sp, #0x60]
1027fe7f8:     	str	x11, [x9, #0x410]
1027fe7fc:     	str	x10, [x9, #0x418]
1027fe800:     	ldp	x10, x11, [sp, #0x50]
1027fe804:     	str	x11, [x9, #0x420]
1027fe808:     	str	x10, [x9, #0x428]
1027fe80c:     	ldp	x10, x11, [sp, #0xa0]
1027fe810:     	str	x11, [x9, #0x430]
1027fe814:     	str	x10, [x9, #0x438]
1027fe818:     	str	x27, [sp, #0x38]
1027fe81c:     	str	x27, [x9, #0x440]
1027fe820:     	ldp	x10, x11, [sp, #0x90]
1027fe824:     	str	x11, [x9, #0x448]
1027fe828:     	str	x10, [x9, #0x450]
1027fe82c:     	ldp	x10, x11, [sp, #0x80]
1027fe830:     	str	x11, [x9, #0x458]
1027fe834:     	str	x10, [x9, #0x460]
1027fe838:     	ldr	x10, [sp, #0x78]
1027fe83c:     	str	x10, [x9, #0x468]
1027fe840:     	ldr	w9, [sp, #0x74]
1027fe844:     	str	w9, [sp, #0x1240]
1027fe848:     	str	w14, [sp, #0x1244]
1027fe84c:     	mov	w9, #0x3                ; =3
1027fe850:     	orr	x0, x9, x8, lsl #32
1027fe854:     	ldp	q0, q1, [x21, #0x80]
1027fe858:     	stp	q0, q1, [x28, #0x80]
1027fe85c:     	ldr	x8, [x21, #0xa0]
1027fe860:     	str	x8, [x28, #0xa0]
1027fe864:     	ldp	q0, q1, [x21, #0x40]
1027fe868:     	stp	q0, q1, [x28, #0x40]
1027fe86c:     	ldp	q1, q0, [x21, #0x60]
1027fe870:     	stp	q1, q0, [x28, #0x60]
1027fe874:     	ldp	q0, q1, [x21]
1027fe878:     	stp	q0, q1, [x28]
1027fe87c:     	ldp	q1, q0, [x21, #0x20]
1027fe880:     	stp	q1, q0, [x28, #0x20]
1027fe884:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
1027fe888:     	add	x1, x1, #0x1e0
1027fe88c:     	add	x4, sp, #0x1, lsl #12   ; =0x1000
1027fe890:     	add	x4, x4, #0x5e0
1027fe894:     	ldr	x2, [sp, #0xb8]
1027fe898:     	mov	x3, x25
1027fe89c:     	bl	0x102d197a0 <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget27evaluate_call_memory_budget>
1027fe8a0:     	mov	x27, x0
1027fe8a4:     	mov	x19, x1
1027fe8a8:     	lsl	x28, x1, #5
1027fe8ac:     	add	x8, sp, #0xdd0
1027fe8b0:     	ldr	x26, [x8, #0x40]
1027fe8b4:     	add	x24, sp, #0xdd0
1027fe8b8:     	ldr	x8, [x8, #0x30]
1027fe8bc:     	sub	x8, x8, x26
1027fe8c0:     	cmp	x1, x8
1027fe8c4:     	b.hi	0x1027ff85c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d9c>
1027fe8c8:     	cbz	x19, 0x1027fe974 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xeb4>
1027fe8cc:     	add	x24, sp, #0xdd0
1027fe8d0:     	ldr	x8, [x24, #0x38]
1027fe8d4:     	add	x0, x8, x26, lsl #5
1027fe8d8:     	mov	x1, x27
1027fe8dc:     	mov	x2, x28
1027fe8e0:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027fe8e4:     	add	x26, x26, x19
1027fe8e8:     	str	x26, [x24, #0x40]
1027fe8ec:     	mov	x0, x27
1027fe8f0:     	mov	x1, x28
1027fe8f4:     	mov	w2, #0x8                ; =8
1027fe8f8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fe8fc:     	ldr	x28, [x24, #0x38]
1027fe900:     	cmp	x26, #0x2
1027fe904:     	ldr	x19, [sp, #0xb0]
1027fe908:     	add	x24, sp, #0x1, lsl #12  ; =0x1000
1027fe90c:     	add	x24, x24, #0x5e0
1027fe910:     	b.hs	0x1027fe994 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xed4>
1027fe914:     	ldr	x8, [x19, #0x80]
1027fe918:     	cbz	x8, 0x1027ff1e4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1724>
1027fe91c:     	ldr	x1, [x19, #0x70]
1027fe920:     	cbz	x1, 0x1027ff87c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1dbc>
1027fe924:     	ldr	x2, [x19, #0x78]
1027fe928:     	add	x0, sp, #0x5c0
1027fe92c:     	bl	0x1025476bc <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model16RegionAccessPlanNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027fe930:     	ldr	x8, [x19, #0x98]
1027fe934:     	cbz	x8, 0x1027ff1f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1734>
1027fe938:     	ldr	x1, [x19, #0x88]
1027fe93c:     	add	x27, sp, #0x9e8
1027fe940:     	cbz	x1, 0x1027ff88c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1dcc>
1027fe944:     	ldr	x2, [x19, #0x90]
1027fe948:     	add	x0, sp, #0x9e8
1027fe94c:     	bl	0x102547354 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB2d_18operation_contract10validation13PortDirectiontENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027fe950:     	ldr	x8, [x19, #0xb0]
1027fe954:     	cbz	x8, 0x1027ff208 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1748>
1027fe958:     	ldr	x1, [x19, #0xa0]
1027fe95c:     	cbz	x1, 0x1027ff89c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ddc>
1027fe960:     	ldr	x2, [x19, #0xa8]
1027fe964:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fe968:     	add	x0, x0, #0x5e0
1027fe96c:     	bl	0x102547a00 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027fe970:     	b	0x1027ff210 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1750>
1027fe974:     	add	x24, sp, #0xdd0
1027fe978:     	str	x26, [x24, #0x40]
1027fe97c:     	ldr	x28, [x24, #0x38]
1027fe980:     	cmp	x26, #0x2
1027fe984:     	ldr	x19, [sp, #0xb0]
1027fe988:     	add	x24, sp, #0x1, lsl #12  ; =0x1000
1027fe98c:     	add	x24, x24, #0x5e0
1027fe990:     	b.lo	0x1027fe914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xe54>
1027fe994:     	cmp	x26, #0x15
1027fe998:     	b.hs	0x1027ffa44 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f84>
1027fe99c:     	sub	x3, x29, #0x61
1027fe9a0:     	mov	x0, x28
1027fe9a4:     	mov	x1, x26
1027fe9a8:     	mov	w2, #0x1                ; =1
1027fe9ac:     	bl	0x1028edcb0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYB1m_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
1027fe9b0:     	mov	x24, #0x0               ; =0
1027fe9b4:     	mov	x27, x28
1027fe9b8:     	add	x28, x28, #0x40
1027fe9bc:     	sub	x19, x26, #0x1
1027fe9c0:     	b	0x1027ff10c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x164c>
1027fe9c4:     	str	x24, [sp, #0x48]
1027fe9c8:     	ldp	q0, q1, [x28, #0x3e0]
1027fe9cc:     	stp	q0, q1, [x28]
1027fe9d0:     	ldr	q0, [x28, #0x400]
1027fe9d4:     	str	q0, [x28, #0x20]
1027fe9d8:     	add	x8, sp, #0x9e8
1027fe9dc:     	add	x0, x8, #0x38
1027fe9e0:     	add	x1, sp, #0xe00
1027fe9e4:     	mov	w2, #0x3b0              ; =944
1027fe9e8:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027fe9ec:     	ldp	q0, q1, [x28]
1027fe9f0:     	add	x24, sp, #0x9e8
1027fe9f4:     	stur	q0, [x24, #0x8]
1027fe9f8:     	stur	q1, [x24, #0x18]
1027fe9fc:     	ldr	q0, [x28, #0x20]
1027fea00:     	stur	q0, [x24, #0x28]
1027fea04:     	str	x26, [x24]
1027fea08:     	ldp	x1, x2, [x20, #0x20]
1027fea0c:     	ldr	w5, [sp, #0xc4]
1027fea10:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027fea14:     	add	x0, x0, #0x5e0
1027fea18:     	add	x4, sp, #0x9e8
1027fea1c:     	mov	x3, x25
1027fea20:     	ldr	x28, [sp, #0xb0]
1027fea24:     	mov	x6, x28
1027fea28:     	bl	0x102800110 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn24refresh_turn_allocations>
1027fea2c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1027fea30:     	add	x9, x9, #0x5e0
1027fea34:     	ldrb	w8, [x9]
1027fea38:     	cmp	w8, #0x16
1027fea3c:     	b.ne	0x1027fee7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x13bc>
1027fea40:     	ldr	x8, [x24, #0x398]
1027fea44:     	ldr	x9, [sp, #0xa8]
1027fea48:     	adds	x9, x8, x9
1027fea4c:     	str	x9, [sp, #0xa8]
1027fea50:     	b.hs	0x1027ff8ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1dec>
1027fea54:     	ldr	x8, [x24, #0x3a0]
1027fea58:     	ldr	x9, [sp, #0xa0]
1027fea5c:     	adds	x9, x8, x9
1027fea60:     	str	x9, [sp, #0xa0]
1027fea64:     	ldr	x2, [sp, #0x20]
1027fea68:     	b.hs	0x1027ff8b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1df8>
1027fea6c:     	ldr	x8, [x24, #0x3a8]
1027fea70:     	ldr	x9, [sp, #0x38]
1027fea74:     	adds	x9, x8, x9
1027fea78:     	str	x9, [sp, #0x38]
1027fea7c:     	b.hs	0x1027ff8cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e0c>
1027fea80:     	ldr	x8, [x24, #0x3b0]
1027fea84:     	ldr	x9, [sp, #0x98]
1027fea88:     	adds	x9, x8, x9
1027fea8c:     	str	x9, [sp, #0x98]
1027fea90:     	b.hs	0x1027ff8d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e18>
1027fea94:     	ldr	x8, [x24, #0x3b8]
1027fea98:     	ldr	x9, [sp, #0x90]
1027fea9c:     	adds	x9, x8, x9
1027feaa0:     	str	x9, [sp, #0x90]
1027feaa4:     	b.hs	0x1027ff8ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e2c>
1027feaa8:     	ldr	x8, [x24, #0x3c0]
1027feaac:     	ldr	x9, [sp, #0x88]
1027feab0:     	adds	x9, x8, x9
1027feab4:     	str	x9, [sp, #0x88]
1027feab8:     	b.hs	0x1027ff900 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e40>
1027feabc:     	ldr	x8, [x24, #0x3c8]
1027feac0:     	ldr	x9, [sp, #0x80]
1027feac4:     	adds	x9, x8, x9
1027feac8:     	str	x9, [sp, #0x80]
1027feacc:     	b.hs	0x1027ff90c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e4c>
1027fead0:     	ldr	x8, [x24, #0x3d0]
1027fead4:     	ldr	x9, [sp, #0x78]
1027fead8:     	adds	x9, x8, x9
1027feadc:     	str	x9, [sp, #0x78]
1027feae0:     	b.hs	0x1027ff920 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e60>
1027feae4:     	ldr	w8, [sp, #0xdc0]
1027feae8:     	ldr	w9, [sp, #0x74]
1027feaec:     	adds	w9, w8, w9
1027feaf0:     	str	w9, [sp, #0x74]
1027feaf4:     	ldr	x24, [sp, #0x48]
1027feaf8:     	b.hs	0x1027ff934 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e74>
1027feafc:     	add	x10, sp, #0x9e8
1027feb00:     	ldr	x8, [x10, #0x378]
1027feb04:     	ldr	x9, [sp, #0x68]
1027feb08:     	adds	x9, x8, x9
1027feb0c:     	str	x9, [sp, #0x68]
1027feb10:     	b.hs	0x1027ff944 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e84>
1027feb14:     	ldr	x8, [x10, #0x380]
1027feb18:     	ldr	x9, [sp, #0x60]
1027feb1c:     	adds	x9, x8, x9
1027feb20:     	str	x9, [sp, #0x60]
1027feb24:     	b.hs	0x1027ff954 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e94>
1027feb28:     	ldr	x8, [x10, #0x388]
1027feb2c:     	ldr	x9, [sp, #0x58]
1027feb30:     	adds	x9, x8, x9
1027feb34:     	str	x9, [sp, #0x58]
1027feb38:     	b.hs	0x1027ff964 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ea4>
1027feb3c:     	ldr	x8, [x10, #0x390]
1027feb40:     	ldr	x9, [sp, #0x50]
1027feb44:     	adds	x9, x8, x9
1027feb48:     	str	x9, [sp, #0x50]
1027feb4c:     	b.hs	0x1027ff974 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1eb4>
1027feb50:     	ldr	x1, [x20, #0x78]
1027feb54:     	ldr	x8, [x20, #0x68]
1027feb58:     	sub	x8, x8, x1
1027feb5c:     	cmp	x2, x8
1027feb60:     	b.hi	0x1027ff990 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ed0>
1027feb64:     	cbz	x2, 0x1027feb98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x10d8>
1027feb68:     	ldr	x8, [x20, #0x70]
1027feb6c:     	mov	w9, #0xc                ; =12
1027feb70:     	madd	x8, x1, x9, x8
1027feb74:     	add	x1, x2, x1
1027feb78:     	ldr	x9, [sp, #0x28]
1027feb7c:     	ldr	x10, [x9]
1027feb80:     	ldr	w11, [x9, #0x8]
1027feb84:     	str	w11, [x8, #0x8]
1027feb88:     	str	x10, [x8], #0xc
1027feb8c:     	add	x9, x9, #0xc
1027feb90:     	subs	x2, x2, #0x1
1027feb94:     	b.ne	0x1027feb7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x10bc>
1027feb98:     	str	x1, [x20, #0x78]
1027feb9c:     	ldr	x9, [x25, #0x370]
1027feba0:     	cbz	x9, 0x1027fee98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x13d8>
1027feba4:     	ldr	x8, [x25, #0x368]
1027feba8:     	add	x9, x8, x9, lsl #2
1027febac:     	ldr	w10, [sp, #0xc4]
1027febb0:     	mov	w11, #0x1b0             ; =432
1027febb4:     	b	0x1027febc8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1108>
1027febb8:     	cbz	w13, 0x1027fec78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x11b8>
1027febbc:     	add	x8, x8, #0x4
1027febc0:     	cmp	x8, x9
1027febc4:     	b.eq	0x1027fee98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x13d8>
1027febc8:     	ldrb	w12, [x8, #0x2]
1027febcc:     	cmp	w12, #0x1
1027febd0:     	b.ne	0x1027febbc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x10fc>
1027febd4:     	cbz	x19, 0x1027ff054 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1594>
1027febd8:     	ldrb	w13, [x8, #0x3]
1027febdc:     	ldrh	w12, [x8]
1027febe0:     	mov	x14, x27
1027febe4:     	mov	x15, x19
1027febe8:     	ldrh	w0, [x15, #0x2ca]
1027febec:     	add	x16, x15, #0x28
1027febf0:     	add	x1, x15, #0xe
1027febf4:     	lsl	x2, x0, #3
1027febf8:     	mov	x17, #-0x1              ; =-1
1027febfc:     	b	0x1027fec1c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x115c>
1027fec00:     	add	x1, x1, #0x8
1027fec04:     	add	x16, x16, #0x38
1027fec08:     	add	x17, x17, #0x1
1027fec0c:     	sub	x2, x2, #0x8
1027fec10:     	and	w3, w3, #0xff
1027fec14:     	cmp	w3, #0x1
1027fec18:     	b.ne	0x1027fec58 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1198>
1027fec1c:     	cbz	x2, 0x1027fec60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x11a0>
1027fec20:     	ldur	w3, [x1, #-0x6]
1027fec24:     	cmp	w10, w3
1027fec28:     	cset	w3, hi
1027fec2c:     	csinv	w3, w3, wzr, hs
1027fec30:     	b.ne	0x1027fec00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1140>
1027fec34:     	ldurb	w3, [x1, #-0x2]
1027fec38:     	sub	w3, w13, w3
1027fec3c:     	tst	w3, #0xff
1027fec40:     	b.ne	0x1027fec00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1140>
1027fec44:     	ldrh	w3, [x1]
1027fec48:     	cmp	w12, w3
1027fec4c:     	cset	w3, hi
1027fec50:     	csinv	w3, w3, wzr, hs
1027fec54:     	b	0x1027fec00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1140>
1027fec58:     	cbnz	w3, 0x1027fec64 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x11a4>
1027fec5c:     	b	0x1027febb8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x10f8>
1027fec60:     	mov	x17, x0
1027fec64:     	cbz	x14, 0x1027ff054 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1594>
1027fec68:     	add	x15, x15, x17, lsl #3
1027fec6c:     	ldr	x15, [x15, #0x2d0]
1027fec70:     	sub	x14, x14, #0x1
1027fec74:     	b	0x1027febe8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1128>
1027fec78:     	ldr	x13, [x25, #0x2b0]
1027fec7c:     	cmp	x13, x12
1027fec80:     	b.ls	0x1027ff560 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1aa0>
1027fec84:     	ldr	x13, [x25, #0x2a8]
1027fec88:     	umaddl	x12, w12, w11, x13
1027fec8c:     	ldr	x13, [x12, #0xe0]
1027fec90:     	cmp	x13, #0x1
1027fec94:     	b.ne	0x1027febbc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x10fc>
1027fec98:     	ldr	x12, [x12, #0xe8]
1027fec9c:     	ldr	x13, [x16]
1027feca0:     	cmp	x13, x12
1027feca4:     	b.ls	0x1027febbc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x10fc>
1027feca8:     	mov	w8, #0xa                ; =10
1027fecac:     	ldr	x11, [sp, #0x40]
1027fecb0:     	strb	w8, [x11, #0x8]
1027fecb4:     	stp	x13, x12, [x11, #0x10]
1027fecb8:     	b	0x1027ff5a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ae4>
1027fecbc:     	mov	x8, #0x0                ; =0
1027fecc0:     	mov	w23, #0x4               ; =4
1027fecc4:     	str	x8, [sp, #0x30]
1027fecc8:     	cbnz	x10, 0x1027fe5a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xae4>
1027feccc:     	mov	x11, #0x0               ; =0
1027fecd0:     	b	0x1027fdbdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x11c>
1027fecd4:     	mov	w26, #0x8               ; =8
1027fecd8:     	mov	x0, x19
1027fecdc:     	mov	x1, x25
1027fece0:     	mov	w2, #0x8                ; =8
1027fece4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027fece8:     	ldr	x8, [x20, #0x3c0]
1027fecec:     	cbnz	x8, 0x1027fe66c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xbac>
1027fecf0:     	b	0x1027fe680 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xbc0>
1027fecf4:     	mov	x11, #0x0               ; =0
1027fecf8:     	lsr	x12, x12, #9
1027fecfc:     	neg	x12, x12, lsl #3
1027fed00:     	b	0x1027fed14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1254>
1027fed04:     	add	x10, x10, #0x300
1027fed08:     	sub	x11, x11, #0x8
1027fed0c:     	cmp	x12, x11
1027fed10:     	b.eq	0x1027fee30 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1370>
1027fed14:     	ldr	w13, [x10, #0x8]
1027fed18:     	cmp	w13, #0x2
1027fed1c:     	b.ne	0x1027feda8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x12e8>
1027fed20:     	ldr	x13, [x10, #0x20]
1027fed24:     	cmp	x25, x13
1027fed28:     	csel	x25, x25, x13, hi
1027fed2c:     	ldr	w13, [x10, #0x68]
1027fed30:     	cmp	w13, #0x2
1027fed34:     	b.eq	0x1027fedb4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x12f4>
1027fed38:     	ldr	w13, [x10, #0xc8]
1027fed3c:     	cmp	w13, #0x2
1027fed40:     	b.ne	0x1027fedcc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x130c>
1027fed44:     	ldr	x13, [x10, #0xe0]
1027fed48:     	cmp	x25, x13
1027fed4c:     	csel	x25, x25, x13, hi
1027fed50:     	ldr	w13, [x10, #0x128]
1027fed54:     	cmp	w13, #0x2
1027fed58:     	b.eq	0x1027fedd8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1318>
1027fed5c:     	ldr	w13, [x10, #0x188]
1027fed60:     	cmp	w13, #0x2
1027fed64:     	b.ne	0x1027fedf0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1330>
1027fed68:     	ldr	x13, [x10, #0x1a0]
1027fed6c:     	cmp	x25, x13
1027fed70:     	csel	x25, x25, x13, hi
1027fed74:     	ldr	w13, [x10, #0x1e8]
1027fed78:     	cmp	w13, #0x2
1027fed7c:     	b.eq	0x1027fedfc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x133c>
1027fed80:     	ldr	w13, [x10, #0x248]
1027fed84:     	cmp	w13, #0x2
1027fed88:     	b.ne	0x1027fee14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1354>
1027fed8c:     	ldr	x13, [x10, #0x260]
1027fed90:     	cmp	x25, x13
1027fed94:     	csel	x25, x25, x13, hi
1027fed98:     	ldr	w13, [x10, #0x2a8]
1027fed9c:     	cmp	w13, #0x2
1027feda0:     	b.ne	0x1027fed04 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1244>
1027feda4:     	b	0x1027fee20 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1360>
1027feda8:     	ldr	w13, [x10, #0x68]
1027fedac:     	cmp	w13, #0x2
1027fedb0:     	b.ne	0x1027fed38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1278>
1027fedb4:     	ldr	x13, [x10, #0x80]
1027fedb8:     	cmp	x25, x13
1027fedbc:     	csel	x25, x25, x13, hi
1027fedc0:     	ldr	w13, [x10, #0xc8]
1027fedc4:     	cmp	w13, #0x2
1027fedc8:     	b.eq	0x1027fed44 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1284>
1027fedcc:     	ldr	w13, [x10, #0x128]
1027fedd0:     	cmp	w13, #0x2
1027fedd4:     	b.ne	0x1027fed5c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x129c>
1027fedd8:     	ldr	x13, [x10, #0x140]
1027feddc:     	cmp	x25, x13
1027fede0:     	csel	x25, x25, x13, hi
1027fede4:     	ldr	w13, [x10, #0x188]
1027fede8:     	cmp	w13, #0x2
1027fedec:     	b.eq	0x1027fed68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x12a8>
1027fedf0:     	ldr	w13, [x10, #0x1e8]
1027fedf4:     	cmp	w13, #0x2
1027fedf8:     	b.ne	0x1027fed80 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x12c0>
1027fedfc:     	ldr	x13, [x10, #0x200]
1027fee00:     	cmp	x25, x13
1027fee04:     	csel	x25, x25, x13, hi
1027fee08:     	ldr	w13, [x10, #0x248]
1027fee0c:     	cmp	w13, #0x2
1027fee10:     	b.eq	0x1027fed8c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x12cc>
1027fee14:     	ldr	w13, [x10, #0x2a8]
1027fee18:     	cmp	w13, #0x2
1027fee1c:     	b.ne	0x1027fed04 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1244>
1027fee20:     	ldr	x13, [x10, #0x2c0]
1027fee24:     	cmp	x25, x13
1027fee28:     	csel	x25, x25, x13, hi
1027fee2c:     	b	0x1027fed04 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1244>
1027fee30:     	cbz	x9, 0x1027fe7ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xd2c>
1027fee34:     	neg	x10, x11
1027fee38:     	add	x10, x10, x10, lsl #1
1027fee3c:     	lsl	x10, x10, #5
1027fee40:     	add	x9, x9, x9, lsl #1
1027fee44:     	lsl	x9, x9, #5
1027fee48:     	b	0x1027fee58 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1398>
1027fee4c:     	add	x10, x10, #0x60
1027fee50:     	subs	x9, x9, #0x60
1027fee54:     	b.eq	0x1027fe7ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xd2c>
1027fee58:     	add	x11, x26, x10
1027fee5c:     	add	x11, x11, x8
1027fee60:     	ldr	w12, [x11, #0x8]
1027fee64:     	cmp	w12, #0x2
1027fee68:     	b.ne	0x1027fee4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x138c>
1027fee6c:     	ldr	x11, [x11, #0x20]
1027fee70:     	cmp	x25, x11
1027fee74:     	csel	x25, x25, x11, hi
1027fee78:     	b	0x1027fee4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x138c>
1027fee7c:     	ldp	q0, q1, [x9]
1027fee80:     	ldp	x11, x24, [sp, #0x40]
1027fee84:     	stur	q0, [x11, #0x8]
1027fee88:     	stur	q1, [x11, #0x18]
1027fee8c:     	ldr	q0, [x9, #0x20]
1027fee90:     	stur	q0, [x11, #0x28]
1027fee94:     	b	0x1027ff5a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ae4>
1027fee98:     	ldr	x10, [x25, #0x2c0]
1027fee9c:     	cbz	x10, 0x1027ff064 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x15a4>
1027feea0:     	str	xzr, [sp, #0xb8]
1027feea4:     	mov	x8, #0x0                ; =0
1027feea8:     	ldr	x9, [x25, #0x2b8]
1027feeac:     	mov	w11, #0x1b0             ; =432
1027feeb0:     	madd	x10, x10, x11, x9
1027feeb4:     	ldr	w11, [sp, #0xc4]
1027feeb8:     	ldp	x12, x13, [x28, #0x70]
1027feebc:     	add	x15, sp, #0x9e8
1027feec0:     	ldr	x14, [x15, #0x2c0]
1027feec4:     	ldr	x15, [x15, #0x2b8]
1027feec8:     	mov	w16, #0x1b0             ; =432
1027feecc:     	cmp	x8, #0x10, lsl #12      ; =0x10000
1027feed0:     	b.eq	0x1027ff56c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1aac>
1027feed4:     	ldrh	w17, [x9]
1027feed8:     	cmp	w17, #0x6
1027feedc:     	b.ne	0x1027fef60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x14a0>
1027feee0:     	cbz	x12, 0x1027ff054 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1594>
1027feee4:     	mov	x17, x13
1027feee8:     	mov	x0, x12
1027feeec:     	add	x4, x0, #0x218
1027feef0:     	ldrh	w2, [x0, #0x272]
1027feef4:     	lsl	x3, x2, #3
1027feef8:     	mov	x1, #-0x1               ; =-1
1027feefc:     	cbz	x3, 0x1027fef48 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1488>
1027fef00:     	ldr	w5, [x4]
1027fef04:     	ldrh	w6, [x4, #0x4]
1027fef08:     	add	x4, x4, #0x8
1027fef0c:     	and	w7, w8, #0xffff
1027fef10:     	cmp	w7, w6
1027fef14:     	cset	w6, hi
1027fef18:     	csinv	w6, w6, wzr, hs
1027fef1c:     	cmp	w11, w5
1027fef20:     	cset	w5, hi
1027fef24:     	csinv	w5, w5, wzr, hs
1027fef28:     	csel	w5, w6, w5, eq
1027fef2c:     	add	x1, x1, #0x1
1027fef30:     	sub	x3, x3, #0x8
1027fef34:     	and	w5, w5, #0xff
1027fef38:     	cmp	w5, #0x1
1027fef3c:     	b.eq	0x1027feefc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x143c>
1027fef40:     	cbnz	w5, 0x1027fef4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x148c>
1027fef44:     	b	0x1027fef60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x14a0>
1027fef48:     	mov	x1, x2
1027fef4c:     	cbz	x17, 0x1027ff054 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1594>
1027fef50:     	add	x0, x0, x1, lsl #3
1027fef54:     	ldr	x0, [x0, #0x278]
1027fef58:     	sub	x17, x17, #0x1
1027fef5c:     	b	0x1027feeec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x142c>
1027fef60:     	cbz	x19, 0x1027ff014 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1554>
1027fef64:     	mov	x17, x27
1027fef68:     	mov	x0, x19
1027fef6c:     	ldrh	w3, [x0, #0x2ca]
1027fef70:     	add	x1, x0, #0x28
1027fef74:     	add	x4, x0, #0xe
1027fef78:     	lsl	x5, x3, #3
1027fef7c:     	mov	x2, #-0x1               ; =-1
1027fef80:     	b	0x1027fefb4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x14f4>
1027fef84:     	ldrh	w6, [x4]
1027fef88:     	and	w7, w8, #0xffff
1027fef8c:     	cmp	w7, w6
1027fef90:     	cset	w6, hi
1027fef94:     	csinv	w6, w6, wzr, hs
1027fef98:     	add	x4, x4, #0x8
1027fef9c:     	add	x1, x1, #0x38
1027fefa0:     	add	x2, x2, #0x1
1027fefa4:     	sub	x5, x5, #0x8
1027fefa8:     	and	w6, w6, #0xff
1027fefac:     	cmp	w6, #0x1
1027fefb0:     	b.ne	0x1027fefdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x151c>
1027fefb4:     	cbz	x5, 0x1027fefe4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1524>
1027fefb8:     	ldur	w6, [x4, #-0x6]
1027fefbc:     	cmp	w11, w6
1027fefc0:     	cset	w6, hi
1027fefc4:     	csinv	w6, w6, wzr, hs
1027fefc8:     	b.ne	0x1027fef98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x14d8>
1027fefcc:     	ldurb	w6, [x4, #-0x2]
1027fefd0:     	cbnz	w6, 0x1027fef84 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x14c4>
1027fefd4:     	mov	w6, #0x1                ; =1
1027fefd8:     	b	0x1027fef98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x14d8>
1027fefdc:     	cbnz	w6, 0x1027fefe8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1528>
1027fefe0:     	b	0x1027feffc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x153c>
1027fefe4:     	mov	x2, x3
1027fefe8:     	cbz	x17, 0x1027ff014 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1554>
1027fefec:     	add	x0, x0, x2, lsl #3
1027feff0:     	ldr	x0, [x0, #0x2d0]
1027feff4:     	sub	x17, x17, #0x1
1027feff8:     	b	0x1027fef6c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x14ac>
1027feffc:     	ldr	w17, [x9, #0xe0]
1027ff000:     	tbz	w17, #0x0, 0x1027ff014 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1554>
1027ff004:     	ldr	x17, [x9, #0xe8]
1027ff008:     	ldr	x0, [x1]
1027ff00c:     	cmp	x0, x17
1027ff010:     	b.hi	0x1027ff6e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c28>
1027ff014:     	cmp	x8, x14
1027ff018:     	b.eq	0x1027ff560 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1aa0>
1027ff01c:     	madd	x17, x8, x16, x15
1027ff020:     	ldr	x0, [x17, #0x1a0]
1027ff024:     	ldr	x1, [sp, #0xb8]
1027ff028:     	adds	x0, x0, x1
1027ff02c:     	b.hs	0x1027ff588 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ac8>
1027ff030:     	ldr	x17, [x17, #0x130]
1027ff034:     	adds	x17, x17, x0
1027ff038:     	str	x17, [sp, #0xb8]
1027ff03c:     	b.hs	0x1027ff588 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ac8>
1027ff040:     	add	x9, x9, #0x1b0
1027ff044:     	add	x8, x8, #0x1
1027ff048:     	cmp	x9, x10
1027ff04c:     	b.ne	0x1027feecc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x140c>
1027ff050:     	b	0x1027ff068 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x15a8>
1027ff054:     	mov	w8, #0x102              ; =258
1027ff058:     	ldr	x11, [sp, #0x40]
1027ff05c:     	strh	w8, [x11, #0x8]
1027ff060:     	b	0x1027ff5a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ae4>
1027ff064:     	str	xzr, [sp, #0xb8]
1027ff068:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027ff06c:     	add	x0, x0, #0x5e0
1027ff070:     	add	x1, sp, #0x9e8
1027ff074:     	mov	w2, #0x3e8              ; =1000
1027ff078:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027ff07c:     	ldp	x3, x4, [x20, #0x20]
1027ff080:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027ff084:     	add	x0, x0, #0x1e0
1027ff088:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
1027ff08c:     	add	x1, x1, #0x5e0
1027ff090:     	mov	x2, x25
1027ff094:     	bl	0x1027fd80c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15scope_turn_call>
1027ff098:     	add	x0, sp, #0x1c0
1027ff09c:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
1027ff0a0:     	add	x1, x1, #0x1e0
1027ff0a4:     	mov	w2, #0x3e8              ; =1000
1027ff0a8:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027ff0ac:     	ldr	x8, [x20, #0x868]
1027ff0b0:     	cbz	x8, 0x1027ff0c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1608>
1027ff0b4:     	lsl	x9, x8, #6
1027ff0b8:     	sub	x1, x9, x8, lsl #3
1027ff0bc:     	mov	x0, x24
1027ff0c0:     	mov	w2, #0x8                ; =8
1027ff0c4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff0c8:     	add	x0, sp, #0x5c0
1027ff0cc:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ff0d0:     	mov	w25, #0x1               ; =1
1027ff0d4:     	add	x0, sp, #0x5a8
1027ff0d8:     	bl	0x10257427c <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff0dc:     	ldr	x26, [x20, #0x78]
1027ff0e0:     	ldr	x24, [x20, #0x68]
1027ff0e4:     	ldp	x27, x25, [sp, #0xc8]
1027ff0e8:     	ldr	x19, [sp, #0xd8]
1027ff0ec:     	sub	x8, x24, x26
1027ff0f0:     	cmp	x19, x8
1027ff0f4:     	b.ls	0x1027fe26c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x7ac>
1027ff0f8:     	b	0x1027fe4bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x9fc>
1027ff0fc:     	add	x28, x28, #0x20
1027ff100:     	add	x24, x24, #0x1
1027ff104:     	cmp	x19, x24
1027ff108:     	b.eq	0x1027ff1cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x170c>
1027ff10c:     	ldur	x8, [x28, #-0x18]
1027ff110:     	ldur	x9, [x28, #-0x38]
1027ff114:     	cmp	x8, x9
1027ff118:     	b.ne	0x1027ff0fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x163c>
1027ff11c:     	ldur	x8, [x28, #-0x10]
1027ff120:     	ldur	x9, [x28, #-0x30]
1027ff124:     	cmp	x8, x9
1027ff128:     	b.ne	0x1027ff0fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x163c>
1027ff12c:     	sub	x0, x28, #0x20
1027ff130:     	sub	x1, x28, #0x40
1027ff134:     	bl	0x102a22fb4 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
1027ff138:     	cbz	w0, 0x1027ff0fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x163c>
1027ff13c:     	ldurb	w8, [x28, #-0x8]
1027ff140:     	ldurb	w9, [x28, #-0x28]
1027ff144:     	cmp	w8, w9
1027ff148:     	b.ne	0x1027ff0fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x163c>
1027ff14c:     	add	x8, x24, #0x2
1027ff150:     	add	x19, x24, #0x1
1027ff154:     	cmp	x8, x26
1027ff158:     	b.hs	0x1027ff1c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1700>
1027ff15c:     	sub	x8, x26, x24
1027ff160:     	sub	x24, x8, #0x2
1027ff164:     	add	x26, x27, x19, lsl #5
1027ff168:     	ldr	x8, [x28, #0x8]
1027ff16c:     	ldur	x9, [x26, #-0x18]
1027ff170:     	cmp	x8, x9
1027ff174:     	b.ne	0x1027ff1a8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x16e8>
1027ff178:     	ldr	x8, [x28, #0x10]
1027ff17c:     	ldur	x9, [x26, #-0x10]
1027ff180:     	cmp	x8, x9
1027ff184:     	b.ne	0x1027ff1a8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x16e8>
1027ff188:     	sub	x1, x26, #0x20
1027ff18c:     	mov	x0, x28
1027ff190:     	bl	0x102a22fb4 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
1027ff194:     	cbz	w0, 0x1027ff1a8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x16e8>
1027ff198:     	ldrb	w8, [x28, #0x18]
1027ff19c:     	ldurb	w9, [x26, #-0x8]
1027ff1a0:     	cmp	w8, w9
1027ff1a4:     	b.eq	0x1027ff1b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x16f4>
1027ff1a8:     	ldp	q0, q1, [x28]
1027ff1ac:     	stp	q0, q1, [x26]
1027ff1b0:     	add	x19, x19, #0x1
1027ff1b4:     	add	x28, x28, #0x20
1027ff1b8:     	subs	x24, x24, #0x1
1027ff1bc:     	b.ne	0x1027ff164 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x16a4>
1027ff1c0:     	add	x8, sp, #0xdd0
1027ff1c4:     	str	x19, [x8, #0x40]
1027ff1c8:     	mov	x26, x19
1027ff1cc:     	ldr	x19, [sp, #0xb0]
1027ff1d0:     	add	x24, sp, #0x1, lsl #12  ; =0x1000
1027ff1d4:     	add	x24, x24, #0x5e0
1027ff1d8:     	mov	x28, x27
1027ff1dc:     	ldr	x8, [x19, #0x80]
1027ff1e0:     	cbnz	x8, 0x1027fe91c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xe5c>
1027ff1e4:     	str	xzr, [x20, #0x480]
1027ff1e8:     	str	xzr, [x20, #0x490]
1027ff1ec:     	ldr	x8, [x19, #0x98]
1027ff1f0:     	cbnz	x8, 0x1027fe938 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xe78>
1027ff1f4:     	add	x27, sp, #0x9e8
1027ff1f8:     	str	xzr, [x27]
1027ff1fc:     	str	xzr, [x27, #0x10]
1027ff200:     	ldr	x8, [x19, #0xb0]
1027ff204:     	cbnz	x8, 0x1027fe958 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xe98>
1027ff208:     	str	xzr, [x24]
1027ff20c:     	str	xzr, [x24, #0x10]
1027ff210:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1027ff214:     	add	x8, x8, #0x1e0
1027ff218:     	add	x8, x8, #0xb8
1027ff21c:     	ldp	q1, q0, [x23, #0x40]
1027ff220:     	str	q0, [x8, #0x50]
1027ff224:     	ldp	q2, q0, [x23, #0x20]
1027ff228:     	stur	q0, [x22, #0xe8]
1027ff22c:     	stur	q1, [x22, #0xf8]
1027ff230:     	ldr	x8, [x23, #0x60]
1027ff234:     	str	x8, [x22, #0x118]
1027ff238:     	ldp	q0, q1, [x23]
1027ff23c:     	stur	q0, [x22, #0xb8]
1027ff240:     	stur	q1, [x22, #0xc8]
1027ff244:     	stur	q2, [x22, #0xd8]
1027ff248:     	ldr	q0, [x20, #0x480]
1027ff24c:     	ldr	x8, [x20, #0x490]
1027ff250:     	str	x8, [x22, #0x80]
1027ff254:     	ldr	x8, [x27, #0x10]
1027ff258:     	str	x8, [x22, #0x98]
1027ff25c:     	ldr	q1, [x27]
1027ff260:     	stur	q1, [x22, #0x88]
1027ff264:     	ldr	x8, [x24, #0x10]
1027ff268:     	str	x8, [x22, #0xb0]
1027ff26c:     	ldr	q1, [x24]
1027ff270:     	str	q1, [x22, #0xa0]
1027ff274:     	ldp	q2, q1, [x19]
1027ff278:     	stp	q2, q1, [x22]
1027ff27c:     	ldr	q1, [x19, #0x60]
1027ff280:     	stp	q1, q0, [x22, #0x60]
1027ff284:     	ldp	q1, q0, [x19, #0x40]
1027ff288:     	stp	q1, q0, [x22, #0x40]
1027ff28c:     	ldp	q0, q1, [x19, #0x20]
1027ff290:     	stp	q0, q1, [x22, #0x20]
1027ff294:     	ldr	x8, [x20, #0x80]
1027ff298:     	str	x8, [sp, #0x8]
1027ff29c:     	ldp	x8, x27, [x20, #0x18]
1027ff2a0:     	ldr	x23, [x20, #0x28]
1027ff2a4:     	cmp	x8, x23
1027ff2a8:     	b.ls	0x1027ff2ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x182c>
1027ff2ac:     	add	x8, x8, x8, lsl #1
1027ff2b0:     	lsl	x19, x8, #5
1027ff2b4:     	cbz	x23, 0x1027ff2f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1834>
1027ff2b8:     	add	x8, x23, x23, lsl #1
1027ff2bc:     	lsl	x22, x8, #5
1027ff2c0:     	mov	x0, x27
1027ff2c4:     	mov	x1, x19
1027ff2c8:     	mov	w2, #0x8                ; =8
1027ff2cc:     	mov	x3, x22
1027ff2d0:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
1027ff2d4:     	str	x0, [sp, #0x10]
1027ff2d8:     	cbnz	x0, 0x1027ff30c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x184c>
1027ff2dc:     	mov	w0, #0x8                ; =8
1027ff2e0:     	mov	x1, x22
1027ff2e4:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027ff2e8:     	b	0x1027ffa40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f80>
1027ff2ec:     	str	x27, [sp, #0x10]
1027ff2f0:     	b	0x1027ff30c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x184c>
1027ff2f4:     	mov	w8, #0x8                ; =8
1027ff2f8:     	str	x8, [sp, #0x10]
1027ff2fc:     	mov	x0, x27
1027ff300:     	mov	x1, x19
1027ff304:     	mov	w2, #0x8                ; =8
1027ff308:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff30c:     	add	x8, sp, #0x9e8
1027ff310:     	ldp	x9, x10, [sp, #0x18]
1027ff314:     	stp	x10, x9, [x8]
1027ff318:     	ldp	x8, x27, [x20, #0x68]
1027ff31c:     	ldr	x22, [x20, #0x78]
1027ff320:     	cmp	x8, x22
1027ff324:     	str	x23, [sp, #0xb0]
1027ff328:     	b.ls	0x1027ff3a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x18e4>
1027ff32c:     	add	x8, x8, x8, lsl #1
1027ff330:     	lsl	x19, x8, #2
1027ff334:     	cbz	x22, 0x1027ff3c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1900>
1027ff338:     	add	x8, x22, x22, lsl #1
1027ff33c:     	lsl	x24, x8, #2
1027ff340:     	mov	x0, x27
1027ff344:     	mov	x1, x19
1027ff348:     	mov	w2, #0x4                ; =4
1027ff34c:     	mov	x3, x24
1027ff350:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
1027ff354:     	mov	x23, x0
1027ff358:     	cbz	x0, 0x1027ffa34 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f74>
1027ff35c:     	add	x8, sp, #0xdd0
1027ff360:     	ldr	x8, [x8, #0x30]
1027ff364:     	cmp	x8, x26
1027ff368:     	b.ls	0x1027ff3b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x18f8>
1027ff36c:     	lsl	x19, x8, #5
1027ff370:     	cbz	x26, 0x1027ff3e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1928>
1027ff374:     	lsl	x24, x26, #5
1027ff378:     	mov	x0, x28
1027ff37c:     	mov	x1, x19
1027ff380:     	mov	w2, #0x8                ; =8
1027ff384:     	mov	x3, x24
1027ff388:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
1027ff38c:     	mov	x27, x0
1027ff390:     	cbnz	x0, 0x1027ff3fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x193c>
1027ff394:     	mov	w0, #0x8                ; =8
1027ff398:     	mov	x1, x24
1027ff39c:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027ff3a0:     	b	0x1027ffa40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f80>
1027ff3a4:     	mov	x23, x27
1027ff3a8:     	add	x8, sp, #0xdd0
1027ff3ac:     	ldr	x8, [x8, #0x30]
1027ff3b0:     	cmp	x8, x26
1027ff3b4:     	b.hi	0x1027ff36c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x18ac>
1027ff3b8:     	mov	x27, x28
1027ff3bc:     	b	0x1027ff3fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x193c>
1027ff3c0:     	mov	w23, #0x4               ; =4
1027ff3c4:     	mov	x0, x27
1027ff3c8:     	mov	x1, x19
1027ff3cc:     	mov	w2, #0x4                ; =4
1027ff3d0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff3d4:     	add	x8, sp, #0xdd0
1027ff3d8:     	ldr	x8, [x8, #0x30]
1027ff3dc:     	cmp	x8, x26
1027ff3e0:     	b.hi	0x1027ff36c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x18ac>
1027ff3e4:     	b	0x1027ff3b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x18f8>
1027ff3e8:     	mov	w27, #0x8               ; =8
1027ff3ec:     	mov	x0, x28
1027ff3f0:     	mov	x1, x19
1027ff3f4:     	mov	w2, #0x8                ; =8
1027ff3f8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff3fc:     	ldr	w19, [sp, #0xc4]
1027ff400:     	add	x20, sp, #0x1, lsl #12  ; =0x1000
1027ff404:     	add	x20, x20, #0x5e0
1027ff408:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027ff40c:     	add	x0, x0, #0x5e0
1027ff410:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
1027ff414:     	add	x1, x1, #0x1e0
1027ff418:     	mov	w2, #0x120              ; =288
1027ff41c:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027ff420:     	add	x0, x20, #0x1c8
1027ff424:     	add	x1, sp, #0x1c0
1027ff428:     	mov	w2, #0x3e8              ; =1000
1027ff42c:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027ff430:     	ldp	q0, q1, [x21, #0x80]
1027ff434:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1027ff438:     	add	x9, x9, #0x5e0
1027ff43c:     	stp	q0, q1, [x9, #0x1a0]
1027ff440:     	ldr	x8, [x21, #0xa0]
1027ff444:     	str	x8, [x9, #0x1c0]
1027ff448:     	ldp	q0, q1, [x21, #0x40]
1027ff44c:     	stp	q0, q1, [x9, #0x160]
1027ff450:     	ldp	q1, q0, [x21, #0x60]
1027ff454:     	stp	q1, q0, [x9, #0x180]
1027ff458:     	ldp	q0, q1, [x21]
1027ff45c:     	stp	q0, q1, [x9, #0x120]
1027ff460:     	ldp	q1, q0, [x21, #0x20]
1027ff464:     	stp	q1, q0, [x9, #0x140]
1027ff468:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
1027ff46c:     	add	x1, x1, #0x5e0
1027ff470:     	ldr	x20, [sp, #0x40]
1027ff474:     	mov	x0, x20
1027ff478:     	mov	w2, #0x5b0              ; =1456
1027ff47c:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1027ff480:     	ldr	x8, [sp, #0x10]
1027ff484:     	str	x8, [x20, #0x5b0]
1027ff488:     	ldr	x8, [sp, #0xb0]
1027ff48c:     	str	x8, [x20, #0x5b8]
1027ff490:     	ldp	x8, x10, [sp, #0x18]
1027ff494:     	str	x10, [x20, #0x5c0]
1027ff498:     	str	x8, [x20, #0x5c8]
1027ff49c:     	str	x23, [x20, #0x5d0]
1027ff4a0:     	str	x22, [x20, #0x5d8]
1027ff4a4:     	str	x27, [x20, #0x5e0]
1027ff4a8:     	str	x26, [x20, #0x5e8]
1027ff4ac:     	ldp	x8, x10, [sp, #0x60]
1027ff4b0:     	str	x10, [x20, #0x5f0]
1027ff4b4:     	str	x8, [x20, #0x5f8]
1027ff4b8:     	ldp	x8, x10, [sp, #0x50]
1027ff4bc:     	str	x10, [x20, #0x600]
1027ff4c0:     	str	x8, [x20, #0x608]
1027ff4c4:     	ldp	x8, x10, [sp, #0xa0]
1027ff4c8:     	str	x10, [x20, #0x610]
1027ff4cc:     	str	x8, [x20, #0x618]
1027ff4d0:     	ldr	x8, [sp, #0x38]
1027ff4d4:     	str	x8, [x20, #0x620]
1027ff4d8:     	ldp	x8, x10, [sp, #0x90]
1027ff4dc:     	str	x10, [x20, #0x628]
1027ff4e0:     	str	x8, [x20, #0x630]
1027ff4e4:     	ldp	x8, x10, [sp, #0x80]
1027ff4e8:     	str	x10, [x20, #0x638]
1027ff4ec:     	str	x8, [x20, #0x640]
1027ff4f0:     	ldr	x8, [sp, #0x78]
1027ff4f4:     	str	x8, [x20, #0x648]
1027ff4f8:     	ldr	w8, [sp, #0x74]
1027ff4fc:     	str	w8, [x20, #0x650]
1027ff500:     	ldr	w8, [sp, #0x48]
1027ff504:     	str	w8, [x20, #0x654]
1027ff508:     	ldr	x8, [sp, #0xb8]
1027ff50c:     	str	x8, [x20, #0x658]
1027ff510:     	str	x25, [x20, #0x660]
1027ff514:     	add	x8, x20, #0x668
1027ff518:     	movi.2d	v0, #0000000000000000
1027ff51c:     	str	q0, [x8]
1027ff520:     	str	w19, [x20, #0x678]
1027ff524:     	mov	w25, #0x0               ; =0
1027ff528:     	add	x0, sp, #0x140
1027ff52c:     	bl	0x102572594 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff530:     	mov	w25, #0x0               ; =0
1027ff534:     	add	x0, sp, #0x128
1027ff538:     	bl	0x102572c84 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff53c:     	mov	w25, #0x0               ; =0
1027ff540:     	add	x0, sp, #0x110
1027ff544:     	bl	0x102572594 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff548:     	mov	w25, #0x0               ; =0
1027ff54c:     	add	x0, sp, #0xf8
1027ff550:     	bl	0x102572c84 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff554:     	ldp	x0, x8, [sp, #0x28]
1027ff558:     	cbnz	x8, 0x1027ff680 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1bc0>
1027ff55c:     	b	0x1027ff690 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1bd0>
1027ff560:     	ldr	x11, [sp, #0x40]
1027ff564:     	strb	wzr, [x11, #0x8]
1027ff568:     	b	0x1027ff5a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ae4>
1027ff56c:     	mov	w8, #0x6                ; =6
1027ff570:     	ldr	x11, [sp, #0x40]
1027ff574:     	strb	w8, [x11, #0x8]
1027ff578:     	adrp	x8, 0x1076ce000 <_anon.b6ff028db8dfb0025970258f65cf5a23.70+0x5>
1027ff57c:     	add	x8, x8, #0x96e
1027ff580:     	mov	w9, #0x13               ; =19
1027ff584:     	b	0x1027ff5a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ae0>
1027ff588:     	mov	w8, #0x6                ; =6
1027ff58c:     	ldr	x11, [sp, #0x40]
1027ff590:     	strb	w8, [x11, #0x8]
1027ff594:     	adrp	x8, 0x1076d1000 <_anon.b6ff028db8dfb0025970258f65cf5a23.804+0x18b>
1027ff598:     	add	x8, x8, #0xfb2
1027ff59c:     	mov	w9, #0x1a               ; =26
1027ff5a0:     	stp	x8, x9, [x11, #0x10]
1027ff5a4:     	mov	w8, #0x2                ; =2
1027ff5a8:     	str	x8, [x11]
1027ff5ac:     	add	x0, sp, #0x9e8
1027ff5b0:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ff5b4:     	ldr	x8, [x20, #0x868]
1027ff5b8:     	cbz	x8, 0x1027ff5d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b10>
1027ff5bc:     	lsl	x9, x8, #6
1027ff5c0:     	sub	x1, x9, x8, lsl #3
1027ff5c4:     	mov	x0, x24
1027ff5c8:     	mov	w2, #0x8                ; =8
1027ff5cc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff5d0:     	add	x0, sp, #0x5c0
1027ff5d4:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ff5d8:     	mov	w25, #0x1               ; =1
1027ff5dc:     	add	x0, sp, #0x5a8
1027ff5e0:     	bl	0x10257427c <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff5e4:     	mov	w25, #0x1               ; =1
1027ff5e8:     	ldr	x8, [x20, #0x80]
1027ff5ec:     	cmp	x8, #0x2
1027ff5f0:     	b.eq	0x1027ff5fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b3c>
1027ff5f4:     	add	x0, sp, #0x1c0
1027ff5f8:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ff5fc:     	ldr	x8, [x20, #0x68]
1027ff600:     	cbz	x8, 0x1027ff618 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b58>
1027ff604:     	ldr	x0, [x20, #0x70]
1027ff608:     	add	x8, x8, x8, lsl #1
1027ff60c:     	lsl	x1, x8, #2
1027ff610:     	mov	w2, #0x4                ; =4
1027ff614:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff618:     	ldr	x8, [x20, #0x18]
1027ff61c:     	cbz	x8, 0x1027ff634 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1b74>
1027ff620:     	ldr	x0, [x20, #0x20]
1027ff624:     	add	x8, x8, x8, lsl #1
1027ff628:     	lsl	x1, x8, #5
1027ff62c:     	mov	w2, #0x8                ; =8
1027ff630:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff634:     	add	x0, sp, #0x140
1027ff638:     	bl	0x102572594 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff63c:     	add	x0, sp, #0x128
1027ff640:     	bl	0x102572c84 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff644:     	add	x0, sp, #0x110
1027ff648:     	bl	0x102572594 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff64c:     	add	x0, sp, #0xf8
1027ff650:     	bl	0x102572c84 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ff654:     	ldr	x8, [sp, #0x30]
1027ff658:     	cbz	x8, 0x1027ff670 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1bb0>
1027ff65c:     	add	x8, x8, x8, lsl #1
1027ff660:     	lsl	x1, x8, #2
1027ff664:     	ldr	x0, [sp, #0x28]
1027ff668:     	mov	w2, #0x4                ; =4
1027ff66c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff670:     	tbz	w25, #0x0, 0x1027ff690 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1bd0>
1027ff674:     	ldr	x8, [sp, #0xc8]
1027ff678:     	cbz	x8, 0x1027ff690 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1bd0>
1027ff67c:     	ldr	x0, [sp, #0xd0]
1027ff680:     	add	x8, x8, x8, lsl #1
1027ff684:     	lsl	x1, x8, #2
1027ff688:     	mov	w2, #0x4                ; =4
1027ff68c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ff690:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
1027ff694:     	add	sp, sp, #0xc50
1027ff698:     	ldp	x29, x30, [sp, #0x50]
1027ff69c:     	ldp	x20, x19, [sp, #0x40]
1027ff6a0:     	ldp	x22, x21, [sp, #0x30]
1027ff6a4:     	ldp	x24, x23, [sp, #0x20]
1027ff6a8:     	ldp	x26, x25, [sp, #0x10]
1027ff6ac:     	ldp	x28, x27, [sp], #0x60
1027ff6b0:     	ret
1027ff6b4:     	cmp	x1, #0x15
1027ff6b8:     	b.hs	0x1027ff9b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ef4>
1027ff6bc:     	add	x24, x19, #0xc
1027ff6c0:     	mov	w8, #0xc                ; =12
1027ff6c4:     	mov	x9, #-0xc               ; =-12
1027ff6c8:     	madd	x25, x1, x8, x9
1027ff6cc:     	mov	x0, x19
1027ff6d0:     	mov	x1, x24
1027ff6d4:     	bl	0x1028e9ca4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort11insert_tailNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementNCINvMNtCsgKscDXrlV49_5alloc5sliceSB18_11sort_by_keyThmmENvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15transaction_keyE0EB3k_>
1027ff6d8:     	add	x24, x24, #0xc
1027ff6dc:     	subs	x25, x25, #0xc
1027ff6e0:     	b.ne	0x1027ff6cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c0c>
1027ff6e4:     	b	0x1027fe2cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x80c>
1027ff6e8:     	mov	w8, #0xa                ; =10
1027ff6ec:     	ldr	x11, [sp, #0x40]
1027ff6f0:     	strb	w8, [x11, #0x8]
1027ff6f4:     	stp	x0, x17, [x11, #0x10]
1027ff6f8:     	b	0x1027ff5a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ae4>
1027ff6fc:     	cmp	x19, #0x15
1027ff700:     	b.hs	0x1027ff9cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f0c>
1027ff704:     	mov	x8, #0x0                ; =0
1027ff708:     	add	x9, x20, x19, lsl #2
1027ff70c:     	add	x10, x20, #0x4
1027ff710:     	b	0x1027ff72c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c6c>
1027ff714:     	mov	x12, x20
1027ff718:     	str	w11, [x12]
1027ff71c:     	add	x10, x10, #0x4
1027ff720:     	add	x8, x8, #0x4
1027ff724:     	cmp	x10, x9
1027ff728:     	b.eq	0x1027ff844 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d84>
1027ff72c:     	ldp	w12, w11, [x10, #-0x4]
1027ff730:     	cmp	w11, w12
1027ff734:     	b.hs	0x1027ff71c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c5c>
1027ff738:     	mov	x13, x8
1027ff73c:     	add	x14, x20, x13
1027ff740:     	str	w12, [x14, #0x4]
1027ff744:     	cbz	x13, 0x1027ff714 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c54>
1027ff748:     	ldur	w12, [x14, #-0x4]
1027ff74c:     	sub	x13, x13, #0x4
1027ff750:     	cmp	w11, w12
1027ff754:     	b.lo	0x1027ff73c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c7c>
1027ff758:     	add	x12, x20, x13
1027ff75c:     	add	x12, x12, #0x4
1027ff760:     	b	0x1027ff718 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1c58>
1027ff764:     	cmp	x25, #0x15
1027ff768:     	b.hs	0x1027ff9e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f28>
1027ff76c:     	add	x19, x20, #0x8
1027ff770:     	lsl	x8, x25, #3
1027ff774:     	sub	x8, x8, #0x8
1027ff778:     	add	x23, sp, #0xdd0
1027ff77c:     	str	x8, [sp, #0xa8]
1027ff780:     	mov	x0, x20
1027ff784:     	mov	x1, x19
1027ff788:     	bl	0x1028e9b24 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort11insert_tailNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYB18_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
1027ff78c:     	ldr	x8, [sp, #0xa8]
1027ff790:     	add	x19, x19, #0x8
1027ff794:     	subs	x8, x8, #0x8
1027ff798:     	b.ne	0x1027ff77c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1cbc>
1027ff79c:     	b	0x1027fdcd8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x218>
1027ff7a0:     	cmp	x19, #0x15
1027ff7a4:     	b.hs	0x1027ffa00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f40>
1027ff7a8:     	mov	x8, #0x0                ; =0
1027ff7ac:     	add	x9, x20, x19, lsl #2
1027ff7b0:     	add	x10, x20, #0x4
1027ff7b4:     	b	0x1027ff7d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d10>
1027ff7b8:     	mov	x12, x20
1027ff7bc:     	str	w11, [x12]
1027ff7c0:     	add	x10, x10, #0x4
1027ff7c4:     	add	x8, x8, #0x4
1027ff7c8:     	cmp	x10, x9
1027ff7cc:     	b.eq	0x1027ff850 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d90>
1027ff7d0:     	ldp	w12, w11, [x10, #-0x4]
1027ff7d4:     	cmp	w11, w12
1027ff7d8:     	b.hs	0x1027ff7c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d00>
1027ff7dc:     	mov	x13, x8
1027ff7e0:     	add	x14, x20, x13
1027ff7e4:     	str	w12, [x14, #0x4]
1027ff7e8:     	cbz	x13, 0x1027ff7b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1cf8>
1027ff7ec:     	ldur	w12, [x14, #-0x4]
1027ff7f0:     	sub	x13, x13, #0x4
1027ff7f4:     	cmp	w11, w12
1027ff7f8:     	b.lo	0x1027ff7e0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d20>
1027ff7fc:     	add	x12, x20, x13
1027ff800:     	add	x12, x12, #0x4
1027ff804:     	b	0x1027ff7bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1cfc>
1027ff808:     	cmp	x25, #0x15
1027ff80c:     	b.hs	0x1027ffa1c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f5c>
1027ff810:     	add	x9, x23, #0x8
1027ff814:     	lsl	x8, x25, #3
1027ff818:     	sub	x8, x8, #0x8
1027ff81c:     	add	x19, sp, #0xdd0
1027ff820:     	stp	x8, x9, [sp, #0xa0]
1027ff824:     	mov	x0, x23
1027ff828:     	mov	x1, x9
1027ff82c:     	bl	0x1028e9b24 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort11insert_tailNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYB18_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
1027ff830:     	ldp	x8, x9, [sp, #0xa0]
1027ff834:     	add	x9, x9, #0x8
1027ff838:     	subs	x8, x8, #0x8
1027ff83c:     	b.ne	0x1027ff820 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1d60>
1027ff840:     	b	0x1027fde7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x3bc>
1027ff844:     	ldr	x20, [x23, #0x418]
1027ff848:     	ldr	x19, [x23, #0x420]
1027ff84c:     	b	0x1027fdc3c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x17c>
1027ff850:     	ldr	x20, [x23, #0x418]
1027ff854:     	ldr	x19, [x23, #0x420]
1027ff858:     	b	0x1027fdde8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x328>
1027ff85c:     	add	x0, sp, #0xe00
1027ff860:     	mov	x1, x26
1027ff864:     	mov	x2, x19
1027ff868:     	mov	w3, #0x8                ; =8
1027ff86c:     	mov	w4, #0x20               ; =32
1027ff870:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027ff874:     	ldr	x26, [x24, #0x40]
1027ff878:     	b	0x1027fe8cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xe0c>
1027ff87c:     	adrp	x0, 0x108035000 <_anon.2314c7dda7e7207dbb1e6612b9b2047f.264+0x340>
1027ff880:     	add	x0, x0, #0x100
1027ff884:     	bl	0x103a03c3c <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1027ff888:     	b	0x1027ffa40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f80>
1027ff88c:     	adrp	x0, 0x108035000 <_anon.2314c7dda7e7207dbb1e6612b9b2047f.264+0x340>
1027ff890:     	add	x0, x0, #0x100
1027ff894:     	bl	0x103a03c3c <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1027ff898:     	b	0x1027ffa40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f80>
1027ff89c:     	adrp	x0, 0x108035000 <_anon.2314c7dda7e7207dbb1e6612b9b2047f.264+0x340>
1027ff8a0:     	add	x0, x0, #0x100
1027ff8a4:     	bl	0x103a03c3c <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1027ff8a8:     	b	0x1027ffa40 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1f80>
1027ff8ac:     	adrp	x8, 0x1076cd000 <_anon.aa7e29194531b90d3b2f4777996458a6.5473+0x1ff>
1027ff8b0:     	add	x8, x8, #0x9d0
1027ff8b4:     	b	0x1027ff8c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e00>
1027ff8b8:     	adrp	x8, 0x1076cd000 <_anon.aa7e29194531b90d3b2f4777996458a6.5473+0x1ff>
1027ff8bc:     	add	x8, x8, #0x9e0
1027ff8c0:     	mov	w9, #0x10               ; =16
1027ff8c4:     	ldr	x24, [sp, #0x48]
1027ff8c8:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff8cc:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff8d0:     	add	x8, x8, #0x22
1027ff8d4:     	b	0x1027ff928 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e68>
1027ff8d8:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff8dc:     	add	x8, x8, #0x31
1027ff8e0:     	mov	w9, #0x16               ; =22
1027ff8e4:     	ldr	x24, [sp, #0x48]
1027ff8e8:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff8ec:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff8f0:     	add	x8, x8, #0x47
1027ff8f4:     	mov	w9, #0xc                ; =12
1027ff8f8:     	ldr	x24, [sp, #0x48]
1027ff8fc:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff900:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff904:     	add	x8, x8, #0x53
1027ff908:     	b	0x1027ff914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1e54>
1027ff90c:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff910:     	add	x8, x8, #0x61
1027ff914:     	mov	w9, #0xe                ; =14
1027ff918:     	ldr	x24, [sp, #0x48]
1027ff91c:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff920:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff924:     	add	x8, x8, #0x6f
1027ff928:     	mov	w9, #0xf                ; =15
1027ff92c:     	ldr	x24, [sp, #0x48]
1027ff930:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff934:     	adrp	x8, 0x1076cd000 <_anon.aa7e29194531b90d3b2f4777996458a6.5473+0x1ff>
1027ff938:     	add	x8, x8, #0x9f0
1027ff93c:     	mov	w9, #0x10               ; =16
1027ff940:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff944:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff948:     	add	x8, x8, #0x7e
1027ff94c:     	mov	w9, #0xf                ; =15
1027ff950:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff954:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff958:     	add	x8, x8, #0x8d
1027ff95c:     	mov	w9, #0xc                ; =12
1027ff960:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff964:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff968:     	add	x8, x8, #0x99
1027ff96c:     	mov	w9, #0x15               ; =21
1027ff970:     	b	0x1027ff980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ec0>
1027ff974:     	adrp	x8, 0x1076d2000 <_anon.b6ff028db8dfb0025970258f65cf5a23.846+0x900>
1027ff978:     	add	x8, x8, #0xae
1027ff97c:     	mov	w9, #0x13               ; =19
1027ff980:     	mov	w10, #0x6               ; =6
1027ff984:     	ldr	x11, [sp, #0x40]
1027ff988:     	str	x10, [x11, #0x8]
1027ff98c:     	b	0x1027ff5a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ae0>
1027ff990:     	add	x0, sp, #0x1a8
1027ff994:     	mov	w3, #0x4                ; =4
1027ff998:     	mov	w4, #0xc                ; =12
1027ff99c:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027ff9a0:     	ldp	x8, x1, [x20, #0x70]
1027ff9a4:     	ldr	x28, [sp, #0xb0]
1027ff9a8:     	ldr	x2, [sp, #0x20]
1027ff9ac:     	ldr	x24, [sp, #0x48]
1027ff9b0:     	b	0x1027feb6c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x10ac>
1027ff9b4:     	mov	w25, #0x0               ; =0
1027ff9b8:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
1027ff9bc:     	add	x2, x2, #0x5e0
1027ff9c0:     	mov	x0, x19
1027ff9c4:     	bl	0x1029df43c <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementNCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_11sort_by_keyThmmENvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15transaction_keyE0INtNtB2i_3vec3VecBZ_EEB3a_>
1027ff9c8:     	b	0x1027fe2cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x80c>
1027ff9cc:     	add	x23, sp, #0xdd0
1027ff9d0:     	sub	x2, x29, #0x61
1027ff9d4:     	mov	x0, x20
1027ff9d8:     	mov	x1, x19
1027ff9dc:     	bl	0x1029df1f4 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
1027ff9e0:     	add	x23, sp, #0xdd0
1027ff9e4:     	b	0x1027fdc3c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x17c>
1027ff9e8:     	sub	x2, x29, #0x61
1027ff9ec:     	mov	x0, x20
1027ff9f0:     	mov	x1, x25
1027ff9f4:     	add	x23, sp, #0xdd0
1027ff9f8:     	bl	0x1029df318 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
1027ff9fc:     	b	0x1027fdcd8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x218>
1027ffa00:     	add	x23, sp, #0xdd0
1027ffa04:     	sub	x2, x29, #0x61
1027ffa08:     	mov	x0, x20
1027ffa0c:     	mov	x1, x19
1027ffa10:     	bl	0x1029df1f4 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
1027ffa14:     	add	x23, sp, #0xdd0
1027ffa18:     	b	0x1027fdde8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x328>
1027ffa1c:     	sub	x2, x29, #0x61
1027ffa20:     	mov	x0, x23
1027ffa24:     	mov	x1, x25
1027ffa28:     	add	x19, sp, #0xdd0
1027ffa2c:     	bl	0x1029df318 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
1027ffa30:     	b	0x1027fde7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x3bc>
1027ffa34:     	mov	w0, #0x4                ; =4
1027ffa38:     	mov	x1, x24
1027ffa3c:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027ffa40:     	brk	#0x1
1027ffa44:     	sub	x2, x29, #0x61
1027ffa48:     	mov	x0, x28
1027ffa4c:     	mov	x1, x26
1027ffa50:     	bl	0x102dc71c8 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EEB15_>
1027ffa54:     	b	0x1027fe9b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0xef0>
1027ffa58:     	mov	x21, x0
1027ffa5c:     	ldr	x8, [x19, #0x410]
1027ffa60:     	cbz	x8, 0x1027ffa74 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1fb4>
1027ffa64:     	lsl	x1, x8, #3
1027ffa68:     	mov	x0, x23
1027ffa6c:     	mov	w2, #0x4                ; =4
1027ffa70:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffa74:     	mov	w25, #0x1               ; =1
1027ffa78:     	b	0x1027ffdcc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x230c>
1027ffa7c:     	mov	x21, x0
1027ffa80:     	ldr	x8, [x23, #0x410]
1027ffa84:     	cbz	x8, 0x1027ffa98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1fd8>
1027ffa88:     	lsl	x1, x8, #2
1027ffa8c:     	mov	x0, x20
1027ffa90:     	mov	w2, #0x4                ; =4
1027ffa94:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffa98:     	mov	w25, #0x1               ; =1
1027ffa9c:     	b	0x1027ffdd4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2314>
1027ffaa0:     	mov	x21, x0
1027ffaa4:     	ldr	x8, [x23, #0x410]
1027ffaa8:     	cbz	x8, 0x1027ffabc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x1ffc>
1027ffaac:     	lsl	x1, x8, #3
1027ffab0:     	mov	x0, x20
1027ffab4:     	mov	w2, #0x4                ; =4
1027ffab8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffabc:     	mov	w25, #0x1               ; =1
1027ffac0:     	b	0x1027ffddc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x231c>
1027ffac4:     	mov	x21, x0
1027ffac8:     	ldr	x8, [x23, #0x410]
1027ffacc:     	cbnz	x8, 0x1027ffad8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2018>
1027ffad0:     	mov	w25, #0x1               ; =1
1027ffad4:     	b	0x1027ffde4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2324>
1027ffad8:     	lsl	x1, x8, #2
1027ffadc:     	mov	x0, x20
1027ffae0:     	mov	w2, #0x4                ; =4
1027ffae4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffae8:     	mov	w25, #0x1               ; =1
1027ffaec:     	b	0x1027ffde4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2324>
1027ffaf0:     	mov	x21, x0
1027ffaf4:     	add	x0, sp, #0x9e8
1027ffaf8:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ffafc:     	b	0x1027ffc68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x21a8>
1027ffb00:     	mov	x21, x0
1027ffb04:     	mov	x0, x27
1027ffb08:     	mov	x1, x28
1027ffb0c:     	mov	w2, #0x8                ; =8
1027ffb10:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffb14:     	b	0x1027ffd24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2264>
1027ffb18:     	mov	x21, x0
1027ffb1c:     	cbnz	x27, 0x1027ffb28 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2068>
1027ffb20:     	mov	w25, #0x0               ; =0
1027ffb24:     	b	0x1027ffd60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22a0>
1027ffb28:     	add	x8, x27, x27, lsl #1
1027ffb2c:     	lsl	x1, x8, #2
1027ffb30:     	mov	x0, x25
1027ffb34:     	mov	w2, #0x4                ; =4
1027ffb38:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffb3c:     	mov	w25, #0x0               ; =0
1027ffb40:     	b	0x1027ffd60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22a0>
1027ffb44:     	b	0x1027ffc64 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x21a4>
1027ffb48:     	mov	x21, x0
1027ffb4c:     	mov	x0, x28
1027ffb50:     	mov	x1, x19
1027ffb54:     	mov	w2, #0x8                ; =8
1027ffb58:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffb5c:     	cbnz	x22, 0x1027ffb68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x20a8>
1027ffb60:     	mov	w19, #0x0               ; =0
1027ffb64:     	b	0x1027ffb9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x20dc>
1027ffb68:     	add	x8, x22, x22, lsl #1
1027ffb6c:     	lsl	x1, x8, #2
1027ffb70:     	mov	x0, x23
1027ffb74:     	mov	w2, #0x4                ; =4
1027ffb78:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffb7c:     	mov	w19, #0x0               ; =0
1027ffb80:     	b	0x1027ffb9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x20dc>
1027ffb84:     	mov	x21, x0
1027ffb88:     	mov	x0, x27
1027ffb8c:     	mov	x1, x19
1027ffb90:     	mov	w2, #0x4                ; =4
1027ffb94:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffb98:     	mov	w19, #0x1               ; =1
1027ffb9c:     	add	x0, sp, #0x9e8
1027ffba0:     	bl	0x1027bec1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
1027ffba4:     	ldr	x8, [sp, #0xb0]
1027ffba8:     	cbnz	x8, 0x1027ffbb4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x20f4>
1027ffbac:     	mov	w22, #0x0               ; =0
1027ffbb0:     	b	0x1027ffbf0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2130>
1027ffbb4:     	ldr	x8, [sp, #0xb0]
1027ffbb8:     	add	x8, x8, x8, lsl #1
1027ffbbc:     	lsl	x1, x8, #5
1027ffbc0:     	ldr	x0, [sp, #0x10]
1027ffbc4:     	mov	w2, #0x8                ; =8
1027ffbc8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffbcc:     	mov	w22, #0x0               ; =0
1027ffbd0:     	b	0x1027ffbf0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2130>
1027ffbd4:     	mov	x21, x0
1027ffbd8:     	mov	x0, x27
1027ffbdc:     	mov	x1, x19
1027ffbe0:     	mov	w2, #0x8                ; =8
1027ffbe4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffbe8:     	mov	w19, #0x1               ; =1
1027ffbec:     	mov	w22, #0x1               ; =1
1027ffbf0:     	ldr	x8, [sp, #0x8]
1027ffbf4:     	cmp	x8, #0x2
1027ffbf8:     	b.eq	0x1027ffc04 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2144>
1027ffbfc:     	add	x0, sp, #0x1c0
1027ffc00:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ffc04:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027ffc08:     	add	x0, x0, #0x1e0
1027ffc0c:     	bl	0x1027c1ac8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15TurnMemoryFactsEBM_>
1027ffc10:     	tbz	w19, #0x0, 0x1027ffc1c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x215c>
1027ffc14:     	mov	w19, #0x0               ; =0
1027ffc18:     	b	0x1027ffd2c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x226c>
1027ffc1c:     	cbz	w22, 0x1027ffc38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2178>
1027ffc20:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027ffc24:     	add	x0, x0, #0xb90
1027ffc28:     	bl	0x1027bec1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
1027ffc2c:     	mov	w19, #0x0               ; =0
1027ffc30:     	mov	w25, #0x0               ; =0
1027ffc34:     	b	0x1027ffd88 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22c8>
1027ffc38:     	mov	w25, #0x0               ; =0
1027ffc3c:     	b	0x1027ffdc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2304>
1027ffc40:     	mov	x21, x0
1027ffc44:     	mov	x0, x19
1027ffc48:     	mov	x1, x25
1027ffc4c:     	mov	w2, #0x8                ; =8
1027ffc50:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffc54:     	b	0x1027ffcb4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x21f4>
1027ffc58:     	mov	x21, x0
1027ffc5c:     	b	0x1027ffc84 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x21c4>
1027ffc60:     	str	x24, [sp, #0x48]
1027ffc64:     	mov	x21, x0
1027ffc68:     	ldr	x8, [x20, #0x868]
1027ffc6c:     	cbz	x8, 0x1027ffc84 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x21c4>
1027ffc70:     	lsl	x9, x8, #6
1027ffc74:     	sub	x1, x9, x8, lsl #3
1027ffc78:     	ldr	x0, [sp, #0x48]
1027ffc7c:     	mov	w2, #0x8                ; =8
1027ffc80:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffc84:     	add	x0, sp, #0x5c0
1027ffc88:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ffc8c:     	b	0x1027ffc94 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x21d4>
1027ffc90:     	mov	x21, x0
1027ffc94:     	add	x0, sp, #0x5a8
1027ffc98:     	bl	0x10257427c <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ffc9c:     	mov	w22, #0x1               ; =1
1027ffca0:     	mov	w25, #0x1               ; =1
1027ffca4:     	b	0x1027ffd64 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22a4>
1027ffca8:     	mov	x21, x0
1027ffcac:     	b	0x1027ffd7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22bc>
1027ffcb0:     	mov	x21, x0
1027ffcb4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027ffcb8:     	add	x0, x0, #0xb90
1027ffcbc:     	bl	0x1027bec1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
1027ffcc0:     	mov	w25, #0x0               ; =0
1027ffcc4:     	b	0x1027ffd60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22a0>
1027ffcc8:     	mov	x21, x0
1027ffccc:     	mov	w25, #0x1               ; =1
1027ffcd0:     	b	0x1027ffdc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2304>
1027ffcd4:     	mov	x21, x0
1027ffcd8:     	b	0x1027ffd60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22a0>
1027ffcdc:     	mov	x21, x0
1027ffce0:     	b	0x1027ffdcc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x230c>
1027ffce4:     	mov	x21, x0
1027ffce8:     	b	0x1027ffdd4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2314>
1027ffcec:     	mov	x21, x0
1027ffcf0:     	b	0x1027ffddc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x231c>
1027ffcf4:     	mov	x21, x0
1027ffcf8:     	b	0x1027ffde4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2324>
1027ffcfc:     	mov	x21, x0
1027ffd00:     	add	x0, sp, #0x9e8
1027ffd04:     	bl	0x1025737fc <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ffd08:     	b	0x1027ffd10 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2250>
1027ffd0c:     	mov	x21, x0
1027ffd10:     	add	x0, sp, #0x5c0
1027ffd14:     	bl	0x1025740cc <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model16RegionAccessPlanENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ffd18:     	b	0x1027ffd24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2264>
1027ffd1c:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1027ffd20:     	mov	x21, x0
1027ffd24:     	mov	w19, #0x1               ; =1
1027ffd28:     	mov	w22, #0x1               ; =1
1027ffd2c:     	add	x9, sp, #0xdd0
1027ffd30:     	ldr	x8, [x9, #0x30]
1027ffd34:     	cbz	x8, 0x1027ffd48 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2288>
1027ffd38:     	ldr	x0, [x9, #0x38]
1027ffd3c:     	lsl	x1, x8, #5
1027ffd40:     	mov	w2, #0x8                ; =8
1027ffd44:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffd48:     	tbz	w22, #0x0, 0x1027ffe0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x234c>
1027ffd4c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1027ffd50:     	add	x0, x0, #0xb90
1027ffd54:     	bl	0x1027bec1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
1027ffd58:     	mov	w25, #0x0               ; =0
1027ffd5c:     	tbz	w19, #0x0, 0x1027ffd84 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22c4>
1027ffd60:     	mov	w22, #0x1               ; =1
1027ffd64:     	ldr	x8, [x20, #0x80]
1027ffd68:     	cmp	x8, #0x2
1027ffd6c:     	b.eq	0x1027ffd78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22b8>
1027ffd70:     	add	x0, sp, #0x1c0
1027ffd74:     	bl	0x1027c4af4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
1027ffd78:     	cbz	w22, 0x1027ffda8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22e8>
1027ffd7c:     	mov	w19, #0x1               ; =1
1027ffd80:     	b	0x1027ffd88 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22c8>
1027ffd84:     	mov	x19, x25
1027ffd88:     	ldr	x8, [x20, #0x68]
1027ffd8c:     	cbz	x8, 0x1027ffda4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22e4>
1027ffd90:     	ldr	x0, [x20, #0x70]
1027ffd94:     	add	x8, x8, x8, lsl #1
1027ffd98:     	lsl	x1, x8, #2
1027ffd9c:     	mov	w2, #0x4                ; =4
1027ffda0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffda4:     	tbz	w19, #0x0, 0x1027ffdc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2304>
1027ffda8:     	ldr	x8, [x20, #0x18]
1027ffdac:     	cbz	x8, 0x1027ffdc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2304>
1027ffdb0:     	ldr	x0, [x20, #0x20]
1027ffdb4:     	add	x8, x8, x8, lsl #1
1027ffdb8:     	lsl	x1, x8, #5
1027ffdbc:     	mov	w2, #0x8                ; =8
1027ffdc0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffdc4:     	add	x0, sp, #0x140
1027ffdc8:     	bl	0x102572594 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ffdcc:     	add	x0, sp, #0x128
1027ffdd0:     	bl	0x102572c84 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ffdd4:     	add	x0, sp, #0x110
1027ffdd8:     	bl	0x102572594 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ffddc:     	add	x0, sp, #0xf8
1027ffde0:     	bl	0x102572c84 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
1027ffde4:     	ldr	x8, [sp, #0x30]
1027ffde8:     	cbz	x8, 0x1027ffe00 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2340>
1027ffdec:     	ldp	x0, x8, [sp, #0x28]
1027ffdf0:     	add	x8, x8, x8, lsl #1
1027ffdf4:     	lsl	x1, x8, #2
1027ffdf8:     	mov	w2, #0x4                ; =4
1027ffdfc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffe00:     	mov	x0, x21
1027ffe04:     	tbnz	w25, #0x0, 0x1027ffe20 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2360>
1027ffe08:     	b	0x1027ffe28 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2368>
1027ffe0c:     	mov	w25, #0x0               ; =0
1027ffe10:     	mov	w22, #0x0               ; =0
1027ffe14:     	tbnz	w19, #0x0, 0x1027ffd64 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x22a4>
1027ffe18:     	b	0x1027ffdc4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x2304>
1027ffe1c:     	bl	0x103a03cc0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1027ffe20:     	ldr	x9, [sp, #0xc8]
1027ffe24:     	cbnz	x9, 0x1027ffe2c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memory+0x236c>
1027ffe28:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
1027ffe2c:     	ldr	x8, [sp, #0xd0]
1027ffe30:     	add	x9, x9, x9, lsl #1
1027ffe34:     	lsl	x1, x9, #2
1027ffe38:     	mov	x19, x0
1027ffe3c:     	mov	x0, x8
1027ffe40:     	mov	w2, #0x4                ; =4
1027ffe44:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ffe48:     	mov	x0, x19
1027ffe4c:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
