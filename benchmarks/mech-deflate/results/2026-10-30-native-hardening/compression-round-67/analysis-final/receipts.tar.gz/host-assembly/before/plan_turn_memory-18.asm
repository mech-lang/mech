
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a5b7bc <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_>:
102a5b7bc:     	sub	sp, sp, #0x50
102a5b7c0:     	stp	x20, x19, [sp, #0x40]
102a5b7c4:     	ldp	x10, x11, [x0, #0x18]
102a5b7c8:     	ldp	x8, x9, [x1]
102a5b7cc:     	cmp	x10, x11
102a5b7d0:     	b.hs	0x102a5b964 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x1a8>
102a5b7d4:     	ldr	x12, [x1, #0x10]
102a5b7d8:     	ldp	x15, x13, [x0, #0x8]
102a5b7dc:     	movi.2d	v0, #0000000000000000
102a5b7e0:     	mov	w14, #0x38              ; =56
102a5b7e4:     	ldr	x16, [x0]
102a5b7e8:     	b	0x102a5b830 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x74>
102a5b7ec:     	ldp	q1, q2, [x3]
102a5b7f0:     	ldr	q3, [x3, #0x20]
102a5b7f4:     	ldr	x17, [x3, #0x30]
102a5b7f8:     	str	x17, [sp, #0x30]
102a5b7fc:     	stp	q2, q3, [sp, #0x10]
102a5b800:     	str	q1, [sp]
102a5b804:     	add	x10, x10, #0x1
102a5b808:     	madd	x17, x9, x14, x12
102a5b80c:     	ldp	q1, q2, [sp]
102a5b810:     	stp	q1, q2, [x17]
102a5b814:     	ldr	q1, [sp, #0x20]
102a5b818:     	str	q1, [x17, #0x20]
102a5b81c:     	ldr	x0, [sp, #0x30]
102a5b820:     	str	x0, [x17, #0x30]
102a5b824:     	add	x9, x9, #0x1
102a5b828:     	cmp	x10, x11
102a5b82c:     	b.eq	0x102a5b964 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x1a8>
102a5b830:     	ldr	x17, [x16, #0xa0]
102a5b834:     	cbz	x17, 0x102a5b8c0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x104>
102a5b838:     	ldr	w0, [x15]
102a5b83c:     	ldr	x1, [x16, #0xa8]
102a5b840:     	add	x6, x17, #0x8
102a5b844:     	ldrh	w4, [x17, #0x2ca]
102a5b848:     	add	x3, x17, #0x28
102a5b84c:     	lsl	x5, x4, #3
102a5b850:     	mov	x2, #-0x1               ; =-1
102a5b854:     	cbz	x5, 0x102a5b8a8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0xec>
102a5b858:     	ldr	w7, [x6]
102a5b85c:     	ldrh	w19, [x6, #0x4]
102a5b860:     	add	x6, x6, #0x8
102a5b864:     	and	w20, w10, #0xffff
102a5b868:     	cmp	w20, w19
102a5b86c:     	cset	w19, hi
102a5b870:     	csinv	w19, w19, wzr, hs
102a5b874:     	cmp	w0, w7
102a5b878:     	cset	w7, hi
102a5b87c:     	csinv	w7, w7, wzr, hs
102a5b880:     	csel	w7, w19, w7, eq
102a5b884:     	add	x3, x3, #0x38
102a5b888:     	add	x2, x2, #0x1
102a5b88c:     	sub	x5, x5, #0x8
102a5b890:     	and	w7, w7, #0xff
102a5b894:     	cmp	w7, #0x1
102a5b898:     	b.eq	0x102a5b854 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x98>
102a5b89c:     	cbz	w7, 0x102a5b7ec <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x30>
102a5b8a0:     	cbnz	x1, 0x102a5b8b0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0xf4>
102a5b8a4:     	b	0x102a5b8c0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x104>
102a5b8a8:     	mov	x2, x4
102a5b8ac:     	cbz	x1, 0x102a5b8c0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x104>
102a5b8b0:     	add	x17, x17, x2, lsl #3
102a5b8b4:     	ldr	x17, [x17, #0x2d0]
102a5b8b8:     	sub	x1, x1, #0x1
102a5b8bc:     	b	0x102a5b840 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x84>
102a5b8c0:     	ldr	x17, [x13]
102a5b8c4:     	cbz	x17, 0x102a5b954 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x198>
102a5b8c8:     	ldr	x0, [x13, #0x8]
102a5b8cc:     	add	x5, x17, #0x270
102a5b8d0:     	ldrh	w3, [x17, #0x29e]
102a5b8d4:     	sub	x2, x17, #0x30
102a5b8d8:     	lsl	x4, x3, #2
102a5b8dc:     	mov	x1, #-0x1               ; =-1
102a5b8e0:     	cbz	x4, 0x102a5b92c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x170>
102a5b8e4:     	ldrb	w6, [x5]
102a5b8e8:     	ldrh	w7, [x5, #0x2]
102a5b8ec:     	add	x5, x5, #0x4
102a5b8f0:     	and	w19, w10, #0xffff
102a5b8f4:     	cmp	w19, w7
102a5b8f8:     	cset	w7, hi
102a5b8fc:     	csinv	w7, w7, wzr, hs
102a5b900:     	cmp	w6, #0x0
102a5b904:     	csinc	w6, w7, wzr, ne
102a5b908:     	add	x2, x2, #0x38
102a5b90c:     	add	x1, x1, #0x1
102a5b910:     	sub	x4, x4, #0x4
102a5b914:     	and	w6, w6, #0xff
102a5b918:     	cmp	w6, #0x1
102a5b91c:     	b.eq	0x102a5b8e0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x124>
102a5b920:     	cbz	w6, 0x102a5b944 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x188>
102a5b924:     	cbnz	x0, 0x102a5b934 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x178>
102a5b928:     	b	0x102a5b954 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x198>
102a5b92c:     	mov	x1, x3
102a5b930:     	cbz	x0, 0x102a5b954 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x198>
102a5b934:     	add	x17, x17, x1, lsl #3
102a5b938:     	ldr	x17, [x17, #0x2a0]
102a5b93c:     	sub	x0, x0, #0x1
102a5b940:     	b	0x102a5b8cc <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x110>
102a5b944:     	ldp	q1, q2, [x2]
102a5b948:     	ldr	q3, [x2, #0x20]
102a5b94c:     	ldr	x17, [x2, #0x30]
102a5b950:     	b	0x102a5b7f8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x3c>
102a5b954:     	str	xzr, [sp, #0x30]
102a5b958:     	stp	q0, q0, [sp, #0x10]
102a5b95c:     	str	q0, [sp]
102a5b960:     	b	0x102a5b804 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_+0x48>
102a5b964:     	str	x9, [x8]
102a5b968:     	ldp	x20, x19, [sp, #0x40]
102a5b96c:     	add	sp, sp, #0x50
102a5b970:     	ret
