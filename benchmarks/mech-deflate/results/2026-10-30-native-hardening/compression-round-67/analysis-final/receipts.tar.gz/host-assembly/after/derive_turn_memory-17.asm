
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a047c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory>:
102a047c4:     	stp	x28, x27, [sp, #-0x60]!
102a047c8:     	stp	x26, x25, [sp, #0x10]
102a047cc:     	stp	x24, x23, [sp, #0x20]
102a047d0:     	stp	x22, x21, [sp, #0x30]
102a047d4:     	stp	x20, x19, [sp, #0x40]
102a047d8:     	stp	x29, x30, [sp, #0x50]
102a047dc:     	add	x29, sp, #0x50
102a047e0:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
102a047e4:     	str	xzr, [sp]
102a047e8:     	sub	sp, sp, #0xc70
102a047ec:     	str	xzr, [sp]
102a047f0:     	str	x3, [sp, #0xc8]
102a047f4:     	mov	x21, x1
102a047f8:     	mov	x19, x0
102a047fc:     	str	w2, [sp, #0xd4]
102a04800:     	ldp	x8, x9, [x1, #0xb0]
102a04804:     	mov	w10, #0x1c0             ; =448
102a04808:     	madd	x9, x9, x10, x8
102a0480c:     	stp	x8, x9, [sp, #0xf0]
102a04810:     	add	x8, sp, #0xd4
102a04814:     	str	x8, [sp, #0x100]
102a04818:     	add	x8, sp, #0xd8
102a0481c:     	add	x0, sp, #0xf0
102a04820:     	bl	0x1027bdb1c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn18derive_turn_memory0ENCB5y_s_0EE9from_iterB4p_>
102a04824:     	ldr	x24, [x21, #0xe0]
102a04828:     	cbz	x24, 0x102a04864 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xa0>
102a0482c:     	ldr	x23, [x24, #0x360]
102a04830:     	add	x8, x23, x23, lsl #1
102a04834:     	lsl	x25, x8, #2
102a04838:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
102a0483c:     	movk	x8, #0xaaab
102a04840:     	movk	x8, #0xaaa, lsl #48
102a04844:     	sub	x8, x8, #0x1
102a04848:     	cmp	x23, x8
102a0484c:     	b.ls	0x102a04874 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb0>
102a04850:     	mov	x27, #0x0               ; =0
102a04854:     	mov	x0, x27
102a04858:     	mov	x1, x25
102a0485c:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a04860:     	b	0x102a06514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d50>
102a04864:     	str	xzr, [sp, #0xb8]
102a04868:     	mov	x23, #0x0               ; =0
102a0486c:     	mov	w20, #0x4               ; =4
102a04870:     	b	0x102a048b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xec>
102a04874:     	ldr	x26, [x24, #0x358]
102a04878:     	cbz	x25, 0x102a05138 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x974>
102a0487c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a04880:     	mov	w27, #0x4               ; =4
102a04884:     	mov	x0, x25
102a04888:     	mov	w1, #0x4                ; =4
102a0488c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a04890:     	cbz	x0, 0x102a04854 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x90>
102a04894:     	mov	x20, x0
102a04898:     	str	x23, [sp, #0xb8]
102a0489c:     	cbz	x23, 0x102a048b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xec>
102a048a0:     	mov	x0, x20
102a048a4:     	mov	x1, x26
102a048a8:     	mov	x2, x25
102a048ac:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a048b0:     	add	x28, sp, #0x1, lsl #12  ; =0x1000
102a048b4:     	add	x28, x28, #0x200
102a048b8:     	ldp	x8, x9, [sp, #0xe0]
102a048bc:     	mov	w10, #0xc               ; =12
102a048c0:     	madd	x9, x9, x10, x8
102a048c4:     	str	x8, [x28, #0x400]
102a048c8:     	str	x9, [x28, #0x408]
102a048cc:     	madd	x8, x23, x10, x20
102a048d0:     	str	x20, [x28, #0x410]
102a048d4:     	str	x8, [x28, #0x418]
102a048d8:     	mov	w25, #0x1               ; =1
102a048dc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a048e0:     	add	x8, x8, #0x200
102a048e4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a048e8:     	add	x0, x0, #0x600
102a048ec:     	str	x20, [sp, #0xc0]
102a048f0:     	bl	0x1027abb1c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_>
102a048f4:     	add	x8, sp, #0xdf0
102a048f8:     	ldr	x26, [x8, #0x420]
102a048fc:     	str	x19, [sp, #0xb0]
102a04900:     	cbz	x26, 0x102a04948 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x184>
102a04904:     	add	x22, sp, #0xdf0
102a04908:     	ldr	x25, [x8, #0x418]
102a0490c:     	cmp	x26, #0x1
102a04910:     	b.ne	0x102a06108 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1944>
102a04914:     	ldr	x8, [x22, #0x410]
102a04918:     	str	x25, [x28, #0x400]
102a0491c:     	add	x9, x25, x26, lsl #2
102a04920:     	str	x25, [x28, #0x408]
102a04924:     	str	x8, [x28, #0x410]
102a04928:     	str	x9, [x28, #0x418]
102a0492c:     	mov	w25, #0x1               ; =1
102a04930:     	add	x8, sp, #0x108
102a04934:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04938:     	add	x0, x0, #0x600
102a0493c:     	bl	0x102554524 <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4D_8BTreeSetB18_E16from_sorted_iterB3S_E0EECs1qJAwyMG1lC_11mech_engine>
102a04940:     	add	x19, sp, #0xdf0
102a04944:     	b	0x102a0496c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a8>
102a04948:     	str	xzr, [sp, #0x108]
102a0494c:     	str	xzr, [sp, #0x118]
102a04950:     	ldr	x8, [x8, #0x410]
102a04954:     	add	x19, sp, #0xdf0
102a04958:     	cbz	x8, 0x102a0496c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a8>
102a0495c:     	ldr	x0, [x19, #0x418]
102a04960:     	lsl	x1, x8, #2
102a04964:     	mov	w2, #0x4                ; =4
102a04968:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a0496c:     	ldp	x20, x8, [x21, #0xc0]
102a04970:     	mov	w9, #0x60               ; =96
102a04974:     	madd	x22, x8, x9, x20
102a04978:     	str	x20, [x28, #0x400]
102a0497c:     	str	x22, [x28, #0x408]
102a04980:     	add	x8, sp, #0x108
102a04984:     	str	x8, [x28, #0x410]
102a04988:     	str	x21, [x28, #0x418]
102a0498c:     	mov	w25, #0x1               ; =1
102a04990:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a04994:     	add	x8, x8, #0x200
102a04998:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a0499c:     	add	x0, x0, #0x600
102a049a0:     	bl	0x1027ac2f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_>
102a049a4:     	ldr	x26, [x19, #0x420]
102a049a8:     	cbz	x26, 0x102a049f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x22c>
102a049ac:     	ldr	x25, [x19, #0x418]
102a049b0:     	cmp	x26, #0x1
102a049b4:     	add	x27, sp, #0xdf0
102a049b8:     	b.ne	0x102a06170 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x19ac>
102a049bc:     	ldr	x8, [x27, #0x410]
102a049c0:     	str	x25, [x28, #0x400]
102a049c4:     	add	x9, x25, x26, lsl #3
102a049c8:     	str	x25, [x28, #0x408]
102a049cc:     	str	x8, [x28, #0x410]
102a049d0:     	str	x9, [x28, #0x418]
102a049d4:     	mov	w25, #0x1               ; =1
102a049d8:     	add	x8, sp, #0x120
102a049dc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a049e0:     	add	x0, x0, #0x600
102a049e4:     	bl	0x1025545f0 <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4G_8BTreeSetB18_E16from_sorted_iterB3V_E0EECs1qJAwyMG1lC_11mech_engine>
102a049e8:     	add	x19, sp, #0xdf0
102a049ec:     	b	0x102a04a10 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x24c>
102a049f0:     	str	xzr, [sp, #0x120]
102a049f4:     	str	xzr, [sp, #0x130]
102a049f8:     	ldr	x8, [x19, #0x410]
102a049fc:     	cbz	x8, 0x102a04a10 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x24c>
102a04a00:     	ldr	x0, [x19, #0x418]
102a04a04:     	lsl	x1, x8, #3
102a04a08:     	mov	w2, #0x4                ; =4
102a04a0c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a04a10:     	mov	w25, #0x1               ; =1
102a04a14:     	str	x25, [x28, #0x400]
102a04a18:     	str	x24, [x28, #0x408]
102a04a1c:     	str	xzr, [x28, #0x410]
102a04a20:     	str	xzr, [x28, #0x438]
102a04a24:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a04a28:     	add	x8, x8, #0x200
102a04a2c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04a30:     	add	x0, x0, #0x600
102a04a34:     	bl	0x1027abcd0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_>
102a04a38:     	ldr	x26, [x19, #0x420]
102a04a3c:     	cbz	x26, 0x102a04a7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2b8>
102a04a40:     	ldr	x25, [x19, #0x418]
102a04a44:     	cmp	x26, #0x1
102a04a48:     	b.ne	0x102a061ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x19e8>
102a04a4c:     	ldr	x8, [x19, #0x410]
102a04a50:     	str	x25, [x28, #0x400]
102a04a54:     	add	x9, x25, x26, lsl #2
102a04a58:     	str	x25, [x28, #0x408]
102a04a5c:     	str	x8, [x28, #0x410]
102a04a60:     	str	x9, [x28, #0x418]
102a04a64:     	mov	w25, #0x1               ; =1
102a04a68:     	add	x8, sp, #0x138
102a04a6c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04a70:     	add	x0, x0, #0x600
102a04a74:     	bl	0x102554524 <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4D_8BTreeSetB18_E16from_sorted_iterB3S_E0EECs1qJAwyMG1lC_11mech_engine>
102a04a78:     	b	0x102a04a9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2d8>
102a04a7c:     	str	xzr, [sp, #0x138]
102a04a80:     	str	xzr, [sp, #0x148]
102a04a84:     	ldr	x8, [x19, #0x410]
102a04a88:     	cbz	x8, 0x102a04a9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2d8>
102a04a8c:     	ldr	x0, [x19, #0x418]
102a04a90:     	lsl	x1, x8, #2
102a04a94:     	mov	w2, #0x4                ; =4
102a04a98:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a04a9c:     	str	x20, [x28, #0x400]
102a04aa0:     	str	x22, [x28, #0x408]
102a04aa4:     	add	x8, sp, #0x138
102a04aa8:     	str	x8, [x28, #0x410]
102a04aac:     	str	x21, [x28, #0x418]
102a04ab0:     	mov	w25, #0x1               ; =1
102a04ab4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a04ab8:     	add	x8, x8, #0x200
102a04abc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04ac0:     	add	x0, x0, #0x600
102a04ac4:     	bl	0x1027ac2f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_>
102a04ac8:     	add	x19, sp, #0x150
102a04acc:     	add	x27, sp, #0xdf0
102a04ad0:     	ldr	x26, [x27, #0x420]
102a04ad4:     	cbz	x26, 0x102a04b14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x350>
102a04ad8:     	ldr	x25, [x27, #0x418]
102a04adc:     	cmp	x26, #0x1
102a04ae0:     	b.ne	0x102a06214 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a50>
102a04ae4:     	ldr	x8, [x27, #0x410]
102a04ae8:     	str	x25, [x28, #0x400]
102a04aec:     	add	x9, x25, x26, lsl #3
102a04af0:     	str	x25, [x28, #0x408]
102a04af4:     	str	x8, [x28, #0x410]
102a04af8:     	str	x9, [x28, #0x418]
102a04afc:     	mov	w25, #0x1               ; =1
102a04b00:     	add	x8, sp, #0x150
102a04b04:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04b08:     	add	x0, x0, #0x600
102a04b0c:     	bl	0x1025545f0 <__RINvMsi_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB6_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB8_7set_val9SetValZSTE27bulk_build_from_sorted_iterINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtBc_3vec9into_iter8IntoIterB18_ENCINvMse_NtB8_3setINtB4G_8BTreeSetB18_E16from_sorted_iterB3V_E0EECs1qJAwyMG1lC_11mech_engine>
102a04b10:     	b	0x102a04b38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x374>
102a04b14:     	str	xzr, [sp, #0x150]
102a04b18:     	str	xzr, [x19, #0x10]
102a04b1c:     	add	x9, sp, #0xdf0
102a04b20:     	ldr	x8, [x27, #0x410]
102a04b24:     	cbz	x8, 0x102a04b38 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x374>
102a04b28:     	ldr	x0, [x9, #0x418]
102a04b2c:     	lsl	x1, x8, #3
102a04b30:     	mov	w2, #0x4                ; =4
102a04b34:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a04b38:     	stp	x20, x22, [x19, #0x30]
102a04b3c:     	add	x8, sp, #0xd4
102a04b40:     	stp	x21, x8, [x19, #0x40]
102a04b44:     	add	x8, sp, #0x138
102a04b48:     	stp	x8, x19, [x19, #0x50]
102a04b4c:     	add	x8, sp, #0x108
102a04b50:     	add	x9, sp, #0x120
102a04b54:     	stp	x8, x9, [x19, #0x60]
102a04b58:     	str	x21, [x19, #0x70]
102a04b5c:     	add	x8, sp, #0x168
102a04b60:     	add	x0, sp, #0x180
102a04b64:     	bl	0x1027bd7e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_>
102a04b68:     	ldr	x27, [sp, #0xc8]
102a04b6c:     	mov	x22, x27
102a04b70:     	ldr	x9, [x22, #0xb8]!
102a04b74:     	add	x20, sp, #0x1, lsl #12  ; =0x1000
102a04b78:     	add	x20, x20, #0x600
102a04b7c:     	mov	w8, #0x4                ; =4
102a04b80:     	stp	xzr, x8, [x19, #0x78]
102a04b84:     	ldp	x10, x11, [x22, #0x8]
102a04b88:     	stp	x10, x9, [sp, #0x60]
102a04b8c:     	ldp	x9, x10, [x22, #0x18]
102a04b90:     	stp	x9, x11, [sp, #0x50]
102a04b94:     	ldp	x9, x8, [x22, #0x28]
102a04b98:     	stp	x9, x10, [sp, #0xa0]
102a04b9c:     	str	x8, [sp, #0x48]
102a04ba0:     	ldp	x9, x8, [x22, #0x38]
102a04ba4:     	stp	x8, x9, [sp, #0x90]
102a04ba8:     	ldp	x9, x8, [x22, #0x48]
102a04bac:     	stp	x8, x9, [sp, #0x80]
102a04bb0:     	ldr	x8, [x22, #0x58]
102a04bb4:     	str	x8, [sp, #0x78]
102a04bb8:     	ldp	w8, w9, [x22, #0x60]
102a04bbc:     	str	w8, [sp, #0x74]
102a04bc0:     	mov	w8, #0x2                ; =2
102a04bc4:     	stp	xzr, x8, [x19, #0x88]
102a04bc8:     	cbz	x24, 0x102a04e5c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x698>
102a04bcc:     	ldp	x26, x10, [x27, #0x88]
102a04bd0:     	ldr	x8, [x27, #0x98]
102a04bd4:     	cmp	x26, #0x0
102a04bd8:     	csel	x8, x8, xzr, ne
102a04bdc:     	cset	w9, ne
102a04be0:     	str	x9, [x28, #0x400]
102a04be4:     	str	xzr, [x28, #0x408]
102a04be8:     	str	x26, [x28, #0x410]
102a04bec:     	str	x10, [x28, #0x418]
102a04bf0:     	str	x9, [x28, #0x420]
102a04bf4:     	str	xzr, [x28, #0x428]
102a04bf8:     	str	x26, [x28, #0x430]
102a04bfc:     	str	x10, [sp, #0x38]
102a04c00:     	str	x10, [x28, #0x438]
102a04c04:     	str	x8, [x28, #0x440]
102a04c08:     	add	x8, sp, #0xd4
102a04c0c:     	str	x8, [x28, #0x448]
102a04c10:     	mov	w25, #0x1               ; =1
102a04c14:     	add	x8, sp, #0x5c8
102a04c18:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04c1c:     	add	x0, x0, #0x600
102a04c20:     	bl	0x10259408c <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_>
102a04c24:     	add	x0, sp, #0x5e0
102a04c28:     	mov	x1, x24
102a04c2c:     	bl	0x102a21be0 <__RNvXs50_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_14CallMemoryPlanNtNtCsgDHHaSskbIF_4core5clone5Clone5clone>
102a04c30:     	ldr	x10, [x19, #0x7a0]
102a04c34:     	cbz	x10, 0x102a04d04 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x540>
102a04c38:     	ldr	x8, [x27, #0x70]
102a04c3c:     	cbz	x8, 0x102a04d04 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x540>
102a04c40:     	mov	x13, #0x0               ; =0
102a04c44:     	ldr	x9, [x19, #0x798]
102a04c48:     	mov	w11, #0x30              ; =48
102a04c4c:     	madd	x10, x10, x11, x9
102a04c50:     	ldr	w11, [sp, #0xd4]
102a04c54:     	ldr	x12, [x27, #0x78]
102a04c58:     	mov	x14, x9
102a04c5c:     	add	x9, x9, #0x30
102a04c60:     	and	w15, w13, #0xffff
102a04c64:     	add	x13, x13, #0x1
102a04c68:     	mov	x16, x12
102a04c6c:     	mov	x17, x8
102a04c70:     	add	x4, x17, #0x218
102a04c74:     	ldrh	w2, [x17, #0x272]
102a04c78:     	sub	x1, x17, #0x30
102a04c7c:     	lsl	x3, x2, #3
102a04c80:     	mov	x0, #-0x1               ; =-1
102a04c84:     	cbz	x3, 0x102a04cd4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x510>
102a04c88:     	ldr	w5, [x4]
102a04c8c:     	ldrh	w6, [x4, #0x4]
102a04c90:     	add	x4, x4, #0x8
102a04c94:     	cmp	w15, w6
102a04c98:     	cset	w6, hi
102a04c9c:     	csinv	w6, w6, wzr, hs
102a04ca0:     	cmp	w11, w5
102a04ca4:     	cset	w5, hi
102a04ca8:     	csinv	w5, w5, wzr, hs
102a04cac:     	csel	w5, w6, w5, eq
102a04cb0:     	add	x1, x1, #0x30
102a04cb4:     	add	x0, x0, #0x1
102a04cb8:     	sub	x3, x3, #0x8
102a04cbc:     	and	w5, w5, #0xff
102a04cc0:     	cmp	w5, #0x1
102a04cc4:     	b.eq	0x102a04c84 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x4c0>
102a04cc8:     	cbz	w5, 0x102a04cec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x528>
102a04ccc:     	cbnz	x16, 0x102a04cdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x518>
102a04cd0:     	b	0x102a04cfc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x538>
102a04cd4:     	mov	x0, x2
102a04cd8:     	cbz	x16, 0x102a04cfc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x538>
102a04cdc:     	add	x17, x17, x0, lsl #3
102a04ce0:     	ldr	x17, [x17, #0x278]
102a04ce4:     	sub	x16, x16, #0x1
102a04ce8:     	b	0x102a04c70 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x4ac>
102a04cec:     	ldp	q0, q1, [x1]
102a04cf0:     	ldr	q2, [x1, #0x20]
102a04cf4:     	stp	q1, q2, [x14, #0x10]
102a04cf8:     	str	q0, [x14]
102a04cfc:     	cmp	x9, x10
102a04d00:     	b.ne	0x102a04c58 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x494>
102a04d04:     	ldr	x8, [x19, #0x750]
102a04d08:     	str	xzr, [x19, #0x8a8]
102a04d0c:     	str	x8, [x19, #0x8b0]
102a04d10:     	str	x27, [x19, #0x890]
102a04d14:     	add	x8, sp, #0xd4
102a04d18:     	str	x8, [x19, #0x898]
102a04d1c:     	add	x8, sp, #0x5c8
102a04d20:     	str	x8, [x19, #0x8a0]
102a04d24:     	add	x8, sp, #0x9c8
102a04d28:     	add	x0, sp, #0x9e0
102a04d2c:     	bl	0x1027d5f84 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0EE9from_iterB48_>
102a04d30:     	ldr	x3, [x19, #0x880]
102a04d34:     	ldr	x4, [x19, #0x888]
102a04d38:     	ldr	q0, [x19, #0x500]
102a04d3c:     	str	q0, [x20, #0x620]
102a04d40:     	ldr	q0, [x19, #0x510]
102a04d44:     	str	q0, [x20, #0x630]
102a04d48:     	ldr	q0, [x19, #0x520]
102a04d4c:     	str	q0, [x20, #0x640]
102a04d50:     	ldr	x8, [x19, #0x530]
102a04d54:     	str	x8, [x20, #0x650]
102a04d58:     	ldr	q0, [x19, #0x4c0]
102a04d5c:     	str	q0, [x20, #0x5e0]
102a04d60:     	ldr	q0, [x19, #0x4d0]
102a04d64:     	str	q0, [x20, #0x5f0]
102a04d68:     	ldr	q0, [x19, #0x4e0]
102a04d6c:     	str	q0, [x20, #0x600]
102a04d70:     	ldr	q0, [x19, #0x4f0]
102a04d74:     	str	q0, [x20, #0x610]
102a04d78:     	ldr	q0, [x19, #0x490]
102a04d7c:     	str	q0, [x20, #0x5b0]
102a04d80:     	ldr	q0, [x19, #0x4a0]
102a04d84:     	str	q0, [x20, #0x5c0]
102a04d88:     	ldr	q0, [x19, #0x4b0]
102a04d8c:     	str	q0, [x20, #0x5d0]
102a04d90:     	str	xzr, [x19, #0x490]
102a04d94:     	str	xzr, [x19, #0x4a0]
102a04d98:     	str	xzr, [x19, #0x4b0]
102a04d9c:     	str	xzr, [x19, #0x4c0]
102a04da0:     	str	xzr, [x19, #0x4d0]
102a04da4:     	str	xzr, [x19, #0x4e0]
102a04da8:     	str	xzr, [x19, #0x4f0]
102a04dac:     	str	xzr, [x19, #0x500]
102a04db0:     	str	xzr, [x19, #0x510]
102a04db4:     	str	xzr, [x19, #0x520]
102a04db8:     	add	x9, sp, #0x5e0
102a04dbc:     	str	wzr, [sp, #0x680]
102a04dc0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a04dc4:     	add	x8, x8, #0x600
102a04dc8:     	add	x0, sp, #0x5e0
102a04dcc:     	add	x1, x9, #0x208
102a04dd0:     	add	x2, sp, #0x5c8
102a04dd4:     	str	x3, [sp, #0x40]
102a04dd8:     	bl	0x102d73608 <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6derive27resolve_current_call_memory>
102a04ddc:     	ldr	q0, [x20, #0x620]
102a04de0:     	str	q0, [x19, #0x500]
102a04de4:     	ldr	q0, [x20, #0x630]
102a04de8:     	str	q0, [x19, #0x510]
102a04dec:     	ldr	q0, [x20, #0x640]
102a04df0:     	str	q0, [x19, #0x520]
102a04df4:     	ldr	x8, [x20, #0x650]
102a04df8:     	str	x8, [x19, #0x530]
102a04dfc:     	ldr	q0, [x20, #0x5e0]
102a04e00:     	str	q0, [x19, #0x4c0]
102a04e04:     	ldr	q0, [x20, #0x5f0]
102a04e08:     	str	q0, [x19, #0x4d0]
102a04e0c:     	ldr	q0, [x20, #0x600]
102a04e10:     	str	q0, [x19, #0x4e0]
102a04e14:     	ldr	q0, [x20, #0x610]
102a04e18:     	str	q0, [x19, #0x4f0]
102a04e1c:     	ldr	q0, [x20, #0x5b0]
102a04e20:     	str	q0, [x19, #0x490]
102a04e24:     	ldr	q0, [x20, #0x5c0]
102a04e28:     	str	q0, [x19, #0x4a0]
102a04e2c:     	ldr	q0, [x20, #0x5d0]
102a04e30:     	str	q0, [x19, #0x4b0]
102a04e34:     	ldr	x8, [x28, #0x400]
102a04e38:     	cmp	x8, #0x2
102a04e3c:     	b.ne	0x102a05098 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x8d4>
102a04e40:     	ldur	q0, [x20, #0x8]
102a04e44:     	ldur	q1, [x20, #0x18]
102a04e48:     	add	x27, sp, #0xdf0
102a04e4c:     	stp	q0, q1, [x27, #0x3e0]
102a04e50:     	ldur	q0, [x20, #0x28]
102a04e54:     	str	q0, [x27, #0x400]
102a04e58:     	b	0x102a0510c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x948>
102a04e5c:     	str	w9, [sp, #0x40]
102a04e60:     	mov	x8, #0x0                ; =0
102a04e64:     	str	xzr, [sp, #0x38]
102a04e68:     	ldp	x23, x25, [sp, #0xd8]
102a04e6c:     	ldr	x26, [sp, #0xe8]
102a04e70:     	sub	x8, x8, x24
102a04e74:     	cmp	x26, x8
102a04e78:     	b.hi	0x102a0572c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xf68>
102a04e7c:     	cbz	x26, 0x102a04e9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x6d8>
102a04e80:     	add	x8, x26, x26, lsl #1
102a04e84:     	lsl	x2, x8, #2
102a04e88:     	ldr	x8, [x19, #0x80]
102a04e8c:     	mov	w9, #0xc                ; =12
102a04e90:     	madd	x0, x24, x9, x8
102a04e94:     	mov	x1, x25
102a04e98:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a04e9c:     	add	x1, x24, x26
102a04ea0:     	str	x1, [x19, #0x88]
102a04ea4:     	cbz	x23, 0x102a04ec0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x6fc>
102a04ea8:     	add	x8, x23, x23, lsl #1
102a04eac:     	lsl	x1, x8, #2
102a04eb0:     	mov	x0, x25
102a04eb4:     	mov	w2, #0x4                ; =4
102a04eb8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a04ebc:     	ldr	x1, [x19, #0x88]
102a04ec0:     	ldr	x24, [x19, #0x80]
102a04ec4:     	sub	x8, x29, #0x61
102a04ec8:     	str	x8, [x20]
102a04ecc:     	cmp	x1, #0x2
102a04ed0:     	b.hs	0x102a06270 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1aac>
102a04ed4:     	mov	w25, #0x0               ; =0
102a04ed8:     	add	x0, sp, #0x1c8
102a04edc:     	bl	0x10276d7ac <__RINvMs_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementE8dedup_byNCNvMs4_B5_Bv_5dedup0ECs1qJAwyMG1lC_11mech_engine>
102a04ee0:     	ldr	w8, [x27]
102a04ee4:     	tbz	w8, #0x0, 0x102a04fec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x828>
102a04ee8:     	ldp	x3, x8, [x27, #0x28]
102a04eec:     	ldp	x9, x11, [sp, #0xa0]
102a04ef0:     	cmp	x3, x11
102a04ef4:     	csel	x10, x3, x11, hi
102a04ef8:     	cmp	x8, x9
102a04efc:     	csel	x9, x8, x9, hi
102a04f00:     	stp	x9, x10, [sp, #0xa0]
102a04f04:     	ldp	x8, x9, [x27, #0x38]
102a04f08:     	ldr	x10, [sp, #0x48]
102a04f0c:     	cmp	x8, x10
102a04f10:     	csel	x10, x8, x10, hi
102a04f14:     	str	x10, [sp, #0x48]
102a04f18:     	ldp	x13, x8, [sp, #0x90]
102a04f1c:     	cmp	x9, x8
102a04f20:     	csel	x8, x9, x8, hi
102a04f24:     	str	x8, [sp, #0x98]
102a04f28:     	ldp	x8, x9, [x27, #0x48]
102a04f2c:     	ldp	x10, x11, [x27, #0x58]
102a04f30:     	ldr	w12, [x27, #0x68]
102a04f34:     	cmp	x8, x13
102a04f38:     	csel	x13, x8, x13, hi
102a04f3c:     	ldr	x8, [sp, #0x88]
102a04f40:     	cmp	x9, x8
102a04f44:     	csel	x8, x9, x8, hi
102a04f48:     	stp	x8, x13, [sp, #0x88]
102a04f4c:     	ldr	x8, [sp, #0x80]
102a04f50:     	cmp	x10, x8
102a04f54:     	csel	x9, x10, x8, hi
102a04f58:     	ldr	x8, [sp, #0x78]
102a04f5c:     	cmp	x11, x8
102a04f60:     	csel	x8, x11, x8, hi
102a04f64:     	stp	x8, x9, [sp, #0x78]
102a04f68:     	ldr	w8, [sp, #0x74]
102a04f6c:     	cmp	w12, w8
102a04f70:     	csel	w8, w12, w8, hi
102a04f74:     	str	w8, [sp, #0x74]
102a04f78:     	ldp	x8, x9, [x27, #0x8]
102a04f7c:     	ldr	x10, [sp, #0x68]
102a04f80:     	cmp	x8, x10
102a04f84:     	csel	x10, x8, x10, hi
102a04f88:     	ldr	x8, [sp, #0x60]
102a04f8c:     	cmp	x9, x8
102a04f90:     	csel	x8, x9, x8, hi
102a04f94:     	stp	x8, x10, [sp, #0x60]
102a04f98:     	ldp	x8, x9, [x27, #0x18]
102a04f9c:     	ldr	x10, [sp, #0x58]
102a04fa0:     	cmp	x8, x10
102a04fa4:     	csel	x10, x8, x10, hi
102a04fa8:     	ldr	x8, [sp, #0x50]
102a04fac:     	cmp	x9, x8
102a04fb0:     	csel	x8, x9, x8, hi
102a04fb4:     	stp	x8, x10, [sp, #0x50]
102a04fb8:     	ldr	x8, [sp, #0x38]
102a04fbc:     	cmp	x3, x8
102a04fc0:     	csel	x8, x3, x8, hi
102a04fc4:     	str	x8, [sp, #0x38]
102a04fc8:     	ldp	x1, x2, [x19, #0x20]
102a04fcc:     	mov	w25, #0x0               ; =0
102a04fd0:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04fd4:     	add	x0, x0, #0x600
102a04fd8:     	mov	x4, x3
102a04fdc:     	bl	0x102a087d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn28grow_transaction_stage_total>
102a04fe0:     	ldrb	w8, [x20]
102a04fe4:     	cmp	w8, #0x16
102a04fe8:     	b.ne	0x102a0547c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xcb8>
102a04fec:     	ldp	x1, x2, [x19, #0x20]
102a04ff0:     	mov	w25, #0x0               ; =0
102a04ff4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a04ff8:     	add	x0, x0, #0x600
102a04ffc:     	bl	0x102a08d9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program17place_allocations>
102a05000:     	ldrb	w8, [x20]
102a05004:     	cmp	w8, #0x16
102a05008:     	b.ne	0x102a05430 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xc6c>
102a0500c:     	ldp	x27, x23, [x20, #0x8]
102a05010:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a05014:     	add	x8, x8, #0xbb0
102a05018:     	stp	x27, x23, [x8]
102a0501c:     	ldr	x8, [x19, #0x90]
102a05020:     	cmp	x8, #0x2
102a05024:     	b.eq	0x102a05788 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xfc4>
102a05028:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a0502c:     	add	x8, x8, #0x600
102a05030:     	add	x0, sp, #0x168
102a05034:     	bl	0x1027da000 <__RNvXsa_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
102a05038:     	mov	x24, x27
102a0503c:     	mov	x27, x23
102a05040:     	ldr	x8, [x20]
102a05044:     	ldr	x23, [x20, #0x10]
102a05048:     	cmp	x8, x23
102a0504c:     	b.ls	0x102a0567c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xeb8>
102a05050:     	ldr	x0, [x20, #0x8]
102a05054:     	add	x8, x8, x8, lsl #1
102a05058:     	lsl	x25, x8, #5
102a0505c:     	cbz	x23, 0x102a0574c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xf88>
102a05060:     	add	x8, x23, x23, lsl #1
102a05064:     	lsl	x3, x8, #5
102a05068:     	str	x0, [sp, #0x18]
102a0506c:     	mov	x1, x25
102a05070:     	mov	w2, #0x8                ; =8
102a05074:     	str	x3, [sp, #0x30]
102a05078:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
102a0507c:     	mov	x26, x0
102a05080:     	cbnz	x0, 0x102a0575c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xf98>
102a05084:     	ldr	x21, [sp, #0x18]
102a05088:     	mov	w0, #0x8                ; =8
102a0508c:     	ldr	x1, [sp, #0x30]
102a05090:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a05094:     	b	0x102a06514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d50>
102a05098:     	add	x27, sp, #0x5e0
102a0509c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a050a0:     	add	x8, x8, #0x600
102a050a4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a050a8:     	add	x0, x0, #0x200
102a050ac:     	add	x1, x8, #0x38
102a050b0:     	mov	w2, #0x3b0              ; =944
102a050b4:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a050b8:     	ldr	x25, [x19, #0x490]
102a050bc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a050c0:     	add	x0, x0, #0x200
102a050c4:     	add	x1, x27, #0x38
102a050c8:     	mov	w2, #0x1d0              ; =464
102a050cc:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a050d0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a050d4:     	add	x8, x8, #0xbb0
102a050d8:     	ldur	q0, [x8, #0x8]
102a050dc:     	ldur	q1, [x8, #0x18]
102a050e0:     	add	x27, sp, #0xdf0
102a050e4:     	stp	q0, q1, [x27, #0x3e0]
102a050e8:     	ldur	q0, [x8, #0x28]
102a050ec:     	str	q0, [x27, #0x400]
102a050f0:     	add	x0, sp, #0xe20
102a050f4:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a050f8:     	add	x1, x1, #0x200
102a050fc:     	mov	w2, #0x3b0              ; =944
102a05100:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a05104:     	cmp	x25, #0x2
102a05108:     	b.ne	0x102a05148 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x984>
102a0510c:     	ldp	q0, q1, [x27, #0x3e0]
102a05110:     	stp	q0, q1, [x27]
102a05114:     	ldr	q2, [x27, #0x400]
102a05118:     	str	q2, [x27, #0x20]
102a0511c:     	ldr	x9, [sp, #0xb0]
102a05120:     	stur	q0, [x9, #0x8]
102a05124:     	stur	q1, [x9, #0x18]
102a05128:     	stur	q2, [x9, #0x28]
102a0512c:     	mov	w8, #0x2                ; =2
102a05130:     	str	x8, [x9]
102a05134:     	b	0x102a05fec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1828>
102a05138:     	str	xzr, [sp, #0xb8]
102a0513c:     	mov	w20, #0x4               ; =4
102a05140:     	cbnz	x23, 0x102a048a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xdc>
102a05144:     	b	0x102a048b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xec>
102a05148:     	ldp	q0, q1, [x27, #0x3e0]
102a0514c:     	stp	q0, q1, [x27]
102a05150:     	ldr	q0, [x27, #0x400]
102a05154:     	str	q0, [x27, #0x20]
102a05158:     	add	x8, sp, #0xa08
102a0515c:     	add	x0, x8, #0x38
102a05160:     	add	x1, sp, #0xe20
102a05164:     	mov	w2, #0x3b0              ; =944
102a05168:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a0516c:     	ldp	q0, q1, [x27]
102a05170:     	add	x8, sp, #0xa08
102a05174:     	stur	q0, [x8, #0x8]
102a05178:     	stur	q1, [x8, #0x18]
102a0517c:     	ldr	q0, [x27, #0x20]
102a05180:     	stur	q0, [x8, #0x28]
102a05184:     	str	x25, [x8]
102a05188:     	add	x25, sp, #0xa08
102a0518c:     	ldp	x1, x2, [x19, #0x20]
102a05190:     	ldr	w5, [sp, #0xd4]
102a05194:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a05198:     	add	x0, x0, #0x600
102a0519c:     	add	x4, sp, #0xa08
102a051a0:     	mov	x3, x24
102a051a4:     	ldr	x27, [sp, #0xc8]
102a051a8:     	mov	x6, x27
102a051ac:     	bl	0x102a069a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn24refresh_turn_allocations>
102a051b0:     	ldrb	w8, [x20]
102a051b4:     	cmp	w8, #0x16
102a051b8:     	b.ne	0x102a054b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xcec>
102a051bc:     	ldr	x8, [x25, #0x398]
102a051c0:     	ldr	x9, [sp, #0xa8]
102a051c4:     	adds	x9, x8, x9
102a051c8:     	str	x9, [sp, #0xa8]
102a051cc:     	b.hs	0x102a062a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1ae0>
102a051d0:     	ldr	x8, [x25, #0x3a0]
102a051d4:     	ldr	x9, [sp, #0xa0]
102a051d8:     	adds	x9, x8, x9
102a051dc:     	str	x9, [sp, #0xa0]
102a051e0:     	b.hs	0x102a062b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1af0>
102a051e4:     	ldr	x8, [x25, #0x3a8]
102a051e8:     	ldr	x9, [sp, #0x48]
102a051ec:     	adds	x9, x8, x9
102a051f0:     	str	x9, [sp, #0x48]
102a051f4:     	b.hs	0x102a062c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b00>
102a051f8:     	ldr	x8, [x25, #0x3b0]
102a051fc:     	ldr	x9, [sp, #0x98]
102a05200:     	adds	x9, x8, x9
102a05204:     	str	x9, [sp, #0x98]
102a05208:     	b.hs	0x102a062d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b10>
102a0520c:     	ldr	x8, [x25, #0x3b8]
102a05210:     	ldr	x9, [sp, #0x90]
102a05214:     	adds	x9, x8, x9
102a05218:     	str	x9, [sp, #0x90]
102a0521c:     	b.hs	0x102a062e4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b20>
102a05220:     	ldr	x8, [x25, #0x3c0]
102a05224:     	ldr	x9, [sp, #0x88]
102a05228:     	adds	x9, x8, x9
102a0522c:     	str	x9, [sp, #0x88]
102a05230:     	b.hs	0x102a062f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b30>
102a05234:     	ldr	x8, [x25, #0x3c8]
102a05238:     	ldr	x9, [sp, #0x80]
102a0523c:     	adds	x9, x8, x9
102a05240:     	str	x9, [sp, #0x80]
102a05244:     	b.hs	0x102a06304 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b40>
102a05248:     	ldr	x8, [x25, #0x3d0]
102a0524c:     	ldr	x9, [sp, #0x78]
102a05250:     	adds	x9, x8, x9
102a05254:     	str	x9, [sp, #0x78]
102a05258:     	b.hs	0x102a06314 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b50>
102a0525c:     	ldr	w8, [sp, #0xde0]
102a05260:     	ldr	w9, [sp, #0x74]
102a05264:     	adds	w9, w8, w9
102a05268:     	str	w9, [sp, #0x74]
102a0526c:     	b.hs	0x102a06324 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b60>
102a05270:     	ldr	x8, [x25, #0x378]
102a05274:     	ldr	x9, [sp, #0x68]
102a05278:     	adds	x9, x8, x9
102a0527c:     	str	x9, [sp, #0x68]
102a05280:     	b.hs	0x102a06334 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b70>
102a05284:     	ldr	x8, [x25, #0x380]
102a05288:     	ldr	x9, [sp, #0x60]
102a0528c:     	adds	x9, x8, x9
102a05290:     	str	x9, [sp, #0x60]
102a05294:     	b.hs	0x102a06344 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b80>
102a05298:     	ldr	x8, [x25, #0x388]
102a0529c:     	ldr	x9, [sp, #0x58]
102a052a0:     	adds	x9, x8, x9
102a052a4:     	str	x9, [sp, #0x58]
102a052a8:     	b.hs	0x102a06354 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1b90>
102a052ac:     	ldr	x8, [x25, #0x390]
102a052b0:     	ldr	x9, [sp, #0x50]
102a052b4:     	adds	x9, x8, x9
102a052b8:     	str	x9, [sp, #0x50]
102a052bc:     	b.hs	0x102a06364 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1ba0>
102a052c0:     	ldr	x1, [x19, #0x88]
102a052c4:     	ldr	x8, [x19, #0x78]
102a052c8:     	sub	x8, x8, x1
102a052cc:     	cmp	x23, x8
102a052d0:     	b.hi	0x102a06380 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bbc>
102a052d4:     	cbz	x23, 0x102a05308 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb44>
102a052d8:     	ldr	x8, [x19, #0x80]
102a052dc:     	mov	w9, #0xc                ; =12
102a052e0:     	madd	x8, x1, x9, x8
102a052e4:     	add	x1, x23, x1
102a052e8:     	ldr	x9, [sp, #0xc0]
102a052ec:     	ldr	x10, [x9]
102a052f0:     	ldr	w11, [x9, #0x8]
102a052f4:     	str	w11, [x8, #0x8]
102a052f8:     	str	x10, [x8], #0xc
102a052fc:     	add	x9, x9, #0xc
102a05300:     	subs	x23, x23, #0x1
102a05304:     	b.ne	0x102a052ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb28>
102a05308:     	str	x1, [x19, #0x88]
102a0530c:     	ldr	x9, [x24, #0x370]
102a05310:     	ldr	x4, [sp, #0x38]
102a05314:     	cbz	x9, 0x102a054cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xd08>
102a05318:     	ldr	x8, [x24, #0x368]
102a0531c:     	add	x9, x8, x9, lsl #2
102a05320:     	ldr	w10, [sp, #0xd4]
102a05324:     	mov	w11, #0x1b0             ; =432
102a05328:     	b	0x102a0533c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb78>
102a0532c:     	cbz	w13, 0x102a053ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xc28>
102a05330:     	add	x8, x8, #0x4
102a05334:     	cmp	x8, x9
102a05338:     	b.eq	0x102a054cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xd08>
102a0533c:     	ldrb	w12, [x8, #0x2]
102a05340:     	cmp	w12, #0x1
102a05344:     	b.ne	0x102a05330 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb6c>
102a05348:     	cbz	x26, 0x102a05684 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xec0>
102a0534c:     	ldrb	w13, [x8, #0x3]
102a05350:     	ldrh	w12, [x8]
102a05354:     	mov	x14, x4
102a05358:     	mov	x15, x26
102a0535c:     	ldrh	w0, [x15, #0x2ca]
102a05360:     	add	x16, x15, #0x28
102a05364:     	add	x1, x15, #0xe
102a05368:     	lsl	x2, x0, #3
102a0536c:     	mov	x17, #-0x1              ; =-1
102a05370:     	b	0x102a05390 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xbcc>
102a05374:     	add	x1, x1, #0x8
102a05378:     	add	x16, x16, #0x38
102a0537c:     	add	x17, x17, #0x1
102a05380:     	sub	x2, x2, #0x8
102a05384:     	and	w3, w3, #0xff
102a05388:     	cmp	w3, #0x1
102a0538c:     	b.ne	0x102a053cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xc08>
102a05390:     	cbz	x2, 0x102a053d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xc10>
102a05394:     	ldur	w3, [x1, #-0x6]
102a05398:     	cmp	w10, w3
102a0539c:     	cset	w3, hi
102a053a0:     	csinv	w3, w3, wzr, hs
102a053a4:     	b.ne	0x102a05374 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xbb0>
102a053a8:     	ldurb	w3, [x1, #-0x2]
102a053ac:     	sub	w3, w13, w3
102a053b0:     	tst	w3, #0xff
102a053b4:     	b.ne	0x102a05374 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xbb0>
102a053b8:     	ldrh	w3, [x1]
102a053bc:     	cmp	w12, w3
102a053c0:     	cset	w3, hi
102a053c4:     	csinv	w3, w3, wzr, hs
102a053c8:     	b	0x102a05374 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xbb0>
102a053cc:     	cbz	w3, 0x102a0532c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb68>
102a053d0:     	b	0x102a053d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xc14>
102a053d4:     	mov	x17, x0
102a053d8:     	cbz	x14, 0x102a05684 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xec0>
102a053dc:     	add	x15, x15, x17, lsl #3
102a053e0:     	ldr	x15, [x15, #0x2d0]
102a053e4:     	sub	x14, x14, #0x1
102a053e8:     	b	0x102a0535c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb98>
102a053ec:     	ldr	x13, [x24, #0x2b0]
102a053f0:     	cmp	x13, x12
102a053f4:     	b.ls	0x102a05f98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17d4>
102a053f8:     	ldr	x13, [x24, #0x2a8]
102a053fc:     	umaddl	x12, w12, w11, x13
102a05400:     	ldr	x13, [x12, #0xe0]
102a05404:     	cmp	x13, #0x1
102a05408:     	b.ne	0x102a05330 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb6c>
102a0540c:     	ldr	x12, [x12, #0xe8]
102a05410:     	ldr	x13, [x16]
102a05414:     	cmp	x13, x12
102a05418:     	b.ls	0x102a05330 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb6c>
102a0541c:     	mov	w8, #0xa                ; =10
102a05420:     	ldr	x11, [sp, #0xb0]
102a05424:     	strb	w8, [x11, #0x8]
102a05428:     	stp	x13, x12, [x11, #0x10]
102a0542c:     	b	0x102a05fdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1818>
102a05430:     	ldur	w9, [x20, #0x1]
102a05434:     	ldr	x12, [sp, #0xb0]
102a05438:     	stur	w9, [x12, #0x9]
102a0543c:     	ldr	w9, [sp, #0x1604]
102a05440:     	str	w9, [x12, #0xc]
102a05444:     	ldp	x9, x10, [x20, #0x8]
102a05448:     	ldur	q0, [x20, #0x18]
102a0544c:     	str	q0, [x12, #0x20]
102a05450:     	ldr	x11, [x20, #0x28]
102a05454:     	str	x11, [x12, #0x30]
102a05458:     	strb	w8, [x12, #0x8]
102a0545c:     	stp	x9, x10, [x12, #0x10]
102a05460:     	mov	w8, #0x2                ; =2
102a05464:     	str	x8, [x12]
102a05468:     	mov	w25, #0x0               ; =0
102a0546c:     	ldr	x8, [x19, #0x90]
102a05470:     	cmp	x8, #0x2
102a05474:     	b.ne	0x102a0602c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1868>
102a05478:     	b	0x102a06034 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1870>
102a0547c:     	mov	w25, #0x0               ; =0
102a05480:     	ldp	q0, q1, [x20]
102a05484:     	ldr	x9, [sp, #0xb0]
102a05488:     	stur	q0, [x9, #0x8]
102a0548c:     	stur	q1, [x9, #0x18]
102a05490:     	ldr	q0, [x20, #0x20]
102a05494:     	stur	q0, [x9, #0x28]
102a05498:     	mov	w8, #0x2                ; =2
102a0549c:     	str	x8, [x9]
102a054a0:     	ldr	x8, [x19, #0x90]
102a054a4:     	cmp	x8, #0x2
102a054a8:     	b.ne	0x102a0602c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1868>
102a054ac:     	b	0x102a06034 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1870>
102a054b0:     	ldp	q0, q1, [x20]
102a054b4:     	ldr	x11, [sp, #0xb0]
102a054b8:     	stur	q0, [x11, #0x8]
102a054bc:     	stur	q1, [x11, #0x18]
102a054c0:     	ldr	q0, [x20, #0x20]
102a054c4:     	stur	q0, [x11, #0x28]
102a054c8:     	b	0x102a05fdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1818>
102a054cc:     	ldr	x10, [x24, #0x2c0]
102a054d0:     	cbz	x10, 0x102a05694 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xed0>
102a054d4:     	mov	x23, #0x0               ; =0
102a054d8:     	mov	x8, #0x0                ; =0
102a054dc:     	ldr	x9, [x24, #0x2b8]
102a054e0:     	mov	w11, #0x1b0             ; =432
102a054e4:     	madd	x10, x10, x11, x9
102a054e8:     	ldr	w11, [sp, #0xd4]
102a054ec:     	ldp	x12, x13, [x27, #0x70]
102a054f0:     	ldr	x14, [x25, #0x2c0]
102a054f4:     	ldr	x15, [x25, #0x2b8]
102a054f8:     	mov	w16, #0x1b0             ; =432
102a054fc:     	cmp	x8, #0x10, lsl #12      ; =0x10000
102a05500:     	b.eq	0x102a05fa4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17e0>
102a05504:     	ldrh	w17, [x9]
102a05508:     	cmp	w17, #0x6
102a0550c:     	b.ne	0x102a05590 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xdcc>
102a05510:     	cbz	x12, 0x102a05684 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xec0>
102a05514:     	mov	x17, x13
102a05518:     	mov	x0, x12
102a0551c:     	add	x4, x0, #0x218
102a05520:     	ldrh	w2, [x0, #0x272]
102a05524:     	lsl	x3, x2, #3
102a05528:     	mov	x1, #-0x1               ; =-1
102a0552c:     	cbz	x3, 0x102a05578 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xdb4>
102a05530:     	ldr	w5, [x4]
102a05534:     	ldrh	w6, [x4, #0x4]
102a05538:     	add	x4, x4, #0x8
102a0553c:     	and	w7, w8, #0xffff
102a05540:     	cmp	w7, w6
102a05544:     	cset	w6, hi
102a05548:     	csinv	w6, w6, wzr, hs
102a0554c:     	cmp	w11, w5
102a05550:     	cset	w5, hi
102a05554:     	csinv	w5, w5, wzr, hs
102a05558:     	csel	w5, w6, w5, eq
102a0555c:     	add	x1, x1, #0x1
102a05560:     	sub	x3, x3, #0x8
102a05564:     	and	w5, w5, #0xff
102a05568:     	cmp	w5, #0x1
102a0556c:     	b.eq	0x102a0552c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xd68>
102a05570:     	cbz	w5, 0x102a05590 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xdcc>
102a05574:     	b	0x102a0557c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xdb8>
102a05578:     	mov	x1, x2
102a0557c:     	cbz	x17, 0x102a05684 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xec0>
102a05580:     	add	x0, x0, x1, lsl #3
102a05584:     	ldr	x0, [x0, #0x278]
102a05588:     	sub	x17, x17, #0x1
102a0558c:     	b	0x102a0551c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xd58>
102a05590:     	cbz	x26, 0x102a05644 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe80>
102a05594:     	ldr	x17, [sp, #0x38]
102a05598:     	mov	x0, x26
102a0559c:     	ldrh	w3, [x0, #0x2ca]
102a055a0:     	add	x1, x0, #0x28
102a055a4:     	add	x4, x0, #0xe
102a055a8:     	lsl	x5, x3, #3
102a055ac:     	mov	x2, #-0x1               ; =-1
102a055b0:     	b	0x102a055e4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe20>
102a055b4:     	ldrh	w6, [x4]
102a055b8:     	and	w7, w8, #0xffff
102a055bc:     	cmp	w7, w6
102a055c0:     	cset	w6, hi
102a055c4:     	csinv	w6, w6, wzr, hs
102a055c8:     	add	x4, x4, #0x8
102a055cc:     	add	x1, x1, #0x38
102a055d0:     	add	x2, x2, #0x1
102a055d4:     	sub	x5, x5, #0x8
102a055d8:     	and	w6, w6, #0xff
102a055dc:     	cmp	w6, #0x1
102a055e0:     	b.ne	0x102a0560c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe48>
102a055e4:     	cbz	x5, 0x102a05614 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe50>
102a055e8:     	ldur	w6, [x4, #-0x6]
102a055ec:     	cmp	w11, w6
102a055f0:     	cset	w6, hi
102a055f4:     	csinv	w6, w6, wzr, hs
102a055f8:     	b.ne	0x102a055c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe04>
102a055fc:     	ldurb	w6, [x4, #-0x2]
102a05600:     	cbnz	w6, 0x102a055b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xdf0>
102a05604:     	mov	w6, #0x1                ; =1
102a05608:     	b	0x102a055c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe04>
102a0560c:     	cbz	w6, 0x102a0562c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe68>
102a05610:     	b	0x102a05618 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe54>
102a05614:     	mov	x2, x3
102a05618:     	cbz	x17, 0x102a05644 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe80>
102a0561c:     	add	x0, x0, x2, lsl #3
102a05620:     	ldr	x0, [x0, #0x2d0]
102a05624:     	sub	x17, x17, #0x1
102a05628:     	b	0x102a0559c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xdd8>
102a0562c:     	ldr	w17, [x9, #0xe0]
102a05630:     	tbz	w17, #0x0, 0x102a05644 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xe80>
102a05634:     	ldr	x17, [x9, #0xe8]
102a05638:     	ldr	x0, [x1]
102a0563c:     	cmp	x0, x17
102a05640:     	b.hi	0x102a060f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1930>
102a05644:     	cmp	x8, x14
102a05648:     	b.eq	0x102a05f98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17d4>
102a0564c:     	madd	x17, x8, x16, x15
102a05650:     	ldr	x0, [x17, #0x1a0]
102a05654:     	adds	x0, x0, x23
102a05658:     	b.hs	0x102a05fc0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17fc>
102a0565c:     	ldr	x17, [x17, #0x130]
102a05660:     	adds	x23, x17, x0
102a05664:     	b.hs	0x102a05fc0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17fc>
102a05668:     	add	x9, x9, #0x1b0
102a0566c:     	add	x8, x8, #0x1
102a05670:     	cmp	x9, x10
102a05674:     	b.ne	0x102a054fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xd38>
102a05678:     	b	0x102a05698 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xed4>
102a0567c:     	ldr	x26, [x20, #0x8]
102a05680:     	b	0x102a0575c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xf98>
102a05684:     	mov	w8, #0x102              ; =258
102a05688:     	ldr	x11, [sp, #0xb0]
102a0568c:     	strh	w8, [x11, #0x8]
102a05690:     	b	0x102a05fdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1818>
102a05694:     	mov	x23, #0x0               ; =0
102a05698:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a0569c:     	add	x0, x0, #0x600
102a056a0:     	add	x1, sp, #0xa08
102a056a4:     	mov	w2, #0x3e8              ; =1000
102a056a8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a056ac:     	ldp	x3, x4, [x19, #0x20]
102a056b0:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a056b4:     	add	x0, x0, #0x200
102a056b8:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a056bc:     	add	x1, x1, #0x600
102a056c0:     	mov	x2, x24
102a056c4:     	bl	0x102a04250 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15scope_turn_call>
102a056c8:     	str	x23, [sp, #0x38]
102a056cc:     	add	x0, sp, #0x1e0
102a056d0:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a056d4:     	add	x1, x1, #0x200
102a056d8:     	mov	w2, #0x3e8              ; =1000
102a056dc:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a056e0:     	ldr	x8, [x19, #0x878]
102a056e4:     	cbz	x8, 0x102a056fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xf38>
102a056e8:     	lsl	x9, x8, #6
102a056ec:     	sub	x1, x9, x8, lsl #3
102a056f0:     	ldr	x0, [sp, #0x40]
102a056f4:     	mov	w2, #0x8                ; =8
102a056f8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a056fc:     	add	x0, sp, #0x5e0
102a05700:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a05704:     	mov	w25, #0x1               ; =1
102a05708:     	add	x0, sp, #0x5c8
102a0570c:     	bl	0x1025ba820 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a05710:     	ldr	x24, [x19, #0x88]
102a05714:     	ldr	x8, [x19, #0x78]
102a05718:     	ldp	x23, x25, [sp, #0xd8]
102a0571c:     	ldr	x26, [sp, #0xe8]
102a05720:     	sub	x8, x8, x24
102a05724:     	cmp	x26, x8
102a05728:     	b.ls	0x102a04e7c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x6b8>
102a0572c:     	add	x0, sp, #0x1c8
102a05730:     	mov	x1, x24
102a05734:     	mov	x2, x26
102a05738:     	mov	w3, #0x4                ; =4
102a0573c:     	mov	w4, #0xc                ; =12
102a05740:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a05744:     	ldr	x24, [x19, #0x88]
102a05748:     	b	0x102a04e80 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x6bc>
102a0574c:     	mov	w26, #0x8               ; =8
102a05750:     	mov	x1, x25
102a05754:     	mov	w2, #0x8                ; =8
102a05758:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a0575c:     	ldr	x8, [x19, #0x3d0]
102a05760:     	cbz	x8, 0x102a05778 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xfb4>
102a05764:     	ldr	x0, [x19, #0x3c8]
102a05768:     	add	x8, x8, x8, lsl #1
102a0576c:     	lsl	x1, x8, #5
102a05770:     	mov	w2, #0x8                ; =8
102a05774:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a05778:     	str	x26, [x19, #0x3c8]
102a0577c:     	str	x23, [x19, #0x3d0]
102a05780:     	mov	x23, x27
102a05784:     	mov	x27, x24
102a05788:     	ldp	x26, x24, [x19, #0x20]
102a0578c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a05790:     	add	x0, x0, #0x600
102a05794:     	mov	x1, x26
102a05798:     	mov	x2, x24
102a0579c:     	bl	0x102a04504 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn17turn_storage_peak>
102a057a0:     	ldrb	w8, [x20]
102a057a4:     	cmp	w8, #0x16
102a057a8:     	b.ne	0x102a05850 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x108c>
102a057ac:     	ldr	x8, [x20, #0x8]
102a057b0:     	ldr	x9, [sp, #0x48]
102a057b4:     	cmp	x8, x9
102a057b8:     	csel	x8, x8, x9, hi
102a057bc:     	str	x8, [sp, #0x30]
102a057c0:     	ldp	x8, x9, [x21, #0xd0]
102a057c4:     	add	x9, x8, x9, lsl #5
102a057c8:     	str	x8, [x28, #0x3e8]
102a057cc:     	str	x9, [x28, #0x3f0]
102a057d0:     	add	x8, sp, #0xd4
102a057d4:     	str	x8, [x28, #0x3f8]
102a057d8:     	add	x8, sp, #0xe20
102a057dc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a057e0:     	add	x0, x0, #0x5e8
102a057e4:     	bl	0x1027bdce0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_>
102a057e8:     	mov	x8, #0x0                ; =0
102a057ec:     	add	x9, x24, x24, lsl #1
102a057f0:     	lsl	x9, x9, #5
102a057f4:     	ldr	x2, [sp, #0x38]
102a057f8:     	str	x23, [sp, #0x20]
102a057fc:     	cmp	x9, x8
102a05800:     	b.eq	0x102a058e4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1120>
102a05804:     	add	x10, x26, x8
102a05808:     	ldr	w10, [x10, #0x8]
102a0580c:     	add	x8, x8, #0x60
102a05810:     	cmp	w10, #0x2
102a05814:     	b.ne	0x102a057fc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1038>
102a05818:     	add	x10, x26, x8
102a0581c:     	ldur	x25, [x10, #-0x40]
102a05820:     	subs	x9, x9, x8
102a05824:     	b.eq	0x102a058e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1124>
102a05828:     	mov	x11, #-0x5555555555555556 ; =-6148914691236517206
102a0582c:     	movk	x11, #0xaaab
102a05830:     	umulh	x12, x9, x11
102a05834:     	lsr	x9, x12, #6
102a05838:     	sub	x11, x9, #0x1
102a0583c:     	ubfx	x9, x12, #6, #3
102a05840:     	cmp	x11, #0x7
102a05844:     	b.hs	0x102a05e10 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x164c>
102a05848:     	mov	x10, #0x0               ; =0
102a0584c:     	b	0x102a05f54 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1790>
102a05850:     	ldur	w9, [x20, #0x1]
102a05854:     	ldr	x10, [sp, #0xb0]
102a05858:     	stur	w9, [x10, #0x9]
102a0585c:     	ldr	w9, [sp, #0x1604]
102a05860:     	str	w9, [x10, #0xc]
102a05864:     	ldr	x9, [x20, #0x8]
102a05868:     	ldp	q0, q1, [x20, #0x10]
102a0586c:     	stur	q0, [x10, #0x18]
102a05870:     	stur	q1, [x10, #0x28]
102a05874:     	strb	w8, [x10, #0x8]
102a05878:     	str	x9, [x10, #0x10]
102a0587c:     	mov	w8, #0x2                ; =2
102a05880:     	str	x8, [x10]
102a05884:     	cbz	x23, 0x102a05468 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xca4>
102a05888:     	add	x20, x27, #0x10
102a0588c:     	mov	x21, x23
102a05890:     	b	0x102a058a0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x10dc>
102a05894:     	add	x20, x20, #0x30
102a05898:     	subs	x21, x21, #0x1
102a0589c:     	b.eq	0x102a058bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x10f8>
102a058a0:     	ldr	x8, [x20]
102a058a4:     	cbz	x8, 0x102a05894 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x10d0>
102a058a8:     	ldur	x0, [x20, #-0x8]
102a058ac:     	lsl	x1, x8, #2
102a058b0:     	mov	w2, #0x4                ; =4
102a058b4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a058b8:     	b	0x102a05894 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x10d0>
102a058bc:     	add	x8, x23, x23, lsl #1
102a058c0:     	lsl	x1, x8, #4
102a058c4:     	mov	x0, x27
102a058c8:     	mov	w2, #0x8                ; =8
102a058cc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a058d0:     	mov	w25, #0x0               ; =0
102a058d4:     	ldr	x8, [x19, #0x90]
102a058d8:     	cmp	x8, #0x2
102a058dc:     	b.ne	0x102a0602c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1868>
102a058e0:     	b	0x102a06034 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1870>
102a058e4:     	mov	x25, #0x0               ; =0
102a058e8:     	ldr	w8, [sp, #0xd4]
102a058ec:     	add	x9, sp, #0xdf0
102a058f0:     	ldp	x10, x11, [sp, #0x60]
102a058f4:     	str	x11, [x9, #0x410]
102a058f8:     	str	x10, [x9, #0x418]
102a058fc:     	ldp	x10, x11, [sp, #0x50]
102a05900:     	str	x11, [x9, #0x420]
102a05904:     	str	x10, [x9, #0x428]
102a05908:     	ldp	x10, x11, [sp, #0xa0]
102a0590c:     	str	x11, [x9, #0x430]
102a05910:     	str	x10, [x9, #0x438]
102a05914:     	ldr	x10, [sp, #0x30]
102a05918:     	str	x10, [x9, #0x440]
102a0591c:     	ldp	x10, x11, [sp, #0x90]
102a05920:     	str	x11, [x9, #0x448]
102a05924:     	str	x10, [x9, #0x450]
102a05928:     	ldp	x10, x11, [sp, #0x80]
102a0592c:     	str	x11, [x9, #0x458]
102a05930:     	str	x10, [x9, #0x460]
102a05934:     	ldr	x10, [sp, #0x78]
102a05938:     	str	x10, [x9, #0x468]
102a0593c:     	ldr	w9, [sp, #0x74]
102a05940:     	str	w9, [sp, #0x1260]
102a05944:     	ldr	w9, [sp, #0x40]
102a05948:     	str	w9, [sp, #0x1264]
102a0594c:     	mov	w9, #0x3                ; =3
102a05950:     	orr	x0, x9, x8, lsl #32
102a05954:     	ldp	q0, q1, [x21, #0x80]
102a05958:     	stp	q0, q1, [x20, #0x80]
102a0595c:     	ldr	x8, [x21, #0xa0]
102a05960:     	str	x8, [x20, #0xa0]
102a05964:     	ldp	q0, q1, [x21, #0x40]
102a05968:     	stp	q0, q1, [x20, #0x40]
102a0596c:     	ldp	q1, q0, [x21, #0x60]
102a05970:     	stp	q1, q0, [x20, #0x60]
102a05974:     	ldp	q0, q1, [x21]
102a05978:     	stp	q0, q1, [x20]
102a0597c:     	ldp	q1, q0, [x21, #0x20]
102a05980:     	stp	q1, q0, [x20, #0x20]
102a05984:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a05988:     	add	x1, x1, #0x200
102a0598c:     	add	x4, sp, #0x1, lsl #12   ; =0x1000
102a05990:     	add	x4, x4, #0x600
102a05994:     	mov	x3, x25
102a05998:     	bl	0x102d1b8a4 <__RNvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget27evaluate_call_memory_budget>
102a0599c:     	mov	x24, x1
102a059a0:     	lsl	x10, x1, #5
102a059a4:     	add	x8, sp, #0xdf0
102a059a8:     	ldr	x9, [x8, #0x40]
102a059ac:     	ldr	x8, [x8, #0x30]
102a059b0:     	mov	x23, x9
102a059b4:     	sub	x8, x8, x9
102a059b8:     	cmp	x1, x8
102a059bc:     	str	x27, [sp, #0x28]
102a059c0:     	b.hi	0x102a063a4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1be0>
102a059c4:     	cbz	x24, 0x102a05a08 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1244>
102a059c8:     	str	x10, [sp, #0x48]
102a059cc:     	str	x0, [sp, #0x18]
102a059d0:     	add	x27, sp, #0xdf0
102a059d4:     	ldr	x8, [x27, #0x38]
102a059d8:     	add	x0, x8, x23, lsl #5
102a059dc:     	ldr	x26, [sp, #0x18]
102a059e0:     	mov	x1, x26
102a059e4:     	ldr	x2, [sp, #0x48]
102a059e8:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a059ec:     	add	x23, x23, x24
102a059f0:     	str	x23, [x27, #0x40]
102a059f4:     	mov	x0, x26
102a059f8:     	ldr	x1, [sp, #0x48]
102a059fc:     	mov	w2, #0x8                ; =8
102a05a00:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a05a04:     	b	0x102a05a10 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x124c>
102a05a08:     	add	x27, sp, #0xdf0
102a05a0c:     	str	x23, [x27, #0x40]
102a05a10:     	ldr	x27, [x27, #0x38]
102a05a14:     	str	x23, [sp, #0x48]
102a05a18:     	cmp	x23, #0x2
102a05a1c:     	str	x27, [sp, #0x18]
102a05a20:     	b.hs	0x102a063d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1c0c>
102a05a24:     	ldr	x23, [sp, #0xc8]
102a05a28:     	ldr	x26, [sp, #0x28]
102a05a2c:     	ldr	x8, [x23, #0x80]
102a05a30:     	cbz	x8, 0x102a05a88 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x12c4>
102a05a34:     	ldr	x1, [x23, #0x70]
102a05a38:     	cbz	x1, 0x102a064e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d24>
102a05a3c:     	ldr	x2, [x23, #0x78]
102a05a40:     	add	x0, sp, #0x5e0
102a05a44:     	bl	0x10258d774 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model16RegionAccessPlanNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a05a48:     	ldr	x8, [x23, #0x98]
102a05a4c:     	cbz	x8, 0x102a05a98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x12d4>
102a05a50:     	ldr	x1, [x23, #0x88]
102a05a54:     	cbz	x1, 0x102a064f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d34>
102a05a58:     	ldr	x2, [x23, #0x90]
102a05a5c:     	add	x0, sp, #0xa08
102a05a60:     	bl	0x10258d40c <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB2d_18operation_contract10validation13PortDirectiontENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a05a64:     	ldr	x8, [x23, #0xb0]
102a05a68:     	cbz	x8, 0x102a05aac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x12e8>
102a05a6c:     	ldr	x1, [x23, #0xa0]
102a05a70:     	cbz	x1, 0x102a06508 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d44>
102a05a74:     	ldr	x2, [x23, #0xa8]
102a05a78:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a05a7c:     	add	x0, x0, #0x600
102a05a80:     	bl	0x10258dab8 <__RINvNvXs0_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB8_8BTreeMappppENtNtCsgDHHaSskbIF_4core5clone5Clone5clone13clone_subtreeTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB2d_11memory_plan5model22CurrentMemoryFootprintNtNtBe_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a05a84:     	b	0x102a05ab4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x12f0>
102a05a88:     	str	xzr, [x19, #0x490]
102a05a8c:     	str	xzr, [x19, #0x4a0]
102a05a90:     	ldr	x8, [x23, #0x98]
102a05a94:     	cbnz	x8, 0x102a05a50 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x128c>
102a05a98:     	add	x8, sp, #0xa08
102a05a9c:     	str	xzr, [x8]
102a05aa0:     	str	xzr, [x8, #0x10]
102a05aa4:     	ldr	x8, [x23, #0xb0]
102a05aa8:     	cbnz	x8, 0x102a05a6c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x12a8>
102a05aac:     	str	xzr, [x20]
102a05ab0:     	str	xzr, [x20, #0x10]
102a05ab4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
102a05ab8:     	add	x8, x8, #0x200
102a05abc:     	add	x8, x8, #0xb8
102a05ac0:     	ldp	q1, q0, [x22, #0x40]
102a05ac4:     	str	q0, [x8, #0x50]
102a05ac8:     	ldp	q2, q0, [x22, #0x20]
102a05acc:     	stur	q0, [x28, #0xe8]
102a05ad0:     	stur	q1, [x28, #0xf8]
102a05ad4:     	ldr	x8, [x22, #0x60]
102a05ad8:     	str	x8, [x28, #0x118]
102a05adc:     	ldp	q0, q1, [x22]
102a05ae0:     	stur	q0, [x28, #0xb8]
102a05ae4:     	stur	q1, [x28, #0xc8]
102a05ae8:     	stur	q2, [x28, #0xd8]
102a05aec:     	ldr	q0, [x19, #0x490]
102a05af0:     	ldr	x8, [x19, #0x4a0]
102a05af4:     	str	x8, [x28, #0x80]
102a05af8:     	add	x9, sp, #0xa08
102a05afc:     	ldr	x8, [x9, #0x10]
102a05b00:     	str	x8, [x28, #0x98]
102a05b04:     	ldr	q1, [x9]
102a05b08:     	stur	q1, [x28, #0x88]
102a05b0c:     	ldr	x8, [x20, #0x10]
102a05b10:     	str	x8, [x28, #0xb0]
102a05b14:     	ldr	q1, [x20]
102a05b18:     	str	q1, [x28, #0xa0]
102a05b1c:     	ldp	q2, q1, [x23]
102a05b20:     	stp	q2, q1, [x28]
102a05b24:     	ldr	q1, [x23, #0x60]
102a05b28:     	stp	q1, q0, [x28, #0x60]
102a05b2c:     	ldp	q1, q0, [x23, #0x40]
102a05b30:     	stp	q1, q0, [x28, #0x40]
102a05b34:     	ldp	q0, q1, [x23, #0x20]
102a05b38:     	stp	q0, q1, [x28, #0x20]
102a05b3c:     	ldr	x10, [x19, #0x90]
102a05b40:     	ldp	x8, x22, [x19, #0x18]
102a05b44:     	ldr	x9, [x19, #0x28]
102a05b48:     	cmp	x8, x9
102a05b4c:     	str	x9, [sp, #0xc8]
102a05b50:     	str	x10, [sp, #0x8]
102a05b54:     	b.ls	0x102a05b98 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x13d4>
102a05b58:     	add	x8, x8, x8, lsl #1
102a05b5c:     	lsl	x24, x8, #5
102a05b60:     	cbz	x9, 0x102a05ba0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x13dc>
102a05b64:     	add	x8, x9, x9, lsl #1
102a05b68:     	lsl	x28, x8, #5
102a05b6c:     	mov	x0, x22
102a05b70:     	mov	x1, x24
102a05b74:     	mov	w2, #0x8                ; =8
102a05b78:     	mov	x3, x28
102a05b7c:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
102a05b80:     	str	x0, [sp, #0x10]
102a05b84:     	cbnz	x0, 0x102a05bb8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x13f4>
102a05b88:     	mov	w0, #0x8                ; =8
102a05b8c:     	mov	x1, x28
102a05b90:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a05b94:     	b	0x102a06514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d50>
102a05b98:     	str	x22, [sp, #0x10]
102a05b9c:     	b	0x102a05bb8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x13f4>
102a05ba0:     	mov	w8, #0x8                ; =8
102a05ba4:     	str	x8, [sp, #0x10]
102a05ba8:     	mov	x0, x22
102a05bac:     	mov	x1, x24
102a05bb0:     	mov	w2, #0x8                ; =8
102a05bb4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a05bb8:     	add	x8, sp, #0xa08
102a05bbc:     	ldr	x9, [sp, #0x20]
102a05bc0:     	stp	x26, x9, [x8]
102a05bc4:     	ldp	x8, x23, [x19, #0x78]
102a05bc8:     	ldr	x26, [x19, #0x88]
102a05bcc:     	cmp	x8, x26
102a05bd0:     	b.ls	0x102a05c14 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1450>
102a05bd4:     	add	x8, x8, x8, lsl #1
102a05bd8:     	lsl	x24, x8, #2
102a05bdc:     	cbz	x26, 0x102a05c68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x14a4>
102a05be0:     	add	x8, x26, x26, lsl #1
102a05be4:     	lsl	x22, x8, #2
102a05be8:     	mov	x0, x23
102a05bec:     	mov	x1, x24
102a05bf0:     	mov	w2, #0x4                ; =4
102a05bf4:     	mov	x3, x22
102a05bf8:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
102a05bfc:     	mov	x27, x0
102a05c00:     	cbnz	x0, 0x102a05c18 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1454>
102a05c04:     	mov	w0, #0x4                ; =4
102a05c08:     	mov	x1, x22
102a05c0c:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a05c10:     	b	0x102a06514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d50>
102a05c14:     	mov	x27, x23
102a05c18:     	add	x8, sp, #0xdf0
102a05c1c:     	ldr	x8, [x8, #0x30]
102a05c20:     	ldr	x9, [sp, #0x48]
102a05c24:     	cmp	x8, x9
102a05c28:     	b.ls	0x102a05c90 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x14cc>
102a05c2c:     	lsl	x24, x8, #5
102a05c30:     	ldr	x23, [sp, #0x38]
102a05c34:     	cbz	x9, 0x102a05c9c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x14d8>
102a05c38:     	lsl	x22, x9, #5
102a05c3c:     	ldr	x0, [sp, #0x18]
102a05c40:     	mov	x1, x24
102a05c44:     	mov	w2, #0x8                ; =8
102a05c48:     	mov	x3, x22
102a05c4c:     	bl	0x1000096a0 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_realloc>
102a05c50:     	mov	x28, x0
102a05c54:     	cbnz	x0, 0x102a05cb0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x14ec>
102a05c58:     	mov	w0, #0x8                ; =8
102a05c5c:     	mov	x1, x22
102a05c60:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a05c64:     	b	0x102a06514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d50>
102a05c68:     	mov	w27, #0x4               ; =4
102a05c6c:     	mov	x0, x23
102a05c70:     	mov	x1, x24
102a05c74:     	mov	w2, #0x4                ; =4
102a05c78:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a05c7c:     	add	x8, sp, #0xdf0
102a05c80:     	ldr	x8, [x8, #0x30]
102a05c84:     	ldr	x9, [sp, #0x48]
102a05c88:     	cmp	x8, x9
102a05c8c:     	b.hi	0x102a05c2c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1468>
102a05c90:     	ldr	x28, [sp, #0x18]
102a05c94:     	ldr	x23, [sp, #0x38]
102a05c98:     	b	0x102a05cb0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x14ec>
102a05c9c:     	mov	w28, #0x8               ; =8
102a05ca0:     	ldr	x0, [sp, #0x18]
102a05ca4:     	mov	x1, x24
102a05ca8:     	mov	w2, #0x8                ; =8
102a05cac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a05cb0:     	ldr	w19, [sp, #0xd4]
102a05cb4:     	add	x22, sp, #0x1, lsl #12  ; =0x1000
102a05cb8:     	add	x22, x22, #0x600
102a05cbc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a05cc0:     	add	x0, x0, #0x600
102a05cc4:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a05cc8:     	add	x1, x1, #0x200
102a05ccc:     	mov	w2, #0x120              ; =288
102a05cd0:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a05cd4:     	add	x0, x22, #0x1c8
102a05cd8:     	add	x1, sp, #0x1e0
102a05cdc:     	mov	w2, #0x3e8              ; =1000
102a05ce0:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a05ce4:     	ldp	q0, q1, [x21, #0x80]
102a05ce8:     	stp	q0, q1, [x20, #0x1a0]
102a05cec:     	ldr	x8, [x21, #0xa0]
102a05cf0:     	str	x8, [x20, #0x1c0]
102a05cf4:     	ldp	q0, q1, [x21, #0x40]
102a05cf8:     	stp	q0, q1, [x20, #0x160]
102a05cfc:     	ldp	q1, q0, [x21, #0x60]
102a05d00:     	stp	q1, q0, [x20, #0x180]
102a05d04:     	ldp	q0, q1, [x21]
102a05d08:     	stp	q0, q1, [x20, #0x120]
102a05d0c:     	ldp	q1, q0, [x21, #0x20]
102a05d10:     	stp	q1, q0, [x20, #0x140]
102a05d14:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
102a05d18:     	add	x1, x1, #0x600
102a05d1c:     	ldr	x20, [sp, #0xb0]
102a05d20:     	mov	x0, x20
102a05d24:     	mov	w2, #0x5b0              ; =1456
102a05d28:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
102a05d2c:     	ldr	x8, [sp, #0x10]
102a05d30:     	str	x8, [x20, #0x5b0]
102a05d34:     	ldr	x8, [sp, #0xc8]
102a05d38:     	str	x8, [x20, #0x5b8]
102a05d3c:     	ldp	x8, x9, [sp, #0x20]
102a05d40:     	str	x9, [x20, #0x5c0]
102a05d44:     	str	x8, [x20, #0x5c8]
102a05d48:     	str	x27, [x20, #0x5d0]
102a05d4c:     	str	x26, [x20, #0x5d8]
102a05d50:     	str	x28, [x20, #0x5e0]
102a05d54:     	ldr	x8, [sp, #0x48]
102a05d58:     	str	x8, [x20, #0x5e8]
102a05d5c:     	ldp	x8, x9, [sp, #0x60]
102a05d60:     	str	x9, [x20, #0x5f0]
102a05d64:     	str	x8, [x20, #0x5f8]
102a05d68:     	ldp	x8, x9, [sp, #0x50]
102a05d6c:     	str	x9, [x20, #0x600]
102a05d70:     	str	x8, [x20, #0x608]
102a05d74:     	ldp	x8, x9, [sp, #0xa0]
102a05d78:     	str	x9, [x20, #0x610]
102a05d7c:     	str	x8, [x20, #0x618]
102a05d80:     	ldr	x8, [sp, #0x30]
102a05d84:     	str	x8, [x20, #0x620]
102a05d88:     	ldp	x8, x9, [sp, #0x90]
102a05d8c:     	str	x9, [x20, #0x628]
102a05d90:     	str	x8, [x20, #0x630]
102a05d94:     	ldp	x8, x9, [sp, #0x80]
102a05d98:     	str	x9, [x20, #0x638]
102a05d9c:     	str	x8, [x20, #0x640]
102a05da0:     	ldr	x8, [sp, #0x78]
102a05da4:     	str	x8, [x20, #0x648]
102a05da8:     	ldr	w8, [sp, #0x74]
102a05dac:     	str	w8, [x20, #0x650]
102a05db0:     	ldr	w8, [sp, #0x40]
102a05db4:     	str	w8, [x20, #0x654]
102a05db8:     	str	x23, [x20, #0x658]
102a05dbc:     	str	x25, [x20, #0x660]
102a05dc0:     	add	x8, x20, #0x668
102a05dc4:     	movi.2d	v0, #0000000000000000
102a05dc8:     	str	q0, [x8]
102a05dcc:     	str	w19, [x20, #0x678]
102a05dd0:     	mov	w25, #0x0               ; =0
102a05dd4:     	add	x0, sp, #0x150
102a05dd8:     	bl	0x1025b8b38 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a05ddc:     	mov	w25, #0x0               ; =0
102a05de0:     	add	x0, sp, #0x138
102a05de4:     	bl	0x1025b9228 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a05de8:     	mov	w25, #0x0               ; =0
102a05dec:     	add	x0, sp, #0x120
102a05df0:     	bl	0x1025b8b38 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a05df4:     	mov	w25, #0x0               ; =0
102a05df8:     	add	x0, sp, #0x108
102a05dfc:     	ldr	x20, [sp, #0xc0]
102a05e00:     	bl	0x1025b9228 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a05e04:     	ldr	x8, [sp, #0xb8]
102a05e08:     	cbnz	x8, 0x102a060bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x18f8>
102a05e0c:     	b	0x102a060d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x190c>
102a05e10:     	mov	x11, #0x0               ; =0
102a05e14:     	lsr	x12, x12, #9
102a05e18:     	neg	x12, x12, lsl #3
102a05e1c:     	b	0x102a05e30 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x166c>
102a05e20:     	add	x10, x10, #0x300
102a05e24:     	sub	x11, x11, #0x8
102a05e28:     	cmp	x12, x11
102a05e2c:     	b.eq	0x102a05f4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1788>
102a05e30:     	ldr	w13, [x10, #0x8]
102a05e34:     	cmp	w13, #0x2
102a05e38:     	b.eq	0x102a05e94 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x16d0>
102a05e3c:     	ldr	w13, [x10, #0x68]
102a05e40:     	cmp	w13, #0x2
102a05e44:     	b.eq	0x102a05eac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x16e8>
102a05e48:     	ldr	w13, [x10, #0xc8]
102a05e4c:     	cmp	w13, #0x2
102a05e50:     	b.eq	0x102a05ec4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1700>
102a05e54:     	ldr	w13, [x10, #0x128]
102a05e58:     	cmp	w13, #0x2
102a05e5c:     	b.eq	0x102a05edc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1718>
102a05e60:     	ldr	w13, [x10, #0x188]
102a05e64:     	cmp	w13, #0x2
102a05e68:     	b.eq	0x102a05ef4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1730>
102a05e6c:     	ldr	w13, [x10, #0x1e8]
102a05e70:     	cmp	w13, #0x2
102a05e74:     	b.eq	0x102a05f0c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1748>
102a05e78:     	ldr	w13, [x10, #0x248]
102a05e7c:     	cmp	w13, #0x2
102a05e80:     	b.eq	0x102a05f24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1760>
102a05e84:     	ldr	w13, [x10, #0x2a8]
102a05e88:     	cmp	w13, #0x2
102a05e8c:     	b.ne	0x102a05e20 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x165c>
102a05e90:     	b	0x102a05f3c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1778>
102a05e94:     	ldr	x13, [x10, #0x20]
102a05e98:     	cmp	x25, x13
102a05e9c:     	csel	x25, x25, x13, hi
102a05ea0:     	ldr	w13, [x10, #0x68]
102a05ea4:     	cmp	w13, #0x2
102a05ea8:     	b.ne	0x102a05e48 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1684>
102a05eac:     	ldr	x13, [x10, #0x80]
102a05eb0:     	cmp	x25, x13
102a05eb4:     	csel	x25, x25, x13, hi
102a05eb8:     	ldr	w13, [x10, #0xc8]
102a05ebc:     	cmp	w13, #0x2
102a05ec0:     	b.ne	0x102a05e54 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1690>
102a05ec4:     	ldr	x13, [x10, #0xe0]
102a05ec8:     	cmp	x25, x13
102a05ecc:     	csel	x25, x25, x13, hi
102a05ed0:     	ldr	w13, [x10, #0x128]
102a05ed4:     	cmp	w13, #0x2
102a05ed8:     	b.ne	0x102a05e60 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x169c>
102a05edc:     	ldr	x13, [x10, #0x140]
102a05ee0:     	cmp	x25, x13
102a05ee4:     	csel	x25, x25, x13, hi
102a05ee8:     	ldr	w13, [x10, #0x188]
102a05eec:     	cmp	w13, #0x2
102a05ef0:     	b.ne	0x102a05e6c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x16a8>
102a05ef4:     	ldr	x13, [x10, #0x1a0]
102a05ef8:     	cmp	x25, x13
102a05efc:     	csel	x25, x25, x13, hi
102a05f00:     	ldr	w13, [x10, #0x1e8]
102a05f04:     	cmp	w13, #0x2
102a05f08:     	b.ne	0x102a05e78 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x16b4>
102a05f0c:     	ldr	x13, [x10, #0x200]
102a05f10:     	cmp	x25, x13
102a05f14:     	csel	x25, x25, x13, hi
102a05f18:     	ldr	w13, [x10, #0x248]
102a05f1c:     	cmp	w13, #0x2
102a05f20:     	b.ne	0x102a05e84 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x16c0>
102a05f24:     	ldr	x13, [x10, #0x260]
102a05f28:     	cmp	x25, x13
102a05f2c:     	csel	x25, x25, x13, hi
102a05f30:     	ldr	w13, [x10, #0x2a8]
102a05f34:     	cmp	w13, #0x2
102a05f38:     	b.ne	0x102a05e20 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x165c>
102a05f3c:     	ldr	x13, [x10, #0x2c0]
102a05f40:     	cmp	x25, x13
102a05f44:     	csel	x25, x25, x13, hi
102a05f48:     	b	0x102a05e20 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x165c>
102a05f4c:     	cbz	x9, 0x102a058e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1124>
102a05f50:     	neg	x10, x11
102a05f54:     	add	x10, x10, x10, lsl #1
102a05f58:     	lsl	x10, x10, #5
102a05f5c:     	add	x9, x9, x9, lsl #1
102a05f60:     	lsl	x9, x9, #5
102a05f64:     	b	0x102a05f74 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17b0>
102a05f68:     	add	x10, x10, #0x60
102a05f6c:     	subs	x9, x9, #0x60
102a05f70:     	b.eq	0x102a058e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1124>
102a05f74:     	add	x11, x26, x10
102a05f78:     	add	x11, x11, x8
102a05f7c:     	ldr	w12, [x11, #0x8]
102a05f80:     	cmp	w12, #0x2
102a05f84:     	b.ne	0x102a05f68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17a4>
102a05f88:     	ldr	x11, [x11, #0x20]
102a05f8c:     	cmp	x25, x11
102a05f90:     	csel	x25, x25, x11, hi
102a05f94:     	b	0x102a05f68 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x17a4>
102a05f98:     	ldr	x11, [sp, #0xb0]
102a05f9c:     	strb	wzr, [x11, #0x8]
102a05fa0:     	b	0x102a05fdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1818>
102a05fa4:     	mov	w8, #0x6                ; =6
102a05fa8:     	ldr	x11, [sp, #0xb0]
102a05fac:     	strb	w8, [x11, #0x8]
102a05fb0:     	adrp	x8, 0x1076e2000 <_anon.a462c1ba11c9eca9725757badbfdd934.323>
102a05fb4:     	add	x8, x8, #0x765
102a05fb8:     	mov	w9, #0x13               ; =19
102a05fbc:     	b	0x102a05fd8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1814>
102a05fc0:     	mov	w8, #0x6                ; =6
102a05fc4:     	ldr	x11, [sp, #0xb0]
102a05fc8:     	strb	w8, [x11, #0x8]
102a05fcc:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a05fd0:     	add	x8, x8, #0x32d
102a05fd4:     	mov	w9, #0x1a               ; =26
102a05fd8:     	stp	x8, x9, [x11, #0x10]
102a05fdc:     	mov	w8, #0x2                ; =2
102a05fe0:     	str	x8, [x11]
102a05fe4:     	add	x0, sp, #0xa08
102a05fe8:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a05fec:     	ldr	x8, [x19, #0x878]
102a05ff0:     	cbz	x8, 0x102a06008 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1844>
102a05ff4:     	lsl	x9, x8, #6
102a05ff8:     	sub	x1, x9, x8, lsl #3
102a05ffc:     	ldr	x0, [sp, #0x40]
102a06000:     	mov	w2, #0x8                ; =8
102a06004:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06008:     	add	x0, sp, #0x5e0
102a0600c:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a06010:     	mov	w25, #0x1               ; =1
102a06014:     	add	x0, sp, #0x5c8
102a06018:     	bl	0x1025ba820 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a0601c:     	mov	w25, #0x1               ; =1
102a06020:     	ldr	x8, [x19, #0x90]
102a06024:     	cmp	x8, #0x2
102a06028:     	b.eq	0x102a06034 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1870>
102a0602c:     	add	x0, sp, #0x1e0
102a06030:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a06034:     	ldr	x8, [x19, #0x78]
102a06038:     	cbz	x8, 0x102a06050 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x188c>
102a0603c:     	ldr	x0, [x19, #0x80]
102a06040:     	add	x8, x8, x8, lsl #1
102a06044:     	lsl	x1, x8, #2
102a06048:     	mov	w2, #0x4                ; =4
102a0604c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06050:     	ldr	x8, [x19, #0x18]
102a06054:     	cbz	x8, 0x102a0606c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x18a8>
102a06058:     	ldr	x0, [x19, #0x20]
102a0605c:     	add	x8, x8, x8, lsl #1
102a06060:     	lsl	x1, x8, #5
102a06064:     	mov	w2, #0x8                ; =8
102a06068:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a0606c:     	add	x0, sp, #0x150
102a06070:     	bl	0x1025b8b38 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06074:     	add	x0, sp, #0x138
102a06078:     	bl	0x1025b9228 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a0607c:     	add	x0, sp, #0x120
102a06080:     	bl	0x1025b8b38 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06084:     	add	x0, sp, #0x108
102a06088:     	ldr	x20, [sp, #0xc0]
102a0608c:     	bl	0x1025b9228 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06090:     	ldr	x8, [sp, #0xb8]
102a06094:     	cbz	x8, 0x102a060ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x18e8>
102a06098:     	add	x8, x8, x8, lsl #1
102a0609c:     	lsl	x1, x8, #2
102a060a0:     	mov	x0, x20
102a060a4:     	mov	w2, #0x4                ; =4
102a060a8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a060ac:     	tbz	w25, #0x0, 0x102a060d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x190c>
102a060b0:     	ldr	x8, [sp, #0xd8]
102a060b4:     	cbz	x8, 0x102a060d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x190c>
102a060b8:     	ldr	x20, [sp, #0xe0]
102a060bc:     	add	x8, x8, x8, lsl #1
102a060c0:     	lsl	x1, x8, #2
102a060c4:     	mov	x0, x20
102a060c8:     	mov	w2, #0x4                ; =4
102a060cc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a060d0:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
102a060d4:     	add	sp, sp, #0xc70
102a060d8:     	ldp	x29, x30, [sp, #0x50]
102a060dc:     	ldp	x20, x19, [sp, #0x40]
102a060e0:     	ldp	x22, x21, [sp, #0x30]
102a060e4:     	ldp	x24, x23, [sp, #0x20]
102a060e8:     	ldp	x26, x25, [sp, #0x10]
102a060ec:     	ldp	x28, x27, [sp], #0x60
102a060f0:     	ret
102a060f4:     	mov	w8, #0xa                ; =10
102a060f8:     	ldr	x11, [sp, #0xb0]
102a060fc:     	strb	w8, [x11, #0x8]
102a06100:     	stp	x0, x17, [x11, #0x10]
102a06104:     	b	0x102a05fdc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1818>
102a06108:     	cmp	x26, #0x15
102a0610c:     	b.hs	0x102a06518 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d54>
102a06110:     	mov	x8, #0x0                ; =0
102a06114:     	add	x9, x25, x26, lsl #2
102a06118:     	add	x10, x25, #0x4
102a0611c:     	b	0x102a06138 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1974>
102a06120:     	mov	x12, x25
102a06124:     	str	w11, [x12]
102a06128:     	add	x10, x10, #0x4
102a0612c:     	add	x8, x8, #0x4
102a06130:     	cmp	x10, x9
102a06134:     	b.eq	0x102a06250 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a8c>
102a06138:     	ldp	w12, w11, [x10, #-0x4]
102a0613c:     	cmp	w11, w12
102a06140:     	b.hs	0x102a06128 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1964>
102a06144:     	mov	x13, x8
102a06148:     	add	x14, x25, x13
102a0614c:     	str	w12, [x14, #0x4]
102a06150:     	cbz	x13, 0x102a06120 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x195c>
102a06154:     	ldur	w12, [x14, #-0x4]
102a06158:     	sub	x13, x13, #0x4
102a0615c:     	cmp	w11, w12
102a06160:     	b.lo	0x102a06148 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1984>
102a06164:     	add	x12, x25, x13
102a06168:     	add	x12, x12, #0x4
102a0616c:     	b	0x102a06124 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1960>
102a06170:     	cmp	x26, #0x15
102a06174:     	b.hs	0x102a0652c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d68>
102a06178:     	add	x19, x25, #0x8
102a0617c:     	lsl	x8, x26, #3
102a06180:     	sub	x8, x8, #0x8
102a06184:     	add	x27, sp, #0xdf0
102a06188:     	str	x8, [sp, #0xa8]
102a0618c:     	mov	x0, x25
102a06190:     	mov	x1, x19
102a06194:     	bl	0x102904454 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort11insert_tailNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYB18_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
102a06198:     	ldr	x8, [sp, #0xa8]
102a0619c:     	add	x19, x19, #0x8
102a061a0:     	subs	x8, x8, #0x8
102a061a4:     	b.ne	0x102a06188 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x19c4>
102a061a8:     	b	0x102a049bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f8>
102a061ac:     	cmp	x26, #0x15
102a061b0:     	b.hs	0x102a06544 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d80>
102a061b4:     	mov	x8, #0x0                ; =0
102a061b8:     	add	x9, x25, x26, lsl #2
102a061bc:     	add	x10, x25, #0x4
102a061c0:     	b	0x102a061dc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a18>
102a061c4:     	mov	x12, x25
102a061c8:     	str	w11, [x12]
102a061cc:     	add	x10, x10, #0x4
102a061d0:     	add	x8, x8, #0x4
102a061d4:     	cmp	x10, x9
102a061d8:     	b.eq	0x102a06264 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1aa0>
102a061dc:     	ldp	w12, w11, [x10, #-0x4]
102a061e0:     	cmp	w11, w12
102a061e4:     	b.hs	0x102a061cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a08>
102a061e8:     	mov	x13, x8
102a061ec:     	add	x14, x25, x13
102a061f0:     	str	w12, [x14, #0x4]
102a061f4:     	cbz	x13, 0x102a061c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a00>
102a061f8:     	ldur	w12, [x14, #-0x4]
102a061fc:     	sub	x13, x13, #0x4
102a06200:     	cmp	w11, w12
102a06204:     	b.lo	0x102a061ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a28>
102a06208:     	add	x12, x25, x13
102a0620c:     	add	x12, x12, #0x4
102a06210:     	b	0x102a061c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a04>
102a06214:     	cmp	x26, #0x15
102a06218:     	b.hs	0x102a06560 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d9c>
102a0621c:     	add	x9, x25, #0x8
102a06220:     	lsl	x8, x26, #3
102a06224:     	sub	x8, x8, #0x8
102a06228:     	add	x27, sp, #0xdf0
102a0622c:     	stp	x8, x9, [sp, #0xa0]
102a06230:     	mov	x0, x25
102a06234:     	mov	x1, x9
102a06238:     	bl	0x102904454 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort11insert_tailNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYB18_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
102a0623c:     	ldp	x8, x9, [sp, #0xa0]
102a06240:     	add	x9, x9, #0x8
102a06244:     	subs	x8, x8, #0x8
102a06248:     	b.ne	0x102a0622c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1a68>
102a0624c:     	b	0x102a04ae4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x320>
102a06250:     	add	x8, sp, #0xdf0
102a06254:     	ldr	x25, [x8, #0x418]
102a06258:     	add	x22, sp, #0xdf0
102a0625c:     	ldr	x26, [x8, #0x420]
102a06260:     	b	0x102a04914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x150>
102a06264:     	ldr	x25, [x19, #0x418]
102a06268:     	ldr	x26, [x19, #0x420]
102a0626c:     	b	0x102a04a4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x288>
102a06270:     	cmp	x1, #0x15
102a06274:     	b.hs	0x102a06578 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1db4>
102a06278:     	add	x25, x24, #0xc
102a0627c:     	mov	w8, #0xc                ; =12
102a06280:     	mov	x9, #-0xc               ; =-12
102a06284:     	madd	x23, x1, x8, x9
102a06288:     	mov	x0, x24
102a0628c:     	mov	x1, x25
102a06290:     	bl	0x1029045d4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort11insert_tailNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementNCINvMNtCsgKscDXrlV49_5alloc5sliceSB18_11sort_by_keyThmmENvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15transaction_keyE0EB3k_>
102a06294:     	add	x25, x25, #0xc
102a06298:     	subs	x23, x23, #0xc
102a0629c:     	b.ne	0x102a06288 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1ac4>
102a062a0:     	b	0x102a04ed4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x710>
102a062a4:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a062a8:     	add	x8, x8, #0x540
102a062ac:     	mov	w9, #0x10               ; =16
102a062b0:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a062b4:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a062b8:     	add	x8, x8, #0x550
102a062bc:     	mov	w9, #0x10               ; =16
102a062c0:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a062c4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a062c8:     	add	x8, x8, #0x39d
102a062cc:     	mov	w9, #0xf                ; =15
102a062d0:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a062d4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a062d8:     	add	x8, x8, #0x3ac
102a062dc:     	mov	w9, #0x16               ; =22
102a062e0:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a062e4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a062e8:     	add	x8, x8, #0x3c2
102a062ec:     	mov	w9, #0xc                ; =12
102a062f0:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a062f4:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a062f8:     	add	x8, x8, #0x3ce
102a062fc:     	mov	w9, #0xe                ; =14
102a06300:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a06304:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a06308:     	add	x8, x8, #0x3dc
102a0630c:     	mov	w9, #0xe                ; =14
102a06310:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a06314:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a06318:     	add	x8, x8, #0x3ea
102a0631c:     	mov	w9, #0xf                ; =15
102a06320:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a06324:     	adrp	x8, 0x1076e1000 <_anon.a3a88120a5ea3356e7e60940c4d40a5d.648+0x1>
102a06328:     	add	x8, x8, #0x560
102a0632c:     	mov	w9, #0x10               ; =16
102a06330:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a06334:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a06338:     	add	x8, x8, #0x3f9
102a0633c:     	mov	w9, #0xf                ; =15
102a06340:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a06344:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a06348:     	add	x8, x8, #0x408
102a0634c:     	mov	w9, #0xc                ; =12
102a06350:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a06354:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a06358:     	add	x8, x8, #0x414
102a0635c:     	mov	w9, #0x15               ; =21
102a06360:     	b	0x102a06370 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1bac>
102a06364:     	adrp	x8, 0x1076e3000 <_anon.a462c1ba11c9eca9725757badbfdd934.857+0x36>
102a06368:     	add	x8, x8, #0x429
102a0636c:     	mov	w9, #0x13               ; =19
102a06370:     	ldr	x11, [sp, #0xb0]
102a06374:     	mov	w10, #0x6               ; =6
102a06378:     	str	x10, [x11, #0x8]
102a0637c:     	b	0x102a05fd8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1814>
102a06380:     	add	x0, sp, #0x1c8
102a06384:     	mov	x2, x23
102a06388:     	mov	w3, #0x4                ; =4
102a0638c:     	mov	w4, #0xc                ; =12
102a06390:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a06394:     	ldp	x8, x1, [x19, #0x80]
102a06398:     	ldr	x27, [sp, #0xc8]
102a0639c:     	add	x25, sp, #0xa08
102a063a0:     	b	0x102a052dc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0xb18>
102a063a4:     	str	x10, [sp, #0x48]
102a063a8:     	str	x0, [sp, #0x18]
102a063ac:     	add	x0, sp, #0xe20
102a063b0:     	mov	x1, x23
102a063b4:     	mov	x2, x24
102a063b8:     	mov	w3, #0x8                ; =8
102a063bc:     	mov	w4, #0x20               ; =32
102a063c0:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a063c4:     	add	x8, sp, #0xdf0
102a063c8:     	ldr	x23, [x8, #0x40]
102a063cc:     	b	0x102a059d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x120c>
102a063d0:     	ldr	x8, [sp, #0x48]
102a063d4:     	cmp	x8, #0x15
102a063d8:     	b.hs	0x102a06590 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1dcc>
102a063dc:     	sub	x3, x29, #0x61
102a063e0:     	ldr	x23, [sp, #0x18]
102a063e4:     	mov	x0, x23
102a063e8:     	ldr	x1, [sp, #0x48]
102a063ec:     	mov	w2, #0x1                ; =1
102a063f0:     	bl	0x1029085e0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYB1m_NtNtBa_3cmp10PartialOrd2ltECs1qJAwyMG1lC_11mech_engine>
102a063f4:     	mov	x26, #0x0               ; =0
102a063f8:     	add	x23, x23, #0x40
102a063fc:     	ldr	x8, [sp, #0x48]
102a06400:     	sub	x24, x8, #0x1
102a06404:     	b	0x102a06418 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1c54>
102a06408:     	add	x23, x23, #0x20
102a0640c:     	add	x26, x26, #0x1
102a06410:     	cmp	x24, x26
102a06414:     	b.eq	0x102a05a24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1260>
102a06418:     	ldur	x8, [x23, #-0x18]
102a0641c:     	ldur	x9, [x23, #-0x38]
102a06420:     	cmp	x8, x9
102a06424:     	b.ne	0x102a06408 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1c44>
102a06428:     	ldur	x8, [x23, #-0x10]
102a0642c:     	ldur	x9, [x23, #-0x30]
102a06430:     	cmp	x8, x9
102a06434:     	b.ne	0x102a06408 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1c44>
102a06438:     	sub	x0, x23, #0x20
102a0643c:     	sub	x1, x23, #0x40
102a06440:     	bl	0x1027cc294 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
102a06444:     	cbz	w0, 0x102a06408 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1c44>
102a06448:     	ldurb	w8, [x23, #-0x8]
102a0644c:     	ldurb	w9, [x23, #-0x28]
102a06450:     	cmp	w8, w9
102a06454:     	b.ne	0x102a06408 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1c44>
102a06458:     	add	x8, x26, #0x2
102a0645c:     	add	x27, x26, #0x1
102a06460:     	ldr	x9, [sp, #0x48]
102a06464:     	cmp	x8, x9
102a06468:     	b.hs	0x102a064d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d14>
102a0646c:     	ldr	x8, [sp, #0x48]
102a06470:     	sub	x8, x8, x26
102a06474:     	sub	x26, x8, #0x2
102a06478:     	ldr	x8, [sp, #0x18]
102a0647c:     	add	x24, x8, x27, lsl #5
102a06480:     	ldr	x8, [x23, #0x8]
102a06484:     	ldur	x9, [x24, #-0x18]
102a06488:     	cmp	x8, x9
102a0648c:     	b.ne	0x102a064c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1cfc>
102a06490:     	ldr	x8, [x23, #0x10]
102a06494:     	ldur	x9, [x24, #-0x10]
102a06498:     	cmp	x8, x9
102a0649c:     	b.ne	0x102a064c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1cfc>
102a064a0:     	sub	x1, x24, #0x20
102a064a4:     	mov	x0, x23
102a064a8:     	bl	0x1027cc294 <__RNvXs3m_NtNtCskIfnrfrMWVM_9mech_core11memory_plan5modelNtB6_17MemoryObjectOwnerNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
102a064ac:     	cbz	w0, 0x102a064c0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1cfc>
102a064b0:     	ldrb	w8, [x23, #0x18]
102a064b4:     	ldurb	w9, [x24, #-0x8]
102a064b8:     	cmp	w8, w9
102a064bc:     	b.eq	0x102a064cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d08>
102a064c0:     	ldp	q0, q1, [x23]
102a064c4:     	stp	q0, q1, [x24]
102a064c8:     	add	x27, x27, #0x1
102a064cc:     	add	x23, x23, #0x20
102a064d0:     	subs	x26, x26, #0x1
102a064d4:     	b.ne	0x102a06478 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1cb4>
102a064d8:     	add	x8, sp, #0xdf0
102a064dc:     	str	x27, [x8, #0x40]
102a064e0:     	str	x27, [sp, #0x48]
102a064e4:     	b	0x102a05a24 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1260>
102a064e8:     	adrp	x0, 0x10803a000 <_anon.ca450c5141039434e7dc58a745d07839.2+0x20>
102a064ec:     	add	x0, x0, #0xcf0
102a064f0:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
102a064f4:     	b	0x102a06514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d50>
102a064f8:     	adrp	x0, 0x10803a000 <_anon.ca450c5141039434e7dc58a745d07839.2+0x20>
102a064fc:     	add	x0, x0, #0xcf0
102a06500:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
102a06504:     	b	0x102a06514 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1d50>
102a06508:     	adrp	x0, 0x10803a000 <_anon.ca450c5141039434e7dc58a745d07839.2+0x20>
102a0650c:     	add	x0, x0, #0xcf0
102a06510:     	bl	0x103a06678 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
102a06514:     	brk	#0x1
102a06518:     	sub	x2, x29, #0x61
102a0651c:     	mov	x0, x25
102a06520:     	mov	x1, x26
102a06524:     	bl	0x102785450 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
102a06528:     	b	0x102a04914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x150>
102a0652c:     	sub	x2, x29, #0x61
102a06530:     	mov	x0, x25
102a06534:     	mov	x1, x26
102a06538:     	add	x27, sp, #0xdf0
102a0653c:     	bl	0x102785574 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
102a06540:     	b	0x102a049bc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f8>
102a06544:     	add	x19, sp, #0xdf0
102a06548:     	sub	x2, x29, #0x61
102a0654c:     	mov	x0, x25
102a06550:     	mov	x1, x26
102a06554:     	bl	0x102785450 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
102a06558:     	add	x19, sp, #0xdf0
102a0655c:     	b	0x102a04a4c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x288>
102a06560:     	sub	x2, x29, #0x61
102a06564:     	mov	x0, x25
102a06568:     	mov	x1, x26
102a0656c:     	add	x27, sp, #0xdf0
102a06570:     	bl	0x102785574 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EECs1qJAwyMG1lC_11mech_engine>
102a06574:     	b	0x102a04ae4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x320>
102a06578:     	mov	w25, #0x0               ; =0
102a0657c:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
102a06580:     	add	x2, x2, #0x600
102a06584:     	mov	x0, x24
102a06588:     	bl	0x102785698 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementNCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_11sort_by_keyThmmENvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15transaction_keyE0INtNtB2i_3vec3VecBZ_EEB3a_>
102a0658c:     	b	0x102a04ed4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x710>
102a06590:     	sub	x2, x29, #0x61
102a06594:     	ldr	x23, [sp, #0x18]
102a06598:     	mov	x0, x23
102a0659c:     	ldr	x1, [sp, #0x48]
102a065a0:     	bl	0x102dc92cc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationNvYBZ_NtNtB8_3cmp10PartialOrd2ltINtNtCsgKscDXrlV49_5alloc3vec3VecBZ_EEB15_>
102a065a4:     	b	0x102a063f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1c30>
102a065a8:     	mov	x20, x0
102a065ac:     	ldr	x8, [x27, #0x410]
102a065b0:     	cbz	x8, 0x102a065c4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1e00>
102a065b4:     	lsl	x1, x8, #3
102a065b8:     	mov	x0, x25
102a065bc:     	mov	w2, #0x4                ; =4
102a065c0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a065c4:     	mov	w25, #0x1               ; =1
102a065c8:     	b	0x102a0691c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2158>
102a065cc:     	mov	x20, x0
102a065d0:     	ldr	x8, [x19, #0x410]
102a065d4:     	cbz	x8, 0x102a065e8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1e24>
102a065d8:     	lsl	x1, x8, #2
102a065dc:     	mov	x0, x25
102a065e0:     	mov	w2, #0x4                ; =4
102a065e4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a065e8:     	mov	w25, #0x1               ; =1
102a065ec:     	b	0x102a06924 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2160>
102a065f0:     	mov	x20, x0
102a065f4:     	ldr	x8, [x27, #0x410]
102a065f8:     	cbz	x8, 0x102a0660c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1e48>
102a065fc:     	lsl	x1, x8, #3
102a06600:     	mov	x0, x25
102a06604:     	mov	w2, #0x4                ; =4
102a06608:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a0660c:     	mov	w25, #0x1               ; =1
102a06610:     	b	0x102a0692c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2168>
102a06614:     	mov	x20, x0
102a06618:     	ldr	x8, [x22, #0x410]
102a0661c:     	cbnz	x8, 0x102a06628 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1e64>
102a06620:     	mov	w25, #0x1               ; =1
102a06624:     	b	0x102a06934 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2170>
102a06628:     	lsl	x1, x8, #2
102a0662c:     	mov	x0, x25
102a06630:     	mov	w2, #0x4                ; =4
102a06634:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06638:     	mov	w25, #0x1               ; =1
102a0663c:     	b	0x102a06934 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2170>
102a06640:     	mov	x20, x0
102a06644:     	ldr	x0, [sp, #0x18]
102a06648:     	ldr	x1, [sp, #0x48]
102a0664c:     	mov	w2, #0x8                ; =8
102a06650:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06654:     	b	0x102a06870 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20ac>
102a06658:     	mov	x20, x0
102a0665c:     	add	x0, sp, #0xa08
102a06660:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a06664:     	b	0x102a067d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2010>
102a06668:     	mov	x20, x0
102a0666c:     	cbnz	x23, 0x102a06678 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1eb4>
102a06670:     	mov	w25, #0x0               ; =0
102a06674:     	b	0x102a068b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20ec>
102a06678:     	add	x8, x23, x23, lsl #1
102a0667c:     	lsl	x1, x8, #2
102a06680:     	mov	x0, x25
102a06684:     	mov	w2, #0x4                ; =4
102a06688:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a0668c:     	mov	w25, #0x0               ; =0
102a06690:     	b	0x102a068b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20ec>
102a06694:     	b	0x102a067d0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x200c>
102a06698:     	mov	x20, x0
102a0669c:     	ldr	x0, [sp, #0x18]
102a066a0:     	mov	x1, x24
102a066a4:     	mov	w2, #0x8                ; =8
102a066a8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a066ac:     	cbnz	x26, 0x102a066b8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1ef4>
102a066b0:     	mov	w21, #0x0               ; =0
102a066b4:     	b	0x102a066ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f28>
102a066b8:     	add	x8, x26, x26, lsl #1
102a066bc:     	lsl	x1, x8, #2
102a066c0:     	mov	x0, x27
102a066c4:     	mov	w2, #0x4                ; =4
102a066c8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a066cc:     	mov	w21, #0x0               ; =0
102a066d0:     	b	0x102a066ec <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f28>
102a066d4:     	mov	x20, x0
102a066d8:     	mov	x0, x23
102a066dc:     	mov	x1, x24
102a066e0:     	mov	w2, #0x4                ; =4
102a066e4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a066e8:     	mov	w21, #0x1               ; =1
102a066ec:     	add	x0, sp, #0xa08
102a066f0:     	bl	0x1029cc4e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
102a066f4:     	ldr	x8, [sp, #0xc8]
102a066f8:     	cbnz	x8, 0x102a06704 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f40>
102a066fc:     	mov	w22, #0x0               ; =0
102a06700:     	b	0x102a06740 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f7c>
102a06704:     	ldr	x8, [sp, #0xc8]
102a06708:     	add	x8, x8, x8, lsl #1
102a0670c:     	lsl	x1, x8, #5
102a06710:     	ldr	x0, [sp, #0x10]
102a06714:     	mov	w2, #0x8                ; =8
102a06718:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a0671c:     	mov	w22, #0x0               ; =0
102a06720:     	b	0x102a06740 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f7c>
102a06724:     	mov	x20, x0
102a06728:     	mov	x0, x22
102a0672c:     	mov	x1, x24
102a06730:     	mov	w2, #0x8                ; =8
102a06734:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06738:     	mov	w21, #0x1               ; =1
102a0673c:     	mov	w22, #0x1               ; =1
102a06740:     	ldr	x8, [sp, #0x8]
102a06744:     	cmp	x8, #0x2
102a06748:     	b.eq	0x102a06754 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1f90>
102a0674c:     	add	x0, sp, #0x1e0
102a06750:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a06754:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a06758:     	add	x0, x0, #0x200
102a0675c:     	bl	0x1029cf3bc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn15TurnMemoryFactsEBM_>
102a06760:     	tbz	w21, #0x0, 0x102a0676c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1fa8>
102a06764:     	mov	w21, #0x0               ; =0
102a06768:     	b	0x102a06878 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20b4>
102a0676c:     	cbz	w22, 0x102a06788 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1fc4>
102a06770:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a06774:     	add	x0, x0, #0xbb0
102a06778:     	bl	0x1029cc4e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
102a0677c:     	mov	w21, #0x0               ; =0
102a06780:     	mov	w25, #0x0               ; =0
102a06784:     	b	0x102a068d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2114>
102a06788:     	mov	w25, #0x0               ; =0
102a0678c:     	b	0x102a06914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2150>
102a06790:     	mov	x20, x0
102a06794:     	mov	x0, x21
102a06798:     	mov	x1, x25
102a0679c:     	mov	w2, #0x8                ; =8
102a067a0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a067a4:     	b	0x102a067ac <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x1fe8>
102a067a8:     	mov	x20, x0
102a067ac:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a067b0:     	add	x0, x0, #0xbb0
102a067b4:     	bl	0x1029cc4e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
102a067b8:     	mov	w25, #0x0               ; =0
102a067bc:     	b	0x102a068b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20ec>
102a067c0:     	mov	x20, x0
102a067c4:     	b	0x102a068cc <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2108>
102a067c8:     	mov	x20, x0
102a067cc:     	b	0x102a067f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x202c>
102a067d0:     	mov	x20, x0
102a067d4:     	ldr	x8, [x19, #0x878]
102a067d8:     	cbz	x8, 0x102a067f0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x202c>
102a067dc:     	lsl	x9, x8, #6
102a067e0:     	sub	x1, x9, x8, lsl #3
102a067e4:     	ldr	x0, [sp, #0x40]
102a067e8:     	mov	w2, #0x8                ; =8
102a067ec:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a067f0:     	add	x0, sp, #0x5e0
102a067f4:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a067f8:     	b	0x102a0680c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2048>
102a067fc:     	mov	x20, x0
102a06800:     	mov	w25, #0x1               ; =1
102a06804:     	b	0x102a06914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2150>
102a06808:     	mov	x20, x0
102a0680c:     	add	x0, sp, #0x5c8
102a06810:     	bl	0x1025ba820 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1b_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06814:     	mov	w22, #0x1               ; =1
102a06818:     	mov	w25, #0x1               ; =1
102a0681c:     	b	0x102a068b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20f0>
102a06820:     	mov	x20, x0
102a06824:     	b	0x102a068b0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20ec>
102a06828:     	mov	x20, x0
102a0682c:     	b	0x102a0691c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2158>
102a06830:     	mov	x20, x0
102a06834:     	b	0x102a06924 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2160>
102a06838:     	mov	x20, x0
102a0683c:     	b	0x102a0692c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2168>
102a06840:     	mov	x20, x0
102a06844:     	b	0x102a06934 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2170>
102a06848:     	mov	x20, x0
102a0684c:     	add	x0, sp, #0xa08
102a06850:     	bl	0x1025b9da0 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model22CurrentMemoryFootprintENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06854:     	b	0x102a0685c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2098>
102a06858:     	mov	x20, x0
102a0685c:     	add	x0, sp, #0x5e0
102a06860:     	bl	0x1025ba670 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdtENtNtNtB19_11memory_plan5model16RegionAccessPlanENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06864:     	b	0x102a06870 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20ac>
102a06868:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102a0686c:     	mov	x20, x0
102a06870:     	mov	w21, #0x1               ; =1
102a06874:     	mov	w22, #0x1               ; =1
102a06878:     	add	x8, sp, #0xdf0
102a0687c:     	ldr	x8, [x8, #0x30]
102a06880:     	cbz	x8, 0x102a06898 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20d4>
102a06884:     	add	x9, sp, #0xdf0
102a06888:     	ldr	x0, [x9, #0x38]
102a0688c:     	lsl	x1, x8, #5
102a06890:     	mov	w2, #0x8                ; =8
102a06894:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06898:     	tbz	w22, #0x0, 0x102a0695c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2198>
102a0689c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
102a068a0:     	add	x0, x0, #0xbb0
102a068a4:     	bl	0x1029cc4e8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc5boxed3BoxSNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model9ArenaPlanEECs1qJAwyMG1lC_11mech_engine>
102a068a8:     	mov	w25, #0x0               ; =0
102a068ac:     	tbz	w21, #0x0, 0x102a068d4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2110>
102a068b0:     	mov	w22, #0x1               ; =1
102a068b4:     	ldr	x8, [x19, #0x90]
102a068b8:     	cmp	x8, #0x2
102a068bc:     	b.eq	0x102a068c8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2104>
102a068c0:     	add	x0, sp, #0x1e0
102a068c4:     	bl	0x1029d2470 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14CallMemoryPlanECs1qJAwyMG1lC_11mech_engine>
102a068c8:     	cbz	w22, 0x102a068f8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2134>
102a068cc:     	mov	w21, #0x1               ; =1
102a068d0:     	b	0x102a068d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2114>
102a068d4:     	mov	x21, x25
102a068d8:     	ldr	x8, [x19, #0x78]
102a068dc:     	cbz	x8, 0x102a068f4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2130>
102a068e0:     	ldr	x0, [x19, #0x80]
102a068e4:     	add	x8, x8, x8, lsl #1
102a068e8:     	lsl	x1, x8, #2
102a068ec:     	mov	w2, #0x4                ; =4
102a068f0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a068f4:     	tbz	w21, #0x0, 0x102a06914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2150>
102a068f8:     	ldr	x8, [x19, #0x18]
102a068fc:     	cbz	x8, 0x102a06914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2150>
102a06900:     	ldr	x0, [x19, #0x20]
102a06904:     	add	x8, x8, x8, lsl #1
102a06908:     	lsl	x1, x8, #5
102a0690c:     	mov	w2, #0x8                ; =8
102a06910:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06914:     	add	x0, sp, #0x150
102a06918:     	bl	0x1025b8b38 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a0691c:     	add	x0, sp, #0x138
102a06920:     	bl	0x1025b9228 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06924:     	add	x0, sp, #0x120
102a06928:     	bl	0x1025b8b38 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapyNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a0692c:     	add	x0, sp, #0x108
102a06930:     	bl	0x1025b9228 <__RNvXNtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdNtNtB4_7set_val9SetValZSTENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropCs1qJAwyMG1lC_11mech_engine>
102a06934:     	ldr	x8, [sp, #0xb8]
102a06938:     	cbz	x8, 0x102a06950 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x218c>
102a0693c:     	ldp	x8, x0, [sp, #0xb8]
102a06940:     	add	x8, x8, x8, lsl #1
102a06944:     	lsl	x1, x8, #2
102a06948:     	mov	w2, #0x4                ; =4
102a0694c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06950:     	mov	x0, x20
102a06954:     	tbnz	w25, #0x0, 0x102a06970 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x21ac>
102a06958:     	b	0x102a06978 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x21b4>
102a0695c:     	mov	w25, #0x0               ; =0
102a06960:     	mov	w22, #0x0               ; =0
102a06964:     	tbnz	w21, #0x0, 0x102a068b4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x20f0>
102a06968:     	b	0x102a06914 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x2150>
102a0696c:     	bl	0x103a066fc <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102a06970:     	ldr	x9, [sp, #0xd8]
102a06974:     	cbnz	x9, 0x102a0697c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memory+0x21b8>
102a06978:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
102a0697c:     	ldr	x8, [sp, #0xe0]
102a06980:     	add	x9, x9, x9, lsl #1
102a06984:     	lsl	x1, x9, #2
102a06988:     	mov	x19, x0
102a0698c:     	mov	x0, x8
102a06990:     	mov	w2, #0x4                ; =4
102a06994:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a06998:     	mov	x0, x19
102a0699c:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
