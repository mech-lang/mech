
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001028147d0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_>:
1028147d0:     	sub	sp, sp, #0x50
1028147d4:     	stp	x22, x21, [sp, #0x20]
1028147d8:     	stp	x20, x19, [sp, #0x30]
1028147dc:     	stp	x29, x30, [sp, #0x40]
1028147e0:     	add	x29, sp, #0x40
1028147e4:     	ldr	x20, [x0]
1028147e8:     	ldr	x19, [x1]
1028147ec:     	mov	x21, x19
1028147f0:     	ldrb	w8, [x19, #0x10]!
1028147f4:     	sub	w8, w8, #0x2
1028147f8:     	cmp	w8, #0x3
1028147fc:     	b.hi	0x10281482c <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x5c>
102814800:     	ldr	w8, [x21, #0x14]
102814804:     	ldr	x9, [x20]
102814808:     	ldr	w9, [x9]
10281480c:     	cmp	w8, w9
102814810:     	b.ne	0x10281482c <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x5c>
102814814:     	mov	w0, #0x1                ; =1
102814818:     	ldp	x29, x30, [sp, #0x40]
10281481c:     	ldp	x20, x19, [sp, #0x30]
102814820:     	ldp	x22, x21, [sp, #0x20]
102814824:     	add	sp, sp, #0x50
102814828:     	ret
10281482c:     	ldr	x9, [x20, #0x8]
102814830:     	ldr	x8, [x9]
102814834:     	cbz	x8, 0x102814898 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xc8>
102814838:     	ldr	x9, [x9, #0x8]
10281483c:     	ldr	w10, [x21, #0x50]
102814840:     	add	x12, x8, #0x8
102814844:     	ldrh	w13, [x8, #0x36]
102814848:     	lsl	x14, x13, #2
10281484c:     	mov	x11, #-0x1              ; =-1
102814850:     	cbz	x14, 0x102814880 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xb0>
102814854:     	ldr	w15, [x12], #0x4
102814858:     	cmp	w10, w15
10281485c:     	cset	w15, hi
102814860:     	csinv	w15, w15, wzr, hs
102814864:     	add	x11, x11, #0x1
102814868:     	sub	x14, x14, #0x4
10281486c:     	and	w15, w15, #0xff
102814870:     	cmp	w15, #0x1
102814874:     	b.eq	0x102814850 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x80>
102814878:     	cbz	w15, 0x102814814 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x44>
10281487c:     	b	0x102814884 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xb4>
102814880:     	mov	x11, x13
102814884:     	cbz	x9, 0x102814898 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xc8>
102814888:     	add	x8, x8, x11, lsl #3
10281488c:     	ldr	x8, [x8, #0x38]
102814890:     	sub	x9, x9, #0x1
102814894:     	b	0x102814840 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x70>
102814898:     	ldrb	w8, [x21, #0x58]
10281489c:     	cmp	w8, #0x1
1028148a0:     	b.ne	0x1028148cc <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xfc>
1028148a4:     	ldr	x8, [x20, #0x10]
1028148a8:     	ldr	x0, [x8]
1028148ac:     	cbz	x0, 0x1028148cc <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0xfc>
1028148b0:     	ldr	x1, [x8, #0x8]
1028148b4:     	mov	x8, sp
1028148b8:     	mov	x2, x19
1028148bc:     	bl	0x102505820 <__RINvMs_NtNtNtCsgKscDXrlV49_5alloc11collections5btree6searchINtNtB7_4node7NodeRefNtNtBY_6marker5ImmutNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB7_7set_val9SetValZSTNtB1i_14LeafOrInternalE11search_treeB1A_ECs1qJAwyMG1lC_11mech_engine>
1028148c0:     	ldr	x8, [sp]
1028148c4:     	cmp	x8, #0x1
1028148c8:     	b.ne	0x102814814 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x44>
1028148cc:     	ldr	x9, [x20, #0x18]
1028148d0:     	ldr	x8, [x9]
1028148d4:     	cbz	x8, 0x102814938 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x168>
1028148d8:     	ldr	x9, [x9, #0x8]
1028148dc:     	ldr	w10, [x21, #0x50]
1028148e0:     	add	x12, x8, #0x8
1028148e4:     	ldrh	w13, [x8, #0x36]
1028148e8:     	lsl	x14, x13, #2
1028148ec:     	mov	x11, #-0x1              ; =-1
1028148f0:     	cbz	x14, 0x102814920 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x150>
1028148f4:     	ldr	w15, [x12], #0x4
1028148f8:     	cmp	w10, w15
1028148fc:     	cset	w15, hi
102814900:     	csinv	w15, w15, wzr, hs
102814904:     	add	x11, x11, #0x1
102814908:     	sub	x14, x14, #0x4
10281490c:     	and	w15, w15, #0xff
102814910:     	cmp	w15, #0x1
102814914:     	b.eq	0x1028148f0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x120>
102814918:     	cbz	w15, 0x102814814 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x44>
10281491c:     	b	0x102814924 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x154>
102814920:     	mov	x11, x13
102814924:     	cbz	x9, 0x102814938 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x168>
102814928:     	add	x8, x8, x11, lsl #3
10281492c:     	ldr	x8, [x8, #0x38]
102814930:     	sub	x9, x9, #0x1
102814934:     	b	0x1028148e0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x110>
102814938:     	ldrb	w8, [x21, #0x58]
10281493c:     	cmp	w8, #0x6
102814940:     	b.ne	0x10281496c <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x19c>
102814944:     	ldr	x8, [x20, #0x20]
102814948:     	ldr	x0, [x8]
10281494c:     	cbz	x0, 0x102814818 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x48>
102814950:     	ldr	x1, [x8, #0x8]
102814954:     	mov	x8, sp
102814958:     	mov	x2, x19
10281495c:     	bl	0x102505820 <__RINvMs_NtNtNtCsgKscDXrlV49_5alloc11collections5btree6searchINtNtB7_4node7NodeRefNtNtBY_6marker5ImmutNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerNtNtB7_7set_val9SetValZSTNtB1i_14LeafOrInternalE11search_treeB1A_ECs1qJAwyMG1lC_11mech_engine>
102814960:     	ldr	w8, [sp]
102814964:     	eor	w0, w8, #0x1
102814968:     	b	0x102814818 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x48>
10281496c:     	mov	w0, #0x0                ; =0
102814970:     	b	0x102814818 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_+0x48>
