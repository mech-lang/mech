
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a2cda8 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0EE9from_iterB48_>:
102a2cda8:     	sub	sp, sp, #0x70
102a2cdac:     	stp	x24, x23, [sp, #0x30]
102a2cdb0:     	stp	x22, x21, [sp, #0x40]
102a2cdb4:     	stp	x20, x19, [sp, #0x50]
102a2cdb8:     	stp	x29, x30, [sp, #0x60]
102a2cdbc:     	add	x29, sp, #0x60
102a2cdc0:     	mov	x19, x8
102a2cdc4:     	mov	x21, #0x0               ; =0
102a2cdc8:     	ldp	x8, x9, [x0, #0x18]
102a2cdcc:     	subs	x8, x9, x8
102a2cdd0:     	csel	x22, xzr, x8, lo
102a2cdd4:     	lsl	x8, x22, #6
102a2cdd8:     	sub	x20, x8, x22, lsl #3
102a2cddc:     	mov	x8, #0x9249             ; =37449
102a2cde0:     	movk	x8, #0x4924, lsl #16
102a2cde4:     	movk	x8, #0x2492, lsl #32
102a2cde8:     	movk	x8, #0x249, lsl #48
102a2cdec:     	cmp	x22, x8
102a2cdf0:     	b.ls	0x102a2ce00 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0EE9from_iterB48_+0x58>
102a2cdf4:     	mov	x0, x21
102a2cdf8:     	mov	x1, x20
102a2cdfc:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a2ce00:     	cbz	x20, 0x102a2ce2c <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0EE9from_iterB48_+0x84>
102a2ce04:     	mov	x23, x0
102a2ce08:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a2ce0c:     	mov	w21, #0x8               ; =8
102a2ce10:     	mov	x0, x20
102a2ce14:     	mov	w1, #0x8                ; =8
102a2ce18:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a2ce1c:     	mov	x8, x0
102a2ce20:     	cbz	x0, 0x102a2cdf4 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0EE9from_iterB48_+0x4c>
102a2ce24:     	mov	x0, x23
102a2ce28:     	b	0x102a2ce34 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0EE9from_iterB48_+0x8c>
102a2ce2c:     	mov	x22, #0x0               ; =0
102a2ce30:     	mov	w8, #0x8                ; =8
102a2ce34:     	stp	x22, x8, [sp]
102a2ce38:     	mov	x9, sp
102a2ce3c:     	add	x9, x9, #0x10
102a2ce40:     	stp	xzr, x9, [sp, #0x10]
102a2ce44:     	stp	xzr, x8, [sp, #0x20]
102a2ce48:     	add	x1, sp, #0x18
102a2ce4c:     	bl	0x102a5b7bc <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2G_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB53_3VecB3J_E14extend_trustedBN_E0E0EB1x_>
102a2ce50:     	ldr	q0, [sp]
102a2ce54:     	str	q0, [x19]
102a2ce58:     	ldr	x8, [sp, #0x10]
102a2ce5c:     	str	x8, [x19, #0x10]
102a2ce60:     	ldp	x29, x30, [sp, #0x60]
102a2ce64:     	ldp	x20, x19, [sp, #0x50]
102a2ce68:     	ldp	x22, x21, [sp, #0x40]
102a2ce6c:     	ldp	x24, x23, [sp, #0x30]
102a2ce70:     	add	sp, sp, #0x70
102a2ce74:     	ret
102a2ce78:     	mov	x19, x0
102a2ce7c:     	ldr	x8, [sp]
102a2ce80:     	cbz	x8, 0x102a2ce98 <__RNvXs_NtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintEINtB4_18SpecFromIterNestedB13_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB2S_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorysa_0EE9from_iterB48_+0xf0>
102a2ce84:     	ldr	x0, [sp, #0x8]
102a2ce88:     	lsl	x9, x8, #6
102a2ce8c:     	sub	x1, x9, x8, lsl #3
102a2ce90:     	mov	w2, #0x8                ; =8
102a2ce94:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a2ce98:     	mov	x0, x19
102a2ce9c:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
