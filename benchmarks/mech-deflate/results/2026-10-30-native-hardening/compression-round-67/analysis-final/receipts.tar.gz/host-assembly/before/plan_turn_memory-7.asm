
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001028f4ac4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_>:
1028f4ac4:     	sub	sp, sp, #0x70
1028f4ac8:     	stp	x22, x21, [sp, #0x40]
1028f4acc:     	stp	x20, x19, [sp, #0x50]
1028f4ad0:     	stp	x29, x30, [sp, #0x60]
1028f4ad4:     	add	x29, sp, #0x60
1028f4ad8:     	cmp	x1, #0x2
1028f4adc:     	b.lo	0x1028f518c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6c8>
1028f4ae0:     	add	x8, x1, #0x10
1028f4ae4:     	cmp	x3, x8
1028f4ae8:     	b.lo	0x1028f51a4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6e0>
1028f4aec:     	mov	x19, x2
1028f4af0:     	mov	x20, x0
1028f4af4:     	lsr	x8, x1, #1
1028f4af8:     	lsl	x9, x8, #6
1028f4afc:     	cmp	x1, #0x7
1028f4b00:     	b.ls	0x1028f4e08 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x344>
1028f4b04:     	ldrb	w11, [x20, #0xc0]
1028f4b08:     	ldrh	w10, [x20, #0xc2]
1028f4b0c:     	ldrb	w12, [x20, #0x80]
1028f4b10:     	ldrh	w13, [x20, #0x82]
1028f4b14:     	cmp	w10, w13
1028f4b18:     	cset	w13, lo
1028f4b1c:     	subs	w14, w11, w12
1028f4b20:     	mov	w10, #0xff              ; =255
1028f4b24:     	bics	wzr, w10, w14
1028f4b28:     	cset	w14, eq
1028f4b2c:     	ldrb	w15, [x20, #0x40]
1028f4b30:     	ldrh	w16, [x20, #0x42]
1028f4b34:     	ldrb	w17, [x20]
1028f4b38:     	ldrh	w0, [x20, #0x2]
1028f4b3c:     	cmp	w11, w12
1028f4b40:     	csel	w11, w13, w14, eq
1028f4b44:     	cmp	w16, w0
1028f4b48:     	cset	w12, lo
1028f4b4c:     	subs	w13, w15, w17
1028f4b50:     	bics	wzr, w10, w13
1028f4b54:     	cset	w13, eq
1028f4b58:     	cmp	w15, w17
1028f4b5c:     	csel	w14, w12, w13, eq
1028f4b60:     	eor	w12, w14, #0x1
1028f4b64:     	add	x15, x20, x12, lsl #6
1028f4b68:     	cmp	w11, #0x0
1028f4b6c:     	mov	w12, #0x80              ; =128
1028f4b70:     	mov	w13, #0xc0              ; =192
1028f4b74:     	csel	x11, x13, x12, ne
1028f4b78:     	csel	x16, x12, x13, ne
1028f4b7c:     	add	x16, x20, x16
1028f4b80:     	ldrb	w17, [x16]
1028f4b84:     	ldrh	w0, [x16, #0x2]
1028f4b88:     	ldrb	w2, [x15]
1028f4b8c:     	ldrh	w3, [x15, #0x2]
1028f4b90:     	cmp	w0, w3
1028f4b94:     	cset	w0, lo
1028f4b98:     	subs	w3, w17, w2
1028f4b9c:     	bics	wzr, w10, w3
1028f4ba0:     	cset	w3, eq
1028f4ba4:     	add	x14, x20, x14, lsl #6
1028f4ba8:     	add	x11, x20, x11
1028f4bac:     	ldrb	w4, [x11]
1028f4bb0:     	ldrh	w5, [x11, #0x2]
1028f4bb4:     	ldrb	w6, [x14]
1028f4bb8:     	ldrh	w7, [x14, #0x2]
1028f4bbc:     	cmp	w17, w2
1028f4bc0:     	csel	w17, w0, w3, eq
1028f4bc4:     	cmp	w5, w7
1028f4bc8:     	cset	w0, lo
1028f4bcc:     	subs	w2, w4, w6
1028f4bd0:     	bics	wzr, w10, w2
1028f4bd4:     	cset	w2, eq
1028f4bd8:     	cmp	w4, w6
1028f4bdc:     	csel	w0, w0, w2, eq
1028f4be0:     	cmp	w17, #0x0
1028f4be4:     	csel	x2, x11, x15, ne
1028f4be8:     	cmp	w0, #0x0
1028f4bec:     	csel	x0, x11, x14, ne
1028f4bf0:     	csel	x14, x14, x2, ne
1028f4bf4:     	csel	x2, x15, x11, ne
1028f4bf8:     	cmp	w17, #0x0
1028f4bfc:     	csel	x11, x15, x16, ne
1028f4c00:     	csel	x15, x16, x2, ne
1028f4c04:     	ldrb	w16, [x15]
1028f4c08:     	ldrh	w17, [x15, #0x2]
1028f4c0c:     	ldrb	w2, [x14]
1028f4c10:     	ldrh	w3, [x14, #0x2]
1028f4c14:     	cmp	w17, w3
1028f4c18:     	cset	w17, lo
1028f4c1c:     	subs	w3, w16, w2
1028f4c20:     	bics	wzr, w10, w3
1028f4c24:     	cset	w3, eq
1028f4c28:     	cmp	w16, w2
1028f4c2c:     	csel	w16, w17, w3, eq
1028f4c30:     	cmp	w16, #0x0
1028f4c34:     	csel	x16, x15, x14, ne
1028f4c38:     	csel	x14, x14, x15, ne
1028f4c3c:     	ldp	q0, q1, [x0]
1028f4c40:     	stp	q0, q1, [x19]
1028f4c44:     	ldp	q0, q1, [x0, #0x20]
1028f4c48:     	stp	q0, q1, [x19, #0x20]
1028f4c4c:     	ldp	q0, q1, [x16]
1028f4c50:     	stp	q0, q1, [x19, #0x40]
1028f4c54:     	ldp	q0, q1, [x16, #0x20]
1028f4c58:     	stp	q0, q1, [x19, #0x60]
1028f4c5c:     	ldp	q0, q1, [x14]
1028f4c60:     	ldp	q2, q3, [x14, #0x20]
1028f4c64:     	add	x14, x20, x9
1028f4c68:     	ldrb	w15, [x14, #0xc0]
1028f4c6c:     	ldrh	w16, [x14, #0xc2]
1028f4c70:     	ldrb	w17, [x14, #0x80]
1028f4c74:     	ldrh	w0, [x14, #0x82]
1028f4c78:     	cmp	w16, w0
1028f4c7c:     	cset	w16, lo
1028f4c80:     	subs	w0, w15, w17
1028f4c84:     	bics	wzr, w10, w0
1028f4c88:     	cset	w0, eq
1028f4c8c:     	ldrb	w2, [x14, #0x40]
1028f4c90:     	ldrh	w3, [x14, #0x42]
1028f4c94:     	ldrb	w4, [x14]
1028f4c98:     	ldrh	w5, [x14, #0x2]
1028f4c9c:     	cmp	w15, w17
1028f4ca0:     	csel	w15, w16, w0, eq
1028f4ca4:     	cmp	w3, w5
1028f4ca8:     	cset	w16, lo
1028f4cac:     	subs	w17, w2, w4
1028f4cb0:     	bics	wzr, w10, w17
1028f4cb4:     	cset	w17, eq
1028f4cb8:     	cmp	w2, w4
1028f4cbc:     	csel	w16, w16, w17, eq
1028f4cc0:     	eor	w17, w16, #0x1
1028f4cc4:     	cmp	w15, #0x0
1028f4cc8:     	csel	x15, x12, x13, ne
1028f4ccc:     	add	x15, x14, x15
1028f4cd0:     	add	x17, x14, x17, lsl #6
1028f4cd4:     	csel	x12, x13, x12, ne
1028f4cd8:     	ldrb	w13, [x15]
1028f4cdc:     	ldrh	w0, [x15, #0x2]
1028f4ce0:     	ldrb	w2, [x17]
1028f4ce4:     	ldrh	w3, [x17, #0x2]
1028f4ce8:     	cmp	w0, w3
1028f4cec:     	cset	w0, lo
1028f4cf0:     	subs	w3, w13, w2
1028f4cf4:     	bics	wzr, w10, w3
1028f4cf8:     	cset	w3, eq
1028f4cfc:     	add	x16, x14, x16, lsl #6
1028f4d00:     	add	x12, x14, x12
1028f4d04:     	ldrb	w14, [x12]
1028f4d08:     	ldrh	w4, [x12, #0x2]
1028f4d0c:     	ldrb	w5, [x16]
1028f4d10:     	ldrh	w6, [x16, #0x2]
1028f4d14:     	cmp	w13, w2
1028f4d18:     	csel	w13, w0, w3, eq
1028f4d1c:     	cmp	w4, w6
1028f4d20:     	cset	w0, lo
1028f4d24:     	subs	w2, w14, w5
1028f4d28:     	bics	wzr, w10, w2
1028f4d2c:     	cset	w2, eq
1028f4d30:     	cmp	w14, w5
1028f4d34:     	csel	w14, w0, w2, eq
1028f4d38:     	cmp	w13, #0x0
1028f4d3c:     	csel	x0, x12, x17, ne
1028f4d40:     	cmp	w14, #0x0
1028f4d44:     	csel	x14, x12, x16, ne
1028f4d48:     	csel	x16, x16, x0, ne
1028f4d4c:     	csel	x0, x17, x12, ne
1028f4d50:     	cmp	w13, #0x0
1028f4d54:     	csel	x12, x17, x15, ne
1028f4d58:     	csel	x13, x15, x0, ne
1028f4d5c:     	ldrb	w15, [x13]
1028f4d60:     	ldrh	w17, [x13, #0x2]
1028f4d64:     	ldrb	w0, [x16]
1028f4d68:     	ldrh	w2, [x16, #0x2]
1028f4d6c:     	cmp	w17, w2
1028f4d70:     	cset	w17, lo
1028f4d74:     	subs	w2, w15, w0
1028f4d78:     	bics	wzr, w10, w2
1028f4d7c:     	cset	w10, eq
1028f4d80:     	stp	q2, q3, [x19, #0xa0]
1028f4d84:     	stp	q0, q1, [x19, #0x80]
1028f4d88:     	ldp	q0, q1, [x11]
1028f4d8c:     	stp	q0, q1, [x19, #0xc0]
1028f4d90:     	ldp	q0, q1, [x11, #0x20]
1028f4d94:     	stp	q0, q1, [x19, #0xe0]
1028f4d98:     	add	x11, x19, x9
1028f4d9c:     	cmp	w15, w0
1028f4da0:     	csel	w10, w17, w10, eq
1028f4da4:     	cmp	w10, #0x0
1028f4da8:     	csel	x10, x13, x16, ne
1028f4dac:     	csel	x13, x16, x13, ne
1028f4db0:     	ldp	q0, q1, [x14]
1028f4db4:     	stp	q0, q1, [x11]
1028f4db8:     	ldp	q0, q1, [x14, #0x20]
1028f4dbc:     	stp	q0, q1, [x11, #0x20]
1028f4dc0:     	ldp	q0, q1, [x10]
1028f4dc4:     	stp	q0, q1, [x11, #0x40]
1028f4dc8:     	ldp	q0, q1, [x10, #0x20]
1028f4dcc:     	stp	q0, q1, [x11, #0x60]
1028f4dd0:     	ldp	q0, q1, [x13]
1028f4dd4:     	ldp	q2, q3, [x13, #0x20]
1028f4dd8:     	stp	q2, q3, [x11, #0xa0]
1028f4ddc:     	stp	q0, q1, [x11, #0x80]
1028f4de0:     	ldp	q0, q1, [x12]
1028f4de4:     	stp	q0, q1, [x11, #0xc0]
1028f4de8:     	ldp	q0, q1, [x12, #0x20]
1028f4dec:     	stp	q0, q1, [x11, #0xe0]
1028f4df0:     	mov	w11, #0x4               ; =4
1028f4df4:     	sub	x12, x1, x8
1028f4df8:     	lsl	x13, x11, #6
1028f4dfc:     	cmp	x11, x8
1028f4e00:     	b.lo	0x1028f4e44 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x380>
1028f4e04:     	b	0x1028f4f50 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
1028f4e08:     	ldp	q0, q1, [x20]
1028f4e0c:     	stp	q0, q1, [x19]
1028f4e10:     	ldp	q0, q1, [x20, #0x20]
1028f4e14:     	stp	q0, q1, [x19, #0x20]
1028f4e18:     	add	x10, x20, x9
1028f4e1c:     	add	x12, x19, x9
1028f4e20:     	ldp	q0, q1, [x10]
1028f4e24:     	stp	q0, q1, [x12]
1028f4e28:     	ldp	q0, q1, [x10, #0x20]
1028f4e2c:     	mov	w11, #0x1               ; =1
1028f4e30:     	stp	q0, q1, [x12, #0x20]
1028f4e34:     	sub	x12, x1, x8
1028f4e38:     	lsl	x13, x11, #6
1028f4e3c:     	cmp	x11, x8
1028f4e40:     	b.hs	0x1028f4f50 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
1028f4e44:     	mov	w10, #0xff              ; =255
1028f4e48:     	mov	x14, x13
1028f4e4c:     	mov	x15, x11
1028f4e50:     	b	0x1028f4e90 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x3cc>
1028f4e54:     	mov	x2, x19
1028f4e58:     	strb	w17, [x2]
1028f4e5c:     	strb	w0, [x2, #0x1]
1028f4e60:     	strh	w16, [x2, #0x2]
1028f4e64:     	ldp	q0, q1, [sp]
1028f4e68:     	stur	q0, [x2, #0x4]
1028f4e6c:     	stur	q1, [x2, #0x14]
1028f4e70:     	ldr	q0, [sp, #0x20]
1028f4e74:     	stur	q0, [x2, #0x24]
1028f4e78:     	ldur	q0, [sp, #0x2c]
1028f4e7c:     	str	q0, [x2, #0x30]
1028f4e80:     	add	x15, x15, #0x1
1028f4e84:     	add	x14, x14, #0x40
1028f4e88:     	cmp	x15, x8
1028f4e8c:     	b.eq	0x1028f4f50 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x48c>
1028f4e90:     	lsl	x16, x15, #6
1028f4e94:     	add	x2, x20, x16
1028f4e98:     	add	x0, x19, x16
1028f4e9c:     	ldp	q0, q1, [x2]
1028f4ea0:     	stp	q0, q1, [x0]
1028f4ea4:     	ldrb	w17, [x0]
1028f4ea8:     	ldrh	w16, [x0, #0x2]
1028f4eac:     	ldurb	w3, [x0, #-0x40]
1028f4eb0:     	ldurh	w4, [x0, #-0x3e]
1028f4eb4:     	cmp	w16, w4
1028f4eb8:     	cset	w4, lo
1028f4ebc:     	subs	w5, w17, w3
1028f4ec0:     	bics	wzr, w10, w5
1028f4ec4:     	cset	w5, eq
1028f4ec8:     	ldp	q0, q1, [x2, #0x20]
1028f4ecc:     	stp	q0, q1, [x0, #0x20]
1028f4ed0:     	cmp	w17, w3
1028f4ed4:     	csel	w3, w4, w5, eq
1028f4ed8:     	cmp	w3, #0x1
1028f4edc:     	b.ne	0x1028f4e80 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x3bc>
1028f4ee0:     	ldrb	w0, [x0, #0x1]
1028f4ee4:     	ldur	q0, [x2, #0x4]
1028f4ee8:     	ldur	q1, [x2, #0x14]
1028f4eec:     	stp	q0, q1, [sp]
1028f4ef0:     	ldur	q0, [x2, #0x24]
1028f4ef4:     	str	q0, [sp, #0x20]
1028f4ef8:     	ldr	q0, [x2, #0x30]
1028f4efc:     	stur	q0, [sp, #0x2c]
1028f4f00:     	mov	x2, x14
1028f4f04:     	add	x3, x19, x2
1028f4f08:     	ldp	q0, q1, [x3, #-0x40]
1028f4f0c:     	stp	q0, q1, [x3]
1028f4f10:     	ldp	q0, q1, [x3, #-0x20]
1028f4f14:     	stp	q0, q1, [x3, #0x20]
1028f4f18:     	subs	x2, x2, #0x40
1028f4f1c:     	b.eq	0x1028f4e54 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x390>
1028f4f20:     	ldurb	w4, [x3, #-0x80]
1028f4f24:     	ldurh	w3, [x3, #-0x7e]
1028f4f28:     	cmp	w16, w3
1028f4f2c:     	cset	w3, lo
1028f4f30:     	subs	w5, w17, w4
1028f4f34:     	bics	wzr, w10, w5
1028f4f38:     	cset	w5, eq
1028f4f3c:     	cmp	w17, w4
1028f4f40:     	csel	w3, w3, w5, eq
1028f4f44:     	tbnz	w3, #0x0, 0x1028f4f04 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x440>
1028f4f48:     	add	x2, x19, x2
1028f4f4c:     	b	0x1028f4e58 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x394>
1028f4f50:     	add	x10, x19, x9
1028f4f54:     	cmp	x11, x12
1028f4f58:     	b.hs	0x1028f507c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5b8>
1028f4f5c:     	add	x9, x20, x9
1028f4f60:     	mov	w14, #0x40              ; =64
1028f4f64:     	mov	w15, #0xff              ; =255
1028f4f68:     	mov	x16, x10
1028f4f6c:     	b	0x1028f4fb0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4ec>
1028f4f70:     	mov	x3, x10
1028f4f74:     	strb	w0, [x3]
1028f4f78:     	strb	w2, [x3, #0x1]
1028f4f7c:     	strh	w17, [x3, #0x2]
1028f4f80:     	ldp	q2, q0, [sp, #0x10]
1028f4f84:     	ldur	q1, [sp, #0x2c]
1028f4f88:     	ldr	q3, [sp]
1028f4f8c:     	stur	q3, [x3, #0x4]
1028f4f90:     	str	q1, [x3, #0x30]
1028f4f94:     	stur	q0, [x3, #0x24]
1028f4f98:     	stur	q2, [x3, #0x14]
1028f4f9c:     	add	x11, x11, #0x1
1028f4fa0:     	add	x16, x16, #0x40
1028f4fa4:     	sub	x14, x14, #0x40
1028f4fa8:     	cmp	x11, x12
1028f4fac:     	b.eq	0x1028f507c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5b8>
1028f4fb0:     	lsl	x17, x11, #6
1028f4fb4:     	add	x3, x9, x17
1028f4fb8:     	add	x2, x10, x17
1028f4fbc:     	ldp	q0, q1, [x3]
1028f4fc0:     	stp	q0, q1, [x2]
1028f4fc4:     	ldrb	w0, [x2]
1028f4fc8:     	ldrh	w17, [x2, #0x2]
1028f4fcc:     	ldurb	w4, [x2, #-0x40]
1028f4fd0:     	ldurh	w5, [x2, #-0x3e]
1028f4fd4:     	cmp	w17, w5
1028f4fd8:     	cset	w5, lo
1028f4fdc:     	subs	w6, w0, w4
1028f4fe0:     	bics	wzr, w15, w6
1028f4fe4:     	cset	w6, eq
1028f4fe8:     	ldp	q0, q1, [x3, #0x20]
1028f4fec:     	stp	q0, q1, [x2, #0x20]
1028f4ff0:     	cmp	w0, w4
1028f4ff4:     	csel	w4, w5, w6, eq
1028f4ff8:     	cmp	w4, #0x1
1028f4ffc:     	b.ne	0x1028f4f9c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4d8>
1028f5000:     	ldrb	w2, [x2, #0x1]
1028f5004:     	ldur	q0, [x3, #0x4]
1028f5008:     	ldur	q1, [x3, #0x14]
1028f500c:     	stp	q0, q1, [sp]
1028f5010:     	ldur	q0, [x3, #0x24]
1028f5014:     	str	q0, [sp, #0x20]
1028f5018:     	ldr	q0, [x3, #0x30]
1028f501c:     	stur	q0, [sp, #0x2c]
1028f5020:     	mov	x4, x14
1028f5024:     	mov	x3, x16
1028f5028:     	add	x5, x3, x13
1028f502c:     	ldp	q0, q1, [x5, #-0x40]
1028f5030:     	stp	q0, q1, [x5]
1028f5034:     	ldp	q0, q1, [x5, #-0x20]
1028f5038:     	stp	q0, q1, [x5, #0x20]
1028f503c:     	cmp	x13, x4
1028f5040:     	b.eq	0x1028f4f70 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4ac>
1028f5044:     	ldurb	w6, [x5, #-0x80]
1028f5048:     	ldurh	w5, [x5, #-0x7e]
1028f504c:     	cmp	w17, w5
1028f5050:     	cset	w5, lo
1028f5054:     	subs	w7, w0, w6
1028f5058:     	bics	wzr, w15, w7
1028f505c:     	cset	w7, eq
1028f5060:     	cmp	w0, w6
1028f5064:     	csel	w5, w5, w7, eq
1028f5068:     	sub	x3, x3, #0x40
1028f506c:     	add	x4, x4, #0x40
1028f5070:     	tbnz	w5, #0x0, 0x1028f5028 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x564>
1028f5074:     	add	x3, x3, x13
1028f5078:     	b	0x1028f4f74 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x4b0>
1028f507c:     	lsl	x21, x1, #6
1028f5080:     	sub	x13, x21, #0x40
1028f5084:     	add	x12, x19, x13
1028f5088:     	sub	x14, x10, #0x40
1028f508c:     	mov	w15, #0xff              ; =255
1028f5090:     	mov	x11, x20
1028f5094:     	mov	x9, x19
1028f5098:     	ldrb	w16, [x12]
1028f509c:     	ldrh	w17, [x12, #0x2]
1028f50a0:     	ldrb	w0, [x14]
1028f50a4:     	ldrh	w2, [x14, #0x2]
1028f50a8:     	cmp	w17, w2
1028f50ac:     	cset	w17, lo
1028f50b0:     	subs	w2, w16, w0
1028f50b4:     	bics	wzr, w15, w2
1028f50b8:     	cset	w2, eq
1028f50bc:     	ldrb	w3, [x10]
1028f50c0:     	ldrh	w4, [x10, #0x2]
1028f50c4:     	ldrb	w5, [x9]
1028f50c8:     	ldrh	w6, [x9, #0x2]
1028f50cc:     	cmp	w16, w0
1028f50d0:     	csel	w16, w17, w2, eq
1028f50d4:     	cmp	w4, w6
1028f50d8:     	cset	w17, lo
1028f50dc:     	subs	w0, w3, w5
1028f50e0:     	bics	wzr, w15, w0
1028f50e4:     	cset	w0, eq
1028f50e8:     	add	x2, x20, x13
1028f50ec:     	cmp	w3, w5
1028f50f0:     	csel	w17, w17, w0, eq
1028f50f4:     	cmp	w17, #0x0
1028f50f8:     	csel	x0, x10, x9, ne
1028f50fc:     	eor	w3, w17, #0x1
1028f5100:     	ldp	q1, q0, [x0, #0x20]
1028f5104:     	stp	q1, q0, [x11, #0x20]
1028f5108:     	ldp	q1, q0, [x0]
1028f510c:     	stp	q1, q0, [x11], #0x40
1028f5110:     	add	x10, x10, x17, lsl #6
1028f5114:     	add	x9, x9, x3, lsl #6
1028f5118:     	cmp	w16, #0x0
1028f511c:     	csel	x17, x14, x12, ne
1028f5120:     	ldp	q1, q0, [x17, #0x20]
1028f5124:     	stp	q1, q0, [x2, #0x20]
1028f5128:     	ldp	q1, q0, [x17]
1028f512c:     	stp	q1, q0, [x2]
1028f5130:     	add	x12, x12, x16, lsl #6
1028f5134:     	sub	x12, x12, #0x40
1028f5138:     	sbfx	x16, x16, #0, #1
1028f513c:     	add	x14, x14, x16, lsl #6
1028f5140:     	sub	x13, x13, #0x40
1028f5144:     	sub	x8, x8, #0x1
1028f5148:     	cbnz	x8, 0x1028f5098 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x5d4>
1028f514c:     	add	x8, x14, #0x40
1028f5150:     	add	x12, x12, #0x40
1028f5154:     	tbz	w1, #0x0, 0x1028f5180 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6bc>
1028f5158:     	cmp	x9, x8
1028f515c:     	csel	x13, x9, x10, lo
1028f5160:     	cset	w14, hs
1028f5164:     	cset	w15, lo
1028f5168:     	ldp	q0, q1, [x13]
1028f516c:     	stp	q0, q1, [x11]
1028f5170:     	ldp	q0, q1, [x13, #0x20]
1028f5174:     	stp	q0, q1, [x11, #0x20]
1028f5178:     	add	x9, x9, x15, lsl #6
1028f517c:     	add	x10, x10, x14, lsl #6
1028f5180:     	cmp	x9, x8
1028f5184:     	ccmp	x10, x12, #0x0, eq
1028f5188:     	b.ne	0x1028f51a0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_+0x6dc>
1028f518c:     	ldp	x29, x30, [sp, #0x60]
1028f5190:     	ldp	x20, x19, [sp, #0x50]
1028f5194:     	ldp	x22, x21, [sp, #0x40]
1028f5198:     	add	sp, sp, #0x70
1028f519c:     	ret
1028f51a0:     	bl	0x103a03f94 <__RNvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort22panic_on_ord_violation>
1028f51a4:     	brk	#0x1
1028f51a8:     	mov	x22, x0
1028f51ac:     	mov	x0, x20
1028f51b0:     	mov	x1, x19
1028f51b4:     	mov	x2, x21
1028f51b8:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
1028f51bc:     	mov	x0, x22
1028f51c0:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
