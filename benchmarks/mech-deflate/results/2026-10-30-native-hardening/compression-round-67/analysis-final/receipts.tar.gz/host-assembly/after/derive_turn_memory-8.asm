
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027bd7e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_>:
1027bd7e8:     	sub	sp, sp, #0x1b0
1027bd7ec:     	stp	x28, x27, [sp, #0x150]
1027bd7f0:     	stp	x26, x25, [sp, #0x160]
1027bd7f4:     	stp	x24, x23, [sp, #0x170]
1027bd7f8:     	stp	x22, x21, [sp, #0x180]
1027bd7fc:     	stp	x20, x19, [sp, #0x190]
1027bd800:     	stp	x29, x30, [sp, #0x1a0]
1027bd804:     	add	x29, sp, #0x1a0
1027bd808:     	mov	x21, x0
1027bd80c:     	mov	x19, x8
1027bd810:     	add	x23, sp, #0x80
1027bd814:     	add	x8, x0, #0x10
1027bd818:     	str	x8, [sp, #0x80]
1027bd81c:     	ldp	x8, x22, [x0]
1027bd820:     	sub	x8, x8, #0x60
1027bd824:     	add	x20, x8, #0x60
1027bd828:     	cmp	x20, x22
1027bd82c:     	b.eq	0x1027bd888 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0xa0>
1027bd830:     	add	x8, x8, #0xc0
1027bd834:     	str	x8, [x21]
1027bd838:     	str	x20, [sp, #0xd0]
1027bd83c:     	add	x0, sp, #0x80
1027bd840:     	add	x1, sp, #0xd0
1027bd844:     	bl	0x102a1ebe0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_>
1027bd848:     	mov	x8, x20
1027bd84c:     	cbz	w0, 0x1027bd824 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x3c>
1027bd850:     	cbz	x20, 0x1027bd888 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0xa0>
1027bd854:     	ldr	x8, [x21, #0x40]
1027bd858:     	ldrb	w9, [x20, #0x10]
1027bd85c:     	and	w22, w9, #0xff
1027bd860:     	add	x9, x20, #0x14
1027bd864:     	ldr	w10, [x8, #0xa8]
1027bd868:     	cmp	w22, #0x4
1027bd86c:     	cset	w11, eq
1027bd870:     	add	x8, x8, #0xac
1027bd874:     	tst	w10, w11
1027bd878:     	csel	x8, x8, x9, ne
1027bd87c:     	ldr	w25, [x20]
1027bd880:     	cmp	w25, #0x2
1027bd884:     	b.ne	0x1027bd8b4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0xcc>
1027bd888:     	mov	w8, #0x8                ; =8
1027bd88c:     	stp	xzr, x8, [x19]
1027bd890:     	str	xzr, [x19, #0x10]
1027bd894:     	ldp	x29, x30, [sp, #0x1a0]
1027bd898:     	ldp	x20, x19, [sp, #0x190]
1027bd89c:     	ldp	x22, x21, [sp, #0x180]
1027bd8a0:     	ldp	x24, x23, [sp, #0x170]
1027bd8a4:     	ldp	x26, x25, [sp, #0x160]
1027bd8a8:     	ldp	x28, x27, [sp, #0x150]
1027bd8ac:     	add	sp, sp, #0x1b0
1027bd8b0:     	ret
1027bd8b4:     	ldr	w24, [x8]
1027bd8b8:     	ldur	x8, [x20, #0x4]
1027bd8bc:     	str	x8, [sp, #0x70]
1027bd8c0:     	ldr	w8, [x20, #0xc]
1027bd8c4:     	str	w8, [sp, #0x78]
1027bd8c8:     	ldurh	w8, [x20, #0x11]
1027bd8cc:     	strh	w8, [sp, #0x6c]
1027bd8d0:     	ldrb	w8, [x20, #0x13]
1027bd8d4:     	strb	w8, [sp, #0x6e]
1027bd8d8:     	ldur	q0, [x20, #0x28]
1027bd8dc:     	ldur	q1, [x20, #0x38]
1027bd8e0:     	ldur	q2, [x20, #0x48]
1027bd8e4:     	stp	q1, q2, [sp, #0x40]
1027bd8e8:     	ldr	x8, [x20, #0x58]
1027bd8ec:     	str	x8, [sp, #0x60]
1027bd8f0:     	ldur	q1, [x20, #0x18]
1027bd8f4:     	stp	q1, q0, [sp, #0x20]
1027bd8f8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027bd8fc:     	mov	w0, #0x180              ; =384
1027bd900:     	mov	w1, #0x8                ; =8
1027bd904:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027bd908:     	cbz	x0, 0x1027bdae4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x2fc>
1027bd90c:     	mov	x20, x0
1027bd910:     	ldp	q1, q0, [sp, #0x20]
1027bd914:     	stur	q0, [x0, #0x28]
1027bd918:     	ldp	q0, q2, [sp, #0x40]
1027bd91c:     	stur	q0, [x0, #0x38]
1027bd920:     	stur	q2, [x0, #0x48]
1027bd924:     	stur	q1, [x0, #0x18]
1027bd928:     	ldp	q0, q1, [x21, #0x20]
1027bd92c:     	ldp	q3, q2, [x21]
1027bd930:     	stp	q2, q0, [x23, #0x10]
1027bd934:     	str	q1, [x23, #0x30]
1027bd938:     	str	w25, [x0]
1027bd93c:     	ldr	x8, [sp, #0x70]
1027bd940:     	stur	x8, [x0, #0x4]
1027bd944:     	ldr	w8, [sp, #0x78]
1027bd948:     	str	w8, [x0, #0xc]
1027bd94c:     	strb	w22, [x0, #0x10]
1027bd950:     	ldrh	w8, [sp, #0x6c]
1027bd954:     	sturh	w8, [x0, #0x11]
1027bd958:     	ldrb	w8, [sp, #0x6e]
1027bd95c:     	strb	w8, [x0, #0x13]
1027bd960:     	str	w24, [x0, #0x14]
1027bd964:     	ldr	x8, [sp, #0x60]
1027bd968:     	str	x8, [x0, #0x58]
1027bd96c:     	mov	w8, #0x4                ; =4
1027bd970:     	stp	x8, x0, [sp, #0x8]
1027bd974:     	mov	w22, #0x1               ; =1
1027bd978:     	str	x22, [sp, #0x18]
1027bd97c:     	ldr	x8, [x21, #0x40]
1027bd980:     	str	x8, [sp, #0xc0]
1027bd984:     	add	x8, sp, #0x80
1027bd988:     	add	x21, x8, #0x10
1027bd98c:     	mov	w24, #0x60              ; =96
1027bd990:     	str	q3, [sp, #0x80]
1027bd994:     	stur	x21, [x29, #-0x70]
1027bd998:     	ldp	x8, x25, [sp, #0x80]
1027bd99c:     	sub	x26, x8, #0x60
1027bd9a0:     	add	x8, x26, #0x60
1027bd9a4:     	cmp	x8, x25
1027bd9a8:     	b.eq	0x1027bdad0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x2e8>
1027bd9ac:     	add	x9, x26, #0xc0
1027bd9b0:     	str	x9, [sp, #0x80]
1027bd9b4:     	stur	x8, [x29, #-0x68]
1027bd9b8:     	sub	x0, x29, #0x70
1027bd9bc:     	sub	x1, x29, #0x68
1027bd9c0:     	bl	0x102a1ebe0 <__RNvXs1_NtNtNtCsgDHHaSskbIF_4core3ops8function5implsQNCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0INtB7_5FnMutTRRNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEE8call_mutBW_>
1027bd9c4:     	add	x26, x26, #0x60
1027bd9c8:     	cbz	w0, 0x1027bd9a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x1b8>
1027bd9cc:     	cbz	x26, 0x1027bdad0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x2e8>
1027bd9d0:     	ldr	x8, [sp, #0xc0]
1027bd9d4:     	ldrb	w9, [x26, #0x10]
1027bd9d8:     	and	w25, w9, #0xff
1027bd9dc:     	add	x9, x26, #0x14
1027bd9e0:     	ldr	w10, [x8, #0xa8]
1027bd9e4:     	cmp	w25, #0x4
1027bd9e8:     	cset	w11, eq
1027bd9ec:     	add	x8, x8, #0xac
1027bd9f0:     	tst	w10, w11
1027bd9f4:     	csel	x8, x8, x9, ne
1027bd9f8:     	ldr	w28, [x26]
1027bd9fc:     	cmp	w28, #0x2
1027bda00:     	b.eq	0x1027bdad0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x2e8>
1027bda04:     	ldr	w27, [x8]
1027bda08:     	ldur	x8, [x26, #0x4]
1027bda0c:     	stur	x8, [x29, #-0x80]
1027bda10:     	ldr	w8, [x26, #0xc]
1027bda14:     	stur	w8, [x29, #-0x78]
1027bda18:     	ldurh	w8, [x26, #0x11]
1027bda1c:     	sturh	w8, [x29, #-0x84]
1027bda20:     	ldrb	w8, [x26, #0x13]
1027bda24:     	sturb	w8, [x29, #-0x82]
1027bda28:     	ldur	q0, [x26, #0x28]
1027bda2c:     	ldur	q1, [x26, #0x38]
1027bda30:     	ldur	q2, [x26, #0x48]
1027bda34:     	stp	q1, q2, [x23, #0x70]
1027bda38:     	ldr	x8, [x26, #0x58]
1027bda3c:     	str	x8, [sp, #0x110]
1027bda40:     	ldur	q1, [x26, #0x18]
1027bda44:     	stp	q1, q0, [x23, #0x50]
1027bda48:     	ldr	x8, [sp, #0x8]
1027bda4c:     	cmp	x22, x8
1027bda50:     	b.ne	0x1027bda70 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x288>
1027bda54:     	add	x0, sp, #0x8
1027bda58:     	mov	x1, x22
1027bda5c:     	mov	w2, #0x1                ; =1
1027bda60:     	mov	w3, #0x8                ; =8
1027bda64:     	mov	w4, #0x60               ; =96
1027bda68:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027bda6c:     	ldr	x20, [sp, #0x10]
1027bda70:     	madd	x8, x22, x24, x20
1027bda74:     	str	w28, [x8]
1027bda78:     	ldur	x9, [x29, #-0x80]
1027bda7c:     	ldur	w10, [x29, #-0x78]
1027bda80:     	str	w10, [x8, #0xc]
1027bda84:     	stur	x9, [x8, #0x4]
1027bda88:     	strb	w25, [x8, #0x10]
1027bda8c:     	ldurh	w9, [x29, #-0x84]
1027bda90:     	ldurb	w10, [x29, #-0x82]
1027bda94:     	strb	w10, [x8, #0x13]
1027bda98:     	sturh	w9, [x8, #0x11]
1027bda9c:     	str	w27, [x8, #0x14]
1027bdaa0:     	ldr	q0, [x23, #0x50]
1027bdaa4:     	stur	q0, [x8, #0x18]
1027bdaa8:     	ldp	q0, q1, [x23, #0x60]
1027bdaac:     	ldr	q2, [x23, #0x80]
1027bdab0:     	ldr	x9, [sp, #0x110]
1027bdab4:     	str	x9, [x8, #0x58]
1027bdab8:     	stur	q2, [x8, #0x48]
1027bdabc:     	stur	q1, [x8, #0x38]
1027bdac0:     	stur	q0, [x8, #0x28]
1027bdac4:     	add	x22, x22, #0x1
1027bdac8:     	str	x22, [sp, #0x18]
1027bdacc:     	b	0x1027bd994 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x1ac>
1027bdad0:     	ldur	q0, [sp, #0x8]
1027bdad4:     	str	q0, [x19]
1027bdad8:     	ldr	x8, [sp, #0x18]
1027bdadc:     	str	x8, [x19, #0x10]
1027bdae0:     	b	0x1027bd894 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0xac>
1027bdae4:     	mov	w0, #0x8                ; =8
1027bdae8:     	mov	w1, #0x180              ; =384
1027bdaec:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027bdaf0:     	b	0x1027bdaf4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x30c>
1027bdaf4:     	mov	x19, x0
1027bdaf8:     	ldr	x8, [sp, #0x8]
1027bdafc:     	cbz	x8, 0x1027bdb14 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14AllocationPlanEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2E_6filter6FilterINtNtNtB2I_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys8_0ENCB4i_s9_0EE9from_iterB4o_+0x32c>
1027bdb00:     	ldr	x0, [sp, #0x10]
1027bdb04:     	add	x8, x8, x8, lsl #1
1027bdb08:     	lsl	x1, x8, #5
1027bdb0c:     	mov	w2, #0x8                ; =8
1027bdb10:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027bdb14:     	mov	x0, x19
1027bdb18:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
