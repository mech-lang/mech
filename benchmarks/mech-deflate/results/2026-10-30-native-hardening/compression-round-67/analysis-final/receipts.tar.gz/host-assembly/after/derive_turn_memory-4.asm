
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027abcd0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_>:
1027abcd0:     	sub	sp, sp, #0xa0
1027abcd4:     	stp	x28, x27, [sp, #0x40]
1027abcd8:     	stp	x26, x25, [sp, #0x50]
1027abcdc:     	stp	x24, x23, [sp, #0x60]
1027abce0:     	stp	x22, x21, [sp, #0x70]
1027abce4:     	stp	x20, x19, [sp, #0x80]
1027abce8:     	stp	x29, x30, [sp, #0x90]
1027abcec:     	add	x29, sp, #0x90
1027abcf0:     	mov	x20, x0
1027abcf4:     	ldr	w10, [x0, #0x10]
1027abcf8:     	ldr	x16, [x0]
1027abcfc:     	mov	x15, x0
1027abd00:     	ldr	x26, [x15, #0x8]!
1027abd04:     	ldp	x9, x11, [x0, #0x18]
1027abd08:     	str	x11, [sp, #0x20]
1027abd0c:     	ldp	x25, x11, [x0, #0x28]
1027abd10:     	str	x11, [sp, #0x10]
1027abd14:     	tbz	w16, #0x0, 0x1027abd68 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x98>
1027abd18:     	tbz	w10, #0x0, 0x1027abdcc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0xfc>
1027abd1c:     	cbz	x9, 0x1027abd38 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x68>
1027abd20:     	add	x27, x9, #0x1b0
1027abd24:     	ldr	x10, [sp, #0x20]
1027abd28:     	cmp	x9, x10
1027abd2c:     	csel	x10, xzr, x27, eq
1027abd30:     	str	x10, [x20, #0x18]
1027abd34:     	b.ne	0x1027abd88 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0xb8>
1027abd38:     	cbz	x25, 0x1027abd48 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x78>
1027abd3c:     	ldr	x9, [sp, #0x10]
1027abd40:     	cmp	x25, x9
1027abd44:     	b.ne	0x1027abea8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1d8>
1027abd48:     	mov	x27, #0x0               ; =0
1027abd4c:     	str	xzr, [x20, #0x10]
1027abd50:     	str	xzr, [x15]
1027abd54:     	cbnz	x26, 0x1027abdd8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x108>
1027abd58:     	ldr	x9, [x20, #0x38]
1027abd5c:     	cmp	x9, #0x1
1027abd60:     	b.ne	0x1027abfd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
1027abd64:     	b	0x1027abf34 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x264>
1027abd68:     	tbz	w10, #0x0, 0x1027abe84 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1b4>
1027abd6c:     	cbz	x9, 0x1027abe98 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1c8>
1027abd70:     	add	x27, x9, #0x1b0
1027abd74:     	ldr	x10, [sp, #0x20]
1027abd78:     	cmp	x9, x10
1027abd7c:     	csel	x10, xzr, x27, eq
1027abd80:     	str	x10, [x20, #0x18]
1027abd84:     	b.eq	0x1027abe98 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1c8>
1027abd88:     	str	x8, [sp]
1027abd8c:     	ldr	w19, [x9, #0x1a8]
1027abd90:     	ldr	x8, [sp, #0x20]
1027abd94:     	sub	x8, x8, x27
1027abd98:     	lsr	x8, x8, #4
1027abd9c:     	mov	x9, #0xda13             ; =55827
1027abda0:     	movk	x9, #0x684b, lsl #16
1027abda4:     	movk	x9, #0xa12f, lsl #32
1027abda8:     	movk	x9, #0x84bd, lsl #48
1027abdac:     	mul	x8, x8, x9
1027abdb0:     	cbnz	x25, 0x1027abe4c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x17c>
1027abdb4:     	mov	w24, #0x1               ; =1
1027abdb8:     	ldr	x28, [x20, #0x38]
1027abdbc:     	cmp	x28, #0x1
1027abdc0:     	str	x16, [sp, #0x18]
1027abdc4:     	b.ne	0x1027ac00c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
1027abdc8:     	b	0x1027abf90 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2c0>
1027abdcc:     	mov	x27, x9
1027abdd0:     	str	xzr, [x15]
1027abdd4:     	cbz	x26, 0x1027abd58 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x88>
1027abdd8:     	ldr	x9, [x26, #0x2a8]
1027abddc:     	ldr	x12, [x26, #0x2b0]
1027abde0:     	mov	w13, #0x1b0             ; =432
1027abde4:     	mul	x10, x12, x13
1027abde8:     	add	x17, x9, x10
1027abdec:     	ldr	x25, [x26, #0x2b8]
1027abdf0:     	ldr	x11, [x26, #0x2c0]
1027abdf4:     	madd	x0, x11, x13, x25
1027abdf8:     	mov	w13, #0x1               ; =1
1027abdfc:     	add	x14, x9, x10
1027abe00:     	str	x14, [sp, #0x20]
1027abe04:     	stp	x17, x25, [x20, #0x20]
1027abe08:     	str	x0, [sp, #0x10]
1027abe0c:     	str	x0, [x20, #0x30]
1027abe10:     	add	x27, x9, #0x1b0
1027abe14:     	cmp	x12, #0x0
1027abe18:     	csel	x14, xzr, x27, eq
1027abe1c:     	stp	x13, x14, [x20, #0x10]
1027abe20:     	cbz	x12, 0x1027abeb0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1e0>
1027abe24:     	str	x8, [sp]
1027abe28:     	mov	x26, #0x0               ; =0
1027abe2c:     	ldr	w19, [x9, #0x1a8]
1027abe30:     	sub	x8, x10, #0x1b0
1027abe34:     	lsr	x8, x8, #4
1027abe38:     	mov	x9, #0xda13             ; =55827
1027abe3c:     	movk	x9, #0x684b, lsl #16
1027abe40:     	movk	x9, #0xa12f, lsl #32
1027abe44:     	movk	x9, #0x84bd, lsl #48
1027abe48:     	mul	x8, x8, x9
1027abe4c:     	ldr	x9, [sp, #0x10]
1027abe50:     	sub	x9, x9, x25
1027abe54:     	lsr	x9, x9, #4
1027abe58:     	mov	x10, #0xda13            ; =55827
1027abe5c:     	movk	x10, #0x684b, lsl #16
1027abe60:     	movk	x10, #0xa12f, lsl #32
1027abe64:     	movk	x10, #0x84bd, lsl #48
1027abe68:     	madd	x8, x9, x10, x8
1027abe6c:     	mov	w24, #0x1               ; =1
1027abe70:     	ldr	x28, [x20, #0x38]
1027abe74:     	cmp	x28, #0x1
1027abe78:     	str	x16, [sp, #0x18]
1027abe7c:     	b.ne	0x1027ac00c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
1027abe80:     	b	0x1027abf90 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2c0>
1027abe84:     	mov	x27, x9
1027abe88:     	ldr	x9, [x20, #0x38]
1027abe8c:     	cmp	x9, #0x1
1027abe90:     	b.eq	0x1027abf34 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x264>
1027abe94:     	b	0x1027abfd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
1027abe98:     	cbz	x25, 0x1027abf04 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x234>
1027abe9c:     	ldr	x9, [sp, #0x10]
1027abea0:     	cmp	x25, x9
1027abea4:     	b.eq	0x1027abf04 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x234>
1027abea8:     	str	x8, [sp]
1027abeac:     	b	0x1027abebc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1ec>
1027abeb0:     	cbz	x11, 0x1027abf1c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x24c>
1027abeb4:     	str	x8, [sp]
1027abeb8:     	mov	x26, #0x0               ; =0
1027abebc:     	mov	x27, #0x0               ; =0
1027abec0:     	ldr	w19, [x25, #0x1a8]
1027abec4:     	add	x25, x25, #0x1b0
1027abec8:     	str	x25, [x20, #0x28]
1027abecc:     	ldr	x8, [sp, #0x10]
1027abed0:     	sub	x8, x8, x25
1027abed4:     	lsr	x8, x8, #4
1027abed8:     	mov	x9, #0xda13             ; =55827
1027abedc:     	movk	x9, #0x684b, lsl #16
1027abee0:     	movk	x9, #0xa12f, lsl #32
1027abee4:     	movk	x9, #0x84bd, lsl #48
1027abee8:     	mul	x8, x8, x9
1027abeec:     	mov	w24, #0x1               ; =1
1027abef0:     	ldr	x28, [x20, #0x38]
1027abef4:     	cmp	x28, #0x1
1027abef8:     	str	x16, [sp, #0x18]
1027abefc:     	b.ne	0x1027ac00c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
1027abf00:     	b	0x1027abf90 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2c0>
1027abf04:     	mov	x27, #0x0               ; =0
1027abf08:     	str	xzr, [x20, #0x10]
1027abf0c:     	ldr	x9, [x20, #0x38]
1027abf10:     	cmp	x9, #0x1
1027abf14:     	b.ne	0x1027abfd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
1027abf18:     	b	0x1027abf34 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x264>
1027abf1c:     	mov	x26, #0x0               ; =0
1027abf20:     	mov	x27, #0x0               ; =0
1027abf24:     	stp	xzr, xzr, [x15]
1027abf28:     	ldr	x9, [x20, #0x38]
1027abf2c:     	cmp	x9, #0x1
1027abf30:     	b.ne	0x1027abfd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
1027abf34:     	ldr	x9, [x20, #0x40]
1027abf38:     	cbz	x9, 0x1027abf54 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x284>
1027abf3c:     	ldr	x11, [x20, #0x48]
1027abf40:     	add	x10, x9, #0x1b0
1027abf44:     	cmp	x9, x11
1027abf48:     	csel	x10, xzr, x10, eq
1027abf4c:     	str	x10, [x20, #0x40]
1027abf50:     	b.ne	0x1027abf70 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2a0>
1027abf54:     	ldr	x9, [x20, #0x50]
1027abf58:     	cbz	x9, 0x1027abfd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
1027abf5c:     	ldr	x10, [x20, #0x58]
1027abf60:     	cmp	x9, x10
1027abf64:     	b.eq	0x1027abfd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
1027abf68:     	add	x10, x9, #0x1b0
1027abf6c:     	str	x10, [x20, #0x50]
1027abf70:     	str	x8, [sp]
1027abf74:     	mov	x24, #0x0               ; =0
1027abf78:     	mov	x8, #0x0                ; =0
1027abf7c:     	ldr	w19, [x9, #0x1a8]
1027abf80:     	ldr	x28, [x20, #0x38]
1027abf84:     	cmp	x28, #0x1
1027abf88:     	str	x16, [sp, #0x18]
1027abf8c:     	b.ne	0x1027ac00c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
1027abf90:     	ldr	x9, [x20, #0x40]
1027abf94:     	ldr	x10, [x20, #0x50]
1027abf98:     	cbz	x9, 0x1027abfe4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x314>
1027abf9c:     	ldr	x11, [x20, #0x48]
1027abfa0:     	sub	x9, x11, x9
1027abfa4:     	lsr	x9, x9, #4
1027abfa8:     	mov	x11, #0xda13            ; =55827
1027abfac:     	movk	x11, #0x684b, lsl #16
1027abfb0:     	movk	x11, #0xa12f, lsl #32
1027abfb4:     	movk	x11, #0x84bd, lsl #48
1027abfb8:     	mul	x9, x9, x11
1027abfbc:     	cbz	x10, 0x1027ac010 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x340>
1027abfc0:     	ldr	x12, [x20, #0x58]
1027abfc4:     	sub	x10, x12, x10
1027abfc8:     	lsr	x10, x10, #4
1027abfcc:     	madd	x9, x10, x11, x9
1027abfd0:     	b	0x1027ac010 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x340>
1027abfd4:     	mov	w9, #0x4                ; =4
1027abfd8:     	stp	xzr, x9, [x8]
1027abfdc:     	str	xzr, [x8, #0x10]
1027abfe0:     	b	0x1027ac2a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5d0>
1027abfe4:     	cbz	x10, 0x1027ac00c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
1027abfe8:     	ldr	x9, [x20, #0x58]
1027abfec:     	sub	x9, x9, x10
1027abff0:     	lsr	x9, x9, #4
1027abff4:     	mov	x10, #0xda13            ; =55827
1027abff8:     	movk	x10, #0x684b, lsl #16
1027abffc:     	movk	x10, #0xa12f, lsl #32
1027ac000:     	movk	x10, #0x84bd, lsl #48
1027ac004:     	mul	x9, x9, x10
1027ac008:     	b	0x1027ac010 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x340>
1027ac00c:     	mov	x9, #0x0                ; =0
1027ac010:     	add	x8, x9, x8
1027ac014:     	mov	w9, #0x3                ; =3
1027ac018:     	cmp	x8, #0x3
1027ac01c:     	csel	x8, x8, x9, hi
1027ac020:     	add	x22, x8, #0x1
1027ac024:     	lsl	x21, x22, #2
1027ac028:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027ac02c:     	mov	x0, x21
1027ac030:     	mov	w1, #0x4                ; =4
1027ac034:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027ac038:     	cbz	x0, 0x1027ac2c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5f0>
1027ac03c:     	str	w19, [x0]
1027ac040:     	stp	x22, x0, [sp, #0x28]
1027ac044:     	mov	w21, #0x1               ; =1
1027ac048:     	str	x21, [sp, #0x38]
1027ac04c:     	ldp	x9, x8, [x20, #0x40]
1027ac050:     	str	x8, [sp, #0x8]
1027ac054:     	mov	x14, #0xda13            ; =55827
1027ac058:     	movk	x14, #0x684b, lsl #16
1027ac05c:     	movk	x14, #0xa12f, lsl #32
1027ac060:     	movk	x14, #0x84bd, lsl #48
1027ac064:     	ldp	x8, x20, [x20, #0x50]
1027ac068:     	ldr	x12, [sp, #0x18]
1027ac06c:     	b	0x1027ac088 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3b8>
1027ac070:     	str	w27, [x0, x21, lsl #2]
1027ac074:     	add	x21, x21, #0x1
1027ac078:     	str	x21, [sp, #0x38]
1027ac07c:     	mov	x27, x23
1027ac080:     	mov	x9, x19
1027ac084:     	mov	x8, x22
1027ac088:     	tbz	w12, #0x0, 0x1027ac0bc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3ec>
1027ac08c:     	tbz	w24, #0x0, 0x1027ac0e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x418>
1027ac090:     	cbz	x27, 0x1027ac0a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3d0>
1027ac094:     	ldr	x10, [sp, #0x20]
1027ac098:     	cmp	x27, x10
1027ac09c:     	b.ne	0x1027ac11c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x44c>
1027ac0a0:     	mov	x23, #0x0               ; =0
1027ac0a4:     	cbz	x25, 0x1027ac0b4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3e4>
1027ac0a8:     	ldr	x10, [sp, #0x10]
1027ac0ac:     	cmp	x25, x10
1027ac0b0:     	b.ne	0x1027ac190 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4c0>
1027ac0b4:     	cbz	x26, 0x1027ac128 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
1027ac0b8:     	b	0x1027ac0f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x420>
1027ac0bc:     	tbz	w24, #0x0, 0x1027ac124 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x454>
1027ac0c0:     	cbz	x27, 0x1027ac0d0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x400>
1027ac0c4:     	ldr	x10, [sp, #0x20]
1027ac0c8:     	cmp	x27, x10
1027ac0cc:     	b.ne	0x1027ac11c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x44c>
1027ac0d0:     	mov	x23, #0x0               ; =0
1027ac0d4:     	cbz	x25, 0x1027ac128 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
1027ac0d8:     	ldr	x10, [sp, #0x10]
1027ac0dc:     	cmp	x25, x10
1027ac0e0:     	b.ne	0x1027ac190 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4c0>
1027ac0e4:     	b	0x1027ac128 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
1027ac0e8:     	mov	x23, x27
1027ac0ec:     	cbz	x26, 0x1027ac128 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
1027ac0f0:     	ldr	x27, [x26, #0x2a8]
1027ac0f4:     	ldr	x11, [x26, #0x2b0]
1027ac0f8:     	mov	w13, #0x1b0             ; =432
1027ac0fc:     	madd	x10, x11, x13, x27
1027ac100:     	str	x10, [sp, #0x20]
1027ac104:     	ldr	x25, [x26, #0x2b8]
1027ac108:     	ldr	x10, [x26, #0x2c0]
1027ac10c:     	madd	x13, x10, x13, x25
1027ac110:     	str	x13, [sp, #0x10]
1027ac114:     	mov	x26, #0x0               ; =0
1027ac118:     	cbz	x11, 0x1027ac188 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4b8>
1027ac11c:     	add	x23, x27, #0x1b0
1027ac120:     	b	0x1027ac19c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4cc>
1027ac124:     	mov	x23, x27
1027ac128:     	cbz	w28, 0x1027ac28c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5bc>
1027ac12c:     	cbz	x9, 0x1027ac15c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x48c>
1027ac130:     	ldr	x10, [sp, #0x8]
1027ac134:     	cmp	x9, x10
1027ac138:     	b.eq	0x1027ac15c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x48c>
1027ac13c:     	mov	x24, #0x0               ; =0
1027ac140:     	add	x19, x9, #0x1b0
1027ac144:     	mov	x22, x8
1027ac148:     	ldr	w27, [x9, #0x1a8]
1027ac14c:     	ldr	x8, [sp, #0x28]
1027ac150:     	cmp	x21, x8
1027ac154:     	b.ne	0x1027ac070 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
1027ac158:     	b	0x1027ac1b8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4e8>
1027ac15c:     	cbz	x8, 0x1027ac28c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5bc>
1027ac160:     	cmp	x8, x20
1027ac164:     	b.eq	0x1027ac28c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5bc>
1027ac168:     	mov	x19, #0x0               ; =0
1027ac16c:     	mov	x24, #0x0               ; =0
1027ac170:     	add	x22, x8, #0x1b0
1027ac174:     	ldr	w27, [x8, #0x1a8]
1027ac178:     	ldr	x8, [sp, #0x28]
1027ac17c:     	cmp	x21, x8
1027ac180:     	b.ne	0x1027ac070 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
1027ac184:     	b	0x1027ac1b8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4e8>
1027ac188:     	mov	x23, #0x0               ; =0
1027ac18c:     	cbz	x10, 0x1027ac128 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
1027ac190:     	mov	x23, #0x0               ; =0
1027ac194:     	mov	x27, x25
1027ac198:     	add	x25, x25, #0x1b0
1027ac19c:     	mov	x19, x9
1027ac1a0:     	mov	x22, x8
1027ac1a4:     	mov	w24, #0x1               ; =1
1027ac1a8:     	ldr	w27, [x27, #0x1a8]
1027ac1ac:     	ldr	x8, [sp, #0x28]
1027ac1b0:     	cmp	x21, x8
1027ac1b4:     	b.ne	0x1027ac070 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
1027ac1b8:     	cbz	x24, 0x1027ac208 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x538>
1027ac1bc:     	cbz	x23, 0x1027ac1ec <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x51c>
1027ac1c0:     	ldr	x8, [sp, #0x20]
1027ac1c4:     	sub	x8, x8, x23
1027ac1c8:     	lsr	x8, x8, #4
1027ac1cc:     	mul	x8, x8, x14
1027ac1d0:     	cbz	x25, 0x1027ac200 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x530>
1027ac1d4:     	ldr	x9, [sp, #0x10]
1027ac1d8:     	sub	x9, x9, x25
1027ac1dc:     	lsr	x9, x9, #4
1027ac1e0:     	madd	x8, x9, x14, x8
1027ac1e4:     	cbz	w28, 0x1027ac250 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
1027ac1e8:     	b	0x1027ac210 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x540>
1027ac1ec:     	cbz	x25, 0x1027ac208 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x538>
1027ac1f0:     	ldr	x8, [sp, #0x10]
1027ac1f4:     	sub	x8, x8, x25
1027ac1f8:     	lsr	x8, x8, #4
1027ac1fc:     	mul	x8, x8, x14
1027ac200:     	cbz	w28, 0x1027ac250 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
1027ac204:     	b	0x1027ac210 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x540>
1027ac208:     	mov	x8, #0x0                ; =0
1027ac20c:     	cbz	w28, 0x1027ac250 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
1027ac210:     	cbz	x19, 0x1027ac23c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x56c>
1027ac214:     	ldr	x9, [sp, #0x8]
1027ac218:     	sub	x9, x9, x19
1027ac21c:     	lsr	x9, x9, #4
1027ac220:     	mul	x9, x9, x14
1027ac224:     	sub	x10, x20, x22
1027ac228:     	lsr	x10, x10, #4
1027ac22c:     	madd	x10, x10, x14, x9
1027ac230:     	cmp	x22, #0x0
1027ac234:     	csel	x9, x9, x10, eq
1027ac238:     	b	0x1027ac254 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x584>
1027ac23c:     	cbz	x22, 0x1027ac250 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
1027ac240:     	sub	x9, x20, x22
1027ac244:     	lsr	x9, x9, #4
1027ac248:     	mul	x9, x9, x14
1027ac24c:     	b	0x1027ac254 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x584>
1027ac250:     	mov	x9, #0x0                ; =0
1027ac254:     	add	x8, x8, x9
1027ac258:     	add	x0, sp, #0x28
1027ac25c:     	add	x2, x8, #0x1
1027ac260:     	mov	x1, x21
1027ac264:     	mov	w3, #0x4                ; =4
1027ac268:     	mov	w4, #0x4                ; =4
1027ac26c:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027ac270:     	ldr	x0, [sp, #0x30]
1027ac274:     	ldr	x12, [sp, #0x18]
1027ac278:     	mov	x14, #0xda13            ; =55827
1027ac27c:     	movk	x14, #0x684b, lsl #16
1027ac280:     	movk	x14, #0xa12f, lsl #32
1027ac284:     	movk	x14, #0x84bd, lsl #48
1027ac288:     	b	0x1027ac070 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
1027ac28c:     	ldur	q0, [sp, #0x28]
1027ac290:     	ldr	x9, [sp]
1027ac294:     	str	q0, [x9]
1027ac298:     	ldr	x8, [sp, #0x38]
1027ac29c:     	str	x8, [x9, #0x10]
1027ac2a0:     	ldp	x29, x30, [sp, #0x90]
1027ac2a4:     	ldp	x20, x19, [sp, #0x80]
1027ac2a8:     	ldp	x22, x21, [sp, #0x70]
1027ac2ac:     	ldp	x24, x23, [sp, #0x60]
1027ac2b0:     	ldp	x26, x25, [sp, #0x50]
1027ac2b4:     	ldp	x28, x27, [sp, #0x40]
1027ac2b8:     	add	sp, sp, #0xa0
1027ac2bc:     	ret
1027ac2c0:     	mov	w0, #0x4                ; =4
1027ac2c4:     	mov	x1, x21
1027ac2c8:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027ac2cc:     	mov	x19, x0
1027ac2d0:     	ldr	x8, [sp, #0x28]
1027ac2d4:     	cbz	x8, 0x1027ac2e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x618>
1027ac2d8:     	ldr	x0, [sp, #0x30]
1027ac2dc:     	lsl	x1, x8, #2
1027ac2e0:     	mov	w2, #0x4                ; =4
1027ac2e4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ac2e8:     	mov	x0, x19
1027ac2ec:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
