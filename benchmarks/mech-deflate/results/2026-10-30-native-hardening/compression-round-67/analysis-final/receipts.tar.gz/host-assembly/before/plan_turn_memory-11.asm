
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a04420 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_>:
102a04420:     	sub	sp, sp, #0x60
102a04424:     	stp	x24, x23, [sp, #0x20]
102a04428:     	stp	x22, x21, [sp, #0x30]
102a0442c:     	stp	x20, x19, [sp, #0x40]
102a04430:     	stp	x29, x30, [sp, #0x50]
102a04434:     	add	x29, sp, #0x50
102a04438:     	mov	x19, x8
102a0443c:     	ldp	x8, x21, [x0]
102a04440:     	cmp	x8, x21
102a04444:     	b.eq	0x102a044e4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xc4>
102a04448:     	ldr	x22, [x0, #0x10]
102a0444c:     	ldr	x9, [x22]
102a04450:     	cbz	x9, 0x102a044e4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xc4>
102a04454:     	ldr	x10, [x22, #0x8]
102a04458:     	add	x23, x8, #0x60
102a0445c:     	ldr	w11, [x8, #0x50]
102a04460:     	mov	x12, x10
102a04464:     	mov	x13, x9
102a04468:     	add	x15, x13, #0x8
102a0446c:     	ldrh	w16, [x13, #0x36]
102a04470:     	lsl	x17, x16, #2
102a04474:     	mov	x14, #-0x1              ; =-1
102a04478:     	cbz	x17, 0x102a044a8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x88>
102a0447c:     	ldr	w1, [x15], #0x4
102a04480:     	cmp	w11, w1
102a04484:     	cset	w1, hi
102a04488:     	csinv	w1, w1, wzr, hs
102a0448c:     	add	x14, x14, #0x1
102a04490:     	sub	x17, x17, #0x4
102a04494:     	and	w1, w1, #0xff
102a04498:     	cmp	w1, #0x1
102a0449c:     	b.eq	0x102a04478 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x58>
102a044a0:     	cbz	w1, 0x102a044d0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xb0>
102a044a4:     	b	0x102a044ac <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x8c>
102a044a8:     	mov	x14, x16
102a044ac:     	cbz	x12, 0x102a044c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xa0>
102a044b0:     	add	x13, x13, x14, lsl #3
102a044b4:     	ldr	x13, [x13, #0x38]
102a044b8:     	sub	x12, x12, #0x1
102a044bc:     	b	0x102a04468 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x48>
102a044c0:     	mov	x8, x23
102a044c4:     	cmp	x23, x21
102a044c8:     	b.ne	0x102a04458 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x38>
102a044cc:     	b	0x102a044e4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xc4>
102a044d0:     	str	x23, [x0]
102a044d4:     	ldr	x20, [x8, #0x10]
102a044d8:     	and	x8, x20, #0xff
102a044dc:     	cmp	x8, #0x8
102a044e0:     	b.ne	0x102a04508 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xe8>
102a044e4:     	mov	w8, #0x4                ; =4
102a044e8:     	stp	xzr, x8, [x19]
102a044ec:     	str	xzr, [x19, #0x10]
102a044f0:     	ldp	x29, x30, [sp, #0x50]
102a044f4:     	ldp	x20, x19, [sp, #0x40]
102a044f8:     	ldp	x22, x21, [sp, #0x30]
102a044fc:     	ldp	x24, x23, [sp, #0x20]
102a04500:     	add	sp, sp, #0x60
102a04504:     	ret
102a04508:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a0450c:     	mov	w0, #0x20               ; =32
102a04510:     	mov	w1, #0x4                ; =4
102a04514:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a04518:     	cbz	x0, 0x102a04630 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x210>
102a0451c:     	str	x20, [x0]
102a04520:     	mov	w8, #0x4                ; =4
102a04524:     	stp	x8, x0, [sp, #0x8]
102a04528:     	mov	w8, #0x1                ; =1
102a0452c:     	str	x8, [sp, #0x18]
102a04530:     	cmp	x23, x21
102a04534:     	b.eq	0x102a0461c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1fc>
102a04538:     	mov	w20, #0x1               ; =1
102a0453c:     	b	0x102a04558 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x138>
102a04540:     	ldr	x0, [sp, #0x10]
102a04544:     	str	x24, [x0, x20, lsl #3]
102a04548:     	add	x20, x20, #0x1
102a0454c:     	str	x20, [sp, #0x18]
102a04550:     	cmp	x23, x21
102a04554:     	b.eq	0x102a0461c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1fc>
102a04558:     	ldr	x8, [x22]
102a0455c:     	cbz	x8, 0x102a0461c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1fc>
102a04560:     	ldr	x9, [x22, #0x8]
102a04564:     	mov	x10, x23
102a04568:     	add	x23, x10, #0x60
102a0456c:     	ldr	w11, [x10, #0x50]
102a04570:     	mov	x12, x9
102a04574:     	mov	x13, x8
102a04578:     	add	x15, x13, #0x8
102a0457c:     	ldrh	w16, [x13, #0x36]
102a04580:     	lsl	x17, x16, #2
102a04584:     	mov	x14, #-0x1              ; =-1
102a04588:     	cbz	x17, 0x102a045bc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x19c>
102a0458c:     	ldr	w1, [x15], #0x4
102a04590:     	cmp	w11, w1
102a04594:     	cset	w1, hi
102a04598:     	csinv	w1, w1, wzr, hs
102a0459c:     	add	x14, x14, #0x1
102a045a0:     	sub	x17, x17, #0x4
102a045a4:     	and	w1, w1, #0xff
102a045a8:     	cmp	w1, #0x1
102a045ac:     	b.eq	0x102a04588 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x168>
102a045b0:     	cbz	w1, 0x102a045e4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1c4>
102a045b4:     	cbnz	x12, 0x102a045c4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1a4>
102a045b8:     	b	0x102a045d4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1b4>
102a045bc:     	mov	x14, x16
102a045c0:     	cbz	x12, 0x102a045d4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1b4>
102a045c4:     	add	x13, x13, x14, lsl #3
102a045c8:     	ldr	x13, [x13, #0x38]
102a045cc:     	sub	x12, x12, #0x1
102a045d0:     	b	0x102a04578 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x158>
102a045d4:     	mov	x10, x23
102a045d8:     	cmp	x23, x21
102a045dc:     	b.ne	0x102a04568 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x148>
102a045e0:     	b	0x102a0461c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1fc>
102a045e4:     	ldr	x24, [x10, #0x10]
102a045e8:     	and	x8, x24, #0xff
102a045ec:     	cmp	x8, #0x8
102a045f0:     	b.eq	0x102a0461c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1fc>
102a045f4:     	ldr	x8, [sp, #0x8]
102a045f8:     	cmp	x20, x8
102a045fc:     	b.ne	0x102a04544 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x124>
102a04600:     	add	x0, sp, #0x8
102a04604:     	mov	x1, x20
102a04608:     	mov	w2, #0x1                ; =1
102a0460c:     	mov	w3, #0x4                ; =4
102a04610:     	mov	w4, #0x8                ; =8
102a04614:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a04618:     	b	0x102a04540 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x120>
102a0461c:     	ldur	q0, [sp, #0x8]
102a04620:     	str	q0, [x19]
102a04624:     	ldr	x8, [sp, #0x18]
102a04628:     	str	x8, [x19, #0x10]
102a0462c:     	b	0x102a044f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xd0>
102a04630:     	mov	w0, #0x4                ; =4
102a04634:     	mov	w1, #0x20               ; =32
102a04638:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a0463c:     	mov	x19, x0
102a04640:     	ldr	x8, [sp, #0x8]
102a04644:     	cbz	x8, 0x102a04658 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x238>
102a04648:     	ldr	x0, [sp, #0x10]
102a0464c:     	lsl	x1, x8, #3
102a04650:     	mov	w2, #0x4                ; =4
102a04654:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a04658:     	mov	x0, x19
102a0465c:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
