
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010235af60 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_>:
10235af60:     	sub	sp, sp, #0xb0
10235af64:     	stp	x28, x27, [sp, #0x50]
10235af68:     	stp	x26, x25, [sp, #0x60]
10235af6c:     	stp	x24, x23, [sp, #0x70]
10235af70:     	stp	x22, x21, [sp, #0x80]
10235af74:     	stp	x20, x19, [sp, #0x90]
10235af78:     	stp	x29, x30, [sp, #0xa0]
10235af7c:     	add	x29, sp, #0xa0
10235af80:     	stp	x6, x3, [sp]
10235af84:     	mov	x21, x2
10235af88:     	mov	x27, x1
10235af8c:     	mov	x22, x0
10235af90:     	cmp	x1, #0x21
10235af94:     	b.hs	0x10235afb0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x50>
10235af98:     	mov	x0, x22
10235af9c:     	mov	x1, x27
10235afa0:     	mov	x2, x21
10235afa4:     	ldp	x4, x3, [sp]
10235afa8:     	bl	0x1028f4ac4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1A_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB3L_11collections5btree3mapINtB4y_8BTreeMapB1t_B2L_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB5B_8adapters10filter_map9FilterMapINtB4y_4IterTNtNtB1A_17semantic_identity6NodeIdB1u_tEB2L_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB8d_>
10235afac:     	b	0x10235b334 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x3d4>
10235afb0:     	mov	x25, x5
10235afb4:     	mov	x23, x4
10235afb8:     	mov	w28, #0xff              ; =255
10235afbc:     	mov	x24, x27
10235afc0:     	cbz	w23, 0x10235b31c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x3bc>
10235afc4:     	lsr	x3, x24, #3
10235afc8:     	add	x1, x22, x3, lsl #8
10235afcc:     	mov	w8, #0x1c0              ; =448
10235afd0:     	madd	x2, x3, x8, x22
10235afd4:     	cmp	x24, #0x40
10235afd8:     	b.hs	0x10235b064 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x104>
10235afdc:     	ldrb	w12, [x22]
10235afe0:     	ldrh	w13, [x22, #0x2]
10235afe4:     	ldrb	w8, [x2]
10235afe8:     	ldrh	w9, [x2, #0x2]
10235afec:     	cmp	w13, w9
10235aff0:     	cset	w14, lo
10235aff4:     	subs	w10, w12, w8
10235aff8:     	bics	wzr, w28, w10
10235affc:     	cset	w15, eq
10235b000:     	ldrb	w10, [x1]
10235b004:     	ldrh	w11, [x1, #0x2]
10235b008:     	cmp	w12, w8
10235b00c:     	csel	w14, w14, w15, eq
10235b010:     	cmp	w13, w11
10235b014:     	cset	w13, lo
10235b018:     	subs	w15, w12, w10
10235b01c:     	bics	wzr, w28, w15
10235b020:     	cset	w15, eq
10235b024:     	cmp	w12, w10
10235b028:     	csel	w12, w13, w15, eq
10235b02c:     	mov	x26, x22
10235b030:     	cmp	w12, w14
10235b034:     	b.ne	0x10235b070 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x110>
10235b038:     	cmp	w11, w9
10235b03c:     	cset	w9, lo
10235b040:     	subs	w11, w10, w8
10235b044:     	cmn	w11, #0x1
10235b048:     	cset	w11, eq
10235b04c:     	cmp	w10, w8
10235b050:     	csel	w8, w9, w11, eq
10235b054:     	eor	w8, w12, w8
10235b058:     	cmp	w8, #0x0
10235b05c:     	csel	x26, x2, x1, ne
10235b060:     	b	0x10235b070 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x110>
10235b064:     	mov	x0, x22
10235b068:     	bl	0x102349964 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7P_>
10235b06c:     	mov	x26, x0
10235b070:     	sub	w23, w23, #0x1
10235b074:     	sub	x8, x26, x22
10235b078:     	lsr	x20, x8, #6
10235b07c:     	ldp	q0, q1, [x26]
10235b080:     	stp	q0, q1, [sp, #0x10]
10235b084:     	ldp	q0, q1, [x26, #0x20]
10235b088:     	stp	q0, q1, [sp, #0x30]
10235b08c:     	add	x19, x21, x24, lsl #6
10235b090:     	cbz	x25, 0x10235b0c8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x168>
10235b094:     	ldrb	w8, [x25]
10235b098:     	ldrh	w9, [x25, #0x2]
10235b09c:     	ldrb	w10, [x26]
10235b0a0:     	ldrh	w11, [x26, #0x2]
10235b0a4:     	cmp	w9, w11
10235b0a8:     	cset	w9, lo
10235b0ac:     	subs	w11, w8, w10
10235b0b0:     	bics	wzr, w28, w11
10235b0b4:     	cset	w11, eq
10235b0b8:     	cmp	w8, w10
10235b0bc:     	csel	w8, w9, w11, eq
10235b0c0:     	cmp	w8, #0x1
10235b0c4:     	b.ne	0x10235b200 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x2a0>
10235b0c8:     	ldr	x8, [sp, #0x8]
10235b0cc:     	cmp	x8, x24
10235b0d0:     	b.lo	0x10235b35c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x3fc>
10235b0d4:     	mov	x27, #0x0               ; =0
10235b0d8:     	mov	x8, x22
10235b0dc:     	mov	x9, x19
10235b0e0:     	mov	x10, x20
10235b0e4:     	add	x11, x22, x20, lsl #6
10235b0e8:     	cmp	x22, x11
10235b0ec:     	b.hs	0x10235b14c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x1ec>
10235b0f0:     	ldrb	w12, [x8]
10235b0f4:     	ldrh	w13, [x8, #0x2]
10235b0f8:     	ldrb	w14, [x26]
10235b0fc:     	ldrh	w15, [x26, #0x2]
10235b100:     	cmp	w13, w15
10235b104:     	cset	w13, lo
10235b108:     	subs	w15, w12, w14
10235b10c:     	bics	wzr, w28, w15
10235b110:     	cset	w15, eq
10235b114:     	cmp	w12, w14
10235b118:     	csel	w12, w13, w15, eq
10235b11c:     	sub	x9, x9, #0x40
10235b120:     	cmp	w12, #0x0
10235b124:     	csel	x13, x21, x9, ne
10235b128:     	add	x13, x13, x27, lsl #6
10235b12c:     	ldp	q0, q1, [x8]
10235b130:     	ldp	q2, q3, [x8, #0x20]
10235b134:     	stp	q2, q3, [x13, #0x20]
10235b138:     	stp	q0, q1, [x13]
10235b13c:     	add	x27, x27, x12
10235b140:     	add	x8, x8, #0x40
10235b144:     	cmp	x8, x11
10235b148:     	b.lo	0x10235b0f0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x190>
10235b14c:     	cmp	x10, x24
10235b150:     	b.eq	0x10235b184 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x224>
10235b154:     	sub	x9, x9, #0x40
10235b158:     	add	x10, x9, x27, lsl #6
10235b15c:     	ldp	q0, q1, [x8]
10235b160:     	stp	q0, q1, [x10]
10235b164:     	ldp	q0, q1, [x8, #0x20]
10235b168:     	stp	q0, q1, [x10, #0x20]
10235b16c:     	add	x8, x8, #0x40
10235b170:     	mov	x10, x24
10235b174:     	add	x11, x22, x24, lsl #6
10235b178:     	cmp	x8, x11
10235b17c:     	b.lo	0x10235b0f0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x190>
10235b180:     	b	0x10235b14c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x1ec>
10235b184:     	lsl	x2, x27, #6
10235b188:     	mov	x0, x22
10235b18c:     	mov	x1, x21
10235b190:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
10235b194:     	add	x0, x22, x27, lsl #6
10235b198:     	subs	x1, x24, x27
10235b19c:     	b.eq	0x10235b1d0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x270>
10235b1a0:     	sub	x8, x21, #0x40
10235b1a4:     	add	x8, x8, x24, lsl #6
10235b1a8:     	mov	x9, x1
10235b1ac:     	mov	x10, x0
10235b1b0:     	ldp	q0, q1, [x8]
10235b1b4:     	stp	q0, q1, [x10]
10235b1b8:     	ldp	q0, q1, [x8, #0x20]
10235b1bc:     	stp	q0, q1, [x10, #0x20]
10235b1c0:     	add	x10, x10, #0x40
10235b1c4:     	sub	x8, x8, #0x40
10235b1c8:     	subs	x9, x9, #0x1
10235b1cc:     	b.ne	0x10235b1b0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x250>
10235b1d0:     	cbz	x27, 0x10235b200 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x2a0>
10235b1d4:     	cmp	x24, x27
10235b1d8:     	b.lo	0x10235b360 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x400>
10235b1dc:     	add	x5, sp, #0x10
10235b1e0:     	mov	x2, x21
10235b1e4:     	ldp	x6, x3, [sp]
10235b1e8:     	mov	x4, x23
10235b1ec:     	bl	0x10235af60 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_>
10235b1f0:     	mov	x24, x27
10235b1f4:     	cmp	x27, #0x21
10235b1f8:     	b.hs	0x10235afc0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x60>
10235b1fc:     	b	0x10235af98 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x38>
10235b200:     	ldr	x8, [sp, #0x8]
10235b204:     	cmp	x8, x24
10235b208:     	b.lo	0x10235b35c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x3fc>
10235b20c:     	mov	x25, #0x0               ; =0
10235b210:     	mov	x8, x22
10235b214:     	add	x9, x22, x20, lsl #6
10235b218:     	cmp	x22, x9
10235b21c:     	b.hs	0x10235b27c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x31c>
10235b220:     	ldrb	w10, [x8]
10235b224:     	ldrh	w11, [x8, #0x2]
10235b228:     	ldrb	w12, [x26]
10235b22c:     	ldrh	w13, [x26, #0x2]
10235b230:     	cmp	w13, w11
10235b234:     	cset	w11, hs
10235b238:     	subs	w13, w12, w10
10235b23c:     	bics	wzr, w28, w13
10235b240:     	cset	w13, ne
10235b244:     	cmp	w12, w10
10235b248:     	csel	w10, w11, w13, eq
10235b24c:     	sub	x19, x19, #0x40
10235b250:     	cmp	w10, #0x0
10235b254:     	csel	x11, x21, x19, ne
10235b258:     	add	x11, x11, x25, lsl #6
10235b25c:     	ldp	q0, q1, [x8]
10235b260:     	ldp	q2, q3, [x8, #0x20]
10235b264:     	stp	q2, q3, [x11, #0x20]
10235b268:     	stp	q0, q1, [x11]
10235b26c:     	add	x25, x25, x10
10235b270:     	add	x8, x8, #0x40
10235b274:     	cmp	x8, x9
10235b278:     	b.lo	0x10235b220 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x2c0>
10235b27c:     	cmp	x20, x24
10235b280:     	b.eq	0x10235b2b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x358>
10235b284:     	sub	x19, x19, #0x40
10235b288:     	add	x9, x21, x25, lsl #6
10235b28c:     	ldp	q0, q1, [x8]
10235b290:     	ldp	q2, q3, [x8, #0x20]
10235b294:     	stp	q2, q3, [x9, #0x20]
10235b298:     	stp	q0, q1, [x9]
10235b29c:     	add	x25, x25, #0x1
10235b2a0:     	add	x8, x8, #0x40
10235b2a4:     	mov	x20, x24
10235b2a8:     	add	x9, x22, x24, lsl #6
10235b2ac:     	cmp	x8, x9
10235b2b0:     	b.lo	0x10235b220 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x2c0>
10235b2b4:     	b	0x10235b27c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x31c>
10235b2b8:     	lsl	x2, x25, #6
10235b2bc:     	mov	x0, x22
10235b2c0:     	mov	x1, x21
10235b2c4:     	bl	0x103a05290 <dyld_stub_binder+0x103a05290>
10235b2c8:     	subs	x27, x24, x25
10235b2cc:     	b.eq	0x10235b354 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x3f4>
10235b2d0:     	add	x22, x22, x25, lsl #6
10235b2d4:     	sub	x8, x21, #0x40
10235b2d8:     	add	x8, x8, x24, lsl #6
10235b2dc:     	mov	x9, x27
10235b2e0:     	mov	x10, x22
10235b2e4:     	ldp	q0, q1, [x8]
10235b2e8:     	stp	q0, q1, [x10]
10235b2ec:     	ldp	q0, q1, [x8, #0x20]
10235b2f0:     	stp	q0, q1, [x10, #0x20]
10235b2f4:     	add	x10, x10, #0x40
10235b2f8:     	sub	x8, x8, #0x40
10235b2fc:     	subs	x9, x9, #0x1
10235b300:     	b.ne	0x10235b2e4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x384>
10235b304:     	cmp	x24, x25
10235b308:     	b.lo	0x10235b378 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x418>
10235b30c:     	mov	x25, #0x0               ; =0
10235b310:     	cmp	x27, #0x21
10235b314:     	b.hs	0x10235afbc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x5c>
10235b318:     	b	0x10235af98 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x38>
10235b31c:     	mov	x0, x22
10235b320:     	mov	x1, x24
10235b324:     	mov	x2, x21
10235b328:     	ldp	x5, x3, [sp]
10235b32c:     	mov	w4, #0x1                ; =1
10235b330:     	bl	0x1027dcd58 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_>
10235b334:     	ldp	x29, x30, [sp, #0xa0]
10235b338:     	ldp	x20, x19, [sp, #0x90]
10235b33c:     	ldp	x22, x21, [sp, #0x80]
10235b340:     	ldp	x24, x23, [sp, #0x70]
10235b344:     	ldp	x26, x25, [sp, #0x60]
10235b348:     	ldp	x28, x27, [sp, #0x50]
10235b34c:     	add	sp, sp, #0xb0
10235b350:     	ret
10235b354:     	add	x22, x22, x24, lsl #6
10235b358:     	b	0x10235af98 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7Q_+0x38>
10235b35c:     	brk	#0x1
10235b360:     	adrp	x0, 0x107577000 <_anon.bacf143378b3839dd1972d7136a97b6c.2706+0x7>
10235b364:     	add	x0, x0, #0x62d
10235b368:     	adrp	x2, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10235b36c:     	add	x2, x2, #0x278
10235b370:     	mov	w1, #0x13               ; =19
10235b374:     	bl	0x103a03e48 <__RNvNtCsgDHHaSskbIF_4core9panicking9panic_fmt>
10235b378:     	adrp	x3, 0x108032000 <_anon.a23694c7749b0a7a16b728b605d1204f.64+0x10>
10235b37c:     	add	x3, x3, #0x290
10235b380:     	mov	x0, x25
10235b384:     	mov	x1, x24
10235b388:     	mov	x2, x24
10235b38c:     	bl	0x103a03e8c <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
