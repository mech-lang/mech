
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001029e25d8 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>:
1029e25d8:     	stp	x26, x25, [sp, #-0x50]!
1029e25dc:     	stp	x24, x23, [sp, #0x10]
1029e25e0:     	stp	x22, x21, [sp, #0x20]
1029e25e4:     	stp	x20, x19, [sp, #0x30]
1029e25e8:     	stp	x29, x30, [sp, #0x40]
1029e25ec:     	add	x29, sp, #0x40
1029e25f0:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
1029e25f4:     	str	xzr, [sp]
1029e25f8:     	mov	x19, x2
1029e25fc:     	sub	x8, x1, x1, lsr #1
1029e2600:     	mov	w9, #0xe848             ; =59464
1029e2604:     	movk	w9, #0x1, lsl #16
1029e2608:     	cmp	x1, x9
1029e260c:     	csel	x9, x1, x9, lo
1029e2610:     	cmp	x9, x8
1029e2614:     	csel	x24, x9, x8, hi
1029e2618:     	mov	w9, #0x30               ; =48
1029e261c:     	cmp	x24, #0x30
1029e2620:     	csel	x23, x24, x9, hi
1029e2624:     	cmp	x24, #0x41
1029e2628:     	b.lo	0x1029e267c <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xa4>
1029e262c:     	mov	x22, #0x0               ; =0
1029e2630:     	lsl	x21, x23, #6
1029e2634:     	lsr	x8, x8, #58
1029e2638:     	cbnz	x8, 0x1029e26cc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1029e263c:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1029e2640:     	cmp	x21, x8
1029e2644:     	b.hi	0x1029e26cc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1029e2648:     	mov	x20, x1
1029e264c:     	mov	x25, x0
1029e2650:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1029e2654:     	mov	w22, #0x8               ; =8
1029e2658:     	mov	x0, x21
1029e265c:     	mov	w1, #0x8                ; =8
1029e2660:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1029e2664:     	mov	x1, x20
1029e2668:     	mov	x20, x0
1029e266c:     	cbz	x0, 0x1029e26cc <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xf4>
1029e2670:     	mov	x0, x25
1029e2674:     	mov	x3, x23
1029e2678:     	b	0x1029e2684 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xac>
1029e267c:     	mov	x20, sp
1029e2680:     	mov	w3, #0x40               ; =64
1029e2684:     	cmp	x1, #0x41
1029e2688:     	cset	w4, lo
1029e268c:     	mov	x2, x20
1029e2690:     	mov	x5, x19
1029e2694:     	bl	0x1027dcd58 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7D_>
1029e2698:     	cmp	x24, #0x40
1029e269c:     	b.ls	0x1029e26b0 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0xd8>
1029e26a0:     	lsl	x1, x23, #6
1029e26a4:     	mov	x0, x20
1029e26a8:     	mov	w2, #0x8                ; =8
1029e26ac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029e26b0:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
1029e26b4:     	ldp	x29, x30, [sp, #0x40]
1029e26b8:     	ldp	x20, x19, [sp, #0x30]
1029e26bc:     	ldp	x22, x21, [sp, #0x20]
1029e26c0:     	ldp	x24, x23, [sp, #0x10]
1029e26c4:     	ldp	x26, x25, [sp], #0x50
1029e26c8:     	ret
1029e26cc:     	mov	x0, x22
1029e26d0:     	mov	x1, x21
1029e26d4:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1029e26d8:     	mov	x19, x0
1029e26dc:     	cmp	x24, #0x40
1029e26e0:     	b.ls	0x1029e26f4 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_+0x11c>
1029e26e4:     	lsl	x1, x23, #6
1029e26e8:     	mov	x0, x20
1029e26ec:     	mov	w2, #0x8                ; =8
1029e26f0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1029e26f4:     	mov	x0, x19
1029e26f8:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
