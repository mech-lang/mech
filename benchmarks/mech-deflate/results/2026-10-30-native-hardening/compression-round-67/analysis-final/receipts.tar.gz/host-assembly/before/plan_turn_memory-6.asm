
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001028ee808 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_>:
1028ee808:     	sub	x8, x2, #0x1
1028ee80c:     	cmp	x8, x1
1028ee810:     	b.hs	0x1028ee91c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x114>
1028ee814:     	cmp	x2, x1
1028ee818:     	b.eq	0x1028ee918 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x110>
1028ee81c:     	sub	sp, sp, #0x40
1028ee820:     	add	x8, x0, x1, lsl #6
1028ee824:     	lsl	x9, x2, #6
1028ee828:     	add	x10, x0, x9
1028ee82c:     	mov	w11, #0xff              ; =255
1028ee830:     	b	0x1028ee870 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x68>
1028ee834:     	mov	x15, x0
1028ee838:     	strb	w13, [x15]
1028ee83c:     	strb	w14, [x15, #0x1]
1028ee840:     	strh	w12, [x15, #0x2]
1028ee844:     	ldp	q0, q1, [sp]
1028ee848:     	stur	q0, [x15, #0x4]
1028ee84c:     	stur	q1, [x15, #0x14]
1028ee850:     	ldr	q0, [sp, #0x20]
1028ee854:     	stur	q0, [x15, #0x24]
1028ee858:     	ldur	q0, [sp, #0x2c]
1028ee85c:     	str	q0, [x15, #0x30]
1028ee860:     	add	x10, x10, #0x40
1028ee864:     	add	x9, x9, #0x40
1028ee868:     	cmp	x10, x8
1028ee86c:     	b.eq	0x1028ee914 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x10c>
1028ee870:     	ldrb	w13, [x10]
1028ee874:     	ldrh	w12, [x10, #0x2]
1028ee878:     	ldurb	w14, [x10, #-0x40]
1028ee87c:     	ldurh	w15, [x10, #-0x3e]
1028ee880:     	cmp	w12, w15
1028ee884:     	cset	w15, lo
1028ee888:     	subs	w16, w13, w14
1028ee88c:     	bics	wzr, w11, w16
1028ee890:     	cset	w16, eq
1028ee894:     	cmp	w13, w14
1028ee898:     	csel	w14, w15, w16, eq
1028ee89c:     	cmp	w14, #0x1
1028ee8a0:     	b.ne	0x1028ee860 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x58>
1028ee8a4:     	ldrb	w14, [x10, #0x1]
1028ee8a8:     	ldur	q0, [x10, #0x4]
1028ee8ac:     	ldur	q1, [x10, #0x14]
1028ee8b0:     	stp	q0, q1, [sp]
1028ee8b4:     	ldur	q0, [x10, #0x24]
1028ee8b8:     	str	q0, [sp, #0x20]
1028ee8bc:     	ldr	q0, [x10, #0x30]
1028ee8c0:     	stur	q0, [sp, #0x2c]
1028ee8c4:     	mov	x15, x9
1028ee8c8:     	add	x16, x0, x15
1028ee8cc:     	ldp	q0, q1, [x16, #-0x40]
1028ee8d0:     	stp	q0, q1, [x16]
1028ee8d4:     	ldp	q0, q1, [x16, #-0x20]
1028ee8d8:     	stp	q0, q1, [x16, #0x20]
1028ee8dc:     	subs	x15, x15, #0x40
1028ee8e0:     	b.eq	0x1028ee834 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x2c>
1028ee8e4:     	ldurb	w17, [x16, #-0x80]
1028ee8e8:     	ldurh	w16, [x16, #-0x7e]
1028ee8ec:     	cmp	w12, w16
1028ee8f0:     	cset	w16, lo
1028ee8f4:     	subs	w1, w13, w17
1028ee8f8:     	bics	wzr, w11, w1
1028ee8fc:     	cset	w1, eq
1028ee900:     	cmp	w13, w17
1028ee904:     	csel	w16, w16, w1, eq
1028ee908:     	tbnz	w16, #0x0, 0x1028ee8c8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0xc0>
1028ee90c:     	add	x15, x0, x15
1028ee910:     	b	0x1028ee838 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_+0x30>
1028ee914:     	add	sp, sp, #0x40
1028ee918:     	ret
1028ee91c:     	brk	#0x1
