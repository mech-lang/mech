
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a0c878 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_>:
102a0c878:     	sub	sp, sp, #0x150
102a0c87c:     	stp	x28, x27, [sp, #0xf0]
102a0c880:     	stp	x26, x25, [sp, #0x100]
102a0c884:     	stp	x24, x23, [sp, #0x110]
102a0c888:     	stp	x22, x21, [sp, #0x120]
102a0c88c:     	stp	x20, x19, [sp, #0x130]
102a0c890:     	stp	x29, x30, [sp, #0x140]
102a0c894:     	add	x29, sp, #0x140
102a0c898:     	mov	x21, x0
102a0c89c:     	mov	x19, x8
102a0c8a0:     	bl	0x10257aacc <__RNvXsk_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB5_4IterTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB18_18operation_contract10validation13PortDirectiontENtNtNtB18_11memory_plan5model22CurrentMemoryFootprintENtNtNtNtCsgDHHaSskbIF_4core4iter6traits8iterator8Iterator4nextCs1qJAwyMG1lC_11mech_engine>
102a0c8a4:     	cbz	x0, 0x102a0c8f4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x7c>
102a0c8a8:     	add	x24, sp, #0x60
102a0c8ac:     	sub	x23, x29, #0x9c
102a0c8b0:     	ldr	x8, [x21, #0x48]
102a0c8b4:     	ldr	w9, [x0]
102a0c8b8:     	ldrb	w20, [x0, #0x4]
102a0c8bc:     	ldrh	w22, [x0, #0x6]
102a0c8c0:     	ldr	w8, [x8]
102a0c8c4:     	ldp	q0, q1, [x1]
102a0c8c8:     	stur	q0, [x23, #0x4]
102a0c8cc:     	stur	q1, [x23, #0x14]
102a0c8d0:     	ldr	q0, [x1, #0x20]
102a0c8d4:     	stur	q0, [x23, #0x24]
102a0c8d8:     	ldr	x10, [x1, #0x30]
102a0c8dc:     	stur	x10, [x23, #0x34]
102a0c8e0:     	cmp	w9, w8
102a0c8e4:     	b.eq	0x102a0c904 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x8c>
102a0c8e8:     	mov	x0, x21
102a0c8ec:     	bl	0x10257aacc <__RNvXsk_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB5_4IterTNtNtCskIfnrfrMWVM_9mech_core17semantic_identity6NodeIdNtNtNtB18_18operation_contract10validation13PortDirectiontENtNtNtB18_11memory_plan5model22CurrentMemoryFootprintENtNtNtNtCsgDHHaSskbIF_4core4iter6traits8iterator8Iterator4nextCs1qJAwyMG1lC_11mech_engine>
102a0c8f0:     	cbnz	x0, 0x102a0c8b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x38>
102a0c8f4:     	mov	w8, #0x8                ; =8
102a0c8f8:     	stp	xzr, x8, [x19]
102a0c8fc:     	str	xzr, [x19, #0x10]
102a0c900:     	b	0x102a0cafc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x284>
102a0c904:     	ldur	q0, [x24, #0x44]
102a0c908:     	ldur	q1, [x24, #0x54]
102a0c90c:     	stp	q0, q1, [sp, #0x20]
102a0c910:     	ldur	q0, [x24, #0x64]
102a0c914:     	str	q0, [sp, #0x40]
102a0c918:     	ldur	q0, [x24, #0x70]
102a0c91c:     	stur	q0, [sp, #0x4c]
102a0c920:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a0c924:     	mov	w0, #0x100              ; =256
102a0c928:     	mov	w1, #0x8                ; =8
102a0c92c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a0c930:     	cbz	x0, 0x102a0cb3c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2c4>
102a0c934:     	ldp	q0, q1, [sp, #0x20]
102a0c938:     	stur	q0, [x0, #0x4]
102a0c93c:     	strb	w20, [x0]
102a0c940:     	strh	w22, [x0, #0x2]
102a0c944:     	stur	q1, [x0, #0x14]
102a0c948:     	ldr	q0, [sp, #0x40]
102a0c94c:     	stur	q0, [x0, #0x24]
102a0c950:     	ldur	q0, [sp, #0x4c]
102a0c954:     	str	q0, [x0, #0x30]
102a0c958:     	mov	w8, #0x4                ; =4
102a0c95c:     	stp	x8, x0, [sp, #0x8]
102a0c960:     	mov	w8, #0x1                ; =1
102a0c964:     	str	x8, [sp, #0x18]
102a0c968:     	ldr	x23, [x21, #0x40]
102a0c96c:     	cbz	x23, 0x102a0caec <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x274>
102a0c970:     	ldp	x9, x26, [x21]
102a0c974:     	ldp	x8, x27, [x21, #0x10]
102a0c978:     	sub	x24, x29, #0x9c
102a0c97c:     	mov	w20, #0x1               ; =1
102a0c980:     	mov	w25, #0x38              ; =56
102a0c984:     	ldr	x21, [x21, #0x48]
102a0c988:     	tbz	w9, #0x0, 0x102a0cb2c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2b4>
102a0c98c:     	cbz	x26, 0x102a0c9a8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x130>
102a0c990:     	ldrh	w9, [x26, #0x2ca]
102a0c994:     	cmp	x27, x9
102a0c998:     	b.hs	0x102a0c9cc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x154>
102a0c99c:     	mov	x9, x26
102a0c9a0:     	mov	x10, x27
102a0c9a4:     	b	0x102a0c9ec <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x174>
102a0c9a8:     	mov	x26, x8
102a0c9ac:     	cbz	x27, 0x102a0c9bc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x144>
102a0c9b0:     	ldr	x26, [x26, #0x2d0]
102a0c9b4:     	subs	x27, x27, #0x1
102a0c9b8:     	b.ne	0x102a0c9b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x138>
102a0c9bc:     	mov	x8, #0x0                ; =0
102a0c9c0:     	ldrh	w9, [x26, #0x2ca]
102a0c9c4:     	cmp	x27, x9
102a0c9c8:     	b.lo	0x102a0c99c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x124>
102a0c9cc:     	ldr	x9, [x26]
102a0c9d0:     	cbz	x9, 0x102a0cb1c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2a4>
102a0c9d4:     	add	x8, x8, #0x1
102a0c9d8:     	ldrh	w10, [x26, #0x2c8]
102a0c9dc:     	ldrh	w11, [x9, #0x2ca]
102a0c9e0:     	mov	x26, x9
102a0c9e4:     	cmp	w10, w11
102a0c9e8:     	b.hs	0x102a0c9cc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x154>
102a0c9ec:     	add	x11, x9, x10, lsl #3
102a0c9f0:     	cbz	x8, 0x102a0ca10 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x198>
102a0c9f4:     	add	x12, x11, #0x2d8
102a0c9f8:     	ldr	x26, [x12]
102a0c9fc:     	add	x12, x26, #0x2d0
102a0ca00:     	subs	x8, x8, #0x1
102a0ca04:     	b.ne	0x102a0c9f8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x180>
102a0ca08:     	mov	x27, #0x0               ; =0
102a0ca0c:     	b	0x102a0ca18 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x1a0>
102a0ca10:     	add	x27, x10, #0x1
102a0ca14:     	mov	x26, x9
102a0ca18:     	sub	x23, x23, #0x1
102a0ca1c:     	ldr	w8, [x11, #0x8]
102a0ca20:     	ldrb	w28, [x11, #0xc]
102a0ca24:     	madd	x9, x10, x25, x9
102a0ca28:     	ldrh	w22, [x11, #0xe]
102a0ca2c:     	ldr	w10, [x21]
102a0ca30:     	ldp	q1, q0, [x9, #0x70]
102a0ca34:     	ldr	x11, [x9, #0x90]
102a0ca38:     	ldr	q2, [x9, #0x60]
102a0ca3c:     	stur	q2, [x24, #0x4]
102a0ca40:     	stur	x11, [x24, #0x34]
102a0ca44:     	stur	q0, [x24, #0x24]
102a0ca48:     	stur	q1, [x24, #0x14]
102a0ca4c:     	cmp	w8, w10
102a0ca50:     	b.eq	0x102a0ca64 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x1ec>
102a0ca54:     	mov	x8, #0x0                ; =0
102a0ca58:     	mov	w9, #0x1                ; =1
102a0ca5c:     	cbnz	x23, 0x102a0c988 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x110>
102a0ca60:     	b	0x102a0caec <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x274>
102a0ca64:     	add	x8, sp, #0x60
102a0ca68:     	ldur	q0, [x8, #0x44]
102a0ca6c:     	ldur	q1, [x8, #0x54]
102a0ca70:     	stp	q0, q1, [sp, #0x60]
102a0ca74:     	ldur	q0, [x8, #0x64]
102a0ca78:     	str	q0, [sp, #0x80]
102a0ca7c:     	ldur	q0, [x8, #0x70]
102a0ca80:     	stur	q0, [x8, #0x2c]
102a0ca84:     	ldr	x8, [sp, #0x8]
102a0ca88:     	cmp	x20, x8
102a0ca8c:     	b.ne	0x102a0caac <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x234>
102a0ca90:     	add	x0, sp, #0x8
102a0ca94:     	mov	x1, x20
102a0ca98:     	mov	w2, #0x1                ; =1
102a0ca9c:     	mov	w3, #0x8                ; =8
102a0caa0:     	mov	w4, #0x40               ; =64
102a0caa4:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a0caa8:     	ldr	x0, [sp, #0x10]
102a0caac:     	mov	x8, #0x0                ; =0
102a0cab0:     	add	x9, x0, x20, lsl #6
102a0cab4:     	strb	w28, [x9]
102a0cab8:     	strh	w22, [x9, #0x2]
102a0cabc:     	ldp	q2, q0, [sp, #0x70]
102a0cac0:     	add	x10, sp, #0x60
102a0cac4:     	ldur	q1, [x10, #0x2c]
102a0cac8:     	ldr	q3, [sp, #0x60]
102a0cacc:     	stur	q3, [x9, #0x4]
102a0cad0:     	str	q1, [x9, #0x30]
102a0cad4:     	stur	q0, [x9, #0x24]
102a0cad8:     	stur	q2, [x9, #0x14]
102a0cadc:     	add	x20, x20, #0x1
102a0cae0:     	str	x20, [sp, #0x18]
102a0cae4:     	mov	w9, #0x1                ; =1
102a0cae8:     	cbnz	x23, 0x102a0c988 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x110>
102a0caec:     	ldur	q0, [sp, #0x8]
102a0caf0:     	str	q0, [x19]
102a0caf4:     	ldr	x8, [sp, #0x18]
102a0caf8:     	str	x8, [x19, #0x10]
102a0cafc:     	ldp	x29, x30, [sp, #0x140]
102a0cb00:     	ldp	x20, x19, [sp, #0x130]
102a0cb04:     	ldp	x22, x21, [sp, #0x120]
102a0cb08:     	ldp	x24, x23, [sp, #0x110]
102a0cb0c:     	ldp	x26, x25, [sp, #0x100]
102a0cb10:     	ldp	x28, x27, [sp, #0xf0]
102a0cb14:     	add	sp, sp, #0x150
102a0cb18:     	ret
102a0cb1c:     	adrp	x0, 0x108034000 <_anon.90ab247f8e401a0c0ede3937b6a9a099.882+0x138>
102a0cb20:     	add	x0, x0, #0xc18
102a0cb24:     	bl	0x103a03c3c <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
102a0cb28:     	b	0x102a0cb38 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2c0>
102a0cb2c:     	adrp	x0, 0x108035000 <_anon.2314c7dda7e7207dbb1e6612b9b2047f.264+0x340>
102a0cb30:     	add	x0, x0, #0x460
102a0cb34:     	bl	0x103a03c3c <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
102a0cb38:     	brk	#0x1
102a0cb3c:     	mov	w0, #0x8                ; =8
102a0cb40:     	mov	w1, #0x100              ; =256
102a0cb44:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a0cb48:     	b	0x102a0cb4c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2d4>
102a0cb4c:     	mov	x19, x0
102a0cb50:     	ldr	x8, [sp, #0x8]
102a0cb54:     	cbz	x8, 0x102a0cb68 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_+0x2f0>
102a0cb58:     	ldr	x0, [sp, #0x10]
102a0cb5c:     	lsl	x1, x8, #6
102a0cb60:     	mov	w2, #0x8                ; =8
102a0cb64:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a0cb68:     	mov	x0, x19
102a0cb6c:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
102a0cb70:     	brk	#0x1
