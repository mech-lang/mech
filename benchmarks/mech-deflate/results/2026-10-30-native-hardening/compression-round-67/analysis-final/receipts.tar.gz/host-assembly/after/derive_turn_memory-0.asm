
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010259408c <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_>:
10259408c:     	sub	sp, sp, #0xd0
102594090:     	stp	x22, x21, [sp, #0xa0]
102594094:     	stp	x20, x19, [sp, #0xb0]
102594098:     	stp	x29, x30, [sp, #0xc0]
10259409c:     	add	x29, sp, #0xc0
1025940a0:     	mov	x19, x8
1025940a4:     	ldp	q0, q1, [x0, #0x20]
1025940a8:     	stp	q0, q1, [sp, #0x50]
1025940ac:     	ldr	q0, [x0, #0x40]
1025940b0:     	str	q0, [sp, #0x70]
1025940b4:     	ldp	q1, q0, [x0]
1025940b8:     	stp	q1, q0, [sp, #0x30]
1025940bc:     	mov	x8, sp
1025940c0:     	add	x0, sp, #0x30
1025940c4:     	bl	0x1027b47d4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB12_11memory_plan5model22CurrentMemoryFootprintEEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterTNtNtB12_17semantic_identity6NodeIdBW_tEB2d_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE9from_iterB60_>
1025940c8:     	ldr	x21, [sp, #0x10]
1025940cc:     	cbz	x21, 0x102594144 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0xb8>
1025940d0:     	ldr	x20, [sp, #0x8]
1025940d4:     	sub	x8, x29, #0x21
1025940d8:     	str	x8, [sp, #0x30]
1025940dc:     	cmp	x21, #0x1
1025940e0:     	b.ne	0x102594178 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0xec>
1025940e4:     	ldr	x22, [sp]
1025940e8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1025940ec:     	mov	w0, #0x2a0              ; =672
1025940f0:     	mov	w1, #0x8                ; =8
1025940f4:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1025940f8:     	cbz	x0, 0x102594198 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0x10c>
1025940fc:     	str	xzr, [x0]
102594100:     	strh	wzr, [x0, #0x29e]
102594104:     	stp	x0, xzr, [sp, #0x18]
102594108:     	str	xzr, [sp, #0x28]
10259410c:     	add	x8, x20, x21, lsl #6
102594110:     	mov	w9, #0x3                ; =3
102594114:     	strb	w9, [sp, #0x30]
102594118:     	stp	x20, x20, [sp, #0x70]
10259411c:     	stp	x22, x8, [sp, #0x80]
102594120:     	add	x0, sp, #0x18
102594124:     	add	x1, sp, #0x30
102594128:     	add	x2, sp, #0x28
10259412c:     	bl	0x10252fab4 <__RINvMNtNtNtCsgKscDXrlV49_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBW_6marker5OwnedTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1F_11memory_plan5model22CurrentMemoryFootprintNtB1g_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterB1y_B2Q_INtNtNtB9_3vec9into_iter8IntoIterTB1y_B2Q_EEENtNtB9_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102594130:     	ldp	x8, x9, [sp, #0x18]
102594134:     	ldr	x10, [sp, #0x28]
102594138:     	stp	x8, x9, [x19]
10259413c:     	str	x10, [x19, #0x10]
102594140:     	b	0x102594164 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0xd8>
102594144:     	str	xzr, [x19]
102594148:     	str	xzr, [x19, #0x10]
10259414c:     	ldr	x8, [sp]
102594150:     	cbz	x8, 0x102594164 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0xd8>
102594154:     	ldr	x0, [sp, #0x8]
102594158:     	lsl	x1, x8, #6
10259415c:     	mov	w2, #0x8                ; =8
102594160:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102594164:     	ldp	x29, x30, [sp, #0xc0]
102594168:     	ldp	x20, x19, [sp, #0xb0]
10259416c:     	ldp	x22, x21, [sp, #0xa0]
102594170:     	add	sp, sp, #0xd0
102594174:     	ret
102594178:     	cmp	x21, #0x15
10259417c:     	b.hs	0x1025941a8 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0x11c>
102594180:     	add	x3, sp, #0x30
102594184:     	mov	x0, x20
102594188:     	mov	x1, x21
10259418c:     	mov	w2, #0x1                ; =1
102594190:     	bl	0x102909138 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1u_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB3F_11collections5btree3mapINtB4s_8BTreeMapB1n_B2F_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB5v_8adapters10filter_map9FilterMapINtB4s_4IterTNtNtB1u_17semantic_identity6NodeIdB1o_tEB2F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn26apply_observed_turn_demands1_0EE0E0EB87_>
102594194:     	b	0x1025940e4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0x58>
102594198:     	mov	w0, #0x8                ; =8
10259419c:     	mov	w1, #0x2a0              ; =672
1025941a0:     	bl	0x103a064ac <__RNvNtCsgKscDXrlV49_5alloc5alloc18handle_alloc_error>
1025941a4:     	brk	#0x1
1025941a8:     	add	x2, sp, #0x30
1025941ac:     	mov	x0, x20
1025941b0:     	mov	x1, x21
1025941b4:     	bl	0x102788834 <__RINvNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable14driftsort_mainTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB17_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB3i_11collections5btree3mapINtB44_8BTreeMapB10_B2i_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB57_8adapters10filter_map9FilterMapINtB44_4IterTNtNtB17_17semantic_identity6NodeIdB11_tEB2i_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0INtNtB3i_3vec3VecBZ_EEB7I_>
1025941b8:     	b	0x1025940e4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0x58>
1025941bc:     	ldr	x22, [sp]
1025941c0:     	cbnz	x22, 0x1025941cc <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0x140>
1025941c4:     	b	0x1025941e4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0x158>
1025941c8:     	cbz	x22, 0x1025941e4 <__RINvXs1o_NtNtNtCsgKscDXrlV49_5alloc11collections5btree3mapINtB7_8BTreeMapTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1g_11memory_plan5model22CurrentMemoryFootprintEINtNtNtNtCsgDHHaSskbIF_4core4iter6traits7collect12FromIteratorTB19_B2r_EE9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB7_4IterTNtNtB1g_17semantic_identity6NodeIdB1a_tEB2r_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EEB6n_+0x158>
1025941cc:     	lsl	x1, x22, #6
1025941d0:     	mov	x19, x0
1025941d4:     	mov	x0, x20
1025941d8:     	mov	w2, #0x8                ; =8
1025941dc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1025941e0:     	mov	x0, x19
1025941e4:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
