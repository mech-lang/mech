
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a16278 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_>:
102a16278:     	sub	sp, sp, #0x70
102a1627c:     	stp	x26, x25, [sp, #0x20]
102a16280:     	stp	x24, x23, [sp, #0x30]
102a16284:     	stp	x22, x21, [sp, #0x40]
102a16288:     	stp	x20, x19, [sp, #0x50]
102a1628c:     	stp	x29, x30, [sp, #0x60]
102a16290:     	add	x29, sp, #0x60
102a16294:     	mov	x19, x8
102a16298:     	ldp	x8, x21, [x0]
102a1629c:     	cmp	x8, x21
102a162a0:     	b.eq	0x102a163e0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x168>
102a162a4:     	ldr	x22, [x0, #0x10]
102a162a8:     	add	x23, x8, #0x1c0
102a162ac:     	b	0x102a162c4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x4c>
102a162b0:     	sub	x8, x23, #0x1c0
102a162b4:     	add	x23, x23, #0x1c0
102a162b8:     	add	x8, x8, #0x1c0
102a162bc:     	cmp	x8, x21
102a162c0:     	b.eq	0x102a163e0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x168>
102a162c4:     	ldur	w20, [x23, #-0x30]
102a162c8:     	cbz	w20, 0x102a162b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
102a162cc:     	ldurb	w8, [x23, #-0x10]
102a162d0:     	and	w8, w8, #0x6
102a162d4:     	cmp	w8, #0x2
102a162d8:     	b.ne	0x102a162b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
102a162dc:     	ldur	w8, [x23, #-0x48]
102a162e0:     	cmp	w8, #0x1
102a162e4:     	b.ne	0x102a162b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
102a162e8:     	ldr	w8, [x22]
102a162ec:     	ldur	w9, [x23, #-0x44]
102a162f0:     	cmp	w9, w8
102a162f4:     	b.ne	0x102a162b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x38>
102a162f8:     	str	x23, [x0]
102a162fc:     	ldur	x24, [x23, #-0x2c]
102a16300:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a16304:     	mov	w0, #0x30               ; =48
102a16308:     	mov	w1, #0x4                ; =4
102a1630c:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a16310:     	cbz	x0, 0x102a16408 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x190>
102a16314:     	str	w20, [x0]
102a16318:     	stur	x24, [x0, #0x4]
102a1631c:     	mov	w8, #0x4                ; =4
102a16320:     	stp	x8, x0, [sp, #0x8]
102a16324:     	mov	w8, #0x1                ; =1
102a16328:     	str	x8, [sp, #0x18]
102a1632c:     	cmp	x23, x21
102a16330:     	b.eq	0x102a163cc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x154>
102a16334:     	mov	w20, #0x1               ; =1
102a16338:     	mov	w24, #0xc               ; =12
102a1633c:     	add	x23, x23, #0x1c0
102a16340:     	b	0x102a16350 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xd8>
102a16344:     	cmp	x23, x21
102a16348:     	add	x23, x23, #0x1c0
102a1634c:     	b.eq	0x102a163cc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x154>
102a16350:     	ldur	w25, [x23, #-0x30]
102a16354:     	cbz	w25, 0x102a16344 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
102a16358:     	ldurb	w8, [x23, #-0x10]
102a1635c:     	and	w8, w8, #0x6
102a16360:     	cmp	w8, #0x2
102a16364:     	b.ne	0x102a16344 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
102a16368:     	ldur	w8, [x23, #-0x48]
102a1636c:     	cmp	w8, #0x1
102a16370:     	b.ne	0x102a16344 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
102a16374:     	ldr	w8, [x22]
102a16378:     	ldur	w9, [x23, #-0x44]
102a1637c:     	cmp	w9, w8
102a16380:     	b.ne	0x102a16344 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xcc>
102a16384:     	ldur	x26, [x23, #-0x2c]
102a16388:     	ldr	x8, [sp, #0x8]
102a1638c:     	cmp	x20, x8
102a16390:     	b.ne	0x102a163b0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x138>
102a16394:     	add	x0, sp, #0x8
102a16398:     	mov	x1, x20
102a1639c:     	mov	w2, #0x1                ; =1
102a163a0:     	mov	w3, #0x4                ; =4
102a163a4:     	mov	w4, #0xc                ; =12
102a163a8:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a163ac:     	ldr	x0, [sp, #0x10]
102a163b0:     	madd	x8, x20, x24, x0
102a163b4:     	str	w25, [x8]
102a163b8:     	stur	x26, [x8, #0x4]
102a163bc:     	add	x20, x20, #0x1
102a163c0:     	str	x20, [sp, #0x18]
102a163c4:     	cmp	x23, x21
102a163c8:     	b.ne	0x102a1633c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0xc4>
102a163cc:     	ldur	q0, [sp, #0x8]
102a163d0:     	str	q0, [x19]
102a163d4:     	ldr	x8, [sp, #0x18]
102a163d8:     	str	x8, [x19, #0x10]
102a163dc:     	b	0x102a163ec <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x174>
102a163e0:     	mov	w8, #0x4                ; =4
102a163e4:     	stp	xzr, x8, [x19]
102a163e8:     	str	xzr, [x19, #0x10]
102a163ec:     	ldp	x29, x30, [sp, #0x60]
102a163f0:     	ldp	x20, x19, [sp, #0x50]
102a163f4:     	ldp	x22, x21, [sp, #0x40]
102a163f8:     	ldp	x24, x23, [sp, #0x30]
102a163fc:     	ldp	x26, x25, [sp, #0x20]
102a16400:     	add	sp, sp, #0x70
102a16404:     	ret
102a16408:     	mov	w0, #0x4                ; =4
102a1640c:     	mov	w1, #0x30               ; =48
102a16410:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a16414:     	mov	x19, x0
102a16418:     	ldr	x8, [sp, #0x8]
102a1641c:     	cbz	x8, 0x102a16434 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22TransactionRequirementEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner7program15ValueMemoryPlanENCNvNtB4n_4turn16plan_turn_memory0ENCB5y_s_0EE9from_iterB4p_+0x1bc>
102a16420:     	ldr	x0, [sp, #0x10]
102a16424:     	add	x8, x8, x8, lsl #1
102a16428:     	lsl	x1, x8, #2
102a1642c:     	mov	w2, #0x4                ; =4
102a16430:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a16434:     	mov	x0, x19
102a16438:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
