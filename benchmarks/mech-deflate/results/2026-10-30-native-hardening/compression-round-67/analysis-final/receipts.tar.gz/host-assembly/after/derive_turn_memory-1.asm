
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027278fc <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_>:
1027278fc:     	sub	sp, sp, #0x50
102727900:     	stp	x20, x19, [sp, #0x40]
102727904:     	ldp	x10, x11, [x0, #0x18]
102727908:     	ldp	x8, x9, [x1]
10272790c:     	cmp	x10, x11
102727910:     	b.hs	0x102727aa4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x1a8>
102727914:     	ldr	x12, [x1, #0x10]
102727918:     	ldp	x15, x13, [x0, #0x8]
10272791c:     	movi.2d	v0, #0000000000000000
102727920:     	mov	w14, #0x38              ; =56
102727924:     	ldr	x16, [x0]
102727928:     	b	0x102727970 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x74>
10272792c:     	ldp	q1, q2, [x3]
102727930:     	ldr	q3, [x3, #0x20]
102727934:     	ldr	x17, [x3, #0x30]
102727938:     	str	x17, [sp, #0x30]
10272793c:     	stp	q2, q3, [sp, #0x10]
102727940:     	str	q1, [sp]
102727944:     	add	x10, x10, #0x1
102727948:     	madd	x17, x9, x14, x12
10272794c:     	ldp	q1, q2, [sp]
102727950:     	stp	q1, q2, [x17]
102727954:     	ldr	q1, [sp, #0x20]
102727958:     	str	q1, [x17, #0x20]
10272795c:     	ldr	x0, [sp, #0x30]
102727960:     	str	x0, [x17, #0x30]
102727964:     	add	x9, x9, #0x1
102727968:     	cmp	x10, x11
10272796c:     	b.eq	0x102727aa4 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x1a8>
102727970:     	ldr	x17, [x16, #0xa0]
102727974:     	cbz	x17, 0x102727a00 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x104>
102727978:     	ldr	w0, [x15]
10272797c:     	ldr	x1, [x16, #0xa8]
102727980:     	add	x6, x17, #0x8
102727984:     	ldrh	w4, [x17, #0x2ca]
102727988:     	add	x3, x17, #0x28
10272798c:     	lsl	x5, x4, #3
102727990:     	mov	x2, #-0x1               ; =-1
102727994:     	cbz	x5, 0x1027279e8 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0xec>
102727998:     	ldr	w7, [x6]
10272799c:     	ldrh	w19, [x6, #0x4]
1027279a0:     	add	x6, x6, #0x8
1027279a4:     	and	w20, w10, #0xffff
1027279a8:     	cmp	w20, w19
1027279ac:     	cset	w19, hi
1027279b0:     	csinv	w19, w19, wzr, hs
1027279b4:     	cmp	w0, w7
1027279b8:     	cset	w7, hi
1027279bc:     	csinv	w7, w7, wzr, hs
1027279c0:     	csel	w7, w19, w7, eq
1027279c4:     	add	x3, x3, #0x38
1027279c8:     	add	x2, x2, #0x1
1027279cc:     	sub	x5, x5, #0x8
1027279d0:     	and	w7, w7, #0xff
1027279d4:     	cmp	w7, #0x1
1027279d8:     	b.eq	0x102727994 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x98>
1027279dc:     	cbz	w7, 0x10272792c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x30>
1027279e0:     	cbnz	x1, 0x1027279f0 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0xf4>
1027279e4:     	b	0x102727a00 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x104>
1027279e8:     	mov	x2, x4
1027279ec:     	cbz	x1, 0x102727a00 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x104>
1027279f0:     	add	x17, x17, x2, lsl #3
1027279f4:     	ldr	x17, [x17, #0x2d0]
1027279f8:     	sub	x1, x1, #0x1
1027279fc:     	b	0x102727980 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x84>
102727a00:     	ldr	x17, [x13]
102727a04:     	cbz	x17, 0x102727a94 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x198>
102727a08:     	ldr	x0, [x13, #0x8]
102727a0c:     	add	x5, x17, #0x270
102727a10:     	ldrh	w3, [x17, #0x29e]
102727a14:     	sub	x2, x17, #0x30
102727a18:     	lsl	x4, x3, #2
102727a1c:     	mov	x1, #-0x1               ; =-1
102727a20:     	cbz	x4, 0x102727a6c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x170>
102727a24:     	ldrb	w6, [x5]
102727a28:     	ldrh	w7, [x5, #0x2]
102727a2c:     	add	x5, x5, #0x4
102727a30:     	and	w19, w10, #0xffff
102727a34:     	cmp	w19, w7
102727a38:     	cset	w7, hi
102727a3c:     	csinv	w7, w7, wzr, hs
102727a40:     	cmp	w6, #0x0
102727a44:     	csinc	w6, w7, wzr, ne
102727a48:     	add	x2, x2, #0x38
102727a4c:     	add	x1, x1, #0x1
102727a50:     	sub	x4, x4, #0x4
102727a54:     	and	w6, w6, #0xff
102727a58:     	cmp	w6, #0x1
102727a5c:     	b.eq	0x102727a20 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x124>
102727a60:     	cbz	w6, 0x102727a84 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x188>
102727a64:     	cbnz	x0, 0x102727a74 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x178>
102727a68:     	b	0x102727a94 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x198>
102727a6c:     	mov	x1, x3
102727a70:     	cbz	x0, 0x102727a94 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x198>
102727a74:     	add	x17, x17, x1, lsl #3
102727a78:     	ldr	x17, [x17, #0x2a0]
102727a7c:     	sub	x0, x0, #0x1
102727a80:     	b	0x102727a0c <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x110>
102727a84:     	ldp	q1, q2, [x2]
102727a88:     	ldr	q3, [x2, #0x20]
102727a8c:     	ldr	x17, [x2, #0x30]
102727a90:     	b	0x102727938 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x3c>
102727a94:     	str	xzr, [sp, #0x30]
102727a98:     	stp	q0, q0, [sp, #0x10]
102727a9c:     	str	q0, [sp]
102727aa0:     	b	0x102727944 <__RINvXs0_NtNtNtCsgDHHaSskbIF_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_3ops5range5RangejENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysb_0ENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB2I_8for_each4callNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model22CurrentMemoryFootprintNCINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB55_3VecB3L_E14extend_trustedBN_E0E0EB1x_+0x48>
102727aa4:     	str	x9, [x8]
102727aa8:     	ldp	x20, x19, [sp, #0x40]
102727aac:     	add	sp, sp, #0x50
102727ab0:     	ret
