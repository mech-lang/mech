
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102349964 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7P_>:
102349964:     	stp	x24, x23, [sp, #-0x40]!
102349968:     	stp	x22, x21, [sp, #0x10]
10234996c:     	stp	x20, x19, [sp, #0x20]
102349970:     	stp	x29, x30, [sp, #0x30]
102349974:     	add	x29, sp, #0x30
102349978:     	mov	x19, x2
10234997c:     	mov	x20, x1
102349980:     	cmp	x3, #0x8
102349984:     	b.lo	0x1023499e0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7P_+0x7c>
102349988:     	lsr	x21, x3, #3
10234998c:     	lsl	x23, x21, #8
102349990:     	lsl	x8, x21, #9
102349994:     	sub	x24, x8, x21, lsl #6
102349998:     	add	x1, x0, x23
10234999c:     	add	x2, x0, x24
1023499a0:     	mov	x3, x21
1023499a4:     	bl	0x102349964 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7P_>
1023499a8:     	mov	x22, x0
1023499ac:     	add	x1, x20, x23
1023499b0:     	add	x2, x20, x24
1023499b4:     	mov	x0, x20
1023499b8:     	mov	x3, x21
1023499bc:     	bl	0x102349964 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7P_>
1023499c0:     	mov	x20, x0
1023499c4:     	add	x1, x19, x23
1023499c8:     	add	x2, x19, x24
1023499cc:     	mov	x0, x19
1023499d0:     	mov	x3, x21
1023499d4:     	bl	0x102349964 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7P_>
1023499d8:     	mov	x19, x0
1023499dc:     	mov	x0, x22
1023499e0:     	ldrb	w12, [x0]
1023499e4:     	ldrh	w13, [x0, #0x2]
1023499e8:     	ldrb	w8, [x19]
1023499ec:     	ldrh	w9, [x19, #0x2]
1023499f0:     	cmp	w13, w9
1023499f4:     	cset	w14, lo
1023499f8:     	subs	w10, w12, w8
1023499fc:     	mov	w15, #0xff              ; =255
102349a00:     	bics	wzr, w15, w10
102349a04:     	cset	w16, eq
102349a08:     	ldrb	w10, [x20]
102349a0c:     	ldrh	w11, [x20, #0x2]
102349a10:     	cmp	w12, w8
102349a14:     	csel	w14, w14, w16, eq
102349a18:     	cmp	w13, w11
102349a1c:     	cset	w13, lo
102349a20:     	subs	w16, w12, w10
102349a24:     	bics	wzr, w15, w16
102349a28:     	cset	w15, eq
102349a2c:     	cmp	w12, w10
102349a30:     	csel	w12, w13, w15, eq
102349a34:     	cmp	w12, w14
102349a38:     	b.ne	0x102349a64 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6shared5pivot11median3_recTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1c_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB3n_11collections5btree3mapINtB4a_8BTreeMapB15_B2n_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB5d_8adapters10filter_map9FilterMapINtB4a_4IterTNtNtB1c_17semantic_identity6NodeIdB16_tEB2n_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys9_0EE0E0EB7P_+0x100>
102349a3c:     	cmp	w11, w9
102349a40:     	cset	w9, lo
102349a44:     	subs	w11, w10, w8
102349a48:     	cmn	w11, #0x1
102349a4c:     	cset	w11, eq
102349a50:     	cmp	w10, w8
102349a54:     	csel	w8, w9, w11, eq
102349a58:     	eor	w8, w12, w8
102349a5c:     	cmp	w8, #0x0
102349a60:     	csel	x0, x19, x20, ne
102349a64:     	ldp	x29, x30, [sp, #0x30]
102349a68:     	ldp	x20, x19, [sp, #0x20]
102349a6c:     	ldp	x22, x21, [sp, #0x10]
102349a70:     	ldp	x24, x23, [sp], #0x40
102349a74:     	ret
