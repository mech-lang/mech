
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027bdce0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_>:
1027bdce0:     	sub	sp, sp, #0xa0
1027bdce4:     	stp	x24, x23, [sp, #0x60]
1027bdce8:     	stp	x22, x21, [sp, #0x70]
1027bdcec:     	stp	x20, x19, [sp, #0x80]
1027bdcf0:     	stp	x29, x30, [sp, #0x90]
1027bdcf4:     	add	x29, sp, #0x90
1027bdcf8:     	mov	x19, x8
1027bdcfc:     	ldp	x8, x21, [x0]
1027bdd00:     	cmp	x8, x21
1027bdd04:     	b.eq	0x1027bde48 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x168>
1027bdd08:     	ldr	x22, [x0, #0x10]
1027bdd0c:     	mov	x9, x8
1027bdd10:     	b	0x1027bdd20 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x40>
1027bdd14:     	mov	x8, x9
1027bdd18:     	cmp	x9, x21
1027bdd1c:     	b.eq	0x1027bde48 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x168>
1027bdd20:     	ldrb	w20, [x9], #0x20
1027bdd24:     	sub	w10, w20, #0x2
1027bdd28:     	cmp	w10, #0x3
1027bdd2c:     	b.hi	0x1027bdd14 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x34>
1027bdd30:     	ldr	w10, [x8, #0x4]
1027bdd34:     	ldr	w11, [x22]
1027bdd38:     	cmp	w10, w11
1027bdd3c:     	b.ne	0x1027bdd14 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x34>
1027bdd40:     	add	x23, x8, #0x20
1027bdd44:     	str	x23, [x0]
1027bdd48:     	ldur	q0, [x8, #0x1]
1027bdd4c:     	str	q0, [sp, #0x20]
1027bdd50:     	ldr	q0, [x8, #0x10]
1027bdd54:     	stur	q0, [sp, #0x2f]
1027bdd58:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027bdd5c:     	mov	w0, #0x80               ; =128
1027bdd60:     	mov	w1, #0x8                ; =8
1027bdd64:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027bdd68:     	cbz	x0, 0x1027bde6c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x18c>
1027bdd6c:     	strb	w20, [x0]
1027bdd70:     	ldr	q0, [sp, #0x20]
1027bdd74:     	stur	q0, [x0, #0x1]
1027bdd78:     	ldur	q0, [sp, #0x2f]
1027bdd7c:     	str	q0, [x0, #0x10]
1027bdd80:     	mov	w8, #0x4                ; =4
1027bdd84:     	stp	x8, x0, [sp, #0x8]
1027bdd88:     	mov	w8, #0x1                ; =1
1027bdd8c:     	str	x8, [sp, #0x18]
1027bdd90:     	cmp	x23, x21
1027bdd94:     	b.eq	0x1027bde34 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x154>
1027bdd98:     	mov	w20, #0x1               ; =1
1027bdd9c:     	mov	x8, x23
1027bdda0:     	b	0x1027bddb0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0xd0>
1027bdda4:     	mov	x23, x8
1027bdda8:     	cmp	x8, x21
1027bddac:     	b.eq	0x1027bde34 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x154>
1027bddb0:     	ldrb	w24, [x8], #0x20
1027bddb4:     	sub	w9, w24, #0x2
1027bddb8:     	cmp	w9, #0x3
1027bddbc:     	b.hi	0x1027bdda4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0xc4>
1027bddc0:     	ldr	w9, [x23, #0x4]
1027bddc4:     	ldr	w10, [x22]
1027bddc8:     	cmp	w9, w10
1027bddcc:     	b.ne	0x1027bdda4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0xc4>
1027bddd0:     	ldur	q0, [x23, #0x1]
1027bddd4:     	ldr	q1, [x23, #0x10]
1027bddd8:     	stur	q1, [sp, #0x4f]
1027bdddc:     	str	q0, [sp, #0x40]
1027bdde0:     	ldr	x8, [sp, #0x8]
1027bdde4:     	cmp	x20, x8
1027bdde8:     	b.ne	0x1027bde08 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x128>
1027bddec:     	add	x0, sp, #0x8
1027bddf0:     	mov	x1, x20
1027bddf4:     	mov	w2, #0x1                ; =1
1027bddf8:     	mov	w3, #0x8                ; =8
1027bddfc:     	mov	w4, #0x20               ; =32
1027bde00:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027bde04:     	ldr	x0, [sp, #0x10]
1027bde08:     	add	x23, x23, #0x20
1027bde0c:     	add	x8, x0, x20, lsl #5
1027bde10:     	strb	w24, [x8]
1027bde14:     	ldur	q0, [sp, #0x4f]
1027bde18:     	ldr	q1, [sp, #0x40]
1027bde1c:     	stur	q1, [x8, #0x1]
1027bde20:     	str	q0, [x8, #0x10]
1027bde24:     	add	x20, x20, #0x1
1027bde28:     	str	x20, [sp, #0x18]
1027bde2c:     	cmp	x23, x21
1027bde30:     	b.ne	0x1027bdd9c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0xbc>
1027bde34:     	ldur	q0, [sp, #0x8]
1027bde38:     	str	q0, [x19]
1027bde3c:     	ldr	x8, [sp, #0x18]
1027bde40:     	str	x8, [x19, #0x10]
1027bde44:     	b	0x1027bde54 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x174>
1027bde48:     	mov	w8, #0x8                ; =8
1027bde4c:     	stp	xzr, x8, [x19]
1027bde50:     	str	xzr, [x19, #0x10]
1027bde54:     	ldp	x29, x30, [sp, #0x90]
1027bde58:     	ldp	x20, x19, [sp, #0x80]
1027bde5c:     	ldp	x22, x21, [sp, #0x70]
1027bde60:     	ldp	x24, x23, [sp, #0x60]
1027bde64:     	add	sp, sp, #0xa0
1027bde68:     	ret
1027bde6c:     	mov	w0, #0x8                ; =8
1027bde70:     	mov	w1, #0x80               ; =128
1027bde74:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027bde78:     	mov	x19, x0
1027bde7c:     	ldr	x8, [sp, #0x8]
1027bde80:     	cbz	x8, 0x1027bde94 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget21MemoryBudgetViolationEINtB2_18SpecFromIterNestedB11_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters6cloned6ClonedINtNtB2M_6filter6FilterINtNtNtB2Q_5slice4iter4IterB11_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysf_0EEE9from_iterB4C_+0x1b4>
1027bde84:     	ldr	x0, [sp, #0x10]
1027bde88:     	lsl	x1, x8, #5
1027bde8c:     	mov	w2, #0x8                ; =8
1027bde90:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027bde94:     	mov	x0, x19
1027bde98:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
