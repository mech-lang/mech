
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001029eae7c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_>:
1029eae7c:     	stp	x28, x27, [sp, #-0x60]!
1029eae80:     	stp	x26, x25, [sp, #0x10]
1029eae84:     	stp	x24, x23, [sp, #0x20]
1029eae88:     	stp	x22, x21, [sp, #0x30]
1029eae8c:     	stp	x20, x19, [sp, #0x40]
1029eae90:     	stp	x29, x30, [sp, #0x50]
1029eae94:     	add	x29, sp, #0x50
1029eae98:     	sub	sp, sp, #0x2e0
1029eae9c:     	str	w4, [sp, #0x1c]
1029eaea0:     	str	x0, [sp, #0x60]
1029eaea4:     	cmp	x1, #0x2
1029eaea8:     	b.lo	0x1029eb418 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x59c>
1029eaeac:     	mov	x26, x5
1029eaeb0:     	mov	x19, x1
1029eaeb4:     	mov	x8, #0x4000000000000000 ; =4611686018427387904
1029eaeb8:     	udiv	x9, x8, x1
1029eaebc:     	mul	x10, x9, x1
1029eaec0:     	cmp	x10, x8
1029eaec4:     	cinc	x8, x9, ne
1029eaec8:     	str	x8, [sp, #0x28]
1029eaecc:     	cmp	x1, #0x1, lsl #12       ; =0x1000
1029eaed0:     	str	x3, [sp, #0x78]
1029eaed4:     	str	x2, [sp, #0x68]
1029eaed8:     	b.hi	0x1029eaef4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x78>
1029eaedc:     	sub	x8, x19, x19, lsr #1
1029eaee0:     	mov	w9, #0x40               ; =64
1029eaee4:     	cmp	x8, #0x40
1029eaee8:     	csel	x8, x8, x9, lo
1029eaeec:     	str	x8, [sp, #0x38]
1029eaef0:     	b	0x1029eaf04 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x88>
1029eaef4:     	mov	x0, x19
1029eaef8:     	bl	0x102e8be28 <__RNvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift11sqrt_approx>
1029eaefc:     	ldr	x3, [sp, #0x78]
1029eaf00:     	str	x0, [sp, #0x38]
1029eaf04:     	mov	x23, #0x0               ; =0
1029eaf08:     	mov	x20, #0x0               ; =0
1029eaf0c:     	ldr	x8, [sp, #0x60]
1029eaf10:     	add	x10, x8, #0x82
1029eaf14:     	sub	x9, x8, #0x20
1029eaf18:     	stp	x9, x10, [sp, #0x8]
1029eaf1c:     	add	x9, x8, #0x20
1029eaf20:     	str	x9, [sp]
1029eaf24:     	sub	x8, x8, #0x40
1029eaf28:     	str	x8, [sp, #0x20]
1029eaf2c:     	mov	w24, #0x1               ; =1
1029eaf30:     	str	x26, [sp, #0x50]
1029eaf34:     	str	x19, [sp, #0x30]
1029eaf38:     	subs	x9, x19, x23
1029eaf3c:     	b.ls	0x1029eaf98 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x11c>
1029eaf40:     	ldr	x8, [sp, #0x60]
1029eaf44:     	add	x0, x8, x23, lsl #6
1029eaf48:     	ldr	x8, [sp, #0x38]
1029eaf4c:     	cmp	x9, x8
1029eaf50:     	b.hs	0x1029eafac <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x130>
1029eaf54:     	ldr	w8, [sp, #0x1c]
1029eaf58:     	tbz	w8, #0x0, 0x1029eafbc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x140>
1029eaf5c:     	cmp	x9, #0x20
1029eaf60:     	mov	w8, #0x20               ; =32
1029eaf64:     	csel	x26, x9, x8, lo
1029eaf68:     	mov	x1, x26
1029eaf6c:     	ldr	x2, [sp, #0x68]
1029eaf70:     	ldr	x3, [sp, #0x78]
1029eaf74:     	mov	w4, #0x0                ; =0
1029eaf78:     	mov	x5, #0x0                ; =0
1029eaf7c:     	ldr	x6, [sp, #0x50]
1029eaf80:     	bl	0x102991da8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_>
1029eaf84:     	ldr	x3, [sp, #0x78]
1029eaf88:     	mov	w8, #0x1                ; =1
1029eaf8c:     	orr	x11, x8, x26, lsl #1
1029eaf90:     	ldr	x26, [sp, #0x50]
1029eaf94:     	b	0x1029eb154 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x2d8>
1029eaf98:     	mov	w10, #0x0               ; =0
1029eaf9c:     	mov	w11, #0x1               ; =1
1029eafa0:     	cmp	x20, #0x2
1029eafa4:     	b.hs	0x1029eb17c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x300>
1029eafa8:     	b	0x1029eb3c0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x544>
1029eafac:     	cmp	x9, #0x2
1029eafb0:     	b.hs	0x1029eafd0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x154>
1029eafb4:     	mov	x8, x9
1029eafb8:     	b	0x1029eb14c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x2d0>
1029eafbc:     	ldr	x8, [sp, #0x38]
1029eafc0:     	cmp	x9, x8
1029eafc4:     	csel	x8, x9, x8, lo
1029eafc8:     	lsl	x11, x8, #1
1029eafcc:     	b	0x1029eb154 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x2d8>
1029eafd0:     	ldrb	w11, [x0, #0x40]
1029eafd4:     	ldrh	w12, [x0, #0x42]
1029eafd8:     	ldrb	w8, [x0]
1029eafdc:     	ldrh	w10, [x0, #0x2]
1029eafe0:     	cmp	w12, w10
1029eafe4:     	cset	w10, lo
1029eafe8:     	subs	w13, w11, w8
1029eafec:     	mov	w14, #0xff              ; =255
1029eaff0:     	bics	wzr, w14, w13
1029eaff4:     	cset	w13, eq
1029eaff8:     	cmp	w11, w8
1029eaffc:     	csel	w10, w10, w13, eq
1029eb000:     	tbz	w10, #0x0, 0x1029eb018 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x19c>
1029eb004:     	cmp	x9, #0x2
1029eb008:     	b.ne	0x1029eb028 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x1ac>
1029eb00c:     	mov	w9, #0x1                ; =1
1029eb010:     	mov	w8, #0x2                ; =2
1029eb014:     	b	0x1029eb0e8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x26c>
1029eb018:     	cmp	x9, #0x2
1029eb01c:     	b.ne	0x1029eb07c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x200>
1029eb020:     	mov	w8, #0x2                ; =2
1029eb024:     	b	0x1029eb14c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x2d0>
1029eb028:     	ldr	x8, [sp, #0x10]
1029eb02c:     	add	x13, x8, x23, lsl #6
1029eb030:     	mov	w8, #0x2                ; =2
1029eb034:     	ldurb	w14, [x13, #-0x2]
1029eb038:     	ldrh	w15, [x13], #0x40
1029eb03c:     	sub	w16, w14, w11
1029eb040:     	cmp	w15, w12
1029eb044:     	cset	w12, lo
1029eb048:     	mov	w17, #0xff              ; =255
1029eb04c:     	bics	wzr, w17, w16
1029eb050:     	cset	w16, eq
1029eb054:     	cmp	w14, w11, uxtb
1029eb058:     	csel	w11, w12, w16, eq
1029eb05c:     	cmp	w11, #0x1
1029eb060:     	b.ne	0x1029eb0cc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x250>
1029eb064:     	add	x8, x8, #0x1
1029eb068:     	mov	x12, x15
1029eb06c:     	mov	x11, x14
1029eb070:     	cmp	x9, x8
1029eb074:     	b.ne	0x1029eb034 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x1b8>
1029eb078:     	b	0x1029eb0c8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x24c>
1029eb07c:     	ldr	x8, [sp, #0x10]
1029eb080:     	add	x13, x8, x23, lsl #6
1029eb084:     	mov	w8, #0x2                ; =2
1029eb088:     	ldurb	w14, [x13, #-0x2]
1029eb08c:     	ldrh	w15, [x13], #0x40
1029eb090:     	sub	w16, w14, w11
1029eb094:     	cmp	w15, w12
1029eb098:     	cset	w12, lo
1029eb09c:     	mov	w17, #0xff              ; =255
1029eb0a0:     	bics	wzr, w17, w16
1029eb0a4:     	cset	w16, eq
1029eb0a8:     	cmp	w14, w11, uxtb
1029eb0ac:     	csel	w11, w12, w16, eq
1029eb0b0:     	tbnz	w11, #0x0, 0x1029eb0cc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x250>
1029eb0b4:     	add	x8, x8, #0x1
1029eb0b8:     	mov	x12, x15
1029eb0bc:     	mov	x11, x14
1029eb0c0:     	cmp	x9, x8
1029eb0c4:     	b.ne	0x1029eb088 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x20c>
1029eb0c8:     	mov	x8, x9
1029eb0cc:     	ldr	x11, [sp, #0x38]
1029eb0d0:     	cmp	x8, x11
1029eb0d4:     	b.lo	0x1029eaf54 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0xd8>
1029eb0d8:     	lsr	x9, x8, #1
1029eb0dc:     	cmp	x9, #0x0
1029eb0e0:     	csel	w10, wzr, w10, eq
1029eb0e4:     	tbz	w10, #0x0, 0x1029eb14c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x2d0>
1029eb0e8:     	lsl	x11, x23, #6
1029eb0ec:     	add	x10, x11, x8, lsl #6
1029eb0f0:     	ldp	x12, x13, [sp]
1029eb0f4:     	add	x10, x13, x10
1029eb0f8:     	add	x11, x12, x11
1029eb0fc:     	ldur	q0, [x11, #-0x20]
1029eb100:     	ldur	q1, [x10, #-0x20]
1029eb104:     	stur	q1, [x11, #-0x20]
1029eb108:     	stur	q0, [x10, #-0x20]
1029eb10c:     	ldur	q0, [x11, #-0x10]
1029eb110:     	ldur	q1, [x10, #-0x10]
1029eb114:     	stur	q1, [x11, #-0x10]
1029eb118:     	stur	q0, [x10, #-0x10]
1029eb11c:     	ldr	q0, [x11]
1029eb120:     	ldr	q1, [x10]
1029eb124:     	str	q1, [x11]
1029eb128:     	str	q0, [x10]
1029eb12c:     	ldr	q0, [x11, #0x10]
1029eb130:     	ldr	q1, [x10, #0x10]
1029eb134:     	str	q1, [x11, #0x10]
1029eb138:     	str	q0, [x10, #0x10]
1029eb13c:     	sub	x10, x10, #0x40
1029eb140:     	add	x11, x11, #0x40
1029eb144:     	sub	x9, x9, #0x1
1029eb148:     	cbnz	x9, 0x1029eb0fc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x280>
1029eb14c:     	mov	w9, #0x1                ; =1
1029eb150:     	orr	x11, x9, x8, lsl #1
1029eb154:     	lsl	x8, x23, #1
1029eb158:     	sub	x9, x8, x24, lsr #1
1029eb15c:     	add	x8, x8, x11, lsr #1
1029eb160:     	ldr	x10, [sp, #0x28]
1029eb164:     	mul	x9, x9, x10
1029eb168:     	mul	x8, x8, x10
1029eb16c:     	eor	x8, x8, x9
1029eb170:     	clz	x10, x8
1029eb174:     	cmp	x20, #0x2
1029eb178:     	b.lo	0x1029eb3c0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x544>
1029eb17c:     	lsl	x8, x23, #6
1029eb180:     	ldr	x9, [sp, #0x60]
1029eb184:     	add	x25, x9, x8
1029eb188:     	ldr	x9, [sp, #0x20]
1029eb18c:     	add	x8, x9, x8
1029eb190:     	stp	x8, x11, [sp, #0x40]
1029eb194:     	str	x23, [sp, #0x58]
1029eb198:     	str	x10, [sp, #0x70]
1029eb19c:     	b	0x1029eb1cc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x350>
1029eb1a0:     	sub	x2, x8, x21
1029eb1a4:     	mov	x0, x23
1029eb1a8:     	mov	x1, x21
1029eb1ac:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029eb1b0:     	ldr	x26, [sp, #0x50]
1029eb1b4:     	ldp	x10, x3, [sp, #0x70]
1029eb1b8:     	mov	w8, #0x1                ; =1
1029eb1bc:     	orr	x24, x8, x19, lsl #1
1029eb1c0:     	ldr	x23, [sp, #0x58]
1029eb1c4:     	cmp	x22, #0x1
1029eb1c8:     	b.ls	0x1029eb3b4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x538>
1029eb1cc:     	sub	x22, x20, #0x1
1029eb1d0:     	sub	x8, x29, #0x9a
1029eb1d4:     	ldrb	w8, [x8, x22]
1029eb1d8:     	cmp	w8, w10
1029eb1dc:     	b.lo	0x1029eb3b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x53c>
1029eb1e0:     	mov	x20, x22
1029eb1e4:     	add	x8, sp, #0x80
1029eb1e8:     	ldr	x8, [x8, x22, lsl #3]
1029eb1ec:     	lsr	x27, x8, #1
1029eb1f0:     	lsr	x28, x24, #1
1029eb1f4:     	orr	w9, w8, w24
1029eb1f8:     	and	x9, x9, #0x1
1029eb1fc:     	add	x19, x27, x28
1029eb200:     	cmp	x19, x3
1029eb204:     	ccmp	x9, #0x0, #0x0, ls
1029eb208:     	b.eq	0x1029eb22c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x3b0>
1029eb20c:     	sub	x9, x23, x19
1029eb210:     	ldr	x10, [sp, #0x60]
1029eb214:     	add	x23, x10, x9, lsl #6
1029eb218:     	tbz	w8, #0x0, 0x1029eb23c <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x3c0>
1029eb21c:     	tbz	w24, #0x0, 0x1029eb270 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x3f4>
1029eb220:     	ldr	x10, [sp, #0x70]
1029eb224:     	cbnz	x28, 0x1029eb2a4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x428>
1029eb228:     	b	0x1029eb1b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x33c>
1029eb22c:     	lsl	x24, x19, #1
1029eb230:     	cmp	x22, #0x1
1029eb234:     	b.hi	0x1029eb1cc <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x350>
1029eb238:     	b	0x1029eb3b4 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x538>
1029eb23c:     	orr	x8, x27, #0x1
1029eb240:     	clz	x8, x8
1029eb244:     	lsl	w8, w8, #1
1029eb248:     	eor	w4, w8, #0x7e
1029eb24c:     	mov	x0, x23
1029eb250:     	mov	x1, x27
1029eb254:     	ldr	x2, [sp, #0x68]
1029eb258:     	ldr	x3, [sp, #0x78]
1029eb25c:     	mov	x5, #0x0                ; =0
1029eb260:     	mov	x6, x26
1029eb264:     	bl	0x102991da8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_>
1029eb268:     	ldr	x3, [sp, #0x78]
1029eb26c:     	tbnz	w24, #0x0, 0x1029eb220 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x3a4>
1029eb270:     	add	x0, x23, x27, lsl #6
1029eb274:     	orr	x8, x28, #0x1
1029eb278:     	clz	x8, x8
1029eb27c:     	lsl	w8, w8, #1
1029eb280:     	eor	w4, w8, #0x7e
1029eb284:     	mov	x1, x28
1029eb288:     	ldr	x2, [sp, #0x68]
1029eb28c:     	ldr	x3, [sp, #0x78]
1029eb290:     	mov	x5, #0x0                ; =0
1029eb294:     	mov	x6, x26
1029eb298:     	bl	0x102991da8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_>
1029eb29c:     	ldp	x10, x3, [sp, #0x70]
1029eb2a0:     	cbz	x28, 0x1029eb1b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x33c>
1029eb2a4:     	cbz	x27, 0x1029eb1b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x33c>
1029eb2a8:     	cmp	x28, x27
1029eb2ac:     	csel	x8, x28, x27, lo
1029eb2b0:     	cmp	x3, x8
1029eb2b4:     	b.lo	0x1029eb1b8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x33c>
1029eb2b8:     	add	x26, x23, x27, lsl #6
1029eb2bc:     	cmp	x27, x28
1029eb2c0:     	csel	x1, x26, x23, hi
1029eb2c4:     	lsl	x24, x8, #6
1029eb2c8:     	ldr	x21, [sp, #0x68]
1029eb2cc:     	mov	x0, x21
1029eb2d0:     	mov	x2, x24
1029eb2d4:     	bl	0x103a07ccc <dyld_stub_binder+0x103a07ccc>
1029eb2d8:     	add	x8, x21, x24
1029eb2dc:     	cmp	x27, x28
1029eb2e0:     	b.ls	0x1029eb350 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x4d4>
1029eb2e4:     	ldr	x9, [sp, #0x40]
1029eb2e8:     	mov	w14, #0xff              ; =255
1029eb2ec:     	ldrb	w10, [x8, #-0x40]!
1029eb2f0:     	ldrh	w11, [x8, #0x2]
1029eb2f4:     	ldrb	w12, [x26, #-0x40]!
1029eb2f8:     	ldrh	w13, [x26, #0x2]
1029eb2fc:     	cmp	w11, w13
1029eb300:     	cset	w11, lo
1029eb304:     	subs	w13, w10, w12
1029eb308:     	bics	wzr, w14, w13
1029eb30c:     	cset	w13, eq
1029eb310:     	cmp	w10, w12
1029eb314:     	csel	w10, w11, w13, eq
1029eb318:     	cmp	w10, #0x0
1029eb31c:     	csel	x11, x26, x8, ne
1029eb320:     	ldp	q0, q1, [x11, #0x20]
1029eb324:     	ldp	q3, q2, [x11]
1029eb328:     	stp	q0, q1, [x9, #0x20]
1029eb32c:     	stp	q3, q2, [x9], #-0x40
1029eb330:     	eor	w11, w10, #0x1
1029eb334:     	add	x26, x26, x11, lsl #6
1029eb338:     	add	x8, x8, x10, lsl #6
1029eb33c:     	cmp	x26, x23
1029eb340:     	ccmp	x8, x21, #0x4, ne
1029eb344:     	b.ne	0x1029eb2ec <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x470>
1029eb348:     	mov	x23, x26
1029eb34c:     	b	0x1029eb1a0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x324>
1029eb350:     	mov	w13, #0xff              ; =255
1029eb354:     	ldrb	w9, [x26]
1029eb358:     	ldrh	w10, [x26, #0x2]
1029eb35c:     	ldrb	w11, [x21]
1029eb360:     	ldrh	w12, [x21, #0x2]
1029eb364:     	cmp	w10, w12
1029eb368:     	cset	w10, lo
1029eb36c:     	subs	w12, w9, w11
1029eb370:     	bics	wzr, w13, w12
1029eb374:     	cset	w12, eq
1029eb378:     	cmp	w9, w11
1029eb37c:     	csel	w9, w10, w12, eq
1029eb380:     	eor	w10, w9, #0x1
1029eb384:     	cmp	w9, #0x0
1029eb388:     	csel	x11, x26, x21, ne
1029eb38c:     	ldp	q0, q1, [x11, #0x20]
1029eb390:     	ldp	q3, q2, [x11]
1029eb394:     	stp	q0, q1, [x23, #0x20]
1029eb398:     	stp	q3, q2, [x23], #0x40
1029eb39c:     	add	x21, x21, x10, lsl #6
1029eb3a0:     	add	x26, x26, x9, lsl #6
1029eb3a4:     	cmp	x21, x8
1029eb3a8:     	ccmp	x26, x25, #0x4, ne
1029eb3ac:     	b.ne	0x1029eb354 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x4d8>
1029eb3b0:     	b	0x1029eb1a0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x324>
1029eb3b4:     	mov	w20, #0x1               ; =1
1029eb3b8:     	ldr	x19, [sp, #0x30]
1029eb3bc:     	ldr	x11, [sp, #0x48]
1029eb3c0:     	add	x8, sp, #0x80
1029eb3c4:     	str	x24, [x8, x20, lsl #3]
1029eb3c8:     	sub	x8, x29, #0x9a
1029eb3cc:     	strb	w10, [x8, x20]
1029eb3d0:     	cmp	x19, x23
1029eb3d4:     	b.ls	0x1029eb3f0 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x574>
1029eb3d8:     	add	x20, x20, #0x1
1029eb3dc:     	add	x23, x23, x11, lsr #1
1029eb3e0:     	mov	x24, x11
1029eb3e4:     	subs	x9, x19, x23
1029eb3e8:     	b.ls	0x1029eaf98 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x11c>
1029eb3ec:     	b	0x1029eaf40 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0xc4>
1029eb3f0:     	tbnz	w24, #0x0, 0x1029eb418 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable5drift4sortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB14_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB3f_11collections5btree3mapINtB41_8BTreeMapBX_B2f_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB53_8adapters10filter_map9FilterMapINtB41_4IterTNtNtB14_17semantic_identity6NodeIdBY_tEB2f_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7D_+0x59c>
1029eb3f4:     	orr	x8, x19, #0x1
1029eb3f8:     	clz	x8, x8
1029eb3fc:     	lsl	w8, w8, #1
1029eb400:     	eor	w4, w8, #0x7e
1029eb404:     	ldp	x0, x2, [sp, #0x60]
1029eb408:     	mov	x1, x19
1029eb40c:     	mov	x5, #0x0                ; =0
1029eb410:     	mov	x6, x26
1029eb414:     	bl	0x102991da8 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTTNtNtNtCskIfnrfrMWVM_9mech_core18operation_contract10validation13PortDirectiontENtNtNtB1d_11memory_plan5model22CurrentMemoryFootprintENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB3o_11collections5btree3mapINtB4b_8BTreeMapB16_B2o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB5e_8adapters10filter_map9FilterMapINtB4b_4IterTNtNtB1d_17semantic_identity6NodeIdB17_tEB2o_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorysa_0EE0E0EB7Q_>
1029eb418:     	add	sp, sp, #0x2e0
1029eb41c:     	ldp	x29, x30, [sp, #0x50]
1029eb420:     	ldp	x20, x19, [sp, #0x40]
1029eb424:     	ldp	x22, x21, [sp, #0x30]
1029eb428:     	ldp	x24, x23, [sp, #0x20]
1029eb42c:     	ldp	x26, x25, [sp, #0x10]
1029eb430:     	ldp	x28, x27, [sp], #0x60
1029eb434:     	ret
