
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027abb1c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_>:
1027abb1c:     	sub	sp, sp, #0x70
1027abb20:     	stp	x26, x25, [sp, #0x20]
1027abb24:     	stp	x24, x23, [sp, #0x30]
1027abb28:     	stp	x22, x21, [sp, #0x40]
1027abb2c:     	stp	x20, x19, [sp, #0x50]
1027abb30:     	stp	x29, x30, [sp, #0x60]
1027abb34:     	add	x29, sp, #0x60
1027abb38:     	mov	x21, x0
1027abb3c:     	mov	x19, x8
1027abb40:     	ldr	x22, [x0]
1027abb44:     	cbz	x22, 0x1027abc38 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x11c>
1027abb48:     	ldr	x8, [x21, #0x8]
1027abb4c:     	cmp	x22, x8
1027abb50:     	b.eq	0x1027abc34 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x118>
1027abb54:     	ldr	w9, [x22], #0xc
1027abb58:     	str	x22, [x21]
1027abb5c:     	cbz	w9, 0x1027abb4c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x30>
1027abb60:     	sub	x8, x22, #0xc
1027abb64:     	ldr	w20, [x8, #0x8]
1027abb68:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027abb6c:     	mov	w0, #0x10               ; =16
1027abb70:     	mov	w1, #0x4                ; =4
1027abb74:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027abb78:     	cbz	x0, 0x1027abc78 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x15c>
1027abb7c:     	str	w20, [x0]
1027abb80:     	mov	w8, #0x4                ; =4
1027abb84:     	stp	x8, x0, [sp, #0x8]
1027abb88:     	mov	w20, #0x1               ; =1
1027abb8c:     	str	x20, [sp, #0x18]
1027abb90:     	ldp	x23, x24, [x21, #0x8]
1027abb94:     	ldr	x21, [x21, #0x18]
1027abb98:     	b	0x1027abba8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x8c>
1027abb9c:     	str	w25, [x0, x20, lsl #2]
1027abba0:     	add	x20, x20, #0x1
1027abba4:     	str	x20, [sp, #0x18]
1027abba8:     	cbz	x22, 0x1027abbd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0xb8>
1027abbac:     	cmp	x22, x23
1027abbb0:     	b.eq	0x1027abbd4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0xb8>
1027abbb4:     	ldr	w8, [x22], #0xc
1027abbb8:     	cbz	w8, 0x1027abbac <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x90>
1027abbbc:     	sub	x8, x22, #0xc
1027abbc0:     	ldr	w25, [x8, #0x8]
1027abbc4:     	ldr	x8, [sp, #0x8]
1027abbc8:     	cmp	x20, x8
1027abbcc:     	b.ne	0x1027abb9c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x80>
1027abbd0:     	b	0x1027abc00 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0xe4>
1027abbd4:     	cbz	x24, 0x1027abc20 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x104>
1027abbd8:     	cmp	x24, x21
1027abbdc:     	b.eq	0x1027abc20 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x104>
1027abbe0:     	ldr	w8, [x24], #0xc
1027abbe4:     	cbz	w8, 0x1027abbd8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0xbc>
1027abbe8:     	mov	x22, #0x0               ; =0
1027abbec:     	sub	x8, x24, #0xc
1027abbf0:     	ldr	w25, [x8, #0x8]
1027abbf4:     	ldr	x8, [sp, #0x8]
1027abbf8:     	cmp	x20, x8
1027abbfc:     	b.ne	0x1027abb9c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x80>
1027abc00:     	add	x0, sp, #0x8
1027abc04:     	mov	x1, x20
1027abc08:     	mov	w2, #0x1                ; =1
1027abc0c:     	mov	w3, #0x4                ; =4
1027abc10:     	mov	w4, #0x4                ; =4
1027abc14:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027abc18:     	ldr	x0, [sp, #0x10]
1027abc1c:     	b	0x1027abb9c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x80>
1027abc20:     	ldur	q0, [sp, #0x8]
1027abc24:     	str	q0, [x19]
1027abc28:     	ldr	x8, [sp, #0x18]
1027abc2c:     	str	x8, [x19, #0x10]
1027abc30:     	b	0x1027abc90 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x174>
1027abc34:     	str	xzr, [x21]
1027abc38:     	ldr	x8, [x21, #0x10]
1027abc3c:     	cbz	x8, 0x1027abc84 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x168>
1027abc40:     	ldr	x9, [x21, #0x18]
1027abc44:     	cmp	x8, x9
1027abc48:     	b.eq	0x1027abc84 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x168>
1027abc4c:     	ldr	w10, [x8], #0xc
1027abc50:     	str	x8, [x21, #0x10]
1027abc54:     	cbz	w10, 0x1027abc44 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x128>
1027abc58:     	mov	x22, #0x0               ; =0
1027abc5c:     	sub	x8, x8, #0xc
1027abc60:     	ldr	w20, [x8, #0x8]
1027abc64:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027abc68:     	mov	w0, #0x10               ; =16
1027abc6c:     	mov	w1, #0x4                ; =4
1027abc70:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027abc74:     	cbnz	x0, 0x1027abb7c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x60>
1027abc78:     	mov	w0, #0x4                ; =4
1027abc7c:     	mov	w1, #0x10               ; =16
1027abc80:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027abc84:     	mov	w8, #0x4                ; =4
1027abc88:     	stp	xzr, x8, [x19]
1027abc8c:     	str	xzr, [x19, #0x10]
1027abc90:     	ldp	x29, x30, [sp, #0x60]
1027abc94:     	ldp	x20, x19, [sp, #0x50]
1027abc98:     	ldp	x22, x21, [sp, #0x40]
1027abc9c:     	ldp	x24, x23, [sp, #0x30]
1027abca0:     	ldp	x26, x25, [sp, #0x20]
1027abca4:     	add	sp, sp, #0x70
1027abca8:     	ret
1027abcac:     	mov	x19, x0
1027abcb0:     	ldr	x8, [sp, #0x8]
1027abcb4:     	cbz	x8, 0x1027abcc8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters10filter_map9FilterMapINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_22TransactionRequirementEB3I_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys1_0EE9from_iterB4Q_+0x1ac>
1027abcb8:     	ldr	x0, [sp, #0x10]
1027abcbc:     	lsl	x1, x8, #2
1027abcc0:     	mov	w2, #0x4                ; =4
1027abcc4:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027abcc8:     	mov	x0, x19
1027abccc:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
