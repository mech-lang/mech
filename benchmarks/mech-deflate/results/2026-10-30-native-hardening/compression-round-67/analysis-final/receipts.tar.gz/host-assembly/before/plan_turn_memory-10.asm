
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102a03e00 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_>:
102a03e00:     	sub	sp, sp, #0xa0
102a03e04:     	stp	x28, x27, [sp, #0x40]
102a03e08:     	stp	x26, x25, [sp, #0x50]
102a03e0c:     	stp	x24, x23, [sp, #0x60]
102a03e10:     	stp	x22, x21, [sp, #0x70]
102a03e14:     	stp	x20, x19, [sp, #0x80]
102a03e18:     	stp	x29, x30, [sp, #0x90]
102a03e1c:     	add	x29, sp, #0x90
102a03e20:     	mov	x20, x0
102a03e24:     	ldr	w10, [x0, #0x10]
102a03e28:     	ldr	x16, [x0]
102a03e2c:     	mov	x15, x0
102a03e30:     	ldr	x26, [x15, #0x8]!
102a03e34:     	ldp	x9, x11, [x0, #0x18]
102a03e38:     	str	x11, [sp, #0x20]
102a03e3c:     	ldp	x25, x11, [x0, #0x28]
102a03e40:     	str	x11, [sp, #0x10]
102a03e44:     	tbz	w16, #0x0, 0x102a03e98 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x98>
102a03e48:     	tbz	w10, #0x0, 0x102a03efc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0xfc>
102a03e4c:     	cbz	x9, 0x102a03e68 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x68>
102a03e50:     	add	x27, x9, #0x1b0
102a03e54:     	ldr	x10, [sp, #0x20]
102a03e58:     	cmp	x9, x10
102a03e5c:     	csel	x10, xzr, x27, eq
102a03e60:     	str	x10, [x20, #0x18]
102a03e64:     	b.ne	0x102a03eb8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0xb8>
102a03e68:     	cbz	x25, 0x102a03e78 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x78>
102a03e6c:     	ldr	x9, [sp, #0x10]
102a03e70:     	cmp	x25, x9
102a03e74:     	b.ne	0x102a03fd8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1d8>
102a03e78:     	mov	x27, #0x0               ; =0
102a03e7c:     	str	xzr, [x20, #0x10]
102a03e80:     	str	xzr, [x15]
102a03e84:     	cbnz	x26, 0x102a03f08 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x108>
102a03e88:     	ldr	x9, [x20, #0x38]
102a03e8c:     	cmp	x9, #0x1
102a03e90:     	b.ne	0x102a04104 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
102a03e94:     	b	0x102a04064 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x264>
102a03e98:     	tbz	w10, #0x0, 0x102a03fb4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1b4>
102a03e9c:     	cbz	x9, 0x102a03fc8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1c8>
102a03ea0:     	add	x27, x9, #0x1b0
102a03ea4:     	ldr	x10, [sp, #0x20]
102a03ea8:     	cmp	x9, x10
102a03eac:     	csel	x10, xzr, x27, eq
102a03eb0:     	str	x10, [x20, #0x18]
102a03eb4:     	b.eq	0x102a03fc8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1c8>
102a03eb8:     	str	x8, [sp]
102a03ebc:     	ldr	w19, [x9, #0x1a8]
102a03ec0:     	ldr	x8, [sp, #0x20]
102a03ec4:     	sub	x8, x8, x27
102a03ec8:     	lsr	x8, x8, #4
102a03ecc:     	mov	x9, #0xda13             ; =55827
102a03ed0:     	movk	x9, #0x684b, lsl #16
102a03ed4:     	movk	x9, #0xa12f, lsl #32
102a03ed8:     	movk	x9, #0x84bd, lsl #48
102a03edc:     	mul	x8, x8, x9
102a03ee0:     	cbnz	x25, 0x102a03f7c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x17c>
102a03ee4:     	mov	w24, #0x1               ; =1
102a03ee8:     	ldr	x28, [x20, #0x38]
102a03eec:     	cmp	x28, #0x1
102a03ef0:     	str	x16, [sp, #0x18]
102a03ef4:     	b.ne	0x102a0413c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
102a03ef8:     	b	0x102a040c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2c0>
102a03efc:     	mov	x27, x9
102a03f00:     	str	xzr, [x15]
102a03f04:     	cbz	x26, 0x102a03e88 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x88>
102a03f08:     	ldr	x9, [x26, #0x2a8]
102a03f0c:     	ldr	x12, [x26, #0x2b0]
102a03f10:     	mov	w13, #0x1b0             ; =432
102a03f14:     	mul	x10, x12, x13
102a03f18:     	add	x17, x9, x10
102a03f1c:     	ldr	x25, [x26, #0x2b8]
102a03f20:     	ldr	x11, [x26, #0x2c0]
102a03f24:     	madd	x0, x11, x13, x25
102a03f28:     	mov	w13, #0x1               ; =1
102a03f2c:     	add	x14, x9, x10
102a03f30:     	str	x14, [sp, #0x20]
102a03f34:     	stp	x17, x25, [x20, #0x20]
102a03f38:     	str	x0, [sp, #0x10]
102a03f3c:     	str	x0, [x20, #0x30]
102a03f40:     	add	x27, x9, #0x1b0
102a03f44:     	cmp	x12, #0x0
102a03f48:     	csel	x14, xzr, x27, eq
102a03f4c:     	stp	x13, x14, [x20, #0x10]
102a03f50:     	cbz	x12, 0x102a03fe0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1e0>
102a03f54:     	str	x8, [sp]
102a03f58:     	mov	x26, #0x0               ; =0
102a03f5c:     	ldr	w19, [x9, #0x1a8]
102a03f60:     	sub	x8, x10, #0x1b0
102a03f64:     	lsr	x8, x8, #4
102a03f68:     	mov	x9, #0xda13             ; =55827
102a03f6c:     	movk	x9, #0x684b, lsl #16
102a03f70:     	movk	x9, #0xa12f, lsl #32
102a03f74:     	movk	x9, #0x84bd, lsl #48
102a03f78:     	mul	x8, x8, x9
102a03f7c:     	ldr	x9, [sp, #0x10]
102a03f80:     	sub	x9, x9, x25
102a03f84:     	lsr	x9, x9, #4
102a03f88:     	mov	x10, #0xda13            ; =55827
102a03f8c:     	movk	x10, #0x684b, lsl #16
102a03f90:     	movk	x10, #0xa12f, lsl #32
102a03f94:     	movk	x10, #0x84bd, lsl #48
102a03f98:     	madd	x8, x9, x10, x8
102a03f9c:     	mov	w24, #0x1               ; =1
102a03fa0:     	ldr	x28, [x20, #0x38]
102a03fa4:     	cmp	x28, #0x1
102a03fa8:     	str	x16, [sp, #0x18]
102a03fac:     	b.ne	0x102a0413c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
102a03fb0:     	b	0x102a040c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2c0>
102a03fb4:     	mov	x27, x9
102a03fb8:     	ldr	x9, [x20, #0x38]
102a03fbc:     	cmp	x9, #0x1
102a03fc0:     	b.eq	0x102a04064 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x264>
102a03fc4:     	b	0x102a04104 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
102a03fc8:     	cbz	x25, 0x102a04034 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x234>
102a03fcc:     	ldr	x9, [sp, #0x10]
102a03fd0:     	cmp	x25, x9
102a03fd4:     	b.eq	0x102a04034 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x234>
102a03fd8:     	str	x8, [sp]
102a03fdc:     	b	0x102a03fec <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x1ec>
102a03fe0:     	cbz	x11, 0x102a0404c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x24c>
102a03fe4:     	str	x8, [sp]
102a03fe8:     	mov	x26, #0x0               ; =0
102a03fec:     	mov	x27, #0x0               ; =0
102a03ff0:     	ldr	w19, [x25, #0x1a8]
102a03ff4:     	add	x25, x25, #0x1b0
102a03ff8:     	str	x25, [x20, #0x28]
102a03ffc:     	ldr	x8, [sp, #0x10]
102a04000:     	sub	x8, x8, x25
102a04004:     	lsr	x8, x8, #4
102a04008:     	mov	x9, #0xda13             ; =55827
102a0400c:     	movk	x9, #0x684b, lsl #16
102a04010:     	movk	x9, #0xa12f, lsl #32
102a04014:     	movk	x9, #0x84bd, lsl #48
102a04018:     	mul	x8, x8, x9
102a0401c:     	mov	w24, #0x1               ; =1
102a04020:     	ldr	x28, [x20, #0x38]
102a04024:     	cmp	x28, #0x1
102a04028:     	str	x16, [sp, #0x18]
102a0402c:     	b.ne	0x102a0413c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
102a04030:     	b	0x102a040c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2c0>
102a04034:     	mov	x27, #0x0               ; =0
102a04038:     	str	xzr, [x20, #0x10]
102a0403c:     	ldr	x9, [x20, #0x38]
102a04040:     	cmp	x9, #0x1
102a04044:     	b.ne	0x102a04104 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
102a04048:     	b	0x102a04064 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x264>
102a0404c:     	mov	x26, #0x0               ; =0
102a04050:     	mov	x27, #0x0               ; =0
102a04054:     	stp	xzr, xzr, [x15]
102a04058:     	ldr	x9, [x20, #0x38]
102a0405c:     	cmp	x9, #0x1
102a04060:     	b.ne	0x102a04104 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
102a04064:     	ldr	x9, [x20, #0x40]
102a04068:     	cbz	x9, 0x102a04084 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x284>
102a0406c:     	ldr	x11, [x20, #0x48]
102a04070:     	add	x10, x9, #0x1b0
102a04074:     	cmp	x9, x11
102a04078:     	csel	x10, xzr, x10, eq
102a0407c:     	str	x10, [x20, #0x40]
102a04080:     	b.ne	0x102a040a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x2a0>
102a04084:     	ldr	x9, [x20, #0x50]
102a04088:     	cbz	x9, 0x102a04104 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
102a0408c:     	ldr	x10, [x20, #0x58]
102a04090:     	cmp	x9, x10
102a04094:     	b.eq	0x102a04104 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x304>
102a04098:     	add	x10, x9, #0x1b0
102a0409c:     	str	x10, [x20, #0x50]
102a040a0:     	str	x8, [sp]
102a040a4:     	mov	x24, #0x0               ; =0
102a040a8:     	mov	x8, #0x0                ; =0
102a040ac:     	ldr	w19, [x9, #0x1a8]
102a040b0:     	ldr	x28, [x20, #0x38]
102a040b4:     	cmp	x28, #0x1
102a040b8:     	str	x16, [sp, #0x18]
102a040bc:     	b.ne	0x102a0413c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
102a040c0:     	ldr	x9, [x20, #0x40]
102a040c4:     	ldr	x10, [x20, #0x50]
102a040c8:     	cbz	x9, 0x102a04114 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x314>
102a040cc:     	ldr	x11, [x20, #0x48]
102a040d0:     	sub	x9, x11, x9
102a040d4:     	lsr	x9, x9, #4
102a040d8:     	mov	x11, #0xda13            ; =55827
102a040dc:     	movk	x11, #0x684b, lsl #16
102a040e0:     	movk	x11, #0xa12f, lsl #32
102a040e4:     	movk	x11, #0x84bd, lsl #48
102a040e8:     	mul	x9, x9, x11
102a040ec:     	cbz	x10, 0x102a04140 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x340>
102a040f0:     	ldr	x12, [x20, #0x58]
102a040f4:     	sub	x10, x12, x10
102a040f8:     	lsr	x10, x10, #4
102a040fc:     	madd	x9, x10, x11, x9
102a04100:     	b	0x102a04140 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x340>
102a04104:     	mov	w9, #0x4                ; =4
102a04108:     	stp	xzr, x9, [x8]
102a0410c:     	str	xzr, [x8, #0x10]
102a04110:     	b	0x102a043d0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5d0>
102a04114:     	cbz	x10, 0x102a0413c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x33c>
102a04118:     	ldr	x9, [x20, #0x58]
102a0411c:     	sub	x9, x9, x10
102a04120:     	lsr	x9, x9, #4
102a04124:     	mov	x10, #0xda13            ; =55827
102a04128:     	movk	x10, #0x684b, lsl #16
102a0412c:     	movk	x10, #0xa12f, lsl #32
102a04130:     	movk	x10, #0x84bd, lsl #48
102a04134:     	mul	x9, x9, x10
102a04138:     	b	0x102a04140 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x340>
102a0413c:     	mov	x9, #0x0                ; =0
102a04140:     	add	x8, x9, x8
102a04144:     	mov	w9, #0x3                ; =3
102a04148:     	cmp	x8, #0x3
102a0414c:     	csel	x8, x8, x9, hi
102a04150:     	add	x22, x8, #0x1
102a04154:     	lsl	x21, x22, #2
102a04158:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
102a0415c:     	mov	x0, x21
102a04160:     	mov	w1, #0x4                ; =4
102a04164:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
102a04168:     	cbz	x0, 0x102a043f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5f0>
102a0416c:     	str	w19, [x0]
102a04170:     	stp	x22, x0, [sp, #0x28]
102a04174:     	mov	w21, #0x1               ; =1
102a04178:     	str	x21, [sp, #0x38]
102a0417c:     	ldp	x9, x8, [x20, #0x40]
102a04180:     	str	x8, [sp, #0x8]
102a04184:     	mov	x14, #0xda13            ; =55827
102a04188:     	movk	x14, #0x684b, lsl #16
102a0418c:     	movk	x14, #0xa12f, lsl #32
102a04190:     	movk	x14, #0x84bd, lsl #48
102a04194:     	ldp	x8, x20, [x20, #0x50]
102a04198:     	ldr	x12, [sp, #0x18]
102a0419c:     	b	0x102a041b8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3b8>
102a041a0:     	str	w27, [x0, x21, lsl #2]
102a041a4:     	add	x21, x21, #0x1
102a041a8:     	str	x21, [sp, #0x38]
102a041ac:     	mov	x27, x23
102a041b0:     	mov	x9, x19
102a041b4:     	mov	x8, x22
102a041b8:     	tbz	w12, #0x0, 0x102a041ec <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3ec>
102a041bc:     	tbz	w24, #0x0, 0x102a04218 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x418>
102a041c0:     	cbz	x27, 0x102a041d0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3d0>
102a041c4:     	ldr	x10, [sp, #0x20]
102a041c8:     	cmp	x27, x10
102a041cc:     	b.ne	0x102a0424c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x44c>
102a041d0:     	mov	x23, #0x0               ; =0
102a041d4:     	cbz	x25, 0x102a041e4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3e4>
102a041d8:     	ldr	x10, [sp, #0x10]
102a041dc:     	cmp	x25, x10
102a041e0:     	b.ne	0x102a042c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4c0>
102a041e4:     	cbz	x26, 0x102a04258 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
102a041e8:     	b	0x102a04220 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x420>
102a041ec:     	tbz	w24, #0x0, 0x102a04254 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x454>
102a041f0:     	cbz	x27, 0x102a04200 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x400>
102a041f4:     	ldr	x10, [sp, #0x20]
102a041f8:     	cmp	x27, x10
102a041fc:     	b.ne	0x102a0424c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x44c>
102a04200:     	mov	x23, #0x0               ; =0
102a04204:     	cbz	x25, 0x102a04258 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
102a04208:     	ldr	x10, [sp, #0x10]
102a0420c:     	cmp	x25, x10
102a04210:     	b.ne	0x102a042c0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4c0>
102a04214:     	b	0x102a04258 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
102a04218:     	mov	x23, x27
102a0421c:     	cbz	x26, 0x102a04258 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
102a04220:     	ldr	x27, [x26, #0x2a8]
102a04224:     	ldr	x11, [x26, #0x2b0]
102a04228:     	mov	w13, #0x1b0             ; =432
102a0422c:     	madd	x10, x11, x13, x27
102a04230:     	str	x10, [sp, #0x20]
102a04234:     	ldr	x25, [x26, #0x2b8]
102a04238:     	ldr	x10, [x26, #0x2c0]
102a0423c:     	madd	x13, x10, x13, x25
102a04240:     	str	x13, [sp, #0x10]
102a04244:     	mov	x26, #0x0               ; =0
102a04248:     	cbz	x11, 0x102a042b8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4b8>
102a0424c:     	add	x23, x27, #0x1b0
102a04250:     	b	0x102a042cc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4cc>
102a04254:     	mov	x23, x27
102a04258:     	cbz	w28, 0x102a043bc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5bc>
102a0425c:     	cbz	x9, 0x102a0428c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x48c>
102a04260:     	ldr	x10, [sp, #0x8]
102a04264:     	cmp	x9, x10
102a04268:     	b.eq	0x102a0428c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x48c>
102a0426c:     	mov	x24, #0x0               ; =0
102a04270:     	add	x19, x9, #0x1b0
102a04274:     	mov	x22, x8
102a04278:     	ldr	w27, [x9, #0x1a8]
102a0427c:     	ldr	x8, [sp, #0x28]
102a04280:     	cmp	x21, x8
102a04284:     	b.ne	0x102a041a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
102a04288:     	b	0x102a042e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4e8>
102a0428c:     	cbz	x8, 0x102a043bc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5bc>
102a04290:     	cmp	x8, x20
102a04294:     	b.eq	0x102a043bc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x5bc>
102a04298:     	mov	x19, #0x0               ; =0
102a0429c:     	mov	x24, #0x0               ; =0
102a042a0:     	add	x22, x8, #0x1b0
102a042a4:     	ldr	w27, [x8, #0x1a8]
102a042a8:     	ldr	x8, [sp, #0x28]
102a042ac:     	cmp	x21, x8
102a042b0:     	b.ne	0x102a041a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
102a042b4:     	b	0x102a042e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x4e8>
102a042b8:     	mov	x23, #0x0               ; =0
102a042bc:     	cbz	x10, 0x102a04258 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x458>
102a042c0:     	mov	x23, #0x0               ; =0
102a042c4:     	mov	x27, x25
102a042c8:     	add	x25, x25, #0x1b0
102a042cc:     	mov	x19, x9
102a042d0:     	mov	x22, x8
102a042d4:     	mov	w24, #0x1               ; =1
102a042d8:     	ldr	w27, [x27, #0x1a8]
102a042dc:     	ldr	x8, [sp, #0x28]
102a042e0:     	cmp	x21, x8
102a042e4:     	b.ne	0x102a041a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
102a042e8:     	cbz	x24, 0x102a04338 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x538>
102a042ec:     	cbz	x23, 0x102a0431c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x51c>
102a042f0:     	ldr	x8, [sp, #0x20]
102a042f4:     	sub	x8, x8, x23
102a042f8:     	lsr	x8, x8, #4
102a042fc:     	mul	x8, x8, x14
102a04300:     	cbz	x25, 0x102a04330 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x530>
102a04304:     	ldr	x9, [sp, #0x10]
102a04308:     	sub	x9, x9, x25
102a0430c:     	lsr	x9, x9, #4
102a04310:     	madd	x8, x9, x14, x8
102a04314:     	cbz	w28, 0x102a04380 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
102a04318:     	b	0x102a04340 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x540>
102a0431c:     	cbz	x25, 0x102a04338 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x538>
102a04320:     	ldr	x8, [sp, #0x10]
102a04324:     	sub	x8, x8, x25
102a04328:     	lsr	x8, x8, #4
102a0432c:     	mul	x8, x8, x14
102a04330:     	cbz	w28, 0x102a04380 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
102a04334:     	b	0x102a04340 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x540>
102a04338:     	mov	x8, #0x0                ; =0
102a0433c:     	cbz	w28, 0x102a04380 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
102a04340:     	cbz	x19, 0x102a0436c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x56c>
102a04344:     	ldr	x9, [sp, #0x8]
102a04348:     	sub	x9, x9, x19
102a0434c:     	lsr	x9, x9, #4
102a04350:     	mul	x9, x9, x14
102a04354:     	sub	x10, x20, x22
102a04358:     	lsr	x10, x10, #4
102a0435c:     	madd	x10, x10, x14, x9
102a04360:     	cmp	x22, #0x0
102a04364:     	csel	x9, x9, x10, eq
102a04368:     	b	0x102a04384 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x584>
102a0436c:     	cbz	x22, 0x102a04380 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x580>
102a04370:     	sub	x9, x20, x22
102a04374:     	lsr	x9, x9, #4
102a04378:     	mul	x9, x9, x14
102a0437c:     	b	0x102a04384 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x584>
102a04380:     	mov	x9, #0x0                ; =0
102a04384:     	add	x8, x8, x9
102a04388:     	add	x0, sp, #0x28
102a0438c:     	add	x2, x8, #0x1
102a04390:     	mov	x1, x21
102a04394:     	mov	w3, #0x4                ; =4
102a04398:     	mov	w4, #0x4                ; =4
102a0439c:     	bl	0x1039f63c4 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
102a043a0:     	ldr	x0, [sp, #0x30]
102a043a4:     	ldr	x12, [sp, #0x18]
102a043a8:     	mov	x14, #0xda13            ; =55827
102a043ac:     	movk	x14, #0x684b, lsl #16
102a043b0:     	movk	x14, #0xa12f, lsl #32
102a043b4:     	movk	x14, #0x84bd, lsl #48
102a043b8:     	b	0x102a041a0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x3a0>
102a043bc:     	ldur	q0, [sp, #0x28]
102a043c0:     	ldr	x9, [sp]
102a043c4:     	str	q0, [x9]
102a043c8:     	ldr	x8, [sp, #0x38]
102a043cc:     	str	x8, [x9, #0x10]
102a043d0:     	ldp	x29, x30, [sp, #0x90]
102a043d4:     	ldp	x20, x19, [sp, #0x80]
102a043d8:     	ldp	x22, x21, [sp, #0x70]
102a043dc:     	ldp	x24, x23, [sp, #0x60]
102a043e0:     	ldp	x26, x25, [sp, #0x50]
102a043e4:     	ldp	x28, x27, [sp, #0x40]
102a043e8:     	add	sp, sp, #0xa0
102a043ec:     	ret
102a043f0:     	mov	w0, #0x4                ; =4
102a043f4:     	mov	x1, x21
102a043f8:     	bl	0x103a03a88 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
102a043fc:     	mov	x19, x0
102a04400:     	ldr	x8, [sp, #0x28]
102a04404:     	cbz	x8, 0x102a04418 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model14MemoryObjectIdEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2q_7flatten7FlatMapINtNtB2u_6option8IntoIterRNtBW_14CallMemoryPlanEINtNtB2q_5chain5ChainINtNtNtB2u_5slice4iter4IterNtBW_14PortMemoryPlanEB4F_ENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn16plan_turn_memorys4_0ENCB5z_s5_0EE9from_iterB5F_+0x618>
102a04408:     	ldr	x0, [sp, #0x30]
102a0440c:     	lsl	x1, x8, #2
102a04410:     	mov	w2, #0x4                ; =4
102a04414:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102a04418:     	mov	x0, x19
102a0441c:     	bl	0x103a050a4 <dyld_stub_binder+0x103a050a4>
