
/private/tmp/mech-borrowed-turn-source-round67-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027ac2f0 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_>:
1027ac2f0:     	sub	sp, sp, #0x80
1027ac2f4:     	stp	x28, x27, [sp, #0x20]
1027ac2f8:     	stp	x26, x25, [sp, #0x30]
1027ac2fc:     	stp	x24, x23, [sp, #0x40]
1027ac300:     	stp	x22, x21, [sp, #0x50]
1027ac304:     	stp	x20, x19, [sp, #0x60]
1027ac308:     	stp	x29, x30, [sp, #0x70]
1027ac30c:     	add	x29, sp, #0x70
1027ac310:     	mov	x19, x8
1027ac314:     	ldp	x8, x21, [x0]
1027ac318:     	cmp	x8, x21
1027ac31c:     	b.eq	0x1027ac3dc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xec>
1027ac320:     	ldr	x22, [x0, #0x10]
1027ac324:     	ldr	x9, [x22]
1027ac328:     	cbz	x9, 0x1027ac3dc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xec>
1027ac32c:     	ldr	x10, [x22, #0x8]
1027ac330:     	add	x23, x8, #0x60
1027ac334:     	ldr	w11, [x8, #0x50]
1027ac338:     	mov	x12, x10
1027ac33c:     	mov	x13, x9
1027ac340:     	add	x15, x13, #0x8
1027ac344:     	ldrh	w16, [x13, #0x36]
1027ac348:     	lsl	x17, x16, #2
1027ac34c:     	mov	x14, #-0x1              ; =-1
1027ac350:     	cbz	x17, 0x1027ac380 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x90>
1027ac354:     	ldr	w1, [x15], #0x4
1027ac358:     	cmp	w11, w1
1027ac35c:     	cset	w1, hi
1027ac360:     	csinv	w1, w1, wzr, hs
1027ac364:     	add	x14, x14, #0x1
1027ac368:     	sub	x17, x17, #0x4
1027ac36c:     	and	w1, w1, #0xff
1027ac370:     	cmp	w1, #0x1
1027ac374:     	b.eq	0x1027ac350 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x60>
1027ac378:     	cbz	w1, 0x1027ac3a8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xb8>
1027ac37c:     	b	0x1027ac384 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x94>
1027ac380:     	mov	x14, x16
1027ac384:     	cbz	x12, 0x1027ac398 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xa8>
1027ac388:     	add	x13, x13, x14, lsl #3
1027ac38c:     	ldr	x13, [x13, #0x38]
1027ac390:     	sub	x12, x12, #0x1
1027ac394:     	b	0x1027ac340 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x50>
1027ac398:     	mov	x8, x23
1027ac39c:     	cmp	x23, x21
1027ac3a0:     	b.ne	0x1027ac330 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x40>
1027ac3a4:     	b	0x1027ac3dc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xec>
1027ac3a8:     	str	x23, [x0]
1027ac3ac:     	ldr	x24, [x0, #0x18]
1027ac3b0:     	ldr	w20, [x8, #0x10]
1027ac3b4:     	add	x8, x8, #0x14
1027ac3b8:     	ldr	w9, [x24, #0xa8]
1027ac3bc:     	and	w10, w20, #0xff
1027ac3c0:     	cmp	w10, #0x4
1027ac3c4:     	cset	w11, eq
1027ac3c8:     	add	x25, x24, #0xac
1027ac3cc:     	tst	w11, w9
1027ac3d0:     	csel	x8, x25, x8, ne
1027ac3d4:     	cmp	w10, #0x8
1027ac3d8:     	b.ne	0x1027ac408 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x118>
1027ac3dc:     	mov	w8, #0x4                ; =4
1027ac3e0:     	stp	xzr, x8, [x19]
1027ac3e4:     	str	xzr, [x19, #0x10]
1027ac3e8:     	ldp	x29, x30, [sp, #0x70]
1027ac3ec:     	ldp	x20, x19, [sp, #0x60]
1027ac3f0:     	ldp	x22, x21, [sp, #0x50]
1027ac3f4:     	ldp	x24, x23, [sp, #0x40]
1027ac3f8:     	ldp	x26, x25, [sp, #0x30]
1027ac3fc:     	ldp	x28, x27, [sp, #0x20]
1027ac400:     	add	sp, sp, #0x80
1027ac404:     	ret
1027ac408:     	ldr	w26, [x8]
1027ac40c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1027ac410:     	mov	w0, #0x20               ; =32
1027ac414:     	mov	w1, #0x4                ; =4
1027ac418:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1027ac41c:     	cbz	x0, 0x1027ac58c <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x29c>
1027ac420:     	strb	w20, [x0]
1027ac424:     	orr	x8, x20, x26, lsl #32
1027ac428:     	lsr	x9, x8, #56
1027ac42c:     	strb	w9, [x0, #0x7]
1027ac430:     	lsr	x9, x8, #40
1027ac434:     	sturh	w9, [x0, #0x5]
1027ac438:     	lsr	x8, x8, #8
1027ac43c:     	stur	w8, [x0, #0x1]
1027ac440:     	mov	w8, #0x4                ; =4
1027ac444:     	stp	x8, x0, [sp, #0x8]
1027ac448:     	mov	w8, #0x1                ; =1
1027ac44c:     	str	x8, [sp, #0x18]
1027ac450:     	cmp	x23, x21
1027ac454:     	b.eq	0x1027ac578 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x288>
1027ac458:     	mov	w20, #0x1               ; =1
1027ac45c:     	b	0x1027ac498 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1a8>
1027ac460:     	ldr	x0, [sp, #0x10]
1027ac464:     	add	x8, x0, x20, lsl #3
1027ac468:     	strb	w26, [x8]
1027ac46c:     	orr	x9, x26, x27, lsl #32
1027ac470:     	lsr	x10, x9, #8
1027ac474:     	lsr	x11, x9, #56
1027ac478:     	strb	w11, [x8, #0x7]
1027ac47c:     	lsr	x9, x9, #40
1027ac480:     	sturh	w9, [x8, #0x5]
1027ac484:     	stur	w10, [x8, #0x1]
1027ac488:     	add	x20, x20, #0x1
1027ac48c:     	str	x20, [sp, #0x18]
1027ac490:     	cmp	x23, x21
1027ac494:     	b.eq	0x1027ac578 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x288>
1027ac498:     	ldr	x8, [x22]
1027ac49c:     	cbz	x8, 0x1027ac578 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x288>
1027ac4a0:     	ldr	x9, [x22, #0x8]
1027ac4a4:     	mov	x10, x23
1027ac4a8:     	add	x23, x10, #0x60
1027ac4ac:     	ldr	w11, [x10, #0x50]
1027ac4b0:     	mov	x12, x9
1027ac4b4:     	mov	x13, x8
1027ac4b8:     	add	x15, x13, #0x8
1027ac4bc:     	ldrh	w16, [x13, #0x36]
1027ac4c0:     	lsl	x17, x16, #2
1027ac4c4:     	mov	x14, #-0x1              ; =-1
1027ac4c8:     	cbz	x17, 0x1027ac4fc <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x20c>
1027ac4cc:     	ldr	w1, [x15], #0x4
1027ac4d0:     	cmp	w11, w1
1027ac4d4:     	cset	w1, hi
1027ac4d8:     	csinv	w1, w1, wzr, hs
1027ac4dc:     	add	x14, x14, #0x1
1027ac4e0:     	sub	x17, x17, #0x4
1027ac4e4:     	and	w1, w1, #0xff
1027ac4e8:     	cmp	w1, #0x1
1027ac4ec:     	b.eq	0x1027ac4c8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1d8>
1027ac4f0:     	cbz	w1, 0x1027ac524 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x234>
1027ac4f4:     	cbnz	x12, 0x1027ac504 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x214>
1027ac4f8:     	b	0x1027ac514 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x224>
1027ac4fc:     	mov	x14, x16
1027ac500:     	cbz	x12, 0x1027ac514 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x224>
1027ac504:     	add	x13, x13, x14, lsl #3
1027ac508:     	ldr	x13, [x13, #0x38]
1027ac50c:     	sub	x12, x12, #0x1
1027ac510:     	b	0x1027ac4b8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1c8>
1027ac514:     	mov	x10, x23
1027ac518:     	cmp	x23, x21
1027ac51c:     	b.ne	0x1027ac4a8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x1b8>
1027ac520:     	b	0x1027ac578 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x288>
1027ac524:     	ldr	w26, [x10, #0x10]
1027ac528:     	add	x8, x10, #0x14
1027ac52c:     	ldr	w9, [x24, #0xa8]
1027ac530:     	and	w10, w26, #0xff
1027ac534:     	cmp	w10, #0x4
1027ac538:     	cset	w11, eq
1027ac53c:     	tst	w11, w9
1027ac540:     	csel	x8, x25, x8, ne
1027ac544:     	cmp	w10, #0x8
1027ac548:     	b.eq	0x1027ac578 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x288>
1027ac54c:     	ldr	w27, [x8]
1027ac550:     	ldr	x8, [sp, #0x8]
1027ac554:     	cmp	x20, x8
1027ac558:     	b.ne	0x1027ac464 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x174>
1027ac55c:     	add	x0, sp, #0x8
1027ac560:     	mov	x1, x20
1027ac564:     	mov	w2, #0x1                ; =1
1027ac568:     	mov	w3, #0x4                ; =4
1027ac56c:     	mov	w4, #0x8                ; =8
1027ac570:     	bl	0x1039f9680 <__RINvNvMs2_NtCsgKscDXrlV49_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1qJAwyMG1lC_11mech_engine>
1027ac574:     	b	0x1027ac460 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x170>
1027ac578:     	ldur	q0, [sp, #0x8]
1027ac57c:     	str	q0, [x19]
1027ac580:     	ldr	x8, [sp, #0x18]
1027ac584:     	str	x8, [x19, #0x10]
1027ac588:     	b	0x1027ac3e8 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0xf8>
1027ac58c:     	mov	w0, #0x4                ; =4
1027ac590:     	mov	w1, #0x20               ; =32
1027ac594:     	bl	0x103a064c4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1027ac598:     	mov	x19, x0
1027ac59c:     	ldr	x8, [sp, #0x8]
1027ac5a0:     	cbz	x8, 0x1027ac5b4 <__RNvXNtNtCsgKscDXrlV49_5alloc3vec14spec_from_iterINtB4_3VecNtNtNtCskIfnrfrMWVM_9mech_core11memory_plan5model17MemoryObjectOwnerEINtB2_12SpecFromIterBU_INtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtB2t_6filter6FilterINtNtNtB2x_5slice4iter4IterNtBW_14AllocationPlanENCNvNtNtCs1qJAwyMG1lC_11mech_engine14memory_planner4turn18derive_turn_memorys6_0ENCB4o_s7_0EE9from_iterB4u_+0x2c4>
1027ac5a4:     	ldr	x0, [sp, #0x10]
1027ac5a8:     	lsl	x1, x8, #3
1027ac5ac:     	mov	w2, #0x4                ; =4
1027ac5b0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1027ac5b4:     	mov	x0, x19
1027ac5b8:     	bl	0x103a07ae0 <dyld_stub_binder+0x103a07ae0>
