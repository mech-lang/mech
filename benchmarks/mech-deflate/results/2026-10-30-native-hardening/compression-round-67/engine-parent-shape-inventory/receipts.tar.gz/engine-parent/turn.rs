use std::collections::{BTreeMap, BTreeSet};

use mech_core::{
    AllocationPlan, ArenaPlan, CurrentMemoryFootprint, MemoryBudgetLimits, MemoryBudgetViolation,
    MemoryObjectOwner, MemoryPlanError, NodeId, PortDirection, RegionAccessPlan, ResourceDemand,
    TransactionRequirement,
};

use super::{ProgramMemoryPlan, checked_demand_add, place_allocations};

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct TurnMemoryFacts {
    pub resolved_regions: BTreeMap<(NodeId, u16), RegionAccessPlan>,
    pub resolved_footprints: BTreeMap<(NodeId, PortDirection, u16), CurrentMemoryFootprint>,
    /// The value retained until publication, distinct from the candidate.
    pub published_footprints: BTreeMap<(NodeId, u16), CurrentMemoryFootprint>,
    pub additional_demand: ResourceDemand,
    /// A complete concrete executor estimate for this turn. Each component
    /// replaces a weaker declaration by maximum rather than being added to
    /// the same operation twice.
    pub observed_demand: Option<ResourceDemand>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TurnMemoryPlan {
    pub node: NodeId,
    /// Concrete facts are retained so admission can refine the candidate
    /// without falling back to activation-time input footprints.
    pub facts: TurnMemoryFacts,
    pub call: Option<mech_core::CallMemoryPlan>,
    pub allocations: Box<[AllocationPlan]>,
    pub arenas: Box<[ArenaPlan]>,
    pub transactions: Box<[TransactionRequirement]>,
    pub demand: ResourceDemand,
    pub output_bytes: u64,
    pub storage_buffer_bytes: u64,
    pub budget_limits: MemoryBudgetLimits,
    pub budget_violations: Box<[MemoryBudgetViolation]>,
    /// Scoped independently owned String-index storage already included in
    /// facts.additional_demand. Lazy growth is reconciled at each permit.
    #[cfg(feature = "resident-artifact")]
    pub(crate) resident_text_index_baseline: (u64, u64),
}

pub fn plan_turn_memory(
    plan: &ProgramMemoryPlan,
    node: NodeId,
    facts: &TurnMemoryFacts,
) -> Result<TurnMemoryPlan, MemoryPlanError> {
    let value_transactions = plan
        .values
        .iter()
        .filter(|value| {
            value.transaction != TransactionRequirement::None
                && matches!(
                    value.class,
                    super::PlannedValueClass::State | super::PlannedValueClass::PublishedOutput
                )
                && value.producer == Some(node)
        })
        .map(|value| value.transaction)
        .collect::<Vec<_>>();
    let call_transactions = plan
        .call_for_node(node)
        .map(|call| call.transactions.to_vec())
        .unwrap_or_default();
    let transaction_objects = value_transactions
        .iter()
        .chain(&call_transactions)
        .filter_map(|transaction| transaction_stage(*transaction))
        .collect::<BTreeSet<_>>();
    let transaction_owners = plan
        .allocations
        .iter()
        .filter(|allocation| transaction_objects.contains(&allocation.id))
        .map(|allocation| allocation.owner.clone())
        .collect::<BTreeSet<_>>();
    let port_objects = plan
        .call_for_node(node)
        .into_iter()
        .flat_map(|call| call.inputs.iter().chain(call.outputs.iter()))
        .map(|port| port.object)
        .collect::<BTreeSet<_>>();
    let port_owners = plan
        .allocations
        .iter()
        .filter(|a| port_objects.contains(&a.id))
        .map(|a| a.owner.clone())
        .collect::<BTreeSet<_>>();
    let mut allocations = plan
        .allocations
        .iter()
        .filter(|allocation| {
            owner_node(&allocation.owner) == Some(node)
                || port_objects.contains(&allocation.id)
                || (allocation.role == mech_core::AllocationRole::VariablePayload
                    && port_owners.contains(&allocation.owner))
                || transaction_objects.contains(&allocation.id)
                || (allocation.role == mech_core::AllocationRole::TransactionStage
                    && transaction_owners.contains(&allocation.owner))
        })
        .cloned()
        .collect::<Vec<_>>();
    let mut transactions = Vec::new();
    let mut demand = facts.additional_demand;
    let mut output_bytes = 0_u64;
    let mut turn_call = None;
    if let Some(call) = plan.call_for_node(node) {
        let resolved = facts
            .resolved_footprints
            .iter()
            .filter_map(|(&(fact_node, direction, port), &footprint)| {
                (fact_node == node).then_some(((direction, port), footprint))
            })
            .collect::<BTreeMap<_, _>>();
        let mut template = call.clone();
        for (ordinal, region) in template.output_regions.iter_mut().enumerate() {
            if let Some(actual) = facts.resolved_regions.get(&(node, ordinal as u16)) {
                *region = actual.clone();
            }
        }
        let published = (0..template.outputs.len())
            .map(|ordinal| {
                facts
                    .published_footprints
                    .get(&(node, ordinal as u16))
                    .copied()
                    .or_else(|| {
                        resolved
                            .get(&(PortDirection::Output, ordinal as u16))
                            .copied()
                    })
                    .unwrap_or_default()
            })
            .collect::<Vec<_>>();
        let resolved_call = derive_turn_call(&mut template, &resolved, Some(&published))?;
        refresh_turn_allocations(&mut allocations, call, &resolved_call, node, facts)?;
        demand = checked_demand_add(demand, resolved_call.demand)?;
        transactions.extend(call_transactions.iter().copied());
        for deferred in &call.deferred_witnesses {
            if deferred.stage != mech_core::MemoryWitnessStage::Turn {
                continue;
            }
            let Some(footprint) =
                facts
                    .resolved_footprints
                    .get(&(node, deferred.direction, deferred.port))
            else {
                return Err(MemoryPlanError::MissingFootprintWitness {
                    stage: mech_core::MemoryWitnessStage::Turn,
                });
            };
            if deferred.direction == PortDirection::Input {
                let input = call
                    .inputs
                    .get(usize::from(deferred.port))
                    .ok_or(MemoryPlanError::DescriptorArityMismatch)?;
                if let Some(maximum) = input.value.capacity_elements.maximum
                    && footprint.logical_elements > maximum
                {
                    return Err(MemoryPlanError::DynamicCardinalityExceedsBound {
                        current: footprint.logical_elements,
                        maximum,
                    });
                }
            }
        }
        for (ordinal, output) in call.outputs.iter().enumerate() {
            let ordinal_index = ordinal;
            let ordinal =
                u16::try_from(ordinal).map_err(|_| MemoryPlanError::ArithmeticOverflow {
                    field: "turn output ordinal",
                })?;
            if matches!(output.region, RegionAccessPlan::Deferred(_))
                && !facts.resolved_regions.contains_key(&(node, ordinal))
            {
                return Err(MemoryPlanError::MissingFootprintWitness {
                    stage: mech_core::MemoryWitnessStage::Turn,
                });
            }
            let footprint = facts
                .resolved_footprints
                .get(&(node, PortDirection::Output, ordinal));
            if let Some(footprint) = footprint {
                if output
                    .value
                    .capacity_elements
                    .maximum
                    .is_some_and(|maximum| footprint.logical_elements > maximum)
                {
                    return Err(MemoryPlanError::DynamicCardinalityExceedsBound {
                        current: footprint.logical_elements,
                        maximum: output.value.capacity_elements.maximum.unwrap(),
                    });
                }
            }
            let resolved_output = resolved_call
                .outputs
                .get(ordinal_index)
                .ok_or(MemoryPlanError::DescriptorArityMismatch)?;
            output_bytes = output_bytes
                .checked_add(resolved_output.value.capacity_bytes)
                .and_then(|value| value.checked_add(resolved_output.value.payload.required_bytes))
                .ok_or(MemoryPlanError::ArithmeticOverflow {
                    field: "complete turn output bytes",
                })?;
        }
        turn_call = Some(scope_turn_call(resolved_call, call, &allocations));
    }
    transactions.extend(value_transactions);
    transactions.sort_by_key(transaction_key);
    transactions.dedup();
    if let Some(observed) = facts.observed_demand {
        demand = demand_max(demand, observed);
        output_bytes = output_bytes.max(observed.persistent_bytes);
        grow_transaction_stage_total(
            &mut allocations,
            observed.persistent_bytes,
            observed.persistent_bytes,
        )?;
    }
    let arenas = place_allocations(&mut allocations)?;
    if let Some(call) = &mut turn_call {
        call.allocations = allocations.clone().into_boxed_slice();
    }
    demand.turn_peak_bytes = demand.turn_peak_bytes.max(turn_storage_peak(&allocations)?);
    let mut budget_violations = plan
        .budget_violations
        .iter()
        .filter(|violation| owner_node(&violation.owner) == Some(node))
        .cloned()
        .collect::<Vec<_>>();
    let storage_buffer_bytes = allocations
        .iter()
        .filter(|allocation| matches!(allocation.space, mech_core::MemorySpace::Device { .. }))
        .map(|allocation| allocation.capacity_bytes)
        .max()
        .unwrap_or(0);
    budget_violations.extend(mech_core::evaluate_call_memory_budget(
        MemoryObjectOwner::NodeOutput { node, port: 0 },
        demand,
        output_bytes,
        storage_buffer_bytes,
        plan.budget_limits,
    ));
    budget_violations.sort();
    budget_violations.dedup();
    Ok(TurnMemoryPlan {
        #[cfg(feature = "resident-artifact")]
        resident_text_index_baseline: (0, 0),
        node,
        facts: facts.clone(),
        call: turn_call,
        allocations: allocations.into_boxed_slice(),
        arenas,
        transactions: transactions.into_boxed_slice(),
        demand,
        output_bytes,
        storage_buffer_bytes,
        budget_limits: plan.budget_limits,
        budget_violations: budget_violations.into_boxed_slice(),
    })
}

/// Bounds borrowed planning work against the real node scope without deriving
/// layouts or making a materialization permit. The meter only accumulates
/// traversal work and temporary/clone/node demand; publication facts must be
/// supplied separately at final admission through `apply_observed_turn_demand`.
#[cfg(feature = "resident-artifact")]
pub(crate) fn check_turn_planning_progress(
    plan: &TurnMemoryPlan,
    progress: ResourceDemand,
) -> Result<(), MemoryPlanError> {
    if progress.persistent_bytes != 0 || progress.output_elements != 0 {
        return Err(MemoryPlanError::DescriptorMismatch);
    }
    let demand = demand_max(
        plan.demand,
        checked_demand_add(progress, plan.facts.additional_demand)?,
    );
    if let Some(violation) = mech_core::evaluate_call_memory_budget(
        MemoryObjectOwner::NodeOutput {
            node: plan.node,
            port: 0,
        },
        demand,
        plan.output_bytes,
        plan.storage_buffer_bytes,
        plan.budget_limits,
    )
    .first()
    {
        return Err(MemoryPlanError::TargetLimitExceeded {
            violation: violation.clone(),
        });
    }
    Ok(())
}

/// Admit a fresh concrete estimate against an unchanged fixed-width plan.
/// Only invariant footprints may avoid derivation. Changed cardinality,
/// payload, regions, or transaction extents take the complete planning path.
/// Work is still checked on every admission, even when the backing is reused.
#[cfg(feature = "resident-artifact")]
pub(crate) fn try_admit_fixed_turn_memory(
    plan: &TurnMemoryPlan,
    observed: ResourceDemand,
    final_output: Option<CurrentMemoryFootprint>,
) -> Result<Option<ResourceDemand>, MemoryPlanError> {
    let Some(call) = plan.call.as_ref() else {
        return Ok(None);
    };
    if !has_invariant_resident_memory_facts(call) || !plan.budget_violations.is_empty() {
        return Ok(None);
    }
    if call.outputs.len() != 1 {
        return Ok(None);
    }
    if observed.persistent_bytes != 0 || observed.output_elements != 0 || final_output.is_some() {
        let Some(previous) =
            plan.facts
                .resolved_footprints
                .get(&(plan.node, PortDirection::Output, 0))
        else {
            return Ok(None);
        };
        let fixed = call.outputs[0].value.current_address_span_bytes;
        let retained = final_output
            .map(|f| {
                f.fixed_bytes
                    .checked_add(f.payload_bytes)
                    .ok_or(MemoryPlanError::TargetAddressOverflow)
            })
            .transpose()?
            .unwrap_or(observed.persistent_bytes);
        let elements = final_output.map_or(observed.output_elements, |f| f.logical_elements);
        let nodes = final_output.map_or(observed.retained_nodes, |f| f.retained_nodes);
        if elements != previous.logical_elements
            || retained != fixed
            || retained != previous.encoded_bytes
            || previous.payload_bytes != 0
            || nodes != previous.retained_nodes
        {
            return Ok(None);
        }
    }
    let observed = checked_demand_add(observed, plan.facts.additional_demand)?;
    let mut current = 0_u64;
    let mut capacity = 0_u64;
    for stage in plan
        .allocations
        .iter()
        .filter(|allocation| allocation.role == mech_core::AllocationRole::TransactionStage)
    {
        current = current
            .checked_add(stage.current_bytes)
            .ok_or(MemoryPlanError::TargetAddressOverflow)?;
        capacity = capacity
            .checked_add(stage.capacity_bytes)
            .ok_or(MemoryPlanError::TargetAddressOverflow)?;
    }
    if observed.persistent_bytes > current || observed.persistent_bytes > capacity {
        return Ok(None);
    }
    let demand = demand_max(plan.demand, observed);
    if let Some(violation) = mech_core::evaluate_call_memory_budget(
        MemoryObjectOwner::NodeOutput {
            node: plan.node,
            port: 0,
        },
        demand,
        plan.output_bytes.max(observed.persistent_bytes),
        plan.storage_buffer_bytes,
        plan.budget_limits,
    )
    .first()
    {
        return Err(MemoryPlanError::TargetLimitExceeded {
            violation: violation.clone(),
        });
    }
    Ok(Some(demand))
}

#[cfg(feature = "resident-artifact")]
/// Resident lane lengths and semantic descriptors cannot change during an
/// activation. Index and F64 ordinal lists have invariant cardinality even when their
/// entries change; execution must still validate those entries on every turn.
/// Boolean masks, payloads, and other value-dependent regions are not cached.
pub(crate) fn has_invariant_resident_memory_facts(call: &mech_core::CallMemoryPlan) -> bool {
    call.deferred_witnesses.is_empty()
        // A fixed-width canonical fallback has fixed draft/finalization
        // obligations too. Cache the complete plan, including its scratch
        // allocations and work, rather than dropping its declared class.
        // The zero-payload checks below exclude actual canonical values.
        && matches!(
            call.implementation_memory,
            mech_core::ImplementationMemoryClass::NoAdditionalScratch
                | mech_core::ImplementationMemoryClass::CanonicalFinalize
        )
        && call.output_regions.iter().all(|region| match region {
            RegionAccessPlan::WholeValue
            | RegionAccessPlan::Contiguous { .. }
            | RegionAccessPlan::Strided { .. }
            | RegionAccessPlan::Rectangle { .. }
            | RegionAccessPlan::Gather { .. }
            | RegionAccessPlan::Deferred(mech_core::RegionPolicy::WholeValue) => true,
            RegionAccessPlan::Deferred(policy) => {
                let selectors = match policy {
                    mech_core::RegionPolicy::IndexedAxis { .. }
                    | mech_core::RegionPolicy::SingleElement => 1,
                    mech_core::RegionPolicy::RectangularRegion if call.inputs.len() >= 4 => 2,
                    _ => return false,
                };
                call.inputs.len() >= selectors
                    && call.inputs.iter().rev().take(selectors).all(|port| {
                        matches!(
                            port.value.storage,
                            mech_core::StorageLayoutClass::Scalar {
                                slot: mech_core::PlannedSlotKind::FixedScalar(
                                    mech_core::ScalarMemoryKind::Index
                                        | mech_core::ScalarMemoryKind::Floating(
                                            mech_core::FloatWidth::W64
                                        )
                                )
                            } | mech_core::StorageLayoutClass::DenseColumnMajor {
                                slot: mech_core::PlannedSlotKind::FixedScalar(
                                    mech_core::ScalarMemoryKind::Index
                                        | mech_core::ScalarMemoryKind::Floating(
                                            mech_core::FloatWidth::W64
                                        )
                                )
                            }
                        )
                    })
            }
            RegionAccessPlan::CollectionEntry { .. } => false,
        })
        && call.inputs.iter().chain(&call.outputs).all(|port| {
            matches!(
                port.value.storage,
                mech_core::StorageLayoutClass::Scalar {
                    slot: mech_core::PlannedSlotKind::FixedScalar(_)
                } | mech_core::StorageLayoutClass::DenseColumnMajor {
                    slot: mech_core::PlannedSlotKind::FixedScalar(_)
                }
            ) && port.value.payload.current_bytes == 0
                && port.value.payload.required_bytes == 0
                && port.value.payload.current_nodes == 0
                && port.value.payload.required_nodes == 0
        })
}

/// Reconciles an executor's complete concrete estimate with the declaration-
/// and footprint-derived turn plan. This preserves real node identity,
/// allocations, transactions, and placement while replacing weaker demand
/// components and growing/re-placing publication stages before admission.
#[cfg(feature = "resident-artifact")]
pub(crate) fn apply_observed_turn_demand(
    mut plan: TurnMemoryPlan,
    observed: ResourceDemand,
    final_output: Option<CurrentMemoryFootprint>,
) -> Result<TurnMemoryPlan, MemoryPlanError> {
    if let Some(mut call) = plan.call.clone() {
        if call.outputs.len() == 1
            && (observed.persistent_bytes != 0
                || observed.output_elements != 0
                || final_output.is_some())
        {
            let old = plan
                .facts
                .resolved_footprints
                .get(&(plan.node, PortDirection::Output, 0))
                .copied()
                .unwrap_or_default();
            let fixed = call.outputs[0].value.current_address_span_bytes;
            let retained = final_output
                .map(|f| {
                    f.fixed_bytes
                        .checked_add(f.payload_bytes)
                        .ok_or(MemoryPlanError::TargetAddressOverflow)
                })
                .transpose()?
                .unwrap_or(observed.persistent_bytes);
            let candidate = CurrentMemoryFootprint {
                logical_elements: final_output
                    .map_or(observed.output_elements, |f| f.logical_elements),
                fixed_bytes: fixed,
                payload_bytes: retained.saturating_sub(fixed),
                // Resident preflight reports complete retained bytes. This is
                // a conservative encoded-size bound until a finalized value
                // exists; unlike the published side, it is not a live value.
                encoded_bytes: retained,
                retained_nodes: final_output.map_or(observed.retained_nodes, |f| f.retained_nodes),
                schema_bytes: old.schema_bytes,
                shape_parameter_count: old.shape_parameter_count,
            };
            plan.facts
                .resolved_footprints
                .insert((plan.node, PortDirection::Output, 0), candidate);
            let resolved: BTreeMap<(PortDirection, u16), CurrentMemoryFootprint> = plan
                .facts
                .resolved_footprints
                .iter()
                .filter_map(|(&(node, direction, port), &f)| {
                    (node == plan.node).then_some(((direction, port), f))
                })
                .collect();
            let published = (0..call.outputs.len())
                .map(|ordinal| {
                    plan.facts
                        .published_footprints
                        .get(&(plan.node, ordinal as u16))
                        .copied()
                        .or_else(|| {
                            resolved
                                .get(&(PortDirection::Output, ordinal as u16))
                                .copied()
                        })
                        .unwrap_or_default()
                })
                .collect::<Vec<_>>();
            let complete = derive_turn_call(&mut call, &resolved, Some(&published))?;
            refresh_turn_allocations(
                &mut plan.allocations,
                &call,
                &complete,
                plan.node,
                &plan.facts,
            )?;
            plan.demand = checked_demand_add(complete.demand, plan.facts.additional_demand)?;
            plan.call = Some(scope_turn_call(complete, &call, &plan.allocations));
        }
    }
    let observed = checked_demand_add(observed, plan.facts.additional_demand)?;
    plan.demand = demand_max(plan.demand, observed);
    plan.output_bytes = plan.output_bytes.max(observed.persistent_bytes);
    grow_transaction_stage_total(
        &mut plan.allocations,
        observed.persistent_bytes,
        observed.persistent_bytes,
    )?;
    plan.arenas = place_allocations(&mut plan.allocations)?;
    if let Some(call) = &mut plan.call {
        call.allocations = plan.allocations.clone();
    }
    plan.demand.turn_peak_bytes = plan
        .demand
        .turn_peak_bytes
        .max(turn_storage_peak(&plan.allocations)?);
    plan.storage_buffer_bytes = plan
        .allocations
        .iter()
        .filter(|allocation| matches!(allocation.space, mech_core::MemorySpace::Device { .. }))
        .map(|allocation| allocation.capacity_bytes)
        .max()
        .unwrap_or(0);
    let mut violations = mech_core::evaluate_call_memory_budget(
        MemoryObjectOwner::NodeOutput {
            node: plan.node,
            port: 0,
        },
        plan.demand,
        plan.output_bytes,
        plan.storage_buffer_bytes,
        plan.budget_limits,
    )
    .into_vec();
    // The scoped plan can still contain a provisional candidate. Admission
    // evaluates the complete replacement, not obsolete candidate violations.
    violations.sort();
    violations.dedup();
    plan.budget_violations = violations.into_boxed_slice();
    Ok(plan)
}

/// The runtime must supply live borrowed facts. No footprint can be recovered
/// from an activation allocation plan after a value has changed.
#[cfg(feature = "resident-artifact")]
pub(crate) fn plan_current_resident_turn(
    plan: &ProgramMemoryPlan,
    node: NodeId,
    facts: &TurnMemoryFacts,
) -> Result<TurnMemoryPlan, MemoryPlanError> {
    let (bytes, nodes) = crate::resident::text_index::live_demand();
    if (bytes, nodes) == (0, 0) {
        return plan_turn_memory(plan, node, facts);
    }
    let mut facts = facts.clone();
    facts.additional_demand.turn_peak_bytes = facts
        .additional_demand
        .turn_peak_bytes
        .checked_add(bytes)
        .ok_or(MemoryPlanError::TargetAddressOverflow)?;
    facts.additional_demand.retained_nodes = facts
        .additional_demand
        .retained_nodes
        .checked_add(nodes)
        .ok_or(MemoryPlanError::TargetAddressOverflow)?;
    let mut current = plan_turn_memory(plan, node, &facts)?;
    current.resident_text_index_baseline = (bytes, nodes);
    Ok(current)
}

/// Re-run the complete call derivation with both the live candidate and the
/// distinct published output footprints. Publication comparison is therefore
/// derived once by the core planner rather than patched through subtraction.
fn derive_turn_call(
    template: &mut mech_core::CallMemoryPlan,
    resolved: &BTreeMap<(PortDirection, u16), CurrentMemoryFootprint>,
    published: Option<&[CurrentMemoryFootprint]>,
) -> Result<mech_core::CallMemoryPlan, MemoryPlanError> {
    // Both callers already own a local template. Restore its limits on errors
    // as well as success, before the caller can reuse it for scoping.
    let limits = std::mem::take(&mut template.target.limits);
    let result =
        mech_core::resolve_current_call_memory(template, &template.bound_call, resolved, published);
    template.target.limits = limits;
    let mut call = result?;
    call.target = template.target.clone();
    Ok(call)
}

fn scope_turn_call(
    mut resolved: mech_core::CallMemoryPlan,
    original: &mech_core::CallMemoryPlan,
    allocations: &[AllocationPlan],
) -> mech_core::CallMemoryPlan {
    for (port, global) in resolved
        .inputs
        .iter_mut()
        .zip(&original.inputs)
        .chain(resolved.outputs.iter_mut().zip(&original.outputs))
    {
        port.object = global.object;
    }
    resolved.transactions = original.transactions.clone();
    resolved.allocations = allocations.into();
    resolved
}

/// Refresh stable global objects from a freshly derived call-local plan.
/// Scratch IDs are matched by their declared ordinal, never by allocation order.
fn refresh_turn_allocations(
    allocations: &mut [AllocationPlan],
    original: &mech_core::CallMemoryPlan,
    resolved: &mech_core::CallMemoryPlan,
    node: NodeId,
    facts: &TurnMemoryFacts,
) -> Result<(), MemoryPlanError> {
    for (direction, old_ports, new_ports) in [
        (PortDirection::Input, &original.inputs, &resolved.inputs),
        (PortDirection::Output, &original.outputs, &resolved.outputs),
    ] {
        for (ordinal, (old, new)) in old_ports.iter().zip(new_ports.iter()).enumerate() {
            let current = if direction == PortDirection::Output {
                facts.published_footprints.get(&(node, ordinal as u16))
            } else {
                facts
                    .resolved_footprints
                    .get(&(node, direction, ordinal as u16))
            };
            let Some(current) = current else {
                continue;
            };
            let fixed = allocations
                .iter_mut()
                .find(|a| a.id == old.object)
                .ok_or(MemoryPlanError::DescriptorMismatch)?;
            let owner = fixed.owner.clone();
            fixed.current_bytes = new.value.current_address_span_bytes;
            fixed.capacity_bytes = fixed.capacity_bytes.max(fixed.current_bytes);
            if let Some(payload) = allocations
                .iter_mut()
                .find(|a| a.owner == owner && a.role == mech_core::AllocationRole::VariablePayload)
            {
                payload.current_bytes = current.payload_bytes;
                payload.capacity_bytes = payload.capacity_bytes.max(current.payload_bytes);
                payload.payload_block_capacity = payload
                    .payload_block_capacity
                    .max(current.retained_nodes.max(1));
            }
        }
    }
    for local in resolved
        .allocations
        .iter()
        .filter(|a| matches!(a.owner, MemoryObjectOwner::NodeScratch { .. }))
    {
        let MemoryObjectOwner::NodeScratch { ordinal, .. } = local.owner else {
            unreachable!()
        };
        let global = allocations
            .iter_mut()
            .find(|a| a.owner == MemoryObjectOwner::NodeScratch { node, ordinal })
            .ok_or(MemoryPlanError::DescriptorMismatch)?;
        global.current_bytes = local.current_bytes;
        global.capacity_bytes = local.capacity_bytes;
        global.payload_block_capacity = local.payload_block_capacity;
        global.alignment = local.alignment;
    }
    for (old, new) in original.transactions.iter().zip(&resolved.transactions) {
        if let (Some(primary), Some(resolved_primary)) =
            (transaction_stage(*old), transaction_stage(*new))
        {
            grow_transaction_family(
                allocations,
                primary,
                resolved_primary,
                &resolved.allocations,
            )?;
        }
    }
    Ok(())
}

fn turn_storage_peak(allocations: &[AllocationPlan]) -> Result<u64, MemoryPlanError> {
    let mut events = BTreeMap::<mech_core::MemoryPlanPoint, (u64, u64)>::new();
    for allocation in allocations {
        let (first, last) = match allocation.lifetime {
            mech_core::MemoryLifetime::Turn { first, last }
            | mech_core::MemoryLifetime::Transaction { first, last }
            | mech_core::MemoryLifetime::Transfer { first, last } => (first, last),
            _ => continue,
        };
        let start = events.entry(first).or_default();
        start.0 = start
            .0
            .checked_add(allocation.capacity_bytes)
            .ok_or(MemoryPlanError::TargetAddressOverflow)?;
        let end = events.entry(last).or_default();
        end.1 = end
            .1
            .checked_add(allocation.capacity_bytes)
            .ok_or(MemoryPlanError::TargetAddressOverflow)?;
    }
    let (mut live, mut peak) = (0_u64, 0_u64);
    for (starts, ends) in events.into_values() {
        live = live
            .checked_add(starts)
            .ok_or(MemoryPlanError::TargetAddressOverflow)?;
        peak = peak.max(live);
        live = live
            .checked_sub(ends)
            .ok_or(MemoryPlanError::LifetimeOrderInvalid)?;
    }
    Ok(peak)
}

fn demand_max(left: ResourceDemand, right: ResourceDemand) -> ResourceDemand {
    ResourceDemand {
        persistent_bytes: left.persistent_bytes.max(right.persistent_bytes),
        activation_bytes: left.activation_bytes.max(right.activation_bytes),
        turn_peak_bytes: left.turn_peak_bytes.max(right.turn_peak_bytes),
        transaction_peak_bytes: left
            .transaction_peak_bytes
            .max(right.transaction_peak_bytes),
        cloned_bytes: left.cloned_bytes.max(right.cloned_bytes),
        transfer_bytes: left.transfer_bytes.max(right.transfer_bytes),
        retained_nodes: left.retained_nodes.max(right.retained_nodes),
        output_elements: left.output_elements.max(right.output_elements),
        storage_bindings: left.storage_bindings.max(right.storage_bindings),
        work: mech_core::WorkDemand {
            comparison: left.work.comparison.max(right.work.comparison),
            compute: left.work.compute.max(right.work.compute),
            canonicalization: left.work.canonicalization.max(right.work.canonicalization),
            scalar_instructions: left
                .work
                .scalar_instructions
                .max(right.work.scalar_instructions),
        },
    }
}

fn grow_transaction_family(
    allocations: &mut [AllocationPlan],
    primary: mech_core::MemoryObjectId,
    resolved_primary: mech_core::MemoryObjectId,
    resolved: &[AllocationPlan],
) -> Result<(), MemoryPlanError> {
    let local = resolved
        .iter()
        .find(|a| a.id == resolved_primary)
        .ok_or(MemoryPlanError::DescriptorMismatch)?;
    let fixed = allocations
        .iter_mut()
        .find(|allocation| allocation.id == primary)
        .ok_or(MemoryPlanError::DescriptorMismatch)?;
    let owner = fixed.owner.clone();
    let lifetime = fixed.lifetime;
    fixed.current_bytes = local.current_bytes;
    fixed.capacity_bytes = fixed.capacity_bytes.max(local.capacity_bytes);
    fixed.alignment = local.alignment;
    if let Some(local_payload) = resolved.iter().find(|a| {
        a.owner == local.owner
            && a.lifetime == local.lifetime
            && a.role == mech_core::AllocationRole::VariablePayload
    }) {
        // Standalone calls retain VariablePayload transaction members. Program
        // and Resident projections identify them as TransactionStage members;
        // both represent the same separately owned payload, never header bytes.
        let payload = allocations
            .iter_mut()
            .find(|a| {
                a.owner == owner
                    && a.payload_block_capacity != 0
                    && (a.role == mech_core::AllocationRole::TransactionStage
                        || (a.role == mech_core::AllocationRole::VariablePayload
                            && a.lifetime == lifetime))
            })
            .ok_or(MemoryPlanError::DescriptorMismatch)?;
        payload.current_bytes = local_payload.current_bytes;
        payload.capacity_bytes = payload.capacity_bytes.max(local_payload.capacity_bytes);
        payload.payload_block_capacity = payload
            .payload_block_capacity
            .max(local_payload.payload_block_capacity);
        payload.alignment = local_payload.alignment;
    }
    Ok(())
}

fn grow_transaction_stage_total(
    allocations: &mut [AllocationPlan],
    current_bytes: u64,
    capacity_bytes: u64,
) -> Result<(), MemoryPlanError> {
    let indices = allocations
        .iter()
        .enumerate()
        .filter(|(_, allocation)| {
            allocation.role == mech_core::AllocationRole::TransactionStage
                || (allocation.role == mech_core::AllocationRole::VariablePayload
                    && matches!(
                        allocation.lifetime,
                        mech_core::MemoryLifetime::Transaction { .. }
                    ))
        })
        .map(|(index, _)| index)
        .collect::<Vec<_>>();
    if indices.is_empty() && (current_bytes != 0 || capacity_bytes != 0) {
        return Err(MemoryPlanError::DescriptorMismatch);
    }
    grow_transaction_stage_indices(allocations, &indices, current_bytes, capacity_bytes)
}

fn grow_transaction_stage_indices(
    allocations: &mut [AllocationPlan],
    indices: &[usize],
    current_bytes: u64,
    capacity_bytes: u64,
) -> Result<(), MemoryPlanError> {
    if indices.is_empty() {
        return Ok(());
    }
    let current_total = indices.iter().try_fold(0_u64, |total, &index| {
        total.checked_add(allocations[index].current_bytes).ok_or(
            MemoryPlanError::ArithmeticOverflow {
                field: "transaction family current bytes",
            },
        )
    })?;
    let capacity_total = indices.iter().try_fold(0_u64, |total, &index| {
        total.checked_add(allocations[index].capacity_bytes).ok_or(
            MemoryPlanError::ArithmeticOverflow {
                field: "transaction family capacity bytes",
            },
        )
    })?;
    let target = indices
        .iter()
        .copied()
        .find(|&index| allocations[index].payload_block_capacity != 0)
        .unwrap_or(indices[0]);
    let capacity_delta = capacity_bytes.saturating_sub(capacity_total);
    allocations[target].capacity_bytes = allocations[target]
        .capacity_bytes
        .checked_add(capacity_delta)
        .ok_or(MemoryPlanError::ArithmeticOverflow {
            field: "grown transaction family capacity",
        })?;
    let current_delta = current_bytes.saturating_sub(current_total);
    allocations[target].current_bytes = allocations[target]
        .current_bytes
        .checked_add(current_delta)
        .ok_or(MemoryPlanError::ArithmeticOverflow {
            field: "grown transaction family current bytes",
        })?;
    if allocations[target].current_bytes > allocations[target].capacity_bytes {
        return Err(MemoryPlanError::CapacityBelowCurrent {
            current: allocations[target].current_bytes,
            maximum: allocations[target].capacity_bytes,
        });
    }
    Ok(())
}

fn transaction_stage(transaction: TransactionRequirement) -> Option<mech_core::MemoryObjectId> {
    match transaction {
        TransactionRequirement::StageAndSwap { staged, .. } => Some(staged),
        TransactionRequirement::DoubleBuffer { next, .. } => Some(next),
        TransactionRequirement::UndoSnapshot { undo, .. } => Some(undo),
        _ => None,
    }
}

fn owner_node(owner: &MemoryObjectOwner) -> Option<NodeId> {
    match *owner {
        MemoryObjectOwner::NodeInput { node, .. }
        | MemoryObjectOwner::NodeOutput { node, .. }
        | MemoryObjectOwner::NodeScratch { node, .. }
        | MemoryObjectOwner::TransactionStage { node, .. } => Some(node),
        _ => None,
    }
}

fn transaction_key(transaction: &TransactionRequirement) -> (u8, u32, u32) {
    match *transaction {
        TransactionRequirement::None => (0, 0, 0),
        TransactionRequirement::StageAndSwap { current, staged } => {
            (1, current.get(), staged.get())
        }
        TransactionRequirement::UndoSnapshot { target, undo } => (2, target.get(), undo.get()),
        TransactionRequirement::DoubleBuffer { current, next } => (3, current.get(), next.get()),
    }
}

#[cfg(all(test, feature = "string"))]
#[path = "turn_tests.rs"]
mod tests;

#[cfg(all(test, feature = "string"))]
pub(crate) fn plan_single_call_turn_memory(original: &mech_core::CallMemoryPlan, node: NodeId, facts: &TurnMemoryFacts) -> Result<TurnMemoryPlan, MemoryPlanError> {
 let mut call=original.clone(); for allocation in &mut call.allocations { if let MemoryObjectOwner::NodeScratch { node: owner, .. }=&mut allocation.owner { *owner=node; } }
 let plan=ProgramMemoryPlan { call_nodes: Box::new([node]), allocations: call.allocations.clone(), budget_limits: call.target.limits, calls: Box::new([call]), ..Default::default() }; plan_turn_memory(&plan,node,facts)
}
