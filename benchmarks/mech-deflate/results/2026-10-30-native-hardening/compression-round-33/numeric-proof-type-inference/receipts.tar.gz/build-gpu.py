from pathlib import Path
import json,subprocess,os,time,hashlib,sys,shutil
w=Path('/private/tmp/mech-deflate-linear-stack');r=Path('/private/tmp/mech-numeric-composition-round33-20261030');d=Path(sys.argv[1]);d.mkdir(exist_ok=False)
b=json.loads((r/'proof-build-02/build.json').read_text());c=b['command'][:];c.remove('--test');c[1:1]=['--crate-type','rlib'];c[c.index('-C')+1]='opt-level=1';c[c.index('-o')+1]=str(d/'libmech_gpu.rlib');e={**os.environ,**b['environment']}
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=w,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=w,text=True).splitlines()
files=sorted({p for p in changed if p.startswith('hosts/gpu/') and p.endswith(('.rs','.mec'))})
hashes={p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in files}
for p in files:
 target=d/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(w/p,target)
(d/'source.diff').write_text(subprocess.check_output(['git','diff','--no-ext-diff','HEAD','--','hosts/gpu'],cwd=w,text=True))
meta={'command':c,'environment':b['environment'],'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'source_hashes':hashes,'scope':'Actual maintained GPU production root, opt1 selected-feature semantic diagnostics only; no timing claim'}
t=time.monotonic();p=subprocess.run(c,cwd=w,env=e,capture_output=True,text=True)
(d/'build.stdout').write_text(p.stdout);(d/'build.stderr').write_text(p.stderr);meta.update(exit=p.returncode,seconds=time.monotonic()-t,source_unchanged=all(hashlib.sha256((w/n).read_bytes()).hexdigest()==h for n,h in hashes.items()))
if p.returncode==0:meta['library_sha256']=hashlib.sha256((d/'libmech_gpu.rlib').read_bytes()).hexdigest()
(d/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({k:v for k,v in meta.items() if k not in ['command','source_hashes','environment']},indent=2)+p.stderr[-4500:],flush=True);p.check_returncode();assert meta['source_unchanged']
