from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;receipts=r/'retry';receipts.mkdir();w=Path('/private/tmp/mech-deflate-linear-stack')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((r.parent/'confirmed-primary/current-build.json').read_text());c=b['command'][:-3];i=c.index('-C',c.index('-C')+2);del c[i:i+2];c += [str(r/'generate.rs'),'-o',str(r/'generate')]
def run(label,c,env=None,cwd=w,timeout=120):
 t=time.monotonic();p=subprocess.run(c,cwd=cwd,env=env,capture_output=True,text=True,timeout=timeout)
 (receipts/(label+'.stdout')).write_text(p.stdout);(receipts/(label+'.stderr')).write_text(p.stderr);(receipts/(label+'.json')).write_text(json.dumps({'command':c,'cwd':str(cwd),'exit':p.returncode,'seconds':time.monotonic()-t,'env':{k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_BUILD_JOBS','RUSTFLAGS','CARGO_TARGET_DIR']} if env else None},indent=2)+'\n');p.check_returncode();return p.stdout
p=r/'project';gen=json.loads((r/'generation.json').read_text())
# Use the generated catalog/symbol prefix and exact maintained retry driver.
s=(p/'src/main.rs').read_text();prefix=s.split('fn main()')[0]
template=w/'hosts/gpu/tests/support/linked_assertion_retry.rs.in';driver=template.read_text().replace('include_bytes!("../../native-descriptor.bin")','include_bytes!("../../native-descriptor.bin")')
# Generated main's imports before fn main also include launcher-only items; use
# the maintained fixture's exact prefix boundary before its launcher import.
newprefix=prefix.replace('use mech_gpu::native_artifact::{NATIVE_PROGRAM_LINK_IDENTITY_BYTES, launch::{BuildOwnedProgramBinding, run_program_application}};', 'use mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES;')
assert 'CORE_ASSIGN_INDEXED_AXIS' in newprefix and 'SEQUENCE_LENGTH' in newprefix
(p/'src/bin/lexical-retry.rs').write_text(newprefix+driver)
shutil.copyfile(w/'Cargo.lock',p/'Cargo.lock')
env={**os.environ,'RUSTUP_TOOLCHAIN':'nightly-2026-03-03','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_BUILD_JOBS':'1','RUSTFLAGS':'-D warnings','CARGO_TARGET_DIR':'/private/tmp/mech-child-loops-round28-20261029/linked/cargo-target'}
metadata=json.loads(run('metadata',['cargo','metadata','--offline','--format-version','1','--manifest-path',str(p/'Cargo.toml')],env=env,cwd=Path('/')))
rows=run('build',['cargo','build','--offline','--locked','--message-format=json','--manifest-path',str(p/'Cargo.toml'),'--bin','lexical-retry'],env=env,cwd=Path('/'),timeout=900)
rows=[json.loads(l) for l in rows.splitlines() if l.startswith('{')];assert rows[-1]=={'reason':'build-finished','success':True}
units=[{'name':x['target']['name'],'features':x['features']} for x in rows if x.get('reason')=='compiler-artifact' and 'custom-build' not in x['target']['kind']]
assert not [x for x in units if x['name']=='mech_syntax' or x['name'].startswith('cranelift')]
for x in units:
 if x['name']=='mech_gpu':assert x['features']==['canonical-native-program-runtime','canonical-native-runtime']
 if x['name']=='mech_engine':assert not set(x['features'])&{'compiler','source','semantic-compiler'}
exe=next(x['executable'] for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']=='lexical-retry')
stdout=run('run',[exe,'1000000000','268435456','134217728','1000000','134217728','--',str(r/'input.json')],timeout=30)
assert stdout==(r/'expected.stdout').read_text();assert not (r/'run.stderr').read_text()
# Generated build script checks all pins. Confirm files still match manifest.
closure={'executed':True,'runtime_only':True,'performance_observations':0,'units':units,'driver_template_sha256':digest(template),'generated_source_sha256':digest(r/'source.mec'),'driver_sha256':digest(p/'src/bin/lexical-retry.rs'),'binary_sha256':digest(Path(exe)),'valid_reject_valid':[3,0,2],'successful_outputs':[4,6],'error_before_division':True,'prior_publication_alias_and_cleanup_recovery_asserted':True,'orchestration':'Same public generator/Object/descriptor and maintained retry driver; direct Cargo CLI instead of mech_build Rust test launcher.','pins':gen['pins']}
(receipts/'closure.json').write_text(json.dumps(closure,indent=2)+'\n');print(json.dumps(closure,indent=2))
