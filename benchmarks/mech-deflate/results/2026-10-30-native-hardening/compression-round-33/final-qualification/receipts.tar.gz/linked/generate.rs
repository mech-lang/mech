use mech_engine::{CanonicalSourceFrontend,ProgramArtifact};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
use mech_core::{ValueDataDraft as Data,snapshot::{ValueDraft,SnapshotValidationContext}};
use std::path::Path;
fn main(){
 let root=Path::new("/private/tmp/mech-numeric-composition-round33-20261030/linked");let text=std::fs::read_to_string(root.join("source.mec")).unwrap();let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(71),Revision(1),text.as_str()).unwrap(),ParseConfig::default());assert!(parsed.is_strictly_clean());let a:ProgramArtifact=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap();
 let generated=mech_gpu::native_artifact::generate_linked_program_application(Path::new("/private/tmp/mech-deflate-linear-stack"),&root.join("project"),"checked-assertion",&a,&mech_stdlib::source_catalog(),text.as_bytes()).unwrap();
 std::fs::write(root.join("generation.json"),serde_json::to_vec_pretty(&serde_json::json!({"metadata":generated.metadata(),"pins":generated.pins(),"manifest":generated.manifest_path()})).unwrap()).unwrap();
 assert_eq!(a.inputs().len(),1);assert_eq!(a.outputs().len(),1);
 let draft=ValueDraft{schema:a.inputs()[0].schema,shape_values:Box::new([]),data:Data::U64(3)};
 std::fs::write(root.join("input.json"),serde_json::to_vec(&vec![draft]).unwrap()).unwrap();
 let value=ValueDraft{schema:a.outputs()[0].schema,shape_values:Box::new([]),data:Data::U64(6)}.finalize(&SnapshotValidationContext::new(a.schemas())).unwrap();
 let expected=value.canonical_snapshot_bytes(a.schemas()).unwrap().iter().map(|b|format!("{b:02x}")).collect::<String>()+"\n";
 std::fs::write(root.join("expected.stdout"),expected).unwrap();
}
