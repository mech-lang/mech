from pathlib import Path
import json, subprocess, os, time, re
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'engine-units';p.mkdir()
b=json.loads((r/'unit-template.json').read_text())
def run(label,cmd,count=None):
 t=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'environment':b['environment'],'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'exit':q.returncode,'seconds':time.monotonic()-t}
 if count is not None:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,row,flush=True)
 subprocess.run(['python3',str(r/'archive.py'),'engine-'+label,str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/(label+'.json')),str(r/'engine-tests.py')],cwd=w,check=True)
 if q.returncode:print(q.stdout[-3000:]+q.stderr[-8000:],flush=True)
 q.check_returncode()
 if count is not None:assert row['executed_tests']==count
run('build',b['command'])
run('prefix',[str(r/'engine-unit-tests'),'record_selector::tests','--nocapture','--test-threads=1'],5)
run('budget',[str(r/'engine-unit-tests'),'resident::budget::tests::','--nocapture','--test-threads=1'])
