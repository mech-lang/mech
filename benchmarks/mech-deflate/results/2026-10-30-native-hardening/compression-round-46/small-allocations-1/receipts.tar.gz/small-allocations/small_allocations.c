#include <execinfo.h>
#include <mach/mach_time.h>
#include <mach-o/dyld.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern size_t mi_usable_size(const void *);
#define SITE_CAP 8192
#define LIVE_CAP 65536
#define DEPTH 128
struct site {void *frames[DEPTH];int depth;uint64_t count,bytes,min,max,freed,survivors,ticks,total_age,max_age;uint64_t phases[4],free_phases[4];};
struct live {uintptr_t address;uint32_t site;uint64_t tick,sequence;};
static struct site sites[SITE_CAP];
static struct live live[LIVE_CAP];
static size_t used_sites;
static uint64_t sequence, requests, bytes, large_requests, large_bytes, phases[4], phase_bytes[4];
static int active,phase;
static struct mach_timebase_info timebase;
static void fail(const char *why){fputs(why,stderr);abort();}
static size_t slot(uintptr_t address){size_t i=((address>>4)*11400714819323198485ull)&(LIVE_CAP-1);for(size_t n=0;n<LIVE_CAP;n++,i=(i+1)&(LIVE_CAP-1)){if(live[i].address==address||live[i].address==0)return i;}fail("allocation live table exhausted\n");return 0;}
static void finish(uintptr_t address){if(!active||!address)return;size_t i=slot(address);if(!live[i].address)return;struct live old=live[i];struct site *s=&sites[old.site];s->freed++;s->ticks+=mach_absolute_time()-old.tick;uint64_t age=sequence-old.sequence;s->total_age+=age;if(age>s->max_age)s->max_age=age;s->free_phases[phase]++;
// Backward shift deletion preserves every colliding probe chain.
size_t hole=i,j=(i+1)&(LIVE_CAP-1);live[hole].address=0;
while(live[j].address){struct live moved=live[j];live[j].address=0;size_t destination=slot(moved.address);live[destination]=moved;j=(j+1)&(LIVE_CAP-1);}}
static void request(void *ptr,size_t size){if(!active||!ptr)return;requests++;bytes+=size;phases[phase]++;phase_bytes[phase]+=size;sequence++;if(size>=65536){large_requests++;large_bytes+=size;return;}void *frames[DEPTH];int depth=backtrace(frames,DEPTH);if(depth==DEPTH)fail("allocation stack truncated\n");size_t at=0;for(;at<used_sites;at++)if(sites[at].depth==depth&&!memcmp(sites[at].frames,frames,(size_t)depth*sizeof(void*)))break;if(at==used_sites){if(at==SITE_CAP)fail("allocation site table exhausted\n");used_sites++;sites[at].depth=depth;memcpy(sites[at].frames,frames,(size_t)depth*sizeof(void*));sites[at].min=size;}struct site *s=&sites[at];s->count++;s->bytes+=size;s->phases[phase]++;if(size<s->min)s->min=size;if(size>s->max)s->max=size;size_t i=slot((uintptr_t)ptr);if(live[i].address)fail("duplicate live allocation\n");live[i]=(struct live){(uintptr_t)ptr,(uint32_t)at,mach_absolute_time(),sequence};}
size_t probe_usable(void *ptr){return ptr?mi_usable_size(ptr):0;}
void probe_alloc(void *ptr,size_t size){request(ptr,size);}
void probe_realloc(uintptr_t old,size_t old_size,void *ptr,size_t size){(void)old_size;if(!ptr)return;finish(old);request(ptr,size);}
void probe_free(void *ptr){finish((uintptr_t)ptr);}
void probe_phase(int value){if(active){if(value<1||value>3)fail("bad allocation phase\n");phase=value;}}
void probe_begin(void){if(active)fail("nested allocation probe\n");memset(sites,0,sizeof(sites));memset(live,0,sizeof(live));memset(phases,0,sizeof(phases));memset(phase_bytes,0,sizeof(phase_bytes));used_sites=sequence=requests=bytes=large_requests=large_bytes=0;mach_timebase_info(&timebase);phase=1;active=1;}
void probe_end(void){active=0;for(size_t i=0;i<LIVE_CAP;i++)if(live[i].address)sites[live[i].site].survivors++;}
void probe_print(uint64_t sample){
#define U(x) ((unsigned long long)(x))
fprintf(stderr,"SMALL_ALLOCATIONS {\"sample\":%llu,\"image_base\":\"%p\",\"requests\":%llu,\"bytes\":%llu,\"large_requests\":%llu,\"large_bytes\":%llu,\"phase_requests\":[%llu,%llu,%llu],\"phase_bytes\":[%llu,%llu,%llu],\"timebase\":[%u,%u],\"sites\":[",U(sample),(void*)_dyld_get_image_header(0),U(requests),U(bytes),U(large_requests),U(large_bytes),U(phases[1]),U(phases[2]),U(phases[3]),U(phase_bytes[1]),U(phase_bytes[2]),U(phase_bytes[3]),timebase.numer,timebase.denom);
for(size_t i=0;i<used_sites;i++){struct site *s=&sites[i];fprintf(stderr,"%s{\"count\":%llu,\"bytes\":%llu,\"min\":%llu,\"max\":%llu,\"freed\":%llu,\"survivors\":%llu,\"lifetime_ticks\":%llu,\"total_age_requests\":%llu,\"max_age_requests\":%llu,\"phases\":[%llu,%llu,%llu],\"free_phases\":[%llu,%llu,%llu],\"stack\":[",i?",":"",U(s->count),U(s->bytes),U(s->min),U(s->max),U(s->freed),U(s->survivors),U(s->ticks),U(s->total_age),U(s->max_age),U(s->phases[1]),U(s->phases[2]),U(s->phases[3]),U(s->free_phases[1]),U(s->free_phases[2]),U(s->free_phases[3]));for(int f=0;f<s->depth;f++)fprintf(stderr,"%s\"%p\"",f?",":"",s->frames[f]);fputs("]}",stderr);}fputs("]}\n",stderr);
}
