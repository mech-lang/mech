from pathlib import Path
import hashlib,json,subprocess,time,shutil
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'small-allocations';p.mkdir()
# Attribution is diagnostic-only and uses the retained baseline library graph.
baseline=Path('/private/tmp/mech-frame-pack-move-round43-20261031');base=json.loads((baseline/'linked-primary/after/worker-build.json').read_text())
shutil.copyfile(r/'small_allocations.c',p/'small_allocations.c')
allocator=(baseline/'counters/allocation_profile.rs').read_text();allocator=allocator.replace('fn probe_print(sample:u64);','fn probe_print(sample:u64);\n    fn probe_phase(phase:i32);');allocator+='\npub fn phase(value:i32){unsafe{probe_phase(value)}}\n';(p/'allocation_profile.rs').write_text(allocator)
s=(baseline/'counters/after/memory.rs').read_text().replace(str(baseline/'counters/allocation_profile.rs'),str(p/'allocation_profile.rs'))
s=s.replace('&LINKED_IDENTITY,linked_entry)', '&LINKED_IDENTITY,traced_entry)')
s+='\n// SAFETY: same pinned linked entry and initialized frame; diagnostics only mark its dynamic extent.\nunsafe extern "C" fn traced_entry(frame:*mut std::ffi::c_void)->u64{allocation_profile::phase(2);let result=unsafe{linked_entry(frame)};allocation_profile::phase(3);result}\n'
(p/'worker.rs').write_text(s)
def run(label,cmd):
 t=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 (p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t,'baseline_compiler':'b12f6c5afb2c859f6cde29ba566ddf09e70d2f79','libraries':base['libraries'],'scope':'Separate allocation-stack diagnostic; no elapsed-performance claim.'},indent=2)+'\n')
 if q.returncode:print(q.stdout[-2000:]+q.stderr[-5000:],flush=True)
 q.check_returncode();return q
run('probe-build',['clang','-O2','-fno-omit-frame-pointer','-c',str(p/'small_allocations.c'),'-o',str(p/'probe.o')])
cmd=base['command'].copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'probe.o')];run('worker-build',cmd)
for repetition in range(2):
 q=run('run'+str(repetition),[str(p/'worker'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','1'])
 rows=[json.loads(line.removeprefix('SMALL_ALLOCATIONS ')) for line in q.stderr.splitlines() if line.startswith('SMALL_ALLOCATIONS ')]
 assert len(rows)==3
 for row in rows:
  assert row['requests']==13994 and row['bytes']==98586843
  assert row['large_requests']==50 and row['large_bytes']==97129588
  assert sum(site['count'] for site in row['sites'])==13944
  assert sum(site['bytes'] for site in row['sites'])==1457255
  assert all(site['freed']+site['survivors']==site['count'] for site in row['sites'])
 assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
 outputs=[json.loads(line) for line in q.stdout.splitlines() if line.startswith('{')]
 assert len(outputs)==3 and all(row['exact_reference'] and row['independent_inflation'] and row['work']==60260219686 and row['capacity']==13 for row in outputs)
 row=rows[1];addresses=list(dict.fromkeys(address for site in row['sites'] for address in site['stack']))
 q=run('symbols'+str(repetition),['atos','-o',str(p/'worker'),'-arch','arm64','-l',row['image_base'],*addresses]);symbols=q.stdout.splitlines();assert len(symbols)==len(addresses)
 mapping=dict(zip(addresses,symbols))
 for site in row['sites']:site['symbols']=[mapping[a] for a in site['stack']]
 (p/('resolved'+str(repetition)+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'small-allocations-'+str(repetition),*map(str,[f for f in p.iterdir() if f.is_file() and f.name not in {'worker','probe.o'}]),str(r/'small-allocations.py')],cwd=w,check=True)
 print('SMALL ALLOCATION TRACE',repetition,'RECONCILED',row['phase_requests'],len(row['sites']),flush=True)
