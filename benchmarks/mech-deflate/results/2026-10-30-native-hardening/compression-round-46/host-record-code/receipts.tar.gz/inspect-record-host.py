from pathlib import Path
import subprocess,json,re,collections,hashlib,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'host-record-code';p.mkdir();result={}
for label in ['before','after']:
 binary=r/'linked-primary'/label/'worker';cmd=['xcrun','nm','-n',str(binary)];q=subprocess.run(cmd,capture_output=True,text=True);q.check_returncode()
 selected=[x for x in q.stdout.splitlines() if any(name in x.split()[-1] for name in ['check_buffer_record_ordinal','admit_buffer_record_child','ordinal_in_context','try_charge_scoped_prefix']) and x.split()[-2] in ['t','T']]
 (p/(label+'.symbols')).write_text('\n'.join(selected)+'\n');assert selected, 'No selected record-admission symbol found'
 result[label]={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'symbol_command':cmd,'functions':[]}
 for index,line in enumerate(selected):
  symbol=line.split()[-1];cmd=['xcrun','llvm-objdump','--disassemble','--no-show-raw-insn','--disassemble-symbols='+symbol,str(binary)];at=time.monotonic();q=subprocess.run(cmd,capture_output=True,text=True);q.check_returncode()
  stem=label+'-'+str(index);(p/(stem+'.stdout')).write_text(q.stdout);(p/(stem+'.stderr')).write_text(q.stderr)
  mnemonics=collections.Counter();calls=[]
  for instruction in q.stdout.splitlines():
   match=re.match(r'^\s*[0-9a-f]+:\s+([a-z][a-z0-9.]*)\s*(.*)$',instruction)
   if match:
    mnemonics[match[1]]+=1
    if match[1] in ['bl','blr']:calls.append(match[2])
  assert sum(mnemonics.values())>0,(symbol,q.stderr)
  result[label]['functions'].append({'symbol':symbol,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'instruction_sites':sum(mnemonics.values()),'atomic_instruction_sites':{k:v for k,v in mnemonics.items() if k.startswith(('ldadd','ldaxr','ldxr','stlxr','stxr','cas'))},'mnemonics':dict(mnemonics),'calls':calls,'scope':'Static selected host function; includes branches/errors/unreached paths, not dynamic counts.'})
(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({label:[{k:f[k] for k in ['symbol','instruction_sites','atomic_instruction_sites']} for f in result[label]['functions']] for label in result},indent=2),flush=True)
# Archived sequentially after the running qualification driver finishes.
