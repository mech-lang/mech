from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');root=r/'linked-primary';root.mkdir(exist_ok=True)
variants=[('baseline',Path('/private/tmp/mech-buffer-ownership-round38-20261030/primary/current-build.json'),'dc77024f29f373f0938695531ab2b7c975bb1e7e',44443824446),('initial',r/'primary/current-build.json','552e537fcbcfc3811ce442c982010b5e1e999e6c',60260219686),('refined',r/'primary-final/current-build.json','892275fec5b462ca76f0ba47a34dfefb6096c6bc',56891416710)]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc')
assert digest(artifact)=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
assert digest(artifact.with_suffix('.mec'))=='331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9'
worker_source=(r/'workers/session.rs').read_text();normalized=None
needle='let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();'
assert worker_source.count(needle)==1
for label,build,revision,work in variants:
 p=root/label;p.mkdir(exist_ok=True);base=json.loads(build.read_text())
 for lib in base['libraries'].values():assert digest(Path(lib['path']))==lib['sha256']
 def command(name,cmd):
  at=time.monotonic()
  with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
  (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':revision,'libraries':base['libraries']},indent=2)+'\n');q.check_returncode();print(label,name,'COMPLETE',flush=True)
 if label=='baseline':
  old=Path('/private/tmp/mech-buffer-ownership-round38-20261030/generated-object')
  for name in ['object.o','descriptor.json','metadata.json']:shutil.copy2(old/name,p/name)
 else:
  source=Path('/private/tmp/mech-retirement-round36-20261030/object/inspect.rs').read_text().replace('/private/tmp/mech-retirement-round36-20261030/object',str(p));(p/'inspect.rs').write_text(source)
  cmd=base['command'].copy();cmd[-3]=str(p/'inspect.rs');cmd[-1]=str(p/'inspect');command('object-build',cmd);command('emit',[str(p/'inspect')])
 meta=json.loads((p/'metadata.json').read_text());identity=meta['identity_symbol'];entry=meta['entry_symbol']
 pins={name:{'sha256':digest(p/name),'bytes':(p/name).stat().st_size} for name in ['object.o','descriptor.json','metadata.json']}
 prefix='unsafe extern "C" {\n #[link_name="'+identity+'"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES];\n #[link_name="'+entry+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64;\n}\n'
 replacement='// SAFETY: the build pins this SAME unchanged emitted Object, image, bytecode and compiler libraries before link; symbols have program lifetime.\n let jit=unsafe {mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("'+str(p/'descriptor.json')+'"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();'
 source=prefix+worker_source.replace(needle,replacement).replace('"phase":"compiled"','"phase":"linked-compressor-image-restored"')
 norm=source.replace(identity,'<IDENTITY>').replace(str(p/'descriptor.json'),'<IMAGE>')
 if normalized is None:normalized=norm
 else:assert normalized==norm,'Worker bodies differ beyond same-build binding'
 (p/'worker.rs').write_text(source)
 cmd=base['command'].copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'object.o')];command('worker-build',cmd)
 (p/'binding.json').write_text(json.dumps({'compiler_source':revision,'expected_work':work,'pins':pins,'worker_sha256':digest(p/'worker'),'worker_source_sha256':digest(p/'worker.rs'),'original_worker_sha256':digest(r/'workers/session.rs'),'normalized_source_sha256':hashlib.sha256(norm.encode()).hexdigest(),'libraries':base['libraries'],'scope':'New matched linked-compressor configuration for ALL three versions; seed/clear helpers keep identical tiny JIT setup outside timing. The original compression timer, input, source, bytecode, allocations and allocator are unchanged. No JIT-to-linked speed credit.'},indent=2)+'\n')
 command('smoke',[str(p/'worker'),str(artifact),'0'])
 rows=[json.loads(line) for line in (p/'smoke.stdout').read_text().splitlines() if line.startswith('{')];assert len(rows)==2 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==work for x in rows);assert (p/'smoke.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
 command('sections',['xcrun','size','-m',str(p/'object.o')])
 files=[f for f in p.iterdir() if f.is_file() and f.name not in {'object.o','descriptor.json','inspect','worker'}]
 subprocess.run(['python3',str(r/'archive.py'),'linked-build-'+label,*map(str,files),str(r/'linked-build.py')],cwd=w,check=True)
