from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'unit-refined';p.mkdir(exist_ok=True)
base=json.loads(Path('/private/tmp/mech-buffer-ownership-round38-20261030/final-unit/build.json').read_text());cmd=base['command'].copy();cmd[-1]=str(p/'gpu-unit-tests')
def run(label,command):
 at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(command,cwd=w,env={**os.environ,**base['environment']},stdout=out,stderr=err)
 (p/(label+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':base['environment'],'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2)+'\n')
 print(label,q.returncode,time.monotonic()-at,flush=True)
 if q.returncode:print((p/(label+'.stderr')).read_text()[-6000:]+(p/(label+'.stdout')).read_text()[-5000:],flush=True)
 q.check_returncode()
run('format',['cargo','+nightly-2026-03-03','fmt','--all'])
run('build',cmd)
run('focused',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::composition_tests::','--nocapture','--test-threads=1'])
assert '6 passed; 0 failed' in (p/'focused.stdout').read_text()
subprocess.run(['python3',str(r/'archive.py'),'focused-unit-refined',str(p),str(r/'unit-refined.py')],cwd=w,check=True)
