from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'red';p.mkdir(exist_ok=True)
base=json.loads(Path('/private/tmp/mech-buffer-ownership-round38-20261030/final-components/build.json').read_text());cmd=base['command'].copy();cmd[-1]=str(p/'tests')
def run(label,command):
 at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(command,cwd=w,env={**os.environ,**base.get('environment',{})},stdout=out,stderr=err)
 (p/(label+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':base.get('environment',{}),'frozen_compiler':'dc77024f29f373f0938695531ab2b7c975bb1e7e'},indent=2)+'\n');return q.returncode
assert run('build',cmd)==0
assert run('run',[str(p/'tests'),'optimal_path_qualification::path_scan_emits_native_pieces_around_its_nested_scalar_child','--exact','--nocapture','--test-threads=1'])==101
text=(p/'run.stdout').read_text()+(p/'run.stderr').read_text();assert '0 passed; 1 failed' in text and 'unchanged path scan must emit native pieces' in text
subprocess.run(['python3',str(r/'archive.py'),'red-component',str(p),str(r/'red.py')],cwd=w,check=True)
print('RED_CONFIRMED missing actual path selection',flush=True)
