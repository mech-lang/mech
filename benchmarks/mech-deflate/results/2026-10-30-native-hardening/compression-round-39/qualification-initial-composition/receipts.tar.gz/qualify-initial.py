from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'qualification-initial';p.mkdir(exist_ok=True)
libs=json.loads((r/'final-libraries.json').read_text());base=json.loads(Path('/private/tmp/mech-buffer-ownership-round38-20261030/final-components/build.json').read_text())
def run(label,cmd,env=None,count=None):
 at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**(env or {})},stdout=out,stderr=err)
 receipt={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':env or {},'compiler_source':'552e537fcbcfc3811ce442c982010b5e1e999e6c'}
 if count is not None:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;', (p/(label+'.stdout')).read_text());receipt['executed_tests']=int(m[1]) if m else None
 (p/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 if q.returncode:print((p/(label+'.stderr')).read_text()[-4000:]+(p/(label+'.stdout')).read_text()[-5000:],flush=True)
 q.check_returncode()
 if count is not None:assert receipt['executed_tests']==count,(label,receipt)
 subprocess.run(['python3',str(r/'archive.py'),'qualification-initial-'+label,*map(str,[p/(label+'.json'),p/(label+'.stdout'),p/(label+'.stderr'),r/'qualify-initial.py'])],cwd=w,check=True)
 print(label,'COMPLETE',receipt.get('executed_tests'),flush=True)
u=r/'unit/gpu-unit-tests'
run('runtime',[str(u),'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--nocapture','--test-threads=1'],count=313)
run('work-values',[str(u),'native_artifact::work::','native_artifact::memory::','native_artifact::values::','--nocapture','--test-threads=1'],count=31)
cmd=base['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern' and a.split('=')[0] in libs:key=a.split('=')[0];cmd[i]=key+'='+libs[key]['path']
cmd[-1]=str(p/'tests');run('component-build',cmd,base['environment'])
run('path-mechanism',[str(p/'tests'),'optimal_path_qualification::path_scan_emits_native_pieces_around_its_nested_scalar_child','--exact','--nocapture','--test-threads=1'],base['environment'],1)
for label,name,count in [('components','existing',234),('composition','connected',8)]:
 d=json.loads(Path('/private/tmp/mech-buffer-ownership-round38-20261030/final-components/'+name+'.json').read_text());cmd=d['command'].copy();cmd[0]=str(p/'tests');run(label,cmd,base['environment'],count)
