from pathlib import Path
import hashlib,json,statistics,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'preflight-refined';p.mkdir(exist_ok=True)
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [x for x in active if Path(x.strip()).name in {'rustc','cargo','tests','gpu-unit-tests','before','after','current','roc-profile','native_frame_transport'}]
reference=Path('/private/tmp/mech-deflate-profiling-20261028/roc-profile');assert hashlib.sha256(reference.read_bytes()).hexdigest()=='3941ef59b2c9343d0493cc6b6d14ca4803e6bd27acfe520b1fb59d9b63026324'
command=[str(reference),'12'];at=time.monotonic()
with (p/'reference.stdout').open('w') as out,(p/'reference.stderr').open('w') as err:q=subprocess.run(command,cwd=w,stdout=out,stderr=err)
q.check_returncode();rows=[line.split('\t') for line in (p/'reference.stdout').read_text().splitlines() if line.startswith('rep\troc-deflate\t')];assert len(rows)==20000;ref=statistics.median(int(row[3]) for row in rows)/1e9
(p/'reference.json').write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'median_seconds':ref,'observations':len(rows),'diagnostic_preflight_only':True},indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'preflight-refined-reference',str(p/'reference.json'),str(p/'reference.stdout'),str(p/'reference.stderr'),str(r/'preflight-refined.py')],cwd=w,check=True)
summary={'scope':'One early complete eight-byte pair after focused correctness, before broader qualification. Not a confirmed gain. No other build/test/profile overlaps. Native sources: baseline dc77024f2, initial 552e537fc, refined 892275fec; same frozen source/bytecode/allocator/timer.','reference_seconds':ref,'fixed_reference_seconds':0.000300,'observations':{}}
for label,binary in [('before',Path('/private/tmp/mech-buffer-ownership-round38-20261030/primary/current')),('initial',r/'primary/current'),('after',r/'primary-final/current')]:
 command=[str(binary),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','32'];at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(command,cwd=w,stdout=out,stderr=err)
 (p/(label+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'primary_comparison_claimed':False},indent=2)+'\n');q.check_returncode();rows=[json.loads(line) for line in (p/(label+'.stdout')).read_text().splitlines() if line.startswith('{')];assert len(rows)==34 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 for x in rows);assert (p/(label+'.stderr')).read_text().endswith('CLEANUP bytes=0 nodes=0\n');steady=[x for x in rows if not x['warmup'] and not x['profile']];assert len(steady)==32;work=sorted(set(x['work'] for x in rows));assert len(work)==1
 if label=='before':assert work==[44443824446]
 median=statistics.median(x['seconds'] for x in steady);summary['observations'][label]={'median_seconds':median,'multiple_of_reference':median/ref,'multiple_of_fixed_reference':median/.000300,'work':work,'steady_calls':len(steady)}
 if label=='after':summary['after_over_before']=median/summary['observations']['before']['median_seconds']
 (p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');subprocess.run(['python3',str(r/'archive.py'),'preflight-refined-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/'summary.json')],cwd=w,check=True);print(label,summary['observations'][label],flush=True)
print('PREFLIGHT_RATIO',summary['after_over_before'],flush=True)
