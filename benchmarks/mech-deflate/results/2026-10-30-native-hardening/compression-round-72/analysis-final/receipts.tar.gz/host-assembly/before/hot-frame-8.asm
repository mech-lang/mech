
/private/tmp/mech-checked-compute-inline-round72-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015b1664 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>:
1015b1664:     	stp	x20, x19, [sp, #-0x20]!
1015b1668:     	stp	x29, x30, [sp, #0x10]
1015b166c:     	add	x29, sp, #0x10
1015b1670:     	mov	x19, x4
1015b1674:     	cmp	x3, x2
1015b1678:     	b.hs	0x1015b16c8 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_+0x64>
1015b167c:     	mov	w8, #0x170              ; =368
1015b1680:     	madd	x8, x3, x8, x1
1015b1684:     	add	x9, x8, #0x148
1015b1688:     	ldr	q0, [x9]
1015b168c:     	stur	q0, [x0, #0x4]
1015b1690:     	ldp	q0, q1, [x19]
1015b1694:     	stur	q0, [x0, #0x18]
1015b1698:     	ldr	w8, [x8, #0x158]
1015b169c:     	str	w8, [x0, #0x14]
1015b16a0:     	stur	q1, [x0, #0x28]
1015b16a4:     	ldr	q0, [x19, #0x20]
1015b16a8:     	stur	q0, [x0, #0x38]
1015b16ac:     	ldr	x8, [x19, #0x30]
1015b16b0:     	str	x8, [x0, #0x48]
1015b16b4:     	mov	w8, #0x3                ; =3
1015b16b8:     	str	w8, [x0]
1015b16bc:     	ldp	x29, x30, [sp, #0x10]
1015b16c0:     	ldp	x20, x19, [sp], #0x20
1015b16c4:     	ret
1015b16c8:     	adrp	x8, 0x107f0e000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.84+0xe0>
1015b16cc:     	add	x8, x8, #0xec8
1015b16d0:     	mov	x0, x3
1015b16d4:     	mov	x1, x2
1015b16d8:     	mov	x2, x8
1015b16dc:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b16e0:     	brk	#0x1
1015b16e4:     	mov	x20, x0
1015b16e8:     	mov	x0, x19
1015b16ec:     	bl	0x1015ae7d0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015b16f0:     	mov	x0, x20
1015b16f4:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
