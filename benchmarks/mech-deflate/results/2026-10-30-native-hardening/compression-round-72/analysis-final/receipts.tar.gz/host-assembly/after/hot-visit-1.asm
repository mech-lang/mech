
/private/tmp/mech-checked-compute-inline-round72-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015c9328 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>:
1015c9328:     	stp	x28, x27, [sp, #-0x60]!
1015c932c:     	stp	x26, x25, [sp, #0x10]
1015c9330:     	stp	x24, x23, [sp, #0x20]
1015c9334:     	stp	x22, x21, [sp, #0x30]
1015c9338:     	stp	x20, x19, [sp, #0x40]
1015c933c:     	stp	x29, x30, [sp, #0x50]
1015c9340:     	add	x29, sp, #0x50
1015c9344:     	sub	sp, sp, #0x2e0
1015c9348:     	mov	x19, x8
1015c934c:     	ldr	x8, [x0, #0x238]
1015c9350:     	ldr	w9, [x0, #0x268]
1015c9354:     	cmp	x8, #0x3
1015c9358:     	ccmp	w9, #0x0, #0x4, ne
1015c935c:     	b.ne	0x1015c9390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x68>
1015c9360:     	ldr	x8, [x0, #0xc0]
1015c9364:     	cmp	x8, #0x2
1015c9368:     	b.ne	0x1015c93ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84>
1015c936c:     	ldr	x8, [x0, #0xa8]
1015c9370:     	cbz	x8, 0x1015c93e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc0>
1015c9374:     	str	wzr, [x19]
1015c9378:     	mov	w8, #0xc                ; =12
1015c937c:     	strb	w8, [x19, #0x8]
1015c9380:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9384:     	add	x8, x8, #0x46
1015c9388:     	mov	w9, #0x2a               ; =42
1015c938c:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9390:     	str	wzr, [x19]
1015c9394:     	mov	w8, #0xc                ; =12
1015c9398:     	strb	w8, [x19, #0x8]
1015c939c:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c93a0:     	add	x8, x8, #0x1ce
1015c93a4:     	mov	w9, #0x24               ; =36
1015c93a8:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c93ac:     	str	wzr, [x19]
1015c93b0:     	mov	w8, #0xc                ; =12
1015c93b4:     	strb	w8, [x19, #0x8]
1015c93b8:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c93bc:     	add	x8, x8, #0x12
1015c93c0:     	mov	w9, #0x34               ; =52
1015c93c4:     	stp	x8, x9, [x19, #0x10]
1015c93c8:     	add	sp, sp, #0x2e0
1015c93cc:     	ldp	x29, x30, [sp, #0x50]
1015c93d0:     	ldp	x20, x19, [sp, #0x40]
1015c93d4:     	ldp	x22, x21, [sp, #0x30]
1015c93d8:     	ldp	x24, x23, [sp, #0x20]
1015c93dc:     	ldp	x26, x25, [sp, #0x10]
1015c93e0:     	ldp	x28, x27, [sp], #0x60
1015c93e4:     	ret
1015c93e8:     	mov	x20, x1
1015c93ec:     	ldrb	w8, [x0, #0x508]
1015c93f0:     	tbz	w8, #0x0, 0x1015c942c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
1015c93f4:     	ldr	x8, [x0, #0x498]
1015c93f8:     	ldr	w9, [x8, #0x300]
1015c93fc:     	cmp	w9, #0x1
1015c9400:     	b.ne	0x1015c942c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
1015c9404:     	ldr	w8, [x8, #0x304]
1015c9408:     	cmp	x20, x8
1015c940c:     	b.ne	0x1015c942c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
1015c9410:     	str	wzr, [x19]
1015c9414:     	mov	w8, #0xc                ; =12
1015c9418:     	strb	w8, [x19, #0x8]
1015c941c:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9420:     	add	x8, x8, #0x196
1015c9424:     	mov	w9, #0x38               ; =56
1015c9428:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c942c:     	ldr	x24, [x0, #0x490]
1015c9430:     	ldr	w8, [x24, #0x2f0]
1015c9434:     	tbz	w8, #0x0, 0x1015c945c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
1015c9438:     	ldr	w1, [x24, #0x2f4]
1015c943c:     	mov	x21, x0
1015c9440:     	bl	0x1015c8548 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
1015c9444:     	mov	x8, x0
1015c9448:     	mov	x0, x21
1015c944c:     	ldr	x24, [x21, #0x490]
1015c9450:     	tbz	w8, #0x0, 0x1015c945c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
1015c9454:     	ldrb	w8, [x24, #0x460]
1015c9458:     	tbz	w8, #0x0, 0x1015c9558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x230>
1015c945c:     	ldr	x21, [x0, #0x498]
1015c9460:     	ldr	w9, [x24, #0xb8]
1015c9464:     	ldr	w8, [x24, #0x2f0]
1015c9468:     	cmp	w9, #0x1
1015c946c:     	b.ne	0x1015c94a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x17c>
1015c9470:     	tbz	w8, #0x0, 0x1015c9488 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x160>
1015c9474:     	ldp	w22, w8, [x24, #0xbc]
1015c9478:     	ldr	w9, [x24, #0x2f4]
1015c947c:     	cmp	x20, x8
1015c9480:     	ccmp	w9, w22, #0x0, eq
1015c9484:     	b.eq	0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c9488:     	adrp	x8, 0x10754c000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x8a8>
1015c948c:     	add	x8, x8, #0xf64
1015c9490:     	mov	w9, #0x26               ; =38
1015c9494:     	str	wzr, [x19]
1015c9498:     	mov	w10, #0xc               ; =12
1015c949c:     	str	w10, [x19, #0x8]
1015c94a0:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c94a4:     	ldr	w22, [x24, #0x2f4]
1015c94a8:     	tbz	w8, #0x0, 0x1015c9538 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x210>
1015c94ac:     	ldr	x8, [x21, #0x590]
1015c94b0:     	cmp	x8, x22
1015c94b4:     	b.ls	0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c94b8:     	ldr	x8, [x21, #0x588]
1015c94bc:     	add	x8, x8, x22, lsl #4
1015c94c0:     	ldr	x9, [x8]
1015c94c4:     	cmp	x9, #0x1
1015c94c8:     	b.ne	0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c94cc:     	ldr	x8, [x8, #0x8]
1015c94d0:     	ldr	x1, [x21, #0x580]
1015c94d4:     	cmp	x8, x1
1015c94d8:     	b.hs	0x1015ca030 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd08>
1015c94dc:     	ldr	x9, [x21, #0x578]
1015c94e0:     	mov	w10, #0x38              ; =56
1015c94e4:     	madd	x8, x8, x10, x9
1015c94e8:     	ldr	x9, [x8]
1015c94ec:     	cmp	x9, #0x1
1015c94f0:     	b.ne	0x1015c9574 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x24c>
1015c94f4:     	ldr	x9, [x24, #0x10]
1015c94f8:     	cmp	x9, #0x2
1015c94fc:     	b.eq	0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c9500:     	ldr	x9, [x8, #0x8]
1015c9504:     	ldr	x10, [x24, #0x40]
1015c9508:     	cmp	x9, x10
1015c950c:     	b.hs	0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c9510:     	ldr	x10, [x24, #0x38]
1015c9514:     	mov	w11, #0x3c8             ; =968
1015c9518:     	madd	x9, x9, x11, x10
1015c951c:     	ldr	x9, [x9, #0x290]
1015c9520:     	cbz	x9, 0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c9524:     	ldr	x9, [x8, #0x18]
1015c9528:     	cbz	x9, 0x1015ca01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015c952c:     	ldr	x9, [x8, #0x10]
1015c9530:     	ldr	w9, [x9]
1015c9534:     	b	0x1015c9598 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x270>
1015c9538:     	mov	w15, #0x0               ; =0
1015c953c:     	mov	w14, #0x0               ; =0
1015c9540:     	add	x23, sp, #0x120
1015c9544:     	mov	x28, x0
1015c9548:     	ldr	x26, [x28, #0xf8]!
1015c954c:     	cmp	x26, #0x2
1015c9550:     	b.eq	0x1015c95d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
1015c9554:     	b	0x1015c96ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
1015c9558:     	str	wzr, [x19]
1015c955c:     	mov	w8, #0xc                ; =12
1015c9560:     	strb	w8, [x19, #0x8]
1015c9564:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9568:     	add	x8, x8, #0x70
1015c956c:     	mov	w9, #0x25               ; =37
1015c9570:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9574:     	ldr	x9, [x8, #0x18]
1015c9578:     	cbz	x9, 0x1015ca01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015c957c:     	ldr	w9, [x24, #0x340]
1015c9580:     	tbz	w9, #0x0, 0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c9584:     	ldr	x9, [x8, #0x10]
1015c9588:     	ldr	w9, [x9]
1015c958c:     	ldr	w10, [x24, #0x344]
1015c9590:     	cmp	w10, w9
1015c9594:     	b.ne	0x1015c95b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015c9598:     	cmp	w22, w9
1015c959c:     	b.ne	0x1015c96a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x37c>
1015c95a0:     	lsr	x9, x20, #32
1015c95a4:     	cbz	x9, 0x1015c96b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x38c>
1015c95a8:     	adrp	x8, 0x10754c000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x8a8>
1015c95ac:     	add	x8, x8, #0xfb4
1015c95b0:     	mov	w9, #0x1a               ; =26
1015c95b4:     	b	0x1015c9494 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
1015c95b8:     	mov	w15, #0x1               ; =1
1015c95bc:     	mov	w14, #0x1               ; =1
1015c95c0:     	add	x23, sp, #0x120
1015c95c4:     	mov	x28, x0
1015c95c8:     	ldr	x26, [x28, #0xf8]!
1015c95cc:     	cmp	x26, #0x2
1015c95d0:     	b.ne	0x1015c96ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
1015c95d4:     	cbz	w14, 0x1015c9688 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x360>
1015c95d8:     	mov	w2, w22
1015c95dc:     	ldr	x8, [x21, #0x188]
1015c95e0:     	cmp	x8, x2
1015c95e4:     	b.ls	0x1015c9ba8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
1015c95e8:     	ldr	x8, [x21, #0x180]
1015c95ec:     	ldr	x8, [x8, x2, lsl #3]
1015c95f0:     	cbz	x8, 0x1015c9ba8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
1015c95f4:     	sub	x8, x8, #0x1
1015c95f8:     	and	x9, x8, #0x3
1015c95fc:     	cmp	x9, #0x2
1015c9600:     	b.ne	0x1015c9ba8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
1015c9604:     	lsr	x8, x8, #2
1015c9608:     	ldr	x1, [x21, #0x160]
1015c960c:     	cmp	x8, x1
1015c9610:     	b.hs	0x1015ca040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd18>
1015c9614:     	ldr	x9, [x21, #0x158]
1015c9618:     	mov	w10, #0x48              ; =72
1015c961c:     	madd	x9, x8, x10, x9
1015c9620:     	ldr	w10, [x9, #0x40]
1015c9624:     	cmp	x20, x10
1015c9628:     	b.ne	0x1015c9678 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015c962c:     	ldr	w10, [x24, #0x2e8]
1015c9630:     	cmp	w10, #0x1
1015c9634:     	b.ne	0x1015c9678 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015c9638:     	ldr	w10, [x9, #0x30]
1015c963c:     	ldr	w11, [x24, #0x2ec]
1015c9640:     	cmp	w11, w10
1015c9644:     	b.ne	0x1015c9678 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015c9648:     	ldr	w9, [x9, #0x34]
1015c964c:     	mov	w10, #0x1               ; =1
1015c9650:     	orr	x9, x10, x9, lsl #1
1015c9654:     	ldr	x1, [x0, #0x4b8]
1015c9658:     	cmp	x9, x1
1015c965c:     	b.hs	0x1015ca090 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd68>
1015c9660:     	ldr	x10, [x0, #0x4b0]
1015c9664:     	ldr	x9, [x10, x9, lsl #3]
1015c9668:     	ldr	x10, [x0, #0xc0]
1015c966c:     	cmp	x9, #0x0
1015c9670:     	ccmp	x10, #0x2, #0x0, eq
1015c9674:     	b.eq	0x1015c9b90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
1015c9678:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c967c:     	add	x8, x8, #0xc88
1015c9680:     	mov	w9, #0x35               ; =53
1015c9684:     	b	0x1015c9bc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
1015c9688:     	ldrb	w8, [x24, #0x338]
1015c968c:     	cmp	w8, #0x1
1015c9690:     	b.ne	0x1015c969c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x374>
1015c9694:     	ldr	x8, [x0, #0x4c0]
1015c9698:     	cbnz	x8, 0x1015c9bbc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x894>
1015c969c:     	str	x20, [sp, #0x10]
1015c96a0:     	b	0x1015c9888 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x560>
1015c96a4:     	adrp	x8, 0x10754c000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x8a8>
1015c96a8:     	add	x8, x8, #0xfce
1015c96ac:     	mov	w9, #0x1a               ; =26
1015c96b0:     	b	0x1015c9494 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
1015c96b4:     	mov	x25, x0
1015c96b8:     	mov	x0, x8
1015c96bc:     	mov	x1, x20
1015c96c0:     	bl	0x101632d90 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB2_5Group11predecessor>
1015c96c4:     	tbz	w0, #0x0, 0x1015c9b80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x858>
1015c96c8:     	mov	x22, x1
1015c96cc:     	mov	w15, #0x1               ; =1
1015c96d0:     	mov	w14, #0x1               ; =1
1015c96d4:     	mov	x0, x25
1015c96d8:     	add	x23, sp, #0x120
1015c96dc:     	mov	x28, x0
1015c96e0:     	ldr	x26, [x28, #0xf8]!
1015c96e4:     	cmp	x26, #0x2
1015c96e8:     	b.eq	0x1015c95d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
1015c96ec:     	cbz	w14, 0x1015c981c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4f4>
1015c96f0:     	mov	w2, w22
1015c96f4:     	ldr	x1, [x21, #0x380]
1015c96f8:     	cmp	x1, x2
1015c96fc:     	b.ls	0x1015c9ff8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd0>
1015c9700:     	ldr	x8, [x21, #0x378]
1015c9704:     	mov	w9, #0x170              ; =368
1015c9708:     	umaddl	x8, w2, w9, x8
1015c970c:     	ldp	x10, x9, [x8]
1015c9710:     	mov	w11, #0x11              ; =17
1015c9714:     	eor	x10, x10, x11
1015c9718:     	orr	x9, x10, x9
1015c971c:     	cbnz	x9, 0x1015c980c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
1015c9720:     	ldr	x1, [x21, #0x390]
1015c9724:     	ldr	w25, [x8, #0x10]
1015c9728:     	cmp	x1, x25
1015c972c:     	b.ls	0x1015ca00c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xce4>
1015c9730:     	ldr	x8, [x21, #0x388]
1015c9734:     	mov	w9, #0x180              ; =384
1015c9738:     	umaddl	x27, w25, w9, x8
1015c973c:     	ldp	x9, x8, [x27]
1015c9740:     	mov	w10, #0x5               ; =5
1015c9744:     	eor	x9, x9, x10
1015c9748:     	orr	x8, x9, x8
1015c974c:     	cbnz	x8, 0x1015c980c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
1015c9750:     	ldr	x8, [x21, #0x558]
1015c9754:     	cmp	x8, x2
1015c9758:     	b.ls	0x1015c9774 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x44c>
1015c975c:     	ldr	x8, [x21, #0x550]
1015c9760:     	mov	w9, #0x28               ; =40
1015c9764:     	umull	x9, w2, w9
1015c9768:     	ldr	w8, [x8, x9]
1015c976c:     	cmp	w8, #0x5
1015c9770:     	b.ne	0x1015c97cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4a4>
1015c9774:     	str	x0, [sp, #0x8]
1015c9778:     	mov	x0, x24
1015c977c:     	mov	x1, x21
1015c9780:     	mov	x24, x14
1015c9784:     	mov	x23, x15
1015c9788:     	bl	0x1015db3cc <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
1015c978c:     	mov	x15, x23
1015c9790:     	mov	x14, x24
1015c9794:     	mov	x8, x0
1015c9798:     	ldr	x0, [sp, #0x8]
1015c979c:     	add	x23, sp, #0x120
1015c97a0:     	tbnz	w8, #0x0, 0x1015c97cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4a4>
1015c97a4:     	ldr	x1, [x21, #0x360]
1015c97a8:     	ldr	w8, [x27, #0x30]
1015c97ac:     	cmp	x1, x8
1015c97b0:     	b.ls	0x1015ca050 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd28>
1015c97b4:     	ldr	x9, [x21, #0x358]
1015c97b8:     	mov	w10, #0x140             ; =320
1015c97bc:     	umaddl	x8, w8, w10, x9
1015c97c0:     	ldrb	w8, [x8, #0x124]
1015c97c4:     	cmp	w8, #0x7
1015c97c8:     	b.eq	0x1015c980c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
1015c97cc:     	mov	x27, x15
1015c97d0:     	mov	x24, x14
1015c97d4:     	mov	x1, x0
1015c97d8:     	add	x0, sp, #0x178
1015c97dc:     	mov	x21, x1
1015c97e0:     	mov	x2, x25
1015c97e4:     	mov	w3, #0x1                ; =1
1015c97e8:     	bl	0x1015c873c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
1015c97ec:     	ldr	w8, [sp, #0x178]
1015c97f0:     	cmp	w8, #0x6
1015c97f4:     	b.ne	0x1015c9db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015c97f8:     	mov	x0, x21
1015c97fc:     	ldr	x26, [x21, #0xf8]
1015c9800:     	ldr	x21, [x21, #0x498]
1015c9804:     	mov	x14, x24
1015c9808:     	mov	x15, x27
1015c980c:     	str	x20, [sp, #0x10]
1015c9810:     	cmp	x26, #0x2
1015c9814:     	b.ne	0x1015c9820 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4f8>
1015c9818:     	b	0x1015c9888 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x560>
1015c981c:     	str	x20, [sp, #0x10]
1015c9820:     	ldr	x9, [x21, #0x5a0]
1015c9824:     	ldr	x8, [x0, #0x1c0]
1015c9828:     	cmp	x8, x9
1015c982c:     	b.hs	0x1015c99a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
1015c9830:     	ldr	x9, [x21, #0x598]
1015c9834:     	mov	w10, #0x58              ; =88
1015c9838:     	madd	x8, x8, x10, x9
1015c983c:     	ldr	x9, [x8, #0x18]
1015c9840:     	cbz	x9, 0x1015c99a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
1015c9844:     	ldr	x8, [x8, #0x10]
1015c9848:     	cmp	x9, #0x1
1015c984c:     	b.ne	0x1015c9858 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x530>
1015c9850:     	mov	x10, #0x0               ; =0
1015c9854:     	b	0x1015c987c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x554>
1015c9858:     	mov	x10, #0x0               ; =0
1015c985c:     	lsr	x11, x9, #1
1015c9860:     	add	x12, x11, x10
1015c9864:     	ldr	w13, [x8, x12, lsl #2]
1015c9868:     	cmp	w13, w20
1015c986c:     	csel	x10, x10, x12, hi
1015c9870:     	sub	x9, x9, x11
1015c9874:     	cmp	x9, #0x1
1015c9878:     	b.hi	0x1015c985c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x534>
1015c987c:     	ldr	w8, [x8, x10, lsl #2]
1015c9880:     	cmp	w8, w20
1015c9884:     	b.ne	0x1015c99a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
1015c9888:     	ldr	x8, [x21, #0x380]
1015c988c:     	cmp	x20, x8
1015c9890:     	b.hs	0x1015c99c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x69c>
1015c9894:     	mov	x25, x15
1015c9898:     	mov	x26, x14
1015c989c:     	ldr	x24, [x21, #0x378]
1015c98a0:     	mov	x1, x0
1015c98a4:     	add	x0, sp, #0x178
1015c98a8:     	mov	x21, x1
1015c98ac:     	mov	x2, x20
1015c98b0:     	bl	0x1015d715c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation31validate_selected_join_boundary>
1015c98b4:     	ldr	w8, [sp, #0x178]
1015c98b8:     	cmp	w8, #0x6
1015c98bc:     	b.ne	0x1015c9db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015c98c0:     	mov	w8, #0x170              ; =368
1015c98c4:     	madd	x24, x20, x8, x24
1015c98c8:     	mov	x8, x21
1015c98cc:     	ldr	x9, [x21, #0x490]
1015c98d0:     	ldr	x10, [x9, #0x1e0]
1015c98d4:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
1015c98d8:     	cmp	x10, x11
1015c98dc:     	b.eq	0x1015c9908 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x5e0>
1015c98e0:     	ldr	x1, [x9, #0x2d0]
1015c98e4:     	ldr	x2, [x9, #0x2e0]
1015c98e8:     	ldp	x3, x4, [x24]
1015c98ec:     	ldrb	w5, [x24, #0x10]
1015c98f0:     	add	x0, sp, #0x178
1015c98f4:     	bl	0x1015cf348 <__RNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections11string_spanNtB7_5State22validate_span_boundary>
1015c98f8:     	ldr	w8, [sp, #0x178]
1015c98fc:     	cmp	w8, #0x6
1015c9900:     	b.ne	0x1015c9db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015c9904:     	mov	x8, x21
1015c9908:     	ldr	x9, [x8, #0x498]
1015c990c:     	mov	x23, x8
1015c9910:     	add	x0, x9, #0x578
1015c9914:     	mov	x1, x20
1015c9918:     	bl	0x1015d3808 <__RNvMs_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB4_6Layout5group>
1015c991c:     	ldr	x8, [x23, #0x490]
1015c9920:     	add	x9, x8, #0x3b8
1015c9924:     	add	x10, x8, #0x2f8
1015c9928:     	stp	x8, x9, [sp, #0x178]
1015c992c:     	stp	x10, x28, [sp, #0x188]
1015c9930:     	add	x8, sp, #0x10
1015c9934:     	str	x8, [sp, #0x198]
1015c9938:     	add	x1, sp, #0x178
1015c993c:     	bl	0x1015a99b4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>
1015c9940:     	cbz	x0, 0x1015c995c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x634>
1015c9944:     	ldr	x8, [x0, #0x18]
1015c9948:     	cbz	x8, 0x1015ca01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015c994c:     	ldr	x8, [x0, #0x10]
1015c9950:     	ldr	w8, [x8]
1015c9954:     	cmp	x20, x8
1015c9958:     	b.ne	0x1015c9a50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x728>
1015c995c:     	ldr	x8, [x28]
1015c9960:     	cmp	x8, #0x2
1015c9964:     	csinc	w8, w25, wzr, ne
1015c9968:     	tbz	w8, #0x0, 0x1015c99e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x6bc>
1015c996c:     	ldr	x8, [x21, #0x490]
1015c9970:     	add	x10, x8, #0x2e8
1015c9974:     	ldr	x8, [x21, #0x498]
1015c9978:     	ldr	x11, [x21, #0x4b0]
1015c997c:     	ldr	x9, [x21, #0x4b8]
1015c9980:     	stp	x10, x8, [sp, #0x1b0]
1015c9984:     	stp	x11, x9, [sp, #0x1c0]
1015c9988:     	mov	w9, #0x13               ; =19
1015c998c:     	strb	w9, [sp, #0x178]
1015c9990:     	add	x23, sp, #0x120
1015c9994:     	cbz	x0, 0x1015c9a8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x764>
1015c9998:     	mov	x25, x0
1015c999c:     	ldr	x4, [x0, #0x30]
1015c99a0:     	mov	w3, #0x1                ; =1
1015c99a4:     	b	0x1015c9a94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x76c>
1015c99a8:     	str	wzr, [x19]
1015c99ac:     	mov	w8, #0xc                ; =12
1015c99b0:     	strb	w8, [x19, #0x8]
1015c99b4:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c99b8:     	add	x8, x8, #0x95
1015c99bc:     	mov	w9, #0x2f               ; =47
1015c99c0:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c99c4:     	str	wzr, [x19]
1015c99c8:     	mov	w8, #0xc                ; =12
1015c99cc:     	adrp	x9, 0x10754a000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x586>
1015c99d0:     	add	x9, x9, #0x9a9
1015c99d4:     	stp	x8, x9, [x19, #0x8]
1015c99d8:     	mov	w8, #0x25               ; =37
1015c99dc:     	str	x8, [x19, #0x18]
1015c99e0:     	b	0x1015c93c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015c99e4:     	ldr	x8, [x21, #0x498]
1015c99e8:     	ldr	x11, [x8, #0x5a0]
1015c99ec:     	ldr	x10, [x21, #0x1c0]
1015c99f0:     	cmp	x10, x11
1015c99f4:     	add	x23, sp, #0x120
1015c99f8:     	b.hs	0x1015c9a6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x744>
1015c99fc:     	cbnz	x0, 0x1015c9b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x830>
1015c9a00:     	ldr	x11, [x8, #0x598]
1015c9a04:     	mov	w12, #0x58              ; =88
1015c9a08:     	madd	x10, x10, x12, x11
1015c9a0c:     	ldr	w2, [x10, #0x38]
1015c9a10:     	cmp	x20, x2
1015c9a14:     	b.ne	0x1015c9b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x830>
1015c9a18:     	mov	x25, x0
1015c9a1c:     	ldr	x10, [x21, #0x490]
1015c9a20:     	add	x10, x10, #0x2e8
1015c9a24:     	ldr	x11, [x21, #0x4b0]
1015c9a28:     	ldr	x9, [x21, #0x4b8]
1015c9a2c:     	stp	x10, x8, [sp, #0x1b0]
1015c9a30:     	stp	x11, x9, [sp, #0x1c0]
1015c9a34:     	mov	w8, #0x13               ; =19
1015c9a38:     	strb	w8, [sp, #0x178]
1015c9a3c:     	add	x8, sp, #0x18
1015c9a40:     	add	x0, sp, #0x178
1015c9a44:     	mov	x1, x20
1015c9a48:     	bl	0x10157b9bc <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE20visit_outlined_entryB9_>
1015c9a4c:     	b	0x1015c9ab0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x788>
1015c9a50:     	str	wzr, [x19]
1015c9a54:     	mov	w8, #0xc                ; =12
1015c9a58:     	strb	w8, [x19, #0x8]
1015c9a5c:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9a60:     	add	x8, x8, #0x16b
1015c9a64:     	mov	w9, #0x2b               ; =43
1015c9a68:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9a6c:     	str	wzr, [x19]
1015c9a70:     	mov	w8, #0xc                ; =12
1015c9a74:     	adrp	x9, 0x10754a000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x586>
1015c9a78:     	add	x9, x9, #0x9ce
1015c9a7c:     	stp	x8, x9, [x19, #0x8]
1015c9a80:     	mov	w8, #0x1a               ; =26
1015c9a84:     	str	x8, [x19, #0x18]
1015c9a88:     	b	0x1015c93c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015c9a8c:     	mov	x25, x0
1015c9a90:     	mov	x3, #0x0                ; =0
1015c9a94:     	ldr	w7, [x8, #0x3f0]
1015c9a98:     	add	x0, sp, #0x18
1015c9a9c:     	add	x1, sp, #0x178
1015c9aa0:     	mov	x2, x20
1015c9aa4:     	mov	x5, x26
1015c9aa8:     	mov	x6, x22
1015c9aac:     	bl	0x10157b25c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>
1015c9ab0:     	ldrb	w8, [sp, #0x18]
1015c9ab4:     	cmp	w8, #0x13
1015c9ab8:     	b.ne	0x1015c9af8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x7d0>
1015c9abc:     	add	x0, sp, #0x178
1015c9ac0:     	bl	0x1015ad0f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
1015c9ac4:     	add	x0, sp, #0x178
1015c9ac8:     	mov	x1, x21
1015c9acc:     	mov	x2, x20
1015c9ad0:     	bl	0x1015d4d54 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation12continuationNtB6_10Invocation23arm_parent_continuation>
1015c9ad4:     	ldr	w8, [sp, #0x178]
1015c9ad8:     	cmp	w8, #0x6
1015c9adc:     	b.ne	0x1015c9db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015c9ae0:     	cbz	x25, 0x1015c9b74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84c>
1015c9ae4:     	ldr	x8, [x25]
1015c9ae8:     	mov	x0, x21
1015c9aec:     	cbz	x8, 0x1015c9bd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8b0>
1015c9af0:     	mov	w8, #0x0                ; =0
1015c9af4:     	b	0x1015c9bec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8c4>
1015c9af8:     	ldur	q0, [sp, #0x18]
1015c9afc:     	ldur	q1, [sp, #0x28]
1015c9b00:     	stp	q0, q1, [sp, #0x120]
1015c9b04:     	ldur	q2, [sp, #0x38]
1015c9b08:     	str	q2, [sp, #0x140]
1015c9b0c:     	ldr	x8, [sp, #0x48]
1015c9b10:     	str	x8, [sp, #0x150]
1015c9b14:     	stur	q0, [sp, #0x1c]
1015c9b18:     	stur	q1, [sp, #0x2c]
1015c9b1c:     	stur	q2, [sp, #0x3c]
1015c9b20:     	stur	x8, [sp, #0x4c]
1015c9b24:     	mov	w8, #0x1                ; =1
1015c9b28:     	str	w8, [x19]
1015c9b2c:     	ldur	q0, [sp, #0x18]
1015c9b30:     	ldur	q1, [sp, #0x28]
1015c9b34:     	stur	q0, [x19, #0x4]
1015c9b38:     	stur	q1, [x19, #0x14]
1015c9b3c:     	ldur	q0, [sp, #0x38]
1015c9b40:     	stur	q0, [x19, #0x24]
1015c9b44:     	ldur	q0, [sp, #0x44]
1015c9b48:     	str	q0, [x19, #0x30]
1015c9b4c:     	add	x0, sp, #0x178
1015c9b50:     	bl	0x1015ad0f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
1015c9b54:     	b	0x1015c93c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015c9b58:     	str	wzr, [x19]
1015c9b5c:     	mov	w8, #0xc                ; =12
1015c9b60:     	strb	w8, [x19, #0x8]
1015c9b64:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9b68:     	add	x8, x8, #0xc4
1015c9b6c:     	mov	w9, #0x26               ; =38
1015c9b70:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9b74:     	mov	w8, #0x0                ; =0
1015c9b78:     	mov	x0, x21
1015c9b7c:     	b	0x1015c9bec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8c4>
1015c9b80:     	adrp	x8, 0x10754c000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x8a8>
1015c9b84:     	add	x8, x8, #0xf8a
1015c9b88:     	mov	w9, #0x2a               ; =42
1015c9b8c:     	b	0x1015c9494 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
1015c9b90:     	ldr	x9, [x0, #0x4c0]
1015c9b94:     	str	xzr, [x0, #0x4c0]
1015c9b98:     	cbz	x9, 0x1015c9e1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaf4>
1015c9b9c:     	sub	x9, x9, #0x1
1015c9ba0:     	cmp	x9, x8
1015c9ba4:     	b.ne	0x1015c9e2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xb04>
1015c9ba8:     	ldrb	w8, [x24, #0x338]
1015c9bac:     	cmp	w8, #0x1
1015c9bb0:     	b.ne	0x1015c96f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
1015c9bb4:     	ldr	x8, [x0, #0x4c0]
1015c9bb8:     	cbz	x8, 0x1015c96f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
1015c9bbc:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9bc0:     	add	x8, x8, #0xea
1015c9bc4:     	mov	w9, #0x29               ; =41
1015c9bc8:     	str	wzr, [x19]
1015c9bcc:     	mov	w10, #0xc               ; =12
1015c9bd0:     	str	x10, [x19, #0x8]
1015c9bd4:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9bd8:     	ldr	x8, [x25, #0x18]
1015c9bdc:     	cbz	x8, 0x1015ca01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015c9be0:     	ldr	x8, [x25, #0x10]
1015c9be4:     	ldr	w9, [x8]
1015c9be8:     	mov	w8, #0x1                ; =1
1015c9bec:     	ldr	x10, [x0, #0x490]
1015c9bf0:     	str	w8, [x10, #0x340]
1015c9bf4:     	str	w9, [x10, #0x344]
1015c9bf8:     	ldr	x8, [x0, #0x490]
1015c9bfc:     	str	wzr, [x8, #0xb8]
1015c9c00:     	ldr	x22, [x0, #0x498]
1015c9c04:     	mov	x1, x20
1015c9c08:     	bl	0x1015be7e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
1015c9c0c:     	cbz	x0, 0x1015c9c40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x918>
1015c9c10:     	ldrb	w8, [x0]
1015c9c14:     	cmp	w8, #0x6
1015c9c18:     	b.ne	0x1015c9c40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x918>
1015c9c1c:     	ldr	x9, [x21, #0x490]
1015c9c20:     	add	x8, sp, #0x178
1015c9c24:     	add	x0, x9, #0x3b8
1015c9c28:     	mov	w1, #0x20               ; =32
1015c9c2c:     	mov	w2, #0x20               ; =32
1015c9c30:     	bl	0x102368df4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>
1015c9c34:     	ldrb	w8, [sp, #0x178]
1015c9c38:     	cmp	w8, #0x8
1015c9c3c:     	b.ne	0x1015c9dd4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaac>
1015c9c40:     	ldr	x1, [x22, #0x458]
1015c9c44:     	cmp	x20, x1
1015c9c48:     	b.hs	0x1015ca060 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd38>
1015c9c4c:     	ldr	x8, [x22, #0x450]
1015c9c50:     	add	x10, x8, x20, lsl #6
1015c9c54:     	ldr	w8, [x10, #0x18]
1015c9c58:     	cmp	w8, #0x4
1015c9c5c:     	mov	x9, x21
1015c9c60:     	b.ne	0x1015c9cb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
1015c9c64:     	ldr	x8, [x9, #0x220]
1015c9c68:     	cmp	x8, #0x2
1015c9c6c:     	b.eq	0x1015c9cb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
1015c9c70:     	ldr	x8, [x22, #0x208]
1015c9c74:     	ldr	x0, [x9, #0x1d8]
1015c9c78:     	cmp	x0, x8
1015c9c7c:     	b.hs	0x1015ca0cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xda4>
1015c9c80:     	ldr	w8, [x10, #0x1c]
1015c9c84:     	ldr	x10, [x22, #0x200]
1015c9c88:     	mov	w11, #0x70              ; =112
1015c9c8c:     	madd	x10, x0, x11, x10
1015c9c90:     	ldr	w10, [x10, #0x40]
1015c9c94:     	cmp	w10, w8
1015c9c98:     	b.ne	0x1015c9cb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
1015c9c9c:     	add	x0, x9, #0x1d8
1015c9ca0:     	bl	0x1015af860 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
1015c9ca4:     	mov	w8, #0x2                ; =2
1015c9ca8:     	mov	x9, x21
1015c9cac:     	str	x8, [x21, #0x220]
1015c9cb0:     	ldr	x1, [x22, #0x458]
1015c9cb4:     	add	x23, sp, #0x120
1015c9cb8:     	cmp	x20, x1
1015c9cbc:     	b.hs	0x1015ca070 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd48>
1015c9cc0:     	ldr	x8, [x22, #0x450]
1015c9cc4:     	add	x8, x8, x20, lsl #6
1015c9cc8:     	ldr	w10, [x8, #0x18]
1015c9ccc:     	cmp	w10, #0x4
1015c9cd0:     	b.ne	0x1015c9d28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa00>
1015c9cd4:     	ldr	w2, [x8, #0x1c]
1015c9cd8:     	ldr	x8, [x22, #0x390]
1015c9cdc:     	cmp	x8, x2
1015c9ce0:     	b.ls	0x1015ca0a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd78>
1015c9ce4:     	ldr	x8, [x22, #0x388]
1015c9ce8:     	mov	w10, #0x180             ; =384
1015c9cec:     	umaddl	x8, w2, w10, x8
1015c9cf0:     	ldp	x8, x10, [x8]
1015c9cf4:     	mov	w11, #0x5               ; =5
1015c9cf8:     	eor	x8, x8, x11
1015c9cfc:     	orr	x8, x8, x10
1015c9d00:     	cbnz	x8, 0x1015c9d28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa00>
1015c9d04:     	mov	x1, x9
1015c9d08:     	add	x0, sp, #0x178
1015c9d0c:     	mov	w3, #0x2                ; =2
1015c9d10:     	bl	0x1015c873c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
1015c9d14:     	ldr	w8, [sp, #0x178]
1015c9d18:     	cmp	w8, #0x6
1015c9d1c:     	b.ne	0x1015c9db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015c9d20:     	ldr	x1, [x22, #0x458]
1015c9d24:     	mov	x9, x21
1015c9d28:     	cmp	x20, x1
1015c9d2c:     	b.hs	0x1015ca080 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd58>
1015c9d30:     	ldr	x8, [x22, #0x450]
1015c9d34:     	add	x8, x8, x20, lsl #6
1015c9d38:     	ldr	w10, [x8, #0x18]
1015c9d3c:     	cmp	w10, #0x4
1015c9d40:     	b.ne	0x1015c9f20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbf8>
1015c9d44:     	ldr	w2, [x8, #0x1c]
1015c9d48:     	ldr	x1, [x22, #0x390]
1015c9d4c:     	cmp	x1, x2
1015c9d50:     	b.ls	0x1015ca0b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd90>
1015c9d54:     	ldr	x8, [x22, #0x388]
1015c9d58:     	mov	w10, #0x180             ; =384
1015c9d5c:     	umaddl	x8, w2, w10, x8
1015c9d60:     	ldp	x8, x10, [x8]
1015c9d64:     	cmp	x8, #0x3
1015c9d68:     	sbcs	xzr, x10, xzr
1015c9d6c:     	b.hs	0x1015c9f20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbf8>
1015c9d70:     	ldr	x12, [x9, #0x490]
1015c9d74:     	ldr	x8, [x12, #0x1e0]
1015c9d78:     	ldr	d0, [x12, #0x1e8]
1015c9d7c:     	ldrb	w9, [x12, #0x1f0]
1015c9d80:     	ldp	x10, x11, [x12, #0x1f8]
1015c9d84:     	mov	x13, #-0x8000000000000000 ; =-9223372036854775808
1015c9d88:     	str	x13, [x12, #0x1e0]
1015c9d8c:     	cmp	x8, x13
1015c9d90:     	b.ne	0x1015c9e3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xb14>
1015c9d94:     	str	wzr, [x19]
1015c9d98:     	mov	w8, #0xc                ; =12
1015c9d9c:     	strb	w8, [x19, #0x8]
1015c9da0:     	adrp	x8, 0x10754a000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x586>
1015c9da4:     	add	x8, x8, #0x9e8
1015c9da8:     	mov	w9, #0x1d               ; =29
1015c9dac:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9db0:     	ldur	q0, [x23, #0x68]
1015c9db4:     	ldur	q1, [x23, #0x78]
1015c9db8:     	ldur	q2, [x23, #0x88]
1015c9dbc:     	stp	q1, q2, [x19, #0x20]
1015c9dc0:     	ldur	q1, [x23, #0x98]
1015c9dc4:     	str	q1, [x19, #0x40]
1015c9dc8:     	ldur	q1, [x23, #0x58]
1015c9dcc:     	stp	q1, q0, [x19]
1015c9dd0:     	b	0x1015c93c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015c9dd4:     	ldur	q0, [x23, #0x58]
1015c9dd8:     	ldur	q1, [x23, #0x68]
1015c9ddc:     	stp	q0, q1, [x29, #-0xb0]
1015c9de0:     	ldr	x8, [sp, #0x198]
1015c9de4:     	stur	x8, [x29, #-0x90]
1015c9de8:     	add	x9, x24, #0x148
1015c9dec:     	ldr	w10, [x24, #0x158]
1015c9df0:     	stur	w10, [x29, #-0x70]
1015c9df4:     	ldr	q2, [x9]
1015c9df8:     	stur	q2, [x29, #-0x80]
1015c9dfc:     	mov	w9, #0x4                ; =4
1015c9e00:     	str	w9, [x19]
1015c9e04:     	stur	q2, [x19, #0x4]
1015c9e08:     	str	w10, [x19, #0x14]
1015c9e0c:     	stur	q0, [x19, #0x18]
1015c9e10:     	stur	q1, [x19, #0x28]
1015c9e14:     	str	x8, [x19, #0x38]
1015c9e18:     	b	0x1015c93c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015c9e1c:     	adrp	x8, 0x10754b000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x1586>
1015c9e20:     	add	x8, x8, #0x7f2
1015c9e24:     	mov	w9, #0x2c               ; =44
1015c9e28:     	b	0x1015c9bc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
1015c9e2c:     	adrp	x8, 0x10754b000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x1586>
1015c9e30:     	add	x8, x8, #0x81e
1015c9e34:     	mov	w9, #0x31               ; =49
1015c9e38:     	b	0x1015c9bc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
1015c9e3c:     	add	x13, sp, #0x18
1015c9e40:     	add	x14, x12, #0x238
1015c9e44:     	add	x15, x12, #0x208
1015c9e48:     	ldp	q1, q2, [x15]
1015c9e4c:     	stp	q1, q2, [sp, #0x40]
1015c9e50:     	ldr	q4, [x15, #0x20]
1015c9e54:     	ldp	q1, q2, [x14, #0x90]
1015c9e58:     	stur	q2, [x13, #0xf8]
1015c9e5c:     	ldr	q2, [x14, #0x80]
1015c9e60:     	stur	q1, [x13, #0xe8]
1015c9e64:     	stur	q2, [x13, #0xd8]
1015c9e68:     	ldp	q2, q1, [x14, #0x60]
1015c9e6c:     	stur	q1, [x13, #0xc8]
1015c9e70:     	stur	q2, [x13, #0xb8]
1015c9e74:     	ldp	q2, q1, [x14, #0x40]
1015c9e78:     	stur	q1, [x13, #0xa8]
1015c9e7c:     	stur	q2, [x13, #0x98]
1015c9e80:     	ldp	q2, q1, [x14, #0x20]
1015c9e84:     	stur	q1, [x13, #0x88]
1015c9e88:     	ldp	q1, q3, [x14]
1015c9e8c:     	stp	q4, q1, [sp, #0x60]
1015c9e90:     	stur	q3, [sp, #0x80]
1015c9e94:     	add	x14, x12, #0x1f1
1015c9e98:     	ldr	w12, [x12, #0x1f4]
1015c9e9c:     	str	w12, [sp, #0x2c]
1015c9ea0:     	ldr	w12, [x14]
1015c9ea4:     	stur	w12, [sp, #0x29]
1015c9ea8:     	stur	q2, [x13, #0x78]
1015c9eac:     	str	x8, [sp, #0x18]
1015c9eb0:     	str	d0, [sp, #0x20]
1015c9eb4:     	strb	w9, [sp, #0x28]
1015c9eb8:     	stp	x10, x11, [sp, #0x30]
1015c9ebc:     	str	x21, [sp, #0x178]
1015c9ec0:     	add	x8, sp, #0x120
1015c9ec4:     	add	x0, sp, #0x18
1015c9ec8:     	add	x1, sp, #0x178
1015c9ecc:     	bl	0x101519308 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections8lifetimeNtB4_5State14release_source>
1015c9ed0:     	add	x0, sp, #0x178
1015c9ed4:     	add	x1, sp, #0x18
1015c9ed8:     	mov	w2, #0x108              ; =264
1015c9edc:     	bl	0x1039fc028 <dyld_stub_binder+0x1039fc028>
1015c9ee0:     	ldr	x8, [x21, #0x490]
1015c9ee4:     	ldr	x9, [x8, #0x1e0]
1015c9ee8:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1015c9eec:     	cmp	x9, x10
1015c9ef0:     	b.eq	0x1015c9f00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbd8>
1015c9ef4:     	add	x0, x8, #0x1e0
1015c9ef8:     	bl	0x1015ae998 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
1015c9efc:     	ldr	x8, [x21, #0x490]
1015c9f00:     	add	x0, x8, #0x1e0
1015c9f04:     	add	x1, sp, #0x178
1015c9f08:     	mov	w2, #0x108              ; =264
1015c9f0c:     	bl	0x1039fc028 <dyld_stub_binder+0x1039fc028>
1015c9f10:     	ldr	w8, [sp, #0x120]
1015c9f14:     	cmp	w8, #0x6
1015c9f18:     	b.ne	0x1015c9fc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc9c>
1015c9f1c:     	mov	x9, x21
1015c9f20:     	ldr	x20, [x9, #0x490]
1015c9f24:     	ldrb	w8, [x20, #0x338]
1015c9f28:     	tbz	w8, #0x0, 0x1015c9f98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc70>
1015c9f2c:     	ldr	x8, [x20, #0x1e0]
1015c9f30:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015c9f34:     	cmp	x8, x9
1015c9f38:     	b.eq	0x1015c9f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc20>
1015c9f3c:     	add	x0, x20, #0x1e0
1015c9f40:     	bl	0x101510658 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collectionsNtB2_5State11is_complete>
1015c9f44:     	tbz	w0, #0x0, 0x1015c9fa8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc80>
1015c9f48:     	ldr	x8, [x20, #0x10]
1015c9f4c:     	cmp	x8, #0x2
1015c9f50:     	b.eq	0x1015c9f74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc4c>
1015c9f54:     	ldr	x8, [x20, #0xa8]
1015c9f58:     	cbz	x8, 0x1015c9f74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc4c>
1015c9f5c:     	str	wzr, [x19]
1015c9f60:     	mov	w8, #0xc                ; =12
1015c9f64:     	strb	w8, [x19, #0x8]
1015c9f68:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9f6c:     	add	x8, x8, #0x113
1015c9f70:     	b	0x1015c9fbc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc94>
1015c9f74:     	ldr	x8, [x21, #0x4c0]
1015c9f78:     	cbz	x8, 0x1015c9f98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc70>
1015c9f7c:     	str	wzr, [x19]
1015c9f80:     	mov	w8, #0xc                ; =12
1015c9f84:     	strb	w8, [x19, #0x8]
1015c9f88:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9f8c:     	add	x8, x8, #0xea
1015c9f90:     	mov	w9, #0x29               ; =41
1015c9f94:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9f98:     	strb	wzr, [x20, #0x460]
1015c9f9c:     	mov	w8, #0x6                ; =6
1015c9fa0:     	str	w8, [x19]
1015c9fa4:     	b	0x1015c93c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015c9fa8:     	str	wzr, [x19]
1015c9fac:     	mov	w8, #0xc                ; =12
1015c9fb0:     	strb	w8, [x19, #0x8]
1015c9fb4:     	adrp	x8, 0x10754d000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x18a8>
1015c9fb8:     	add	x8, x8, #0x13f
1015c9fbc:     	mov	w9, #0x2c               ; =44
1015c9fc0:     	b	0x1015c93c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015c9fc4:     	add	x9, sp, #0x120
1015c9fc8:     	ldur	q0, [x9, #0x14]
1015c9fcc:     	stur	q0, [x19, #0x14]
1015c9fd0:     	ldur	q0, [x9, #0x24]
1015c9fd4:     	stur	q0, [x19, #0x24]
1015c9fd8:     	ldur	q0, [x9, #0x34]
1015c9fdc:     	stur	q0, [x19, #0x34]
1015c9fe0:     	ldr	q0, [sp, #0x160]
1015c9fe4:     	str	q0, [x19, #0x40]
1015c9fe8:     	ldur	q0, [x9, #0x4]
1015c9fec:     	stur	q0, [x19, #0x4]
1015c9ff0:     	str	w8, [x19]
1015c9ff4:     	b	0x1015c93c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015c9ff8:     	adrp	x8, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015c9ffc:     	add	x8, x8, #0x420
1015ca000:     	mov	x0, x2
1015ca004:     	mov	x2, x8
1015ca008:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca00c:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca010:     	add	x2, x2, #0x438
1015ca014:     	mov	x0, x25
1015ca018:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca01c:     	adrp	x2, 0x107f03000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015ca020:     	add	x2, x2, #0x150
1015ca024:     	mov	x0, #0x0                ; =0
1015ca028:     	mov	x1, #0x0                ; =0
1015ca02c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca030:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca034:     	add	x2, x2, #0xa50
1015ca038:     	mov	x0, x8
1015ca03c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca040:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca044:     	add	x2, x2, #0xbd0
1015ca048:     	mov	x0, x8
1015ca04c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca050:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca054:     	add	x2, x2, #0x450
1015ca058:     	mov	x0, x8
1015ca05c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca060:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca064:     	add	x2, x2, #0x468
1015ca068:     	mov	x0, x20
1015ca06c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca070:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca074:     	add	x2, x2, #0x480
1015ca078:     	mov	x0, x20
1015ca07c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca080:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca084:     	add	x2, x2, #0x4b0
1015ca088:     	mov	x0, x20
1015ca08c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca090:     	adrp	x2, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca094:     	add	x2, x2, #0xbe8
1015ca098:     	mov	x0, x9
1015ca09c:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca0a0:     	adrp	x9, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca0a4:     	add	x9, x9, #0x498
1015ca0a8:     	mov	x0, x2
1015ca0ac:     	mov	x1, x8
1015ca0b0:     	mov	x2, x9
1015ca0b4:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca0b8:     	adrp	x8, 0x107f04000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ca0bc:     	add	x8, x8, #0x4c8
1015ca0c0:     	mov	x0, x2
1015ca0c4:     	mov	x2, x8
1015ca0c8:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca0cc:     	adrp	x2, 0x107f03000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015ca0d0:     	add	x2, x2, #0x168
1015ca0d4:     	mov	x1, x8
1015ca0d8:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca0dc:     	mov	x19, x0
1015ca0e0:     	ldr	x8, [x21, #0x490]
1015ca0e4:     	add	x0, x8, #0x1e0
1015ca0e8:     	add	x1, sp, #0x178
1015ca0ec:     	mov	w2, #0x108              ; =264
1015ca0f0:     	bl	0x1039fc028 <dyld_stub_binder+0x1039fc028>
1015ca0f4:     	ldr	w8, [sp, #0x120]
1015ca0f8:     	cmp	w8, #0x6
1015ca0fc:     	b.eq	0x1015ca130 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xe08>
1015ca100:     	add	x0, sp, #0x120
1015ca104:     	bl	0x1015ae63c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015ca108:     	mov	x0, x19
1015ca10c:     	bl	0x1039fbe3c <dyld_stub_binder+0x1039fbe3c>
1015ca110:     	mov	x19, x0
1015ca114:     	add	x0, sp, #0x18
1015ca118:     	bl	0x1015ae998 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
1015ca11c:     	b	0x1015ca130 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xe08>
1015ca120:     	bl	0x1039faa58 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ca124:     	mov	x19, x0
1015ca128:     	mov	w8, #0x2                ; =2
1015ca12c:     	str	x8, [x21, #0x220]
1015ca130:     	mov	x0, x19
1015ca134:     	bl	0x1039fbe3c <dyld_stub_binder+0x1039fbe3c>
1015ca138:     	mov	x19, x0
1015ca13c:     	add	x0, sp, #0x178
1015ca140:     	bl	0x1015ad0f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
1015ca144:     	mov	x0, x19
1015ca148:     	bl	0x1039fbe3c <dyld_stub_binder+0x1039fbe3c>
1015ca14c:     	mov	x19, x0
1015ca150:     	add	x0, sp, #0x178
1015ca154:     	bl	0x1015ad0f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtNtBL_7program5image23NativeProgramDescriptorEEBN_>
1015ca158:     	mov	x0, x19
1015ca15c:     	bl	0x1039fbe3c <dyld_stub_binder+0x1039fbe3c>
