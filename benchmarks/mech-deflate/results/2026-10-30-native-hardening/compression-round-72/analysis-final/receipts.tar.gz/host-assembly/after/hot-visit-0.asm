
/private/tmp/mech-checked-compute-inline-round72-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015a99b4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>:
1015a99b4:     	sub	sp, sp, #0x50
1015a99b8:     	stp	x22, x21, [sp, #0x20]
1015a99bc:     	stp	x20, x19, [sp, #0x30]
1015a99c0:     	stp	x29, x30, [sp, #0x40]
1015a99c4:     	add	x29, sp, #0x40
1015a99c8:     	cbz	x0, 0x1015a9a7c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015a99cc:     	ldr	x8, [x0]
1015a99d0:     	cmp	x8, #0x1
1015a99d4:     	b.ne	0x1015a9a14 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x60>
1015a99d8:     	ldr	x8, [x1]
1015a99dc:     	ldr	x9, [x8, #0x10]
1015a99e0:     	cmp	x9, #0x2
1015a99e4:     	b.eq	0x1015a9a7c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015a99e8:     	ldr	x9, [x0, #0x8]
1015a99ec:     	ldr	x10, [x8, #0x40]
1015a99f0:     	cmp	x9, x10
1015a99f4:     	b.hs	0x1015a9a7c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015a99f8:     	ldr	x8, [x8, #0x38]
1015a99fc:     	mov	w10, #0x3c8             ; =968
1015a9a00:     	madd	x8, x9, x10, x8
1015a9a04:     	ldr	x8, [x8, #0x290]
1015a9a08:     	cbz	x8, 0x1015a9a7c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015a9a0c:     	mov	x1, x0
1015a9a10:     	b	0x1015a9a80 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
1015a9a14:     	ldr	x8, [x0, #0x18]
1015a9a18:     	cbz	x8, 0x1015a9ad8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x124>
1015a9a1c:     	ldr	x8, [x0, #0x10]
1015a9a20:     	ldr	w8, [x8]
1015a9a24:     	ldr	x9, [x1, #0x20]
1015a9a28:     	ldr	x9, [x9]
1015a9a2c:     	cmp	x9, x8
1015a9a30:     	b.ne	0x1015a9a7c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015a9a34:     	ldr	x8, [x1, #0x18]
1015a9a38:     	ldr	x8, [x8]
1015a9a3c:     	cmp	x8, #0x2
1015a9a40:     	b.ne	0x1015a9a7c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015a9a44:     	mov	x21, x1
1015a9a48:     	ldr	x9, [x1, #0x8]
1015a9a4c:     	add	x8, sp, #0x8
1015a9a50:     	mov	x20, x0
1015a9a54:     	mov	x0, x9
1015a9a58:     	bl	0x1023680e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015a9a5c:     	ldr	x8, [sp, #0x8]
1015a9a60:     	cmp	x8, #0x1
1015a9a64:     	b.ne	0x1015a9a7c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015a9a68:     	mov	x0, x20
1015a9a6c:     	ldr	x8, [sp, #0x10]
1015a9a70:     	ldr	x19, [x20, #0x30]
1015a9a74:     	cmp	x8, x19
1015a9a78:     	b.hs	0x1015a9a98 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xe4>
1015a9a7c:     	mov	x1, #0x0                ; =0
1015a9a80:     	mov	x0, x1
1015a9a84:     	ldp	x29, x30, [sp, #0x40]
1015a9a88:     	ldp	x20, x19, [sp, #0x30]
1015a9a8c:     	ldp	x22, x21, [sp, #0x20]
1015a9a90:     	add	sp, sp, #0x50
1015a9a94:     	ret
1015a9a98:     	ldr	x8, [x21, #0x10]
1015a9a9c:     	ldr	x9, [x8, #0x18]!
1015a9aa0:     	ldur	x21, [x8, #-0x8]
1015a9aa4:     	cbz	x9, 0x1015a9abc <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x108>
1015a9aa8:     	mov	x0, x8
1015a9aac:     	bl	0x102368dc4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
1015a9ab0:     	mov	x8, x0
1015a9ab4:     	mov	x0, x20
1015a9ab8:     	b	0x1015a9ac0 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x10c>
1015a9abc:     	ldur	x8, [x8, #-0x10]
1015a9ac0:     	mov	x1, #0x0                ; =0
1015a9ac4:     	subs	x8, x21, x8
1015a9ac8:     	b.lo	0x1015a9a80 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
1015a9acc:     	cmp	x8, x19
1015a9ad0:     	b.hs	0x1015a9a0c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x58>
1015a9ad4:     	b	0x1015a9a80 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
1015a9ad8:     	adrp	x2, 0x107f03000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015a9adc:     	add	x2, x2, #0x150
1015a9ae0:     	mov	x0, #0x0                ; =0
1015a9ae4:     	mov	x1, #0x0                ; =0
1015a9ae8:     	bl	0x1039faa70 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
