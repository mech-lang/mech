
/private/tmp/mech-checked-compute-inline-round72-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015b4ec4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>:
1015b4ec4:     	stp	x28, x27, [sp, #-0x60]!
1015b4ec8:     	stp	x26, x25, [sp, #0x10]
1015b4ecc:     	stp	x24, x23, [sp, #0x20]
1015b4ed0:     	stp	x22, x21, [sp, #0x30]
1015b4ed4:     	stp	x20, x19, [sp, #0x40]
1015b4ed8:     	stp	x29, x30, [sp, #0x50]
1015b4edc:     	add	x29, sp, #0x50
1015b4ee0:     	sub	sp, sp, #0x4c0
1015b4ee4:     	str	xzr, [sp]
1015b4ee8:     	ldr	x27, [x1, #0x498]
1015b4eec:     	ldr	x8, [x27, #0x4a0]
1015b4ef0:     	cmp	x2, x8
1015b4ef4:     	b.hs	0x1015b4fc0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
1015b4ef8:     	mov	x22, x5
1015b4efc:     	mov	x23, x4
1015b4f00:     	mov	x20, x2
1015b4f04:     	mov	x21, x1
1015b4f08:     	add	x26, sp, #0x400
1015b4f0c:     	ldr	x8, [x27, #0x498]
1015b4f10:     	mov	w9, #0x28               ; =40
1015b4f14:     	madd	x24, x2, x9, x8
1015b4f18:     	ldr	w8, [x24]
1015b4f1c:     	cmp	w8, #0x1
1015b4f20:     	b.gt	0x1015b4fa4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe0>
1015b4f24:     	cbnz	w8, 0x1015b4fd4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x110>
1015b4f28:     	cbnz	x3, 0x1015b5228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015b4f2c:     	ldr	x1, [x27, #0x380]
1015b4f30:     	cmp	x20, x1
1015b4f34:     	b.hs	0x1015b6244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1380>
1015b4f38:     	ldr	x8, [x27, #0x378]
1015b4f3c:     	mov	w9, #0x170              ; =368
1015b4f40:     	madd	x8, x20, x9, x8
1015b4f44:     	ldp	x10, x9, [x8]
1015b4f48:     	cmp	x10, #0x2
1015b4f4c:     	sbcs	xzr, x9, xzr
1015b4f50:     	b.hs	0x1015b53fc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x538>
1015b4f54:     	ldr	w9, [x8, #0x130]
1015b4f58:     	ldr	w10, [x24, #0x4]
1015b4f5c:     	cmp	w9, w10
1015b4f60:     	b.ne	0x1015b5418 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
1015b4f64:     	ldr	x9, [x8, #0x128]
1015b4f68:     	cmp	x22, x9
1015b4f6c:     	b.ne	0x1015b5418 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
1015b4f70:     	stp	x24, x0, [sp, #0x38]
1015b4f74:     	add	x9, x27, #0x488
1015b4f78:     	ldr	x8, [x8, #0x120]
1015b4f7c:     	str	x8, [sp, #0x30]
1015b4f80:     	lsl	x8, x22, #2
1015b4f84:     	stp	x8, x9, [sp, #0x18]
1015b4f88:     	cbz	x22, 0x1015b55f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
1015b4f8c:     	mov	x10, #0x0               ; =0
1015b4f90:     	mov	x25, #0x0               ; =0
1015b4f94:     	ldr	x24, [x21, #0x490]
1015b4f98:     	ldr	x26, [sp, #0x18]
1015b4f9c:     	str	x24, [sp, #0x28]
1015b4fa0:     	b	0x1015b5060 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x19c>
1015b4fa4:     	cmp	w8, #0x2
1015b4fa8:     	b.ne	0x1015b4fc0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
1015b4fac:     	cbz	x3, 0x1015b5214 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
1015b4fb0:     	cmp	x3, #0x12
1015b4fb4:     	b.ne	0x1015b5228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015b4fb8:     	cbnz	x22, 0x1015b5228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015b4fbc:     	b	0x1015b5284 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
1015b4fc0:     	mov	w8, #0x2                ; =2
1015b4fc4:     	str	x8, [x0, #0x8]
1015b4fc8:     	mov	w8, #0x6                ; =6
1015b4fcc:     	str	w8, [x0]
1015b4fd0:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b4fd4:     	cmp	x3, #0x1
1015b4fd8:     	b.ne	0x1015b5228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015b4fdc:     	cbnz	x22, 0x1015b5228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015b4fe0:     	mov	x19, x0
1015b4fe4:     	add	x0, sp, #0x400
1015b4fe8:     	mov	x1, x21
1015b4fec:     	mov	x2, x20
1015b4ff0:     	bl	0x1015c8104 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
1015b4ff4:     	ldr	w8, [sp, #0x400]
1015b4ff8:     	cmp	w8, #0x1
1015b4ffc:     	b.ne	0x1015b5264 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3a0>
1015b5000:     	ldr	w3, [sp, #0x404]
1015b5004:     	ldr	w4, [sp, #0x408]
1015b5008:     	ldp	w8, w9, [x24, #0x4]
1015b500c:     	cmp	w3, w8
1015b5010:     	ccmp	w4, w9, #0x0, eq
1015b5014:     	mov	x11, x19
1015b5018:     	b.eq	0x1015b5434 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x570>
1015b501c:     	str	wzr, [x11]
1015b5020:     	mov	w8, #0xc                ; =12
1015b5024:     	strb	w8, [x11, #0x8]
1015b5028:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b502c:     	add	x8, x8, #0x6c3
1015b5030:     	mov	w9, #0x2e               ; =46
1015b5034:     	stp	x8, x9, [x11, #0x10]
1015b5038:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b503c:     	ldp	q0, q1, [sp, #0x2f0]
1015b5040:     	ldp	q2, q3, [sp, #0x310]
1015b5044:     	stp	q2, q3, [x24, #0x20]
1015b5048:     	stp	q0, q1, [x24]
1015b504c:     	add	x10, x19, #0x40
1015b5050:     	add	x25, x25, #0x1
1015b5054:     	subs	x26, x26, #0x4
1015b5058:     	ldr	x24, [sp, #0x28]
1015b505c:     	b.eq	0x1015b55f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
1015b5060:     	str	x26, [sp, #0x48]
1015b5064:     	ldr	x8, [x27, #0x360]
1015b5068:     	ldr	x9, [sp, #0x30]
1015b506c:     	ldr	w1, [x9, x25, lsl #2]
1015b5070:     	cmp	x8, x1
1015b5074:     	b.ls	0x1015b6230 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
1015b5078:     	ldr	x8, [x27, #0x358]
1015b507c:     	mov	w9, #0x140              ; =320
1015b5080:     	umaddl	x8, w1, w9, x8
1015b5084:     	ldrb	w9, [x8, #0x124]
1015b5088:     	cmp	w9, #0x7
1015b508c:     	b.ne	0x1015b5158 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x294>
1015b5090:     	cmp	x25, x22
1015b5094:     	b.hs	0x1015b6254 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1390>
1015b5098:     	ldr	x8, [x23, x25, lsl #3]
1015b509c:     	cbnz	x8, 0x1015b57ac <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8e8>
1015b50a0:     	ldr	x8, [x27, #0x490]
1015b50a4:     	cmp	x8, x1
1015b50a8:     	b.ls	0x1015b50e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
1015b50ac:     	ldr	x8, [sp, #0x20]
1015b50b0:     	ldr	x8, [x8]
1015b50b4:     	mov	w9, #0x18               ; =24
1015b50b8:     	umaddl	x8, w1, w9, x8
1015b50bc:     	ldr	x9, [x8]
1015b50c0:     	cmp	x9, #0x1
1015b50c4:     	b.ne	0x1015b50e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
1015b50c8:     	ldp	x8, x9, [x8, #0x8]
1015b50cc:     	adds	x8, x8, x9
1015b50d0:     	b.hs	0x1015b50e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
1015b50d4:     	ldr	x9, [x27, #0x4b0]
1015b50d8:     	cmp	x8, x9
1015b50dc:     	b.ls	0x1015b51a8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
1015b50e0:     	mov	x26, x10
1015b50e4:     	add	x8, sp, #0x400
1015b50e8:     	add	x0, x24, #0xf0
1015b50ec:     	add	x2, x24, #0x2f8
1015b50f0:     	bl	0x1015d0bac <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015b50f4:     	ldr	x8, [sp, #0x400]
1015b50f8:     	add	x9, sp, #0x400
1015b50fc:     	ldur	q0, [x9, #0x8]
1015b5100:     	ldur	q1, [x9, #0x18]
1015b5104:     	stp	q0, q1, [sp, #0x50]
1015b5108:     	ldur	q0, [x9, #0x28]
1015b510c:     	str	q0, [sp, #0x70]
1015b5110:     	ldur	x9, [x9, #0x38]
1015b5114:     	str	x9, [sp, #0x80]
1015b5118:     	cbz	x8, 0x1015b57ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x928>
1015b511c:     	mov	w19, #0x0               ; =0
1015b5120:     	ldp	q0, q1, [sp, #0x50]
1015b5124:     	add	x10, sp, #0x2f0
1015b5128:     	stur	q0, [x10, #0x8]
1015b512c:     	stur	q1, [x10, #0x18]
1015b5130:     	ldr	q0, [sp, #0x70]
1015b5134:     	stur	q0, [x10, #0x28]
1015b5138:     	ldr	x9, [sp, #0x80]
1015b513c:     	stur	x9, [x10, #0x38]
1015b5140:     	mov	x10, x26
1015b5144:     	str	x8, [sp, #0x2f0]
1015b5148:     	ldr	x1, [x24, #0xd8]
1015b514c:     	cmp	x25, x1
1015b5150:     	b.lo	0x1015b51c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
1015b5154:     	b	0x1015b5200 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
1015b5158:     	cmp	x25, x22
1015b515c:     	b.hs	0x1015b6268 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13a4>
1015b5160:     	ldr	x8, [x23, x25, lsl #3]
1015b5164:     	cmp	w9, #0x3
1015b5168:     	b.gt	0x1015b5184 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2c0>
1015b516c:     	sub	w9, w9, #0x1
1015b5170:     	cmp	w9, #0x3
1015b5174:     	b.lo	0x1015b51a8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
1015b5178:     	cmp	x8, #0x2
1015b517c:     	b.lo	0x1015b51a8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
1015b5180:     	b	0x1015b583c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
1015b5184:     	cmp	w9, #0x4
1015b5188:     	b.eq	0x1015b51a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2dc>
1015b518c:     	cmp	w9, #0x5
1015b5190:     	b.ne	0x1015b51e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x320>
1015b5194:     	cmp	x8, #0x10, lsl #12      ; =0x10000
1015b5198:     	b.lo	0x1015b51a8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
1015b519c:     	b	0x1015b583c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
1015b51a0:     	cmp	x8, #0x100
1015b51a4:     	b.hs	0x1015b583c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
1015b51a8:     	mov	x8, #0x0                ; =0
1015b51ac:     	mov	w19, #0x1               ; =1
1015b51b0:     	str	x8, [sp, #0x2f0]
1015b51b4:     	ldr	x1, [x24, #0xd8]
1015b51b8:     	cmp	x25, x1
1015b51bc:     	b.hs	0x1015b5200 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
1015b51c0:     	ldr	x28, [x24, #0xd0]
1015b51c4:     	add	x24, x28, x10
1015b51c8:     	ldr	x8, [x24]
1015b51cc:     	mov	x19, x10
1015b51d0:     	ldr	x26, [sp, #0x48]
1015b51d4:     	cbz	x8, 0x1015b503c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
1015b51d8:     	add	x0, x28, x19
1015b51dc:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b51e0:     	b	0x1015b503c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
1015b51e4:     	lsr	x8, x8, #32
1015b51e8:     	cbnz	x8, 0x1015b583c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
1015b51ec:     	mov	w19, #0x1               ; =1
1015b51f0:     	str	x8, [sp, #0x2f0]
1015b51f4:     	ldr	x1, [x24, #0xd8]
1015b51f8:     	cmp	x25, x1
1015b51fc:     	b.lo	0x1015b51c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
1015b5200:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b5204:     	add	x2, x2, #0x668
1015b5208:     	mov	x0, x25
1015b520c:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b5210:     	b	0x1015b6328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015b5214:     	cmp	x22, #0x2
1015b5218:     	b.ne	0x1015b5228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
1015b521c:     	ldp	x9, x8, [x23]
1015b5220:     	orr	x8, x9, x8
1015b5224:     	cbz	x8, 0x1015b5284 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
1015b5228:     	str	wzr, [x0]
1015b522c:     	mov	w8, #0xc                ; =12
1015b5230:     	strb	w8, [x0, #0x8]
1015b5234:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b5238:     	add	x8, x8, #0x7f6
1015b523c:     	mov	w9, #0x34               ; =52
1015b5240:     	stp	x8, x9, [x0, #0x10]
1015b5244:     	add	sp, sp, #0x4c0
1015b5248:     	ldp	x29, x30, [sp, #0x50]
1015b524c:     	ldp	x20, x19, [sp, #0x40]
1015b5250:     	ldp	x22, x21, [sp, #0x30]
1015b5254:     	ldp	x24, x23, [sp, #0x20]
1015b5258:     	ldp	x26, x25, [sp, #0x10]
1015b525c:     	ldp	x28, x27, [sp], #0x60
1015b5260:     	ret
1015b5264:     	str	wzr, [x19]
1015b5268:     	mov	w8, #0xc                ; =12
1015b526c:     	str	w8, [x19, #0x8]
1015b5270:     	adrp	x8, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015b5274:     	add	x8, x8, #0x7b9
1015b5278:     	mov	w9, #0x27               ; =39
1015b527c:     	stp	x8, x9, [x19, #0x10]
1015b5280:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5284:     	ldr	x1, [x27, #0x380]
1015b5288:     	cmp	x20, x1
1015b528c:     	b.hs	0x1015b627c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13b8>
1015b5290:     	stp	x24, x0, [sp, #0x38]
1015b5294:     	ldr	x8, [x27, #0x378]
1015b5298:     	mov	w9, #0x170              ; =368
1015b529c:     	madd	x26, x20, x9, x8
1015b52a0:     	cbz	x3, 0x1015b5564 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6a0>
1015b52a4:     	cmp	x3, #0x12
1015b52a8:     	b.ne	0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b52ac:     	ldp	x9, x8, [x26]
1015b52b0:     	eor	x9, x9, #0x3
1015b52b4:     	orr	x8, x9, x8
1015b52b8:     	cbnz	x8, 0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b52bc:     	ldr	w22, [x26, #0x28]
1015b52c0:     	ldr	x8, [sp, #0x38]
1015b52c4:     	ldr	w8, [x8, #0x4]
1015b52c8:     	cmp	w22, w8
1015b52cc:     	b.ne	0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b52d0:     	ldr	w24, [x26, #0x2c]
1015b52d4:     	ldr	x8, [sp, #0x38]
1015b52d8:     	ldr	w8, [x8, #0x8]
1015b52dc:     	cmp	w24, w8
1015b52e0:     	b.ne	0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b52e4:     	mov	x25, #0x0               ; =0
1015b52e8:     	mov	w28, #0x3               ; =3
1015b52ec:     	add	x0, x27, #0x488
1015b52f0:     	mov	x1, x22
1015b52f4:     	bl	0x1015c8050 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
1015b52f8:     	cbz	x0, 0x1015b57c8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
1015b52fc:     	ldr	x8, [sp, #0x38]
1015b5300:     	ldr	x23, [x8, #0x10]
1015b5304:     	cmp	x23, x1
1015b5308:     	b.hs	0x1015b57c8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
1015b530c:     	add	x8, x0, x23, lsl #5
1015b5310:     	ldrb	w9, [x8]
1015b5314:     	cmp	w9, #0x2
1015b5318:     	b.ne	0x1015b59f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
1015b531c:     	ldp	x8, x9, [x8, #0x8]
1015b5320:     	adds	x8, x8, x9
1015b5324:     	b.hs	0x1015b59f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
1015b5328:     	ldr	x9, [x27, #0x4b0]
1015b532c:     	cmp	x8, x9
1015b5330:     	b.hi	0x1015b59f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
1015b5334:     	cmp	x28, #0x2
1015b5338:     	sbcs	xzr, x25, xzr
1015b533c:     	b.hs	0x1015b5b58 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc94>
1015b5340:     	ldr	x1, [x26, #0x128]
1015b5344:     	cmp	x1, #0x1
1015b5348:     	b.ls	0x1015b62f4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1430>
1015b534c:     	ldr	x8, [x26, #0x120]
1015b5350:     	ldr	x25, [x21, #0x490]
1015b5354:     	ldr	w1, [x8, #0x4]
1015b5358:     	add	x8, sp, #0x400
1015b535c:     	add	x0, x25, #0xf0
1015b5360:     	add	x2, x25, #0x2f8
1015b5364:     	bl	0x1015d0bac <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015b5368:     	add	x8, sp, #0x400
1015b536c:     	ldur	q0, [x8, #0x8]
1015b5370:     	ldur	q1, [x8, #0x18]
1015b5374:     	stp	q0, q1, [sp, #0x150]
1015b5378:     	ldur	q0, [x8, #0x28]
1015b537c:     	str	q0, [sp, #0x170]
1015b5380:     	ldr	x8, [sp, #0x400]
1015b5384:     	ldr	x9, [sp, #0x438]
1015b5388:     	str	x9, [sp, #0x180]
1015b538c:     	cbz	x8, 0x1015b5c60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd9c>
1015b5390:     	ldp	q0, q1, [sp, #0x150]
1015b5394:     	add	x9, sp, #0x230
1015b5398:     	stur	q0, [x9, #0x48]
1015b539c:     	stur	q1, [x9, #0x58]
1015b53a0:     	ldr	q0, [sp, #0x170]
1015b53a4:     	stur	q0, [x9, #0x68]
1015b53a8:     	ldr	x9, [sp, #0x180]
1015b53ac:     	str	x9, [sp, #0x2a8]
1015b53b0:     	str	x8, [sp, #0x270]
1015b53b4:     	ldr	x1, [x27, #0x408]
1015b53b8:     	cmp	x20, x1
1015b53bc:     	b.hs	0x1015b6318 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1454>
1015b53c0:     	ldr	x8, [x27, #0x400]
1015b53c4:     	add	x23, x8, x20, lsl #9
1015b53c8:     	ldp	x9, x8, [x23]
1015b53cc:     	eor	x9, x9, #0x2
1015b53d0:     	orr	x8, x9, x8
1015b53d4:     	cbnz	x8, 0x1015b5c80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xdbc>
1015b53d8:     	ldr	x10, [sp, #0x40]
1015b53dc:     	str	wzr, [x10]
1015b53e0:     	mov	w8, #0xc                ; =12
1015b53e4:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015b53e8:     	add	x9, x9, #0x800
1015b53ec:     	stp	x8, x9, [x10, #0x8]
1015b53f0:     	mov	w8, #0x23               ; =35
1015b53f4:     	str	x8, [x10, #0x18]
1015b53f8:     	b	0x1015b6108 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
1015b53fc:     	str	wzr, [x0]
1015b5400:     	mov	w8, #0xc                ; =12
1015b5404:     	strb	w8, [x0, #0x8]
1015b5408:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b540c:     	add	x8, x8, #0x69b
1015b5410:     	mov	w9, #0x28               ; =40
1015b5414:     	b	0x1015b5240 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
1015b5418:     	str	wzr, [x0]
1015b541c:     	mov	w8, #0xc                ; =12
1015b5420:     	strb	w8, [x0, #0x8]
1015b5424:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b5428:     	add	x8, x8, #0x679
1015b542c:     	mov	w9, #0x22               ; =34
1015b5430:     	b	0x1015b5240 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
1015b5434:     	ldp	x8, x9, [x24, #0x18]
1015b5438:     	lsl	x9, x9, #2
1015b543c:     	stp	x24, x11, [sp, #0x38]
1015b5440:     	cbz	x9, 0x1015b5470 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ac>
1015b5444:     	ldr	w10, [x8], #0x4
1015b5448:     	sub	x9, x9, #0x4
1015b544c:     	cmp	w10, w3
1015b5450:     	b.ne	0x1015b5440 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x57c>
1015b5454:     	ldr	x25, [x21, #0x490]
1015b5458:     	add	x0, sp, #0x400
1015b545c:     	add	x1, x25, #0x3c0
1015b5460:     	add	x2, x27, #0x488
1015b5464:     	add	x5, x25, #0x2f8
1015b5468:     	bl	0x1015aa5a8 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb1_EBb_>
1015b546c:     	b	0x1015b5488 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5c4>
1015b5470:     	ldr	x25, [x21, #0x490]
1015b5474:     	add	x0, sp, #0x400
1015b5478:     	add	x1, x25, #0x3c0
1015b547c:     	add	x2, x27, #0x488
1015b5480:     	add	x5, x25, #0x2f8
1015b5484:     	bl	0x1015aa284 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb0_EBb_>
1015b5488:     	ldr	w8, [sp, #0x400]
1015b548c:     	cmp	w8, #0x6
1015b5490:     	b.ne	0x1015b5b94 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
1015b5494:     	mov	x22, #0x0               ; =0
1015b5498:     	ldr	x9, [sp, #0x38]
1015b549c:     	ldr	x8, [x9, #0x20]
1015b54a0:     	cbz	x8, 0x1015b55dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
1015b54a4:     	ldr	x23, [x9, #0x18]
1015b54a8:     	lsl	x24, x8, #2
1015b54ac:     	b	0x1015b54b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5f4>
1015b54b0:     	subs	x24, x24, #0x4
1015b54b4:     	b.eq	0x1015b55dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
1015b54b8:     	ldr	w20, [x23], #0x4
1015b54bc:     	ldr	x1, [x25, #0x3c0]
1015b54c0:     	add	x0, sp, #0x400
1015b54c4:     	add	x2, x27, #0x4d0
1015b54c8:     	add	x4, x25, #0x2f8
1015b54cc:     	mov	x3, x20
1015b54d0:     	bl	0x1015b4914 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
1015b54d4:     	ldr	w9, [sp, #0x400]
1015b54d8:     	ldrb	w8, [sp, #0x404]
1015b54dc:     	cmp	w9, #0x6
1015b54e0:     	b.ne	0x1015b5638 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x774>
1015b54e4:     	tbnz	w8, #0x0, 0x1015b54b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
1015b54e8:     	add	x8, sp, #0x400
1015b54ec:     	add	x0, x25, #0xf0
1015b54f0:     	add	x2, x25, #0x2f8
1015b54f4:     	mov	x1, x20
1015b54f8:     	bl	0x1015d142c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
1015b54fc:     	ldrb	w8, [sp, #0x400]
1015b5500:     	cmp	w8, #0x14
1015b5504:     	b.eq	0x1015b54b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
1015b5508:     	ldr	q0, [sp, #0x400]
1015b550c:     	ldr	q1, [sp, #0x410]
1015b5510:     	stp	q0, q1, [sp, #0x2f0]
1015b5514:     	ldr	q2, [sp, #0x420]
1015b5518:     	str	q2, [sp, #0x310]
1015b551c:     	ldr	x8, [sp, #0x430]
1015b5520:     	str	x8, [sp, #0x320]
1015b5524:     	stur	q0, [x26, #0x4]
1015b5528:     	stur	q1, [x26, #0x14]
1015b552c:     	stur	q2, [x26, #0x24]
1015b5530:     	stur	x8, [x26, #0x34]
1015b5534:     	mov	w8, #0x2                ; =2
1015b5538:     	ldr	x9, [sp, #0x40]
1015b553c:     	str	w8, [x9]
1015b5540:     	ldr	q0, [sp, #0x400]
1015b5544:     	ldr	q1, [sp, #0x410]
1015b5548:     	stur	q0, [x9, #0x4]
1015b554c:     	stur	q1, [x9, #0x14]
1015b5550:     	ldr	q0, [sp, #0x420]
1015b5554:     	stur	q0, [x9, #0x24]
1015b5558:     	ldur	q0, [x26, #0x2c]
1015b555c:     	str	q0, [x9, #0x30]
1015b5560:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5564:     	ldp	x28, x25, [x26]
1015b5568:     	cmp	x28, #0x2
1015b556c:     	sbcs	xzr, x25, xzr
1015b5570:     	b.hs	0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b5574:     	ldr	x8, [x26, #0x128]
1015b5578:     	cmp	x8, #0x2
1015b557c:     	b.ne	0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b5580:     	ldr	x8, [x26, #0x120]
1015b5584:     	ldr	w22, [x8]
1015b5588:     	ldr	x8, [sp, #0x38]
1015b558c:     	ldr	w8, [x8, #0x4]
1015b5590:     	cmp	w22, w8
1015b5594:     	b.ne	0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b5598:     	ldr	w24, [x26, #0x130]
1015b559c:     	ldr	x8, [sp, #0x38]
1015b55a0:     	ldr	w8, [x8, #0x8]
1015b55a4:     	cmp	w24, w8
1015b55a8:     	b.ne	0x1015b55b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
1015b55ac:     	ldr	x8, [x26, #0x10]
1015b55b0:     	cmp	x8, #0xb
1015b55b4:     	b.eq	0x1015b52ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x428>
1015b55b8:     	ldr	x10, [sp, #0x40]
1015b55bc:     	str	wzr, [x10]
1015b55c0:     	mov	w8, #0xc                ; =12
1015b55c4:     	strb	w8, [x10, #0x8]
1015b55c8:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b55cc:     	add	x8, x8, #0x7cb
1015b55d0:     	mov	w9, #0x2b               ; =43
1015b55d4:     	stp	x8, x9, [x10, #0x10]
1015b55d8:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b55dc:     	ldr	x9, [sp, #0x40]
1015b55e0:     	stp	x22, x21, [x9, #0x8]
1015b55e4:     	mov	w8, #0x6                ; =6
1015b55e8:     	str	w8, [x9]
1015b55ec:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b55f0:     	ldr	x1, [x27, #0x408]
1015b55f4:     	cmp	x20, x1
1015b55f8:     	b.hs	0x1015b628c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13c8>
1015b55fc:     	ldr	x8, [x27, #0x400]
1015b5600:     	add	x28, x8, x20, lsl #9
1015b5604:     	ldp	x9, x8, [x28]
1015b5608:     	eor	x9, x9, #0x2
1015b560c:     	orr	x8, x9, x8
1015b5610:     	ldr	x19, [sp, #0x40]
1015b5614:     	cbnz	x8, 0x1015b5670 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7ac>
1015b5618:     	str	wzr, [x19]
1015b561c:     	mov	w8, #0xc                ; =12
1015b5620:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015b5624:     	add	x9, x9, #0x796
1015b5628:     	stp	x8, x9, [x19, #0x8]
1015b562c:     	mov	w8, #0x23               ; =35
1015b5630:     	str	x8, [x19, #0x18]
1015b5634:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5638:     	ldur	q0, [x26, #0x15]
1015b563c:     	ldr	x10, [sp, #0x40]
1015b5640:     	stur	q0, [x10, #0x15]
1015b5644:     	ldur	q0, [x26, #0x25]
1015b5648:     	stur	q0, [x10, #0x25]
1015b564c:     	ldur	q0, [x26, #0x35]
1015b5650:     	stur	q0, [x10, #0x35]
1015b5654:     	ldr	q0, [sp, #0x440]
1015b5658:     	str	q0, [x10, #0x40]
1015b565c:     	ldur	q0, [x26, #0x5]
1015b5660:     	stur	q0, [x10, #0x5]
1015b5664:     	str	w9, [x10]
1015b5668:     	strb	w8, [x10, #0x4]
1015b566c:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5670:     	add	x24, sp, #0x400
1015b5674:     	add	x8, sp, #0x400
1015b5678:     	mov	x0, x21
1015b567c:     	mov	w1, #0x0                ; =0
1015b5680:     	bl	0x1015d7004 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015b5684:     	ldr	w8, [sp, #0x400]
1015b5688:     	tbz	w8, #0x0, 0x1015b56bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7f8>
1015b568c:     	ldur	q0, [x24, #0x18]
1015b5690:     	ldur	q1, [x24, #0x28]
1015b5694:     	ldur	q2, [x24, #0x38]
1015b5698:     	stp	q1, q2, [sp, #0x310]
1015b569c:     	ldur	q3, [x24, #0x48]
1015b56a0:     	str	q3, [sp, #0x330]
1015b56a4:     	ldur	q4, [x24, #0x8]
1015b56a8:     	stp	q4, q0, [sp, #0x2f0]
1015b56ac:     	stp	q1, q2, [x19, #0x20]
1015b56b0:     	str	q3, [x19, #0x40]
1015b56b4:     	stp	q4, q0, [x19]
1015b56b8:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b56bc:     	ldr	x10, [sp, #0x30]
1015b56c0:     	ldr	x8, [sp, #0x18]
1015b56c4:     	add	x8, x10, x8
1015b56c8:     	ldur	q0, [x24, #0x48]
1015b56cc:     	ldur	q1, [x24, #0x58]
1015b56d0:     	stp	q0, q1, [sp, #0x330]
1015b56d4:     	ldur	x9, [x24, #0x68]
1015b56d8:     	str	x9, [sp, #0x350]
1015b56dc:     	ldur	q2, [x24, #0x8]
1015b56e0:     	str	q2, [sp, #0x2f0]
1015b56e4:     	ldur	q3, [x24, #0x38]
1015b56e8:     	ldur	q4, [x24, #0x18]
1015b56ec:     	ldur	q5, [x24, #0x28]
1015b56f0:     	stp	q2, q4, [sp, #0x90]
1015b56f4:     	stp	q5, q3, [sp, #0xb0]
1015b56f8:     	str	x9, [sp, #0xf0]
1015b56fc:     	stp	q0, q1, [sp, #0xd0]
1015b5700:     	str	x10, [sp, #0x400]
1015b5704:     	str	x8, [sp, #0x408]
1015b5708:     	add	x0, sp, #0x400
1015b570c:     	add	x1, x27, #0x488
1015b5710:     	bl	0x1015b0f1c <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>
1015b5714:     	ldr	x25, [x21, #0x490]
1015b5718:     	ldr	x2, [x25, #0xd8]
1015b571c:     	cmp	x22, x2
1015b5720:     	add	x26, sp, #0x400
1015b5724:     	tbz	w0, #0x0, 0x1015b585c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x998>
1015b5728:     	b.hi	0x1015b61c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1300>
1015b572c:     	ldr	x1, [x25, #0xd0]
1015b5730:     	ldp	q0, q1, [x21, #0x80]
1015b5734:     	str	q0, [sp, #0x480]
1015b5738:     	str	q1, [sp, #0x490]
1015b573c:     	ldr	x8, [x21, #0xa0]
1015b5740:     	str	x8, [sp, #0x4a0]
1015b5744:     	ldp	q0, q1, [x21, #0x40]
1015b5748:     	str	q0, [sp, #0x440]
1015b574c:     	str	q1, [sp, #0x450]
1015b5750:     	ldp	q1, q0, [x21, #0x60]
1015b5754:     	str	q0, [sp, #0x470]
1015b5758:     	str	q1, [sp, #0x460]
1015b575c:     	ldp	q0, q1, [x21]
1015b5760:     	str	q0, [sp, #0x400]
1015b5764:     	str	q1, [sp, #0x410]
1015b5768:     	ldp	q1, q0, [x21, #0x20]
1015b576c:     	add	x8, x25, #0x3b8
1015b5770:     	str	q0, [sp, #0x430]
1015b5774:     	str	q1, [sp, #0x420]
1015b5778:     	add	x9, sp, #0x90
1015b577c:     	stp	x8, x9, [sp, #0x8]
1015b5780:     	add	x9, sp, #0x400
1015b5784:     	str	x9, [sp]
1015b5788:     	add	x8, sp, #0xf8
1015b578c:     	add	x5, x25, #0x3c0
1015b5790:     	mov	x0, x28
1015b5794:     	mov	x2, x22
1015b5798:     	mov	x3, x23
1015b579c:     	mov	x4, x22
1015b57a0:     	mov	x6, #0x0                ; =0
1015b57a4:     	bl	0x1016123cc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>
1015b57a8:     	b	0x1015b58cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa08>
1015b57ac:     	ldr	x10, [sp, #0x40]
1015b57b0:     	str	wzr, [x10]
1015b57b4:     	mov	w8, #0xc                ; =12
1015b57b8:     	strb	w8, [x10, #0x8]
1015b57bc:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b57c0:     	add	x8, x8, #0x624
1015b57c4:     	b	0x1015b55d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x70c>
1015b57c8:     	ldr	x10, [sp, #0x40]
1015b57cc:     	str	wzr, [x10]
1015b57d0:     	mov	w8, #0xc                ; =12
1015b57d4:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015b57d8:     	add	x9, x9, #0x7e0
1015b57dc:     	stp	x8, x9, [x10, #0x8]
1015b57e0:     	mov	w8, #0x20               ; =32
1015b57e4:     	str	x8, [x10, #0x18]
1015b57e8:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b57ec:     	ldp	q0, q1, [sp, #0x50]
1015b57f0:     	add	x9, sp, #0x400
1015b57f4:     	stur	q0, [x9, #0x4]
1015b57f8:     	stur	q1, [x9, #0x14]
1015b57fc:     	ldr	q0, [sp, #0x70]
1015b5800:     	stur	q0, [x9, #0x24]
1015b5804:     	ldr	x8, [sp, #0x80]
1015b5808:     	stur	x8, [x9, #0x34]
1015b580c:     	ldr	q0, [sp, #0x400]
1015b5810:     	ldr	q1, [sp, #0x410]
1015b5814:     	ldr	x10, [sp, #0x40]
1015b5818:     	stur	q0, [x10, #0x4]
1015b581c:     	mov	w8, #0x2                ; =2
1015b5820:     	str	w8, [x10]
1015b5824:     	stur	q1, [x10, #0x14]
1015b5828:     	ldr	q0, [sp, #0x420]
1015b582c:     	stur	q0, [x10, #0x24]
1015b5830:     	ldur	q0, [x9, #0x2c]
1015b5834:     	str	q0, [x10, #0x30]
1015b5838:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b583c:     	ldr	x10, [sp, #0x40]
1015b5840:     	str	wzr, [x10]
1015b5844:     	mov	w8, #0xc                ; =12
1015b5848:     	strb	w8, [x10, #0x8]
1015b584c:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b5850:     	add	x8, x8, #0x64f
1015b5854:     	mov	w9, #0x2a               ; =42
1015b5858:     	b	0x1015b55d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
1015b585c:     	b.hi	0x1015b61d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1314>
1015b5860:     	ldr	x1, [x25, #0xd0]
1015b5864:     	ldp	q0, q1, [x21, #0x80]
1015b5868:     	str	q0, [sp, #0x480]
1015b586c:     	str	q1, [sp, #0x490]
1015b5870:     	ldr	x8, [x21, #0xa0]
1015b5874:     	str	x8, [sp, #0x4a0]
1015b5878:     	ldp	q0, q1, [x21, #0x40]
1015b587c:     	str	q0, [sp, #0x440]
1015b5880:     	str	q1, [sp, #0x450]
1015b5884:     	ldp	q1, q0, [x21, #0x60]
1015b5888:     	str	q0, [sp, #0x470]
1015b588c:     	str	q1, [sp, #0x460]
1015b5890:     	ldp	q0, q1, [x21]
1015b5894:     	str	q0, [sp, #0x400]
1015b5898:     	str	q1, [sp, #0x410]
1015b589c:     	ldp	q1, q0, [x21, #0x20]
1015b58a0:     	str	q0, [sp, #0x430]
1015b58a4:     	str	q1, [sp, #0x420]
1015b58a8:     	add	x8, sp, #0xf8
1015b58ac:     	add	x5, sp, #0x400
1015b58b0:     	add	x6, x25, #0x3b8
1015b58b4:     	add	x7, sp, #0x90
1015b58b8:     	mov	x0, x28
1015b58bc:     	mov	x2, x22
1015b58c0:     	mov	x3, x23
1015b58c4:     	mov	x4, x22
1015b58c8:     	bl	0x1027f6918 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_frame_words>
1015b58cc:     	ldrb	w8, [sp, #0xf8]
1015b58d0:     	cmp	w8, #0x2e
1015b58d4:     	b.ne	0x1015b5974 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xab0>
1015b58d8:     	ldr	x2, [x25, #0xd8]
1015b58dc:     	cmp	x22, x2
1015b58e0:     	b.hi	0x1015b61ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1328>
1015b58e4:     	ldr	x6, [x25, #0xd0]
1015b58e8:     	ldp	x4, x8, [sp, #0x30]
1015b58ec:     	ldr	w3, [x8, #0x4]
1015b58f0:     	add	x8, x25, #0x2f8
1015b58f4:     	stp	x22, x8, [sp, #0x8]
1015b58f8:     	add	x0, sp, #0x400
1015b58fc:     	add	x1, x25, #0x3c0
1015b5900:     	add	x2, x27, #0x488
1015b5904:     	str	x23, [sp]
1015b5908:     	mov	x5, x22
1015b590c:     	mov	x7, x22
1015b5910:     	bl	0x1015b4214 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4pack>
1015b5914:     	ldr	x2, [x25, #0xd8]
1015b5918:     	cmp	x22, x2
1015b591c:     	b.hi	0x1015b6218 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1354>
1015b5920:     	ldr	x0, [x25, #0xd0]
1015b5924:     	str	xzr, [sp, #0x2f0]
1015b5928:     	add	x2, sp, #0x2f0
1015b592c:     	mov	x1, x22
1015b5930:     	bl	0x1015e41f4 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
1015b5934:     	ldr	w8, [sp, #0x400]
1015b5938:     	cmp	w8, #0x6
1015b593c:     	b.eq	0x1015b5494 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d0>
1015b5940:     	ldur	q0, [x26, #0x14]
1015b5944:     	ldr	x9, [sp, #0x40]
1015b5948:     	stur	q0, [x9, #0x14]
1015b594c:     	ldur	q0, [x26, #0x24]
1015b5950:     	stur	q0, [x9, #0x24]
1015b5954:     	ldur	q0, [x26, #0x34]
1015b5958:     	stur	q0, [x9, #0x34]
1015b595c:     	ldr	q0, [sp, #0x440]
1015b5960:     	str	q0, [x9, #0x40]
1015b5964:     	ldur	q0, [x26, #0x4]
1015b5968:     	stur	q0, [x9, #0x4]
1015b596c:     	str	w8, [x9]
1015b5970:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5974:     	ldr	x2, [x25, #0xd8]
1015b5978:     	cmp	x22, x2
1015b597c:     	b.hi	0x1015b6200 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x133c>
1015b5980:     	ldr	x0, [x25, #0xd0]
1015b5984:     	str	xzr, [sp, #0x400]
1015b5988:     	add	x2, sp, #0x400
1015b598c:     	mov	x1, x22
1015b5990:     	bl	0x1015e41f4 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
1015b5994:     	ldr	x1, [x27, #0x380]
1015b5998:     	cmp	x20, x1
1015b599c:     	b.hs	0x1015b629c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13d8>
1015b59a0:     	ldr	x8, [x27, #0x378]
1015b59a4:     	mov	w9, #0x170              ; =368
1015b59a8:     	madd	x8, x20, x9, x8
1015b59ac:     	ldr	w9, [x8, #0x158]
1015b59b0:     	add	x10, sp, #0xf8
1015b59b4:     	add	x8, x8, #0x148
1015b59b8:     	ldr	q0, [x8]
1015b59bc:     	ldp	q1, q2, [x10]
1015b59c0:     	ldr	x11, [sp, #0x40]
1015b59c4:     	stur	q1, [x11, #0x18]
1015b59c8:     	stur	q2, [x11, #0x28]
1015b59cc:     	ldr	q1, [x10, #0x20]
1015b59d0:     	stur	q1, [x11, #0x38]
1015b59d4:     	ldr	x8, [sp, #0x128]
1015b59d8:     	str	x8, [x11, #0x48]
1015b59dc:     	mov	w8, #0x3                ; =3
1015b59e0:     	str	w8, [x11]
1015b59e4:     	stur	q0, [x11, #0x4]
1015b59e8:     	str	w9, [x11, #0x14]
1015b59ec:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b59f0:     	ldr	x25, [x21, #0x490]
1015b59f4:     	ldr	x1, [x25, #0x3c0]
1015b59f8:     	add	x0, sp, #0x400
1015b59fc:     	add	x2, x27, #0x488
1015b5a00:     	add	x5, x25, #0x2f8
1015b5a04:     	mov	x3, x22
1015b5a08:     	mov	x4, x23
1015b5a0c:     	bl	0x1015b4b7c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames7project>
1015b5a10:     	ldr	w8, [sp, #0x400]
1015b5a14:     	cmp	w8, #0x6
1015b5a18:     	b.ne	0x1015b5b0c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc48>
1015b5a1c:     	add	x8, sp, #0x400
1015b5a20:     	ldur	q0, [x8, #0x38]
1015b5a24:     	ldur	q1, [x8, #0x28]
1015b5a28:     	ldur	q2, [x8, #0x18]
1015b5a2c:     	ldur	q3, [x8, #0x8]
1015b5a30:     	stp	q3, q2, [sp, #0x230]
1015b5a34:     	stp	q1, q0, [sp, #0x250]
1015b5a38:     	ldp	x9, x8, [x26]
1015b5a3c:     	mov	w10, #0x1               ; =1
1015b5a40:     	cmp	x10, x9
1015b5a44:     	ngcs	xzr, x8
1015b5a48:     	b.lo	0x1015b5ef4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1030>
1015b5a4c:     	ldr	x8, [x26, #0x128]
1015b5a50:     	cmp	x8, #0x2
1015b5a54:     	b.lo	0x1015b62bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13f8>
1015b5a58:     	ldr	x8, [x26, #0x120]
1015b5a5c:     	ldr	w1, [x8, #0x4]
1015b5a60:     	mov	w22, #0x1               ; =1
1015b5a64:     	add	x8, sp, #0x400
1015b5a68:     	add	x0, x25, #0xf0
1015b5a6c:     	add	x2, x25, #0x2f8
1015b5a70:     	bl	0x1015d0bac <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015b5a74:     	add	x8, sp, #0x400
1015b5a78:     	ldur	q0, [x8, #0x8]
1015b5a7c:     	ldur	q1, [x8, #0x18]
1015b5a80:     	stp	q0, q1, [sp, #0x2b0]
1015b5a84:     	ldur	q0, [x8, #0x28]
1015b5a88:     	str	q0, [sp, #0x2d0]
1015b5a8c:     	ldr	x8, [sp, #0x400]
1015b5a90:     	ldr	x9, [sp, #0x438]
1015b5a94:     	str	x9, [sp, #0x2e0]
1015b5a98:     	cbz	x8, 0x1015b5bbc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcf8>
1015b5a9c:     	ldp	q0, q1, [sp, #0x2b0]
1015b5aa0:     	add	x9, sp, #0x230
1015b5aa4:     	stur	q0, [x9, #0x48]
1015b5aa8:     	stur	q1, [x9, #0x58]
1015b5aac:     	ldr	q0, [sp, #0x2d0]
1015b5ab0:     	add	x26, sp, #0x230
1015b5ab4:     	stur	q0, [x9, #0x68]
1015b5ab8:     	ldr	x9, [sp, #0x2e0]
1015b5abc:     	str	x9, [sp, #0x2a8]
1015b5ac0:     	str	x8, [sp, #0x270]
1015b5ac4:     	ldr	x1, [x27, #0x408]
1015b5ac8:     	cmp	x20, x1
1015b5acc:     	b.hs	0x1015b6304 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1440>
1015b5ad0:     	ldr	x8, [x27, #0x400]
1015b5ad4:     	add	x22, x8, x20, lsl #9
1015b5ad8:     	ldp	x9, x8, [x22]
1015b5adc:     	eor	x9, x9, #0x2
1015b5ae0:     	orr	x8, x9, x8
1015b5ae4:     	cbnz	x8, 0x1015b5c0c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd48>
1015b5ae8:     	ldr	x10, [sp, #0x40]
1015b5aec:     	str	wzr, [x10]
1015b5af0:     	mov	w8, #0xc                ; =12
1015b5af4:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015b5af8:     	add	x9, x9, #0x823
1015b5afc:     	stp	x8, x9, [x10, #0x8]
1015b5b00:     	mov	w8, #0x2a               ; =42
1015b5b04:     	str	x8, [x10, #0x18]
1015b5b08:     	b	0x1015b6094 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
1015b5b0c:     	add	x10, sp, #0x400
1015b5b10:     	ldur	q0, [x10, #0x14]
1015b5b14:     	ldur	q1, [x10, #0x24]
1015b5b18:     	ldur	q2, [x10, #0x34]
1015b5b1c:     	stp	q1, q2, [sp, #0x310]
1015b5b20:     	ldr	w9, [sp, #0x444]
1015b5b24:     	str	w9, [sp, #0x330]
1015b5b28:     	ldur	q3, [x10, #0x4]
1015b5b2c:     	stp	q3, q0, [sp, #0x2f0]
1015b5b30:     	ldr	x10, [sp, #0x448]
1015b5b34:     	ldr	x11, [sp, #0x40]
1015b5b38:     	stur	q0, [x11, #0x14]
1015b5b3c:     	stur	q1, [x11, #0x24]
1015b5b40:     	stur	q2, [x11, #0x34]
1015b5b44:     	str	w9, [x11, #0x44]
1015b5b48:     	stur	q3, [x11, #0x4]
1015b5b4c:     	str	w8, [x11]
1015b5b50:     	str	x10, [x11, #0x48]
1015b5b54:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5b58:     	ldr	x25, [x21, #0x490]
1015b5b5c:     	add	x0, sp, #0x400
1015b5b60:     	add	x1, x25, #0x3c0
1015b5b64:     	add	x2, x27, #0x488
1015b5b68:     	add	x6, x25, #0x2f8
1015b5b6c:     	mov	x3, x22
1015b5b70:     	mov	x4, x23
1015b5b74:     	mov	x5, x24
1015b5b78:     	bl	0x1015b35a8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames17project_composite>
1015b5b7c:     	ldr	w8, [sp, #0x400]
1015b5b80:     	cmp	w8, #0x6
1015b5b84:     	b.ne	0x1015b5b94 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
1015b5b88:     	mov	x22, #0x0               ; =0
1015b5b8c:     	add	x26, sp, #0x400
1015b5b90:     	b	0x1015b5498 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
1015b5b94:     	ldr	q0, [sp, #0x420]
1015b5b98:     	ldr	q1, [sp, #0x430]
1015b5b9c:     	ldr	x8, [sp, #0x40]
1015b5ba0:     	stp	q0, q1, [x8, #0x20]
1015b5ba4:     	ldr	q0, [sp, #0x440]
1015b5ba8:     	str	q0, [x8, #0x40]
1015b5bac:     	ldr	q0, [sp, #0x410]
1015b5bb0:     	ldr	q1, [sp, #0x400]
1015b5bb4:     	stp	q1, q0, [x8]
1015b5bb8:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5bbc:     	ldp	q0, q1, [sp, #0x2b0]
1015b5bc0:     	add	x9, sp, #0x400
1015b5bc4:     	stur	q0, [x9, #0x4]
1015b5bc8:     	stur	q1, [x9, #0x14]
1015b5bcc:     	ldr	q0, [sp, #0x2d0]
1015b5bd0:     	stur	q0, [x9, #0x24]
1015b5bd4:     	ldr	x8, [sp, #0x2e0]
1015b5bd8:     	stur	x8, [x9, #0x34]
1015b5bdc:     	ldr	q0, [sp, #0x400]
1015b5be0:     	ldr	q1, [sp, #0x410]
1015b5be4:     	ldr	x10, [sp, #0x40]
1015b5be8:     	stur	q0, [x10, #0x4]
1015b5bec:     	mov	w8, #0x2                ; =2
1015b5bf0:     	str	w8, [x10]
1015b5bf4:     	stur	q1, [x10, #0x14]
1015b5bf8:     	ldr	q0, [sp, #0x420]
1015b5bfc:     	stur	q0, [x10, #0x24]
1015b5c00:     	ldur	q0, [x9, #0x2c]
1015b5c04:     	str	q0, [x10, #0x30]
1015b5c08:     	b	0x1015b60a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11dc>
1015b5c0c:     	add	x24, sp, #0x400
1015b5c10:     	add	x8, sp, #0x400
1015b5c14:     	mov	x0, x21
1015b5c18:     	mov	w1, #0x0                ; =0
1015b5c1c:     	bl	0x1015d7004 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015b5c20:     	ldr	x8, [sp, #0x400]
1015b5c24:     	cmp	x8, #0x1
1015b5c28:     	b.ne	0x1015b5cd4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe10>
1015b5c2c:     	ldur	q0, [x24, #0x18]
1015b5c30:     	ldur	q1, [x24, #0x28]
1015b5c34:     	ldur	q2, [x24, #0x38]
1015b5c38:     	stp	q1, q2, [sp, #0x310]
1015b5c3c:     	ldur	q3, [x24, #0x48]
1015b5c40:     	str	q3, [sp, #0x330]
1015b5c44:     	ldur	q4, [x24, #0x8]
1015b5c48:     	stp	q4, q0, [sp, #0x2f0]
1015b5c4c:     	ldr	x8, [sp, #0x40]
1015b5c50:     	stp	q1, q2, [x8, #0x20]
1015b5c54:     	str	q3, [x8, #0x40]
1015b5c58:     	stp	q4, q0, [x8]
1015b5c5c:     	b	0x1015b6094 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
1015b5c60:     	ldp	q0, q1, [sp, #0x150]
1015b5c64:     	add	x9, sp, #0x400
1015b5c68:     	stur	q0, [x9, #0x4]
1015b5c6c:     	stur	q1, [x9, #0x14]
1015b5c70:     	ldr	q0, [sp, #0x170]
1015b5c74:     	stur	q0, [x9, #0x24]
1015b5c78:     	ldr	x8, [sp, #0x180]
1015b5c7c:     	b	0x1015b5808 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x944>
1015b5c80:     	add	x24, sp, #0x400
1015b5c84:     	add	x8, sp, #0x400
1015b5c88:     	mov	x0, x21
1015b5c8c:     	mov	w1, #0x0                ; =0
1015b5c90:     	bl	0x1015d7004 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015b5c94:     	ldr	x8, [sp, #0x400]
1015b5c98:     	cmp	x8, #0x1
1015b5c9c:     	b.ne	0x1015b5d80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xebc>
1015b5ca0:     	ldur	q0, [x24, #0x18]
1015b5ca4:     	ldur	q1, [x24, #0x28]
1015b5ca8:     	ldur	q2, [x24, #0x38]
1015b5cac:     	stp	q1, q2, [sp, #0x310]
1015b5cb0:     	ldur	q3, [x24, #0x48]
1015b5cb4:     	str	q3, [sp, #0x330]
1015b5cb8:     	ldur	q4, [x24, #0x8]
1015b5cbc:     	stp	q4, q0, [sp, #0x2f0]
1015b5cc0:     	ldr	x8, [sp, #0x40]
1015b5cc4:     	stp	q1, q2, [x8, #0x20]
1015b5cc8:     	str	q3, [x8, #0x40]
1015b5ccc:     	stp	q4, q0, [x8]
1015b5cd0:     	b	0x1015b6108 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
1015b5cd4:     	ldur	q0, [x24, #0x48]
1015b5cd8:     	ldur	q1, [x24, #0x58]
1015b5cdc:     	stp	q0, q1, [sp, #0x330]
1015b5ce0:     	ldur	x8, [x24, #0x68]
1015b5ce4:     	str	x8, [sp, #0x350]
1015b5ce8:     	ldur	q2, [x24, #0x8]
1015b5cec:     	ldur	q3, [x24, #0x18]
1015b5cf0:     	stp	q2, q3, [sp, #0x2f0]
1015b5cf4:     	ldur	q4, [x24, #0x38]
1015b5cf8:     	ldur	q5, [x24, #0x28]
1015b5cfc:     	stp	q2, q3, [sp, #0x360]
1015b5d00:     	stp	q5, q4, [sp, #0x380]
1015b5d04:     	str	x8, [sp, #0x3c0]
1015b5d08:     	stp	q0, q1, [sp, #0x3a0]
1015b5d0c:     	ldr	x8, [sp, #0x230]
1015b5d10:     	cbz	x8, 0x1015b5e68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfa4>
1015b5d14:     	ldp	q0, q1, [x21, #0x80]
1015b5d18:     	str	q0, [sp, #0x480]
1015b5d1c:     	str	q1, [sp, #0x490]
1015b5d20:     	ldr	x8, [x21, #0xa0]
1015b5d24:     	str	x8, [sp, #0x4a0]
1015b5d28:     	ldp	q0, q1, [x21, #0x40]
1015b5d2c:     	str	q0, [sp, #0x440]
1015b5d30:     	str	q1, [sp, #0x450]
1015b5d34:     	ldp	q1, q0, [x21, #0x60]
1015b5d38:     	str	q0, [sp, #0x470]
1015b5d3c:     	str	q1, [sp, #0x460]
1015b5d40:     	ldp	q0, q1, [x21]
1015b5d44:     	str	q0, [sp, #0x400]
1015b5d48:     	str	q1, [sp, #0x410]
1015b5d4c:     	ldp	q1, q0, [x21, #0x20]
1015b5d50:     	str	q0, [sp, #0x430]
1015b5d54:     	str	q1, [sp, #0x420]
1015b5d58:     	add	x8, sp, #0x3c8
1015b5d5c:     	add	x1, sp, #0x270
1015b5d60:     	add	x3, sp, #0x230
1015b5d64:     	add	x4, sp, #0x400
1015b5d68:     	add	x5, x25, #0x3b8
1015b5d6c:     	add	x6, sp, #0x360
1015b5d70:     	mov	x0, x22
1015b5d74:     	mov	x2, x23
1015b5d78:     	bl	0x1027f6cbc <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall25admit_buffer_record_field>
1015b5d7c:     	b	0x1015b5edc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1018>
1015b5d80:     	ldur	q0, [x24, #0x48]
1015b5d84:     	ldur	q1, [x24, #0x58]
1015b5d88:     	stp	q0, q1, [sp, #0x330]
1015b5d8c:     	ldur	x8, [x24, #0x68]
1015b5d90:     	str	x8, [sp, #0x350]
1015b5d94:     	ldur	q2, [x24, #0x8]
1015b5d98:     	ldur	q3, [x24, #0x18]
1015b5d9c:     	stp	q2, q3, [sp, #0x2f0]
1015b5da0:     	ldur	q4, [x24, #0x38]
1015b5da4:     	ldur	q5, [x24, #0x28]
1015b5da8:     	stp	q2, q3, [sp, #0x190]
1015b5dac:     	stp	q5, q4, [sp, #0x1b0]
1015b5db0:     	str	x8, [sp, #0x1f0]
1015b5db4:     	stp	q0, q1, [sp, #0x1d0]
1015b5db8:     	ldr	x8, [sp, #0x38]
1015b5dbc:     	ldr	x7, [x8, #0x10]
1015b5dc0:     	ldp	q0, q1, [x21, #0x80]
1015b5dc4:     	str	q0, [sp, #0x480]
1015b5dc8:     	str	q1, [sp, #0x490]
1015b5dcc:     	ldr	x8, [x21, #0xa0]
1015b5dd0:     	str	x8, [sp, #0x4a0]
1015b5dd4:     	ldp	q0, q1, [x21, #0x40]
1015b5dd8:     	str	q0, [sp, #0x440]
1015b5ddc:     	str	q1, [sp, #0x450]
1015b5de0:     	ldp	q1, q0, [x21, #0x60]
1015b5de4:     	str	q0, [sp, #0x470]
1015b5de8:     	str	q1, [sp, #0x460]
1015b5dec:     	ldp	q0, q1, [x21]
1015b5df0:     	str	q0, [sp, #0x400]
1015b5df4:     	str	q1, [sp, #0x410]
1015b5df8:     	ldp	q1, q0, [x21, #0x20]
1015b5dfc:     	add	x8, x25, #0x3b8
1015b5e00:     	str	q0, [sp, #0x430]
1015b5e04:     	str	q1, [sp, #0x420]
1015b5e08:     	add	x9, sp, #0x190
1015b5e0c:     	stp	x8, x9, [sp, #0x8]
1015b5e10:     	add	x9, sp, #0x400
1015b5e14:     	adrp	x1, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b5e18:     	add	x1, x1, #0x6f8
1015b5e1c:     	str	x9, [sp]
1015b5e20:     	add	x8, sp, #0x1f8
1015b5e24:     	add	x5, x25, #0x3c0
1015b5e28:     	add	x6, sp, #0x270
1015b5e2c:     	adrp	x3, 0x10755a000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x2b98>
1015b5e30:     	add	x3, x3, #0x7d0
1015b5e34:     	mov	x0, x23
1015b5e38:     	mov	w2, #0x2                ; =2
1015b5e3c:     	mov	w4, #0x2                ; =2
1015b5e40:     	bl	0x101612614 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>
1015b5e44:     	ldrb	w8, [sp, #0x1f8]
1015b5e48:     	cmp	w8, #0x2e
1015b5e4c:     	b.ne	0x1015b60cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1208>
1015b5e50:     	add	x0, sp, #0x270
1015b5e54:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b5e58:     	ldr	x8, [sp, #0x38]
1015b5e5c:     	ldr	x23, [x8, #0x10]
1015b5e60:     	ldr	w24, [x8, #0x8]
1015b5e64:     	b	0x1015b5b5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc98>
1015b5e68:     	ldr	w3, [sp, #0x248]
1015b5e6c:     	ldur	q0, [x26, #0x8]
1015b5e70:     	str	q0, [sp, #0x2f0]
1015b5e74:     	ldp	q0, q1, [x21, #0x80]
1015b5e78:     	str	q0, [sp, #0x480]
1015b5e7c:     	str	q1, [sp, #0x490]
1015b5e80:     	ldr	x8, [x21, #0xa0]
1015b5e84:     	str	x8, [sp, #0x4a0]
1015b5e88:     	ldp	q0, q1, [x21, #0x40]
1015b5e8c:     	str	q0, [sp, #0x440]
1015b5e90:     	str	q1, [sp, #0x450]
1015b5e94:     	ldp	q1, q0, [x21, #0x60]
1015b5e98:     	str	q0, [sp, #0x470]
1015b5e9c:     	str	q1, [sp, #0x460]
1015b5ea0:     	ldp	q0, q1, [x21]
1015b5ea4:     	str	q0, [sp, #0x400]
1015b5ea8:     	str	q1, [sp, #0x410]
1015b5eac:     	ldp	q1, q0, [x21, #0x20]
1015b5eb0:     	str	q0, [sp, #0x430]
1015b5eb4:     	str	q1, [sp, #0x420]
1015b5eb8:     	add	x8, sp, #0x3c8
1015b5ebc:     	add	x1, sp, #0x270
1015b5ec0:     	add	x4, sp, #0x2f0
1015b5ec4:     	add	x5, sp, #0x400
1015b5ec8:     	add	x6, x25, #0x3b8
1015b5ecc:     	add	x7, sp, #0x360
1015b5ed0:     	mov	x0, x22
1015b5ed4:     	mov	x2, x23
1015b5ed8:     	bl	0x1027f6974 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_record_word>
1015b5edc:     	ldrb	w8, [sp, #0x3c8]
1015b5ee0:     	cmp	w8, #0x2e
1015b5ee4:     	b.ne	0x1015b6058 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1194>
1015b5ee8:     	mov	w22, #0x1               ; =1
1015b5eec:     	add	x0, sp, #0x270
1015b5ef0:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b5ef4:     	ldr	x8, [x27, #0x360]
1015b5ef8:     	ldr	x9, [sp, #0x38]
1015b5efc:     	ldr	w1, [x9, #0x8]
1015b5f00:     	cmp	x8, x1
1015b5f04:     	b.ls	0x1015b62b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13ec>
1015b5f08:     	ldr	x8, [x27, #0x358]
1015b5f0c:     	mov	w9, #0x140              ; =320
1015b5f10:     	umaddl	x9, w1, w9, x8
1015b5f14:     	ldr	x8, [sp, #0x230]
1015b5f18:     	cbz	x8, 0x1015b5ffc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1138>
1015b5f1c:     	ldp	q0, q1, [sp, #0x230]
1015b5f20:     	str	q0, [sp, #0x400]
1015b5f24:     	str	q1, [sp, #0x410]
1015b5f28:     	ldp	q0, q1, [sp, #0x250]
1015b5f2c:     	str	q0, [sp, #0x420]
1015b5f30:     	str	q1, [sp, #0x430]
1015b5f34:     	ldr	x8, [x27, #0x448]
1015b5f38:     	cmp	x8, x1
1015b5f3c:     	b.ls	0x1015b62dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1418>
1015b5f40:     	ldr	x8, [x27, #0x440]
1015b5f44:     	mov	w10, #0x24              ; =36
1015b5f48:     	umaddl	x8, w1, w10, x8
1015b5f4c:     	ldr	w10, [sp, #0x438]
1015b5f50:     	ldr	w11, [x8, #0x20]
1015b5f54:     	cmp	w10, w11
1015b5f58:     	b.ne	0x1015b5fcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
1015b5f5c:     	ldp	q0, q1, [sp, #0x240]
1015b5f60:     	stp	q0, q1, [sp, #0x2f0]
1015b5f64:     	ldr	x10, [sp, #0x2f0]
1015b5f68:     	ldr	x11, [sp, #0x2f8]
1015b5f6c:     	ldp	x12, x13, [x8]
1015b5f70:     	ldr	x14, [sp, #0x300]
1015b5f74:     	ldr	x15, [sp, #0x308]
1015b5f78:     	ldp	x16, x8, [x8, #0x10]
1015b5f7c:     	cmp	x10, x12
1015b5f80:     	ccmp	x11, x13, #0x0, eq
1015b5f84:     	ccmp	x14, x16, #0x0, eq
1015b5f88:     	ccmp	x15, x8, #0x0, eq
1015b5f8c:     	b.ne	0x1015b5fcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
1015b5f90:     	ldrb	w8, [x9, #0x124]
1015b5f94:     	cmp	w8, #0x7
1015b5f98:     	b.ne	0x1015b5fcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
1015b5f9c:     	add	x8, sp, #0x2f0
1015b5fa0:     	add	x0, x25, #0xf0
1015b5fa4:     	add	x2, sp, #0x400
1015b5fa8:     	add	x3, x25, #0x2f8
1015b5fac:     	bl	0x1015d26b4 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015b5fb0:     	ldrb	w8, [sp, #0x2f0]
1015b5fb4:     	cmp	w8, #0x14
1015b5fb8:     	b.ne	0x1015b6114 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1250>
1015b5fbc:     	mov	w22, #0x0               ; =0
1015b5fc0:     	add	x0, sp, #0x400
1015b5fc4:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b5fc8:     	b	0x1015b5b88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcc4>
1015b5fcc:     	ldr	x10, [sp, #0x40]
1015b5fd0:     	str	wzr, [x10]
1015b5fd4:     	mov	w8, #0xc                ; =12
1015b5fd8:     	strb	w8, [x10, #0x8]
1015b5fdc:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b5fe0:     	add	x8, x8, #0x7a1
1015b5fe4:     	mov	w9, #0x2a               ; =42
1015b5fe8:     	stp	x8, x9, [x10, #0x10]
1015b5fec:     	mov	w22, #0x0               ; =0
1015b5ff0:     	add	x0, sp, #0x400
1015b5ff4:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b5ff8:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b5ffc:     	ldr	w8, [sp, #0x248]
1015b6000:     	ldr	w10, [x9, #0x130]
1015b6004:     	cmp	w8, w10
1015b6008:     	b.ne	0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b600c:     	ldrb	w8, [sp, #0x239]
1015b6010:     	ldr	x21, [sp, #0x240]
1015b6014:     	ldrb	w10, [sp, #0x238]
1015b6018:     	ldrb	w9, [x9, #0x124]
1015b601c:     	cmp	w10, #0x2
1015b6020:     	b.le	0x1015b6040 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x117c>
1015b6024:     	cmp	w10, #0x4
1015b6028:     	b.gt	0x1015b60b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11f0>
1015b602c:     	cmp	w10, #0x3
1015b6030:     	b.ne	0x1015b6174 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12b0>
1015b6034:     	cmp	w9, #0x3
1015b6038:     	b.eq	0x1015b6198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015b603c:     	b	0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b6040:     	cbz	w10, 0x1015b615c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1298>
1015b6044:     	cmp	w10, #0x1
1015b6048:     	b.ne	0x1015b6168 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a4>
1015b604c:     	cmp	w9, #0x1
1015b6050:     	b.eq	0x1015b6198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015b6054:     	b	0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b6058:     	ldr	x1, [x27, #0x378]
1015b605c:     	ldr	x2, [x27, #0x380]
1015b6060:     	add	x0, sp, #0x400
1015b6064:     	add	x4, sp, #0x3c8
1015b6068:     	mov	x3, x20
1015b606c:     	bl	0x1015b16f8 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>
1015b6070:     	ldr	q0, [sp, #0x420]
1015b6074:     	ldr	q1, [sp, #0x430]
1015b6078:     	ldr	x8, [sp, #0x40]
1015b607c:     	stp	q0, q1, [x8, #0x20]
1015b6080:     	ldr	q0, [sp, #0x440]
1015b6084:     	str	q0, [x8, #0x40]
1015b6088:     	ldr	q0, [sp, #0x410]
1015b608c:     	ldr	q1, [sp, #0x400]
1015b6090:     	stp	q1, q0, [x8]
1015b6094:     	mov	w22, #0x1               ; =1
1015b6098:     	add	x0, sp, #0x270
1015b609c:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b60a0:     	ldr	x8, [sp, #0x230]
1015b60a4:     	cbz	x8, 0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b60a8:     	add	x0, sp, #0x230
1015b60ac:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b60b0:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b60b4:     	cmp	w10, #0x5
1015b60b8:     	b.ne	0x1015b618c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12c8>
1015b60bc:     	cmp	w9, #0x5
1015b60c0:     	b.ne	0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b60c4:     	ldrh	w21, [sp, #0x23a]
1015b60c8:     	b	0x1015b6198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015b60cc:     	ldr	x1, [x27, #0x378]
1015b60d0:     	ldr	x2, [x27, #0x380]
1015b60d4:     	add	x0, sp, #0x400
1015b60d8:     	add	x4, sp, #0x1f8
1015b60dc:     	mov	x3, x20
1015b60e0:     	bl	0x1015b1664 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>
1015b60e4:     	ldr	q0, [sp, #0x420]
1015b60e8:     	ldr	q1, [sp, #0x430]
1015b60ec:     	ldr	x8, [sp, #0x40]
1015b60f0:     	stp	q0, q1, [x8, #0x20]
1015b60f4:     	ldr	q0, [sp, #0x440]
1015b60f8:     	str	q0, [x8, #0x40]
1015b60fc:     	ldr	q0, [sp, #0x410]
1015b6100:     	ldr	q1, [sp, #0x400]
1015b6104:     	stp	q1, q0, [x8]
1015b6108:     	add	x0, sp, #0x270
1015b610c:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b6110:     	b	0x1015b5244 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
1015b6114:     	add	x10, sp, #0x230
1015b6118:     	ldur	w9, [x10, #0xc1]
1015b611c:     	ldr	x11, [sp, #0x40]
1015b6120:     	stur	w9, [x11, #0x9]
1015b6124:     	ldr	w9, [sp, #0x2f4]
1015b6128:     	str	w9, [x11, #0xc]
1015b612c:     	ldr	q0, [sp, #0x310]
1015b6130:     	stur	q0, [x11, #0x28]
1015b6134:     	ldr	x9, [sp, #0x320]
1015b6138:     	str	x9, [x11, #0x38]
1015b613c:     	ldr	d0, [sp, #0x308]
1015b6140:     	ldur	q1, [x10, #0xc8]
1015b6144:     	mov	w9, #0x2                ; =2
1015b6148:     	str	w9, [x11]
1015b614c:     	strb	w8, [x11, #0x8]
1015b6150:     	str	q1, [x11, #0x10]
1015b6154:     	str	d0, [x11, #0x20]
1015b6158:     	b	0x1015b5fec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1128>
1015b615c:     	cbnz	w9, 0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b6160:     	and	x21, x8, #0x1
1015b6164:     	b	0x1015b6198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015b6168:     	cmp	w9, #0x2
1015b616c:     	b.eq	0x1015b6198 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015b6170:     	b	0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b6174:     	cmp	w9, #0x4
1015b6178:     	b.ne	0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b617c:     	mov	w22, #0x1               ; =1
1015b6180:     	mov	x21, x8
1015b6184:     	add	x26, sp, #0x400
1015b6188:     	b	0x1015b5498 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
1015b618c:     	cmp	w9, #0x6
1015b6190:     	b.ne	0x1015b61a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015b6194:     	ldr	w21, [sp, #0x23c]
1015b6198:     	mov	w22, #0x1               ; =1
1015b619c:     	add	x26, sp, #0x400
1015b61a0:     	b	0x1015b5498 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
1015b61a4:     	ldr	x10, [sp, #0x40]
1015b61a8:     	str	wzr, [x10]
1015b61ac:     	mov	w8, #0xc                ; =12
1015b61b0:     	strb	w8, [x10, #0x8]
1015b61b4:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015b61b8:     	add	x8, x8, #0x778
1015b61bc:     	mov	w9, #0x29               ; =41
1015b61c0:     	b	0x1015b55d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
1015b61c4:     	adrp	x3, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b61c8:     	add	x3, x3, #0x608
1015b61cc:     	mov	x0, #0x0                ; =0
1015b61d0:     	mov	x1, x22
1015b61d4:     	bl	0x103a05ef4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015b61d8:     	adrp	x3, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b61dc:     	add	x3, x3, #0x590
1015b61e0:     	mov	x0, #0x0                ; =0
1015b61e4:     	mov	x1, x22
1015b61e8:     	bl	0x103a05ef4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015b61ec:     	adrp	x3, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b61f0:     	add	x3, x3, #0x5f0
1015b61f4:     	mov	x0, #0x0                ; =0
1015b61f8:     	mov	x1, x22
1015b61fc:     	bl	0x103a05ef4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015b6200:     	adrp	x3, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b6204:     	add	x3, x3, #0x5c0
1015b6208:     	mov	x0, #0x0                ; =0
1015b620c:     	mov	x1, x22
1015b6210:     	bl	0x103a05ef4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015b6214:     	b	0x1015b6328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015b6218:     	adrp	x3, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b621c:     	add	x3, x3, #0x5d8
1015b6220:     	mov	x0, #0x0                ; =0
1015b6224:     	mov	x1, x22
1015b6228:     	bl	0x103a05ef4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015b622c:     	b	0x1015b6328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015b6230:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b6234:     	add	x2, x2, #0x620
1015b6238:     	mov	x0, x1
1015b623c:     	mov	x1, x8
1015b6240:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b6244:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b6248:     	add	x2, x2, #0x560
1015b624c:     	mov	x0, x20
1015b6250:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b6254:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b6258:     	add	x2, x2, #0x638
1015b625c:     	mov	x0, x25
1015b6260:     	mov	x1, x22
1015b6264:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b6268:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b626c:     	add	x2, x2, #0x650
1015b6270:     	mov	x0, x25
1015b6274:     	mov	x1, x22
1015b6278:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b627c:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b6280:     	add	x2, x2, #0x680
1015b6284:     	mov	x0, x20
1015b6288:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b628c:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b6290:     	add	x2, x2, #0x578
1015b6294:     	mov	x0, x20
1015b6298:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b629c:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b62a0:     	add	x2, x2, #0x5a8
1015b62a4:     	mov	x0, x20
1015b62a8:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b62ac:     	b	0x1015b6328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015b62b0:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b62b4:     	add	x2, x2, #0x6f8
1015b62b8:     	b	0x1015b62c8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1404>
1015b62bc:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b62c0:     	add	x2, x2, #0x6c8
1015b62c4:     	mov	w1, #0x1                ; =1
1015b62c8:     	mov	w22, #0x1               ; =1
1015b62cc:     	mov	x0, x1
1015b62d0:     	mov	x1, x8
1015b62d4:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b62d8:     	b	0x1015b6328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015b62dc:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b62e0:     	add	x2, x2, #0x710
1015b62e4:     	mov	x0, x1
1015b62e8:     	mov	x1, x8
1015b62ec:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b62f0:     	b	0x1015b6328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015b62f4:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b62f8:     	add	x2, x2, #0x698
1015b62fc:     	mov	w0, #0x1                ; =1
1015b6300:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b6304:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b6308:     	add	x2, x2, #0x6e0
1015b630c:     	mov	x0, x20
1015b6310:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b6314:     	b	0x1015b6328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
1015b6318:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015b631c:     	add	x2, x2, #0x6b0
1015b6320:     	mov	x0, x20
1015b6324:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015b6328:     	brk	#0x1
1015b632c:     	mov	x20, x0
1015b6330:     	add	x0, sp, #0x400
1015b6334:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b6338:     	b	0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b633c:     	mov	x20, x0
1015b6340:     	add	x0, sp, #0x270
1015b6344:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b6348:     	b	0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b634c:     	mov	x20, x0
1015b6350:     	add	x0, sp, #0x270
1015b6354:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b6358:     	mov	w22, #0x1               ; =1
1015b635c:     	b	0x1015b6364 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14a0>
1015b6360:     	mov	x20, x0
1015b6364:     	cbz	w22, 0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b6368:     	ldr	x8, [sp, #0x230]
1015b636c:     	cbz	x8, 0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b6370:     	add	x0, sp, #0x230
1015b6374:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b6378:     	b	0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b637c:     	add	x8, x28, x19
1015b6380:     	ldp	q0, q1, [sp, #0x2f0]
1015b6384:     	ldp	q2, q3, [sp, #0x310]
1015b6388:     	stp	q2, q3, [x8, #0x20]
1015b638c:     	stp	q0, q1, [x8]
1015b6390:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
1015b6394:     	mov	x20, x0
1015b6398:     	tbnz	w19, #0x0, 0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b639c:     	add	x0, sp, #0x2f0
1015b63a0:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015b63a4:     	b	0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b63a8:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015b63ac:     	mov	x20, x0
1015b63b0:     	ldr	w8, [sp, #0x400]
1015b63b4:     	cmp	w8, #0x6
1015b63b8:     	b.eq	0x1015b63d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
1015b63bc:     	add	x0, sp, #0x400
1015b63c0:     	bl	0x1015ae63c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015b63c4:     	mov	x0, x20
1015b63c8:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
1015b63cc:     	mov	x20, x0
1015b63d0:     	add	x0, sp, #0xf8
1015b63d4:     	bl	0x1015ae7d0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015b63d8:     	mov	x0, x20
1015b63dc:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
