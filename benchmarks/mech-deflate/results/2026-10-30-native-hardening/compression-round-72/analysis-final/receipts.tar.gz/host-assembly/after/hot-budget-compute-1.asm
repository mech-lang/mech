
/private/tmp/mech-checked-compute-inline-round72-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010236f080 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
10236f080:     	stp	x28, x27, [sp, #-0x60]!
10236f084:     	stp	x26, x25, [sp, #0x10]
10236f088:     	stp	x24, x23, [sp, #0x20]
10236f08c:     	stp	x22, x21, [sp, #0x30]
10236f090:     	stp	x20, x19, [sp, #0x40]
10236f094:     	stp	x29, x30, [sp, #0x50]
10236f098:     	add	x29, sp, #0x50
10236f09c:     	sub	sp, sp, #0x1a0
10236f0a0:     	ldr	x9, [x0, #0xd0]
10236f0a4:     	adds	x13, x9, x1
10236f0a8:     	b.hs	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f0ac:     	ldr	x21, [x0, #0xc8]
10236f0b0:     	ldr	x26, [x0, #0xe8]
10236f0b4:     	ldr	x28, [x0, #0xf8]
10236f0b8:     	ldr	x25, [x0, #0x108]
10236f0bc:     	ldp	x22, x23, [x0, #0x118]
10236f0c0:     	ldr	x9, [x0]
10236f0c4:     	cmp	x9, #0x1
10236f0c8:     	b.ne	0x10236f134 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
10236f0cc:     	cmp	x23, #0x10, lsl #12     ; =0x10000
10236f0d0:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f0d4:     	mov	w9, #0x1000000          ; =16777216
10236f0d8:     	cmp	x26, x9
10236f0dc:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f0e0:     	mov	w9, #0x1000000          ; =16777216
10236f0e4:     	cmp	x13, x9
10236f0e8:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f0ec:     	mov	w9, #0x1000000          ; =16777216
10236f0f0:     	cmp	x28, x9
10236f0f4:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f0f8:     	mov	w9, #0x1000000          ; =16777216
10236f0fc:     	cmp	x25, x9
10236f100:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f104:     	cmp	x22, #0x10, lsl #12     ; =0x10000
10236f108:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f10c:     	cmp	x21, #0x10, lsl #12     ; =0x10000
10236f110:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f114:     	ldr	x9, [x0, #0x8]
10236f118:     	cmp	x13, x9
10236f11c:     	b.hi	0x10236f12c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f120:     	ldr	x9, [x0, #0x10]
10236f124:     	cmp	x21, x9
10236f128:     	b.ls	0x10236f26c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10236f12c:     	mov	w9, #0x2                ; =2
10236f130:     	b	0x10236f274 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f4>
10236f134:     	ldp	x24, x2, [x0, #0xd8]
10236f138:     	ldr	x20, [x0, #0xf0]
10236f13c:     	ldr	x9, [x0, #0x100]
10236f140:     	ldr	x1, [x0, #0x110]
10236f144:     	ldr	x15, [x0, #0x128]
10236f148:     	ldr	x27, [x0, #0x18]
10236f14c:     	cmp	x27, #0x2
10236f150:     	b.ne	0x10236f1c4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x144>
10236f154:     	mov	x19, x0
10236f158:     	mov	x27, x8
10236f15c:     	stp	x21, x13, [x29, #-0xf0]
10236f160:     	mov	x21, x13
10236f164:     	stp	x24, x2, [x29, #-0xe0]
10236f168:     	stp	x26, x20, [x29, #-0xd0]
10236f16c:     	stp	x28, x9, [x29, #-0xc0]
10236f170:     	stp	x25, x1, [x29, #-0xb0]
10236f174:     	stp	x22, x23, [x29, #-0xa0]
10236f178:     	stur	x15, [x29, #-0x90]
10236f17c:     	sub	x8, x29, #0x88
10236f180:     	sub	x0, x29, #0xf0
10236f184:     	bl	0x10237c38c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
10236f188:     	ldurb	w8, [x29, #-0x88]
10236f18c:     	cmp	w8, #0x8
10236f190:     	b.ne	0x10236f240 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1c0>
10236f194:     	add	x0, sp, #0xd0
10236f198:     	sub	x1, x29, #0xf0
10236f19c:     	bl	0x10236a940 <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
10236f1a0:     	mov	x8, x27
10236f1a4:     	ldrb	w9, [sp, #0xd0]
10236f1a8:     	cmp	w9, #0x8
10236f1ac:     	b.eq	0x10236f264 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e4>
10236f1b0:     	ldp	q0, q1, [sp, #0xd0]
10236f1b4:     	stp	q0, q1, [x8]
10236f1b8:     	ldr	x9, [sp, #0xf0]
10236f1bc:     	str	x9, [x8, #0x20]
10236f1c0:     	b	0x10236f278 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f1c4:     	str	x9, [sp, #0xc0]
10236f1c8:     	ldr	x10, [x0, #0x20]
10236f1cc:     	ldp	x11, x9, [x0, #0x38]
10236f1d0:     	stp	x9, x10, [sp, #0xb0]
10236f1d4:     	ldp	x10, x9, [x0, #0x48]
10236f1d8:     	stp	x9, x11, [sp, #0xa0]
10236f1dc:     	ldr	x9, [x0, #0x58]
10236f1e0:     	stp	x9, x10, [sp, #0x90]
10236f1e4:     	ldp	x10, x9, [x0, #0x60]
10236f1e8:     	str	x9, [sp, #0x88]
10236f1ec:     	ldp	x11, x9, [x0, #0x70]
10236f1f0:     	stp	x0, x9, [sp, #0x78]
10236f1f4:     	ldp	x6, x12, [x0, #0x80]
10236f1f8:     	ldp	x4, x7, [x0, #0x90]
10236f1fc:     	ldr	x3, [x0, #0xa0]
10236f200:     	ldp	w5, w14, [x0, #0xb8]
10236f204:     	ldr	x9, [x0, #0xc0]
10236f208:     	str	x9, [sp, #0xc8]
10236f20c:     	adrp	x0, 0x108067000 <__mi_heap_main+0xb28>
10236f210:     	add	x0, x0, #0x550
10236f214:     	ldr	x9, [x0]
10236f218:     	blr	x9
10236f21c:     	mov	x19, x0
10236f220:     	ldrb	w9, [x0, #0x48]
10236f224:     	cmp	w9, #0x1
10236f228:     	b.eq	0x10236f2f4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x274>
10236f22c:     	cmp	w9, #0x2
10236f230:     	b.ne	0x10236f298 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x218>
10236f234:     	adrp	x0, 0x10802a000 <_anon.a7c7e38c7a68621129987b4543ae834d.36>
10236f238:     	add	x0, x0, #0x480
10236f23c:     	bl	0x1039fa2c0 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10236f240:     	sub	x8, x29, #0x88
10236f244:     	ldp	q0, q1, [x8]
10236f248:     	stp	q0, q1, [sp, #0xd0]
10236f24c:     	ldur	x8, [x29, #-0x68]
10236f250:     	str	x8, [sp, #0xf0]
10236f254:     	mov	x8, x27
10236f258:     	ldrb	w9, [sp, #0xd0]
10236f25c:     	cmp	w9, #0x8
10236f260:     	b.ne	0x10236f1b0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x130>
10236f264:     	mov	x0, x19
10236f268:     	mov	x13, x21
10236f26c:     	str	x13, [x0, #0xd0]
10236f270:     	mov	w9, #0x8                ; =8
10236f274:     	strb	w9, [x8]
10236f278:     	add	sp, sp, #0x1a0
10236f27c:     	ldp	x29, x30, [sp, #0x50]
10236f280:     	ldp	x20, x19, [sp, #0x40]
10236f284:     	ldp	x22, x21, [sp, #0x30]
10236f288:     	ldp	x24, x23, [sp, #0x20]
10236f28c:     	ldp	x26, x25, [sp, #0x10]
10236f290:     	ldp	x28, x27, [sp], #0x60
10236f294:     	ret
10236f298:     	stp	x1, x15, [sp, #0x10]
10236f29c:     	adrp	x1, 0x10235e000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortjNCINvMNtCsgKscDXrlV49_5alloc5sliceSj11sort_by_keybNCNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine16source_semantics8frontend17document_loweringNtB23_15SemanticBuilder28order_document_state_writers0E0EB27_+0x610>
10236f2a0:     	add	x1, x1, #0x310
10236f2a4:     	mov	x0, x19
10236f2a8:     	str	x8, [sp, #0x20]
10236f2ac:     	stp	x6, x13, [sp, #0x50]
10236f2b0:     	stp	x14, x7, [sp, #0x30]
10236f2b4:     	str	x2, [sp, #0x8]
10236f2b8:     	stp	x3, x4, [sp, #0x40]
10236f2bc:     	str	w5, [sp, #0x2c]
10236f2c0:     	stp	x12, x11, [sp, #0x60]
10236f2c4:     	str	x10, [sp, #0x70]
10236f2c8:     	bl	0x102e66ad4 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10236f2cc:     	ldp	x11, x10, [sp, #0x68]
10236f2d0:     	ldp	x13, x12, [sp, #0x58]
10236f2d4:     	ldp	x7, x3, [sp, #0x38]
10236f2d8:     	ldp	x4, x6, [sp, #0x48]
10236f2dc:     	ldr	w5, [sp, #0x2c]
10236f2e0:     	ldp	x2, x1, [sp, #0x8]
10236f2e4:     	ldp	x15, x8, [sp, #0x18]
10236f2e8:     	ldr	x14, [sp, #0x30]
10236f2ec:     	mov	w9, #0x1                ; =1
10236f2f0:     	strb	w9, [x19, #0x48]
10236f2f4:     	str	x10, [sp, #0x70]
10236f2f8:     	ldr	x9, [x19]
10236f2fc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10236f300:     	cmp	x9, x10
10236f304:     	b.hs	0x10236f514 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x494>
10236f308:     	add	x10, x9, #0x1
10236f30c:     	str	x10, [x19]
10236f310:     	ldr	x10, [x19, #0x8]
10236f314:     	cbz	x10, 0x10236f3bc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x33c>
10236f318:     	stp	x12, x11, [sp, #0x60]
10236f31c:     	ldr	x11, [x10, #0x10]
10236f320:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
10236f324:     	cmp	x11, x12
10236f328:     	b.hs	0x10236f520 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x4a0>
10236f32c:     	ldr	x10, [x10, #0x58]
10236f330:     	str	x9, [x19]
10236f334:     	ldr	x9, [sp, #0xc8]
10236f338:     	cmp	x10, x9
10236f33c:     	b.ne	0x10236f3c0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x340>
10236f340:     	stp	x7, x3, [sp, #0x38]
10236f344:     	stp	x4, x6, [sp, #0x48]
10236f348:     	str	w5, [sp, #0x2c]
10236f34c:     	str	x14, [sp, #0x30]
10236f350:     	mov	x19, x8
10236f354:     	stp	x21, x13, [x29, #-0xf0]
10236f358:     	str	x13, [sp, #0x58]
10236f35c:     	stp	x24, x2, [x29, #-0xe0]
10236f360:     	mov	x24, x2
10236f364:     	stp	x26, x20, [x29, #-0xd0]
10236f368:     	ldr	x8, [sp, #0xc0]
10236f36c:     	stp	x28, x8, [x29, #-0xc0]
10236f370:     	stp	x25, x1, [x29, #-0xb0]
10236f374:     	mov	x26, x1
10236f378:     	stp	x22, x23, [x29, #-0xa0]
10236f37c:     	mov	x20, x15
10236f380:     	stur	x15, [x29, #-0x90]
10236f384:     	sub	x8, x29, #0x88
10236f388:     	sub	x0, x29, #0xf0
10236f38c:     	bl	0x10237c38c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
10236f390:     	ldurb	w8, [x29, #-0x88]
10236f394:     	cmp	w8, #0x8
10236f398:     	b.ne	0x10236f3c8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
10236f39c:     	cmp	x27, #0x1
10236f3a0:     	mov	x8, x19
10236f3a4:     	ldr	x11, [sp, #0xb8]
10236f3a8:     	b.ne	0x10236f3e0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
10236f3ac:     	cmp	x23, x11
10236f3b0:     	b.ls	0x10236f3e0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
10236f3b4:     	mov	w9, #0x0                ; =0
10236f3b8:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f3bc:     	str	x9, [x19]
10236f3c0:     	strb	wzr, [x8]
10236f3c4:     	b	0x10236f278 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f3c8:     	sub	x8, x29, #0x88
10236f3cc:     	ldp	q0, q1, [x8]
10236f3d0:     	stp	q0, q1, [x19]
10236f3d4:     	ldur	x8, [x29, #-0x68]
10236f3d8:     	str	x8, [x19, #0x20]
10236f3dc:     	b	0x10236f278 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f3e0:     	ldp	x9, x11, [sp, #0xa8]
10236f3e4:     	cmp	x9, #0x1
10236f3e8:     	b.ne	0x10236f400 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
10236f3ec:     	cmp	x28, x11
10236f3f0:     	b.ls	0x10236f400 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
10236f3f4:     	mov	w9, #0x2                ; =2
10236f3f8:     	mov	x23, x28
10236f3fc:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f400:     	ldp	x9, x11, [sp, #0x98]
10236f404:     	cmp	x9, #0x1
10236f408:     	b.ne	0x10236f420 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
10236f40c:     	cmp	x25, x11
10236f410:     	b.ls	0x10236f420 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
10236f414:     	mov	w9, #0x3                ; =3
10236f418:     	mov	x23, x25
10236f41c:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f420:     	ldr	x9, [sp, #0x90]
10236f424:     	cmp	x9, #0x1
10236f428:     	ldr	x11, [sp, #0x70]
10236f42c:     	b.ne	0x10236f444 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
10236f430:     	cmp	x22, x11
10236f434:     	b.ls	0x10236f444 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
10236f438:     	mov	w9, #0x4                ; =4
10236f43c:     	mov	x23, x22
10236f440:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f444:     	ldr	x9, [sp, #0x88]
10236f448:     	cmp	x9, #0x1
10236f44c:     	ldr	x11, [sp, #0x68]
10236f450:     	b.ne	0x10236f468 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
10236f454:     	cmp	x21, x11
10236f458:     	b.ls	0x10236f468 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
10236f45c:     	mov	w9, #0x5                ; =5
10236f460:     	mov	x23, x21
10236f464:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f468:     	ldr	x9, [sp, #0x80]
10236f46c:     	cmp	x9, #0x1
10236f470:     	ldp	x11, x13, [sp, #0x50]
10236f474:     	b.ne	0x10236f48c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
10236f478:     	cmp	x13, x11
10236f47c:     	b.ls	0x10236f48c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
10236f480:     	mov	w9, #0x6                ; =6
10236f484:     	mov	x23, x13
10236f488:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f48c:     	ldr	x9, [sp, #0x60]
10236f490:     	cmp	x9, #0x1
10236f494:     	ldr	x11, [sp, #0x48]
10236f498:     	b.ne	0x10236f4b0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
10236f49c:     	cmp	x24, x11
10236f4a0:     	b.ls	0x10236f4b0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
10236f4a4:     	mov	w9, #0x7                ; =7
10236f4a8:     	mov	x23, x24
10236f4ac:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f4b0:     	ldp	x9, x11, [sp, #0x38]
10236f4b4:     	cmp	x9, #0x1
10236f4b8:     	b.ne	0x10236f4d4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
10236f4bc:     	mov	x24, x26
10236f4c0:     	cmp	x26, x11
10236f4c4:     	b.ls	0x10236f4d4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
10236f4c8:     	mov	w9, #0x8                ; =8
10236f4cc:     	mov	x23, x24
10236f4d0:     	b	0x10236f4f8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f4d4:     	ldr	w9, [sp, #0x2c]
10236f4d8:     	cmp	w9, #0x1
10236f4dc:     	ldr	x0, [sp, #0x78]
10236f4e0:     	ldr	x11, [sp, #0x30]
10236f4e4:     	b.ne	0x10236f26c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10236f4e8:     	cmp	w11, w20
10236f4ec:     	b.hs	0x10236f26c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10236f4f0:     	mov	w23, w20
10236f4f4:     	mov	w9, #0xa                ; =10
10236f4f8:     	mov	w10, #0x6               ; =6
10236f4fc:     	strb	w10, [x8]
10236f500:     	strb	w9, [x8, #0x1]
10236f504:     	mov	w9, #0x1                ; =1
10236f508:     	strb	w9, [x8, #0x2]
10236f50c:     	stp	x23, x11, [x8, #0x8]
10236f510:     	b	0x10236f278 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f514:     	adrp	x0, 0x10802b000 <_anon.a7c7e38c7a68621129987b4543ae834d.258+0x30>
10236f518:     	add	x0, x0, #0x948
10236f51c:     	bl	0x1039fa974 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236f520:     	adrp	x0, 0x10802b000 <_anon.a7c7e38c7a68621129987b4543ae834d.258+0x30>
10236f524:     	add	x0, x0, #0x960
10236f528:     	bl	0x1039fa974 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236f52c:     	brk	#0x1
10236f530:     	ldr	x8, [x19]
10236f534:     	sub	x8, x8, #0x1
10236f538:     	str	x8, [x19]
10236f53c:     	bl	0x1039fbe3c <dyld_stub_binder+0x1039fbe3c>
