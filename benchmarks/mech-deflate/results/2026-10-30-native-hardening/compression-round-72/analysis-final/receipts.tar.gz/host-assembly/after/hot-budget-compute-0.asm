
/private/tmp/mech-checked-compute-inline-round72-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023688ec <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
1023688ec:     	sub	sp, sp, #0x90
1023688f0:     	stp	x22, x21, [sp, #0x60]
1023688f4:     	stp	x20, x19, [sp, #0x70]
1023688f8:     	stp	x29, x30, [sp, #0x80]
1023688fc:     	add	x29, sp, #0x80
102368900:     	mov	x19, x8
102368904:     	ldr	x20, [x0]
102368908:     	ldr	x8, [x20, #0x10]
10236890c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102368910:     	cmp	x8, x9
102368914:     	b.hs	0x102368980 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
102368918:     	add	x9, x8, #0x1
10236891c:     	str	x9, [x20, #0x10]
102368920:     	ldr	x9, [x20, #0x38]
102368924:     	adds	x21, x9, x1
102368928:     	b.hs	0x10236898c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xa0>
10236892c:     	str	x8, [x20, #0x10]
102368930:     	cmp	x21, x2
102368934:     	b.ls	0x102368950 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x64>
102368938:     	mov	w8, #0x606              ; =1542
10236893c:     	strh	w8, [x19]
102368940:     	mov	w8, #0x1                ; =1
102368944:     	strb	w8, [x19, #0x2]
102368948:     	stp	x21, x2, [x19, #0x8]
10236894c:     	b	0x102368afc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x210>
102368950:     	adrp	x0, 0x108067000 <__mi_heap_main+0xb28>
102368954:     	add	x0, x0, #0x550
102368958:     	ldr	x8, [x0]
10236895c:     	blr	x8
102368960:     	ldrb	w8, [x0, #0x48]
102368964:     	cmp	w8, #0x1
102368968:     	b.eq	0x1023689d4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe8>
10236896c:     	cmp	w8, #0x2
102368970:     	b.ne	0x1023689ac <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xc0>
102368974:     	adrp	x0, 0x10802a000 <_anon.a7c7e38c7a68621129987b4543ae834d.36>
102368978:     	add	x0, x0, #0x480
10236897c:     	bl	0x1039fa2c0 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102368980:     	adrp	x0, 0x10802b000 <_anon.a7c7e38c7a68621129987b4543ae834d.258+0x30>
102368984:     	add	x0, x0, #0xfb8
102368988:     	bl	0x1039fa974 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236898c:     	mov	w9, #0x606              ; =1542
102368990:     	strh	w9, [x19]
102368994:     	mov	w9, #0x1                ; =1
102368998:     	strb	w9, [x19, #0x2]
10236899c:     	mov	x9, #-0x1               ; =-1
1023689a0:     	stp	x9, x2, [x19, #0x8]
1023689a4:     	str	x8, [x20, #0x10]
1023689a8:     	b	0x102368afc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x210>
1023689ac:     	adrp	x8, 0x10235e000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortjNCINvMNtCsgKscDXrlV49_5alloc5sliceSj11sort_by_keybNCNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine16source_semantics8frontend17document_loweringNtB23_15SemanticBuilder28order_document_state_writers0E0EB27_+0x610>
1023689b0:     	add	x8, x8, #0x310
1023689b4:     	str	x0, [sp, #0x8]
1023689b8:     	mov	x22, x1
1023689bc:     	mov	x1, x8
1023689c0:     	bl	0x102e66ad4 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
1023689c4:     	ldr	x0, [sp, #0x8]
1023689c8:     	mov	x1, x22
1023689cc:     	mov	w8, #0x1                ; =1
1023689d0:     	strb	w8, [x0, #0x48]
1023689d4:     	ldr	x8, [x0, #0x20]
1023689d8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1023689dc:     	cmp	x8, x9
1023689e0:     	b.hs	0x102368b10 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x224>
1023689e4:     	ldr	x8, [x0, #0x28]
1023689e8:     	cmp	x8, #0x0
1023689ec:     	ccmp	x8, x20, #0x4, ne
1023689f0:     	b.ne	0x102368a5c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x170>
1023689f4:     	ldr	x8, [x20, #0x10]
1023689f8:     	cbnz	x8, 0x102368b24 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x238>
1023689fc:     	mov	x8, #-0x1               ; =-1
102368a00:     	str	x8, [x20, #0x10]
102368a04:     	ldr	w8, [x0, #0x30]
102368a08:     	ldp	x9, x10, [x0, #0x38]
102368a0c:     	ldp	x11, x12, [x20, #0x60]
102368a10:     	cmp	x9, x11
102368a14:     	csel	x9, x9, x11, lo
102368a18:     	cmp	x10, x12
102368a1c:     	csel	x10, x10, x12, lo
102368a20:     	tst	w8, #0x1
102368a24:     	csel	x9, x9, x11, ne
102368a28:     	csel	x12, x10, x12, ne
102368a2c:     	ldr	x8, [x20, #0x48]
102368a30:     	adds	x10, x8, x21
102368a34:     	b.hs	0x102368b1c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
102368a38:     	ldr	x22, [x20, #0x40]
102368a3c:     	ldr	x8, [x20, #0x50]
102368a40:     	adds	x13, x8, x22
102368a44:     	b.hs	0x102368b1c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
102368a48:     	cmp	x10, x9
102368a4c:     	b.ls	0x102368a64 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x178>
102368a50:     	mov	w8, #0x6                ; =6
102368a54:     	mov	w11, #0x6               ; =6
102368a58:     	b	0x102368a7c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x190>
102368a5c:     	mov	w8, #0x0                ; =0
102368a60:     	b	0x102368ae4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1f8>
102368a64:     	cmp	x13, x12
102368a68:     	b.ls	0x102368a94 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
102368a6c:     	mov	w11, #0x5               ; =5
102368a70:     	mov	w8, #0x6                ; =6
102368a74:     	mov	x10, x13
102368a78:     	mov	x9, x12
102368a7c:     	mov	x12, #0x0               ; =0
102368a80:     	strb	w11, [sp, #0x39]
102368a84:     	mov	w11, #0x1               ; =1
102368a88:     	strb	w11, [sp, #0x3a]
102368a8c:     	stp	x10, x9, [sp, #0x40]
102368a90:     	b	0x102368acc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1e0>
102368a94:     	ldr	x8, [x20, #0x70]
102368a98:     	cbz	x8, 0x102368abc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d0>
102368a9c:     	add	x0, sp, #0x38
102368aa0:     	mov	x2, x1
102368aa4:     	mov	x1, x8
102368aa8:     	mov	x3, #0x0                ; =0
102368aac:     	bl	0x102369d38 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102368ab0:     	ldrb	w8, [sp, #0x38]
102368ab4:     	cmp	w8, #0x8
102368ab8:     	b.ne	0x102368ac4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d8>
102368abc:     	stp	x21, x22, [x20, #0x38]
102368ac0:     	mov	w8, #0x8                ; =8
102368ac4:     	ldr	x9, [x20, #0x10]
102368ac8:     	add	x12, x9, #0x1
102368acc:     	str	x12, [x20, #0x10]
102368ad0:     	ldur	q0, [sp, #0x39]
102368ad4:     	ldur	q1, [sp, #0x49]
102368ad8:     	stp	q0, q1, [sp, #0x10]
102368adc:     	ldr	x9, [sp, #0x58]
102368ae0:     	stur	x9, [sp, #0x2f]
102368ae4:     	strb	w8, [x19]
102368ae8:     	ldp	q0, q1, [sp, #0x10]
102368aec:     	stur	q0, [x19, #0x1]
102368af0:     	stur	q1, [x19, #0x11]
102368af4:     	ldur	x8, [sp, #0x2f]
102368af8:     	str	x8, [x19, #0x20]
102368afc:     	ldp	x29, x30, [sp, #0x80]
102368b00:     	ldp	x20, x19, [sp, #0x70]
102368b04:     	ldp	x22, x21, [sp, #0x60]
102368b08:     	add	sp, sp, #0x90
102368b0c:     	ret
102368b10:     	adrp	x0, 0x10802b000 <_anon.a7c7e38c7a68621129987b4543ae834d.258+0x30>
102368b14:     	add	x0, x0, #0xfa0
102368b18:     	bl	0x1039fa974 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102368b1c:     	mov	w8, #0x2                ; =2
102368b20:     	b	0x102368a7c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x190>
102368b24:     	adrp	x0, 0x10802b000 <_anon.a7c7e38c7a68621129987b4543ae834d.258+0x30>
102368b28:     	add	x0, x0, #0x4c8
102368b2c:     	bl	0x1039fa944 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102368b30:     	ldr	x8, [x20, #0x10]
102368b34:     	add	x8, x8, #0x1
102368b38:     	str	x8, [x20, #0x10]
102368b3c:     	bl	0x1039fbe3c <dyld_stub_binder+0x1039fbe3c>
