use mech_core::{ManagedMemoryBudget,Value,ValueDataDraft as Data,snapshot::{SnapshotValidationContext,ValueDraft}};
use mech_engine::{CanonicalSourceFrontend,ProgramArtifact};
use mech_gpu::native_artifact::{JitProgramArtifact,NativeProgramLimitMode};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
use std::sync::Arc;
fn source(text: &str) -> ProgramArtifact {
 let parsed = parse_canonical_document(TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(), ParseConfig::default());
 assert!(parsed.is_strictly_clean());
 CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(), mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap()
}
fn import(artifact: &ProgramArtifact, input: &[(String, Data)], memory: &ManagedMemoryBudget) -> Vec<Value> {
 let schemas=Arc::new(artifact.schemas().clone());
 artifact.inputs().iter().map(|port| {
  let name=mech_engine::decode_source_input_name(&port.name).unwrap();
  let data=input.iter().find(|(n,_)| *n==name).unwrap().1.clone();
  let shape_values: Box<[u64]>=if let Data::Matrix(values)=&data {mech_core::shape_for_resolved_extents(schemas.get(port.schema).unwrap(), &[1,values.len() as u64]).unwrap().parameter_values().into()} else {Box::new([])};
  let v=ValueDraft{schema:port.schema,shape_values,data}.finalize(&SnapshotValidationContext::with_shared_schemas(&schemas)).unwrap();
  let mut admission=memory.reserve_capacity(v.memory_budget_admission_bytes(memory).unwrap()).unwrap();v.into_memory_budget(&mut admission).unwrap()
 }).collect()
}

fn main(){let original=source(include_str!("/private/tmp/mech-deflate-linear-stack/hosts/gpu/tests/fixtures/native/prepared-record-lookup.mec"));let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();let mode=NativeProgramLimitMode::NoLimits;let catalog=mech_stdlib::source_catalog();let mut receipts=Vec::new();
for artifact in [original,decoded]{
 let plan=mech_engine::native_artifact::lower_native_program_artifact(&artifact,&catalog).unwrap();let frames=plan.buffer_frames();
 let mut kinds=std::collections::BTreeSet::new();
 for (site,block) in plan.blocks().iter().enumerate(){
  use mech_engine::native_artifact::{NativeIterationAction as A,NativeBufferFrameOperation as F,NativeCollectionPrimitive as P,NativeScalarKind as K,NativeScalarValue as S};
  let A::LibraryCall{template,..}=block.action()else{continue};if template.primitive()!=P::RecordFieldAccess{continue}
  let Some(action)=frames.action(site)else{continue};let F::Project{ordinal,..}=action.operation()else{continue};let Some(kind)=K::from_schema_body(template.output().body())else{continue};
  kinds.insert(format!("{kind:?}"));let prepared=mech_engine::native_artifact::prepare_native_program_library_call(&artifact,template,&catalog).unwrap();
  let mech_core::ResolvedOperationContract::Declared(contract)=template.contract()else{panic!()};let mech_core::SchemaBody::Record(fields)=template.inputs()[0].body()else{panic!()};
  let valid=mech_core::hash_str(&fields[*ordinal].name);let other=mech_core::hash_str(&fields[(*ordinal+1)%fields.len()].name);let unknown=mech_core::hash_str("absent-field-name");
  let word=match kind{K::Bool=>S::Bool(true),K::U64=>S::U64(23),K::I64=>S::I64(-17),K::F64=>S::F64(1.5),_=>continue};
  let trial=|selected,wrong,compute,comparison|{
   let memory=mode.memory_budget();let selector=ValueDraft{schema:contract.inputs[1].schema,shape_values:Box::new([]),data:Data::Id(selected)}.finalize(&SnapshotValidationContext::new(artifact.schemas())).unwrap();let mut reserve=memory.reserve_capacity(selector.memory_budget_admission_bytes(&memory).unwrap()).unwrap();let selector=selector.into_memory_budget(&mut reserve).unwrap();drop(reserve);
   let work=mech_engine::native_artifact::NativeLibraryWorkBudget::new(u64::MAX,u64::MAX,&memory).unwrap();let mut limits=mode.execution().library;limits.max_compute_work=Some(compute);limits.max_comparison_work=Some(comparison);
   let word=if wrong{if kind==K::Bool{S::U64(2)}else{S::Bool(false)}}else{word};
   let result=prepared.admit_buffer_record_word(&selector,*ordinal,contract.outputs[0].schema,word,limits,&work,mech_core::ResourceDemand::default());let row=serde_json::json!({"site":site,"kind":format!("{kind:?}"),"ordinal":ordinal,"selected":selected,"wrong_kind":wrong,"compute_limit":compute,"comparison_limit":comparison,"result":format!("{result:?}"),"used":work.used()});let used=work.used();drop((work,selector));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));(row,used)
  };
  let (row,used)=trial(valid,false,u64::MAX,u64::MAX);assert_eq!(row["result"],"Ok(())");receipts.push(row);
  for (selected,wrong,compute,comparison) in [(valid,false,used.0,used.1),(valid,false,used.0-1,used.1),(valid,false,used.0,used.1-1),(other,false,u64::MAX,u64::MAX),(unknown,false,u64::MAX,u64::MAX),(valid,true,u64::MAX,u64::MAX)]{receipts.push(trial(selected,wrong,compute,comparison).0);}
 }
 assert_eq!(kinds,["Bool","F64","I64","U64"].map(str::to_string).into_iter().collect());
 let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();let memory=mode.memory_budget();let mut published=vec![None;artifact.outputs().len()];
 for (word,number,flag,signed,ratio,left,allowed,divisor,empty,expected,error) in [(3u8,2u64,true,-2i64,1.5f64,2u64,true,1u64,false,Some(36u64),None),(11,20,false,2,0.5,3,true,2,false,Some(30),None),(3,2,true,-2,1.5,2,false,0,true,None,Some("Integrity")),(3,2,true,-2,1.5,2,true,1,true,None,Some("Library")),(3,2,true,-2,1.5,2,true,0,false,None,Some("Arithmetic")),(5,2,false,0,2.5,1,true,1,false,Some(17),None)]{
  let args=import(&artifact,&[("xs".into(),Data::Matrix(if empty{vec![]}else{vec![Data::U8(word)]}.into())),("number".into(),Data::U64(number)),("flag".into(),Data::Bool(flag)),("signed".into(),Data::I64(signed)),("ratio".into(),Data::F64(ratio)),("left".into(),Data::U64(left)),("allowed".into(),Data::Bool(allowed)),("divisor".into(),Data::U64(divisor))],&memory);let aliases=args.clone();let before=args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>();let prior=published.clone();let retained=(memory.used_bytes(),memory.retained_snapshot_nodes());
  let result=jit.evaluate_into(&args,&mut published,mode.execution(),&memory);
  if let Some(expected)=expected{let report=result.unwrap();assert_eq!(published[0].as_ref().unwrap().canonical_data_draft().unwrap(),Data::U64(expected));receipts.push(serde_json::json!({"generated_success":expected,"work":report.work}));}else{let error_text=format!("{:?}",result.unwrap_err());assert!(error_text.contains(error.unwrap()),"{error_text}");assert!(published.iter().zip(&prior).all(|(a,b)|a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),retained);receipts.push(serde_json::json!({"generated_failure":error_text}));}
  assert_eq!(args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>(),before);assert!(args.iter().zip(&aliases).all(|(a,b)|a.shares_frozen_storage(b)));
 }
 drop(published);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
}
println!("{}",serde_json::to_string_pretty(&receipts).unwrap());}
