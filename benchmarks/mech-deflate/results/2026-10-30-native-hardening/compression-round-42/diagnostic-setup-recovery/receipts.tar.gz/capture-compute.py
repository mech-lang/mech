#!/usr/bin/env python3
import json,os,subprocess,sys
from pathlib import Path
args=sys.argv[1:]
if '--crate-name' in args and args[args.index('--crate-name')+1]=='mech_compute':
 Path('/private/tmp/mech-record-lookup-round42-20261030/baseline-dependency/captured.json').write_text(json.dumps({'cwd':os.getcwd(),'command':args,'environment':{k:v for k,v in os.environ.items() if k.startswith('CARGO_PKG_') or k in ['CARGO_MANIFEST_DIR','CARGO_MANIFEST_PATH','OPT_LEVEL','PROFILE','OUT_DIR']}},indent=2)+'\n')
 sys.exit(97)
sys.exit(subprocess.run(args).returncode)
