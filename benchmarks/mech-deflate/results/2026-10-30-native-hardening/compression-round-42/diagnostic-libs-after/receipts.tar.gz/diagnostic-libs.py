from pathlib import Path
import json,subprocess,os,time,hashlib
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'diagnostic-libs';p.mkdir(exist_ok=True)
base=json.loads(Path('/private/tmp/mech-scalar-child-round39-20261030/unit/build.json').read_text());compute=json.loads((r/'baseline-dependency/captured.json').read_text());variants={'before':json.loads(Path('/private/tmp/mech-scalar-child-round39-20261030/final-libraries.json').read_text()),'after':json.loads((r/'final-libraries.json').read_text())}
def run(label,cmd,d,env,cwd):
 at=time.monotonic();q=subprocess.run(cmd,cwd=cwd,env={**os.environ,**env},capture_output=True,text=True);(d/(label+'.stdout')).write_text(q.stdout);(d/(label+'.stderr')).write_text(q.stderr);(d/(label+'.json')).write_text(json.dumps({'command':cmd,'cwd':str(cwd),'environment':env,'exit':q.returncode,'seconds':time.monotonic()-at},indent=2)+'\n');print(d.name,label,q.returncode,flush=True)
 if q.returncode:print(q.stderr[-4500:],flush=True)
 q.check_returncode()
for label,libs in variants.items():
 d=p/label;d.mkdir(exist_ok=True);cmd=compute['command'].copy();cmd[cmd.index('--out-dir')+1]=str(d)
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern' and a.startswith('mech_engine='):cmd[i]='mech_engine='+libs['mech_engine']['path']
 run('compute-build',cmd,d,compute['environment'],compute['cwd'])
 cmd=base['command'].copy();cmd.remove('--test');cmd[cmd.index('opt-level=1')]='opt-level=3';cmd[-1]=str(d/'libmech_gpu.rlib');cmd[1:1]=['--crate-type','lib','-C','embed-bitcode=no','-C','strip=debuginfo'];cmd[-3:-3]=['-L','dependency='+str(d),'-L','dependency='+str(Path(libs['mech_engine']['path']).parent)]
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern':
   key=a.split('=')[0]
   if key in libs:cmd[i]=key+'='+libs[key]['path']
   if key=='mech_compute':cmd[i]=key+'='+str(d/'libmech_compute-84cb0ef1d137eee3.rlib')
 run('gpu-build',cmd,d,base['environment'],w)
 current={**libs,'mech_gpu':{**libs['mech_gpu'],'path':str(d/'libmech_gpu.rlib'),'sha256':hashlib.sha256((d/'libmech_gpu.rlib').read_bytes()).hexdigest()}}
 (d/'libraries.json').write_text(json.dumps(current,indent=2)+'\n')
 files=[x for x in d.iterdir() if x.suffix in {'.json','.stdout','.stderr'}]
 subprocess.run(['python3',str(r/'archive.py'),'diagnostic-libs-'+label,*map(str,files),str(r/'diagnostic-libs.py')],cwd=w,check=True)
