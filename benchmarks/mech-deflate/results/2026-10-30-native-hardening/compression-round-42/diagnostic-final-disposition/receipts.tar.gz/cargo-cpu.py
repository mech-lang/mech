from pathlib import Path
import os,json,hashlib,subprocess,time,statistics
r=Path(__file__).resolve().parent; w=Path('/private/tmp/mech-deflate-linear-stack'); p=r/'cargo-cpu';p.mkdir()
libs=json.loads((r/'final-libraries.json').read_text());cmd=json.loads((r/'counters/after/cpu-build.json').read_text())['command']
source=(r/'counters/after/cpu.rs').read_text().replace(str(r/'diagnostic-libs/after/image/descriptor.json'),str(r/'linked-primary/after/descriptor.json'))
(p/'cpu.rs').write_text(source)
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':key=a.split('=')[0];cmd[i]=key+'='+libs[key]['path']
 if a=='dependency='+str(r/'diagnostic-libs/after'):cmd[i]='dependency='+str(r/'final-library')
 if a=='link-arg='+str(r/'diagnostic-libs/after/image/object.o'):cmd[i]='link-arg='+str(r/'linked-primary/after/object.o')
cmd[-3]=str(p/'cpu.rs');cmd[-1]=str(p/'cpu')
def run(label,command):
 at=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True)
 for kind in ['stdout','stderr']:(p/(label+'.'+kind)).write_text(getattr(q,kind))
 receipt={'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'scope':'Separate after-only hardware-counter check using the exact frozen Cargo libraries and primary same-build Object/image; not a new matched elapsed comparison.'}
 if label=='build':
  receipt['libraries']=libs
  compute=Path('/private/tmp/mech-live-control-target/release/deps/libmech_compute-84cb0ef1d137eee3.rlib');receipt['mech_compute']={'path':str(compute),'sha256':hashlib.sha256(compute.read_bytes()).hexdigest()}
 else:receipt['binary_sha256']=hashlib.sha256((p/'cpu').read_bytes()).hexdigest()
 (p/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(label,q.returncode,flush=True)
 if q.returncode:print(q.stderr[-5000:],flush=True)
 q.check_returncode()
run('build',cmd)
run('run',[str(p/'cpu'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','32'])
rows=[json.loads(x) for x in (p/'run.stdout').read_text().splitlines() if x.startswith('{')];rows=[x for x in rows if not x['warmup'] and not x['profile']]
assert len(rows)==32 and all(x['work']==60260219686 and x['capacity']==13 and x['exact_reference'] and x['independent_inflation'] and x['pageins']==0 for x in rows)
assert 'CLEANUP bytes=0 nodes=0' in (p/'run.stderr').read_text()
print(json.dumps({k:statistics.median(x[k] for x in rows) for k in ['instructions','cycles','physical_after','rss_after']},indent=2),flush=True)
subprocess.run(['python3',str(r/'archive.py'),'cargo-cpu',str(p/'cpu.rs'),str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(p/'run.json'),str(p/'run.stdout'),str(p/'run.stderr'),str(r/'cargo-cpu.py')],cwd=w,check=True)
