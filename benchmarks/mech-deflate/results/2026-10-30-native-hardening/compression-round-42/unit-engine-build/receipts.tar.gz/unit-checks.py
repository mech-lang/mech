from pathlib import Path
import json,subprocess,os,time,re
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'units';p.mkdir()
libs=json.loads((r/'final-libraries.json').read_text())
def run(label,cmd,env=None,expected=None):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**(env or {})},capture_output=True,text=True);(p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr);receipt={'command':cmd,'exit':q.returncode,'environment':env or {},'seconds':time.monotonic()-at}
 if expected is not None:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);receipt['executed_tests']=int(m[1]) if m else None
 (p/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(label,q.returncode,receipt.get('executed_tests'),flush=True)
 if q.returncode:print(q.stdout[-2200:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if expected is not None:assert receipt['executed_tests']==expected,receipt
 subprocess.run(['python3',str(r/'archive.py'),'unit-'+label,*map(str,[p/(label+'.stdout'),p/(label+'.stderr'),p/(label+'.json'),r/'unit-checks.py'])],cwd=w,check=True)
for label,base in [('engine',Path('/private/tmp/mech-append-loops-round25-20261029/engine-units/build.json')),('gpu',Path('/private/tmp/mech-scalar-child-round39-20261030/unit/build.json'))]:
 b=json.loads(base.read_text());cmd=b['command'].copy()
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern' and a.split('=')[0] in libs:
   key=a.split('=')[0];cmd[i]=key+'='+libs[key]['path']
 cmd[-1]=str(p/(label+'-unit-tests'));run(label+'-build',cmd,b.get('environment'))
 if label=='engine':run('record-selector',[str(p/'engine-unit-tests'),'record_selector::tests','--nocapture','--test-threads=1'],expected=2)
 else:
  run('record-generated',[str(p/'gpu-unit-tests'),'composition_tests::record_lookup::','record_lookup_finite_boundaries','--nocapture','--test-threads=1'],expected=2)
  run('runtime',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--nocapture','--test-threads=1'],expected=315)
  run('work-values',[str(p/'gpu-unit-tests'),'native_artifact::work::','native_artifact::memory::','native_artifact::values::','--nocapture','--test-threads=1'],expected=31)
