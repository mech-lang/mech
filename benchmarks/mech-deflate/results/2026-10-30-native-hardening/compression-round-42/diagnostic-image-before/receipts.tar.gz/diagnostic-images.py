from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');base=json.loads(Path('/private/tmp/mech-scalar-child-round39-20261030/primary/current-build.json').read_text())
for label in ['before','after']:
 d=r/'diagnostic-libs'/label;libs=json.loads((d/'libraries.json').read_text());p=d/'image';p.mkdir()
 source=Path('/private/tmp/mech-retirement-round36-20261030/object/inspect.rs').read_text().replace('/private/tmp/mech-retirement-round36-20261030/object',str(p));(p/'inspect.rs').write_text(source)
 cmd=base['command'].copy()
 for i,a in enumerate(cmd):
  if i and cmd[i-1]=='--extern':key=a.split('=')[0];cmd[i]=key+'='+libs[key]['path']
 cmd[-3]=str(p/'inspect.rs');cmd[-1]=str(p/'inspect');cmd[-3:-3]=['-L','dependency='+str(d),'-L','dependency='+str(Path(libs['mech_engine']['path']).parent)]
 for name,command in [('build',cmd),('emit',[str(p/'inspect')])]:
  at=time.monotonic();q=subprocess.run(command,cwd=w,capture_output=True,text=True);(p/(name+'.stdout')).write_text(q.stdout);(p/(name+'.stderr')).write_text(q.stderr);(p/(name+'.json')).write_text(json.dumps({'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'libraries':libs},indent=2)+'\n');print(label,name,q.returncode,flush=True)
  if q.returncode:print(q.stderr[-4000:],flush=True)
  q.check_returncode()
 pins={name:{'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest(),'bytes':(p/name).stat().st_size} for name in ['object.o','descriptor.json','metadata.json']}
 (p/'pins.json').write_text(json.dumps({'pins':pins,'object_matches_primary':(p/'object.o').read_bytes()==(r/'linked-primary'/label/'object.o').read_bytes(),'scope':'Fresh Object/image from these SAME diagnostic libraries. Original frozen primary executables remain unchanged.'},indent=2)+'\n')
 files=[f for f in p.iterdir() if f.is_file() and f.name not in {'object.o','descriptor.json','inspect'}]
 subprocess.run(['python3',str(r/'archive.py'),'diagnostic-image-'+label,*map(str,files),str(r/'diagnostic-images.py')],cwd=w,check=True)
 (p/'inspect').unlink()
