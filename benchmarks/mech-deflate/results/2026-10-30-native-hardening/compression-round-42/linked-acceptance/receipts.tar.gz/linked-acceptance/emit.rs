use mech_engine::CanonicalSourceFrontend;use mech_engine::ProgramArtifact;
use mech_gpu::native_artifact::{NativeProgramLimitMode,emit_program_object_with_limits};
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
fn source(text: &str) -> ProgramArtifact {
 let parsed = parse_canonical_document(TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(), ParseConfig::default());
 assert!(parsed.is_strictly_clean());
 CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(), mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap()
}
fn main(){let artifact=source(include_str!("/private/tmp/mech-record-lookup-round42-20261030/linked-acceptance/source.mec"));let object=emit_program_object_with_limits(&artifact,&mech_stdlib::source_catalog(),NativeProgramLimitMode::NoLimits.compilation()).unwrap();let p=std::path::Path::new("/private/tmp/mech-record-lookup-round42-20261030/linked-acceptance");std::fs::write(p.join("object.o"),object.bytes()).unwrap();std::fs::write(p.join("descriptor.json"),object.descriptor().encode_build_owned_image().unwrap()).unwrap();std::fs::write(p.join("metadata.json"),serde_json::to_vec_pretty(&object.metadata()).unwrap()).unwrap();}