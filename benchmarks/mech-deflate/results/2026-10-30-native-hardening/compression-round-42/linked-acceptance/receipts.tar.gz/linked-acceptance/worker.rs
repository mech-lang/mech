unsafe extern "C" { #[link_name="mech_canonical_program_identity_v1_718fbe7e810c0f413244d0abf926c2b82d2ace0f76c120eec3580a6bacb90e22"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES]; #[link_name="mech_canonical_program_entry_v1"] fn linked_entry(frame:*mut std::ffi::c_void)->u64; }
use mech_core::{ManagedMemoryBudget,Value,ValueDataDraft as Data,snapshot::{SnapshotValidationContext,ValueDraft}};
use mech_engine::{CanonicalSourceFrontend,ProgramArtifact};
use mech_gpu::native_artifact::NativeProgramLimitMode;
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
use std::sync::Arc;
fn source(text: &str) -> ProgramArtifact {
 let parsed = parse_canonical_document(TextSnapshot::new(DocumentId(71), Revision(1), text).unwrap(), ParseConfig::default());
 assert!(parsed.is_strictly_clean());
 CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(), mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap()
}
fn import(artifact: &ProgramArtifact, input: &[(String, Data)], memory: &ManagedMemoryBudget) -> Vec<Value> {
 let schemas=Arc::new(artifact.schemas().clone());
 artifact.inputs().iter().map(|port| {
  let name=mech_engine::decode_source_input_name(&port.name).unwrap();
  let data=input.iter().find(|(n,_)| *n==name).unwrap().1.clone();
  let shape_values: Box<[u64]>=if let Data::Matrix(values)=&data {mech_core::shape_for_resolved_extents(schemas.get(port.schema).unwrap(), &[1,values.len() as u64]).unwrap().parameter_values().into()} else {Box::new([])};
  let v=ValueDraft{schema:port.schema,shape_values,data}.finalize(&SnapshotValidationContext::with_shared_schemas(&schemas)).unwrap();
  let mut admission=memory.reserve_capacity(v.memory_budget_admission_bytes(memory).unwrap()).unwrap();v.into_memory_budget(&mut admission).unwrap()
 }).collect()
}
fn main(){let original=source(include_str!("/private/tmp/mech-record-lookup-round42-20261030/linked-acceptance/source.mec"));let decoded=mech_engine::decode_program_artifact_bytecode_v1(&mech_engine::encode_program_artifact_bytecode_v1(&original).unwrap()).unwrap();let mode=NativeProgramLimitMode::NoLimits;let catalog=mech_stdlib::source_catalog();let mut receipts=Vec::new();for artifact in [original,decoded]{
 // SAFETY: this exact same-build Object and unchanged image are pinned before link; entry and identity live throughout execution.
 let jit=unsafe{mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("/private/tmp/mech-record-lookup-round42-20261030/linked-acceptance/descriptor.json"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();let memory=mode.memory_budget();let mut published=vec![None;artifact.outputs().len()];
 for (word,number,flag,signed,ratio,left,allowed,divisor,empty,expected,error) in [(3u8,2u64,true,-2i64,1.5f64,2u64,true,1u64,false,Some(36u64),None),(11,20,false,2,0.5,3,true,2,false,Some(30),None),(3,2,true,-2,1.5,2,false,0,true,None,Some("Integrity")),(3,2,true,-2,1.5,2,true,1,true,None,Some("Library")),(3,2,true,-2,1.5,2,true,0,false,None,Some("Arithmetic")),(5,2,false,0,2.5,1,true,1,false,Some(17),None)]{
  let args=import(&artifact,&[("xs".into(),Data::Matrix(if empty{vec![]}else{vec![Data::U8(word)]}.into())),("number".into(),Data::U64(number)),("flag".into(),Data::Bool(flag)),("signed".into(),Data::I64(signed)),("ratio".into(),Data::F64(mech_core::snapshot::F64Bits::from_f64(ratio))),("left".into(),Data::U64(left)),("allowed".into(),Data::Bool(allowed)),("divisor".into(),Data::U64(divisor))],&memory);let aliases=args.clone();let before=args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>();let prior=published.clone();let retained=(memory.used_bytes(),memory.retained_snapshot_nodes());
  let result=jit.evaluate_into(&args,&mut published,mode.execution(),&memory);
  if let Some(expected)=expected{let report=result.unwrap();assert_eq!(published[0].as_ref().unwrap().canonical_data_draft().unwrap(),Data::U64(expected));receipts.push(serde_json::json!({"generated_success":expected,"work":report.work}));}else{let error_text=format!("{:?}",result.unwrap_err());assert!(error_text.contains(error.unwrap()),"{error_text}");assert!(published.iter().zip(&prior).all(|(a,b)|a.as_ref().unwrap().shares_frozen_storage(b.as_ref().unwrap())));assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),retained);receipts.push(serde_json::json!({"generated_failure":error_text}));}
  assert_eq!(args.iter().map(|v|v.canonical_data_draft().unwrap()).collect::<Vec<_>>(),before);assert!(args.iter().zip(&aliases).all(|(a,b)|a.shares_frozen_storage(b)));
 }
 drop(published);assert_eq!((memory.used_bytes(),memory.retained_snapshot_nodes()),(0,0));
}
println!("{}",serde_json::to_string_pretty(&receipts).unwrap());}
