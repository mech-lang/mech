from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'unit-qualification-safe';p.mkdir(exist_ok=False)
u=r/'green-safe/gpu-unit-tests'
for label,cmd,count in [('runtime',[str(u),'native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map','--nocapture','--test-threads=1'],314),('work-values',[str(u),'native_artifact::work::','native_artifact::memory::','native_artifact::values::','--nocapture','--test-threads=1'],31)]:
 at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 receipt={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':'03bfd07f5e9ea719fa375c6c1c101fb01438efbd'}
 m=re.search(r'test result: ok. (\d+) passed; 0 failed;', (p/(label+'.stdout')).read_text());receipt['executed_tests']=int(m[1]) if m else None
 (p/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'unit-safe-'+label,str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/(label+'.json')),str(r/'prepare.py')],cwd=w,check=True)
 print(label,q.returncode,receipt['executed_tests'],flush=True)
 if q.returncode:print((p/(label+'.stdout')).read_text()[-3000:],flush=True)
 assert q.returncode==0 and receipt['executed_tests']==count
subprocess.run(['python3',str(r/'build.py')],cwd=w,check=True)
subprocess.run(['python3',str(r/'archive.py'),'release-build',str(r/'final-release.json'),str(r/'final-release.log'),str(r/'final-release.stderr'),str(r/'final-libraries.json'),str(r/'build.py')],cwd=w,check=True)
