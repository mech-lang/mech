from pathlib import Path
import json,os,subprocess,time,sys
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-scalar-child-round39-20261030')
phase=sys.argv[1];p=r/phase;p.mkdir(exist_ok=False)
def run(name,cmd,env=None,expect=0):
 at=time.monotonic()
 with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**(env or {})},stdout=out,stderr=err)
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':env or {},'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2)+'\n')
 print(name,q.returncode,flush=True)
 print((p/(name+'.stderr')).read_text()[-2400:]+(p/(name+'.stdout')).read_text()[-2400:],flush=True)
 assert q.returncode==expect,(name,q.returncode)
b=json.loads((old/'unit/build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'gpu-unit-tests');run('unit-build',cmd,b['environment'])
run('unit',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::maps::admission_tests::scalar_aggregates::ordinary_aggregate_groups_keep_current_words_origins_fallback_and_retry','--exact','--nocapture','--test-threads=1'],expect=101 if phase=='red' else 0)
subprocess.run(['python3',str(r/'archive.py'),phase+'-unit',str(p/'unit-build.json'),str(p/'unit-build.stdout'),str(p/'unit-build.stderr'),str(p/'unit.json'),str(p/'unit.stdout'),str(p/'unit.stderr'),str(r/'test.py')],cwd=w,check=True)
