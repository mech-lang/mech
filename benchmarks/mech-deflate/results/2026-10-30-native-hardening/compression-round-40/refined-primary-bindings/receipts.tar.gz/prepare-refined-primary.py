from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;root=r/'refined-primary';root.mkdir(exist_ok=False)
for label,source in [('baseline',r/'linked-primary/before'),('initial',r/'linked-primary/after'),('refined',r/'refined/linked-primary/after')]:
 p=root/label;p.mkdir();binding=json.loads((source/'binding.json').read_text());assert hashlib.sha256((source/'worker').read_bytes()).hexdigest()==binding['worker_sha256']
 for name in ['object.o','descriptor.json','metadata.json','worker','worker.rs','worker-build.json','binding.json']:os.link(source/name,p/name)
files=[p/name for p in root.iterdir() if p.is_dir() for name in ['metadata.json','binding.json','worker.rs','worker-build.json']]
subprocess.run(['python3',str(r/'archive.py'),'refined-primary-bindings',*map(str,files),str(r/'prepare-refined-primary.py')],check=True)
