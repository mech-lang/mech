from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-scalar-child-round39-20261030');root=r/'linked-primary';root.mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
artifact=Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc')
assert digest(artifact)=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
assert digest(artifact.with_suffix('.mec'))=='331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9'
worker_source=(old/'workers/session.rs').read_text();needle='let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();';assert worker_source.count(needle)==1
before=root/'before';before.mkdir();frozen=old/'linked-primary/initial';binding=json.loads((frozen/'binding.json').read_text())
assert digest(frozen/'worker')==binding['worker_sha256']
for name,pin in binding['pins'].items():assert digest(frozen/name)==pin['sha256']
for lib in binding['libraries'].values():assert digest(Path(lib['path']))==lib['sha256']
for name in ['object.o','descriptor.json','metadata.json','worker','worker.rs','worker-build.json','binding.json']:shutil.copy2(frozen/name,before/name)
libs=json.loads((r/'final-libraries.json').read_text());revision=json.loads((r/'final-release.json').read_text())['head'];base=json.loads((old/'primary/current-build.json').read_text());base['libraries']=libs
for i,a in enumerate(base['command']):
 if i and base['command'][i-1]=='--extern':key=a.split('=')[0];base['command'][i]=key+'='+libs[key]['path']
p=root/'after';p.mkdir()
def command(name,cmd):
 at=time.monotonic()
 with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'compiler_source':revision,'libraries':libs},indent=2)+'\n')
 if q.returncode:print((p/(name+'.stderr')).read_text()[-3000:],flush=True)
 q.check_returncode();print(name,'COMPLETE',flush=True)
source=Path('/private/tmp/mech-retirement-round36-20261030/object/inspect.rs').read_text().replace('/private/tmp/mech-retirement-round36-20261030/object',str(p));(p/'inspect.rs').write_text(source)
cmd=base['command'].copy();cmd[-3]=str(p/'inspect.rs');cmd[-1]=str(p/'inspect');command('object-build',cmd);command('emit',[str(p/'inspect')])
meta=json.loads((p/'metadata.json').read_text());identity=meta['identity_symbol'];entry=meta['entry_symbol'];pins={name:{'sha256':digest(p/name),'bytes':(p/name).stat().st_size} for name in ['object.o','descriptor.json','metadata.json']}
prefix='unsafe extern "C" {\n #[link_name="'+identity+'"] static LINKED_IDENTITY:[u8;mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES];\n #[link_name="'+entry+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64;\n}\n'
replacement='// SAFETY: the build pins this SAME unchanged emitted Object, image, bytecode and compiler libraries before link; symbols have program lifetime.\n let jit=unsafe {mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(include_bytes!("'+str(p/'descriptor.json')+'"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();'
source=prefix+worker_source.replace(needle,replacement).replace('"phase":"compiled"','"phase":"linked-compressor-image-restored"');(p/'worker.rs').write_text(source)
normalize=lambda source,ident,image:source.replace(ident,'<IDENTITY>').replace(str(image),'<IMAGE>')
assert normalize(source,identity,p/'descriptor.json')==normalize((before/'worker.rs').read_text(),json.loads((before/'metadata.json').read_text())['identity_symbol'],frozen/'descriptor.json')
cmd=base['command'].copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker');cmd[-3:-3]=['-C','link-arg='+str(p/'object.o')];command('worker-build',cmd)
command('smoke',[str(p/'worker'),str(artifact),'0']);rows=[json.loads(line) for line in (p/'smoke.stdout').read_text().splitlines() if line.startswith('{')]
assert len(rows)==2 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 for x in rows) and rows[0]['work']==rows[1]['work'] and rows[0]['work']>0
assert (p/'smoke.stderr').read_text().endswith('CLEANUP bytes=0 nodes=0\n')
(p/'binding.json').write_text(json.dumps({'compiler_source':revision,'expected_work':rows[0]['work'],'pins':pins,'worker_sha256':digest(p/'worker'),'worker_source_sha256':digest(p/'worker.rs'),'original_worker_sha256':digest(old/'workers/session.rs'),'normalized_source_sha256':hashlib.sha256(normalize(source,identity,p/'descriptor.json').encode()).hexdigest(),'libraries':libs,'scope':'Same matched linked-compressor configuration as prior round. Before is the frozen retained version, after uses current same-build Object/image/libraries. Only image path/identity binding differ in worker source. Original timer, source, bytecode, buffers, allocator and output reuse unchanged.'},indent=2)+'\n')
command('sections',['xcrun','size','-m',str(p/'object.o')])
for label in ['before','after']:
 p=root/label;files=[f for f in p.iterdir() if f.is_file() and f.name not in {'object.o','descriptor.json','inspect','worker'}]
 subprocess.run(['python3',str(r/'archive.py'),'linked-build-'+label,*map(str,files),str(r/'linked-build.py')],cwd=w,check=True)
p=r/'primary';p.mkdir()
for label,source,revision in [('before',old/'primary/frame-after','552e537fcbcfc3811ce442c982010b5e1e999e6c'),('after',Path('/private/tmp/mech-live-control-target/release/native_frame_transport'),revision)]:
 shutil.copy2(source,p/('frame-'+label));(p/('frame-'+label+'.json')).write_text(json.dumps({'path':str(source),'sha256':digest(p/('frame-'+label)),'compiler_source':revision},indent=2)+'\n')
print('READY',rows[0]['work'],flush=True)
