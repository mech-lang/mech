from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-scalar-child-round39-20261030');p=r/'red-component';p.mkdir(exist_ok=False)
b=json.loads((old/'qualification-initial/component-build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'tests')
for name,cmd,expected in [('build',cmd,0),('run',[str(p/'tests'),'optimal_path_qualification::path_match_search_groups_existing_private_scalar_aggregate_steps','--exact','--nocapture','--test-threads=1'],101)]:
 at=time.monotonic()
 with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**b['environment']},stdout=out,stderr=err)
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':b['environment'],'frozen_compiler_source':'552e537fcbcfc3811ce442c982010b5e1e999e6c'},indent=2)+'\n');print(name,q.returncode,flush=True);print((p/(name+'.stderr')).read_text()[-1800:]+(p/(name+'.stdout')).read_text()[-1800:],flush=True);assert q.returncode==expected
subprocess.run(['python3',str(r/'archive.py'),'red-component',str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(p/'run.json'),str(p/'run.stdout'),str(p/'run.stderr'),str(r/'red-component.py')],cwd=w,check=True)
