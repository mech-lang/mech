use mech_gpu::native_artifact::NativeProgramDescriptor;
fn main(){
 let catalog=mech_stdlib::source_catalog();
 // SAFETY: the immutable image and this exact retained optimized library graph
 // are the same R55 build. This inspector neither creates nor executes an entry.
 let descriptor=unsafe {NativeProgramDescriptor::decode_build_owned_image(include_bytes!("/private/tmp/mech-registration-locks-round55-20261031/linked-primary/after/descriptor.json"),&catalog)}.unwrap();
 let plan=descriptor.plan();let facts=plan.facts();let buffers=facts.unsigned_buffer_calls();let frames=facts.buffer_frames();
 let mut rows=Vec::new();
 for (site,proof) in buffers.iter().enumerate(){let Some(proof)=proof else{continue};
  let block=&plan.blocks()[site];let mech_engine::native_artifact::NativeIterationAction::LibraryCall{template,operands,..}=block.action() else{unreachable!()};
  if !matches!(template.primitive(),mech_engine::native_artifact::NativeCollectionPrimitive::SequenceAppend|mech_engine::native_artifact::NativeCollectionPrimitive::SequenceClear|mech_engine::native_artifact::NativeCollectionPrimitive::SequenceWithCapacity){continue;}
  let is_u64=proof.source().is_some_and(|v|format!("{:?}",plan.values()[v.get() as usize].definition()).contains("W64"));
  if !is_u64 && !operands.iter().any(|v|plan.constants().iter().any(|c|c.value()==*v && matches!(c.constant().data(),mech_core::ValueData::U64(305257)))){continue;}
  rows.push(serde_json::json!({"site":site,"origin":format!("{:?}",block.origin()),"iteration":block.iteration(),"operation":format!("{:?}",template.primitive()),"source":proof.source().map(|v|v.get()),"source_future_read":proof.source().map(|v|facts.old_value_has_future_reads(v,site as u32)),"owned_source_slots":proof.owned_source_slots().iter().map(|v|v.get()).collect::<Vec<_>>(),"frame_action":format!("{:?}",frames.action(site))}));
 }
 println!("{}",serde_json::to_string_pretty(&rows).unwrap());
}
