from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
jobs=[('allocation-regression.py',['after']),('core-tests.py',[]),('linked-build.py',['after']),('run-primary.py',[]),('counters.py',[]),('sites-after.py',[]),('profile-isolated.py',[]),('profile-reference.py',[]),('finish-qualification.py',[])]
for name,args in jobs:
 print('START',name,flush=True)
 subprocess.run(['python3',str(r/name),*args],check=True)
 print('DONE',name,flush=True)
