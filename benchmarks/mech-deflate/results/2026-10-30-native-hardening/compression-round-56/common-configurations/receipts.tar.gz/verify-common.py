from pathlib import Path
import collections,hashlib,json
r=Path(__file__).resolve().parent
old=Path('/private/tmp/mech-registration-locks-round55-20261031/variants/after/common-all.json')
before=json.loads(old.read_text())
rows=[json.loads(x) for x in (r/'variants/after/cargo.log').read_text().splitlines() if x.startswith('{')]
def signature(x):return {k:x[k] for k in ['name','package','kind','features','profile','filenames']}
full=[]
for x in rows:
 if x.get('reason')!='compiler-artifact' or x['target']['name'].startswith('mech_') or x['target']['kind']==['bin']:continue
 full.append({'name':x['target']['name'],'package':x['package_id'],'kind':x['target']['kind'],'features':x['features'],'profile':x['profile'],'filenames':[Path(f).name for f in x['filenames']],'fresh':x['fresh'],'artifacts':{Path(f).name:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in x['filenames']}})
assert collections.Counter(json.dumps(signature(x),sort_keys=True) for x in before)==collections.Counter(json.dumps(signature(x),sort_keys=True) for x in full)
for x in before:assert any(signature(x)==signature(y) and x['artifacts']==y['artifacts'] for y in full),x['name']
(r/'variants/after/common-all.json').write_text(json.dumps(full,indent=2)+'\n')
(r/'variants/after/common-comparison.json').write_text(json.dumps({'before_configurations':len(before),'after_configurations':len(full),'all_configuration_signatures_and_artifact_hashes_match':True},indent=2)+'\n')
print('MATCHED COMMON CONFIGURATIONS',len(full),flush=True)
