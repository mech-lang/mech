from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'architecture-final';p.mkdir(exist_ok=True)
old=json.loads(Path('/private/tmp/mech-action-retirement-round37-20261030/architecture/results.json').read_text());results=[]
for index,entry in enumerate(old):
 cmd=entry['command'];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(p/(str(index)+'.stdout')).write_text(q.stdout);(p/(str(index)+'.stderr')).write_text(q.stderr);results.append({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at});(p/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(index,q.returncode,flush=True)
 if q.returncode:print(q.stdout[-2500:]);print(q.stderr[-2500:])
assert all(x['exit']==0 for x in results)
subprocess.run(['python3',str(r/'archive.py'),'architecture-final',str(p),str(r/'final-architecture.py')],cwd=w,check=True)
