from pathlib import Path
import json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'final-constructor-ci';p.mkdir()
for label,cmd,expected in [('constructor-list',[str(r/'allocation-after-recovery/tests'),'--list'],4),('constructor-execute',[str(r/'allocation-after-recovery/tests'),'--nocapture','--test-threads=1'],4)]:
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 count=len(re.findall(': test$',q.stdout,re.M)) if label.endswith('list') else int(re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout)[1]) if q.returncode==0 else None
 (p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'listed_tests' if label.endswith('list') else 'executed_tests':count,'profile':'Same local selected Core feature configuration and opt1 unit / opt3 constructor binaries; hosted all-features execution not claimed.'},indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'final-'+label,*map(str,[p/(label+'.json'),p/(label+'.stdout'),p/(label+'.stderr'),r/'final-constructor-ci.py'])],cwd=w,check=True);q.check_returncode();assert count==expected;print(label,count,flush=True)
