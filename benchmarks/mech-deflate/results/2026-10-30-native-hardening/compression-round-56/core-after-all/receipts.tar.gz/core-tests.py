from pathlib import Path
import json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'core-after';p.mkdir();base=json.loads(Path('/private/tmp/mech-unique-admission-round48-20261031/core-after/build.json').read_text());cmd=base['command'].copy();cmd[-1]=str(p/'core-unit-tests')
for name,args in [('build',cmd),('all',[str(p/'core-unit-tests'),'--nocapture','--test-threads=1'])]:
 at=time.monotonic();q=subprocess.run(args,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 match=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row={'command':args,'environment':base['environment'],'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'exit':q.returncode,'seconds':time.monotonic()-at,'executed_tests':int(match[1]) if match else None}
 (p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'core-after-'+name,*map(str,[p/(name+'.json'),p/(name+'.stdout'),p/(name+'.stderr'),r/'core-tests.py'])],cwd=w,check=True)
 print(name,q.returncode,row['executed_tests'],flush=True)
 if q.returncode:print(q.stdout[-4000:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if name=='all':assert row['executed_tests']==364
