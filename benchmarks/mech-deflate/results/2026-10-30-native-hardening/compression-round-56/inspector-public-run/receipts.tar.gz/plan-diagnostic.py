from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');base=json.loads(Path('/private/tmp/mech-registration-locks-round55-20261031/linked-primary/after/worker-build.json').read_text());cmd=base['command'].copy()
indices=[i for i,x in enumerate(cmd) if x.startswith('link-arg=') and x.endswith('/object.o')];assert len(indices)==1;i=indices[0];assert cmd[i-1]=='-C';del cmd[i-1:i+1];cmd[-3]=str(r/'inspect.rs');cmd[-1]=str(r/'inspect')
for name,args in [('build',cmd),('run',[str(r/'inspect')])]:
 t=time.monotonic();q=subprocess.run(args,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(r/('public-inspect-'+name+'.'+stream)).write_text(getattr(q,stream))
 (r/('public-inspect-'+name+'.json')).write_text(json.dumps({'command':args,'exit':q.returncode,'seconds':time.monotonic()-t,'libraries':base['libraries'],'source_head':base['compiler_source'],'scope':'Read-only restored-plan diagnostic. No compression or timed performance observations.'},indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'inspector-public-'+name,str(r/'inspect.rs'),str(r/'plan-diagnostic.py'),*[str(r/('public-inspect-'+name+'.'+s)) for s in ['json','stdout','stderr']]],cwd=w,check=True)
 if q.returncode:print(q.stderr,flush=True)
 q.check_returncode()
 if name=='run':print(q.stdout,flush=True)
