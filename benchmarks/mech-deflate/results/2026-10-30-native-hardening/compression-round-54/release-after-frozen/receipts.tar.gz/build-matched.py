from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];p=r/'variants'/phase;p.mkdir(parents=True)
old=Path('/private/tmp/mech-frame-transfer-round53-20261031');settings=json.loads(Path('/private/tmp/mech-record-prefix-round46-20261031/cargo-release.json').read_text());previous=json.loads((old/'final-libraries.json').read_text())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
cmd=settings['command'];env=settings['environment'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();at=time.monotonic()
with (p/'cargo.log').open('w') as out,(p/'cargo.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**env},stdout=out,stderr=err)
receipt={'command':cmd,'environment':env,'cwd':str(w),'source_head':head,'exit':q.returncode,'seconds':time.monotonic()-at,'profile':'Unchanged selected-operation release manifest/features/profile, opt3 WAE, offline locked single job. Both variants freshly rebuilt against identical common dependencies.'};(p/'cargo.json').write_text(json.dumps(receipt,indent=2)+'\n');print('CARGO',phase,q.returncode,receipt['seconds'],flush=True)
subprocess.run(['python3',str(r/'archive.py'),'release-'+phase+'-cargo',str(p/'cargo.json'),str(p/'cargo.log'),str(p/'cargo.stderr'),str(r/'build-matched.py')],cwd=w,check=True)
if q.returncode:print((p/'cargo.stderr').read_text()[-6000:],flush=True)
q.check_returncode();rows=[json.loads(x) for x in (p/'cargo.log').read_text().splitlines() if x.startswith('{')];assert rows[-1]=={'reason':'build-finished','success':True}
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();common={};libs={};pins=[];d=p/'dependency';d.mkdir()
for row in rows:
 if row.get('reason')!='compiler-artifact':continue
 name=row['target']['name']
 if not name.startswith('mech_') and row['target']['kind'] not in [['bin']]:
  common[name]={'features':row['features'],'profile':row['profile'],'artifacts':{Path(f).name:sha(f) for f in row['filenames']}}
 if name.startswith('mech_'):
  for f in map(Path,row['filenames']):
   if f.suffix not in {'.rlib','.rmeta'}:continue
   target=d/f.name;shutil.copy2(f,target);pins.append({'path':str(target),'sha256':sha(target),'bytes':target.stat().st_size})
 if name in previous:
  fs=[Path(f) for f in row['filenames'] if f.endswith('.rlib')];assert len(fs)==1
  target=d/fs[0].name if name.startswith('mech_') else fs[0]
  if not name.startswith('mech_'):target=d/fs[0].name;shutil.copy2(fs[0],target)
  libs[name]={'path':str(target),'sha256':sha(target),'features':row['features'],'profile':row['profile']}
  assert libs[name]['features']==previous[name]['features'] and libs[name]['profile']==previous[name]['profile'],name
assert len(libs)==8
(p/'common.json').write_text(json.dumps(common,indent=2)+'\n')
if phase=='after':assert common==json.loads((r/'variants/before/common.json').read_text()),'unrelated dependencies changed'
(p/'libraries.json').write_text(json.dumps(libs,indent=2)+'\n');aux={'scope':'Freeze every selected Core-dependent transitive artifact before another Core rebuild. Mutable Cargo outputs are copied, never hardlinked.','files':pins};(p/'auxiliary.json').write_text(json.dumps(aux,indent=2)+'\n')
# Match the retained host's direct rustc flags; only exact dependencies change.
b=json.loads((old/'final-release.json').read_text());cmd=b['command'].copy()
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  key=a.split('=')[0]
  if key in libs:cmd[i]=key+'='+libs[key]['path']
  elif key.startswith('mech_'):
   f=d/Path(a.split('=',1)[1]).name;assert f.exists(),f;cmd[i]=key+'='+str(f)
 if a.startswith('dependency=') and any(x in a for x in ['/mech-frame-transfer-round53-','/mech-unique-admission-round48-']):cmd[i]='dependency='+str(d)
# Frozen matching transitive graph wins before the mutable Cargo search path.
cmd[1:1]=['-L','dependency='+str(d)];cmd[-1]=str(p/'libmech_gpu.rlib');at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
for stream in ['stdout','stderr']:(p/('host.'+stream)).write_text(getattr(q,stream))
host={'command':cmd,'environment':b['environment'],'cwd':str(w),'source_head':head,'exit':q.returncode,'seconds':time.monotonic()-at,'profile':'Identical retained host flags against exact matching freshly frozen graph.'};(p/'host.json').write_text(json.dumps(host,indent=2)+'\n')
if q.returncode:print(q.stderr[-6000:],flush=True)
q.check_returncode();libs['mech_gpu']={**libs['mech_gpu'],'path':str(p/'libmech_gpu.rlib'),'sha256':sha(p/'libmech_gpu.rlib')};(p/'libraries.json').write_text(json.dumps(libs,indent=2)+'\n')
if phase=='after':
 for source,target in [('libraries.json','final-libraries.json'),('host.json','final-release.json'),('auxiliary.json','auxiliary-dependencies.json')]:shutil.copy2(p/source,r/target)
subprocess.run(['python3',str(r/'archive.py'),'release-'+phase+'-frozen',str(p/'common.json'),str(p/'auxiliary.json'),str(p/'libraries.json'),str(p/'host.json'),str(p/'host.stdout'),str(p/'host.stderr'),str(r/'build-matched.py')],cwd=w,check=True)
print('FROZEN NORMALIZED',phase,host['seconds'],flush=True)
