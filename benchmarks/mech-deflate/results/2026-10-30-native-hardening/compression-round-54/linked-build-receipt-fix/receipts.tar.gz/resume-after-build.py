from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for script,args in [('linked-build.py',['after']),('run-primary.py',[]),('counters.py',[]),('profile-isolated.py',[]),('profile-reference.py',[]),('sites-after.py',[]),('units.py',['after']),('core-integrations.py',[]),('numeric-ci.py',[]),('qualify-all.py',[]),('comparison-witness.py',[])]:
 print('START',script,*args,flush=True);subprocess.run(['python3',str(r/script),*args],check=True)
