from pathlib import Path
import json,os,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');phase=sys.argv[1];p=r/('units-'+phase);p.mkdir();old=Path('/private/tmp/mech-child-cleanup-round50-20261031');b=json.loads((old/'units-layout/build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'gpu-unit-tests');source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
def run(label,command,expected=None):
 t=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**b['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':b['environment'],'exit':q.returncode,'seconds':time.monotonic()-t,'compiler_source':source,'production_dependencies':str(old/'final-libraries.json'),'scope':'Exact retained selected-consumer unit feature flags and frozen Core-dependent graph, opt1 warnings-as-errors. Counter is cfg(test)-only.'}
 m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout)
 if m:row.update(executed_tests=int(m[1])+int(m[2]),passed_tests=int(m[1]),failed_tests=int(m[2]))
 (p/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'unit-'+phase+'-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'units.py')],cwd=w,check=True)
 print(phase,label,q.returncode,row.get('passed_tests'),row.get('failed_tests'),flush=True)
 if expected=='red':
  assert q.returncode!=0 and row.get('passed_tests')==1 and row.get('failed_tests')==2,q.stdout+q.stderr
 else:
  if q.returncode:print(q.stdout[-6000:]+q.stderr[-7000:],flush=True)
  q.check_returncode()
  if expected is not None:assert row['passed_tests']==expected
 return q
run('build',cmd)
q=run('domain',[str(p/'gpu-unit-tests'),'numeric_shadow_tests::','--nocapture','--test-threads=1'],'red' if phase=='before' else 3)
if phase=='before':print(q.stdout[-3000:]+q.stderr[-4000:],flush=True)
