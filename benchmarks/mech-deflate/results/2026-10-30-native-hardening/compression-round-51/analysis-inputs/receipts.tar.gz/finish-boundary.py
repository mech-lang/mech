from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
subprocess.run(['python3',str(r/'units.py'),'boundary'],check=True)
for name in ['ci.py','architecture.py']:
 print('BOUNDARY-REPAIR',name,flush=True)
 subprocess.run(['python3',str(r/name)],check=True)
