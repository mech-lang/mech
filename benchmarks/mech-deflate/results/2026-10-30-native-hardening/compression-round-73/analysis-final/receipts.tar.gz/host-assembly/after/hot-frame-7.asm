
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101533228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>:
101533228:     	stp	x28, x27, [sp, #-0x60]!
10153322c:     	stp	x26, x25, [sp, #0x10]
101533230:     	stp	x24, x23, [sp, #0x20]
101533234:     	stp	x22, x21, [sp, #0x30]
101533238:     	stp	x20, x19, [sp, #0x40]
10153323c:     	stp	x29, x30, [sp, #0x50]
101533240:     	add	x29, sp, #0x50
101533244:     	sub	sp, sp, #0x4c0
101533248:     	str	xzr, [sp]
10153324c:     	ldr	x28, [x1, #0x498]
101533250:     	ldr	x8, [x28, #0x4a0]
101533254:     	cmp	x2, x8
101533258:     	b.hs	0x101533328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x100>
10153325c:     	mov	x22, x5
101533260:     	mov	x23, x4
101533264:     	mov	x20, x2
101533268:     	mov	x21, x1
10153326c:     	add	x27, sp, #0x400
101533270:     	ldr	x8, [x28, #0x498]
101533274:     	mov	w9, #0x28               ; =40
101533278:     	madd	x24, x2, x9, x8
10153327c:     	ldr	w8, [x24]
101533280:     	cmp	w8, #0x1
101533284:     	b.gt	0x10153330c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe4>
101533288:     	cbnz	w8, 0x10153333c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x114>
10153328c:     	cbnz	x3, 0x1015333b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x18c>
101533290:     	ldr	x1, [x28, #0x380]
101533294:     	cmp	x20, x1
101533298:     	b.hs	0x10153461c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13f4>
10153329c:     	ldr	x8, [x28, #0x378]
1015332a0:     	mov	w9, #0x170              ; =368
1015332a4:     	madd	x8, x20, x9, x8
1015332a8:     	ldp	x10, x9, [x8]
1015332ac:     	cmp	x10, #0x2
1015332b0:     	sbcs	xzr, x9, xzr
1015332b4:     	b.hs	0x1015337c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x598>
1015332b8:     	ldr	w9, [x8, #0x130]
1015332bc:     	ldr	w10, [x24, #0x4]
1015332c0:     	cmp	w9, w10
1015332c4:     	b.ne	0x1015337dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5b4>
1015332c8:     	ldr	x9, [x8, #0x128]
1015332cc:     	cmp	x22, x9
1015332d0:     	b.ne	0x1015337dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5b4>
1015332d4:     	add	x9, x28, #0x488
1015332d8:     	str	x9, [sp, #0x40]
1015332dc:     	str	x24, [sp, #0x78]
1015332e0:     	ldr	x8, [x8, #0x120]
1015332e4:     	stp	x8, x0, [sp, #0x60]
1015332e8:     	lsl	x8, x22, #2
1015332ec:     	str	x8, [sp, #0x20]
1015332f0:     	cbz	x22, 0x1015339e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7bc>
1015332f4:     	mov	x27, #0x0               ; =0
1015332f8:     	mov	x19, #0x0               ; =0
1015332fc:     	ldr	x24, [x21, #0x490]
101533300:     	ldr	x25, [sp, #0x20]
101533304:     	str	x24, [sp, #0x58]
101533308:     	b	0x10153343c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x214>
10153330c:     	cmp	w8, #0x2
101533310:     	b.ne	0x101533328 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x100>
101533314:     	cbz	x3, 0x1015333a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
101533318:     	cmp	x3, #0x12
10153331c:     	b.ne	0x1015333b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x18c>
101533320:     	cbnz	x22, 0x1015333b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x18c>
101533324:     	b	0x101533648 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x420>
101533328:     	mov	w8, #0x2                ; =2
10153332c:     	str	x8, [x0, #0x8]
101533330:     	mov	w8, #0x6                ; =6
101533334:     	str	w8, [x0]
101533338:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
10153333c:     	cmp	x3, #0x1
101533340:     	b.ne	0x1015333b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x18c>
101533344:     	cbnz	x22, 0x1015333b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x18c>
101533348:     	mov	x19, x0
10153334c:     	add	x0, sp, #0x400
101533350:     	mov	x1, x21
101533354:     	mov	x2, x20
101533358:     	bl	0x101546df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
10153335c:     	ldr	w8, [sp, #0x400]
101533360:     	cmp	w8, #0x1
101533364:     	b.ne	0x1015333f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1c8>
101533368:     	ldr	w3, [sp, #0x404]
10153336c:     	ldr	w4, [sp, #0x408]
101533370:     	ldp	w8, w9, [x24, #0x4]
101533374:     	cmp	w3, w8
101533378:     	ccmp	w4, w9, #0x0, eq
10153337c:     	b.eq	0x1015337f8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d0>
101533380:     	str	wzr, [x19]
101533384:     	mov	w8, #0xc                ; =12
101533388:     	strb	w8, [x19, #0x8]
10153338c:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101533390:     	add	x8, x8, #0xfc3
101533394:     	mov	w9, #0x2e               ; =46
101533398:     	stp	x8, x9, [x19, #0x10]
10153339c:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
1015333a0:     	cmp	x22, #0x2
1015333a4:     	b.ne	0x1015333b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x18c>
1015333a8:     	ldp	x9, x8, [x23]
1015333ac:     	orr	x8, x9, x8
1015333b0:     	cbz	x8, 0x101533648 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x420>
1015333b4:     	str	wzr, [x0]
1015333b8:     	mov	w8, #0xc                ; =12
1015333bc:     	strb	w8, [x0, #0x8]
1015333c0:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
1015333c4:     	add	x8, x8, #0xf6
1015333c8:     	mov	w9, #0x34               ; =52
1015333cc:     	stp	x8, x9, [x0, #0x10]
1015333d0:     	add	sp, sp, #0x4c0
1015333d4:     	ldp	x29, x30, [sp, #0x50]
1015333d8:     	ldp	x20, x19, [sp, #0x40]
1015333dc:     	ldp	x22, x21, [sp, #0x30]
1015333e0:     	ldp	x24, x23, [sp, #0x20]
1015333e4:     	ldp	x26, x25, [sp, #0x10]
1015333e8:     	ldp	x28, x27, [sp], #0x60
1015333ec:     	ret
1015333f0:     	str	wzr, [x19]
1015333f4:     	mov	w8, #0xc                ; =12
1015333f8:     	str	w8, [x19, #0x8]
1015333fc:     	adrp	x8, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101533400:     	add	x8, x8, #0x1d9
101533404:     	mov	w9, #0x27               ; =39
101533408:     	stp	x8, x9, [x19, #0x10]
10153340c:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533410:     	ldr	q0, [sp, #0x400]
101533414:     	ldr	q1, [sp, #0x410]
101533418:     	ldr	q2, [sp, #0x420]
10153341c:     	ldr	q3, [sp, #0x430]
101533420:     	stp	q2, q3, [x26, #0x20]
101533424:     	stp	q0, q1, [x26]
101533428:     	add	x27, x27, #0x40
10153342c:     	add	x19, x19, #0x1
101533430:     	subs	x25, x25, #0x4
101533434:     	ldr	x24, [sp, #0x58]
101533438:     	b.eq	0x1015339e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7bc>
10153343c:     	str	x25, [sp, #0x70]
101533440:     	ldr	x1, [x28, #0x360]
101533444:     	ldr	x8, [sp, #0x60]
101533448:     	ldr	w26, [x8, x19, lsl #2]
10153344c:     	cmp	x1, x26
101533450:     	b.ls	0x10153462c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1404>
101533454:     	mov	x25, x19
101533458:     	ldr	x8, [x28, #0x358]
10153345c:     	mov	w9, #0x140              ; =320
101533460:     	umaddl	x8, w26, w9, x8
101533464:     	ldrb	w8, [x8, #0x124]
101533468:     	cmp	w8, #0x7
10153346c:     	b.ne	0x101533598 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x370>
101533470:     	cmp	x25, x22
101533474:     	ldr	x19, [sp, #0x68]
101533478:     	b.hs	0x101534674 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x144c>
10153347c:     	ldr	x8, [x23, x25, lsl #3]
101533480:     	cbnz	x8, 0x101533bb8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x990>
101533484:     	ldr	x8, [x28, #0x490]
101533488:     	cmp	x8, x26
10153348c:     	b.ls	0x1015334c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x29c>
101533490:     	ldr	x8, [sp, #0x40]
101533494:     	ldr	x8, [x8]
101533498:     	mov	w9, #0x18               ; =24
10153349c:     	umaddl	x8, w26, w9, x8
1015334a0:     	ldr	x9, [x8]
1015334a4:     	cmp	x9, #0x1
1015334a8:     	b.ne	0x1015334c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x29c>
1015334ac:     	ldp	x8, x9, [x8, #0x8]
1015334b0:     	adds	x8, x8, x9
1015334b4:     	b.hs	0x1015334c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x29c>
1015334b8:     	ldr	x9, [x28, #0x4b0]
1015334bc:     	cmp	x8, x9
1015334c0:     	b.ls	0x1015335c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x398>
1015334c4:     	ldr	x8, [x24, #0x100]
1015334c8:     	ldr	x9, [x24, #0x2f8]
1015334cc:     	cmp	x9, x8
1015334d0:     	b.ne	0x101533bd4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9ac>
1015334d4:     	ldr	x8, [x24, #0x318]
1015334d8:     	cbz	x8, 0x1015334e8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2c0>
1015334dc:     	ldr	x9, [x24, #0x108]
1015334e0:     	cmp	x8, x9
1015334e4:     	b.ne	0x101533bdc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9b4>
1015334e8:     	add	x0, sp, #0x2f0
1015334ec:     	add	x1, x24, #0x2f8
1015334f0:     	mov	w2, #0x0                ; =0
1015334f4:     	mov	w4, #0x20               ; =32
1015334f8:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015334fc:     	ldrb	w8, [sp, #0x2f0]
101533500:     	cmp	w8, #0xe
101533504:     	b.ne	0x101533c04 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9dc>
101533508:     	ldr	x8, [x24, #0x130]
10153350c:     	cmp	x8, x26
101533510:     	b.ls	0x101533b9c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x974>
101533514:     	ldr	x8, [x24, #0x128]
101533518:     	add	x9, x8, x26, lsl #6
10153351c:     	ldr	x8, [x9]
101533520:     	cbz	x8, 0x101533b9c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x974>
101533524:     	ldr	w10, [x9, #0x38]
101533528:     	str	w10, [sp, #0x54]
10153352c:     	mov	w12, #0x1               ; =1
101533530:     	ldadd	x12, x10, [x8]
101533534:     	tbnz	x10, #0x3f, 0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
101533538:     	ldr	x11, [x9, #0x8]
10153353c:     	ldadd	x12, x10, [x11]
101533540:     	tbnz	x10, #0x3f, 0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
101533544:     	str	x11, [sp, #0x48]
101533548:     	ldr	x11, [x9, #0x30]
10153354c:     	cbz	x11, 0x101533558 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x330>
101533550:     	ldadd	x12, x10, [x11]
101533554:     	tbnz	x10, #0x3f, 0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
101533558:     	mov	w26, #0x0               ; =0
10153355c:     	ldp	x10, x12, [x9, #0x10]
101533560:     	ldr	q0, [x9, #0x20]
101533564:     	add	x9, sp, #0x400
101533568:     	stur	q0, [x9, #0x20]
10153356c:     	str	x8, [sp, #0x400]
101533570:     	ldr	x8, [sp, #0x48]
101533574:     	str	x8, [sp, #0x408]
101533578:     	stp	x12, x10, [sp, #0x28]
10153357c:     	str	x10, [sp, #0x410]
101533580:     	str	x12, [sp, #0x418]
101533584:     	str	x11, [sp, #0x38]
101533588:     	str	x11, [sp, #0x430]
10153358c:     	ldr	w8, [sp, #0x54]
101533590:     	str	w8, [sp, #0x438]
101533594:     	b	0x1015335c8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3a0>
101533598:     	cmp	x25, x22
10153359c:     	ldr	x11, [sp, #0x68]
1015335a0:     	b.hs	0x101534660 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1438>
1015335a4:     	ldr	x9, [x23, x25, lsl #3]
1015335a8:     	cmp	w8, #0x3
1015335ac:     	b.gt	0x1015335f8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3d0>
1015335b0:     	sub	w8, w8, #0x1
1015335b4:     	cmp	w8, #0x3
1015335b8:     	ccmp	x9, #0x2, #0x0, hs
1015335bc:     	b.hs	0x101533628 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x400>
1015335c0:     	str	xzr, [sp, #0x400]
1015335c4:     	mov	w26, #0x1               ; =1
1015335c8:     	ldr	x1, [x24, #0xd8]
1015335cc:     	mov	x19, x25
1015335d0:     	cmp	x25, x1
1015335d4:     	b.hs	0x10153463c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1414>
1015335d8:     	ldr	x24, [x24, #0xd0]
1015335dc:     	add	x26, x24, x27
1015335e0:     	ldr	x8, [x26]
1015335e4:     	ldr	x25, [sp, #0x70]
1015335e8:     	cbz	x8, 0x101533410 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1e8>
1015335ec:     	add	x0, x24, x27
1015335f0:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015335f4:     	b	0x101533410 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1e8>
1015335f8:     	cmp	w8, #0x4
1015335fc:     	b.eq	0x101533614 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3ec>
101533600:     	cmp	w8, #0x5
101533604:     	b.ne	0x101533620 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3f8>
101533608:     	cmp	x9, #0x10, lsl #12      ; =0x10000
10153360c:     	b.lo	0x1015335c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x398>
101533610:     	b	0x101533628 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x400>
101533614:     	cmp	x9, #0xff
101533618:     	b.ls	0x1015335c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x398>
10153361c:     	b	0x101533628 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x400>
101533620:     	lsr	x8, x9, #32
101533624:     	cbz	x8, 0x1015335c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x398>
101533628:     	str	wzr, [x11]
10153362c:     	mov	w8, #0xc                ; =12
101533630:     	strb	w8, [x11, #0x8]
101533634:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101533638:     	add	x8, x8, #0xf4f
10153363c:     	mov	w9, #0x2a               ; =42
101533640:     	stp	x8, x9, [x11, #0x10]
101533644:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533648:     	ldr	x1, [x28, #0x380]
10153364c:     	cmp	x20, x1
101533650:     	b.hs	0x101534650 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1428>
101533654:     	str	x24, [sp, #0x78]
101533658:     	ldr	x8, [x28, #0x378]
10153365c:     	mov	w9, #0x170              ; =368
101533660:     	madd	x27, x20, x9, x8
101533664:     	cbz	x3, 0x101533930 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x708>
101533668:     	cmp	x3, #0x12
10153366c:     	b.ne	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
101533670:     	ldp	x9, x8, [x27]
101533674:     	eor	x9, x9, #0x3
101533678:     	orr	x8, x9, x8
10153367c:     	cbnz	x8, 0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
101533680:     	ldr	w22, [x27, #0x28]
101533684:     	ldr	x8, [sp, #0x78]
101533688:     	ldr	w8, [x8, #0x4]
10153368c:     	cmp	w22, w8
101533690:     	b.ne	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
101533694:     	ldr	w25, [x27, #0x2c]
101533698:     	ldr	x8, [sp, #0x78]
10153369c:     	ldr	w8, [x8, #0x8]
1015336a0:     	cmp	w25, w8
1015336a4:     	b.ne	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
1015336a8:     	mov	x19, x0
1015336ac:     	mov	x26, #0x0               ; =0
1015336b0:     	mov	w23, #0x3               ; =3
1015336b4:     	add	x0, x28, #0x488
1015336b8:     	mov	x1, x22
1015336bc:     	bl	0x101546d3c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
1015336c0:     	cbz	x0, 0x101533998 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x770>
1015336c4:     	ldr	x8, [sp, #0x78]
1015336c8:     	ldr	x24, [x8, #0x10]
1015336cc:     	cmp	x24, x1
1015336d0:     	b.hs	0x101533998 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x770>
1015336d4:     	add	x8, x0, x24, lsl #5
1015336d8:     	ldrb	w9, [x8]
1015336dc:     	cmp	w9, #0x2
1015336e0:     	b.ne	0x101533dd8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xbb0>
1015336e4:     	ldp	x8, x9, [x8, #0x8]
1015336e8:     	adds	x8, x8, x9
1015336ec:     	b.hs	0x101533dd8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xbb0>
1015336f0:     	ldr	x9, [x28, #0x4b0]
1015336f4:     	cmp	x8, x9
1015336f8:     	b.hi	0x101533dd8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xbb0>
1015336fc:     	cmp	x23, #0x2
101533700:     	sbcs	xzr, x26, xzr
101533704:     	b.hs	0x101533f3c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd14>
101533708:     	ldr	x1, [x27, #0x128]
10153370c:     	cmp	x1, #0x1
101533710:     	b.ls	0x1015346f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14c8>
101533714:     	ldr	x8, [x27, #0x120]
101533718:     	ldr	x26, [x21, #0x490]
10153371c:     	ldr	w1, [x8, #0x4]
101533720:     	add	x8, sp, #0x400
101533724:     	add	x0, x26, #0xf0
101533728:     	add	x2, x26, #0x2f8
10153372c:     	bl	0x10154fa14 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101533730:     	add	x8, sp, #0x400
101533734:     	ldur	q0, [x8, #0x8]
101533738:     	ldur	q1, [x8, #0x18]
10153373c:     	stp	q0, q1, [sp, #0x150]
101533740:     	ldur	q0, [x8, #0x28]
101533744:     	str	q0, [sp, #0x170]
101533748:     	ldr	x8, [sp, #0x400]
10153374c:     	ldr	x9, [sp, #0x438]
101533750:     	str	x9, [sp, #0x180]
101533754:     	cbz	x8, 0x101534038 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe10>
101533758:     	ldp	q0, q1, [sp, #0x150]
10153375c:     	add	x9, sp, #0x230
101533760:     	stur	q0, [x9, #0x48]
101533764:     	stur	q1, [x9, #0x58]
101533768:     	ldr	q0, [sp, #0x170]
10153376c:     	stur	q0, [x9, #0x68]
101533770:     	ldr	x9, [sp, #0x180]
101533774:     	str	x9, [sp, #0x2a8]
101533778:     	str	x8, [sp, #0x270]
10153377c:     	ldr	x1, [x28, #0x408]
101533780:     	cmp	x20, x1
101533784:     	b.hs	0x101534714 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14ec>
101533788:     	ldr	x8, [x28, #0x400]
10153378c:     	add	x23, x8, x20, lsl #9
101533790:     	ldp	x9, x8, [x23]
101533794:     	eor	x9, x9, #0x2
101533798:     	orr	x8, x9, x8
10153379c:     	cbnz	x8, 0x101534084 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe5c>
1015337a0:     	str	wzr, [x19]
1015337a4:     	mov	w8, #0xc                ; =12
1015337a8:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
1015337ac:     	add	x9, x9, #0x220
1015337b0:     	stp	x8, x9, [x19, #0x8]
1015337b4:     	mov	w8, #0x23               ; =35
1015337b8:     	str	x8, [x19, #0x18]
1015337bc:     	b	0x1015344fc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015337c0:     	str	wzr, [x0]
1015337c4:     	mov	w8, #0xc                ; =12
1015337c8:     	strb	w8, [x0, #0x8]
1015337cc:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
1015337d0:     	add	x8, x8, #0xf9b
1015337d4:     	mov	w9, #0x28               ; =40
1015337d8:     	b	0x1015333cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a4>
1015337dc:     	str	wzr, [x0]
1015337e0:     	mov	w8, #0xc                ; =12
1015337e4:     	strb	w8, [x0, #0x8]
1015337e8:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
1015337ec:     	add	x8, x8, #0xf79
1015337f0:     	mov	w9, #0x22               ; =34
1015337f4:     	b	0x1015333cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a4>
1015337f8:     	ldp	x8, x9, [x24, #0x18]
1015337fc:     	lsl	x9, x9, #2
101533800:     	str	x24, [sp, #0x78]
101533804:     	cbz	x9, 0x101533834 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x60c>
101533808:     	ldr	w10, [x8], #0x4
10153380c:     	sub	x9, x9, #0x4
101533810:     	cmp	w10, w3
101533814:     	b.ne	0x101533804 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5dc>
101533818:     	ldr	x26, [x21, #0x490]
10153381c:     	add	x0, sp, #0x400
101533820:     	add	x1, x26, #0x3c0
101533824:     	add	x2, x28, #0x488
101533828:     	add	x5, x26, #0x2f8
10153382c:     	bl	0x101528178 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb1_EBb_>
101533830:     	b	0x10153384c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x624>
101533834:     	ldr	x26, [x21, #0x490]
101533838:     	add	x0, sp, #0x400
10153383c:     	add	x1, x26, #0x3c0
101533840:     	add	x2, x28, #0x488
101533844:     	add	x5, x26, #0x2f8
101533848:     	bl	0x101527ec0 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb0_EBb_>
10153384c:     	ldr	w8, [sp, #0x400]
101533850:     	cmp	w8, #0x6
101533854:     	b.ne	0x101533f78 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd50>
101533858:     	mov	x22, #0x0               ; =0
10153385c:     	ldr	x9, [sp, #0x78]
101533860:     	ldr	x8, [x9, #0x20]
101533864:     	cbz	x8, 0x1015339d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7ac>
101533868:     	ldr	x23, [x9, #0x18]
10153386c:     	lsl	x24, x8, #2
101533870:     	b	0x101533880 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x658>
101533874:     	mov	x19, x25
101533878:     	subs	x24, x24, #0x4
10153387c:     	b.eq	0x1015339d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7ac>
101533880:     	mov	x25, x19
101533884:     	ldr	w20, [x23], #0x4
101533888:     	ldr	x1, [x26, #0x3c0]
10153388c:     	add	x0, sp, #0x400
101533890:     	add	x2, x28, #0x4d0
101533894:     	add	x4, x26, #0x2f8
101533898:     	mov	x3, x20
10153389c:     	bl	0x101532b38 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
1015338a0:     	ldr	w9, [sp, #0x400]
1015338a4:     	ldrb	w8, [sp, #0x404]
1015338a8:     	cmp	w9, #0x6
1015338ac:     	b.ne	0x101533a2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x804>
1015338b0:     	mov	x19, x25
1015338b4:     	tbnz	w8, #0x0, 0x101533878 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x650>
1015338b8:     	add	x8, sp, #0x400
1015338bc:     	add	x0, x26, #0xf0
1015338c0:     	add	x2, x26, #0x2f8
1015338c4:     	mov	x1, x20
1015338c8:     	bl	0x10155049c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
1015338cc:     	ldrb	w8, [sp, #0x400]
1015338d0:     	cmp	w8, #0x14
1015338d4:     	b.eq	0x101533874 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x64c>
1015338d8:     	ldr	q0, [sp, #0x400]
1015338dc:     	ldr	q1, [sp, #0x410]
1015338e0:     	stp	q0, q1, [sp, #0x2f0]
1015338e4:     	ldr	q2, [sp, #0x420]
1015338e8:     	str	q2, [sp, #0x310]
1015338ec:     	ldr	x8, [sp, #0x430]
1015338f0:     	str	x8, [sp, #0x320]
1015338f4:     	stur	q0, [x27, #0x4]
1015338f8:     	stur	q1, [x27, #0x14]
1015338fc:     	stur	q2, [x27, #0x24]
101533900:     	stur	x8, [x27, #0x34]
101533904:     	mov	w8, #0x2                ; =2
101533908:     	str	w8, [x25]
10153390c:     	ldr	q0, [sp, #0x400]
101533910:     	ldr	q1, [sp, #0x410]
101533914:     	stur	q0, [x25, #0x4]
101533918:     	stur	q1, [x25, #0x14]
10153391c:     	ldr	q0, [sp, #0x420]
101533920:     	stur	q0, [x25, #0x24]
101533924:     	ldur	q0, [x27, #0x2c]
101533928:     	str	q0, [x25, #0x30]
10153392c:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533930:     	ldp	x23, x26, [x27]
101533934:     	cmp	x23, #0x2
101533938:     	sbcs	xzr, x26, xzr
10153393c:     	b.hs	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
101533940:     	ldr	x8, [x27, #0x128]
101533944:     	cmp	x8, #0x2
101533948:     	b.ne	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
10153394c:     	ldr	x8, [x27, #0x120]
101533950:     	ldr	w22, [x8]
101533954:     	ldr	x8, [sp, #0x78]
101533958:     	ldr	w8, [x8, #0x4]
10153395c:     	cmp	w22, w8
101533960:     	b.ne	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
101533964:     	ldr	w25, [x27, #0x130]
101533968:     	ldr	x8, [sp, #0x78]
10153396c:     	ldr	w8, [x8, #0x8]
101533970:     	cmp	w25, w8
101533974:     	b.ne	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
101533978:     	ldr	x8, [x27, #0x10]
10153397c:     	cmp	x8, #0xb
101533980:     	b.ne	0x1015339b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x790>
101533984:     	mov	x19, x0
101533988:     	add	x0, x28, #0x488
10153398c:     	mov	x1, x22
101533990:     	bl	0x101546d3c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
101533994:     	cbnz	x0, 0x1015336c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x49c>
101533998:     	str	wzr, [x19]
10153399c:     	mov	w8, #0xc                ; =12
1015339a0:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
1015339a4:     	add	x9, x9, #0x200
1015339a8:     	stp	x8, x9, [x19, #0x8]
1015339ac:     	mov	w8, #0x20               ; =32
1015339b0:     	str	x8, [x19, #0x18]
1015339b4:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
1015339b8:     	str	wzr, [x0]
1015339bc:     	mov	w8, #0xc                ; =12
1015339c0:     	strb	w8, [x0, #0x8]
1015339c4:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
1015339c8:     	add	x8, x8, #0xcb
1015339cc:     	mov	w9, #0x2b               ; =43
1015339d0:     	b	0x1015333cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a4>
1015339d4:     	stp	x22, x21, [x19, #0x8]
1015339d8:     	mov	w8, #0x6                ; =6
1015339dc:     	str	w8, [x19]
1015339e0:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
1015339e4:     	ldr	x1, [x28, #0x408]
1015339e8:     	cmp	x20, x1
1015339ec:     	b.hs	0x101534688 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1460>
1015339f0:     	ldr	x8, [x28, #0x400]
1015339f4:     	add	x25, x8, x20, lsl #9
1015339f8:     	ldp	x9, x8, [x25]
1015339fc:     	eor	x9, x9, #0x2
101533a00:     	orr	x8, x9, x8
101533a04:     	ldr	x19, [sp, #0x68]
101533a08:     	cbnz	x8, 0x101533a60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x838>
101533a0c:     	str	wzr, [x19]
101533a10:     	mov	w8, #0xc                ; =12
101533a14:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101533a18:     	add	x9, x9, #0x1b6
101533a1c:     	stp	x8, x9, [x19, #0x8]
101533a20:     	mov	w8, #0x23               ; =35
101533a24:     	str	x8, [x19, #0x18]
101533a28:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533a2c:     	ldur	q0, [x27, #0x15]
101533a30:     	stur	q0, [x25, #0x15]
101533a34:     	ldur	q0, [x27, #0x25]
101533a38:     	stur	q0, [x25, #0x25]
101533a3c:     	ldur	q0, [x27, #0x35]
101533a40:     	stur	q0, [x25, #0x35]
101533a44:     	ldr	q0, [sp, #0x440]
101533a48:     	str	q0, [x25, #0x40]
101533a4c:     	ldur	q0, [x27, #0x5]
101533a50:     	stur	q0, [x25, #0x5]
101533a54:     	str	w9, [x25]
101533a58:     	strb	w8, [x25, #0x4]
101533a5c:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533a60:     	add	x26, sp, #0x400
101533a64:     	add	x8, sp, #0x400
101533a68:     	mov	x0, x21
101533a6c:     	mov	w1, #0x0                ; =0
101533a70:     	bl	0x101556974 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101533a74:     	ldr	w8, [sp, #0x400]
101533a78:     	tbz	w8, #0x0, 0x101533aac <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x884>
101533a7c:     	ldur	q0, [x26, #0x18]
101533a80:     	ldur	q1, [x26, #0x28]
101533a84:     	ldur	q2, [x26, #0x38]
101533a88:     	stp	q1, q2, [sp, #0x310]
101533a8c:     	ldur	q3, [x26, #0x48]
101533a90:     	str	q3, [sp, #0x330]
101533a94:     	ldur	q4, [x26, #0x8]
101533a98:     	stp	q4, q0, [sp, #0x2f0]
101533a9c:     	stp	q1, q2, [x19, #0x20]
101533aa0:     	str	q3, [x19, #0x40]
101533aa4:     	stp	q4, q0, [x19]
101533aa8:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533aac:     	ldr	x10, [sp, #0x60]
101533ab0:     	ldr	x8, [sp, #0x20]
101533ab4:     	add	x8, x10, x8
101533ab8:     	ldur	q0, [x26, #0x48]
101533abc:     	ldur	q1, [x26, #0x58]
101533ac0:     	stp	q0, q1, [sp, #0x330]
101533ac4:     	ldur	x9, [x26, #0x68]
101533ac8:     	str	x9, [sp, #0x350]
101533acc:     	ldur	q2, [x26, #0x8]
101533ad0:     	str	q2, [sp, #0x2f0]
101533ad4:     	ldur	q3, [x26, #0x38]
101533ad8:     	ldur	q4, [x26, #0x18]
101533adc:     	ldur	q5, [x26, #0x28]
101533ae0:     	stp	q2, q4, [sp, #0x90]
101533ae4:     	stp	q5, q3, [sp, #0xb0]
101533ae8:     	str	x9, [sp, #0xf0]
101533aec:     	stp	q0, q1, [sp, #0xd0]
101533af0:     	str	x10, [sp, #0x400]
101533af4:     	str	x8, [sp, #0x408]
101533af8:     	add	x0, sp, #0x400
101533afc:     	add	x1, x28, #0x488
101533b00:     	bl	0x10152e9ec <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>
101533b04:     	ldr	x26, [x21, #0x490]
101533b08:     	ldr	x2, [x26, #0xd8]
101533b0c:     	cmp	x22, x2
101533b10:     	add	x27, sp, #0x400
101533b14:     	tbz	w0, #0x0, 0x101533c48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa20>
101533b18:     	b.hi	0x1015345b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1388>
101533b1c:     	ldr	x1, [x26, #0xd0]
101533b20:     	ldp	q0, q1, [x21, #0x80]
101533b24:     	str	q0, [sp, #0x480]
101533b28:     	str	q1, [sp, #0x490]
101533b2c:     	ldr	x8, [x21, #0xa0]
101533b30:     	str	x8, [sp, #0x4a0]
101533b34:     	ldp	q0, q1, [x21, #0x40]
101533b38:     	str	q0, [sp, #0x440]
101533b3c:     	str	q1, [sp, #0x450]
101533b40:     	ldp	q1, q0, [x21, #0x60]
101533b44:     	str	q0, [sp, #0x470]
101533b48:     	str	q1, [sp, #0x460]
101533b4c:     	ldp	q0, q1, [x21]
101533b50:     	str	q0, [sp, #0x400]
101533b54:     	str	q1, [sp, #0x410]
101533b58:     	ldp	q1, q0, [x21, #0x20]
101533b5c:     	add	x8, x26, #0x3b8
101533b60:     	str	q0, [sp, #0x430]
101533b64:     	str	q1, [sp, #0x420]
101533b68:     	add	x9, sp, #0x90
101533b6c:     	stp	x8, x9, [sp, #0x8]
101533b70:     	add	x9, sp, #0x400
101533b74:     	str	x9, [sp]
101533b78:     	add	x8, sp, #0xf8
101533b7c:     	add	x5, x26, #0x3c0
101533b80:     	mov	x0, x25
101533b84:     	mov	x2, x22
101533b88:     	mov	x3, x23
101533b8c:     	mov	x4, x22
101533b90:     	mov	x6, #0x0                ; =0
101533b94:     	bl	0x10161a988 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>
101533b98:     	b	0x101533cb8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa90>
101533b9c:     	mov	x8, #0x11               ; =17
101533ba0:     	ldr	x9, [sp, #0x48]
101533ba4:     	bfxil	x9, x8, #0, #8
101533ba8:     	ldr	s0, [sp, #0x54]
101533bac:     	ldp	x11, x10, [sp, #0x30]
101533bb0:     	ldr	x12, [sp, #0x28]
101533bb4:     	b	0x101533c24 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9fc>
101533bb8:     	str	wzr, [x19]
101533bbc:     	mov	w8, #0xc                ; =12
101533bc0:     	strb	w8, [x19, #0x8]
101533bc4:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101533bc8:     	add	x8, x8, #0xf24
101533bcc:     	mov	w9, #0x2b               ; =43
101533bd0:     	b	0x101533408 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1e0>
101533bd4:     	mov	w9, #0x13               ; =19
101533bd8:     	b	0x101533be0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9b8>
101533bdc:     	mov	w9, #0xc                ; =12
101533be0:     	ldr	x8, [sp, #0x48]
101533be4:     	and	x8, x8, #0xffffffffffffff00
101533be8:     	orr	x9, x9, x8
101533bec:     	ldr	s0, [sp, #0x54]
101533bf0:     	adrp	x11, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
101533bf4:     	add	x11, x11, #0x1f9
101533bf8:     	mov	w12, #0x2f              ; =47
101533bfc:     	ldr	x10, [sp, #0x38]
101533c00:     	b	0x101533c24 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x9fc>
101533c04:     	ldr	x9, [sp, #0x2f0]
101533c08:     	ldr	x11, [sp, #0x2f8]
101533c0c:     	add	x8, sp, #0x230
101533c10:     	ldur	q0, [x8, #0xd8]
101533c14:     	str	q0, [sp, #0x80]
101533c18:     	ldr	x12, [sp, #0x300]
101533c1c:     	ldr	x10, [sp, #0x318]
101533c20:     	ldr	d0, [sp, #0x320]
101533c24:     	ldr	q1, [sp, #0x80]
101533c28:     	str	q1, [x19, #0x20]
101533c2c:     	mov	w8, #0x2                ; =2
101533c30:     	str	w8, [x19]
101533c34:     	stp	x9, x11, [x19, #0x8]
101533c38:     	str	x12, [x19, #0x18]
101533c3c:     	str	x10, [x19, #0x30]
101533c40:     	str	d0, [x19, #0x38]
101533c44:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533c48:     	b.hi	0x1015345c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x139c>
101533c4c:     	ldr	x1, [x26, #0xd0]
101533c50:     	ldp	q0, q1, [x21, #0x80]
101533c54:     	str	q0, [sp, #0x480]
101533c58:     	str	q1, [sp, #0x490]
101533c5c:     	ldr	x8, [x21, #0xa0]
101533c60:     	str	x8, [sp, #0x4a0]
101533c64:     	ldp	q0, q1, [x21, #0x40]
101533c68:     	str	q0, [sp, #0x440]
101533c6c:     	str	q1, [sp, #0x450]
101533c70:     	ldp	q1, q0, [x21, #0x60]
101533c74:     	str	q0, [sp, #0x470]
101533c78:     	str	q1, [sp, #0x460]
101533c7c:     	ldp	q0, q1, [x21]
101533c80:     	str	q0, [sp, #0x400]
101533c84:     	str	q1, [sp, #0x410]
101533c88:     	ldp	q1, q0, [x21, #0x20]
101533c8c:     	str	q0, [sp, #0x430]
101533c90:     	str	q1, [sp, #0x420]
101533c94:     	add	x8, sp, #0xf8
101533c98:     	add	x5, sp, #0x400
101533c9c:     	add	x6, x26, #0x3b8
101533ca0:     	add	x7, sp, #0x90
101533ca4:     	mov	x0, x25
101533ca8:     	mov	x2, x22
101533cac:     	mov	x3, x23
101533cb0:     	mov	x4, x22
101533cb4:     	bl	0x1027c7dc0 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_frame_words>
101533cb8:     	ldrb	w8, [sp, #0xf8]
101533cbc:     	cmp	w8, #0x2e
101533cc0:     	b.ne	0x101533d60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb38>
101533cc4:     	ldr	x2, [x26, #0xd8]
101533cc8:     	cmp	x22, x2
101533ccc:     	b.hi	0x1015345d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13b0>
101533cd0:     	ldr	x6, [x26, #0xd0]
101533cd4:     	ldr	x8, [sp, #0x78]
101533cd8:     	ldr	w3, [x8, #0x4]
101533cdc:     	add	x8, x26, #0x2f8
101533ce0:     	stp	x22, x8, [sp, #0x8]
101533ce4:     	add	x0, sp, #0x400
101533ce8:     	add	x1, x26, #0x3c0
101533cec:     	add	x2, x28, #0x488
101533cf0:     	str	x23, [sp]
101533cf4:     	ldr	x4, [sp, #0x60]
101533cf8:     	mov	x5, x22
101533cfc:     	mov	x7, x22
101533d00:     	bl	0x1015323b4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4pack>
101533d04:     	ldr	x2, [x26, #0xd8]
101533d08:     	cmp	x22, x2
101533d0c:     	b.hi	0x101534604 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13dc>
101533d10:     	ldr	x0, [x26, #0xd0]
101533d14:     	str	xzr, [sp, #0x2f0]
101533d18:     	add	x2, sp, #0x2f0
101533d1c:     	mov	x1, x22
101533d20:     	bl	0x1014e01c4 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
101533d24:     	ldr	w8, [sp, #0x400]
101533d28:     	cmp	w8, #0x6
101533d2c:     	b.eq	0x101533858 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x630>
101533d30:     	ldur	q0, [x27, #0x14]
101533d34:     	stur	q0, [x19, #0x14]
101533d38:     	ldur	q0, [x27, #0x24]
101533d3c:     	stur	q0, [x19, #0x24]
101533d40:     	ldur	q0, [x27, #0x34]
101533d44:     	stur	q0, [x19, #0x34]
101533d48:     	ldr	q0, [sp, #0x440]
101533d4c:     	str	q0, [x19, #0x40]
101533d50:     	ldur	q0, [x27, #0x4]
101533d54:     	stur	q0, [x19, #0x4]
101533d58:     	str	w8, [x19]
101533d5c:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533d60:     	ldr	x2, [x26, #0xd8]
101533d64:     	cmp	x22, x2
101533d68:     	b.hi	0x1015345ec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13c4>
101533d6c:     	ldr	x0, [x26, #0xd0]
101533d70:     	str	xzr, [sp, #0x400]
101533d74:     	add	x2, sp, #0x400
101533d78:     	mov	x1, x22
101533d7c:     	bl	0x1014e01c4 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
101533d80:     	ldr	x1, [x28, #0x380]
101533d84:     	cmp	x20, x1
101533d88:     	b.hs	0x101534698 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1470>
101533d8c:     	ldr	x8, [x28, #0x378]
101533d90:     	mov	w9, #0x170              ; =368
101533d94:     	madd	x8, x20, x9, x8
101533d98:     	ldr	w9, [x8, #0x158]
101533d9c:     	add	x10, sp, #0xf8
101533da0:     	add	x8, x8, #0x148
101533da4:     	ldr	q0, [x8]
101533da8:     	ldur	q1, [sp, #0xf8]
101533dac:     	stur	q1, [x19, #0x18]
101533db0:     	ldp	q1, q2, [x10, #0x10]
101533db4:     	stur	q1, [x19, #0x28]
101533db8:     	stur	q2, [x19, #0x38]
101533dbc:     	ldr	x8, [sp, #0x128]
101533dc0:     	str	x8, [x19, #0x48]
101533dc4:     	mov	w8, #0x3                ; =3
101533dc8:     	str	w8, [x19]
101533dcc:     	stur	q0, [x19, #0x4]
101533dd0:     	str	w9, [x19, #0x14]
101533dd4:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533dd8:     	ldr	x26, [x21, #0x490]
101533ddc:     	ldr	x1, [x26, #0x3c0]
101533de0:     	add	x0, sp, #0x400
101533de4:     	add	x2, x28, #0x488
101533de8:     	add	x5, x26, #0x2f8
101533dec:     	mov	x3, x22
101533df0:     	mov	x4, x24
101533df4:     	bl	0x101532e2c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames7project>
101533df8:     	ldr	w8, [sp, #0x400]
101533dfc:     	cmp	w8, #0x6
101533e00:     	b.ne	0x101533ef4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xccc>
101533e04:     	add	x8, sp, #0x400
101533e08:     	ldur	q0, [x8, #0x38]
101533e0c:     	ldur	q1, [x8, #0x28]
101533e10:     	ldur	q2, [x8, #0x18]
101533e14:     	ldur	q3, [x8, #0x8]
101533e18:     	stp	q3, q2, [sp, #0x230]
101533e1c:     	stp	q1, q0, [sp, #0x250]
101533e20:     	ldp	x9, x8, [x27]
101533e24:     	mov	w10, #0x1               ; =1
101533e28:     	cmp	x10, x9
101533e2c:     	ngcs	xzr, x8
101533e30:     	b.lo	0x1015342f4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10cc>
101533e34:     	ldr	x8, [x27, #0x128]
101533e38:     	cmp	x8, #0x2
101533e3c:     	b.lo	0x1015346b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1490>
101533e40:     	mov	x25, x24
101533e44:     	ldr	x8, [x27, #0x120]
101533e48:     	ldr	w1, [x8, #0x4]
101533e4c:     	mov	w22, #0x1               ; =1
101533e50:     	add	x8, sp, #0x400
101533e54:     	add	x0, x26, #0xf0
101533e58:     	add	x2, x26, #0x2f8
101533e5c:     	bl	0x10154fa14 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101533e60:     	add	x8, sp, #0x400
101533e64:     	ldur	q0, [x8, #0x8]
101533e68:     	ldur	q1, [x8, #0x18]
101533e6c:     	stp	q0, q1, [sp, #0x2b0]
101533e70:     	ldur	q0, [x8, #0x28]
101533e74:     	str	q0, [sp, #0x2d0]
101533e78:     	ldr	x8, [sp, #0x400]
101533e7c:     	ldr	x9, [sp, #0x438]
101533e80:     	str	x9, [sp, #0x2e0]
101533e84:     	cbz	x8, 0x101533f9c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd74>
101533e88:     	ldp	q0, q1, [sp, #0x2b0]
101533e8c:     	add	x9, sp, #0x230
101533e90:     	stur	q0, [x9, #0x48]
101533e94:     	stur	q1, [x9, #0x58]
101533e98:     	ldr	q0, [sp, #0x2d0]
101533e9c:     	add	x24, sp, #0x230
101533ea0:     	stur	q0, [x9, #0x68]
101533ea4:     	ldr	x9, [sp, #0x2e0]
101533ea8:     	str	x9, [sp, #0x2a8]
101533eac:     	str	x8, [sp, #0x270]
101533eb0:     	ldr	x1, [x28, #0x408]
101533eb4:     	cmp	x20, x1
101533eb8:     	b.hs	0x101534700 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14d8>
101533ebc:     	ldr	x8, [x28, #0x400]
101533ec0:     	add	x22, x8, x20, lsl #9
101533ec4:     	ldp	x9, x8, [x22]
101533ec8:     	eor	x9, x9, #0x2
101533ecc:     	orr	x8, x9, x8
101533ed0:     	cbnz	x8, 0x101533fe8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xdc0>
101533ed4:     	str	wzr, [x19]
101533ed8:     	mov	w8, #0xc                ; =12
101533edc:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101533ee0:     	add	x9, x9, #0x243
101533ee4:     	stp	x8, x9, [x19, #0x8]
101533ee8:     	mov	w8, #0x2a               ; =42
101533eec:     	str	x8, [x19, #0x18]
101533ef0:     	b	0x10153448c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1264>
101533ef4:     	add	x10, sp, #0x400
101533ef8:     	ldur	q0, [x10, #0x14]
101533efc:     	ldur	q1, [x10, #0x24]
101533f00:     	ldur	q2, [x10, #0x34]
101533f04:     	stp	q1, q2, [sp, #0x310]
101533f08:     	ldr	w9, [sp, #0x444]
101533f0c:     	str	w9, [sp, #0x330]
101533f10:     	ldur	q3, [x10, #0x4]
101533f14:     	stp	q3, q0, [sp, #0x2f0]
101533f18:     	ldr	x10, [sp, #0x448]
101533f1c:     	stur	q0, [x19, #0x14]
101533f20:     	stur	q1, [x19, #0x24]
101533f24:     	stur	q2, [x19, #0x34]
101533f28:     	str	w9, [x19, #0x44]
101533f2c:     	stur	q3, [x19, #0x4]
101533f30:     	str	w8, [x19]
101533f34:     	str	x10, [x19, #0x48]
101533f38:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533f3c:     	ldr	x26, [x21, #0x490]
101533f40:     	add	x0, sp, #0x400
101533f44:     	add	x1, x26, #0x3c0
101533f48:     	add	x2, x28, #0x488
101533f4c:     	add	x6, x26, #0x2f8
101533f50:     	mov	x3, x22
101533f54:     	mov	x4, x24
101533f58:     	mov	x5, x25
101533f5c:     	bl	0x101531730 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames17project_composite>
101533f60:     	ldr	w8, [sp, #0x400]
101533f64:     	cmp	w8, #0x6
101533f68:     	b.ne	0x101533f78 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd50>
101533f6c:     	mov	x22, #0x0               ; =0
101533f70:     	add	x27, sp, #0x400
101533f74:     	b	0x10153385c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x634>
101533f78:     	ldr	q0, [sp, #0x420]
101533f7c:     	ldr	q1, [sp, #0x430]
101533f80:     	stp	q0, q1, [x19, #0x20]
101533f84:     	ldr	q0, [sp, #0x440]
101533f88:     	str	q0, [x19, #0x40]
101533f8c:     	ldr	q0, [sp, #0x410]
101533f90:     	ldr	q1, [sp, #0x400]
101533f94:     	stp	q1, q0, [x19]
101533f98:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101533f9c:     	ldp	q0, q1, [sp, #0x2b0]
101533fa0:     	add	x9, sp, #0x400
101533fa4:     	stur	q0, [x9, #0x4]
101533fa8:     	stur	q1, [x9, #0x14]
101533fac:     	ldr	q0, [sp, #0x2d0]
101533fb0:     	stur	q0, [x9, #0x24]
101533fb4:     	ldr	x8, [sp, #0x2e0]
101533fb8:     	stur	x8, [x9, #0x34]
101533fbc:     	ldr	q0, [sp, #0x400]
101533fc0:     	ldr	q1, [sp, #0x410]
101533fc4:     	stur	q0, [x19, #0x4]
101533fc8:     	mov	w8, #0x2                ; =2
101533fcc:     	str	w8, [x19]
101533fd0:     	stur	q1, [x19, #0x14]
101533fd4:     	ldr	q0, [sp, #0x420]
101533fd8:     	stur	q0, [x19, #0x24]
101533fdc:     	ldur	q0, [x9, #0x2c]
101533fe0:     	str	q0, [x19, #0x30]
101533fe4:     	b	0x101534498 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1270>
101533fe8:     	add	x23, sp, #0x400
101533fec:     	add	x8, sp, #0x400
101533ff0:     	mov	x0, x21
101533ff4:     	mov	w1, #0x0                ; =0
101533ff8:     	bl	0x101556974 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101533ffc:     	ldr	x8, [sp, #0x400]
101534000:     	cmp	x8, #0x1
101534004:     	b.ne	0x1015340d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xeac>
101534008:     	ldur	q0, [x23, #0x18]
10153400c:     	ldur	q1, [x23, #0x28]
101534010:     	ldur	q2, [x23, #0x38]
101534014:     	stp	q1, q2, [sp, #0x310]
101534018:     	ldur	q3, [x23, #0x48]
10153401c:     	str	q3, [sp, #0x330]
101534020:     	ldur	q4, [x23, #0x8]
101534024:     	stp	q4, q0, [sp, #0x2f0]
101534028:     	stp	q1, q2, [x19, #0x20]
10153402c:     	str	q3, [x19, #0x40]
101534030:     	stp	q4, q0, [x19]
101534034:     	b	0x10153448c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1264>
101534038:     	ldp	q0, q1, [sp, #0x150]
10153403c:     	add	x9, sp, #0x400
101534040:     	stur	q0, [x9, #0x4]
101534044:     	stur	q1, [x9, #0x14]
101534048:     	ldr	q0, [sp, #0x170]
10153404c:     	stur	q0, [x9, #0x24]
101534050:     	ldr	x8, [sp, #0x180]
101534054:     	stur	x8, [x9, #0x34]
101534058:     	ldr	q0, [sp, #0x400]
10153405c:     	ldr	q1, [sp, #0x410]
101534060:     	stur	q0, [x19, #0x4]
101534064:     	mov	w8, #0x2                ; =2
101534068:     	str	w8, [x19]
10153406c:     	stur	q1, [x19, #0x14]
101534070:     	ldr	q0, [sp, #0x420]
101534074:     	stur	q0, [x19, #0x24]
101534078:     	ldur	q0, [x9, #0x2c]
10153407c:     	str	q0, [x19, #0x30]
101534080:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101534084:     	add	x25, sp, #0x400
101534088:     	add	x8, sp, #0x400
10153408c:     	mov	x0, x21
101534090:     	mov	w1, #0x0                ; =0
101534094:     	bl	0x101556974 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101534098:     	ldr	x8, [sp, #0x400]
10153409c:     	cmp	x8, #0x1
1015340a0:     	b.ne	0x101534180 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xf58>
1015340a4:     	ldur	q0, [x25, #0x18]
1015340a8:     	ldur	q1, [x25, #0x28]
1015340ac:     	ldur	q2, [x25, #0x38]
1015340b0:     	stp	q1, q2, [sp, #0x310]
1015340b4:     	ldur	q3, [x25, #0x48]
1015340b8:     	str	q3, [sp, #0x330]
1015340bc:     	ldur	q4, [x25, #0x8]
1015340c0:     	stp	q4, q0, [sp, #0x2f0]
1015340c4:     	stp	q1, q2, [x19, #0x20]
1015340c8:     	str	q3, [x19, #0x40]
1015340cc:     	stp	q4, q0, [x19]
1015340d0:     	b	0x1015344fc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
1015340d4:     	ldur	q0, [x23, #0x48]
1015340d8:     	ldur	q1, [x23, #0x58]
1015340dc:     	stp	q0, q1, [sp, #0x330]
1015340e0:     	ldur	x8, [x23, #0x68]
1015340e4:     	str	x8, [sp, #0x350]
1015340e8:     	ldur	q2, [x23, #0x8]
1015340ec:     	ldur	q3, [x23, #0x18]
1015340f0:     	stp	q2, q3, [sp, #0x2f0]
1015340f4:     	ldur	q4, [x23, #0x38]
1015340f8:     	ldur	q5, [x23, #0x28]
1015340fc:     	stp	q2, q3, [sp, #0x360]
101534100:     	stp	q5, q4, [sp, #0x380]
101534104:     	str	x8, [sp, #0x3c0]
101534108:     	stp	q0, q1, [sp, #0x3a0]
10153410c:     	ldr	x8, [sp, #0x230]
101534110:     	cbz	x8, 0x101534268 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1040>
101534114:     	ldp	q0, q1, [x21, #0x80]
101534118:     	str	q0, [sp, #0x480]
10153411c:     	str	q1, [sp, #0x490]
101534120:     	ldr	x8, [x21, #0xa0]
101534124:     	str	x8, [sp, #0x4a0]
101534128:     	ldp	q0, q1, [x21, #0x40]
10153412c:     	str	q0, [sp, #0x440]
101534130:     	str	q1, [sp, #0x450]
101534134:     	ldp	q1, q0, [x21, #0x60]
101534138:     	str	q0, [sp, #0x470]
10153413c:     	str	q1, [sp, #0x460]
101534140:     	ldp	q0, q1, [x21]
101534144:     	str	q0, [sp, #0x400]
101534148:     	str	q1, [sp, #0x410]
10153414c:     	ldp	q1, q0, [x21, #0x20]
101534150:     	str	q0, [sp, #0x430]
101534154:     	str	q1, [sp, #0x420]
101534158:     	add	x8, sp, #0x3c8
10153415c:     	add	x1, sp, #0x270
101534160:     	add	x3, sp, #0x230
101534164:     	add	x4, sp, #0x400
101534168:     	add	x5, x26, #0x3b8
10153416c:     	add	x6, sp, #0x360
101534170:     	mov	x0, x22
101534174:     	mov	x2, x25
101534178:     	bl	0x1027c8164 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall25admit_buffer_record_field>
10153417c:     	b	0x1015342dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x10b4>
101534180:     	ldur	q0, [x25, #0x48]
101534184:     	ldur	q1, [x25, #0x58]
101534188:     	stp	q0, q1, [sp, #0x330]
10153418c:     	ldur	x8, [x25, #0x68]
101534190:     	str	x8, [sp, #0x350]
101534194:     	ldur	q2, [x25, #0x8]
101534198:     	ldur	q3, [x25, #0x18]
10153419c:     	stp	q2, q3, [sp, #0x2f0]
1015341a0:     	ldur	q4, [x25, #0x38]
1015341a4:     	ldur	q5, [x25, #0x28]
1015341a8:     	stp	q2, q3, [sp, #0x190]
1015341ac:     	stp	q5, q4, [sp, #0x1b0]
1015341b0:     	str	x8, [sp, #0x1f0]
1015341b4:     	stp	q0, q1, [sp, #0x1d0]
1015341b8:     	ldr	x8, [sp, #0x78]
1015341bc:     	ldr	x7, [x8, #0x10]
1015341c0:     	ldp	q0, q1, [x21, #0x80]
1015341c4:     	str	q0, [sp, #0x480]
1015341c8:     	str	q1, [sp, #0x490]
1015341cc:     	ldr	x8, [x21, #0xa0]
1015341d0:     	str	x8, [sp, #0x4a0]
1015341d4:     	ldp	q0, q1, [x21, #0x40]
1015341d8:     	str	q0, [sp, #0x440]
1015341dc:     	str	q1, [sp, #0x450]
1015341e0:     	ldp	q1, q0, [x21, #0x60]
1015341e4:     	str	q0, [sp, #0x470]
1015341e8:     	str	q1, [sp, #0x460]
1015341ec:     	ldp	q0, q1, [x21]
1015341f0:     	str	q0, [sp, #0x400]
1015341f4:     	str	q1, [sp, #0x410]
1015341f8:     	ldp	q1, q0, [x21, #0x20]
1015341fc:     	add	x8, x26, #0x3b8
101534200:     	str	q0, [sp, #0x430]
101534204:     	str	q1, [sp, #0x420]
101534208:     	add	x9, sp, #0x190
10153420c:     	stp	x8, x9, [sp, #0x8]
101534210:     	add	x9, sp, #0x400
101534214:     	adrp	x1, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101534218:     	add	x1, x1, #0xff8
10153421c:     	str	x9, [sp]
101534220:     	add	x8, sp, #0x1f8
101534224:     	add	x5, x26, #0x3c0
101534228:     	add	x6, sp, #0x270
10153422c:     	adrp	x3, 0x107557000 <_anon.99617498846789129750b3326436f5d5.850+0xd6c>
101534230:     	add	x3, x3, #0x120
101534234:     	mov	x0, x23
101534238:     	mov	w2, #0x2                ; =2
10153423c:     	mov	w4, #0x2                ; =2
101534240:     	bl	0x10161abd0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>
101534244:     	ldrb	w8, [sp, #0x1f8]
101534248:     	cmp	w8, #0x2e
10153424c:     	b.ne	0x1015344c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x129c>
101534250:     	add	x0, sp, #0x270
101534254:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101534258:     	ldr	x8, [sp, #0x78]
10153425c:     	ldr	x24, [x8, #0x10]
101534260:     	ldr	w25, [x8, #0x8]
101534264:     	b	0x101533f40 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd18>
101534268:     	ldr	w3, [sp, #0x248]
10153426c:     	ldur	q0, [x24, #0x8]
101534270:     	str	q0, [sp, #0x2f0]
101534274:     	ldp	q0, q1, [x21, #0x80]
101534278:     	str	q0, [sp, #0x480]
10153427c:     	str	q1, [sp, #0x490]
101534280:     	ldr	x8, [x21, #0xa0]
101534284:     	str	x8, [sp, #0x4a0]
101534288:     	ldp	q0, q1, [x21, #0x40]
10153428c:     	str	q0, [sp, #0x440]
101534290:     	str	q1, [sp, #0x450]
101534294:     	ldp	q1, q0, [x21, #0x60]
101534298:     	str	q0, [sp, #0x470]
10153429c:     	str	q1, [sp, #0x460]
1015342a0:     	ldp	q0, q1, [x21]
1015342a4:     	str	q0, [sp, #0x400]
1015342a8:     	str	q1, [sp, #0x410]
1015342ac:     	ldp	q1, q0, [x21, #0x20]
1015342b0:     	str	q0, [sp, #0x430]
1015342b4:     	str	q1, [sp, #0x420]
1015342b8:     	add	x8, sp, #0x3c8
1015342bc:     	add	x1, sp, #0x270
1015342c0:     	add	x4, sp, #0x2f0
1015342c4:     	add	x5, sp, #0x400
1015342c8:     	add	x6, x26, #0x3b8
1015342cc:     	add	x7, sp, #0x360
1015342d0:     	mov	x0, x22
1015342d4:     	mov	x2, x25
1015342d8:     	bl	0x1027c7e1c <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_record_word>
1015342dc:     	ldrb	w8, [sp, #0x3c8]
1015342e0:     	cmp	w8, #0x2e
1015342e4:     	b.ne	0x101534454 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x122c>
1015342e8:     	mov	w22, #0x1               ; =1
1015342ec:     	add	x0, sp, #0x270
1015342f0:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015342f4:     	ldr	x8, [x28, #0x360]
1015342f8:     	ldr	x9, [sp, #0x78]
1015342fc:     	ldr	w1, [x9, #0x8]
101534300:     	cmp	x8, x1
101534304:     	b.ls	0x1015346ac <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1484>
101534308:     	ldr	x8, [x28, #0x358]
10153430c:     	mov	w9, #0x140              ; =320
101534310:     	umaddl	x9, w1, w9, x8
101534314:     	ldr	x8, [sp, #0x230]
101534318:     	cbz	x8, 0x1015343f8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
10153431c:     	ldp	q0, q1, [sp, #0x230]
101534320:     	str	q0, [sp, #0x400]
101534324:     	str	q1, [sp, #0x410]
101534328:     	ldp	q0, q1, [sp, #0x250]
10153432c:     	str	q0, [sp, #0x420]
101534330:     	str	q1, [sp, #0x430]
101534334:     	ldr	x8, [x28, #0x448]
101534338:     	cmp	x8, x1
10153433c:     	b.ls	0x1015346d8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14b0>
101534340:     	ldr	x8, [x28, #0x440]
101534344:     	mov	w10, #0x24              ; =36
101534348:     	umaddl	x8, w1, w10, x8
10153434c:     	ldr	w10, [sp, #0x438]
101534350:     	ldr	w11, [x8, #0x20]
101534354:     	cmp	w10, w11
101534358:     	b.ne	0x1015343cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11a4>
10153435c:     	ldp	q0, q1, [sp, #0x240]
101534360:     	stp	q0, q1, [sp, #0x2f0]
101534364:     	ldr	x10, [sp, #0x2f0]
101534368:     	ldr	x11, [sp, #0x2f8]
10153436c:     	ldp	x12, x13, [x8]
101534370:     	ldr	x14, [sp, #0x300]
101534374:     	ldr	x15, [sp, #0x308]
101534378:     	ldp	x16, x8, [x8, #0x10]
10153437c:     	cmp	x10, x12
101534380:     	ccmp	x11, x13, #0x0, eq
101534384:     	ccmp	x14, x16, #0x0, eq
101534388:     	ccmp	x15, x8, #0x0, eq
10153438c:     	b.ne	0x1015343cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11a4>
101534390:     	ldrb	w8, [x9, #0x124]
101534394:     	cmp	w8, #0x7
101534398:     	b.ne	0x1015343cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11a4>
10153439c:     	add	x8, sp, #0x2f0
1015343a0:     	add	x0, x26, #0xf0
1015343a4:     	add	x2, sp, #0x400
1015343a8:     	add	x3, x26, #0x2f8
1015343ac:     	bl	0x101551af4 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015343b0:     	ldrb	w8, [sp, #0x2f0]
1015343b4:     	cmp	w8, #0x14
1015343b8:     	b.ne	0x101534508 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
1015343bc:     	mov	w22, #0x0               ; =0
1015343c0:     	add	x0, sp, #0x400
1015343c4:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015343c8:     	b	0x101533f6c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd44>
1015343cc:     	str	wzr, [x19]
1015343d0:     	mov	w8, #0xc                ; =12
1015343d4:     	strb	w8, [x19, #0x8]
1015343d8:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
1015343dc:     	add	x8, x8, #0xa1
1015343e0:     	mov	w9, #0x2a               ; =42
1015343e4:     	stp	x8, x9, [x19, #0x10]
1015343e8:     	mov	w22, #0x0               ; =0
1015343ec:     	add	x0, sp, #0x400
1015343f0:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015343f4:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
1015343f8:     	ldr	w8, [sp, #0x248]
1015343fc:     	ldr	w10, [x9, #0x130]
101534400:     	cmp	w8, w10
101534404:     	b.ne	0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
101534408:     	ldrb	w8, [sp, #0x239]
10153440c:     	ldr	x21, [sp, #0x240]
101534410:     	ldrb	w10, [sp, #0x238]
101534414:     	ldrb	w9, [x9, #0x124]
101534418:     	cmp	w10, #0x2
10153441c:     	b.le	0x10153443c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1214>
101534420:     	cmp	w10, #0x4
101534424:     	b.gt	0x1015344ac <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1284>
101534428:     	cmp	w10, #0x3
10153442c:     	b.ne	0x101534564 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x133c>
101534430:     	cmp	w9, #0x3
101534434:     	b.eq	0x101534588 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1360>
101534438:     	b	0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
10153443c:     	cbz	w10, 0x10153454c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1324>
101534440:     	cmp	w10, #0x1
101534444:     	b.ne	0x101534558 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1330>
101534448:     	cmp	w9, #0x1
10153444c:     	b.eq	0x101534588 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1360>
101534450:     	b	0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
101534454:     	ldr	x1, [x28, #0x378]
101534458:     	ldr	x2, [x28, #0x380]
10153445c:     	add	x0, sp, #0x400
101534460:     	add	x4, sp, #0x3c8
101534464:     	mov	x3, x20
101534468:     	bl	0x10152f240 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>
10153446c:     	ldr	q0, [sp, #0x420]
101534470:     	ldr	q1, [sp, #0x430]
101534474:     	stp	q0, q1, [x19, #0x20]
101534478:     	ldr	q0, [sp, #0x440]
10153447c:     	str	q0, [x19, #0x40]
101534480:     	ldr	q0, [sp, #0x410]
101534484:     	ldr	q1, [sp, #0x400]
101534488:     	stp	q1, q0, [x19]
10153448c:     	mov	w22, #0x1               ; =1
101534490:     	add	x0, sp, #0x270
101534494:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101534498:     	ldr	x8, [sp, #0x230]
10153449c:     	cbz	x8, 0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
1015344a0:     	add	x0, sp, #0x230
1015344a4:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015344a8:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
1015344ac:     	cmp	w10, #0x5
1015344b0:     	b.ne	0x10153457c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1354>
1015344b4:     	cmp	w9, #0x5
1015344b8:     	b.ne	0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
1015344bc:     	ldrh	w21, [sp, #0x23a]
1015344c0:     	b	0x101534588 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1360>
1015344c4:     	ldr	x1, [x28, #0x378]
1015344c8:     	ldr	x2, [x28, #0x380]
1015344cc:     	add	x0, sp, #0x400
1015344d0:     	add	x4, sp, #0x1f8
1015344d4:     	mov	x3, x20
1015344d8:     	bl	0x10152f1ac <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>
1015344dc:     	ldr	q0, [sp, #0x420]
1015344e0:     	ldr	q1, [sp, #0x430]
1015344e4:     	stp	q0, q1, [x19, #0x20]
1015344e8:     	ldr	q0, [sp, #0x440]
1015344ec:     	str	q0, [x19, #0x40]
1015344f0:     	ldr	q0, [sp, #0x410]
1015344f4:     	ldr	q1, [sp, #0x400]
1015344f8:     	stp	q1, q0, [x19]
1015344fc:     	add	x0, sp, #0x270
101534500:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101534504:     	b	0x1015333d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1a8>
101534508:     	add	x10, sp, #0x230
10153450c:     	ldur	w9, [x10, #0xc1]
101534510:     	stur	w9, [x19, #0x9]
101534514:     	ldr	w9, [sp, #0x2f4]
101534518:     	str	w9, [x19, #0xc]
10153451c:     	ldr	q0, [sp, #0x310]
101534520:     	stur	q0, [x19, #0x28]
101534524:     	ldr	x9, [sp, #0x320]
101534528:     	str	x9, [x19, #0x38]
10153452c:     	ldr	d0, [sp, #0x308]
101534530:     	ldur	q1, [x10, #0xc8]
101534534:     	mov	w9, #0x2                ; =2
101534538:     	str	w9, [x19]
10153453c:     	strb	w8, [x19, #0x8]
101534540:     	str	q1, [x19, #0x10]
101534544:     	str	d0, [x19, #0x20]
101534548:     	b	0x1015343e8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11c0>
10153454c:     	cbnz	w9, 0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
101534550:     	and	x21, x8, #0x1
101534554:     	b	0x101534588 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1360>
101534558:     	cmp	w9, #0x2
10153455c:     	b.eq	0x101534588 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1360>
101534560:     	b	0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
101534564:     	cmp	w9, #0x4
101534568:     	b.ne	0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
10153456c:     	mov	w22, #0x1               ; =1
101534570:     	mov	x21, x8
101534574:     	add	x27, sp, #0x400
101534578:     	b	0x10153385c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x634>
10153457c:     	cmp	w9, #0x6
101534580:     	b.ne	0x101534594 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
101534584:     	ldr	w21, [sp, #0x23c]
101534588:     	mov	w22, #0x1               ; =1
10153458c:     	add	x27, sp, #0x400
101534590:     	b	0x10153385c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x634>
101534594:     	str	wzr, [x19]
101534598:     	mov	w8, #0xc                ; =12
10153459c:     	strb	w8, [x19, #0x8]
1015345a0:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
1015345a4:     	add	x8, x8, #0x78
1015345a8:     	mov	w9, #0x29               ; =41
1015345ac:     	b	0x101533408 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1e0>
1015345b0:     	adrp	x3, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
1015345b4:     	add	x3, x3, #0xfc8
1015345b8:     	mov	x0, #0x0                ; =0
1015345bc:     	mov	x1, x22
1015345c0:     	bl	0x103a07be0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015345c4:     	adrp	x3, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
1015345c8:     	add	x3, x3, #0xf50
1015345cc:     	mov	x0, #0x0                ; =0
1015345d0:     	mov	x1, x22
1015345d4:     	bl	0x103a07be0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015345d8:     	adrp	x3, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
1015345dc:     	add	x3, x3, #0xfb0
1015345e0:     	mov	x0, #0x0                ; =0
1015345e4:     	mov	x1, x22
1015345e8:     	bl	0x103a07be0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015345ec:     	adrp	x3, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
1015345f0:     	add	x3, x3, #0xf80
1015345f4:     	mov	x0, #0x0                ; =0
1015345f8:     	mov	x1, x22
1015345fc:     	bl	0x103a07be0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101534600:     	b	0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
101534604:     	adrp	x3, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
101534608:     	add	x3, x3, #0xf98
10153460c:     	mov	x0, #0x0                ; =0
101534610:     	mov	x1, x22
101534614:     	bl	0x103a07be0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101534618:     	b	0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
10153461c:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
101534620:     	add	x2, x2, #0xf20
101534624:     	mov	x0, x20
101534628:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10153462c:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
101534630:     	add	x2, x2, #0xfe0
101534634:     	mov	x0, x26
101534638:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10153463c:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101534640:     	add	x2, x2, #0x28
101534644:     	mov	x0, x19
101534648:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10153464c:     	b	0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
101534650:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101534654:     	add	x2, x2, #0x40
101534658:     	mov	x0, x20
10153465c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101534660:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101534664:     	add	x2, x2, #0x10
101534668:     	mov	x0, x25
10153466c:     	mov	x1, x22
101534670:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101534674:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
101534678:     	add	x2, x2, #0xff8
10153467c:     	mov	x0, x25
101534680:     	mov	x1, x22
101534684:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101534688:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
10153468c:     	add	x2, x2, #0xf38
101534690:     	mov	x0, x20
101534694:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101534698:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
10153469c:     	add	x2, x2, #0xf68
1015346a0:     	mov	x0, x20
1015346a4:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015346a8:     	b	0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
1015346ac:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
1015346b0:     	add	x2, x2, #0xb8
1015346b4:     	b	0x1015346c4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x149c>
1015346b8:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
1015346bc:     	add	x2, x2, #0x88
1015346c0:     	mov	w1, #0x1                ; =1
1015346c4:     	mov	w22, #0x1               ; =1
1015346c8:     	mov	x0, x1
1015346cc:     	mov	x1, x8
1015346d0:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015346d4:     	b	0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
1015346d8:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
1015346dc:     	add	x2, x2, #0xd0
1015346e0:     	mov	x0, x1
1015346e4:     	mov	x1, x8
1015346e8:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015346ec:     	b	0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
1015346f0:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
1015346f4:     	add	x2, x2, #0x58
1015346f8:     	mov	w0, #0x1                ; =1
1015346fc:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101534700:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101534704:     	add	x2, x2, #0xa0
101534708:     	mov	x0, x20
10153470c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101534710:     	b	0x101534724 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14fc>
101534714:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101534718:     	add	x2, x2, #0x70
10153471c:     	mov	x0, x20
101534720:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101534724:     	brk	#0x1
101534728:     	mov	x19, x0
10153472c:     	add	x0, sp, #0x400
101534730:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101534734:     	b	0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
101534738:     	mov	x19, x0
10153473c:     	add	x0, sp, #0x270
101534740:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101534744:     	b	0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
101534748:     	mov	x19, x0
10153474c:     	add	x0, sp, #0x270
101534750:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101534754:     	mov	w22, #0x1               ; =1
101534758:     	b	0x101534760 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1538>
10153475c:     	mov	x19, x0
101534760:     	cbz	w22, 0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
101534764:     	ldr	x8, [sp, #0x230]
101534768:     	cbz	x8, 0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
10153476c:     	add	x0, sp, #0x230
101534770:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101534774:     	b	0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
101534778:     	add	x8, x24, x27
10153477c:     	ldr	q0, [sp, #0x400]
101534780:     	ldr	q1, [sp, #0x410]
101534784:     	ldr	q2, [sp, #0x420]
101534788:     	ldr	q3, [sp, #0x430]
10153478c:     	stp	q2, q3, [x8, #0x20]
101534790:     	stp	q0, q1, [x8]
101534794:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
101534798:     	mov	x19, x0
10153479c:     	tbnz	w26, #0x0, 0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
1015347a0:     	add	x0, sp, #0x400
1015347a4:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015347a8:     	b	0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
1015347ac:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015347b0:     	mov	x19, x0
1015347b4:     	ldr	w8, [sp, #0x400]
1015347b8:     	cmp	w8, #0x6
1015347bc:     	b.eq	0x1015347dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x15b4>
1015347c0:     	add	x0, sp, #0x400
1015347c4:     	bl	0x10152bff0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015347c8:     	mov	x0, x19
1015347cc:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
1015347d0:     	mov	x19, x0
1015347d4:     	add	x0, sp, #0xf8
1015347d8:     	bl	0x10152c184 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015347dc:     	mov	x0, x19
1015347e0:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
