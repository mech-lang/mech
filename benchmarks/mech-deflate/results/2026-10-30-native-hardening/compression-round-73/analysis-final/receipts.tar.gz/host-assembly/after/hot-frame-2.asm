
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014c8df4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_>:
1014c8df4:     	sub	sp, sp, #0x150
1014c8df8:     	stp	x28, x27, [sp, #0xf0]
1014c8dfc:     	stp	x26, x25, [sp, #0x100]
1014c8e00:     	stp	x24, x23, [sp, #0x110]
1014c8e04:     	stp	x22, x21, [sp, #0x120]
1014c8e08:     	stp	x20, x19, [sp, #0x130]
1014c8e0c:     	stp	x29, x30, [sp, #0x140]
1014c8e10:     	add	x29, sp, #0x140
1014c8e14:     	mov	x21, x2
1014c8e18:     	mov	x24, x1
1014c8e1c:     	str	x8, [sp, #0x40]
1014c8e20:     	ldr	x8, [x0, #0x8]
1014c8e24:     	str	x0, [sp, #0x50]
1014c8e28:     	cbz	x8, 0x1014c8fb8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1c4>
1014c8e2c:     	ldr	x20, [x0]
1014c8e30:     	lsl	x22, x8, #2
1014c8e34:     	ldp	x8, x19, [x24, #0x10]
1014c8e38:     	add	x10, x8, #0x10
1014c8e3c:     	ldp	x25, x8, [x21]
1014c8e40:     	ldp	x9, x11, [x21, #0x28]
1014c8e44:     	stp	x11, x9, [sp, #0x28]
1014c8e48:     	ldp	x9, x11, [x21, #0x10]
1014c8e4c:     	str	x11, [sp, #0x38]
1014c8e50:     	stp	x10, x9, [sp, #0x18]
1014c8e54:     	stp	x8, x19, [sp, #0x8]
1014c8e58:     	add	x26, x8, #0x1
1014c8e5c:     	mov	w8, #0x2c               ; =44
1014c8e60:     	ldr	w23, [x20], #0x4
1014c8e64:     	cmp	x19, x23
1014c8e68:     	b.ls	0x1014c9320 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c8e6c:     	strb	w8, [sp, #0x90]
1014c8e70:     	add	x0, sp, #0x90
1014c8e74:     	bl	0x1014cc1dc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c8e78:     	sub	x26, x26, #0x1
1014c8e7c:     	cbz	x26, 0x1014c93a4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5b0>
1014c8e80:     	ldrb	w8, [x25]
1014c8e84:     	cmp	w8, #0x3
1014c8e88:     	b.ne	0x1014c8ebc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0xc8>
1014c8e8c:     	ldr	x0, [x25, #0x8]
1014c8e90:     	ldr	x8, [sp, #0x38]
1014c8e94:     	cmp	x0, x8
1014c8e98:     	b.hs	0x1014c93e8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5f4>
1014c8e9c:     	ldr	x8, [sp, #0x30]
1014c8ea0:     	cmp	x0, x8
1014c8ea4:     	b.hs	0x1014c93f8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x604>
1014c8ea8:     	lsl	x8, x0, #6
1014c8eac:     	ldr	x9, [sp, #0x20]
1014c8eb0:     	ldr	x8, [x9, x8]
1014c8eb4:     	cbnz	x8, 0x1014c8ef4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x100>
1014c8eb8:     	b	0x1014c8efc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014c8ebc:     	ldp	q0, q1, [x25]
1014c8ec0:     	stp	q0, q1, [sp, #0x90]
1014c8ec4:     	ldr	x8, [sp, #0x28]
1014c8ec8:     	ldr	x8, [x8]
1014c8ecc:     	ldr	x1, [x8]
1014c8ed0:     	add	x0, sp, #0x68
1014c8ed4:     	add	x2, sp, #0x90
1014c8ed8:     	bl	0x1014cf64c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c8edc:     	ldr	x8, [sp, #0x68]
1014c8ee0:     	cmp	x8, #0x1
1014c8ee4:     	b.ne	0x1014c8efc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014c8ee8:     	ldr	x8, [sp, #0x70]
1014c8eec:     	cbz	x8, 0x1014c8efc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x108>
1014c8ef0:     	ldr	x8, [x8]
1014c8ef4:     	ldp	x19, x28, [x8, #0x10]
1014c8ef8:     	b	0x1014c8f04 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x110>
1014c8efc:     	mov	x28, #0x0               ; =0
1014c8f00:     	mov	w19, #0x8               ; =8
1014c8f04:     	mov	x1, x27
1014c8f08:     	lsl	x27, x28, #3
1014c8f0c:     	lsr	x8, x28, #61
1014c8f10:     	cmp	x8, #0x0
1014c8f14:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1014c8f18:     	ccmp	x27, x8, #0x2, eq
1014c8f1c:     	b.hi	0x1014c8fe4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1f0>
1014c8f20:     	str	x24, [sp, #0x48]
1014c8f24:     	cbz	x27, 0x1014c8f5c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x168>
1014c8f28:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014c8f2c:     	mov	x0, x27
1014c8f30:     	mov	w1, #0x8                ; =8
1014c8f34:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
1014c8f38:     	cbz	x0, 0x1014c9408 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x614>
1014c8f3c:     	mov	x24, x0
1014c8f40:     	cbz	x28, 0x1014c8f54 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x160>
1014c8f44:     	mov	x0, x24
1014c8f48:     	mov	x1, x19
1014c8f4c:     	mov	x2, x27
1014c8f50:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
1014c8f54:     	mov	x27, x24
1014c8f58:     	b	0x1014c8f64 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x170>
1014c8f5c:     	mov	w27, #0x8               ; =8
1014c8f60:     	mov	w24, #0x8               ; =8
1014c8f64:     	ldr	x8, [sp, #0x18]
1014c8f68:     	add	x0, x8, x23, lsl #7
1014c8f6c:     	add	x8, sp, #0x90
1014c8f70:     	mov	x1, x24
1014c8f74:     	mov	x2, x28
1014c8f78:     	bl	0x102dadf2c <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
1014c8f7c:     	ldr	x8, [sp, #0x90]
1014c8f80:     	cmp	x8, #0x1e
1014c8f84:     	b.ne	0x1014c9300 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x50c>
1014c8f88:     	ldr	x8, [sp, #0xa0]
1014c8f8c:     	cbz	x8, 0x1014c8fa0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1ac>
1014c8f90:     	ldr	x0, [sp, #0x98]
1014c8f94:     	lsl	x1, x8, #3
1014c8f98:     	mov	w2, #0x8                ; =8
1014c8f9c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c8fa0:     	add	x25, x25, #0x20
1014c8fa4:     	sub	x22, x22, #0x4
1014c8fa8:     	ldp	x24, x0, [sp, #0x48]
1014c8fac:     	ldr	x19, [sp, #0x10]
1014c8fb0:     	mov	w8, #0x2c               ; =44
1014c8fb4:     	cbnz	x22, 0x1014c8e60 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x6c>
1014c8fb8:     	ldr	x25, [x0, #0x30]
1014c8fbc:     	lsl	x19, x25, #3
1014c8fc0:     	lsr	x8, x25, #61
1014c8fc4:     	cmp	x8, #0x0
1014c8fc8:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
1014c8fcc:     	ccmp	x19, x8, #0x2, eq
1014c8fd0:     	b.ls	0x1014c8fec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1f8>
1014c8fd4:     	mov	x24, #0x0               ; =0
1014c8fd8:     	mov	x0, x24
1014c8fdc:     	mov	x1, x19
1014c8fe0:     	bl	0x103a077dc <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014c8fe4:     	mov	x0, #0x0                ; =0
1014c8fe8:     	bl	0x103a077dc <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014c8fec:     	str	x24, [sp, #0x48]
1014c8ff0:     	cbz	x19, 0x1014c902c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x238>
1014c8ff4:     	mov	x20, x0
1014c8ff8:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
1014c8ffc:     	mov	w24, #0x8               ; =8
1014c9000:     	mov	x0, x19
1014c9004:     	mov	w1, #0x8                ; =8
1014c9008:     	bl	0x1000096b8 <__RNvCsfBzVIH1HIC6_7___rustc19___rust_alloc_zeroed>
1014c900c:     	str	x0, [sp, #0x38]
1014c9010:     	cbz	x0, 0x1014c8fd8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x1e4>
1014c9014:     	ldp	x24, x8, [x20, #0x10]
1014c9018:     	lsl	x9, x8, #6
1014c901c:     	sub	x9, x9, x8, lsl #3
1014c9020:     	stp	x25, x9, [sp, #0x18]
1014c9024:     	cbnz	x8, 0x1014c9048 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x254>
1014c9028:     	b	0x1014c9154 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014c902c:     	mov	w8, #0x8                ; =8
1014c9030:     	str	x8, [sp, #0x38]
1014c9034:     	ldp	x24, x8, [x0, #0x10]
1014c9038:     	lsl	x9, x8, #6
1014c903c:     	sub	x9, x9, x8, lsl #3
1014c9040:     	stp	xzr, x9, [sp, #0x18]
1014c9044:     	cbz	x8, 0x1014c9154 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014c9048:     	ldp	x22, x26, [x21]
1014c904c:     	add	x28, x24, #0x18
1014c9050:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c9054:     	add	x8, x8, #0x968
1014c9058:     	str	x8, [sp, #0x10]
1014c905c:     	ldp	x8, x9, [x21, #0x28]
1014c9060:     	stp	x9, x8, [sp, #0x28]
1014c9064:     	ldr	x20, [sp, #0x20]
1014c9068:     	ldp	x23, x27, [x21, #0x10]
1014c906c:     	b	0x1014c9084 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x290>
1014c9070:     	ldr	x8, [sp, #0x38]
1014c9074:     	str	x1, [x8, x0, lsl #3]
1014c9078:     	add	x28, x28, #0x38
1014c907c:     	subs	x20, x20, #0x38
1014c9080:     	b.eq	0x1014c9154 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x360>
1014c9084:     	ldr	x0, [x28, #0x18]
1014c9088:     	cmp	x0, x26
1014c908c:     	b.hs	0x1014c93d8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5e4>
1014c9090:     	add	x8, x22, x0, lsl #5
1014c9094:     	ldrb	w9, [x8]
1014c9098:     	cmp	w9, #0x3
1014c909c:     	b.ne	0x1014c90c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x2d4>
1014c90a0:     	ldr	x0, [x8, #0x8]
1014c90a4:     	cmp	x0, x27
1014c90a8:     	b.hs	0x1014c93b8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5c4>
1014c90ac:     	ldr	x8, [sp, #0x30]
1014c90b0:     	cmp	x0, x8
1014c90b4:     	b.hs	0x1014c93c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5d4>
1014c90b8:     	lsl	x8, x0, #6
1014c90bc:     	ldr	x19, [x23, x8]
1014c90c0:     	cbnz	x19, 0x1014c90fc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x308>
1014c90c4:     	b	0x1014c92bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c90c8:     	ldp	q0, q1, [x8]
1014c90cc:     	stp	q0, q1, [sp, #0x90]
1014c90d0:     	ldr	x8, [sp, #0x28]
1014c90d4:     	ldr	x8, [x8]
1014c90d8:     	ldr	x1, [x8]
1014c90dc:     	add	x0, sp, #0x68
1014c90e0:     	add	x2, sp, #0x90
1014c90e4:     	bl	0x1014cf64c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c90e8:     	ldp	x9, x8, [sp, #0x68]
1014c90ec:     	cmp	x9, #0x1
1014c90f0:     	ccmp	x8, #0x0, #0x4, eq
1014c90f4:     	b.eq	0x1014c92bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c90f8:     	ldr	x19, [x8]
1014c90fc:     	mov	w8, #0x2c               ; =44
1014c9100:     	strb	w8, [sp, #0x90]
1014c9104:     	add	x0, sp, #0x90
1014c9108:     	bl	0x1014cc1dc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c910c:     	add	x8, sp, #0x90
1014c9110:     	add	x0, x19, #0x10
1014c9114:     	mov	x1, x28
1014c9118:     	bl	0x102e3238c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c911c:     	ldp	x8, x1, [sp, #0x90]
1014c9120:     	cmp	x8, #0x1e
1014c9124:     	b.ne	0x1014c92a0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4ac>
1014c9128:     	ldur	w8, [x28, #-0x18]
1014c912c:     	cmp	w8, #0x2
1014c9130:     	b.ne	0x1014c9078 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x284>
1014c9134:     	ldur	w0, [x28, #-0x14]
1014c9138:     	cmp	x25, x0
1014c913c:     	b.hi	0x1014c9070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x27c>
1014c9140:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c9144:     	add	x2, x2, #0x920
1014c9148:     	mov	x1, x25
1014c914c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c9150:     	b	0x1014c9450 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x65c>
1014c9154:     	ldp	x9, x8, [sp, #0x48]
1014c9158:     	ldr	w19, [x8, #0x38]
1014c915c:     	ldr	x8, [x9, #0x18]
1014c9160:     	cmp	x8, x19
1014c9164:     	b.ls	0x1014c92bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c9168:     	ldr	x20, [x9, #0x10]
1014c916c:     	mov	w8, #0x2c               ; =44
1014c9170:     	strb	w8, [sp, #0x90]
1014c9174:     	add	x0, sp, #0x90
1014c9178:     	bl	0x1014cc1dc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c917c:     	add	x9, x20, x19, lsl #7
1014c9180:     	add	x8, sp, #0x68
1014c9184:     	add	x0, x9, #0x10
1014c9188:     	ldr	x1, [sp, #0x38]
1014c918c:     	mov	x2, x25
1014c9190:     	bl	0x102dadf2c <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
1014c9194:     	ldr	x8, [sp, #0x68]
1014c9198:     	cmp	x8, #0x1e
1014c919c:     	b.ne	0x1014c92e4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4f0>
1014c91a0:     	ldp	x8, x20, [sp, #0x70]
1014c91a4:     	str	x8, [sp, #0x38]
1014c91a8:     	stp	x8, x20, [sp, #0x58]
1014c91ac:     	ldp	x25, x22, [x21]
1014c91b0:     	ldp	x28, x9, [x21, #0x28]
1014c91b4:     	ldp	x21, x26, [x21, #0x10]
1014c91b8:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c91bc:     	add	x8, x8, #0x968
1014c91c0:     	stp	x8, x9, [sp, #0x48]
1014c91c4:     	ldr	x27, [sp, #0x20]
1014c91c8:     	cbz	x27, 0x1014c934c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x558>
1014c91cc:     	ldr	x0, [x24, #0x30]
1014c91d0:     	cmp	x0, x22
1014c91d4:     	b.hs	0x1014c9414 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x620>
1014c91d8:     	add	x8, x25, x0, lsl #5
1014c91dc:     	ldrb	w9, [x8]
1014c91e0:     	cmp	w9, #0x3
1014c91e4:     	b.ne	0x1014c920c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x418>
1014c91e8:     	ldr	x0, [x8, #0x8]
1014c91ec:     	cmp	x0, x26
1014c91f0:     	b.hs	0x1014c941c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x628>
1014c91f4:     	cmp	x0, x28
1014c91f8:     	b.hs	0x1014c9430 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x63c>
1014c91fc:     	lsl	x8, x0, #6
1014c9200:     	ldr	x19, [x21, x8]
1014c9204:     	cbnz	x19, 0x1014c9244 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x450>
1014c9208:     	b	0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c920c:     	ldp	q0, q1, [x8]
1014c9210:     	stp	q0, q1, [sp, #0x90]
1014c9214:     	ldr	x8, [sp, #0x50]
1014c9218:     	ldr	x8, [x8]
1014c921c:     	ldr	x1, [x8]
1014c9220:     	sub	x0, x29, #0x70
1014c9224:     	add	x2, sp, #0x90
1014c9228:     	bl	0x1014cf64c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c922c:     	ldur	x8, [x29, #-0x70]
1014c9230:     	cmp	x8, #0x1
1014c9234:     	b.ne	0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c9238:     	ldur	x8, [x29, #-0x68]
1014c923c:     	cbz	x8, 0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c9240:     	ldr	x19, [x8]
1014c9244:     	mov	w8, #0x2c               ; =44
1014c9248:     	strb	w8, [sp, #0x90]
1014c924c:     	add	x0, sp, #0x90
1014c9250:     	bl	0x1014cc1dc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1014c9254:     	add	x8, sp, #0x68
1014c9258:     	add	x0, x19, #0x10
1014c925c:     	add	x1, x24, #0x18
1014c9260:     	bl	0x102e3238c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c9264:     	ldp	x8, x23, [sp, #0x68]
1014c9268:     	cmp	x8, #0x1e
1014c926c:     	b.ne	0x1014c9354 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x560>
1014c9270:     	add	x8, sp, #0x90
1014c9274:     	add	x0, sp, #0x58
1014c9278:     	mov	x1, x24
1014c927c:     	bl	0x102e3238c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c9280:     	ldp	x8, x1, [sp, #0x90]
1014c9284:     	cmp	x8, #0x1e
1014c9288:     	b.ne	0x1014c9370 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x57c>
1014c928c:     	add	x24, x24, #0x38
1014c9290:     	sub	x27, x27, #0x38
1014c9294:     	cmp	x1, x23
1014c9298:     	b.eq	0x1014c91c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x3d4>
1014c929c:     	b	0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c92a0:     	and	x8, x8, #0x1e
1014c92a4:     	cmp	x8, #0x14
1014c92a8:     	b.ne	0x1014c92bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c92ac:     	cbz	x1, 0x1014c92bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4c8>
1014c92b0:     	ldr	x0, [sp, #0xa0]
1014c92b4:     	mov	w2, #0x1                ; =1
1014c92b8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c92bc:     	mov	w8, #0x2c               ; =44
1014c92c0:     	ldr	x9, [sp, #0x40]
1014c92c4:     	strb	w8, [x9]
1014c92c8:     	ldr	x8, [sp, #0x18]
1014c92cc:     	cbz	x8, 0x1014c932c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014c92d0:     	lsl	x1, x8, #3
1014c92d4:     	ldr	x0, [sp, #0x38]
1014c92d8:     	mov	w2, #0x8                ; =8
1014c92dc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c92e0:     	b	0x1014c932c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014c92e4:     	and	x8, x8, #0x1e
1014c92e8:     	cmp	x8, #0x14
1014c92ec:     	b.ne	0x1014c9320 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c92f0:     	ldr	x1, [sp, #0x70]
1014c92f4:     	cbz	x1, 0x1014c9320 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c92f8:     	ldr	x0, [sp, #0x78]
1014c92fc:     	b	0x1014c9318 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x524>
1014c9300:     	and	x8, x8, #0x1e
1014c9304:     	cmp	x8, #0x14
1014c9308:     	b.ne	0x1014c9320 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c930c:     	ldr	x1, [sp, #0x98]
1014c9310:     	cbz	x1, 0x1014c9320 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x52c>
1014c9314:     	ldr	x0, [sp, #0xa0]
1014c9318:     	mov	w2, #0x1                ; =1
1014c931c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c9320:     	mov	w8, #0x2c               ; =44
1014c9324:     	ldr	x9, [sp, #0x40]
1014c9328:     	strb	w8, [x9]
1014c932c:     	ldp	x29, x30, [sp, #0x140]
1014c9330:     	ldp	x20, x19, [sp, #0x130]
1014c9334:     	ldp	x22, x21, [sp, #0x120]
1014c9338:     	ldp	x24, x23, [sp, #0x110]
1014c933c:     	ldp	x26, x25, [sp, #0x100]
1014c9340:     	ldp	x28, x27, [sp, #0xf0]
1014c9344:     	add	sp, sp, #0x150
1014c9348:     	ret
1014c934c:     	mov	w8, #0x2e               ; =46
1014c9350:     	b	0x1014c9390 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x59c>
1014c9354:     	and	x8, x8, #0x1e
1014c9358:     	cmp	x8, #0x14
1014c935c:     	b.ne	0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c9360:     	cbz	x23, 0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c9364:     	ldr	x0, [sp, #0x78]
1014c9368:     	mov	x1, x23
1014c936c:     	b	0x1014c9384 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x590>
1014c9370:     	and	x8, x8, #0x1e
1014c9374:     	cmp	x8, #0x14
1014c9378:     	b.ne	0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c937c:     	cbz	x1, 0x1014c938c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x598>
1014c9380:     	ldr	x0, [sp, #0xa0]
1014c9384:     	mov	w2, #0x1                ; =1
1014c9388:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c938c:     	mov	w8, #0x2c               ; =44
1014c9390:     	ldr	x9, [sp, #0x40]
1014c9394:     	strb	w8, [x9]
1014c9398:     	cbz	x20, 0x1014c932c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x538>
1014c939c:     	lsl	x1, x20, #3
1014c93a0:     	b	0x1014c92d4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x4e0>
1014c93a4:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c93a8:     	add	x2, x2, #0x968
1014c93ac:     	ldr	x0, [sp, #0x8]
1014c93b0:     	mov	x1, x0
1014c93b4:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c93b8:     	mov	x26, x27
1014c93bc:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c93c0:     	add	x8, x8, #0x980
1014c93c4:     	b	0x1014c93d4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x5e0>
1014c93c8:     	ldr	x26, [sp, #0x30]
1014c93cc:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c93d0:     	add	x8, x8, #0x998
1014c93d4:     	str	x8, [sp, #0x10]
1014c93d8:     	mov	x1, x26
1014c93dc:     	ldr	x2, [sp, #0x10]
1014c93e0:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c93e4:     	b	0x1014c9450 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x65c>
1014c93e8:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c93ec:     	add	x2, x2, #0x980
1014c93f0:     	ldr	x1, [sp, #0x38]
1014c93f4:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c93f8:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c93fc:     	add	x2, x2, #0x998
1014c9400:     	ldr	x1, [sp, #0x30]
1014c9404:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c9408:     	mov	x1, x27
1014c940c:     	mov	w0, #0x8                ; =8
1014c9410:     	bl	0x103a077dc <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
1014c9414:     	str	x20, [sp, #0x18]
1014c9418:     	b	0x1014c9444 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x650>
1014c941c:     	str	x20, [sp, #0x18]
1014c9420:     	mov	x22, x26
1014c9424:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c9428:     	add	x8, x8, #0x980
1014c942c:     	b	0x1014c9440 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x64c>
1014c9430:     	str	x20, [sp, #0x18]
1014c9434:     	mov	x22, x28
1014c9438:     	adrp	x8, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c943c:     	add	x8, x8, #0x998
1014c9440:     	str	x8, [sp, #0x48]
1014c9444:     	mov	x1, x22
1014c9448:     	ldr	x2, [sp, #0x48]
1014c944c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c9450:     	brk	#0x1
1014c9454:     	b	0x1014c946c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x678>
1014c9458:     	mov	x21, x0
1014c945c:     	str	x20, [sp, #0x18]
1014c9460:     	cbnz	x20, 0x1014c9478 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x684>
1014c9464:     	b	0x1014c948c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x698>
1014c9468:     	b	0x1014c946c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x678>
1014c946c:     	mov	x21, x0
1014c9470:     	ldr	x8, [sp, #0x18]
1014c9474:     	cbz	x8, 0x1014c948c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_+0x698>
1014c9478:     	ldr	x8, [sp, #0x18]
1014c947c:     	lsl	x1, x8, #3
1014c9480:     	ldr	x0, [sp, #0x38]
1014c9484:     	mov	w2, #0x8                ; =8
1014c9488:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c948c:     	mov	x0, x21
1014c9490:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
