
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010161a988 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>:
10161a988:     	sub	sp, sp, #0x1d0
10161a98c:     	stp	x28, x27, [sp, #0x170]
10161a990:     	stp	x26, x25, [sp, #0x180]
10161a994:     	stp	x24, x23, [sp, #0x190]
10161a998:     	stp	x22, x21, [sp, #0x1a0]
10161a99c:     	stp	x20, x19, [sp, #0x1b0]
10161a9a0:     	stp	x29, x30, [sp, #0x1c0]
10161a9a4:     	add	x29, sp, #0x1c0
10161a9a8:     	mov	x25, x6
10161a9ac:     	mov	x26, x4
10161a9b0:     	mov	x23, x3
10161a9b4:     	mov	x22, x2
10161a9b8:     	mov	x24, x1
10161a9bc:     	mov	x20, x0
10161a9c0:     	mov	x19, x8
10161a9c4:     	ldr	x21, [x29, #0x10]
10161a9c8:     	stp	x5, x6, [sp]
10161a9cc:     	str	x7, [sp, #0x10]
10161a9d0:     	add	x27, sp, #0x80
10161a9d4:     	ldr	w0, [x0, #0x110]
10161a9d8:     	add	x8, sp, #0xc8
10161a9dc:     	mov	x1, x21
10161a9e0:     	bl	0x1027db718 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
10161a9e4:     	ldrb	w8, [sp, #0xc8]
10161a9e8:     	cmp	w8, #0x29
10161a9ec:     	b.ne	0x10161aa40 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb8>
10161a9f0:     	ldr	x28, [x20, #0x1d8]
10161a9f4:     	cbz	x28, 0x10161aa60 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xd8>
10161a9f8:     	mov	w27, #0x2c              ; =44
10161a9fc:     	strb	w27, [sp, #0xc8]
10161aa00:     	add	x0, sp, #0xc8
10161aa04:     	bl	0x1016209f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10161aa08:     	cmp	x22, x26
10161aa0c:     	b.ne	0x10161aa38 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb0>
10161aa10:     	ldr	x8, [x20, #0x78]
10161aa14:     	cmp	x22, x8
10161aa18:     	b.ne	0x10161aa38 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xb0>
10161aa1c:     	cmp	x25, #0x0
10161aa20:     	cset	w8, ne
10161aa24:     	ldr	x9, [x20, #0x10]
10161aa28:     	cmp	x9, #0xb
10161aa2c:     	cset	w9, eq
10161aa30:     	eor	w8, w8, w9
10161aa34:     	tbz	w8, #0x0, 0x10161aa88 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x100>
10161aa38:     	strb	w27, [x19]
10161aa3c:     	b	0x10161aa68 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10161aa40:     	ldur	q0, [x27, #0x48]
10161aa44:     	ldur	q1, [x27, #0x58]
10161aa48:     	stp	q0, q1, [x19]
10161aa4c:     	ldur	q0, [x27, #0x68]
10161aa50:     	str	q0, [x19, #0x20]
10161aa54:     	ldr	x8, [sp, #0xf8]
10161aa58:     	str	x8, [x19, #0x30]
10161aa5c:     	b	0x10161aa68 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10161aa60:     	mov	w8, #0x2c               ; =44
10161aa64:     	strb	w8, [x19]
10161aa68:     	ldp	x29, x30, [sp, #0x1c0]
10161aa6c:     	ldp	x20, x19, [sp, #0x1b0]
10161aa70:     	ldp	x22, x21, [sp, #0x1a0]
10161aa74:     	ldp	x24, x23, [sp, #0x190]
10161aa78:     	ldp	x26, x25, [sp, #0x180]
10161aa7c:     	ldp	x28, x27, [sp, #0x170]
10161aa80:     	add	sp, sp, #0x1d0
10161aa84:     	ret
10161aa88:     	ldp	x8, x9, [x28, #0x10]
10161aa8c:     	stp	x8, x9, [sp, #0x18]
10161aa90:     	stp	x24, x22, [sp, #0x28]
10161aa94:     	stp	x23, x22, [sp, #0x38]
10161aa98:     	mov	x10, sp
10161aa9c:     	str	x10, [sp, #0x48]
10161aaa0:     	ldr	x10, [x21, #0x60]
10161aaa4:     	cmp	x10, #0x1
10161aaa8:     	b.ne	0x10161abb8 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x230>
10161aaac:     	ldr	w10, [x21, #0x50]
10161aab0:     	add	x22, sp, #0x80
10161aab4:     	tbz	w10, #0x0, 0x10161abc4 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x23c>
10161aab8:     	ldp	x11, x10, [x29, #0x18]
10161aabc:     	ldr	x12, [x21, #0x68]
10161aac0:     	ldr	x13, [x21, #0x58]
10161aac4:     	ldp	x14, x15, [x28, #0x20]
10161aac8:     	add	x16, x28, #0x50
10161aacc:     	add	x17, x28, #0x30
10161aad0:     	add	x0, x28, #0x38
10161aad4:     	add	x1, x28, #0x40
10161aad8:     	add	x2, x28, #0x48
10161aadc:     	stp	x12, x13, [sp, #0xb8]
10161aae0:     	add	x12, sp, #0xb8
10161aae4:     	stp	x11, x12, [sp, #0xc8]
10161aae8:     	add	x12, sp, #0xc0
10161aaec:     	stp	x12, x11, [sp, #0xd8]
10161aaf0:     	stp	x21, x10, [sp, #0xe8]
10161aaf4:     	stp	x8, x9, [sp, #0xf8]
10161aaf8:     	stp	x14, x15, [sp, #0x108]
10161aafc:     	stp	x16, x28, [sp, #0x118]
10161ab00:     	stp	x17, x0, [sp, #0x128]
10161ab04:     	stp	x1, x2, [sp, #0x138]
10161ab08:     	add	x8, sp, #0x8
10161ab0c:     	stp	x8, x20, [sp, #0x148]
10161ab10:     	add	x8, sp, #0x18
10161ab14:     	str	x8, [sp, #0x158]
10161ab18:     	adrp	x0, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
10161ab1c:     	add	x0, x0, #0x5d8
10161ab20:     	add	x8, sp, #0x80
10161ab24:     	add	x1, sp, #0xc8
10161ab28:     	bl	0x1015c96f8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
10161ab2c:     	ldrb	w8, [sp, #0x80]
10161ab30:     	cmp	w8, #0x2f
10161ab34:     	b.ne	0x10161ab80 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0x1f8>
10161ab38:     	ldur	q0, [x22, #0x8]
10161ab3c:     	stur	q0, [sp, #0x57]
10161ab40:     	ldur	q1, [x22, #0x18]
10161ab44:     	stur	q1, [sp, #0x67]
10161ab48:     	ldr	x8, [sp, #0xa8]
10161ab4c:     	stur	x8, [sp, #0x77]
10161ab50:     	stur	q0, [x22, #0x4f]
10161ab54:     	stur	q1, [x22, #0x5f]
10161ab58:     	stur	x8, [x22, #0x6f]
10161ab5c:     	mov	w8, #0x29               ; =41
10161ab60:     	strb	w8, [x19]
10161ab64:     	ldur	q0, [x22, #0x48]
10161ab68:     	stur	q0, [x19, #0x1]
10161ab6c:     	ldur	q0, [x22, #0x58]
10161ab70:     	stur	q0, [x19, #0x11]
10161ab74:     	ldur	q0, [x22, #0x67]
10161ab78:     	str	q0, [x19, #0x20]
10161ab7c:     	b	0x10161aa68 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10161ab80:     	ldr	q0, [sp, #0xa0]
10161ab84:     	stur	q0, [sp, #0x6f]
10161ab88:     	ldur	q0, [x22, #0x11]
10161ab8c:     	ldur	q1, [x22, #0x1]
10161ab90:     	stp	q1, q0, [sp, #0x50]
10161ab94:     	ldr	x9, [sp, #0xb0]
10161ab98:     	strb	w8, [x19]
10161ab9c:     	stur	q1, [x19, #0x1]
10161aba0:     	ldr	q0, [sp, #0x60]
10161aba4:     	stur	q0, [x19, #0x11]
10161aba8:     	ldur	q0, [sp, #0x6f]
10161abac:     	str	q0, [x19, #0x20]
10161abb0:     	str	x9, [x19, #0x30]
10161abb4:     	b	0x10161aa68 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_+0xe0>
10161abb8:     	adrp	x0, 0x107f13000 <_anon.05a6795a892e9990141ceecb5b939896.82+0x2e0>
10161abbc:     	add	x0, x0, #0x980
10161abc0:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10161abc4:     	adrp	x0, 0x107f13000 <_anon.05a6795a892e9990141ceecb5b939896.82+0x2e0>
10161abc8:     	add	x0, x0, #0x998
10161abcc:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
