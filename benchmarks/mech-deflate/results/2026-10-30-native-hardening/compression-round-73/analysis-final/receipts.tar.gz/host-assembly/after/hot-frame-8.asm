
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015c3910 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>:
1015c3910:     	sub	sp, sp, #0x110
1015c3914:     	stp	x28, x27, [sp, #0xb0]
1015c3918:     	stp	x26, x25, [sp, #0xc0]
1015c391c:     	stp	x24, x23, [sp, #0xd0]
1015c3920:     	stp	x22, x21, [sp, #0xe0]
1015c3924:     	stp	x20, x19, [sp, #0xf0]
1015c3928:     	stp	x29, x30, [sp, #0x100]
1015c392c:     	add	x29, sp, #0x100
1015c3930:     	stp	x6, x0, [sp, #0x8]
1015c3934:     	mov	x22, x3
1015c3938:     	mov	x25, x1
1015c393c:     	mov	x19, #0x0               ; =0
1015c3940:     	mov	x26, #0x0               ; =0
1015c3944:     	mov	x23, #0x0               ; =0
1015c3948:     	mov	x24, #0x0               ; =0
1015c394c:     	ldp	x27, x9, [x4]
1015c3950:     	ldr	x10, [x4, #0x30]
1015c3954:     	ldp	x8, x11, [x4, #0x10]
1015c3958:     	stp	x11, x5, [sp, #0x38]
1015c395c:     	str	x8, [sp, #0x20]
1015c3960:     	ldp	x8, x11, [x4, #0x20]
1015c3964:     	stp	x11, x10, [sp, #0x28]
1015c3968:     	str	x8, [sp, #0x18]
1015c396c:     	lsl	x8, x2, #7
1015c3970:     	sub	x28, x8, x2, lsl #3
1015c3974:     	str	x9, [sp]
1015c3978:     	add	x21, x9, #0x1
1015c397c:     	cmp	x28, x19
1015c3980:     	b.eq	0x1015c3b38 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x228>
1015c3984:     	subs	x21, x21, #0x1
1015c3988:     	b.eq	0x1015c3bd0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2c0>
1015c398c:     	ldrb	w8, [x27]
1015c3990:     	cmp	w8, #0x3
1015c3994:     	b.ne	0x1015c3a6c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x15c>
1015c3998:     	ldr	x0, [x27, #0x8]
1015c399c:     	ldr	x8, [sp, #0x38]
1015c39a0:     	cmp	x0, x8
1015c39a4:     	b.hs	0x1015c3be4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2d4>
1015c39a8:     	ldr	x8, [sp, #0x28]
1015c39ac:     	cmp	x0, x8
1015c39b0:     	b.hs	0x1015c3bf4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2e4>
1015c39b4:     	ldp	x9, x8, [sp, #0x18]
1015c39b8:     	add	x20, x8, x0, lsl #6
1015c39bc:     	ldr	x8, [x20]
1015c39c0:     	ldr	x10, [x9, x0, lsl #3]
1015c39c4:     	cbz	x8, 0x1015c3aa0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x190>
1015c39c8:     	cbnz	x10, 0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c39cc:     	ldr	w9, [x20, #0x38]
1015c39d0:     	add	x8, x25, x19
1015c39d4:     	ldr	w10, [x8, #0x70]
1015c39d8:     	cmp	w9, w10
1015c39dc:     	b.ne	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c39e0:     	ldp	q0, q1, [x20, #0x10]
1015c39e4:     	stp	q0, q1, [sp, #0x60]
1015c39e8:     	ldp	x9, x10, [sp, #0x60]
1015c39ec:     	ldp	x11, x12, [x8, #0x50]
1015c39f0:     	ldp	x13, x14, [sp, #0x70]
1015c39f4:     	ldp	x15, x8, [x8, #0x60]
1015c39f8:     	cmp	x9, x11
1015c39fc:     	ccmp	x10, x12, #0x0, eq
1015c3a00:     	ccmp	x13, x15, #0x0, eq
1015c3a04:     	ccmp	x14, x8, #0x0, eq
1015c3a08:     	b.ne	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3a0c:     	mov	x0, x20
1015c3a10:     	ldr	x1, [sp, #0x40]
1015c3a14:     	bl	0x102e16620 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
1015c3a18:     	cmp	x0, #0x1
1015c3a1c:     	b.ne	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3a20:     	add	x8, sp, #0x60
1015c3a24:     	mov	x0, x20
1015c3a28:     	mov	x1, x22
1015c3a2c:     	bl	0x102e14704 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
1015c3a30:     	ldrb	w8, [sp, #0x60]
1015c3a34:     	cmp	w8, #0x16
1015c3a38:     	b.ne	0x1015c3b70 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x260>
1015c3a3c:     	add	x8, sp, #0x60
1015c3a40:     	add	x0, x25, x19
1015c3a44:     	mov	x1, x20
1015c3a48:     	mov	x2, x22
1015c3a4c:     	bl	0x1023679c8 <__RNvMNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget15frame_footprintNtB2_28PreparedNativeFrameFootprint5value>
1015c3a50:     	ldr	w8, [sp, #0x60]
1015c3a54:     	tbz	w8, #0x0, 0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3a58:     	ldp	x9, x8, [sp, #0x70]
1015c3a5c:     	ldr	x10, [sp, #0x80]
1015c3a60:     	adds	x26, x9, x26
1015c3a64:     	b.lo	0x1015c3b14 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x204>
1015c3a68:     	b	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3a6c:     	ldp	q0, q1, [x27]
1015c3a70:     	stp	q0, q1, [sp, #0x60]
1015c3a74:     	ldr	x8, [sp, #0x30]
1015c3a78:     	ldr	x8, [x8]
1015c3a7c:     	ldr	x1, [x8]
1015c3a80:     	add	x0, sp, #0x48
1015c3a84:     	add	x2, sp, #0x60
1015c3a88:     	bl	0x1015dd604 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1015c3a8c:     	ldr	x8, [sp, #0x48]
1015c3a90:     	cmp	x8, #0x1
1015c3a94:     	b.ne	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3a98:     	ldp	x20, x10, [sp, #0x50]
1015c3a9c:     	cbnz	x20, 0x1015c39c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0xb8>
1015c3aa0:     	ldrb	w8, [x25, x19]
1015c3aa4:     	tbnz	w8, #0x0, 0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3aa8:     	add	x8, x25, x19
1015c3aac:     	ldrb	w11, [x8, #0x1]
1015c3ab0:     	ldp	x9, x8, [x8, #0x10]
1015c3ab4:     	cmp	w11, #0x3
1015c3ab8:     	b.gt	0x1015c3ad4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1c4>
1015c3abc:     	sub	w11, w11, #0x1
1015c3ac0:     	cmp	w11, #0x3
1015c3ac4:     	b.lo	0x1015c3b04 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1015c3ac8:     	cmp	x10, #0x2
1015c3acc:     	b.lo	0x1015c3b04 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1015c3ad0:     	b	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3ad4:     	cmp	w11, #0x4
1015c3ad8:     	b.eq	0x1015c3af0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1e0>
1015c3adc:     	cmp	w11, #0x5
1015c3ae0:     	b.ne	0x1015c3afc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1ec>
1015c3ae4:     	cmp	x10, #0x10, lsl #12     ; =0x10000
1015c3ae8:     	b.lo	0x1015c3b04 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1015c3aec:     	b	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3af0:     	cmp	x10, #0xff
1015c3af4:     	b.ls	0x1015c3b04 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
1015c3af8:     	b	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3afc:     	lsr	x10, x10, #32
1015c3b00:     	cbnz	x10, 0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3b04:     	add	x10, x25, x19
1015c3b08:     	ldr	x10, [x10, #0x20]
1015c3b0c:     	adds	x26, x9, x26
1015c3b10:     	b.hs	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3b14:     	adds	x23, x10, x23
1015c3b18:     	cset	w9, hs
1015c3b1c:     	adds	x24, x8, x24
1015c3b20:     	cset	w8, hs
1015c3b24:     	tbnz	w9, #0x0, 0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3b28:     	add	x27, x27, #0x20
1015c3b2c:     	add	x19, x19, #0x78
1015c3b30:     	tbz	w8, #0x0, 0x1015c397c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x6c>
1015c3b34:     	b	0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3b38:     	add	x8, sp, #0x60
1015c3b3c:     	ldr	x0, [sp, #0x8]
1015c3b40:     	mov	x1, x23
1015c3b44:     	mov	x2, x24
1015c3b48:     	bl	0x10237132c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter29try_charge_borrowed_footprint>
1015c3b4c:     	ldrb	w9, [sp, #0x60]
1015c3b50:     	ldrb	w8, [sp, #0x61]
1015c3b54:     	cmp	w9, #0x8
1015c3b58:     	b.ne	0x1015c3ba8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x298>
1015c3b5c:     	tbz	w8, #0x0, 0x1015c3b78 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1015c3b60:     	mov	w8, #0x1                ; =1
1015c3b64:     	ldr	x9, [sp, #0x10]
1015c3b68:     	stp	x8, x26, [x9, #0x8]
1015c3b6c:     	b	0x1015c3b80 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x270>
1015c3b70:     	add	x0, sp, #0x60
1015c3b74:     	bl	0x1015d5eec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
1015c3b78:     	ldr	x9, [sp, #0x10]
1015c3b7c:     	str	xzr, [x9, #0x8]
1015c3b80:     	mov	w8, #0x8                ; =8
1015c3b84:     	strb	w8, [x9]
1015c3b88:     	ldp	x29, x30, [sp, #0x100]
1015c3b8c:     	ldp	x20, x19, [sp, #0xf0]
1015c3b90:     	ldp	x22, x21, [sp, #0xe0]
1015c3b94:     	ldp	x24, x23, [sp, #0xd0]
1015c3b98:     	ldp	x26, x25, [sp, #0xc0]
1015c3b9c:     	ldp	x28, x27, [sp, #0xb0]
1015c3ba0:     	add	sp, sp, #0x110
1015c3ba4:     	ret
1015c3ba8:     	ldur	q0, [sp, #0x62]
1015c3bac:     	ldr	x11, [sp, #0x10]
1015c3bb0:     	stur	q0, [x11, #0x2]
1015c3bb4:     	ldur	q0, [sp, #0x72]
1015c3bb8:     	stur	q0, [x11, #0x12]
1015c3bbc:     	ldr	x10, [sp, #0x80]
1015c3bc0:     	str	x10, [x11, #0x20]
1015c3bc4:     	strb	w9, [x11]
1015c3bc8:     	strb	w8, [x11, #0x1]
1015c3bcc:     	b	0x1015c3b88 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x278>
1015c3bd0:     	adrp	x2, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015c3bd4:     	add	x2, x2, #0xa60
1015c3bd8:     	ldr	x0, [sp]
1015c3bdc:     	mov	x1, x0
1015c3be0:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c3be4:     	adrp	x2, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015c3be8:     	add	x2, x2, #0xa78
1015c3bec:     	ldr	x1, [sp, #0x38]
1015c3bf0:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015c3bf4:     	adrp	x2, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015c3bf8:     	add	x2, x2, #0xa90
1015c3bfc:     	ldr	x1, [sp, #0x28]
1015c3c00:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
