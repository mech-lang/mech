
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101548f20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>:
101548f20:     	stp	x28, x27, [sp, #-0x60]!
101548f24:     	stp	x26, x25, [sp, #0x10]
101548f28:     	stp	x24, x23, [sp, #0x20]
101548f2c:     	stp	x22, x21, [sp, #0x30]
101548f30:     	stp	x20, x19, [sp, #0x40]
101548f34:     	stp	x29, x30, [sp, #0x50]
101548f38:     	add	x29, sp, #0x50
101548f3c:     	sub	sp, sp, #0x800
101548f40:     	str	xzr, [sp]
101548f44:     	add	x9, x2, #0x1d
101548f48:     	cmp	x9, #0x1f
101548f4c:     	b.hi	0x101548f78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101548f50:     	mov	w10, #-0x10000001       ; =-268435457
101548f54:     	lsr	w10, w10, w9
101548f58:     	tbz	w10, #0x0, 0x101548f78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101548f5c:     	adrp	x10, 0x107557000 <_anon.99617498846789129750b3326436f5d5.850+0xd6c>
101548f60:     	add	x10, x10, #0x10
101548f64:     	ldr	x22, [x10, x9, lsl #3]
101548f68:     	ldr	x9, [x0, #0x238]
101548f6c:     	cmp	x9, #0x3
101548f70:     	b.ne	0x101548f8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6c>
101548f74:     	b	0x101548fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101548f78:     	sub	x21, x2, #0x3
101548f7c:     	mov	w22, #0x3               ; =3
101548f80:     	ldr	x9, [x0, #0x238]
101548f84:     	cmp	x9, #0x3
101548f88:     	b.eq	0x101548fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101548f8c:     	ldr	w9, [x0, #0x268]
101548f90:     	cbz	w9, 0x101548fb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101548f94:     	str	wzr, [x8]
101548f98:     	mov	w9, #0xc                ; =12
101548f9c:     	strb	w9, [x8, #0x8]
101548fa0:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548fa4:     	add	x9, x9, #0x867
101548fa8:     	mov	w10, #0x25              ; =37
101548fac:     	stp	x9, x10, [x8, #0x10]
101548fb0:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101548fb4:     	cmp	x22, #0xb
101548fb8:     	b.eq	0x101549090 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
101548fbc:     	add	x27, sp, #0x550
101548fc0:     	add	x28, sp, #0x440
101548fc4:     	add	x26, sp, #0x330
101548fc8:     	add	x25, sp, #0x220
101548fcc:     	cmp	x22, #0x1d
101548fd0:     	b.eq	0x101549024 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104>
101548fd4:     	cmp	x22, #0x1f
101548fd8:     	b.ne	0x1015490c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a0>
101548fdc:     	ldp	x20, x28, [x3]
101548fe0:     	ldr	x10, [x3, #0x10]
101548fe4:     	ldp	x12, x11, [x0, #0xc0]
101548fe8:     	ldp	x26, x19, [x0, #0xd0]
101548fec:     	ldp	x22, x25, [x0, #0xe0]
101548ff0:     	ldr	w9, [x0, #0xf0]
101548ff4:     	mov	w13, #0x2               ; =2
101548ff8:     	str	x13, [x0, #0xc0]
101548ffc:     	cbz	x12, 0x10154913c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x21c>
101549000:     	cmp	x12, #0x2
101549004:     	b.ne	0x101549158 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x238>
101549008:     	str	wzr, [x8]
10154900c:     	mov	w9, #0xc                ; =12
101549010:     	adrp	x10, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101549014:     	add	x10, x10, #0x3d9
101549018:     	stp	x9, x10, [x8, #0x8]
10154901c:     	mov	w9, #0x20               ; =32
101549020:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549024:     	ldr	x19, [x0, #0x498]
101549028:     	ldr	x9, [x19, #0x270]
10154902c:     	cmp	x1, x9
101549030:     	b.hs	0x101549104 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
101549034:     	ldr	x9, [x19, #0x268]
101549038:     	add	x9, x9, x1, lsl #4
10154903c:     	ldr	w10, [x9]
101549040:     	tbz	w10, #0x0, 0x101549104 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
101549044:     	ldr	x9, [x9, #0x8]
101549048:     	ldr	x10, [x19, #0x258]
10154904c:     	cmp	x9, x10
101549050:     	b.hs	0x10154b728 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2808>
101549054:     	ldr	x10, [x19, #0x250]
101549058:     	mov	w11, #0x160             ; =352
10154905c:     	madd	x21, x9, x11, x10
101549060:     	mov	x20, x21
101549064:     	ldr	x10, [x20, #0x30]!
101549068:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
10154906c:     	cmp	x10, x11
101549070:     	b.ne	0x101549258 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x338>
101549074:     	str	wzr, [x8]
101549078:     	mov	w9, #0xc                ; =12
10154907c:     	adrp	x10, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101549080:     	add	x10, x10, #0x361
101549084:     	stp	x9, x10, [x8, #0x8]
101549088:     	mov	w9, #0x23               ; =35
10154908c:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549090:     	mov	x9, x0
101549094:     	mov	x0, x8
101549098:     	mov	x2, x1
10154909c:     	mov	x1, x9
1015490a0:     	add	sp, sp, #0x800
1015490a4:     	ldp	x29, x30, [sp, #0x50]
1015490a8:     	ldp	x20, x19, [sp, #0x40]
1015490ac:     	ldp	x22, x21, [sp, #0x30]
1015490b0:     	ldp	x24, x23, [sp, #0x20]
1015490b4:     	ldp	x26, x25, [sp, #0x10]
1015490b8:     	ldp	x28, x27, [sp], #0x60
1015490bc:     	b	0x10153b794 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
1015490c0:     	ldr	x9, [x0, #0xc0]
1015490c4:     	cmp	x9, #0x2
1015490c8:     	b.ne	0x101549120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x200>
1015490cc:     	cmp	x22, #0x15
1015490d0:     	b.gt	0x101549214 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4>
1015490d4:     	sub	x9, x22, #0xc
1015490d8:     	cmp	x9, #0x4
1015490dc:     	b.hs	0x1015494ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5cc>
1015490e0:     	lsr	x9, x1, #32
1015490e4:     	cbz	x9, 0x101549298 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x378>
1015490e8:     	str	wzr, [x8]
1015490ec:     	mov	w9, #0xc                ; =12
1015490f0:     	strb	w9, [x8, #0x8]
1015490f4:     	adrp	x9, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
1015490f8:     	add	x9, x9, #0x638
1015490fc:     	mov	w10, #0x15              ; =21
101549100:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549104:     	str	wzr, [x8]
101549108:     	mov	w9, #0xc                ; =12
10154910c:     	adrp	x10, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101549110:     	add	x10, x10, #0x26d
101549114:     	stp	x9, x10, [x8, #0x8]
101549118:     	mov	w9, #0x2d               ; =45
10154911c:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549120:     	str	wzr, [x8]
101549124:     	mov	w9, #0xc                ; =12
101549128:     	strb	w9, [x8, #0x8]
10154912c:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549130:     	add	x9, x9, #0x6a7
101549134:     	mov	w10, #0x35              ; =53
101549138:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154913c:     	str	wzr, [x8]
101549140:     	mov	w9, #0xc                ; =12
101549144:     	strb	w9, [x8, #0x8]
101549148:     	adrp	x9, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154914c:     	add	x9, x9, #0x46c
101549150:     	mov	w10, #0x27              ; =39
101549154:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549158:     	ldr	x21, [x0, #0x498]
10154915c:     	ldr	x12, [x21, #0x178]
101549160:     	cmp	x11, x12
101549164:     	b.hs	0x1015491d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101549168:     	ldr	x12, [x21, #0x170]
10154916c:     	add	x12, x12, x11, lsl #4
101549170:     	ldr	x11, [x12]
101549174:     	ldr	x13, [x21, #0x160]
101549178:     	cmp	x11, x13
10154917c:     	b.hs	0x1015491d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101549180:     	ldr	x12, [x12, #0x8]
101549184:     	ldr	x13, [x21, #0x158]
101549188:     	mov	w14, #0x48              ; =72
10154918c:     	madd	x11, x11, x14, x13
101549190:     	ldr	x13, [x11, #0x28]
101549194:     	cmp	x12, x13
101549198:     	b.hs	0x1015491d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
10154919c:     	ldr	x13, [x11, #0x20]
1015491a0:     	mov	w14, #0x110             ; =272
1015491a4:     	madd	x23, x12, x14, x13
1015491a8:     	mov	x24, x23
1015491ac:     	ldr	x13, [x24, #0x30]!
1015491b0:     	mov	x12, #-0x8000000000000000 ; =-9223372036854775808
1015491b4:     	cmp	x13, x12
1015491b8:     	b.ne	0x10154976c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x84c>
1015491bc:     	str	wzr, [x8]
1015491c0:     	mov	w9, #0xc                ; =12
1015491c4:     	adrp	x10, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
1015491c8:     	add	x10, x10, #0x3f9
1015491cc:     	stp	x9, x10, [x8, #0x8]
1015491d0:     	mov	w9, #0x1f               ; =31
1015491d4:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015491d8:     	str	wzr, [x8]
1015491dc:     	mov	w9, #0xc                ; =12
1015491e0:     	adrp	x10, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
1015491e4:     	add	x10, x10, #0x556
1015491e8:     	stp	x9, x10, [x8, #0x8]
1015491ec:     	mov	w9, #0x29               ; =41
1015491f0:     	str	x9, [x8, #0x18]
1015491f4:     	add	sp, sp, #0x800
1015491f8:     	ldp	x29, x30, [sp, #0x50]
1015491fc:     	ldp	x20, x19, [sp, #0x40]
101549200:     	ldp	x22, x21, [sp, #0x30]
101549204:     	ldp	x24, x23, [sp, #0x20]
101549208:     	ldp	x26, x25, [sp, #0x10]
10154920c:     	ldp	x28, x27, [sp], #0x60
101549210:     	ret
101549214:     	sub	x9, x22, #0x17
101549218:     	cmp	x9, #0x4
10154921c:     	b.hs	0x101549524 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x604>
101549220:     	cmn	x2, #0x17
101549224:     	b.gt	0x10154931c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3fc>
101549228:     	cmn	x2, #0x18
10154922c:     	b.eq	0x101549640 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x720>
101549230:     	cmn	x2, #0x17
101549234:     	b.ne	0x101549624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x704>
101549238:     	ldr	x9, [x0, #0xf8]
10154923c:     	cmp	x9, #0x2
101549240:     	b.ne	0x1015497bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x89c>
101549244:     	str	wzr, [x8]
101549248:     	mov	w9, #0xc                ; =12
10154924c:     	adrp	x10, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549250:     	add	x10, x10, #0xbb5
101549254:     	b	0x10154978c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x86c>
101549258:     	ldp	x10, x11, [x21, #0x68]
10154925c:     	sub	x23, x10, #0x18
101549260:     	lsl	x10, x11, #5
101549264:     	cbz	x10, 0x1015494d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5b4>
101549268:     	ldr	x11, [x23, #0x18]
10154926c:     	add	x23, x23, #0x20
101549270:     	sub	x10, x10, #0x20
101549274:     	cmp	x11, x1
101549278:     	b.ne	0x101549264 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344>
10154927c:     	ldr	w10, [x23]
101549280:     	cmp	w10, #0x5
101549284:     	b.eq	0x101549798 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x878>
101549288:     	cmp	w10, #0x6
10154928c:     	b.ne	0x1015494d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5b4>
101549290:     	mov	w22, #0x8               ; =8
101549294:     	b	0x10154979c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x87c>
101549298:     	mov	x23, x8
10154929c:     	ldr	x8, [x0, #0x4b8]
1015492a0:     	mov	x9, #-0x21              ; =-33
1015492a4:     	movk	x9, #0x7ff, lsl #48
1015492a8:     	cmp	x8, x9
1015492ac:     	b.hi	0x10154a43c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x151c>
1015492b0:     	mov	x22, x2
1015492b4:     	mov	x21, x3
1015492b8:     	mov	x19, x1
1015492bc:     	mov	x20, x0
1015492c0:     	ldr	x9, [x0, #0x490]
1015492c4:     	lsl	x8, x8, #5
1015492c8:     	and	x8, x8, #0xffffffffffffffc0
1015492cc:     	add	x0, sp, #0x550
1015492d0:     	add	x1, x9, #0x2f8
1015492d4:     	add	x4, x8, #0x400
1015492d8:     	mov	w2, #0x0                ; =0
1015492dc:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015492e0:     	ldrb	w8, [sp, #0x550]
1015492e4:     	cmp	w8, #0xe
1015492e8:     	b.ne	0x101549ff4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10d4>
1015492ec:     	add	x8, sp, #0x550
1015492f0:     	mov	x0, x20
1015492f4:     	mov	x1, x19
1015492f8:     	cmn	x22, #0xd
1015492fc:     	b.ne	0x101549710 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7f0>
101549300:     	bl	0x1015522a4 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation17check_prefix_exit>
101549304:     	ldr	w8, [sp, #0x550]
101549308:     	cmp	w8, #0x6
10154930c:     	b.ne	0x101549748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x828>
101549310:     	mov	x8, x23
101549314:     	mov	x10, x22
101549318:     	b	0x10154995c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa3c>
10154931c:     	cmn	x2, #0x16
101549320:     	b.eq	0x101549668 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x748>
101549324:     	cmn	x2, #0x15
101549328:     	b.ne	0x101549624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x704>
10154932c:     	ldr	x9, [x0, #0x498]
101549330:     	str	x9, [sp, #0x660]
101549334:     	ldr	x19, [x3, #0x10]
101549338:     	ldr	x10, [x9, #0x5a0]
10154933c:     	cmp	x19, x10
101549340:     	b.hs	0x101549854 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x934>
101549344:     	ldr	x9, [x9, #0x598]
101549348:     	mov	w10, #0x58              ; =88
10154934c:     	madd	x22, x19, x10, x9
101549350:     	ldr	w9, [x22, #0x3c]
101549354:     	cmp	x1, x9
101549358:     	b.ne	0x101549924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
10154935c:     	ldr	x24, [x0, #0x490]
101549360:     	ldr	w9, [x24, #0x2f0]
101549364:     	cmp	w9, #0x1
101549368:     	b.ne	0x101549924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
10154936c:     	ldr	w9, [x24, #0x2f4]
101549370:     	cmp	w9, w1
101549374:     	b.ne	0x101549924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101549378:     	ldr	w9, [x24, #0x2e8]
10154937c:     	cmp	w9, #0x1
101549380:     	b.ne	0x101549924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101549384:     	ldr	w9, [x22, #0x34]
101549388:     	ldr	w10, [x24, #0x2ec]
10154938c:     	cmp	w10, w9
101549390:     	b.ne	0x101549924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
101549394:     	ldrb	w10, [x24, #0x460]
101549398:     	cmp	w10, #0x1
10154939c:     	b.ne	0x101549924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
1015493a0:     	mov	x23, x8
1015493a4:     	str	x0, [sp, #0x58]
1015493a8:     	ldr	x8, [x0, #0xf8]
1015493ac:     	cmp	x8, #0x2
1015493b0:     	b.ne	0x10154a270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1350>
1015493b4:     	ldr	x8, [sp, #0x58]
1015493b8:     	ldrb	w8, [x8, #0x508]
1015493bc:     	tbnz	w8, #0x0, 0x10154a270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1350>
1015493c0:     	lsl	x0, x9, #1
1015493c4:     	ldr	x8, [sp, #0x58]
1015493c8:     	ldr	x1, [x8, #0x4b8]
1015493cc:     	cmp	x0, x1
1015493d0:     	b.hs	0x10154c448 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3528>
1015493d4:     	ldr	x8, [sp, #0x58]
1015493d8:     	ldr	x9, [x8, #0x4b0]
1015493dc:     	ldr	x28, [x9, x0, lsl #3]
1015493e0:     	ldr	x8, [x8, #0x3c0]
1015493e4:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015493e8:     	cmp	x8, x9
1015493ec:     	b.ne	0x10154a4d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15b4>
1015493f0:     	mov	x21, x3
1015493f4:     	bl	0x102e70e10 <__RNvNtNtCsgirOGyZpP7g_3std6thread9functions21available_parallelism>
1015493f8:     	cmp	x0, #0x1
1015493fc:     	b.ne	0x10154940c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ec>
101549400:     	mov	x0, x1
101549404:     	bl	0x101529a64 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtNtB4_3num7nonzero7NonZerojENtNtNtCsgirOGyZpP7g_3std2io5error5ErrorEECs7fdMCt8k5K6_8mech_gpu>
101549408:     	mov	w1, #0x1                ; =1
10154940c:     	mov	w8, #0x20               ; =32
101549410:     	cmp	x1, #0x20
101549414:     	csel	x20, x1, x8, lo
101549418:     	sub	x8, x28, #0x1
10154941c:     	cmp	x8, x20
101549420:     	b.hs	0x10154a270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1350>
101549424:     	ldr	x8, [x22, #0x28]
101549428:     	str	x8, [sp, #0x50]
10154942c:     	cmp	x8, x20
101549430:     	b.hi	0x10154a270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1350>
101549434:     	ldr	x8, [x22, #0x20]
101549438:     	str	x8, [sp, #0x48]
10154943c:     	add	x8, sp, #0x550
101549440:     	add	x0, x24, #0x3b8
101549444:     	bl	0x10236980c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101549448:     	ldr	x8, [sp, #0x550]
10154944c:     	cmp	x8, #0x1
101549450:     	b.ne	0x10154a270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1350>
101549454:     	ldr	x8, [sp, #0x558]
101549458:     	cbz	x8, 0x10154a270 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1350>
10154945c:     	ldr	x8, [x21]
101549460:     	str	x8, [sp, #0x40]
101549464:     	cbz	x8, 0x10154aadc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bbc>
101549468:     	ldr	x8, [x21, #0x8]
10154946c:     	cbz	x8, 0x10154aadc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bbc>
101549470:     	mov	x21, x8
101549474:     	ldr	x9, [x8, #0x38]
101549478:     	ldr	x8, [sp, #0x58]
10154947c:     	cmp	x9, x8
101549480:     	b.ne	0x1015494b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x598>
101549484:     	ldr	x8, [x21]
101549488:     	cmp	x8, #0x25
10154948c:     	b.ne	0x1015494b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x598>
101549490:     	ldr	x8, [x21, #0x10]
101549494:     	ldr	x9, [sp, #0x660]
101549498:     	ldr	x9, [x9, #0x360]
10154949c:     	cmp	x8, x9
1015494a0:     	b.lo	0x1015494b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x598>
1015494a4:     	ldr	x8, [x21, #0x28]
1015494a8:     	cbz	x8, 0x1015494b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x598>
1015494ac:     	ldr	x8, [x21, #0x70]
1015494b0:     	cmp	x8, #0x4
1015494b4:     	b.ne	0x10154ba50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b30>
1015494b8:     	str	wzr, [x23]
1015494bc:     	mov	w8, #0xc                ; =12
1015494c0:     	strb	w8, [x23, #0x8]
1015494c4:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
1015494c8:     	add	x8, x8, #0xa47
1015494cc:     	mov	w9, #0x28               ; =40
1015494d0:     	b	0x10154a120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1200>
1015494d4:     	str	wzr, [x8]
1015494d8:     	mov	w9, #0xc                ; =12
1015494dc:     	strb	w9, [x8, #0x8]
1015494e0:     	adrp	x9, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
1015494e4:     	add	x9, x9, #0x17b
1015494e8:     	b	0x101549900 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e0>
1015494ec:     	mov	x19, x2
1015494f0:     	mov	x23, x3
1015494f4:     	cmp	x22, #0x14
1015494f8:     	b.ne	0x101549598 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x678>
1015494fc:     	ldr	x9, [x0, #0x490]
101549500:     	ldr	x10, [x0, #0x498]
101549504:     	mov	x24, x0
101549508:     	mov	x0, x9
10154950c:     	mov	x20, x1
101549510:     	mov	x1, x10
101549514:     	mov	x2, x20
101549518:     	mov	x25, x8
10154951c:     	bl	0x10155ac8c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
101549520:     	b	0x101549558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x638>
101549524:     	mov	x19, x2
101549528:     	mov	x23, x3
10154952c:     	cmp	x22, #0x16
101549530:     	b.ne	0x101549598 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x678>
101549534:     	ldr	x9, [x0, #0x490]
101549538:     	ldr	x10, [x0, #0x498]
10154953c:     	mov	x24, x0
101549540:     	mov	x0, x9
101549544:     	mov	x20, x1
101549548:     	mov	x1, x10
10154954c:     	mov	x2, x20
101549550:     	mov	x25, x8
101549554:     	bl	0x1015443ec <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
101549558:     	mov	x1, x20
10154955c:     	mov	x8, x25
101549560:     	mov	x9, x0
101549564:     	mov	x0, x24
101549568:     	tbz	w9, #0x0, 0x101549598 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x678>
10154956c:     	mov	x20, x8
101549570:     	add	x8, sp, #0x550
101549574:     	mov	x24, x0
101549578:     	mov	x25, x1
10154957c:     	bl	0x1015480e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
101549580:     	ldr	w8, [sp, #0x550]
101549584:     	cmp	w8, #0x6
101549588:     	b.ne	0x1015496ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7cc>
10154958c:     	mov	x8, x20
101549590:     	mov	x0, x24
101549594:     	mov	x1, x25
101549598:     	ldr	x9, [x0, #0x490]
10154959c:     	ldr	w10, [x9, #0x2f0]
1015495a0:     	tbz	w10, #0x0, 0x101549608 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6e8>
1015495a4:     	ldr	w10, [x9, #0x2f4]
1015495a8:     	cmp	x1, x10
1015495ac:     	b.ne	0x101549608 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6e8>
1015495b0:     	mov	x3, x23
1015495b4:     	ldr	x23, [x0, #0x498]
1015495b8:     	mov	x20, x1
1015495bc:     	mov	x25, x0
1015495c0:     	cmp	x22, #0x1a
1015495c4:     	b.gt	0x101549b74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
1015495c8:     	sub	x10, x22, #0x13
1015495cc:     	cmp	x10, #0x4
1015495d0:     	b.hs	0x101549cfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xddc>
1015495d4:     	mov	x0, x8
1015495d8:     	mov	x1, x25
1015495dc:     	mov	x2, x20
1015495e0:     	mov	x4, x3
1015495e4:     	mov	x3, x19
1015495e8:     	add	sp, sp, #0x800
1015495ec:     	ldp	x29, x30, [sp, #0x50]
1015495f0:     	ldp	x20, x19, [sp, #0x40]
1015495f4:     	ldp	x22, x21, [sp, #0x30]
1015495f8:     	ldp	x24, x23, [sp, #0x20]
1015495fc:     	ldp	x26, x25, [sp, #0x10]
101549600:     	ldp	x28, x27, [sp], #0x60
101549604:     	b	0x101559224 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation19retained_map_helper>
101549608:     	str	wzr, [x8]
10154960c:     	mov	w9, #0xc                ; =12
101549610:     	strb	w9, [x8, #0x8]
101549614:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549618:     	add	x9, x9, #0x844
10154961c:     	mov	w10, #0x23              ; =35
101549620:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549624:     	str	wzr, [x8]
101549628:     	mov	w9, #0xc                ; =12
10154962c:     	strb	w9, [x8, #0x8]
101549630:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549634:     	add	x9, x9, #0xc7f
101549638:     	mov	w10, #0x20              ; =32
10154963c:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549640:     	ldr	x9, [x0, #0xf8]
101549644:     	cmp	x9, #0x2
101549648:     	b.ne	0x101549870 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x950>
10154964c:     	str	wzr, [x8]
101549650:     	mov	w9, #0xc                ; =12
101549654:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101549658:     	add	x10, x10, #0x3bc
10154965c:     	stp	x9, x10, [x8, #0x8]
101549660:     	mov	w9, #0x26               ; =38
101549664:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549668:     	ldr	x9, [x3]
10154966c:     	ldr	x22, [x0, #0x498]
101549670:     	ldr	x10, [x22, #0x5a0]
101549674:     	cmp	x9, x10
101549678:     	b.hs	0x101549908 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
10154967c:     	ldp	x11, x10, [x3, #0x8]
101549680:     	orr	x10, x11, x10
101549684:     	cbnz	x10, 0x101549940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
101549688:     	ldr	x10, [x22, #0x598]
10154968c:     	mov	w11, #0x58              ; =88
101549690:     	madd	x21, x9, x11, x10
101549694:     	ldr	w10, [x21, #0x44]
101549698:     	cmp	x1, x10
10154969c:     	b.ne	0x101549940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
1015496a0:     	ldr	x10, [x0, #0x490]
1015496a4:     	ldr	w11, [x10, #0x2f0]
1015496a8:     	cmp	w11, #0x1
1015496ac:     	b.ne	0x101549940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
1015496b0:     	ldr	w11, [x10, #0x2f4]
1015496b4:     	cmp	w11, w1
1015496b8:     	b.ne	0x101549940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
1015496bc:     	ldrb	w11, [x10, #0x460]
1015496c0:     	cmp	w11, #0x1
1015496c4:     	b.ne	0x101549940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
1015496c8:     	mov	x19, x8
1015496cc:     	ldr	x8, [x0, #0x3c0]
1015496d0:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
1015496d4:     	cmp	x8, x11
1015496d8:     	b.ne	0x10154a1a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
1015496dc:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
1015496e0:     	ldr	q0, [x8, #0x9c0]
1015496e4:     	stur	q0, [x19, #0x8]
1015496e8:     	b	0x10154a2e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c4>
1015496ec:     	ldr	q0, [sp, #0x570]
1015496f0:     	ldr	q1, [sp, #0x580]
1015496f4:     	stp	q0, q1, [x20, #0x20]
1015496f8:     	ldr	q0, [sp, #0x590]
1015496fc:     	str	q0, [x20, #0x40]
101549700:     	ldr	q0, [sp, #0x560]
101549704:     	ldr	q1, [sp, #0x550]
101549708:     	stp	q1, q0, [x20]
10154970c:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101549710:     	bl	0x101552408 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation19check_prefix_header>
101549714:     	ldr	w8, [sp, #0x550]
101549718:     	cmp	w8, #0x6
10154971c:     	b.ne	0x101549748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x828>
101549720:     	mov	x10, x22
101549724:     	cmn	x22, #0xa
101549728:     	mov	x8, x23
10154972c:     	b.ne	0x10154995c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa3c>
101549730:     	mov	x1, x20
101549734:     	ldr	x11, [x20, #0xa8]
101549738:     	mov	x9, x19
10154973c:     	mov	x3, x21
101549740:     	cbnz	x11, 0x101549a04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xae4>
101549744:     	b	0x101549984 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa64>
101549748:     	ldr	q0, [sp, #0x570]
10154974c:     	ldr	q1, [sp, #0x580]
101549750:     	stp	q0, q1, [x23, #0x20]
101549754:     	ldr	q0, [sp, #0x590]
101549758:     	str	q0, [x23, #0x40]
10154975c:     	ldr	q0, [sp, #0x560]
101549760:     	ldr	q1, [sp, #0x550]
101549764:     	stp	q1, q0, [x23]
101549768:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154976c:     	mov	x14, x23
101549770:     	ldr	x13, [x14, #0xb0]!
101549774:     	cmp	x13, x12
101549778:     	b.ne	0x101549bb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc98>
10154977c:     	str	wzr, [x8]
101549780:     	mov	w9, #0xc                ; =12
101549784:     	adrp	x10, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101549788:     	add	x10, x10, #0x418
10154978c:     	stp	x9, x10, [x8, #0x8]
101549790:     	mov	w9, #0x21               ; =33
101549794:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549798:     	mov	w22, #0x10              ; =16
10154979c:     	ldr	x10, [x3, #0x10]
1015497a0:     	cbz	x10, 0x101549a20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb00>
1015497a4:     	str	wzr, [x8]
1015497a8:     	mov	w9, #0xc                ; =12
1015497ac:     	strb	w9, [x8, #0x8]
1015497b0:     	adrp	x9, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
1015497b4:     	add	x9, x9, #0x14d
1015497b8:     	b	0x101549900 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e0>
1015497bc:     	ldr	x23, [x0, #0x498]
1015497c0:     	ldr	x11, [x23, #0x5a0]
1015497c4:     	ldr	x10, [x0, #0x1c0]
1015497c8:     	cmp	x10, x11
1015497cc:     	b.hs	0x101549cc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
1015497d0:     	ldr	x21, [x0, #0x490]
1015497d4:     	ldr	w11, [x21, #0x2f0]
1015497d8:     	cmp	w11, #0x1
1015497dc:     	b.ne	0x101549d64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe44>
1015497e0:     	ldr	x11, [x3, #0x8]
1015497e4:     	cmp	x11, x10
1015497e8:     	b.ne	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
1015497ec:     	ldr	x11, [x3, #0x10]
1015497f0:     	cbnz	x11, 0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
1015497f4:     	cbnz	x9, 0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
1015497f8:     	ldr	x9, [x23, #0x598]
1015497fc:     	mov	w11, #0x58              ; =88
101549800:     	madd	x24, x10, x11, x9
101549804:     	ldr	w26, [x24, #0x48]
101549808:     	cmp	x1, x26
10154980c:     	b.ne	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101549810:     	ldr	w9, [x21, #0x2e8]
101549814:     	tbz	w9, #0x0, 0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101549818:     	ldr	w9, [x24, #0x34]
10154981c:     	ldr	w10, [x21, #0x2ec]
101549820:     	cmp	w10, w9
101549824:     	b.ne	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101549828:     	ldr	x9, [x24, #0x18]
10154982c:     	cbz	x9, 0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
101549830:     	mov	x25, x3
101549834:     	mov	x20, x0
101549838:     	mov	x22, x8
10154983c:     	ldr	w19, [x21, #0x2f4]
101549840:     	ldr	x8, [x24, #0x10]
101549844:     	cmp	x9, #0x1
101549848:     	b.ne	0x10154a36c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x144c>
10154984c:     	mov	x10, #0x0               ; =0
101549850:     	b	0x10154a390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1470>
101549854:     	str	wzr, [x8]
101549858:     	mov	w9, #0xc                ; =12
10154985c:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101549860:     	add	x10, x10, #0x145
101549864:     	stp	x9, x10, [x8, #0x8]
101549868:     	mov	w9, #0x22               ; =34
10154986c:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549870:     	ldr	x11, [x0, #0x498]
101549874:     	ldr	x12, [x11, #0x5a0]
101549878:     	ldr	x10, [x0, #0x1c0]
10154987c:     	cmp	x10, x12
101549880:     	b.hs	0x101549ce0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdc0>
101549884:     	ldr	x11, [x11, #0x598]
101549888:     	mov	w12, #0x58              ; =88
10154988c:     	madd	x11, x10, x12, x11
101549890:     	ldr	w11, [x11, #0x38]
101549894:     	cmp	x1, x11
101549898:     	b.ne	0x1015498ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
10154989c:     	add	x11, x0, #0x1c8
1015498a0:     	ldr	q0, [x11]
1015498a4:     	stur	q0, [x27, #0x8]
1015498a8:     	ldp	x11, x12, [x3]
1015498ac:     	ldr	x13, [x3, #0x10]
1015498b0:     	ldr	x14, [sp, #0x558]
1015498b4:     	ldr	x15, [sp, #0x560]
1015498b8:     	cmp	x11, x10
1015498bc:     	ccmp	x12, x14, #0x0, eq
1015498c0:     	ccmp	x13, x15, #0x0, eq
1015498c4:     	cset	w10, ne
1015498c8:     	cbnz	x9, 0x1015498ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
1015498cc:     	cbnz	w10, 0x1015498ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
1015498d0:     	ldr	x9, [x0, #0x490]
1015498d4:     	ldr	w10, [x9, #0x2f0]
1015498d8:     	cbnz	w10, 0x1015498ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
1015498dc:     	ldr	w10, [x9, #0x2e8]
1015498e0:     	cbnz	w10, 0x1015498ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
1015498e4:     	ldrb	w10, [x9, #0x338]
1015498e8:     	tbz	w10, #0x0, 0x10154a2bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x139c>
1015498ec:     	str	wzr, [x8]
1015498f0:     	mov	w9, #0xc                ; =12
1015498f4:     	strb	w9, [x8, #0x8]
1015498f8:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
1015498fc:     	add	x9, x9, #0xc51
101549900:     	mov	w10, #0x2e              ; =46
101549904:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549908:     	str	wzr, [x8]
10154990c:     	mov	w9, #0xc                ; =12
101549910:     	adrp	x10, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549914:     	add	x10, x10, #0xaa5
101549918:     	stp	x9, x10, [x8, #0x8]
10154991c:     	mov	w9, #0x14               ; =20
101549920:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549924:     	str	wzr, [x8]
101549928:     	mov	w9, #0xc                ; =12
10154992c:     	strb	w9, [x8, #0x8]
101549930:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549934:     	add	x9, x9, #0xa6f
101549938:     	mov	w10, #0x36              ; =54
10154993c:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549940:     	str	wzr, [x8]
101549944:     	mov	w9, #0xc                ; =12
101549948:     	strb	w9, [x8, #0x8]
10154994c:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549950:     	add	x9, x9, #0xb8f
101549954:     	mov	w10, #0x26              ; =38
101549958:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154995c:     	mov	x3, x21
101549960:     	ldp	x9, x11, [x21]
101549964:     	ldr	x12, [x21, #0x10]
101549968:     	orr	x9, x9, x11
10154996c:     	mov	x1, x20
101549970:     	ldr	x11, [x20, #0xa8]
101549974:     	orr	x11, x12, x11
101549978:     	orr	x11, x9, x11
10154997c:     	mov	x9, x19
101549980:     	cbnz	x11, 0x101549a04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xae4>
101549984:     	ldr	x11, [x1, #0x290]
101549988:     	cmp	x11, #0x6
10154998c:     	b.ne	0x101549a04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xae4>
101549990:     	ldr	x11, [x1, #0x498]
101549994:     	ldr	x12, [x11]
101549998:     	cmp	x12, #0x2
10154999c:     	b.eq	0x10154ab60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c40>
1015499a0:     	add	x24, x1, #0x238
1015499a4:     	ldr	x12, [x24]
1015499a8:     	cmp	x12, #0x3
1015499ac:     	b.eq	0x10154ab6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c4c>
1015499b0:     	ldr	x22, [x11, #0x138]
1015499b4:     	ldr	w12, [x1, #0x280]
1015499b8:     	cmn	x10, #0xc
1015499bc:     	b.gt	0x101549e1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xefc>
1015499c0:     	cmn	x10, #0xd
1015499c4:     	b.eq	0x101549f48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1028>
1015499c8:     	cmn	x10, #0xc
1015499cc:     	b.ne	0x101549f2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x100c>
1015499d0:     	cmp	w12, w9
1015499d4:     	b.ne	0x1015499e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xac8>
1015499d8:     	ldrb	w10, [x1, #0x288]
1015499dc:     	tbz	w10, #0x0, 0x1015499e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xac8>
1015499e0:     	ldrb	w10, [x1, #0x289]
1015499e4:     	tbz	w10, #0x0, 0x10154a148 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1228>
1015499e8:     	str	wzr, [x8]
1015499ec:     	mov	w9, #0xc                ; =12
1015499f0:     	strb	w9, [x8, #0x8]
1015499f4:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
1015499f8:     	add	x9, x9, #0xf7b
1015499fc:     	mov	w10, #0x29              ; =41
101549a00:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549a04:     	str	wzr, [x8]
101549a08:     	mov	w9, #0xc                ; =12
101549a0c:     	strb	w9, [x8, #0x8]
101549a10:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549a14:     	add	x9, x9, #0xfc0
101549a18:     	mov	w10, #0x24              ; =36
101549a1c:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549a20:     	ldr	x10, [x0, #0x490]
101549a24:     	ldr	x10, [x10, #0x3c0]
101549a28:     	cbz	x10, 0x101549b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc38>
101549a2c:     	ldr	x11, [x10, #0x40]
101549a30:     	cmp	x11, #0x2
101549a34:     	b.eq	0x101549b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc38>
101549a38:     	ldr	x11, [x10, #0xd8]
101549a3c:     	cmp	x11, x9
101549a40:     	b.ne	0x101549b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc38>
101549a44:     	ldr	x11, [x23, x22]
101549a48:     	ldr	x12, [x10, #0x78]
101549a4c:     	cmp	x11, x12
101549a50:     	b.hs	0x101549b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc38>
101549a54:     	ldr	x10, [x10, #0x70]
101549a58:     	mov	w12, #0x108             ; =264
101549a5c:     	mul	x11, x11, x12
101549a60:     	ldr	x10, [x10, x11]
101549a64:     	cbnz	x10, 0x1015497a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x884>
101549a68:     	add	x24, sp, #0x440
101549a6c:     	stp	x9, x1, [sp, #0x48]
101549a70:     	mov	x28, x8
101549a74:     	ldr	x8, [x0, #0x4d0]
101549a78:     	cbz	x8, 0x10154a128 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1208>
101549a7c:     	ldr	x10, [x21, #0xb8]
101549a80:     	add	x9, x10, #0x2
101549a84:     	ldr	x11, [x0, #0x4d8]
101549a88:     	cmp	x9, x11
101549a8c:     	b.hs	0x10154a128 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1208>
101549a90:     	str	x0, [sp, #0x58]
101549a94:     	add	x10, x10, #0x3
101549a98:     	cmp	x10, x11
101549a9c:     	b.hs	0x10154a128 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1208>
101549aa0:     	ldr	x9, [x8, x9, lsl #3]
101549aa4:     	ldr	x8, [x8, x10, lsl #3]
101549aa8:     	stp	x9, x8, [sp, #0x38]
101549aac:     	ldr	q0, [x3]
101549ab0:     	str	q0, [sp, #0x440]
101549ab4:     	mov	w8, #0x5                ; =5
101549ab8:     	str	x8, [sp, #0x450]
101549abc:     	add	x0, sp, #0x550
101549ac0:     	add	x3, sp, #0x440
101549ac4:     	ldp	x2, x1, [sp, #0x50]
101549ac8:     	bl	0x10153b794 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
101549acc:     	ldr	w8, [sp, #0x550]
101549ad0:     	cmp	w8, #0x6
101549ad4:     	b.ne	0x10154a5b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1694>
101549ad8:     	ldr	x1, [x19, #0x380]
101549adc:     	ldr	x8, [sp, #0x50]
101549ae0:     	cmp	x8, x1
101549ae4:     	b.hs	0x10154c4ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x358c>
101549ae8:     	ldr	x9, [x19, #0x378]
101549aec:     	mov	w10, #0x170             ; =368
101549af0:     	ldr	x8, [sp, #0x50]
101549af4:     	madd	x8, x8, x10, x9
101549af8:     	ldp	x8, x9, [x8]
101549afc:     	cmp	x8, #0x2
101549b00:     	sbcs	xzr, x9, xzr
101549b04:     	b.hs	0x10154a6ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17cc>
101549b08:     	ldr	x1, [x19, #0x408]
101549b0c:     	ldr	x8, [sp, #0x50]
101549b10:     	cmp	x8, x1
101549b14:     	b.hs	0x10154c4bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x359c>
101549b18:     	ldr	x9, [x19, #0x400]
101549b1c:     	ldr	x8, [sp, #0x50]
101549b20:     	add	x9, x9, x8, lsl #9
101549b24:     	str	x9, [sp, #0x30]
101549b28:     	ldp	x9, x8, [x9]
101549b2c:     	eor	x9, x9, #0x2
101549b30:     	orr	x8, x9, x8
101549b34:     	cbnz	x8, 0x10154a74c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x182c>
101549b38:     	str	wzr, [x28]
101549b3c:     	mov	w8, #0xc                ; =12
101549b40:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101549b44:     	add	x9, x9, #0x29a
101549b48:     	stp	x8, x9, [x28, #0x8]
101549b4c:     	mov	w8, #0x23               ; =35
101549b50:     	str	x8, [x28, #0x18]
101549b54:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101549b58:     	str	wzr, [x8]
101549b5c:     	mov	w9, #0xc                ; =12
101549b60:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101549b64:     	add	x10, x10, #0x987
101549b68:     	stp	x9, x10, [x8, #0x8]
101549b6c:     	mov	w9, #0x2b               ; =43
101549b70:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549b74:     	sub	x10, x22, #0x1b
101549b78:     	cmp	x10, #0x2
101549b7c:     	b.hs	0x101549d30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe10>
101549b80:     	ldp	x5, x6, [x3, #0x8]
101549b84:     	ldr	x4, [x3]
101549b88:     	mov	x0, x8
101549b8c:     	mov	x1, x25
101549b90:     	mov	x2, x20
101549b94:     	mov	x3, x19
101549b98:     	add	sp, sp, #0x800
101549b9c:     	ldp	x29, x30, [sp, #0x50]
101549ba0:     	ldp	x20, x19, [sp, #0x40]
101549ba4:     	ldp	x22, x21, [sp, #0x30]
101549ba8:     	ldp	x24, x23, [sp, #0x20]
101549bac:     	ldp	x26, x25, [sp, #0x10]
101549bb0:     	ldp	x28, x27, [sp], #0x60
101549bb4:     	b	0x101546a28 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation17frozen_map_helper>
101549bb8:     	cbnz	x10, 0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549bbc:     	ldr	x12, [x0, #0x490]
101549bc0:     	ldr	w10, [x12, #0x2f0]
101549bc4:     	cmp	w10, #0x1
101549bc8:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549bcc:     	ldr	w10, [x12, #0x2f4]
101549bd0:     	cmp	w10, w9
101549bd4:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549bd8:     	ldr	w9, [x12, #0x2e8]
101549bdc:     	cmp	w9, #0x1
101549be0:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549be4:     	ldr	w9, [x11, #0x30]
101549be8:     	ldr	w10, [x12, #0x2ec]
101549bec:     	cmp	w10, w9
101549bf0:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549bf4:     	stp	x14, x12, [sp, #0x38]
101549bf8:     	stp	x8, x1, [sp, #0x48]
101549bfc:     	mov	w8, #0x1                ; =1
101549c00:     	orr	x8, x8, x9, lsl #1
101549c04:     	str	x0, [sp, #0x58]
101549c08:     	ldr	x1, [x0, #0x4b8]
101549c0c:     	cmp	x8, x1
101549c10:     	b.hs	0x10154c438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3518>
101549c14:     	ldr	x9, [sp, #0x58]
101549c18:     	ldr	x9, [x9, #0x4b0]
101549c1c:     	ldr	x8, [x9, x8, lsl #3]
101549c20:     	cmp	x8, #0x1
101549c24:     	ldp	x9, x8, [sp, #0x40]
101549c28:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549c2c:     	add	x0, x9, #0x3b8
101549c30:     	bl	0x102369f74 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101549c34:     	ldp	x9, x8, [sp, #0x40]
101549c38:     	cmp	x0, x26
101549c3c:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549c40:     	cmp	x1, x19
101549c44:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549c48:     	add	x8, sp, #0x550
101549c4c:     	add	x0, x9, #0x3b8
101549c50:     	bl	0x10236980c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101549c54:     	ldr	x8, [sp, #0x48]
101549c58:     	ldr	x9, [sp, #0x550]
101549c5c:     	cmp	x9, #0x1
101549c60:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549c64:     	ldr	x9, [sp, #0x558]
101549c68:     	cmp	x9, x22
101549c6c:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549c70:     	ldr	x9, [sp, #0x560]
101549c74:     	cmp	x9, x25
101549c78:     	b.ne	0x101549ca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd88>
101549c7c:     	cbz	x20, 0x10154a950 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a30>
101549c80:     	cmp	x20, #0x2
101549c84:     	b.eq	0x10154a914 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19f4>
101549c88:     	cmp	x20, #0x3
101549c8c:     	b.ne	0x10154a930 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a10>
101549c90:     	cbnz	x28, 0x10154a930 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a10>
101549c94:     	ldp	x1, x2, [x23, #0x8]
101549c98:     	ldr	x0, [sp, #0x50]
101549c9c:     	bl	0x10155c504 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
101549ca0:     	tbnz	w0, #0x0, 0x10154a928 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a08>
101549ca4:     	b	0x10154a930 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a10>
101549ca8:     	str	wzr, [x8]
101549cac:     	mov	w9, #0xc                ; =12
101549cb0:     	strb	w9, [x8, #0x8]
101549cb4:     	adrp	x9, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
101549cb8:     	add	x9, x9, #0x42e
101549cbc:     	mov	w10, #0x3e              ; =62
101549cc0:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549cc4:     	str	wzr, [x8]
101549cc8:     	mov	w9, #0xc                ; =12
101549ccc:     	adrp	x10, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549cd0:     	add	x10, x10, #0xbd6
101549cd4:     	stp	x9, x10, [x8, #0x8]
101549cd8:     	mov	w9, #0x13               ; =19
101549cdc:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549ce0:     	str	wzr, [x8]
101549ce4:     	mov	w9, #0xc                ; =12
101549ce8:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101549cec:     	add	x10, x10, #0x3e2
101549cf0:     	stp	x9, x10, [x8, #0x8]
101549cf4:     	mov	w9, #0x19               ; =25
101549cf8:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101549cfc:     	cmp	x22, #0xa
101549d00:     	b.ne	0x101549d80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe60>
101549d04:     	mov	x0, x8
101549d08:     	mov	x1, x25
101549d0c:     	mov	x2, x20
101549d10:     	add	sp, sp, #0x800
101549d14:     	ldp	x29, x30, [sp, #0x50]
101549d18:     	ldp	x20, x19, [sp, #0x40]
101549d1c:     	ldp	x22, x21, [sp, #0x30]
101549d20:     	ldp	x24, x23, [sp, #0x20]
101549d24:     	ldp	x26, x25, [sp, #0x10]
101549d28:     	ldp	x28, x27, [sp], #0x60
101549d2c:     	b	0x10153bdd8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation17begin_closed_tail>
101549d30:     	cmp	x22, #0x1e
101549d34:     	b.ne	0x101549d80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe60>
101549d38:     	mov	x0, x8
101549d3c:     	mov	x1, x25
101549d40:     	mov	x2, x20
101549d44:     	add	sp, sp, #0x800
101549d48:     	ldp	x29, x30, [sp, #0x50]
101549d4c:     	ldp	x20, x19, [sp, #0x40]
101549d50:     	ldp	x22, x21, [sp, #0x30]
101549d54:     	ldp	x24, x23, [sp, #0x20]
101549d58:     	ldp	x26, x25, [sp, #0x10]
101549d5c:     	ldp	x28, x27, [sp], #0x60
101549d60:     	b	0x101538b44 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB4_10Invocation21begin_numeric_segment>
101549d64:     	str	wzr, [x8]
101549d68:     	mov	w9, #0xc                ; =12
101549d6c:     	strb	w9, [x8, #0x8]
101549d70:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549d74:     	add	x9, x9, #0xbe9
101549d78:     	mov	w10, #0x18              ; =24
101549d7c:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549d80:     	mov	x24, x3
101549d84:     	mov	x19, x8
101549d88:     	mov	x0, x9
101549d8c:     	mov	x1, x23
101549d90:     	mov	x2, x20
101549d94:     	bl	0x101546c7c <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation20frozen_native_action>
101549d98:     	tbnz	w0, #0x0, 0x101549dfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xedc>
101549d9c:     	mov	x8, x25
101549da0:     	ldr	x25, [x25, #0x490]
101549da4:     	str	x8, [sp, #0x58]
101549da8:     	ldr	x26, [x8, #0x498]
101549dac:     	mov	x0, x25
101549db0:     	mov	x1, x26
101549db4:     	mov	x2, x20
101549db8:     	bl	0x10155ad5c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
101549dbc:     	tbnz	w0, #0x0, 0x101549dfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xedc>
101549dc0:     	mov	x0, x25
101549dc4:     	mov	x1, x26
101549dc8:     	mov	x2, x20
101549dcc:     	bl	0x10155ac8c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
101549dd0:     	tbnz	w0, #0x0, 0x101549dfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xedc>
101549dd4:     	mov	x0, x25
101549dd8:     	mov	x1, x26
101549ddc:     	mov	x2, x20
101549de0:     	bl	0x10155acf4 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_exit>
101549de4:     	tbnz	w0, #0x0, 0x101549dfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xedc>
101549de8:     	mov	x0, x25
101549dec:     	mov	x1, x26
101549df0:     	mov	x2, x20
101549df4:     	bl	0x1015443ec <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
101549df8:     	tbz	w0, #0x0, 0x10154a32c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x140c>
101549dfc:     	str	wzr, [x19]
101549e00:     	mov	w8, #0xc                ; =12
101549e04:     	strb	w8, [x19, #0x8]
101549e08:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549e0c:     	add	x8, x8, #0x819
101549e10:     	mov	w9, #0x2b               ; =43
101549e14:     	stp	x8, x9, [x19, #0x10]
101549e18:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101549e1c:     	cmn	x10, #0xb
101549e20:     	b.eq	0x10154a04c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x112c>
101549e24:     	cmn	x10, #0xa
101549e28:     	b.ne	0x101549f2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x100c>
101549e2c:     	ldrb	w21, [x1, #0x284]
101549e30:     	ldr	x2, [x1, #0x278]
101549e34:     	mov	x8, x1
101549e38:     	add	x0, sp, #0x550
101549e3c:     	mov	x1, x3
101549e40:     	add	x3, x8, #0x250
101549e44:     	bl	0x101556d74 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB4_9Retention7checked>
101549e48:     	ldr	w8, [sp, #0x550]
101549e4c:     	cmp	w8, #0x6
101549e50:     	b.ne	0x10154a0d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11b0>
101549e54:     	ldr	x8, [sp, #0x568]
101549e58:     	ldur	q0, [x27, #0x8]
101549e5c:     	str	q0, [sp, #0x220]
101549e60:     	str	x8, [sp, #0x230]
101549e64:     	tbnz	w21, #0x0, 0x10154a108 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11e8>
101549e68:     	mov	x8, x20
101549e6c:     	ldr	x9, [x20, #0xc0]
101549e70:     	cmp	x9, #0x2
101549e74:     	b.ne	0x10154a108 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11e8>
101549e78:     	ldr	x9, [x8, #0x220]
101549e7c:     	cmp	x9, #0x2
101549e80:     	b.eq	0x10154a108 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11e8>
101549e84:     	ldr	x9, [x8, #0x1d8]
101549e88:     	cmp	x9, x22
101549e8c:     	b.ne	0x10154a108 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11e8>
101549e90:     	ldr	x21, [x8, #0x4d8]
101549e94:     	mov	x8, #-0x41              ; =-65
101549e98:     	movk	x8, #0xfff, lsl #48
101549e9c:     	cmp	x21, x8
101549ea0:     	b.hi	0x10154a43c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x151c>
101549ea4:     	ldr	x8, [x20, #0x490]
101549ea8:     	lsl	x9, x21, #4
101549eac:     	add	x0, sp, #0x550
101549eb0:     	add	x1, x8, #0x2f8
101549eb4:     	add	x4, x9, #0x400
101549eb8:     	mov	w2, #0x0                ; =0
101549ebc:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101549ec0:     	ldrb	w8, [sp, #0x550]
101549ec4:     	cmp	w8, #0xe
101549ec8:     	b.ne	0x101549ff4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10d4>
101549ecc:     	cbz	x21, 0x101549ee0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfc0>
101549ed0:     	ldr	x0, [x20, #0x4d0]
101549ed4:     	cbz	x0, 0x10154a5e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16c8>
101549ed8:     	lsl	x1, x21, #3
101549edc:     	bl	0x103a08ea0 <dyld_stub_binder+0x103a08ea0>
101549ee0:     	add	x0, x20, #0x1d8
101549ee4:     	bl	0x10152d414 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
101549ee8:     	mov	w8, #0x2                ; =2
101549eec:     	str	x8, [x20, #0x220]
101549ef0:     	ldr	x8, [x20, #0x238]
101549ef4:     	cmp	x8, #0x3
101549ef8:     	b.eq	0x10154be00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ee0>
101549efc:     	ldr	q0, [sp, #0x220]
101549f00:     	str	q0, [x24]
101549f04:     	ldr	x8, [sp, #0x230]
101549f08:     	str	x8, [x24, #0x10]
101549f0c:     	ldr	x8, [x24]
101549f10:     	cmp	x8, #0x3
101549f14:     	b.eq	0x10154be0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2eec>
101549f18:     	mov	w8, #0x1                ; =1
101549f1c:     	str	w8, [x20, #0x268]
101549f20:     	str	w19, [x20, #0x26c]
101549f24:     	str	xzr, [x23, #0x8]
101549f28:     	b	0x10154a27c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x135c>
101549f2c:     	str	wzr, [x8]
101549f30:     	mov	w9, #0xc                ; =12
101549f34:     	strb	w9, [x8, #0x8]
101549f38:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101549f3c:     	add	x9, x9, #0xfa4
101549f40:     	mov	w10, #0x1c              ; =28
101549f44:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101549f48:     	ldr	w9, [x1, #0x270]
101549f4c:     	cbnz	w9, 0x10154a09c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x117c>
101549f50:     	ldr	x9, [x1, #0xc0]
101549f54:     	cmp	x9, #0x2
101549f58:     	b.ne	0x10154a09c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x117c>
101549f5c:     	ldr	x9, [x1, #0x220]
101549f60:     	cmp	x9, #0x2
101549f64:     	b.eq	0x10154a09c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x117c>
101549f68:     	ldr	x9, [x1, #0x1d8]
101549f6c:     	cmp	x9, x22
101549f70:     	b.ne	0x10154a09c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x117c>
101549f74:     	ldr	x21, [x1, #0x4d8]
101549f78:     	mov	x8, #-0x41              ; =-65
101549f7c:     	movk	x8, #0xfff, lsl #48
101549f80:     	cmp	x21, x8
101549f84:     	b.hi	0x10154a43c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x151c>
101549f88:     	ldr	x8, [x20, #0x490]
101549f8c:     	lsl	x9, x21, #4
101549f90:     	add	x0, sp, #0x550
101549f94:     	add	x1, x8, #0x2f8
101549f98:     	add	x4, x9, #0x400
101549f9c:     	mov	w2, #0x0                ; =0
101549fa0:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101549fa4:     	ldrb	w8, [sp, #0x550]
101549fa8:     	cmp	w8, #0xe
101549fac:     	b.ne	0x101549ff4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10d4>
101549fb0:     	cbz	x21, 0x101549fc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10a4>
101549fb4:     	ldr	x0, [x20, #0x4d0]
101549fb8:     	cbz	x0, 0x10154a5e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16c8>
101549fbc:     	lsl	x1, x21, #3
101549fc0:     	bl	0x103a08ea0 <dyld_stub_binder+0x103a08ea0>
101549fc4:     	add	x0, x20, #0x1d8
101549fc8:     	bl	0x10152d414 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
101549fcc:     	mov	w8, #0x2                ; =2
101549fd0:     	str	x8, [x20, #0x220]
101549fd4:     	ldr	x8, [x20, #0x238]
101549fd8:     	cmp	x8, #0x3
101549fdc:     	b.eq	0x10154bad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bb8>
101549fe0:     	mov	w8, #0x1                ; =1
101549fe4:     	str	w8, [x20, #0x270]
101549fe8:     	str	w19, [x20, #0x274]
101549fec:     	str	xzr, [x23, #0x8]
101549ff0:     	b	0x10154a27c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x135c>
101549ff4:     	ldr	q0, [sp, #0x550]
101549ff8:     	ldr	q1, [sp, #0x560]
101549ffc:     	str	q0, [sp, #0x440]
10154a000:     	str	q1, [sp, #0x450]
10154a004:     	ldr	q2, [sp, #0x570]
10154a008:     	str	q2, [sp, #0x460]
10154a00c:     	ldr	x8, [sp, #0x580]
10154a010:     	str	x8, [sp, #0x470]
10154a014:     	stur	q0, [x27, #0x4]
10154a018:     	stur	q1, [x27, #0x14]
10154a01c:     	stur	q2, [x27, #0x24]
10154a020:     	stur	x8, [x27, #0x34]
10154a024:     	str	wzr, [x23]
10154a028:     	ldr	q0, [sp, #0x550]
10154a02c:     	ldr	q1, [sp, #0x560]
10154a030:     	stur	q0, [x23, #0x4]
10154a034:     	stur	q1, [x23, #0x14]
10154a038:     	ldr	q0, [sp, #0x570]
10154a03c:     	stur	q0, [x23, #0x24]
10154a040:     	ldur	q0, [x27, #0x2c]
10154a044:     	str	q0, [x23, #0x30]
10154a048:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a04c:     	cmp	w12, w9
10154a050:     	b.ne	0x10154a0b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1198>
10154a054:     	ldrb	w9, [x1, #0x288]
10154a058:     	tbnz	w9, #0x0, 0x10154a0b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1198>
10154a05c:     	ldrb	w9, [x1, #0x289]
10154a060:     	tbnz	w9, #0x0, 0x10154a0b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1198>
10154a064:     	add	x0, sp, #0x550
10154a068:     	mov	x2, x19
10154a06c:     	mov	x4, x22
10154a070:     	bl	0x10153e66c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23prepare_borrowed_region>
10154a074:     	ldr	w8, [sp, #0x550]
10154a078:     	cmp	w8, #0x6
10154a07c:     	b.ne	0x10154a288 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1368>
10154a080:     	ldr	x8, [x24]
10154a084:     	cmp	x8, #0x3
10154a088:     	b.eq	0x10154ba14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2af4>
10154a08c:     	ldur	q0, [x27, #0x8]
10154a090:     	mov	w8, #0x1                ; =1
10154a094:     	strb	w8, [x20, #0x288]
10154a098:     	b	0x10154a278 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1358>
10154a09c:     	str	wzr, [x8]
10154a0a0:     	mov	w9, #0xc                ; =12
10154a0a4:     	strb	w9, [x8, #0x8]
10154a0a8:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a0ac:     	add	x9, x9, #0xeec
10154a0b0:     	mov	w10, #0x2f              ; =47
10154a0b4:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154a0b8:     	str	wzr, [x8]
10154a0bc:     	mov	w9, #0xc                ; =12
10154a0c0:     	strb	w9, [x8, #0x8]
10154a0c4:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a0c8:     	add	x9, x9, #0xf4d
10154a0cc:     	b	0x101549900 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e0>
10154a0d0:     	ldr	q0, [sp, #0x560]
10154a0d4:     	ldr	q1, [sp, #0x570]
10154a0d8:     	stur	q0, [x28, #0xc]
10154a0dc:     	ldur	q0, [x27, #0x4]
10154a0e0:     	str	q0, [sp, #0x440]
10154a0e4:     	ldr	q0, [sp, #0x580]
10154a0e8:     	ldr	q2, [sp, #0x590]
10154a0ec:     	stp	q0, q2, [x23, #0x30]
10154a0f0:     	ldr	q0, [sp, #0x440]
10154a0f4:     	stur	q0, [x23, #0x4]
10154a0f8:     	ldur	q0, [x28, #0xc]
10154a0fc:     	stp	q0, q1, [x23, #0x10]
10154a100:     	str	w8, [x23]
10154a104:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a108:     	str	wzr, [x23]
10154a10c:     	mov	w8, #0xc                ; =12
10154a110:     	strb	w8, [x23, #0x8]
10154a114:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a118:     	add	x8, x8, #0xf1b
10154a11c:     	mov	w9, #0x32               ; =50
10154a120:     	stp	x8, x9, [x23, #0x10]
10154a124:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a128:     	str	wzr, [x28]
10154a12c:     	mov	w8, #0xc                ; =12
10154a130:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154a134:     	add	x9, x9, #0x4b4
10154a138:     	stp	x8, x9, [x28, #0x8]
10154a13c:     	mov	w8, #0x30               ; =48
10154a140:     	str	x8, [x28, #0x18]
10154a144:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a148:     	ldr	x1, [x11, #0x270]
10154a14c:     	cmp	x9, x1
10154a150:     	b.hs	0x10154c3fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34dc>
10154a154:     	ldr	x8, [x11, #0x268]
10154a158:     	add	x8, x8, x19, lsl #4
10154a15c:     	ldr	w9, [x8]
10154a160:     	tbz	w9, #0x0, 0x10154a2f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d0>
10154a164:     	ldr	x3, [x8, #0x8]
10154a168:     	add	x0, sp, #0x550
10154a16c:     	mov	x1, x20
10154a170:     	mov	x2, x21
10154a174:     	bl	0x10153be28 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation19begin_closed_region>
10154a178:     	ldr	w8, [sp, #0x550]
10154a17c:     	cmp	w8, #0x6
10154a180:     	b.ne	0x10154a288 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1368>
10154a184:     	ldr	x8, [x24]
10154a188:     	cmp	x8, #0x3
10154a18c:     	b.eq	0x10154bde8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ec8>
10154a190:     	ldur	q0, [x27, #0x8]
10154a194:     	mov	w8, #0x1                ; =1
10154a198:     	strb	w8, [x20, #0x289]
10154a19c:     	b	0x10154a278 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1358>
10154a1a0:     	mov	x20, x0
10154a1a4:     	ldr	x11, [x0, #0x3d8]
10154a1a8:     	cbz	x11, 0x10154a45c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x153c>
10154a1ac:     	ldr	x12, [x20, #0x3d0]
10154a1b0:     	cmp	x12, x8
10154a1b4:     	csel	x8, xzr, x8, lo
10154a1b8:     	sub	x8, x12, x8
10154a1bc:     	ldr	x11, [x20, #0x3c8]
10154a1c0:     	mov	w12, #0x58              ; =88
10154a1c4:     	madd	x8, x8, x12, x11
10154a1c8:     	ldr	x11, [x8, #0x40]
10154a1cc:     	cmp	x11, x9
10154a1d0:     	b.ne	0x10154a310 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13f0>
10154a1d4:     	ldr	w9, [x10, #0x2e8]
10154a1d8:     	cmp	w9, #0x1
10154a1dc:     	b.ne	0x10154a310 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13f0>
10154a1e0:     	ldr	w9, [x21, #0x34]
10154a1e4:     	ldr	w10, [x10, #0x2ec]
10154a1e8:     	cmp	w10, w9
10154a1ec:     	b.ne	0x10154a310 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13f0>
10154a1f0:     	lsl	x0, x9, #1
10154a1f4:     	ldr	x1, [x20, #0x4b8]
10154a1f8:     	cmp	x0, x1
10154a1fc:     	b.hs	0x10154c520 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3600>
10154a200:     	ldr	x9, [x8, #0x50]
10154a204:     	ldr	x10, [x20, #0x4b0]
10154a208:     	ldr	x10, [x10, x0, lsl #3]
10154a20c:     	subs	x9, x9, x10
10154a210:     	b.lo	0x10154a310 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13f0>
10154a214:     	ldr	x10, [x8, #0x48]
10154a218:     	cmp	x9, x10
10154a21c:     	b.ne	0x10154a310 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13f0>
10154a220:     	ldr	x10, [x20, #0x3f8]
10154a224:     	ldr	x9, [x20, #0x3e8]
10154a228:     	cmp	x9, x10
10154a22c:     	b.eq	0x10154a254 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1334>
10154a230:     	add	x10, x9, #0xc8
10154a234:     	str	x10, [x20, #0x3e8]
10154a238:     	ldr	x15, [x9]
10154a23c:     	ldp	w14, w13, [x9, #0x8]
10154a240:     	ldrb	w12, [x9, #0x10]
10154a244:     	ldp	x11, x10, [x9, #0x18]
10154a248:     	cbz	x15, 0x10154b2f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x23d0>
10154a24c:     	cmp	x15, #0x2
10154a250:     	b.ne	0x10154b418 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24f8>
10154a254:     	str	wzr, [x19]
10154a258:     	mov	w8, #0xc                ; =12
10154a25c:     	strb	w8, [x19, #0x8]
10154a260:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a264:     	add	x8, x8, #0xad6
10154a268:     	mov	w9, #0x16               ; =22
10154a26c:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154a270:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154a274:     	ldr	q0, [x8, #0x9c0]
10154a278:     	stur	q0, [x23, #0x8]
10154a27c:     	mov	w8, #0x6                ; =6
10154a280:     	str	w8, [x23]
10154a284:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a288:     	ldr	w9, [sp, #0x554]
10154a28c:     	ldur	q0, [x27, #0x18]
10154a290:     	stur	q0, [x23, #0x18]
10154a294:     	ldur	q0, [x27, #0x28]
10154a298:     	stur	q0, [x23, #0x28]
10154a29c:     	ldur	q0, [x27, #0x38]
10154a2a0:     	stur	q0, [x23, #0x38]
10154a2a4:     	ldr	x10, [sp, #0x598]
10154a2a8:     	str	x10, [x23, #0x48]
10154a2ac:     	ldur	q0, [x27, #0x8]
10154a2b0:     	stp	w8, w9, [x23]
10154a2b4:     	stur	q0, [x23, #0x8]
10154a2b8:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a2bc:     	mov	x19, x8
10154a2c0:     	add	x0, sp, #0x550
10154a2c4:     	add	x1, x9, #0x2f8
10154a2c8:     	mov	w2, #0x0                ; =0
10154a2cc:     	mov	w4, #0x100              ; =256
10154a2d0:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10154a2d4:     	ldrb	w8, [sp, #0x550]
10154a2d8:     	cmp	w8, #0xe
10154a2dc:     	b.ne	0x10154a47c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x155c>
10154a2e0:     	str	xzr, [x19, #0x8]
10154a2e4:     	mov	w8, #0x6                ; =6
10154a2e8:     	str	w8, [x19]
10154a2ec:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a2f0:     	str	wzr, [x23]
10154a2f4:     	mov	w8, #0xc                ; =12
10154a2f8:     	adrp	x9, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154a2fc:     	add	x9, x9, #0x64d
10154a300:     	stp	x8, x9, [x23, #0x8]
10154a304:     	mov	w8, #0x26               ; =38
10154a308:     	str	x8, [x23, #0x18]
10154a30c:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a310:     	str	wzr, [x19]
10154a314:     	mov	w8, #0xc                ; =12
10154a318:     	strb	w8, [x19, #0x8]
10154a31c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a320:     	add	x8, x8, #0xb5c
10154a324:     	mov	w9, #0x33               ; =51
10154a328:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154a32c:     	cmp	x22, #0x9
10154a330:     	b.eq	0x10154a690 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1770>
10154a334:     	cmp	x22, #0x8
10154a338:     	b.ne	0x10154a6c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17a0>
10154a33c:     	mov	x0, x19
10154a340:     	ldr	x1, [sp, #0x58]
10154a344:     	mov	x2, x20
10154a348:     	mov	x3, x24
10154a34c:     	add	sp, sp, #0x800
10154a350:     	ldp	x29, x30, [sp, #0x50]
10154a354:     	ldp	x20, x19, [sp, #0x40]
10154a358:     	ldp	x22, x21, [sp, #0x30]
10154a35c:     	ldp	x24, x23, [sp, #0x20]
10154a360:     	ldp	x26, x25, [sp, #0x10]
10154a364:     	ldp	x28, x27, [sp], #0x60
10154a368:     	b	0x10153f828 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation24prepare_borrowed_strings>
10154a36c:     	mov	x10, #0x0               ; =0
10154a370:     	lsr	x11, x9, #1
10154a374:     	add	x12, x11, x10
10154a378:     	ldr	w13, [x8, x12, lsl #2]
10154a37c:     	cmp	w13, w19
10154a380:     	csel	x10, x10, x12, hi
10154a384:     	sub	x9, x9, x11
10154a388:     	cmp	x9, #0x1
10154a38c:     	b.hi	0x10154a370 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1450>
10154a390:     	ldr	w8, [x8, x10, lsl #2]
10154a394:     	cmp	w8, w19
10154a398:     	mov	x8, x22
10154a39c:     	b.ne	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
10154a3a0:     	ldr	x1, [x23, #0x380]
10154a3a4:     	cmp	x1, x19
10154a3a8:     	b.ls	0x10154c49c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x357c>
10154a3ac:     	ldr	x8, [x23, #0x378]
10154a3b0:     	mov	w9, #0x170              ; =368
10154a3b4:     	umaddl	x8, w19, w9, x8
10154a3b8:     	add	x9, x8, #0x15c
10154a3bc:     	ldr	w8, [x8, #0x16c]
10154a3c0:     	str	w8, [sp, #0x560]
10154a3c4:     	ldr	q0, [x9]
10154a3c8:     	str	q0, [sp, #0x550]
10154a3cc:     	add	x8, sp, #0x440
10154a3d0:     	add	x0, sp, #0x550
10154a3d4:     	bl	0x1027055f0 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
10154a3d8:     	ldr	w8, [sp, #0x440]
10154a3dc:     	cmp	w8, #0x1
10154a3e0:     	b.ne	0x10154a3f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14d0>
10154a3e4:     	ldr	w8, [sp, #0x444]
10154a3e8:     	cmp	w8, w26
10154a3ec:     	b.eq	0x10154a408 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14e8>
10154a3f0:     	ldr	w8, [sp, #0x448]
10154a3f4:     	cmp	w8, #0x1
10154a3f8:     	b.ne	0x10154a72c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x180c>
10154a3fc:     	ldr	w8, [sp, #0x44c]
10154a400:     	cmp	w8, w26
10154a404:     	b.ne	0x10154a72c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x180c>
10154a408:     	mov	x0, x20
10154a40c:     	mov	x1, x19
10154a410:     	bl	0x101547234 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
10154a414:     	cbz	w0, 0x10154a620 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1700>
10154a418:     	ldrb	w8, [x21, #0x460]
10154a41c:     	cmp	w8, #0x1
10154a420:     	mov	x8, x22
10154a424:     	b.ne	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
10154a428:     	mov	x9, x20
10154a42c:     	ldr	x10, [x20, #0xc0]
10154a430:     	cmp	x10, #0x2
10154a434:     	b.eq	0x10154a634 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1714>
10154a438:     	b	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
10154a43c:     	str	wzr, [x23]
10154a440:     	mov	w8, #0xc                ; =12
10154a444:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154a448:     	add	x9, x9, #0x10
10154a44c:     	stp	x8, x9, [x23, #0x8]
10154a450:     	mov	w8, #0x1a               ; =26
10154a454:     	str	x8, [x23, #0x18]
10154a458:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a45c:     	str	wzr, [x19]
10154a460:     	mov	w8, #0xc                ; =12
10154a464:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a468:     	add	x9, x9, #0xab9
10154a46c:     	stp	x8, x9, [x19, #0x8]
10154a470:     	mov	w8, #0x1d               ; =29
10154a474:     	str	x8, [x19, #0x18]
10154a478:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a47c:     	ldr	q0, [sp, #0x550]
10154a480:     	ldr	q1, [sp, #0x560]
10154a484:     	str	q0, [sp, #0x440]
10154a488:     	str	q1, [sp, #0x450]
10154a48c:     	ldr	q2, [sp, #0x570]
10154a490:     	str	q2, [sp, #0x460]
10154a494:     	ldr	x8, [sp, #0x580]
10154a498:     	str	x8, [sp, #0x470]
10154a49c:     	stur	q0, [x27, #0x4]
10154a4a0:     	stur	q1, [x27, #0x14]
10154a4a4:     	stur	q2, [x27, #0x24]
10154a4a8:     	stur	x8, [x27, #0x34]
10154a4ac:     	str	wzr, [x19]
10154a4b0:     	ldr	q0, [sp, #0x550]
10154a4b4:     	ldr	q1, [sp, #0x560]
10154a4b8:     	stur	q0, [x19, #0x4]
10154a4bc:     	stur	q1, [x19, #0x14]
10154a4c0:     	ldr	q0, [sp, #0x570]
10154a4c4:     	stur	q0, [x19, #0x24]
10154a4c8:     	ldur	q0, [x27, #0x2c]
10154a4cc:     	str	q0, [x19, #0x30]
10154a4d0:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a4d4:     	ldr	x9, [sp, #0x58]
10154a4d8:     	ldr	x9, [x9, #0x3d8]
10154a4dc:     	cbz	x9, 0x10154a70c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17ec>
10154a4e0:     	ldr	x9, [sp, #0x58]
10154a4e4:     	ldr	x10, [x9, #0x3d0]
10154a4e8:     	cmp	x10, x8
10154a4ec:     	csel	x8, xzr, x8, lo
10154a4f0:     	sub	x8, x10, x8
10154a4f4:     	ldr	x9, [x9, #0x3c8]
10154a4f8:     	mov	w10, #0x58              ; =88
10154a4fc:     	madd	x20, x8, x10, x9
10154a500:     	ldr	x8, [x20, #0x40]
10154a504:     	cmp	x8, x19
10154a508:     	b.ne	0x10154a604 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16e4>
10154a50c:     	ldr	x8, [x20, #0x48]
10154a510:     	cbnz	x8, 0x10154a604 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16e4>
10154a514:     	ldr	x8, [x20, #0x50]
10154a518:     	cmp	x8, x28
10154a51c:     	b.ne	0x10154a604 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x16e4>
10154a520:     	ldr	w1, [x22, #0x50]
10154a524:     	add	x8, sp, #0x550
10154a528:     	add	x0, x24, #0xf0
10154a52c:     	add	x2, x24, #0x2f8
10154a530:     	bl	0x10154fa14 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10154a534:     	ldur	q0, [x27, #0x8]
10154a538:     	ldur	q1, [x27, #0x18]
10154a53c:     	stp	q0, q1, [sp, #0x3a0]
10154a540:     	ldur	q0, [x27, #0x28]
10154a544:     	str	q0, [sp, #0x3c0]
10154a548:     	ldr	x8, [sp, #0x550]
10154a54c:     	ldr	x9, [sp, #0x588]
10154a550:     	str	x9, [sp, #0x3d0]
10154a554:     	cbz	x8, 0x10154acf0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dd0>
10154a558:     	ldp	q0, q1, [sp, #0x3a0]
10154a55c:     	add	x9, sp, #0x440
10154a560:     	stur	q0, [x9, #0x8]
10154a564:     	ldr	x10, [sp, #0x3d0]
10154a568:     	ldr	q0, [sp, #0x3c0]
10154a56c:     	stur	q0, [x9, #0x28]
10154a570:     	stur	q1, [x9, #0x18]
10154a574:     	str	x10, [sp, #0x478]
10154a578:     	str	x8, [sp, #0x440]
10154a57c:     	ldr	x8, [sp, #0x448]
10154a580:     	ldr	x9, [x20, #0x8]
10154a584:     	ldr	x8, [x8, #0x10]
10154a588:     	ldr	x9, [x9, #0x10]
10154a58c:     	cmp	x8, x9
10154a590:     	b.eq	0x10154ae64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f44>
10154a594:     	mov	w8, #0x0                ; =0
10154a598:     	mov	w9, #0xc                ; =12
10154a59c:     	strb	w9, [x23, #0x8]
10154a5a0:     	mov	w9, #0x27               ; =39
10154a5a4:     	str	x9, [x23, #0x18]
10154a5a8:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a5ac:     	add	x9, x9, #0x8e6
10154a5b0:     	b	0x10154ae74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f54>
10154a5b4:     	ldr	w9, [sp, #0x554]
10154a5b8:     	ldur	q0, [x27, #0x18]
10154a5bc:     	stur	q0, [x28, #0x18]
10154a5c0:     	ldur	q0, [x27, #0x28]
10154a5c4:     	stur	q0, [x28, #0x28]
10154a5c8:     	ldur	q0, [x27, #0x38]
10154a5cc:     	stur	q0, [x28, #0x38]
10154a5d0:     	ldr	x10, [sp, #0x598]
10154a5d4:     	str	x10, [x28, #0x48]
10154a5d8:     	ldur	q0, [x27, #0x8]
10154a5dc:     	stp	w8, w9, [x28]
10154a5e0:     	stur	q0, [x28, #0x8]
10154a5e4:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a5e8:     	str	wzr, [x23]
10154a5ec:     	mov	w8, #0xc                ; =12
10154a5f0:     	strb	w8, [x23, #0x8]
10154a5f4:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154a5f8:     	add	x8, x8, #0x556
10154a5fc:     	mov	w9, #0x29               ; =41
10154a600:     	b	0x10154a120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1200>
10154a604:     	str	wzr, [x23]
10154a608:     	mov	w8, #0xc                ; =12
10154a60c:     	strb	w8, [x23, #0x8]
10154a610:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a614:     	add	x8, x8, #0x90d
10154a618:     	mov	w9, #0x36               ; =54
10154a61c:     	b	0x10154a120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1200>
10154a620:     	mov	x9, x20
10154a624:     	ldr	x8, [x20, #0xc0]
10154a628:     	cmp	x8, #0x2
10154a62c:     	mov	x8, x22
10154a630:     	b.ne	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
10154a634:     	ldr	x9, [x9, #0x220]
10154a638:     	cmp	x9, #0x2
10154a63c:     	b.ne	0x10154a730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1810>
10154a640:     	ldr	x8, [x23, #0x360]
10154a644:     	ldr	w1, [x24, #0x4c]
10154a648:     	cmp	x8, x1
10154a64c:     	b.ls	0x10154c50c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35ec>
10154a650:     	ldr	x8, [x23, #0x358]
10154a654:     	mov	w9, #0x140              ; =320
10154a658:     	umaddl	x8, w1, w9, x8
10154a65c:     	ldrb	w9, [x8, #0x124]
10154a660:     	ldr	x8, [x25]
10154a664:     	cmp	w9, #0x7
10154a668:     	b.ne	0x10154a8ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x198c>
10154a66c:     	cbz	x8, 0x10154aaf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bd8>
10154a670:     	str	wzr, [x22]
10154a674:     	mov	w8, #0xc                ; =12
10154a678:     	strb	w8, [x22, #0x8]
10154a67c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a680:     	add	x8, x8, #0xc01
10154a684:     	mov	w9, #0x28               ; =40
10154a688:     	stp	x8, x9, [x22, #0x10]
10154a68c:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a690:     	mov	x0, x19
10154a694:     	ldr	x1, [sp, #0x58]
10154a698:     	mov	x2, x20
10154a69c:     	mov	x3, x24
10154a6a0:     	add	sp, sp, #0x800
10154a6a4:     	ldp	x29, x30, [sp, #0x50]
10154a6a8:     	ldp	x20, x19, [sp, #0x40]
10154a6ac:     	ldp	x22, x21, [sp, #0x30]
10154a6b0:     	ldp	x24, x23, [sp, #0x20]
10154a6b4:     	ldp	x26, x25, [sp, #0x10]
10154a6b8:     	ldp	x28, x27, [sp], #0x60
10154a6bc:     	b	0x10153d3cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23borrowed_string_failure>
10154a6c0:     	ldr	x0, [sp, #0x58]
10154a6c4:     	mov	x1, x20
10154a6c8:     	bl	0x10153d30c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
10154a6cc:     	cbz	x0, 0x10154a840 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1920>
10154a6d0:     	str	wzr, [x19]
10154a6d4:     	mov	w8, #0xc                ; =12
10154a6d8:     	strb	w8, [x19, #0x8]
10154a6dc:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a6e0:     	add	x8, x8, #0x6dc
10154a6e4:     	mov	w9, #0x2e               ; =46
10154a6e8:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154a6ec:     	str	wzr, [x28]
10154a6f0:     	mov	w8, #0xc                ; =12
10154a6f4:     	strb	w8, [x28, #0x8]
10154a6f8:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154a6fc:     	add	x8, x8, #0x12a
10154a700:     	mov	w9, #0x23               ; =35
10154a704:     	stp	x8, x9, [x28, #0x10]
10154a708:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a70c:     	str	wzr, [x23]
10154a710:     	mov	w8, #0xc                ; =12
10154a714:     	adrp	x9, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154a718:     	add	x9, x9, #0x3f
10154a71c:     	stp	x8, x9, [x23, #0x8]
10154a720:     	mov	w8, #0x14               ; =20
10154a724:     	str	x8, [x23, #0x18]
10154a728:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a72c:     	mov	x8, x22
10154a730:     	str	wzr, [x8]
10154a734:     	mov	w9, #0xc                ; =12
10154a738:     	strb	w9, [x8, #0x8]
10154a73c:     	adrp	x9, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154a740:     	add	x9, x9, #0xc29
10154a744:     	mov	w10, #0x28              ; =40
10154a748:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154a74c:     	ldr	x8, [sp, #0x58]
10154a750:     	ldr	x8, [x8, #0x490]
10154a754:     	add	x0, sp, #0x550
10154a758:     	add	x1, x8, #0x2f8
10154a75c:     	mov	w2, #0x0                ; =0
10154a760:     	mov	w4, #0x40               ; =64
10154a764:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10154a768:     	ldrb	w8, [sp, #0x550]
10154a76c:     	cmp	w8, #0xe
10154a770:     	b.ne	0x10154a9cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aac>
10154a774:     	ldr	x0, [x23, x22]
10154a778:     	ldr	x8, [x21, #0x40]
10154a77c:     	str	x8, [sp, #0x28]
10154a780:     	cmp	x0, x8
10154a784:     	b.hs	0x10154c570 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3650>
10154a788:     	ldr	x10, [x21, #0x38]
10154a78c:     	ldr	w3, [x21, #0xe0]
10154a790:     	ldr	x8, [sp, #0x58]
10154a794:     	ldr	x8, [x8, #0x490]
10154a798:     	mov	w9, #0x18               ; =24
10154a79c:     	mul	x9, x0, x9
10154a7a0:     	str	x10, [sp, #0x20]
10154a7a4:     	ldr	x4, [x10, x9]
10154a7a8:     	ldr	x1, [x8, #0x3c0]
10154a7ac:     	add	x0, sp, #0x550
10154a7b0:     	add	x2, x19, #0x488
10154a7b4:     	bl	0x101531b98 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames18take_managed_owner>
10154a7b8:     	ldr	w8, [sp, #0x550]
10154a7bc:     	cmp	w8, #0x6
10154a7c0:     	b.ne	0x10154aa90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b70>
10154a7c4:     	ldur	q0, [x27, #0x28]
10154a7c8:     	stur	q0, [x24, #0x24]
10154a7cc:     	ldur	q1, [x27, #0x38]
10154a7d0:     	ldur	q2, [x27, #0x18]
10154a7d4:     	ldur	q3, [x27, #0x8]
10154a7d8:     	stp	q3, q2, [sp, #0x60]
10154a7dc:     	stp	q0, q1, [sp, #0x80]
10154a7e0:     	add	x24, sp, #0x550
10154a7e4:     	add	x8, sp, #0x550
10154a7e8:     	ldr	x0, [sp, #0x58]
10154a7ec:     	mov	w1, #0x0                ; =0
10154a7f0:     	bl	0x101556974 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10154a7f4:     	ldr	x8, [sp, #0x550]
10154a7f8:     	cmp	x8, #0x1
10154a7fc:     	b.ne	0x10154ac18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cf8>
10154a800:     	ldur	q0, [x24, #0x18]
10154a804:     	ldur	q1, [x24, #0x28]
10154a808:     	ldur	q2, [x24, #0x38]
10154a80c:     	str	q1, [sp, #0x460]
10154a810:     	str	q2, [sp, #0x470]
10154a814:     	ldur	q3, [x24, #0x48]
10154a818:     	str	q3, [sp, #0x480]
10154a81c:     	ldur	q4, [x24, #0x8]
10154a820:     	str	q0, [sp, #0x450]
10154a824:     	str	q4, [sp, #0x440]
10154a828:     	stp	q1, q2, [x28, #0x20]
10154a82c:     	str	q3, [x28, #0x40]
10154a830:     	stp	q4, q0, [x28]
10154a834:     	add	x0, sp, #0x60
10154a838:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154a83c:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a840:     	ldr	x8, [x23, #0x558]
10154a844:     	cmp	x20, x8
10154a848:     	b.hs	0x10154a864 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1944>
10154a84c:     	ldr	x8, [x23, #0x550]
10154a850:     	mov	w9, #0x28               ; =40
10154a854:     	mul	x9, x20, x9
10154a858:     	ldr	w8, [x8, x9]
10154a85c:     	cmp	w8, #0x5
10154a860:     	b.ne	0x10154ab44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c24>
10154a864:     	cmp	x22, #0x6
10154a868:     	b.gt	0x10154aa44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b24>
10154a86c:     	cmp	x22, #0x4
10154a870:     	b.eq	0x10154ad24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e04>
10154a874:     	cmp	x22, #0x5
10154a878:     	b.eq	0x10154adac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e8c>
10154a87c:     	cmp	x22, #0x6
10154a880:     	b.ne	0x10154ad84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e64>
10154a884:     	ldr	q0, [x24]
10154a888:     	str	q0, [sp, #0x550]
10154a88c:     	ldr	x8, [x24, #0x10]
10154a890:     	str	x8, [sp, #0x560]
10154a894:     	add	x3, sp, #0x550
10154a898:     	mov	x0, x19
10154a89c:     	ldr	x1, [sp, #0x58]
10154a8a0:     	mov	x2, x20
10154a8a4:     	bl	0x1015417a4 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation25prepare_string_map_region>
10154a8a8:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a8ac:     	mov	x9, #0x0                ; =0
10154a8b0:     	ldr	x10, [x21, #0x330]
10154a8b4:     	ldr	x11, [x21, #0x3c8]
10154a8b8:     	ldr	x12, [x21, #0x430]
10154a8bc:     	ldp	q0, q1, [x21, #0x3d0]
10154a8c0:     	ldp	q2, q3, [x21, #0x3f0]
10154a8c4:     	ldr	q4, [x21, #0x410]
10154a8c8:     	ldr	q5, [x21, #0x420]
10154a8cc:     	mov	w13, #0x1               ; =1
10154a8d0:     	stp	x13, x9, [x20, #0xf8]
10154a8d4:     	str	x8, [x20, #0x108]
10154a8d8:     	ldp	q6, q7, [sp, #0x60]
10154a8dc:     	stp	q6, q7, [x20, #0x110]
10154a8e0:     	ldr	q6, [sp, #0x80]
10154a8e4:     	str	q6, [x20, #0x130]
10154a8e8:     	stp	x10, x11, [x20, #0x140]
10154a8ec:     	stp	q0, q1, [x20, #0x150]
10154a8f0:     	stp	q2, q3, [x20, #0x170]
10154a8f4:     	stp	q4, q5, [x20, #0x190]
10154a8f8:     	str	x12, [x20, #0x1b0]
10154a8fc:     	str	w19, [x20, #0x1b8]
10154a900:     	dup.2d	v0, x13
10154a904:     	stur	q0, [x22, #0x8]
10154a908:     	mov	w8, #0x6                ; =6
10154a90c:     	str	w8, [x22]
10154a910:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154a914:     	cbnz	x28, 0x10154a930 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a10>
10154a918:     	ldp	x1, x2, [x23, #0x8]
10154a91c:     	ldr	x0, [sp, #0x50]
10154a920:     	bl	0x10155c504 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
10154a924:     	tbz	w0, #0x0, 0x10154a930 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a10>
10154a928:     	mov	x8, #0x0                ; =0
10154a92c:     	b	0x10154a98c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a6c>
10154a930:     	ldr	x8, [sp, #0x48]
10154a934:     	str	wzr, [x8]
10154a938:     	mov	w9, #0xc                ; =12
10154a93c:     	strb	w9, [x8, #0x8]
10154a940:     	adrp	x9, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154a944:     	add	x9, x9, #0x3f6
10154a948:     	mov	w10, #0x38              ; =56
10154a94c:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154a950:     	ldr	x9, [x23, #0xa0]
10154a954:     	cbz	x9, 0x10154aa24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b04>
10154a958:     	ldr	x8, [x23, #0x98]
10154a95c:     	lsl	x9, x9, #5
10154a960:     	b	0x10154a970 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a50>
10154a964:     	add	x8, x8, #0x20
10154a968:     	subs	x9, x9, #0x20
10154a96c:     	b.eq	0x10154aa24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b04>
10154a970:     	ldr	w11, [x8, #0x18]
10154a974:     	ldr	x10, [sp, #0x50]
10154a978:     	cmp	x10, x11
10154a97c:     	b.ne	0x10154a964 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a44>
10154a980:     	ldr	w10, [x8, #0x1c]
10154a984:     	cmp	x28, x10
10154a988:     	b.ne	0x10154a964 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a44>
10154a98c:     	str	x8, [sp, #0x220]
10154a990:     	ldr	x9, [sp, #0x40]
10154a994:     	ldp	x8, x9, [x9, #0xd0]
10154a998:     	lsl	x9, x9, #6
10154a99c:     	cbz	x9, 0x10154ab78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c58>
10154a9a0:     	ldr	x10, [x8], #0x40
10154a9a4:     	sub	x9, x9, #0x40
10154a9a8:     	cbz	x10, 0x10154a99c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a7c>
10154a9ac:     	ldr	x8, [sp, #0x48]
10154a9b0:     	str	wzr, [x8]
10154a9b4:     	mov	w9, #0xc                ; =12
10154a9b8:     	strb	w9, [x8, #0x8]
10154a9bc:     	adrp	x9, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154a9c0:     	add	x9, x9, #0x3c4
10154a9c4:     	mov	w10, #0x32              ; =50
10154a9c8:     	b	0x101548fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154a9cc:     	ldr	q0, [sp, #0x550]
10154a9d0:     	ldr	q1, [sp, #0x560]
10154a9d4:     	str	q0, [sp, #0x440]
10154a9d8:     	str	q1, [sp, #0x450]
10154a9dc:     	ldr	q2, [sp, #0x570]
10154a9e0:     	str	q2, [sp, #0x460]
10154a9e4:     	ldr	x8, [sp, #0x580]
10154a9e8:     	str	x8, [sp, #0x470]
10154a9ec:     	stur	q0, [x27, #0x4]
10154a9f0:     	stur	q1, [x27, #0x14]
10154a9f4:     	stur	q2, [x27, #0x24]
10154a9f8:     	stur	x8, [x27, #0x34]
10154a9fc:     	str	wzr, [x28]
10154aa00:     	ldr	q0, [sp, #0x550]
10154aa04:     	ldr	q1, [sp, #0x560]
10154aa08:     	stur	q0, [x28, #0x4]
10154aa0c:     	stur	q1, [x28, #0x14]
10154aa10:     	ldr	q0, [sp, #0x570]
10154aa14:     	stur	q0, [x28, #0x24]
10154aa18:     	ldur	q0, [x27, #0x2c]
10154aa1c:     	str	q0, [x28, #0x30]
10154aa20:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154aa24:     	ldr	x8, [sp, #0x48]
10154aa28:     	str	wzr, [x8]
10154aa2c:     	mov	w9, #0xc                ; =12
10154aa30:     	adrp	x10, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154aa34:     	add	x10, x10, #0x439
10154aa38:     	stp	x9, x10, [x8, #0x8]
10154aa3c:     	mov	w9, #0x31               ; =49
10154aa40:     	b	0x1015491f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10154aa44:     	cmp	x22, #0x7
10154aa48:     	b.eq	0x10154ad54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e34>
10154aa4c:     	cmp	x22, #0x10
10154aa50:     	b.eq	0x10154addc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ebc>
10154aa54:     	cmp	x22, #0x11
10154aa58:     	b.ne	0x10154ad84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e64>
10154aa5c:     	ldp	x4, x5, [x24, #0x8]
10154aa60:     	ldr	x3, [x24]
10154aa64:     	mov	x0, x19
10154aa68:     	ldr	x1, [sp, #0x58]
10154aa6c:     	mov	x2, x20
10154aa70:     	add	sp, sp, #0x800
10154aa74:     	ldp	x29, x30, [sp, #0x50]
10154aa78:     	ldp	x20, x19, [sp, #0x40]
10154aa7c:     	ldp	x22, x21, [sp, #0x30]
10154aa80:     	ldp	x24, x23, [sp, #0x20]
10154aa84:     	ldp	x26, x25, [sp, #0x10]
10154aa88:     	ldp	x28, x27, [sp], #0x60
10154aa8c:     	b	0x1015589b8 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation21finish_join_map_chunk>
10154aa90:     	ldur	q0, [x27, #0x14]
10154aa94:     	ldur	q1, [x27, #0x24]
10154aa98:     	ldur	q2, [x27, #0x34]
10154aa9c:     	str	q1, [sp, #0x460]
10154aaa0:     	str	q2, [sp, #0x470]
10154aaa4:     	ldr	w9, [sp, #0x594]
10154aaa8:     	str	w9, [sp, #0x480]
10154aaac:     	ldur	q3, [x27, #0x4]
10154aab0:     	str	q0, [sp, #0x450]
10154aab4:     	str	q3, [sp, #0x440]
10154aab8:     	ldr	x10, [sp, #0x598]
10154aabc:     	stur	q0, [x28, #0x14]
10154aac0:     	stur	q1, [x28, #0x24]
10154aac4:     	stur	q2, [x28, #0x34]
10154aac8:     	str	w9, [x28, #0x44]
10154aacc:     	stur	q3, [x28, #0x4]
10154aad0:     	str	w8, [x28]
10154aad4:     	str	x10, [x28, #0x48]
10154aad8:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154aadc:     	str	wzr, [x23]
10154aae0:     	mov	w8, #0xc                ; =12
10154aae4:     	strb	w8, [x23, #0x8]
10154aae8:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154aaec:     	add	x8, x8, #0x943
10154aaf0:     	mov	w9, #0x24               ; =36
10154aaf4:     	b	0x10154a120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1200>
10154aaf8:     	add	x8, sp, #0x550
10154aafc:     	add	x0, x21, #0xf0
10154ab00:     	add	x2, x21, #0x2f8
10154ab04:     	bl	0x10154fa14 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10154ab08:     	ldr	x9, [sp, #0x550]
10154ab0c:     	ldr	x8, [sp, #0x558]
10154ab10:     	ldr	q0, [sp, #0x560]
10154ab14:     	ldr	q1, [sp, #0x570]
10154ab18:     	str	q0, [sp, #0x440]
10154ab1c:     	str	q1, [sp, #0x450]
10154ab20:     	ldr	q0, [sp, #0x580]
10154ab24:     	str	q0, [sp, #0x460]
10154ab28:     	cbz	x9, 0x10154ae0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1eec>
10154ab2c:     	ldr	q0, [sp, #0x440]
10154ab30:     	ldr	q1, [sp, #0x450]
10154ab34:     	stp	q0, q1, [sp, #0x60]
10154ab38:     	ldr	q0, [sp, #0x460]
10154ab3c:     	str	q0, [sp, #0x80]
10154ab40:     	b	0x10154a8b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1990>
10154ab44:     	str	wzr, [x19]
10154ab48:     	mov	w8, #0xc                ; =12
10154ab4c:     	strb	w8, [x19, #0x8]
10154ab50:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154ab54:     	add	x8, x8, #0x7f5
10154ab58:     	mov	w9, #0x24               ; =36
10154ab5c:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154ab60:     	adrp	x0, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154ab64:     	add	x0, x0, #0x1d0
10154ab68:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154ab6c:     	adrp	x0, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154ab70:     	add	x0, x0, #0x1e8
10154ab74:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154ab78:     	add	x8, sp, #0x220
10154ab7c:     	str	x8, [sp, #0x440]
10154ab80:     	str	x24, [sp, #0x448]
10154ab84:     	ldr	x19, [sp, #0x58]
10154ab88:     	str	x19, [sp, #0x450]
10154ab8c:     	ldr	x8, [sp, #0x38]
10154ab90:     	str	x8, [sp, #0x458]
10154ab94:     	str	x21, [sp, #0x460]
10154ab98:     	add	x0, sp, #0x550
10154ab9c:     	add	x1, sp, #0x440
10154aba0:     	bl	0x10152f488 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB6_10Invocation19end_numeric_segments4_0Be_>
10154aba4:     	ldr	x8, [x19, #0x490]
10154aba8:     	ldr	x2, [x8, #0xd8]
10154abac:     	ldr	x1, [x23, #0x40]
10154abb0:     	cmp	x1, x2
10154abb4:     	b.hi	0x10154c0e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31c4>
10154abb8:     	ldr	x0, [x8, #0xd0]
10154abbc:     	str	xzr, [sp, #0x440]
10154abc0:     	add	x2, sp, #0x440
10154abc4:     	bl	0x1014e01c4 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
10154abc8:     	ldr	w8, [sp, #0x550]
10154abcc:     	cmp	w8, #0x6
10154abd0:     	b.ne	0x10154ae30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f10>
10154abd4:     	ldr	x9, [sp, #0x58]
10154abd8:     	ldr	x8, [x9, #0x490]
10154abdc:     	str	wzr, [x8, #0x340]
10154abe0:     	ldr	x10, [x9, #0x490]
10154abe4:     	mov	w8, #0x1                ; =1
10154abe8:     	str	w8, [x10, #0x2f0]
10154abec:     	ldr	x8, [sp, #0x50]
10154abf0:     	str	w8, [x10, #0x2f4]
10154abf4:     	ldr	x8, [x9, #0x490]
10154abf8:     	cmp	x20, #0x2
10154abfc:     	cset	w9, ne
10154ac00:     	strb	w9, [x8, #0x460]
10154ac04:     	ldr	x8, [sp, #0x48]
10154ac08:     	str	xzr, [x8, #0x8]
10154ac0c:     	mov	w9, #0x6                ; =6
10154ac10:     	str	w9, [x8]
10154ac14:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154ac18:     	ldur	q0, [x24, #0x48]
10154ac1c:     	ldur	q1, [x24, #0x58]
10154ac20:     	str	q0, [sp, #0x480]
10154ac24:     	str	q1, [sp, #0x490]
10154ac28:     	ldur	x8, [x24, #0x68]
10154ac2c:     	str	x8, [sp, #0x4a0]
10154ac30:     	ldur	q2, [x24, #0x8]
10154ac34:     	ldur	q3, [x24, #0x18]
10154ac38:     	str	q2, [sp, #0x440]
10154ac3c:     	str	q3, [sp, #0x450]
10154ac40:     	ldur	q4, [x24, #0x38]
10154ac44:     	ldur	q5, [x24, #0x28]
10154ac48:     	stp	q2, q3, [sp, #0xa0]
10154ac4c:     	stp	q5, q4, [sp, #0xc0]
10154ac50:     	str	x8, [sp, #0x100]
10154ac54:     	stp	q0, q1, [sp, #0xe0]
10154ac58:     	ldr	w8, [x23]
10154ac5c:     	cmp	w8, #0x6
10154ac60:     	b.ne	0x10154ae88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f68>
10154ac64:     	ldp	q0, q1, [sp, #0x60]
10154ac68:     	str	q0, [sp, #0x440]
10154ac6c:     	str	q1, [sp, #0x450]
10154ac70:     	ldp	q0, q1, [sp, #0x80]
10154ac74:     	str	q0, [sp, #0x460]
10154ac78:     	str	q1, [sp, #0x470]
10154ac7c:     	ldr	x8, [sp, #0x58]
10154ac80:     	ldp	q0, q1, [x8, #0x80]
10154ac84:     	str	q0, [sp, #0x5d0]
10154ac88:     	str	q1, [sp, #0x5e0]
10154ac8c:     	ldr	x9, [x8, #0xa0]
10154ac90:     	str	x9, [sp, #0x5f0]
10154ac94:     	ldp	q0, q1, [x8, #0x40]
10154ac98:     	str	q0, [sp, #0x590]
10154ac9c:     	str	q1, [sp, #0x5a0]
10154aca0:     	ldp	q1, q0, [x8, #0x60]
10154aca4:     	str	q0, [sp, #0x5c0]
10154aca8:     	str	q1, [sp, #0x5b0]
10154acac:     	ldp	q0, q1, [x8]
10154acb0:     	str	q0, [sp, #0x550]
10154acb4:     	str	q1, [sp, #0x560]
10154acb8:     	ldp	q1, q0, [x8, #0x20]
10154acbc:     	str	q0, [sp, #0x580]
10154acc0:     	str	q1, [sp, #0x570]
10154acc4:     	ldr	x9, [x8, #0x490]
10154acc8:     	add	x8, sp, #0x110
10154accc:     	add	x1, sp, #0x440
10154acd0:     	add	x4, sp, #0x550
10154acd4:     	add	x5, x9, #0x3b8
10154acd8:     	add	x6, sp, #0xa0
10154acdc:     	ldr	x0, [sp, #0x30]
10154ace0:     	ldr	x2, [sp, #0x40]
10154ace4:     	mov	w3, #0x1                ; =1
10154ace8:     	bl	0x1027bf018 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private>
10154acec:     	b	0x10154af10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ff0>
10154acf0:     	ldp	q0, q1, [sp, #0x3a0]
10154acf4:     	stur	q0, [x27, #0x4]
10154acf8:     	stur	q1, [x27, #0x14]
10154acfc:     	ldr	q0, [sp, #0x3c0]
10154ad00:     	stur	q0, [x27, #0x24]
10154ad04:     	ldr	x8, [sp, #0x3d0]
10154ad08:     	stur	x8, [x27, #0x34]
10154ad0c:     	ldr	q0, [sp, #0x550]
10154ad10:     	ldr	q1, [sp, #0x560]
10154ad14:     	stur	q0, [x23, #0x4]
10154ad18:     	mov	w8, #0x2                ; =2
10154ad1c:     	str	w8, [x23]
10154ad20:     	b	0x10154a034 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1114>
10154ad24:     	mov	x0, x19
10154ad28:     	ldr	x1, [sp, #0x58]
10154ad2c:     	mov	x2, x20
10154ad30:     	mov	x3, x24
10154ad34:     	add	sp, sp, #0x800
10154ad38:     	ldp	x29, x30, [sp, #0x50]
10154ad3c:     	ldp	x20, x19, [sp, #0x40]
10154ad40:     	ldp	x22, x21, [sp, #0x30]
10154ad44:     	ldp	x24, x23, [sp, #0x20]
10154ad48:     	ldp	x26, x25, [sp, #0x10]
10154ad4c:     	ldp	x28, x27, [sp], #0x60
10154ad50:     	b	0x10153ca60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation21prepare_window_region>
10154ad54:     	mov	x0, x19
10154ad58:     	ldr	x1, [sp, #0x58]
10154ad5c:     	mov	x2, x20
10154ad60:     	mov	x3, x24
10154ad64:     	add	sp, sp, #0x800
10154ad68:     	ldp	x29, x30, [sp, #0x50]
10154ad6c:     	ldp	x20, x19, [sp, #0x40]
10154ad70:     	ldp	x22, x21, [sp, #0x30]
10154ad74:     	ldp	x24, x23, [sp, #0x20]
10154ad78:     	ldp	x26, x25, [sp, #0x10]
10154ad7c:     	ldp	x28, x27, [sp], #0x60
10154ad80:     	b	0x1015413fc <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation24finish_string_map_region>
10154ad84:     	ldr	x8, [sp, #0x58]
10154ad88:     	ldr	x8, [x8, #0xa8]
10154ad8c:     	cbz	x8, 0x10154b500 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25e0>
10154ad90:     	str	wzr, [x19]
10154ad94:     	mov	w8, #0xc                ; =12
10154ad98:     	strb	w8, [x19, #0x8]
10154ad9c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154ada0:     	add	x8, x8, #0x70a
10154ada4:     	mov	w9, #0x2d               ; =45
10154ada8:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154adac:     	mov	x0, x19
10154adb0:     	ldr	x1, [sp, #0x58]
10154adb4:     	mov	x2, x20
10154adb8:     	mov	x3, x24
10154adbc:     	add	sp, sp, #0x800
10154adc0:     	ldp	x29, x30, [sp, #0x50]
10154adc4:     	ldp	x20, x19, [sp, #0x40]
10154adc8:     	ldp	x22, x21, [sp, #0x30]
10154adcc:     	ldp	x24, x23, [sp, #0x20]
10154add0:     	ldp	x26, x25, [sp, #0x10]
10154add4:     	ldp	x28, x27, [sp], #0x60
10154add8:     	b	0x10153c464 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation20finish_window_region>
10154addc:     	mov	x0, x19
10154ade0:     	ldr	x1, [sp, #0x58]
10154ade4:     	mov	x2, x20
10154ade8:     	mov	x3, x24
10154adec:     	add	sp, sp, #0x800
10154adf0:     	ldp	x29, x30, [sp, #0x50]
10154adf4:     	ldp	x20, x19, [sp, #0x40]
10154adf8:     	ldp	x22, x21, [sp, #0x30]
10154adfc:     	ldp	x24, x23, [sp, #0x20]
10154ae00:     	ldp	x26, x25, [sp, #0x10]
10154ae04:     	ldp	x28, x27, [sp], #0x60
10154ae08:     	b	0x101558d18 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation22prepare_join_map_chunk>
10154ae0c:     	ldr	q0, [sp, #0x440]
10154ae10:     	ldr	q1, [sp, #0x450]
10154ae14:     	stp	q0, q1, [x22, #0x10]
10154ae18:     	ldr	q0, [sp, #0x460]
10154ae1c:     	str	q0, [x22, #0x30]
10154ae20:     	mov	w9, #0x2                ; =2
10154ae24:     	str	w9, [x22]
10154ae28:     	str	x8, [x22, #0x8]
10154ae2c:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154ae30:     	ldur	q0, [x27, #0x14]
10154ae34:     	ldr	x9, [sp, #0x48]
10154ae38:     	stur	q0, [x9, #0x14]
10154ae3c:     	ldur	q0, [x27, #0x24]
10154ae40:     	stur	q0, [x9, #0x24]
10154ae44:     	ldur	q0, [x27, #0x34]
10154ae48:     	stur	q0, [x9, #0x34]
10154ae4c:     	ldr	q0, [sp, #0x590]
10154ae50:     	str	q0, [x9, #0x40]
10154ae54:     	ldur	q0, [x27, #0x4]
10154ae58:     	stur	q0, [x9, #0x4]
10154ae5c:     	str	w8, [x9]
10154ae60:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154ae64:     	mov	w8, #0x1                ; =1
10154ae68:     	str	x8, [x23, #0x8]
10154ae6c:     	mov	w8, #0x6                ; =6
10154ae70:     	mov	w9, #0x2                ; =2
10154ae74:     	str	x9, [x23, #0x10]
10154ae78:     	str	w8, [x23]
10154ae7c:     	add	x0, sp, #0x440
10154ae80:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154ae84:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154ae88:     	ldp	q0, q1, [sp, #0x60]
10154ae8c:     	str	q0, [sp, #0x440]
10154ae90:     	str	q1, [sp, #0x450]
10154ae94:     	ldp	q0, q1, [sp, #0x80]
10154ae98:     	str	q0, [sp, #0x460]
10154ae9c:     	str	q1, [sp, #0x470]
10154aea0:     	ldr	x8, [sp, #0x58]
10154aea4:     	ldp	q0, q1, [x8, #0x80]
10154aea8:     	str	q0, [sp, #0x5d0]
10154aeac:     	str	q1, [sp, #0x5e0]
10154aeb0:     	ldr	x9, [x8, #0xa0]
10154aeb4:     	str	x9, [sp, #0x5f0]
10154aeb8:     	ldp	q0, q1, [x8, #0x40]
10154aebc:     	str	q0, [sp, #0x590]
10154aec0:     	str	q1, [sp, #0x5a0]
10154aec4:     	ldp	q1, q0, [x8, #0x60]
10154aec8:     	str	q0, [sp, #0x5c0]
10154aecc:     	str	q1, [sp, #0x5b0]
10154aed0:     	ldp	q0, q1, [x8]
10154aed4:     	str	q0, [sp, #0x550]
10154aed8:     	str	q1, [sp, #0x560]
10154aedc:     	ldp	q1, q0, [x8, #0x20]
10154aee0:     	str	q0, [sp, #0x580]
10154aee4:     	str	q1, [sp, #0x570]
10154aee8:     	ldr	x9, [x8, #0x490]
10154aeec:     	add	x8, sp, #0x110
10154aef0:     	add	x1, sp, #0x440
10154aef4:     	add	x5, sp, #0x550
10154aef8:     	add	x6, x9, #0x3b8
10154aefc:     	add	x7, sp, #0xa0
10154af00:     	ldp	x0, x2, [sp, #0x30]
10154af04:     	ldr	x3, [sp, #0x40]
10154af08:     	mov	w4, #0x1                ; =1
10154af0c:     	bl	0x1027be3e4 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private>
10154af10:     	ldr	x9, [sp, #0x110]
10154af14:     	add	x8, sp, #0x110
10154af18:     	cbz	x9, 0x10154b46c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x254c>
10154af1c:     	add	x10, sp, #0x110
10154af20:     	ldur	q0, [x10, #0xc8]
10154af24:     	stur	q0, [x25, #0xc8]
10154af28:     	ldur	q0, [x10, #0xd8]
10154af2c:     	stur	q0, [x25, #0xd8]
10154af30:     	ldur	q0, [x10, #0xe8]
10154af34:     	stur	q0, [x25, #0xe8]
10154af38:     	ldur	q0, [x10, #0xf8]
10154af3c:     	stur	q0, [x25, #0xf8]
10154af40:     	ldur	q0, [x10, #0x88]
10154af44:     	stur	q0, [x25, #0x88]
10154af48:     	ldur	q0, [x10, #0x98]
10154af4c:     	stur	q0, [x25, #0x98]
10154af50:     	ldur	q0, [x10, #0xa8]
10154af54:     	stur	q0, [x25, #0xa8]
10154af58:     	ldur	q0, [x10, #0xb8]
10154af5c:     	stur	q0, [x25, #0xb8]
10154af60:     	ldur	q0, [x10, #0x58]
10154af64:     	stur	q0, [x25, #0x58]
10154af68:     	ldur	q0, [x10, #0x68]
10154af6c:     	stur	q0, [x25, #0x68]
10154af70:     	ldur	q0, [x10, #0x78]
10154af74:     	stur	q0, [x25, #0x78]
10154af78:     	ldur	q0, [x8, #0x18]
10154af7c:     	stur	q0, [x25, #0x18]
10154af80:     	ldur	q0, [x8, #0x28]
10154af84:     	stur	q0, [x25, #0x28]
10154af88:     	ldur	q0, [x8, #0x38]
10154af8c:     	stur	q0, [x25, #0x38]
10154af90:     	ldur	q0, [x8, #0x48]
10154af94:     	stur	q0, [x25, #0x48]
10154af98:     	ldur	q0, [x8, #0x8]
10154af9c:     	stur	q0, [x25, #0x8]
10154afa0:     	str	x9, [sp, #0x220]
10154afa4:     	ldr	x8, [sp, #0x58]
10154afa8:     	ldr	x9, [x8, #0x490]
10154afac:     	sub	x8, x29, #0xa0
10154afb0:     	add	x0, x9, #0x3b8
10154afb4:     	bl	0x1023696e8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
10154afb8:     	ldr	x8, [x19, #0x5e8]
10154afbc:     	cmn	x8, #0x1, lsl #12       ; =0x1000
10154afc0:     	b.hs	0x10154c380 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3460>
10154afc4:     	add	x24, x8, #0x1, lsl #12  ; =0x1000
10154afc8:     	lsr	x8, x24, #60
10154afcc:     	cbnz	x8, 0x10154c3a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3480>
10154afd0:     	ldr	x8, [sp, #0x58]
10154afd4:     	ldr	x8, [x8, #0x490]
10154afd8:     	lsl	x4, x24, #4
10154afdc:     	mov	w19, #0x1               ; =1
10154afe0:     	add	x0, sp, #0x550
10154afe4:     	add	x1, x8, #0x2f8
10154afe8:     	mov	w2, #0x0                ; =0
10154afec:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10154aff0:     	ldrb	w8, [sp, #0x550]
10154aff4:     	cmp	w8, #0xe
10154aff8:     	b.ne	0x10154b4a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2588>
10154affc:     	add	x8, sp, #0x550
10154b000:     	sub	x0, x29, #0xa0
10154b004:     	mov	x1, x24
10154b008:     	bl	0x102d56530 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
10154b00c:     	ldr	w8, [sp, #0x550]
10154b010:     	cmp	w8, #0x1a
10154b014:     	b.ne	0x10154b678 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2758>
10154b018:     	ldur	q0, [x27, #0x18]
10154b01c:     	ldur	q1, [x27, #0x8]
10154b020:     	stp	q1, q0, [x29, #-0x80]
10154b024:     	ldr	x1, [x23, x22]
10154b028:     	ldr	x8, [sp, #0x28]
10154b02c:     	cmp	x1, x8
10154b030:     	b.hs	0x10154cb7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c5c>
10154b034:     	mov	w8, #0x18               ; =24
10154b038:     	ldr	x9, [sp, #0x20]
10154b03c:     	madd	x8, x1, x8, x9
10154b040:     	ldrb	w8, [x8, #0x12]
10154b044:     	tbz	w8, #0x0, 0x10154b1fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x22dc>
10154b048:     	ldr	x8, [sp, #0x58]
10154b04c:     	ldr	x8, [x8, #0x490]
10154b050:     	ldr	x8, [x8, #0x3c0]
10154b054:     	cbz	x8, 0x10154b73c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
10154b058:     	ldr	x9, [x8, #0x40]
10154b05c:     	cmp	x9, #0x2
10154b060:     	b.eq	0x10154b73c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
10154b064:     	ldr	x10, [x8, #0xd8]
10154b068:     	ldr	x9, [sp, #0x48]
10154b06c:     	cmp	x10, x9
10154b070:     	b.ne	0x10154b73c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
10154b074:     	ldr	x9, [x8, #0x80]
10154b078:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
10154b07c:     	cmp	x9, x10
10154b080:     	b.eq	0x10154b73c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
10154b084:     	ldr	x9, [x8, #0x90]
10154b088:     	cmp	x1, x9
10154b08c:     	b.hs	0x10154b73c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x281c>
10154b090:     	ldr	x8, [x8, #0x88]
10154b094:     	mov	w9, #0x70               ; =112
10154b098:     	madd	x8, x1, x9, x8
10154b09c:     	ldr	x11, [x8]
10154b0a0:     	ldr	d0, [x8, #0x8]
10154b0a4:     	ldrb	w12, [x8, #0x10]
10154b0a8:     	ldp	x9, x10, [x8, #0x18]
10154b0ac:     	str	xzr, [x8]
10154b0b0:     	cbz	x11, 0x10154c0f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31d8>
10154b0b4:     	ldur	q1, [x8, #0x58]
10154b0b8:     	stur	q1, [x26, #0x58]
10154b0bc:     	ldr	x13, [x8, #0x68]
10154b0c0:     	str	x13, [sp, #0x398]
10154b0c4:     	str	x11, [sp, #0x330]
10154b0c8:     	str	d0, [sp, #0x338]
10154b0cc:     	strb	w12, [sp, #0x340]
10154b0d0:     	ldur	w11, [x8, #0x11]
10154b0d4:     	stur	w11, [x26, #0x11]
10154b0d8:     	ldr	w11, [x8, #0x14]
10154b0dc:     	str	w11, [sp, #0x344]
10154b0e0:     	str	x9, [sp, #0x348]
10154b0e4:     	str	x10, [sp, #0x350]
10154b0e8:     	ldur	q0, [x8, #0x28]
10154b0ec:     	stur	q0, [x26, #0x28]
10154b0f0:     	ldur	q0, [x8, #0x38]
10154b0f4:     	stur	q0, [x26, #0x38]
10154b0f8:     	ldur	q0, [x8, #0x48]
10154b0fc:     	stur	q0, [x26, #0x48]
10154b100:     	add	x0, sp, #0x550
10154b104:     	add	x1, sp, #0x220
10154b108:     	mov	w2, #0x108              ; =264
10154b10c:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
10154b110:     	mov	w19, #0x0               ; =0
10154b114:     	add	x24, sp, #0x440
10154b118:     	add	x8, sp, #0x440
10154b11c:     	add	x0, sp, #0x550
10154b120:     	add	x1, sp, #0x330
10154b124:     	bl	0x102e13d2c <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix23with_append_preparation>
10154b128:     	ldr	x8, [sp, #0x440]
10154b12c:     	cbz	x8, 0x10154c204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32e4>
10154b130:     	add	x9, sp, #0x220
10154b134:     	ldr	w10, [sp, #0x448]
10154b138:     	add	x11, sp, #0x440
10154b13c:     	ldur	q0, [x11, #0x1c]
10154b140:     	ldur	q1, [x11, #0x2c]
10154b144:     	ldur	q2, [x11, #0x3c]
10154b148:     	str	q1, [sp, #0x410]
10154b14c:     	str	q2, [sp, #0x420]
10154b150:     	ldur	q1, [x11, #0x48]
10154b154:     	stur	q1, [x26, #0xfc]
10154b158:     	ldur	q1, [x11, #0xc]
10154b15c:     	stp	q1, q0, [sp, #0x3f0]
10154b160:     	ldur	q0, [x11, #0xc8]
10154b164:     	stur	q0, [x9, #0xc8]
10154b168:     	ldur	q0, [x11, #0xd8]
10154b16c:     	stur	q0, [x9, #0xd8]
10154b170:     	ldur	q0, [x11, #0xe8]
10154b174:     	stur	q0, [x9, #0xe8]
10154b178:     	ldur	q0, [x11, #0xf8]
10154b17c:     	stur	q0, [x9, #0xf8]
10154b180:     	ldur	q0, [x11, #0x88]
10154b184:     	stur	q0, [x9, #0x88]
10154b188:     	ldur	q0, [x11, #0x98]
10154b18c:     	stur	q0, [x9, #0x98]
10154b190:     	ldur	q0, [x11, #0xa8]
10154b194:     	stur	q0, [x9, #0xa8]
10154b198:     	ldur	q0, [x11, #0xb8]
10154b19c:     	stur	q0, [x9, #0xb8]
10154b1a0:     	ldur	q0, [x11, #0x58]
10154b1a4:     	stur	q0, [x9, #0x58]
10154b1a8:     	ldur	q0, [x11, #0x68]
10154b1ac:     	stur	q0, [x9, #0x68]
10154b1b0:     	ldur	q0, [x11, #0x78]
10154b1b4:     	stur	q0, [x9, #0x78]
10154b1b8:     	ldur	q0, [x26, #0xfc]
10154b1bc:     	stur	q0, [x26, #0xac]
10154b1c0:     	ldr	q0, [sp, #0x420]
10154b1c4:     	ldr	q1, [sp, #0x410]
10154b1c8:     	stp	q1, q0, [sp, #0x3c0]
10154b1cc:     	ldp	q2, q0, [sp, #0x3f0]
10154b1d0:     	stp	q2, q0, [sp, #0x3a0]
10154b1d4:     	stur	q0, [x25, #0x1c]
10154b1d8:     	stur	q1, [x25, #0x2c]
10154b1dc:     	stur	q2, [x25, #0xc]
10154b1e0:     	ldr	q0, [sp, #0x3d0]
10154b1e4:     	stur	q0, [x25, #0x3c]
10154b1e8:     	ldur	q0, [x26, #0xac]
10154b1ec:     	stur	q0, [x25, #0x48]
10154b1f0:     	str	x8, [sp, #0x220]
10154b1f4:     	str	w10, [sp, #0x228]
10154b1f8:     	ldr	x1, [x23, x22]
10154b1fc:     	mov	w19, #0x1               ; =1
10154b200:     	mov	x0, x20
10154b204:     	bl	0x101566b74 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare16readonly_numericNtB2_5Proof8capacity>
10154b208:     	cmp	x0, #0x1
10154b20c:     	b.ne	0x10154b884 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2964>
10154b210:     	mov	x20, x1
10154b214:     	add	x8, sp, #0x550
10154b218:     	add	x0, sp, #0x220
10154b21c:     	bl	0x102e13c14 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix20reserved_native_view>
10154b220:     	ldr	w8, [sp, #0x550]
10154b224:     	tbz	w8, #0x0, 0x10154bd94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e74>
10154b228:     	ldr	x8, [sp, #0x58]
10154b22c:     	ldr	x10, [x8, #0x4d0]
10154b230:     	cbz	x10, 0x10154c020 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3100>
10154b234:     	ldr	x8, [x23, x22]
10154b238:     	ldr	x9, [x21, #0xb0]
10154b23c:     	add	x8, x9, x8, lsl #2
10154b240:     	add	x11, x8, #0x3
10154b244:     	ldr	x8, [sp, #0x58]
10154b248:     	ldr	x8, [x8, #0x4d8]
10154b24c:     	cmp	x11, x8
10154b250:     	b.hs	0x10154c020 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3100>
10154b254:     	ldr	x19, [sp, #0x558]
10154b258:     	ldr	x9, [sp, #0x560]
10154b25c:     	ldr	x8, [sp, #0x568]
10154b260:     	str	x9, [x10, x11, lsl #3]
10154b264:     	ldr	x10, [sp, #0x58]
10154b268:     	ldr	x10, [x10, #0x4d0]
10154b26c:     	cbz	x10, 0x10154bf58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
10154b270:     	ldr	x11, [x23, x22]
10154b274:     	ldr	x12, [x21, #0xb0]
10154b278:     	add	x11, x12, x11, lsl #2
10154b27c:     	add	x11, x11, #0x4
10154b280:     	ldr	x12, [sp, #0x58]
10154b284:     	ldr	x12, [x12, #0x4d8]
10154b288:     	cmp	x11, x12
10154b28c:     	b.hs	0x10154bf58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
10154b290:     	mov	w12, #0x1               ; =1
10154b294:     	str	x12, [x10, x11, lsl #3]
10154b298:     	ldr	x10, [sp, #0x58]
10154b29c:     	ldr	x10, [x10, #0x4d0]
10154b2a0:     	cbz	x10, 0x10154bf58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
10154b2a4:     	ldr	x11, [x23, x22]
10154b2a8:     	ldr	x12, [x21, #0xb0]
10154b2ac:     	add	x11, x12, x11, lsl #2
10154b2b0:     	add	x11, x11, #0x5
10154b2b4:     	ldr	x12, [sp, #0x58]
10154b2b8:     	ldr	x12, [x12, #0x4d8]
10154b2bc:     	cmp	x11, x12
10154b2c0:     	b.hs	0x10154bf58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
10154b2c4:     	str	x9, [x10, x11, lsl #3]
10154b2c8:     	ldr	x9, [sp, #0x58]
10154b2cc:     	ldr	x9, [x9, #0x4d0]
10154b2d0:     	cbz	x9, 0x10154bf58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
10154b2d4:     	add	x10, x20, #0x2
10154b2d8:     	ldr	x11, [sp, #0x58]
10154b2dc:     	ldr	x11, [x11, #0x4d8]
10154b2e0:     	cmp	x10, x11
10154b2e4:     	b.hs	0x10154bf58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
10154b2e8:     	str	x8, [x9, x10, lsl #3]
10154b2ec:     	b	0x10154b894 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2974>
10154b2f0:     	ldur	w15, [x9, #0x11]
10154b2f4:     	stur	w15, [x27, #0x9]
10154b2f8:     	ldur	w15, [x9, #0x14]
10154b2fc:     	str	w15, [sp, #0x55c]
10154b300:     	str	w14, [sp, #0x550]
10154b304:     	str	w13, [sp, #0x554]
10154b308:     	strb	w12, [sp, #0x558]
10154b30c:     	str	x11, [sp, #0x560]
10154b310:     	str	x10, [sp, #0x568]
10154b314:     	ldur	q0, [x9, #0x28]
10154b318:     	ldur	q1, [x9, #0x38]
10154b31c:     	str	q1, [sp, #0x580]
10154b320:     	str	q0, [sp, #0x570]
10154b324:     	ldur	q0, [x9, #0x48]
10154b328:     	ldur	q1, [x9, #0x58]
10154b32c:     	ldur	q2, [x9, #0x68]
10154b330:     	ldur	q3, [x9, #0x78]
10154b334:     	ldur	q4, [x9, #0x88]
10154b338:     	ldur	q5, [x9, #0x98]
10154b33c:     	ldur	q6, [x9, #0xa8]
10154b340:     	ldur	q7, [x9, #0xb8]
10154b344:     	str	q7, [sp, #0x600]
10154b348:     	str	q6, [sp, #0x5f0]
10154b34c:     	str	q5, [sp, #0x5e0]
10154b350:     	str	q4, [sp, #0x5d0]
10154b354:     	str	q3, [sp, #0x5c0]
10154b358:     	str	q2, [sp, #0x5b0]
10154b35c:     	str	q0, [sp, #0x590]
10154b360:     	str	q1, [sp, #0x5a0]
10154b364:     	ldr	x9, [x8, #0x48]
10154b368:     	cmn	x9, #0x1
10154b36c:     	b.eq	0x10154c3e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34c0>
10154b370:     	add	x9, x9, #0x1
10154b374:     	str	x9, [x8, #0x48]
10154b378:     	ldr	x8, [x8, #0x50]
10154b37c:     	cmp	x9, x8
10154b380:     	b.ne	0x10154b3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24d8>
10154b384:     	ldr	x8, [x20, #0x3d8]
10154b388:     	cbz	x8, 0x10154b3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24d8>
10154b38c:     	ldr	x10, [x20, #0x3d0]
10154b390:     	add	x11, x10, #0x1
10154b394:     	ldr	x12, [x20, #0x3c0]
10154b398:     	cmp	x11, x12
10154b39c:     	csel	x12, xzr, x12, lo
10154b3a0:     	sub	x11, x11, x12
10154b3a4:     	str	x11, [x20, #0x3d0]
10154b3a8:     	sub	x8, x8, #0x1
10154b3ac:     	str	x8, [x20, #0x3d8]
10154b3b0:     	ldr	x8, [x20, #0x3c8]
10154b3b4:     	mov	w9, #0x58               ; =88
10154b3b8:     	madd	x8, x10, x9, x8
10154b3bc:     	ldp	q1, q0, [x8]
10154b3c0:     	str	q1, [sp, #0x440]
10154b3c4:     	str	q0, [sp, #0x450]
10154b3c8:     	ldp	q1, q0, [x8, #0x30]
10154b3cc:     	ldr	x9, [x8, #0x50]
10154b3d0:     	ldr	q2, [x8, #0x20]
10154b3d4:     	str	x9, [sp, #0x490]
10154b3d8:     	str	q0, [sp, #0x480]
10154b3dc:     	str	q2, [sp, #0x460]
10154b3e0:     	str	q1, [sp, #0x470]
10154b3e4:     	ldr	x8, [sp, #0x440]
10154b3e8:     	cbz	x8, 0x10154b3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24d8>
10154b3ec:     	mov	w24, #0x1               ; =1
10154b3f0:     	add	x0, sp, #0x440
10154b3f4:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154b3f8:     	ldr	x9, [x21, #0x18]
10154b3fc:     	cbz	x9, 0x10154b648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2728>
10154b400:     	ldr	w0, [sp, #0x608]
10154b404:     	ldr	x8, [x21, #0x10]
10154b408:     	cmp	x9, #0x1
10154b40c:     	b.ne	0x10154b540 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2620>
10154b410:     	mov	x10, #0x0               ; =0
10154b414:     	b	0x10154b564 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2644>
10154b418:     	ldur	w8, [x9, #0x11]
10154b41c:     	str	w8, [sp, #0xa0]
10154b420:     	ldur	w8, [x9, #0x14]
10154b424:     	stur	w8, [sp, #0xa3]
10154b428:     	ldur	q0, [x9, #0x28]
10154b42c:     	ldur	q1, [x9, #0x38]
10154b430:     	stp	q0, q1, [sp, #0x110]
10154b434:     	ldur	q0, [x9, #0x48]
10154b438:     	str	q0, [sp, #0x330]
10154b43c:     	stp	w14, w13, [x19]
10154b440:     	strb	w12, [x19, #0x8]
10154b444:     	mov	w8, w8
10154b448:     	str	w8, [x19, #0xc]
10154b44c:     	ldr	w8, [sp, #0xa0]
10154b450:     	stur	w8, [x19, #0x9]
10154b454:     	stp	x11, x10, [x19, #0x10]
10154b458:     	ldp	q1, q0, [sp, #0x110]
10154b45c:     	stp	q1, q0, [x19, #0x20]
10154b460:     	ldr	q0, [sp, #0x330]
10154b464:     	str	q0, [x19, #0x40]
10154b468:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154b46c:     	ldr	x1, [x19, #0x378]
10154b470:     	ldr	x2, [x19, #0x380]
10154b474:     	add	x0, sp, #0x550
10154b478:     	add	x4, x8, #0x8
10154b47c:     	ldr	x3, [sp, #0x50]
10154b480:     	bl	0x10152f2d4 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14numeric_writesNtB6_10Invocation21prepare_numeric_writes1_0Be_>
10154b484:     	ldr	q0, [sp, #0x570]
10154b488:     	ldr	q1, [sp, #0x580]
10154b48c:     	stp	q0, q1, [x28, #0x20]
10154b490:     	ldr	q0, [sp, #0x590]
10154b494:     	str	q0, [x28, #0x40]
10154b498:     	ldr	q0, [sp, #0x560]
10154b49c:     	ldr	q1, [sp, #0x550]
10154b4a0:     	stp	q1, q0, [x28]
10154b4a4:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154b4a8:     	ldr	q0, [sp, #0x550]
10154b4ac:     	ldr	q1, [sp, #0x560]
10154b4b0:     	str	q0, [sp, #0x440]
10154b4b4:     	str	q1, [sp, #0x450]
10154b4b8:     	ldr	q2, [sp, #0x570]
10154b4bc:     	str	q2, [sp, #0x460]
10154b4c0:     	ldr	x8, [sp, #0x580]
10154b4c4:     	str	x8, [sp, #0x470]
10154b4c8:     	stur	q0, [x27, #0x4]
10154b4cc:     	stur	q1, [x27, #0x14]
10154b4d0:     	stur	q2, [x27, #0x24]
10154b4d4:     	stur	x8, [x27, #0x34]
10154b4d8:     	str	wzr, [x28]
10154b4dc:     	ldr	q0, [sp, #0x550]
10154b4e0:     	ldr	q1, [sp, #0x560]
10154b4e4:     	stur	q0, [x28, #0x4]
10154b4e8:     	stur	q1, [x28, #0x14]
10154b4ec:     	ldr	q0, [sp, #0x570]
10154b4f0:     	stur	q0, [x28, #0x24]
10154b4f4:     	ldur	q0, [x27, #0x2c]
10154b4f8:     	str	q0, [x28, #0x30]
10154b4fc:     	b	0x10154b6b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2794>
10154b500:     	cmp	x22, #0x1
10154b504:     	b.gt	0x10154b6d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27b8>
10154b508:     	cbz	x22, 0x10154b758 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2838>
10154b50c:     	cmp	x22, #0x1
10154b510:     	b.ne	0x10154b7cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28ac>
10154b514:     	ldr	x8, [sp, #0x58]
10154b518:     	ldr	x8, [x8, #0x490]
10154b51c:     	ldrb	w8, [x8, #0x460]
10154b520:     	tbz	w8, #0x0, 0x10154bae4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bc4>
10154b524:     	str	wzr, [x19]
10154b528:     	mov	w8, #0xc                ; =12
10154b52c:     	strb	w8, [x19, #0x8]
10154b530:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154b534:     	add	x8, x8, #0x752
10154b538:     	mov	w9, #0x16               ; =22
10154b53c:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154b540:     	mov	x10, #0x0               ; =0
10154b544:     	lsr	x11, x9, #1
10154b548:     	add	x12, x11, x10
10154b54c:     	ldr	w13, [x8, x12, lsl #2]
10154b550:     	cmp	w13, w0
10154b554:     	csel	x10, x10, x12, hi
10154b558:     	sub	x9, x9, x11
10154b55c:     	cmp	x9, #0x1
10154b560:     	b.hi	0x10154b544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2624>
10154b564:     	ldr	w8, [x8, x10, lsl #2]
10154b568:     	cmp	w8, w0
10154b56c:     	b.ne	0x10154b648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2728>
10154b570:     	ldr	x1, [x22, #0x380]
10154b574:     	cmp	x1, x0
10154b578:     	b.ls	0x10154cb68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c48>
10154b57c:     	ldr	x8, [x22, #0x378]
10154b580:     	mov	w9, #0x170              ; =368
10154b584:     	umaddl	x8, w0, w9, x8
10154b588:     	add	x9, x8, #0x15c
10154b58c:     	ldr	w8, [x8, #0x16c]
10154b590:     	str	w8, [sp, #0x450]
10154b594:     	ldr	q0, [x9]
10154b598:     	str	q0, [sp, #0x440]
10154b59c:     	mov	w24, #0x1               ; =1
10154b5a0:     	add	x8, sp, #0x220
10154b5a4:     	add	x0, sp, #0x440
10154b5a8:     	bl	0x1027055f0 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
10154b5ac:     	ldr	w8, [x21, #0x48]
10154b5b0:     	ldr	w9, [sp, #0x220]
10154b5b4:     	cmp	w9, #0x1
10154b5b8:     	b.ne	0x10154b5c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26a8>
10154b5bc:     	ldr	w9, [sp, #0x224]
10154b5c0:     	cmp	w9, w8
10154b5c4:     	b.eq	0x10154b5e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26c0>
10154b5c8:     	ldr	w9, [sp, #0x228]
10154b5cc:     	cmp	w9, #0x1
10154b5d0:     	b.ne	0x10154b648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2728>
10154b5d4:     	ldr	w9, [sp, #0x22c]
10154b5d8:     	cmp	w9, w8
10154b5dc:     	b.ne	0x10154b648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2728>
10154b5e0:     	ldr	x22, [sp, #0x550]
10154b5e4:     	cmp	x22, #0x0
10154b5e8:     	cset	w23, eq
10154b5ec:     	cbz	x22, 0x10154b804 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28e4>
10154b5f0:     	ldr	q0, [sp, #0x550]
10154b5f4:     	ldr	q1, [sp, #0x560]
10154b5f8:     	str	q0, [sp, #0x440]
10154b5fc:     	str	q1, [sp, #0x450]
10154b600:     	ldr	q0, [sp, #0x570]
10154b604:     	ldr	q1, [sp, #0x580]
10154b608:     	str	q0, [sp, #0x460]
10154b60c:     	str	q1, [sp, #0x470]
10154b610:     	ldr	x9, [x20, #0x490]
10154b614:     	ldr	w1, [x21, #0x4c]
10154b618:     	add	x8, sp, #0x220
10154b61c:     	add	x0, x9, #0xf0
10154b620:     	add	x2, sp, #0x440
10154b624:     	add	x3, x9, #0x2f8
10154b628:     	bl	0x101551af4 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
10154b62c:     	ldrb	w8, [sp, #0x220]
10154b630:     	cmp	w8, #0x14
10154b634:     	b.ne	0x10154b9c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2aa8>
10154b638:     	mov	w24, #0x0               ; =0
10154b63c:     	add	x0, sp, #0x440
10154b640:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154b644:     	b	0x10154b81c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28fc>
10154b648:     	str	wzr, [x19]
10154b64c:     	mov	w9, #0xc                ; =12
10154b650:     	strb	w9, [x19, #0x8]
10154b654:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154b658:     	add	x8, x8, #0xaec
10154b65c:     	mov	w9, #0x2d               ; =45
10154b660:     	stp	x8, x9, [x19, #0x10]
10154b664:     	ldr	x8, [sp, #0x550]
10154b668:     	cbz	x8, 0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154b66c:     	add	x0, sp, #0x550
10154b670:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154b674:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154b678:     	ldur	q0, [x27, #0x4]
10154b67c:     	ldur	q1, [x27, #0x14]
10154b680:     	str	q0, [sp, #0x440]
10154b684:     	str	q1, [sp, #0x450]
10154b688:     	ldr	w9, [sp, #0x574]
10154b68c:     	str	w9, [sp, #0x460]
10154b690:     	ldr	x10, [sp, #0x578]
10154b694:     	stur	q0, [x28, #0x14]
10154b698:     	stur	q1, [x28, #0x24]
10154b69c:     	str	w9, [x28, #0x34]
10154b6a0:     	str	wzr, [x28]
10154b6a4:     	mov	w9, #0xd                ; =13
10154b6a8:     	strb	w9, [x28, #0x8]
10154b6ac:     	str	w8, [x28, #0x10]
10154b6b0:     	str	x10, [x28, #0x38]
10154b6b4:     	ldur	x8, [x29, #-0xa0]
10154b6b8:     	mov	x9, #-0x1               ; =-1
10154b6bc:     	ldaddl	x9, x8, [x8]
10154b6c0:     	cmp	x8, #0x1
10154b6c4:     	b.ne	0x10154bddc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ebc>
10154b6c8:     	dmb	ishld
10154b6cc:     	sub	x0, x29, #0xa0
10154b6d0:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154b6d4:     	b	0x10154bddc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ebc>
10154b6d8:     	cmp	x22, #0x2
10154b6dc:     	b.eq	0x10154b784 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2864>
10154b6e0:     	cmp	x22, #0x12
10154b6e4:     	b.ne	0x10154b7cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28ac>
10154b6e8:     	ldr	x8, [sp, #0x58]
10154b6ec:     	ldr	x8, [x8, #0x490]
10154b6f0:     	ldrb	w8, [x8, #0x460]
10154b6f4:     	tbnz	w8, #0x0, 0x10154b70c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27ec>
10154b6f8:     	ldp	x8, x9, [x24]
10154b6fc:     	ldr	x10, [x24, #0x10]
10154b700:     	orr	x8, x8, x9
10154b704:     	orr	x8, x8, x10
10154b708:     	cbz	x8, 0x10154be6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4c>
10154b70c:     	str	wzr, [x19]
10154b710:     	mov	w8, #0xc                ; =12
10154b714:     	strb	w8, [x19, #0x8]
10154b718:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154b71c:     	add	x8, x8, #0x7c8
10154b720:     	mov	w9, #0x2d               ; =45
10154b724:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154b728:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154b72c:     	add	x2, x2, #0xe8
10154b730:     	mov	x0, x9
10154b734:     	mov	x1, x10
10154b738:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154b73c:     	str	wzr, [x28]
10154b740:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154b744:     	add	x8, x8, #0xb9e
10154b748:     	mov	w9, #0xc                ; =12
10154b74c:     	stp	x9, x8, [x28, #0x8]
10154b750:     	mov	w8, #0x30               ; =48
10154b754:     	b	0x10154bdac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e8c>
10154b758:     	ldr	x8, [sp, #0x58]
10154b75c:     	ldr	x8, [x8, #0x490]
10154b760:     	ldrb	w8, [x8, #0x460]
10154b764:     	tbz	w8, #0x0, 0x10154bc18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2cf8>
10154b768:     	str	wzr, [x19]
10154b76c:     	mov	w8, #0xc                ; =12
10154b770:     	strb	w8, [x19, #0x8]
10154b774:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154b778:     	add	x8, x8, #0x7b0
10154b77c:     	mov	w9, #0x18               ; =24
10154b780:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154b784:     	ldr	x8, [sp, #0x58]
10154b788:     	ldr	x8, [x8, #0x490]
10154b78c:     	ldrb	w8, [x8, #0x460]
10154b790:     	tbnz	w8, #0x0, 0x10154bd5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e3c>
10154b794:     	ldr	x8, [x24, #0x10]
10154b798:     	cbnz	x8, 0x10154bd5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e3c>
10154b79c:     	ldp	x3, x4, [x24]
10154b7a0:     	mov	x0, x19
10154b7a4:     	ldr	x1, [sp, #0x58]
10154b7a8:     	mov	x2, x20
10154b7ac:     	add	sp, sp, #0x800
10154b7b0:     	ldp	x29, x30, [sp, #0x50]
10154b7b4:     	ldp	x20, x19, [sp, #0x40]
10154b7b8:     	ldp	x22, x21, [sp, #0x30]
10154b7bc:     	ldp	x24, x23, [sp, #0x20]
10154b7c0:     	ldp	x26, x25, [sp, #0x10]
10154b7c4:     	ldp	x28, x27, [sp], #0x60
10154b7c8:     	b	0x101536de4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper>
10154b7cc:     	ldr	x5, [x24]
10154b7d0:     	mov	x0, x19
10154b7d4:     	ldr	x1, [sp, #0x58]
10154b7d8:     	mov	x2, x20
10154b7dc:     	mov	x3, x22
10154b7e0:     	mov	x4, x21
10154b7e4:     	add	sp, sp, #0x800
10154b7e8:     	ldp	x29, x30, [sp, #0x50]
10154b7ec:     	ldp	x20, x19, [sp, #0x40]
10154b7f0:     	ldp	x22, x21, [sp, #0x30]
10154b7f4:     	ldp	x24, x23, [sp, #0x20]
10154b7f8:     	ldp	x26, x25, [sp, #0x10]
10154b7fc:     	ldp	x28, x27, [sp], #0x60
10154b800:     	b	0x1015370d4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper>
10154b804:     	ldr	x8, [x20, #0x4d0]
10154b808:     	cbz	x8, 0x10154bd78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e58>
10154b80c:     	ldr	x9, [x20, #0x4d8]
10154b810:     	cbz	x9, 0x10154bd78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e58>
10154b814:     	ldr	x9, [sp, #0x558]
10154b818:     	str	x9, [x8]
10154b81c:     	ldr	w8, [sp, #0x608]
10154b820:     	ldr	x10, [x20, #0x490]
10154b824:     	mov	w11, #0x1               ; =1
10154b828:     	str	w11, [x10, #0x2f0]
10154b82c:     	str	w8, [x10, #0x2f4]
10154b830:     	ldr	x8, [x20, #0x490]
10154b834:     	strb	w11, [x8, #0x460]
10154b838:     	ldr	x8, [x20, #0x3c0]
10154b83c:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10154b840:     	cmp	x8, x9
10154b844:     	b.eq	0x10154be60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f40>
10154b848:     	ldr	x8, [x20, #0x3d8]
10154b84c:     	cbnz	x8, 0x10154be60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f40>
10154b850:     	ldr	x9, [x20, #0x3e8]
10154b854:     	ldr	x8, [x20, #0x3f8]
10154b858:     	cmp	x8, x9
10154b85c:     	b.eq	0x10154be4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f2c>
10154b860:     	str	wzr, [x19]
10154b864:     	mov	w8, #0xc                ; =12
10154b868:     	strb	w8, [x19, #0x8]
10154b86c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154b870:     	add	x8, x8, #0xb19
10154b874:     	mov	w9, #0x25               ; =37
10154b878:     	stp	x8, x9, [x19, #0x10]
10154b87c:     	cbz	x22, 0x10154b664 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2744>
10154b880:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154b884:     	add	x8, sp, #0x550
10154b888:     	add	x0, sp, #0x220
10154b88c:     	bl	0x102e0eda8 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix12elements_mut>
10154b890:     	ldr	x19, [sp, #0x558]
10154b894:     	add	x0, sp, #0x550
10154b898:     	add	x1, sp, #0x220
10154b89c:     	mov	w2, #0x108              ; =264
10154b8a0:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
10154b8a4:     	ldr	x8, [sp, #0x58]
10154b8a8:     	ldr	x8, [x8, #0x490]
10154b8ac:     	ldr	x8, [x8, #0x3c0]
10154b8b0:     	cbz	x8, 0x10154ba20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b00>
10154b8b4:     	ldr	x9, [x8, #0x40]
10154b8b8:     	cmp	x9, #0x2
10154b8bc:     	b.eq	0x10154ba20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b00>
10154b8c0:     	ldr	x10, [x8, #0xd8]
10154b8c4:     	ldr	x9, [sp, #0x48]
10154b8c8:     	cmp	x10, x9
10154b8cc:     	b.ne	0x10154ba20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b00>
10154b8d0:     	ldr	x9, [x23, x22]
10154b8d4:     	ldr	x10, [x8, #0x78]
10154b8d8:     	cmp	x9, x10
10154b8dc:     	b.hs	0x10154ba20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b00>
10154b8e0:     	ldr	x8, [x8, #0x70]
10154b8e4:     	mov	w10, #0x108             ; =264
10154b8e8:     	madd	x20, x9, x10, x8
10154b8ec:     	mov	x0, x20
10154b8f0:     	bl	0x1015295f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
10154b8f4:     	add	x1, sp, #0x550
10154b8f8:     	mov	x0, x20
10154b8fc:     	mov	w2, #0x108              ; =264
10154b900:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
10154b904:     	ldr	x8, [sp, #0x58]
10154b908:     	ldr	x8, [x8, #0x4d0]
10154b90c:     	cbz	x8, 0x10154c01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30fc>
10154b910:     	ldr	x9, [x23, x22]
10154b914:     	ldr	x10, [x21, #0xb0]
10154b918:     	add	x9, x10, x9, lsl #2
10154b91c:     	add	x9, x9, #0x2
10154b920:     	ldr	x10, [sp, #0x58]
10154b924:     	ldr	x10, [x10, #0x4d8]
10154b928:     	cmp	x9, x10
10154b92c:     	b.hs	0x10154c01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30fc>
10154b930:     	str	x19, [x8, x9, lsl #3]
10154b934:     	ldr	x8, [sp, #0x58]
10154b938:     	ldr	x8, [x8, #0x4d0]
10154b93c:     	cbz	x8, 0x10154c01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30fc>
10154b940:     	ldr	x9, [x23, x22]
10154b944:     	ldr	x10, [x21, #0x40]
10154b948:     	ldr	x11, [x21, #0xb0]
10154b94c:     	add	x9, x9, x10, lsl #2
10154b950:     	add	x9, x9, x11
10154b954:     	add	x9, x9, #0x2
10154b958:     	ldr	x10, [sp, #0x58]
10154b95c:     	ldr	x10, [x10, #0x4d8]
10154b960:     	cmp	x9, x10
10154b964:     	b.hs	0x10154c01c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30fc>
10154b968:     	mov	w10, #0x1               ; =1
10154b96c:     	str	x10, [x8, x9, lsl #3]
10154b970:     	mov	w19, #0x0               ; =0
10154b974:     	add	x0, sp, #0x550
10154b978:     	ldp	x3, x1, [sp, #0x50]
10154b97c:     	ldr	x2, [sp, #0x48]
10154b980:     	bl	0x10153c32c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation26resume_numeric_after_write>
10154b984:     	ldr	w8, [sp, #0x550]
10154b988:     	cmp	w8, #0x6
10154b98c:     	b.ne	0x10154c358 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3438>
10154b990:     	str	xzr, [x28, #0x8]
10154b994:     	str	w8, [x28]
10154b998:     	mov	w19, #0x0               ; =0
10154b99c:     	sub	x0, x29, #0x80
10154b9a0:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154b9a4:     	ldur	x8, [x29, #-0xa0]
10154b9a8:     	mov	x9, #-0x1               ; =-1
10154b9ac:     	ldaddl	x9, x8, [x8]
10154b9b0:     	cmp	x8, #0x1
10154b9b4:     	b.ne	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154b9b8:     	dmb	ishld
10154b9bc:     	sub	x0, x29, #0xa0
10154b9c0:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154b9c4:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154b9c8:     	ldur	w9, [x25, #0x1]
10154b9cc:     	stur	w9, [x19, #0x9]
10154b9d0:     	ldr	w9, [sp, #0x224]
10154b9d4:     	str	w9, [x19, #0xc]
10154b9d8:     	ldr	q0, [sp, #0x240]
10154b9dc:     	stur	q0, [x19, #0x28]
10154b9e0:     	ldr	x9, [sp, #0x250]
10154b9e4:     	str	x9, [x19, #0x38]
10154b9e8:     	ldr	d0, [sp, #0x238]
10154b9ec:     	ldur	q1, [x25, #0x8]
10154b9f0:     	mov	w9, #0x2                ; =2
10154b9f4:     	str	w9, [x19]
10154b9f8:     	strb	w8, [x19, #0x8]
10154b9fc:     	str	q1, [x19, #0x10]
10154ba00:     	str	d0, [x19, #0x20]
10154ba04:     	mov	w24, #0x0               ; =0
10154ba08:     	add	x0, sp, #0x440
10154ba0c:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154ba10:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154ba14:     	adrp	x0, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154ba18:     	add	x0, x0, #0x248
10154ba1c:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154ba20:     	str	wzr, [x28]
10154ba24:     	mov	w8, #0xc                ; =12
10154ba28:     	adrp	x9, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154ba2c:     	add	x9, x9, #0x987
10154ba30:     	stp	x8, x9, [x28, #0x8]
10154ba34:     	mov	w8, #0x2b               ; =43
10154ba38:     	str	x8, [x28, #0x18]
10154ba3c:     	mov	w19, #0x0               ; =0
10154ba40:     	add	x0, sp, #0x550
10154ba44:     	bl	0x1015295f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
10154ba48:     	mov	w19, #0x0               ; =0
10154ba4c:     	b	0x10154bdb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e90>
10154ba50:     	add	x8, sp, #0x550
10154ba54:     	add	x0, x24, #0x3b8
10154ba58:     	bl	0x1023696e8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
10154ba5c:     	ldr	x8, [sp, #0x58]
10154ba60:     	ldr	x8, [x8, #0x20]
10154ba64:     	cmp	x8, #0x1
10154ba68:     	b.ne	0x10154bdf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ed4>
10154ba6c:     	ldr	x8, [sp, #0x58]
10154ba70:     	ldr	w8, [x8, #0x40]
10154ba74:     	tbz	w8, #0x0, 0x10154bf18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ff8>
10154ba78:     	ldr	x8, [sp, #0x58]
10154ba7c:     	ldr	x1, [x8, #0x28]
10154ba80:     	ldr	x2, [x8, #0x48]
10154ba84:     	add	x8, sp, #0x668
10154ba88:     	add	x0, sp, #0x550
10154ba8c:     	bl	0x102d563c4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget11with_limits>
10154ba90:     	ldr	x8, [sp, #0x550]
10154ba94:     	mov	x9, #-0x1               ; =-1
10154ba98:     	ldaddl	x9, x8, [x8]
10154ba9c:     	cmp	x8, #0x1
10154baa0:     	b.ne	0x10154bab0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b90>
10154baa4:     	dmb	ishld
10154baa8:     	add	x0, sp, #0x550
10154baac:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154bab0:     	ldr	x8, [sp, #0x660]
10154bab4:     	ldr	x9, [x8, #0x6c0]
10154bab8:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10154babc:     	b.ls	0x10154bf7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x305c>
10154bac0:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154bac4:     	ldr	q0, [x8, #0x9c0]
10154bac8:     	stur	q0, [x23, #0x8]
10154bacc:     	mov	w8, #0x6                ; =6
10154bad0:     	str	w8, [x23]
10154bad4:     	b	0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154bad8:     	adrp	x0, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154badc:     	add	x0, x0, #0x200
10154bae0:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154bae4:     	add	x0, sp, #0x550
10154bae8:     	ldr	x1, [sp, #0x58]
10154baec:     	mov	x2, x20
10154baf0:     	bl	0x101546df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
10154baf4:     	ldr	w8, [sp, #0x550]
10154baf8:     	tbz	w8, #0x0, 0x10154be18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ef8>
10154bafc:     	ldr	w21, [sp, #0x554]
10154bb00:     	ldr	w22, [sp, #0x558]
10154bb04:     	add	x0, sp, #0x550
10154bb08:     	ldr	x1, [sp, #0x58]
10154bb0c:     	mov	x2, x20
10154bb10:     	mov	w3, #0x1                ; =1
10154bb14:     	mov	w4, #0x8                ; =8
10154bb18:     	mov	x5, #0x0                ; =0
10154bb1c:     	bl	0x101533228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
10154bb20:     	ldr	w8, [sp, #0x550]
10154bb24:     	cmp	w8, #0x6
10154bb28:     	b.ne	0x10154becc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fac>
10154bb2c:     	ldr	x8, [sp, #0x558]
10154bb30:     	cmp	x8, #0x2
10154bb34:     	b.ne	0x10154bb8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c6c>
10154bb38:     	add	x0, sp, #0x550
10154bb3c:     	ldr	x1, [sp, #0x58]
10154bb40:     	mov	x2, x21
10154bb44:     	mov	x3, x22
10154bb48:     	bl	0x101556f18 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation15move_joined_map>
10154bb4c:     	ldr	w9, [sp, #0x550]
10154bb50:     	ldrb	w8, [sp, #0x554]
10154bb54:     	cmp	w9, #0x6
10154bb58:     	b.ne	0x10154c0b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3190>
10154bb5c:     	tbnz	w8, #0x0, 0x10154bc04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ce4>
10154bb60:     	ldr	x8, [sp, #0x58]
10154bb64:     	ldr	x8, [x8, #0x490]
10154bb68:     	add	x0, sp, #0x550
10154bb6c:     	add	x1, x8, #0xf0
10154bb70:     	add	x4, x8, #0x2f8
10154bb74:     	mov	x2, x21
10154bb78:     	mov	x3, x22
10154bb7c:     	bl	0x10155073c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena15copy_current_to>
10154bb80:     	ldrb	w8, [sp, #0x550]
10154bb84:     	cmp	w8, #0x14
10154bb88:     	b.ne	0x10154c318 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33f8>
10154bb8c:     	ldr	x1, [x23, #0x380]
10154bb90:     	cmp	x20, x1
10154bb94:     	b.hs	0x10154cd0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3dec>
10154bb98:     	ldr	x8, [x23, #0x378]
10154bb9c:     	mov	w9, #0x170              ; =368
10154bba0:     	madd	x8, x20, x9, x8
10154bba4:     	ldp	x10, x9, [x8]
10154bba8:     	mov	w11, #0x11              ; =17
10154bbac:     	eor	x10, x10, x11
10154bbb0:     	orr	x9, x10, x9
10154bbb4:     	cbnz	x9, 0x10154bc04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ce4>
10154bbb8:     	ldr	x1, [x23, #0x390]
10154bbbc:     	ldr	w2, [x8, #0x10]
10154bbc0:     	cmp	x1, x2
10154bbc4:     	b.ls	0x10154cd48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e28>
10154bbc8:     	ldr	x8, [x23, #0x388]
10154bbcc:     	mov	w9, #0x180              ; =384
10154bbd0:     	umaddl	x8, w2, w9, x8
10154bbd4:     	ldp	x8, x9, [x8]
10154bbd8:     	mov	w10, #0x5               ; =5
10154bbdc:     	eor	x8, x8, x10
10154bbe0:     	orr	x8, x8, x9
10154bbe4:     	cbnz	x8, 0x10154bc04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ce4>
10154bbe8:     	add	x0, sp, #0x550
10154bbec:     	ldr	x1, [sp, #0x58]
10154bbf0:     	mov	w3, #0x1                ; =1
10154bbf4:     	bl	0x101547428 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
10154bbf8:     	ldr	w8, [sp, #0x550]
10154bbfc:     	cmp	w8, #0x6
10154bc00:     	b.ne	0x10154c2f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33d4>
10154bc04:     	ldr	x8, [sp, #0x58]
10154bc08:     	ldr	x8, [x8, #0x490]
10154bc0c:     	mov	w9, #0x1                ; =1
10154bc10:     	strb	w9, [x8, #0x460]
10154bc14:     	b	0x10154a2e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c0>
10154bc18:     	ldr	x1, [x23, #0x380]
10154bc1c:     	cmp	x20, x1
10154bc20:     	b.hs	0x10154cbf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cd8>
10154bc24:     	ldr	x8, [x23, #0x378]
10154bc28:     	mov	w9, #0x170              ; =368
10154bc2c:     	madd	x25, x20, x9, x8
10154bc30:     	ldp	x9, x8, [x25]
10154bc34:     	cmp	x9, #0x2
10154bc38:     	sbcs	xzr, x8, xzr
10154bc3c:     	b.hs	0x10154be34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f14>
10154bc40:     	ldr	x9, [x24]
10154bc44:     	ldr	x8, [sp, #0x58]
10154bc48:     	ldr	x21, [x8, #0x4d0]
10154bc4c:     	cmp	x9, x21
10154bc50:     	b.ne	0x10154bf00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fe0>
10154bc54:     	ldr	x22, [x24, #0x8]
10154bc58:     	ldr	x8, [x25, #0x128]
10154bc5c:     	cmp	x22, x8
10154bc60:     	b.ne	0x10154bf00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fe0>
10154bc64:     	ldr	x9, [x24, #0x10]
10154bc68:     	cbnz	x9, 0x10154bf00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fe0>
10154bc6c:     	ldr	x9, [sp, #0x58]
10154bc70:     	ldr	x9, [x9, #0x4d8]
10154bc74:     	cmp	x8, x9
10154bc78:     	b.hi	0x10154bf00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fe0>
10154bc7c:     	ldr	x23, [x25, #0x120]
10154bc80:     	add	x0, sp, #0x550
10154bc84:     	ldr	x1, [sp, #0x58]
10154bc88:     	mov	x2, x20
10154bc8c:     	mov	x3, x21
10154bc90:     	mov	x4, x22
10154bc94:     	bl	0x1015347e4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14selected_callsNtB4_10Invocation21prepared_library_call>
10154bc98:     	ldr	w8, [sp, #0x550]
10154bc9c:     	cmp	w8, #0x6
10154bca0:     	b.ne	0x10154becc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fac>
10154bca4:     	ldr	x8, [sp, #0x558]
10154bca8:     	cmp	x8, #0x2
10154bcac:     	b.ne	0x10154c004 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30e4>
10154bcb0:     	add	x0, sp, #0x550
10154bcb4:     	ldr	x1, [sp, #0x58]
10154bcb8:     	mov	x2, x20
10154bcbc:     	mov	x3, x21
10154bcc0:     	mov	x4, x22
10154bcc4:     	bl	0x101540104 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5lines10line_callsNtNtB6_10invocation10Invocation16line_matrix_call>
10154bcc8:     	ldr	w8, [sp, #0x550]
10154bccc:     	cmp	w8, #0x6
10154bcd0:     	b.ne	0x10154becc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fac>
10154bcd4:     	ldr	x8, [sp, #0x558]
10154bcd8:     	cmp	x8, #0x2
10154bcdc:     	b.ne	0x10154c004 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30e4>
10154bce0:     	add	x0, sp, #0x550
10154bce4:     	ldr	x1, [sp, #0x58]
10154bce8:     	mov	x2, x20
10154bcec:     	mov	x3, x21
10154bcf0:     	mov	x4, x22
10154bcf4:     	bl	0x1015444f8 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime7session7capture14captured_callsNtNtB8_10invocation10Invocation26captured_line_element_call>
10154bcf8:     	ldr	w9, [sp, #0x550]
10154bcfc:     	ldrb	w8, [sp, #0x554]
10154bd00:     	cmp	w9, #0x6
10154bd04:     	b.ne	0x10154c0b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3190>
10154bd08:     	tbnz	w8, #0x0, 0x10154bc04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ce4>
10154bd0c:     	add	x0, sp, #0x550
10154bd10:     	ldr	x1, [sp, #0x58]
10154bd14:     	mov	x2, x20
10154bd18:     	mov	x3, x21
10154bd1c:     	mov	x4, x22
10154bd20:     	bl	0x101554618 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation18selected_join_call>
10154bd24:     	ldr	w9, [sp, #0x550]
10154bd28:     	ldrb	w8, [sp, #0x554]
10154bd2c:     	cmp	w9, #0x6
10154bd30:     	b.ne	0x10154c0b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3190>
10154bd34:     	tbz	w8, #0x0, 0x10154c4cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35ac>
10154bd38:     	ldr	x8, [sp, #0x58]
10154bd3c:     	ldr	x9, [x8, #0x490]
10154bd40:     	mov	w10, #0x1               ; =1
10154bd44:     	strb	w10, [x9, #0x460]
10154bd48:     	ldr	x8, [x8, #0x290]
10154bd4c:     	cmp	x8, #0x4
10154bd50:     	cset	w8, eq
10154bd54:     	stp	x8, x10, [x19, #0x8]
10154bd58:     	b	0x10154a2e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c4>
10154bd5c:     	str	wzr, [x19]
10154bd60:     	mov	w8, #0xc                ; =12
10154bd64:     	strb	w8, [x19, #0x8]
10154bd68:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154bd6c:     	add	x8, x8, #0x737
10154bd70:     	mov	w9, #0x1b               ; =27
10154bd74:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154bd78:     	str	wzr, [x19]
10154bd7c:     	mov	w9, #0xc                ; =12
10154bd80:     	strb	w9, [x19, #0x8]
10154bd84:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154bd88:     	add	x8, x8, #0x556
10154bd8c:     	mov	w9, #0x29               ; =41
10154bd90:     	b	0x10154b660 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2740>
10154bd94:     	str	wzr, [x28]
10154bd98:     	adrp	x8, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154bd9c:     	add	x8, x8, #0x339
10154bda0:     	mov	w9, #0xc                ; =12
10154bda4:     	stp	x9, x8, [x28, #0x8]
10154bda8:     	mov	w8, #0x28               ; =40
10154bdac:     	str	x8, [x28, #0x18]
10154bdb0:     	sub	x0, x29, #0x80
10154bdb4:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154bdb8:     	ldur	x8, [x29, #-0xa0]
10154bdbc:     	mov	x9, #-0x1               ; =-1
10154bdc0:     	ldaddl	x9, x8, [x8]
10154bdc4:     	cmp	x8, #0x1
10154bdc8:     	b.ne	0x10154bdd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2eb8>
10154bdcc:     	dmb	ishld
10154bdd0:     	sub	x0, x29, #0xa0
10154bdd4:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154bdd8:     	tbz	w19, #0x0, 0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154bddc:     	add	x0, sp, #0x220
10154bde0:     	bl	0x10152c114 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
10154bde4:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154bde8:     	adrp	x0, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154bdec:     	add	x0, x0, #0x278
10154bdf0:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154bdf4:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154bdf8:     	add	x8, x8, #0x53
10154bdfc:     	b	0x10154bf20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3000>
10154be00:     	adrp	x0, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154be04:     	add	x0, x0, #0x218
10154be08:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154be0c:     	adrp	x0, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154be10:     	add	x0, x0, #0x230
10154be14:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154be18:     	str	wzr, [x19]
10154be1c:     	mov	w8, #0xc                ; =12
10154be20:     	str	w8, [x19, #0x8]
10154be24:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154be28:     	add	x8, x8, #0x1e
10154be2c:     	mov	w9, #0x21               ; =33
10154be30:     	b	0x101549e14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xef4>
10154be34:     	str	wzr, [x19]
10154be38:     	mov	w8, #0xc                ; =12
10154be3c:     	strb	w8, [x19, #0x8]
10154be40:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154be44:     	add	x8, x8, #0x78c
10154be48:     	b	0x10154ab58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c38>
10154be4c:     	add	x20, x20, #0x3c0
10154be50:     	mov	x0, x20
10154be54:     	bl	0x101529668 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
10154be58:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10154be5c:     	str	x8, [x20]
10154be60:     	mov	w8, #0x1                ; =1
10154be64:     	dup.2d	v0, x8
10154be68:     	b	0x1015496e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c4>
10154be6c:     	add	x0, sp, #0x550
10154be70:     	ldr	x1, [sp, #0x58]
10154be74:     	mov	x2, x20
10154be78:     	mov	w3, #0x12               ; =18
10154be7c:     	mov	w4, #0x8                ; =8
10154be80:     	mov	x5, #0x0                ; =0
10154be84:     	bl	0x101533228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
10154be88:     	ldr	w8, [sp, #0x550]
10154be8c:     	cmp	w8, #0x6
10154be90:     	b.ne	0x10154becc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fac>
10154be94:     	ldr	x8, [sp, #0x558]
10154be98:     	cmp	x8, #0x2
10154be9c:     	b.ne	0x10154c004 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30e4>
10154bea0:     	mov	x0, x19
10154bea4:     	ldr	x1, [sp, #0x58]
10154bea8:     	mov	x2, x20
10154beac:     	add	sp, sp, #0x800
10154beb0:     	ldp	x29, x30, [sp, #0x50]
10154beb4:     	ldp	x20, x19, [sp, #0x40]
10154beb8:     	ldp	x22, x21, [sp, #0x30]
10154bebc:     	ldp	x24, x23, [sp, #0x20]
10154bec0:     	ldp	x26, x25, [sp, #0x10]
10154bec4:     	ldp	x28, x27, [sp], #0x60
10154bec8:     	b	0x101537dc4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation>
10154becc:     	ldr	w9, [sp, #0x554]
10154bed0:     	ldur	q0, [x27, #0x18]
10154bed4:     	stur	q0, [x19, #0x18]
10154bed8:     	ldur	q0, [x27, #0x28]
10154bedc:     	stur	q0, [x19, #0x28]
10154bee0:     	ldur	q0, [x27, #0x38]
10154bee4:     	stur	q0, [x19, #0x38]
10154bee8:     	ldr	x10, [sp, #0x598]
10154beec:     	str	x10, [x19, #0x48]
10154bef0:     	ldur	q0, [x27, #0x8]
10154bef4:     	stp	w8, w9, [x19]
10154bef8:     	stur	q0, [x19, #0x8]
10154befc:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154bf00:     	str	wzr, [x19]
10154bf04:     	mov	w8, #0xc                ; =12
10154bf08:     	strb	w8, [x19, #0x8]
10154bf0c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154bf10:     	add	x8, x8, #0x768
10154bf14:     	b	0x10154ab58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c38>
10154bf18:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154bf1c:     	add	x8, x8, #0x71
10154bf20:     	str	wzr, [x23]
10154bf24:     	mov	w9, #0xc                ; =12
10154bf28:     	stp	x9, x8, [x23, #0x8]
10154bf2c:     	mov	w8, #0x1e               ; =30
10154bf30:     	str	x8, [x23, #0x18]
10154bf34:     	ldr	x8, [sp, #0x550]
10154bf38:     	mov	x9, #-0x1               ; =-1
10154bf3c:     	ldaddl	x9, x8, [x8]
10154bf40:     	cmp	x8, #0x1
10154bf44:     	b.ne	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154bf48:     	dmb	ishld
10154bf4c:     	add	x0, sp, #0x550
10154bf50:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154bf54:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154bf58:     	str	wzr, [x28]
10154bf5c:     	mov	w8, #0xc                ; =12
10154bf60:     	strb	w8, [x28, #0x8]
10154bf64:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154bf68:     	add	x8, x8, #0x556
10154bf6c:     	mov	w9, #0x29               ; =41
10154bf70:     	stp	x8, x9, [x28, #0x10]
10154bf74:     	mov	w19, #0x1               ; =1
10154bf78:     	b	0x10154bdb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e90>
10154bf7c:     	str	xzr, [sp, #0x38]
10154bf80:     	add	x24, sp, #0x720
10154bf84:     	ldp	x15, x9, [sp, #0x48]
10154bf88:     	lsl	x11, x9, #2
10154bf8c:     	add	x9, x15, x11
10154bf90:     	str	x9, [sp, #0x28]
10154bf94:     	ldr	x12, [x8, #0x5a0]
10154bf98:     	ldr	x13, [x8, #0x598]
10154bf9c:     	mov	w8, #0xc                ; =12
10154bfa0:     	mov	w9, #0x29               ; =41
10154bfa4:     	mov	w14, #0x58              ; =88
10154bfa8:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154bfac:     	add	x10, x10, #0x8f
10154bfb0:     	ldr	x16, [sp, #0x38]
10154bfb4:     	cbz	x11, 0x10154c040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3120>
10154bfb8:     	ldr	w17, [x15], #0x4
10154bfbc:     	cmp	x12, x17
10154bfc0:     	b.ls	0x10154bff4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30d4>
10154bfc4:     	umaddl	x17, w17, w14, x13
10154bfc8:     	ldr	x17, [x17, #0x8]
10154bfcc:     	sub	x11, x11, #0x4
10154bfd0:     	ldr	x0, [sp, #0x38]
10154bfd4:     	adds	x0, x17, x0
10154bfd8:     	str	x0, [sp, #0x38]
10154bfdc:     	b.lo	0x10154bfb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3090>
10154bfe0:     	and	x8, x16, #0xffffffffffffff00
10154bfe4:     	orr	x8, x8, #0xc
10154bfe8:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154bfec:     	add	x10, x10, #0xb8
10154bff0:     	mov	w9, #0x1f               ; =31
10154bff4:     	str	wzr, [x23]
10154bff8:     	stp	x8, x10, [x23, #0x8]
10154bffc:     	str	x9, [x23, #0x18]
10154c000:     	b	0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154c004:     	ldur	q0, [x27, #0x8]
10154c008:     	ldr	x8, [sp, #0x58]
10154c00c:     	ldr	x8, [x8, #0x490]
10154c010:     	mov	w9, #0x1                ; =1
10154c014:     	strb	w9, [x8, #0x460]
10154c018:     	b	0x1015496e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c4>
10154c01c:     	mov	w19, #0x0               ; =0
10154c020:     	str	wzr, [x28]
10154c024:     	mov	w8, #0xc                ; =12
10154c028:     	strb	w8, [x28, #0x8]
10154c02c:     	adrp	x8, 0x107554000 <_anon.99617498846789129750b3326436f5d5.369+0x298>
10154c030:     	add	x8, x8, #0x556
10154c034:     	mov	w9, #0x29               ; =41
10154c038:     	stp	x8, x9, [x28, #0x10]
10154c03c:     	b	0x10154bdb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e90>
10154c040:     	mov	w8, #0x48               ; =72
10154c044:     	mov	x9, #0x48               ; =72
10154c048:     	madd	x8, x20, x8, x9
10154c04c:     	ldr	x9, [sp, #0x38]
10154c050:     	umulh	x9, x9, x8
10154c054:     	cmp	xzr, x9
10154c058:     	b.ne	0x10154c870 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3950>
10154c05c:     	ldr	x9, [sp, #0x38]
10154c060:     	mul	x8, x9, x8
10154c064:     	mov	w9, #0x580              ; =1408
10154c068:     	mov	x10, #0x400             ; =1024
10154c06c:     	madd	x9, x20, x9, x10
10154c070:     	adds	x8, x8, x9
10154c074:     	str	x8, [sp, #0x30]
10154c078:     	b.hs	0x10154c884 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3964>
10154c07c:     	mov	x8, #-0x201             ; =-513
10154c080:     	movk	x8, #0x1fff, lsl #48
10154c084:     	ldr	x9, [sp, #0x30]
10154c088:     	cmp	x9, x8
10154c08c:     	b.ls	0x10154c114 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f4>
10154c090:     	str	wzr, [x23]
10154c094:     	mov	w8, #0xc                ; =12
10154c098:     	adrp	x9, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154c09c:     	add	x9, x9, #0xf1
10154c0a0:     	stp	x8, x9, [x23, #0x8]
10154c0a4:     	mov	w8, #0x17               ; =23
10154c0a8:     	str	x8, [x23, #0x18]
10154c0ac:     	b	0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154c0b0:     	ldur	q0, [x27, #0x15]
10154c0b4:     	stur	q0, [x19, #0x15]
10154c0b8:     	ldur	q0, [x27, #0x25]
10154c0bc:     	stur	q0, [x19, #0x25]
10154c0c0:     	ldur	q0, [x27, #0x35]
10154c0c4:     	stur	q0, [x19, #0x35]
10154c0c8:     	ldr	q0, [sp, #0x590]
10154c0cc:     	str	q0, [x19, #0x40]
10154c0d0:     	ldur	q0, [x27, #0x5]
10154c0d4:     	stur	q0, [x19, #0x5]
10154c0d8:     	str	w9, [x19]
10154c0dc:     	strb	w8, [x19, #0x4]
10154c0e0:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154c0e4:     	adrp	x3, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c0e8:     	add	x3, x3, #0x2f8
10154c0ec:     	mov	x0, #0x0                ; =0
10154c0f0:     	bl	0x103a07be0 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10154c0f4:     	b	0x10154d0a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
10154c0f8:     	str	wzr, [x28]
10154c0fc:     	mov	w8, #0xc                ; =12
10154c100:     	strb	w8, [x28, #0x8]
10154c104:     	adrp	x8, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154c108:     	add	x8, x8, #0x30d
10154c10c:     	mov	w9, #0x2c               ; =44
10154c110:     	b	0x10154c038 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3118>
10154c114:     	ldr	x8, [sp, #0x58]
10154c118:     	ldr	x9, [x8, #0x490]
10154c11c:     	ldr	x8, [sp, #0x30]
10154c120:     	lsl	x8, x8, #3
10154c124:     	add	x0, sp, #0x550
10154c128:     	str	x9, [sp, #0x20]
10154c12c:     	add	x1, x9, #0x2f8
10154c130:     	add	x4, x8, #0x1, lsl #12   ; =0x1000
10154c134:     	mov	w2, #0x0                ; =0
10154c138:     	bl	0x101530250 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
10154c13c:     	ldrb	w8, [sp, #0x550]
10154c140:     	cmp	w8, #0xe
10154c144:     	b.ne	0x10154c29c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x337c>
10154c148:     	add	x8, sp, #0x550
10154c14c:     	add	x0, sp, #0x668
10154c150:     	ldr	x1, [sp, #0x30]
10154c154:     	bl	0x102d56530 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
10154c158:     	ldr	w8, [sp, #0x550]
10154c15c:     	cmp	w8, #0x1a
10154c160:     	b.ne	0x10154c3c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34a0>
10154c164:     	ldur	q0, [x27, #0x8]
10154c168:     	ldur	q1, [x27, #0x18]
10154c16c:     	str	q0, [sp, #0x680]
10154c170:     	str	q1, [sp, #0x690]
10154c174:     	add	x8, sp, #0x550
10154c178:     	mov	x0, x20
10154c17c:     	ldr	x1, [sp, #0x50]
10154c180:     	ldr	x2, [sp, #0x38]
10154c184:     	bl	0x1014c6654 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel15scheduler_nodes>
10154c188:     	ldr	w8, [sp, #0x550]
10154c18c:     	cmp	w8, #0x6
10154c190:     	b.ne	0x10154c40c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34ec>
10154c194:     	ldr	x1, [sp, #0x558]
10154c198:     	add	x8, sp, #0x440
10154c19c:     	add	x0, sp, #0x668
10154c1a0:     	bl	0x102d56404 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
10154c1a4:     	ldr	w8, [sp, #0x440]
10154c1a8:     	cmp	w8, #0x1a
10154c1ac:     	b.ne	0x10154c454 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3534>
10154c1b0:     	add	x8, sp, #0x440
10154c1b4:     	ldur	q0, [x8, #0x8]
10154c1b8:     	ldur	q1, [x8, #0x18]
10154c1bc:     	str	q0, [sp, #0x6a0]
10154c1c0:     	str	q1, [sp, #0x6b0]
10154c1c4:     	ldr	x8, [sp, #0x50]
10154c1c8:     	cbnz	x8, 0x10154c52c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x360c>
10154c1cc:     	mov	w8, #0x8                ; =8
10154c1d0:     	str	xzr, [sp, #0x6c0]
10154c1d4:     	str	x8, [sp, #0x6c8]
10154c1d8:     	str	xzr, [sp, #0x6d0]
10154c1dc:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154c1e0:     	ldr	q0, [x8, #0x9c0]
10154c1e4:     	stur	q0, [x23, #0x8]
10154c1e8:     	mov	w8, #0x6                ; =6
10154c1ec:     	str	w8, [x23]
10154c1f0:     	add	x0, sp, #0x6c0
10154c1f4:     	bl	0x10152a36c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
10154c1f8:     	add	x0, sp, #0x6a0
10154c1fc:     	bl	0x10152b450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10154c200:     	b	0x10154c470 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3550>
10154c204:     	mov	w19, #0x0               ; =0
10154c208:     	ldur	q0, [x24, #0x8]
10154c20c:     	ldur	q1, [x24, #0x18]
10154c210:     	ldur	q2, [x24, #0x28]
10154c214:     	ldur	q3, [x24, #0x38]
10154c218:     	ldur	x8, [x24, #0x48]
10154c21c:     	stur	x8, [x27, #0x44]
10154c220:     	stur	q0, [x27, #0x4]
10154c224:     	stur	q1, [x27, #0x14]
10154c228:     	stur	q2, [x27, #0x24]
10154c22c:     	stur	q3, [x27, #0x34]
10154c230:     	ldr	q0, [sp, #0x570]
10154c234:     	ldr	q1, [sp, #0x580]
10154c238:     	str	q0, [sp, #0x410]
10154c23c:     	str	q1, [sp, #0x420]
10154c240:     	ldur	q0, [x27, #0x3c]
10154c244:     	stur	q0, [x26, #0xfc]
10154c248:     	ldr	q0, [sp, #0x560]
10154c24c:     	ldr	q1, [sp, #0x550]
10154c250:     	stp	q1, q0, [sp, #0x3f0]
10154c254:     	ldp	q0, q1, [sp, #0x3f0]
10154c258:     	ldur	q2, [x26, #0xfc]
10154c25c:     	stur	q2, [x26, #0xac]
10154c260:     	ldr	q2, [sp, #0x410]
10154c264:     	ldr	q3, [sp, #0x420]
10154c268:     	stp	q2, q3, [sp, #0x3c0]
10154c26c:     	stp	q0, q1, [sp, #0x3a0]
10154c270:     	ldp	q1, q0, [sp, #0x3a0]
10154c274:     	stur	q0, [x28, #0x14]
10154c278:     	ldp	q0, q2, [sp, #0x3c0]
10154c27c:     	stur	q0, [x28, #0x24]
10154c280:     	stur	q2, [x28, #0x34]
10154c284:     	ldur	q0, [x26, #0xac]
10154c288:     	str	q0, [x28, #0x40]
10154c28c:     	stur	q1, [x28, #0x4]
10154c290:     	mov	w8, #0x5                ; =5
10154c294:     	str	w8, [x28]
10154c298:     	b	0x10154bdb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e90>
10154c29c:     	ldr	q0, [sp, #0x550]
10154c2a0:     	ldr	q1, [sp, #0x560]
10154c2a4:     	str	q0, [sp, #0x440]
10154c2a8:     	str	q1, [sp, #0x450]
10154c2ac:     	ldr	q2, [sp, #0x570]
10154c2b0:     	str	q2, [sp, #0x460]
10154c2b4:     	ldr	x8, [sp, #0x580]
10154c2b8:     	str	x8, [sp, #0x470]
10154c2bc:     	stur	q0, [x27, #0x4]
10154c2c0:     	stur	q1, [x27, #0x14]
10154c2c4:     	stur	q2, [x27, #0x24]
10154c2c8:     	stur	x8, [x27, #0x34]
10154c2cc:     	str	wzr, [x23]
10154c2d0:     	ldr	q0, [sp, #0x550]
10154c2d4:     	ldr	q1, [sp, #0x560]
10154c2d8:     	stur	q0, [x23, #0x4]
10154c2dc:     	stur	q1, [x23, #0x14]
10154c2e0:     	ldr	q0, [sp, #0x570]
10154c2e4:     	stur	q0, [x23, #0x24]
10154c2e8:     	ldur	q0, [x27, #0x2c]
10154c2ec:     	str	q0, [x23, #0x30]
10154c2f0:     	b	0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154c2f4:     	ldr	q0, [sp, #0x570]
10154c2f8:     	ldr	q1, [sp, #0x580]
10154c2fc:     	stp	q0, q1, [x19, #0x20]
10154c300:     	ldr	q0, [sp, #0x590]
10154c304:     	str	q0, [x19, #0x40]
10154c308:     	ldr	q0, [sp, #0x560]
10154c30c:     	ldr	q1, [sp, #0x550]
10154c310:     	stp	q1, q0, [x19]
10154c314:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154c318:     	ldur	w9, [x27, #0x1]
10154c31c:     	stur	w9, [x19, #0x9]
10154c320:     	ldr	w9, [sp, #0x554]
10154c324:     	str	w9, [x19, #0xc]
10154c328:     	ldr	q0, [sp, #0x570]
10154c32c:     	stur	q0, [x19, #0x28]
10154c330:     	ldr	x9, [sp, #0x580]
10154c334:     	str	x9, [x19, #0x38]
10154c338:     	ldr	d0, [sp, #0x568]
10154c33c:     	ldur	q1, [x27, #0x8]
10154c340:     	mov	w9, #0x2                ; =2
10154c344:     	str	w9, [x19]
10154c348:     	strb	w8, [x19, #0x8]
10154c34c:     	str	q1, [x19, #0x10]
10154c350:     	str	d0, [x19, #0x20]
10154c354:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154c358:     	mov	w19, #0x0               ; =0
10154c35c:     	ldr	q0, [sp, #0x570]
10154c360:     	ldr	q1, [sp, #0x580]
10154c364:     	stp	q0, q1, [x28, #0x20]
10154c368:     	ldr	q0, [sp, #0x590]
10154c36c:     	str	q0, [x28, #0x40]
10154c370:     	ldr	q0, [sp, #0x560]
10154c374:     	ldr	q1, [sp, #0x550]
10154c378:     	stp	q1, q0, [x28]
10154c37c:     	b	0x10154bdb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2e90>
10154c380:     	str	wzr, [x28]
10154c384:     	mov	w8, #0xc                ; =12
10154c388:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154c38c:     	add	x9, x9, #0x2bd
10154c390:     	stp	x8, x9, [x28, #0x8]
10154c394:     	mov	w8, #0x2a               ; =42
10154c398:     	str	x8, [x28, #0x18]
10154c39c:     	b	0x10154b6b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2794>
10154c3a0:     	str	wzr, [x28]
10154c3a4:     	mov	w8, #0xc                ; =12
10154c3a8:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154c3ac:     	add	x9, x9, #0x2e7
10154c3b0:     	stp	x8, x9, [x28, #0x8]
10154c3b4:     	mov	w8, #0x26               ; =38
10154c3b8:     	str	x8, [x28, #0x18]
10154c3bc:     	b	0x10154b6b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2794>
10154c3c0:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154c3c4:     	ldr	q0, [x8, #0x9c0]
10154c3c8:     	stur	q0, [x23, #0x8]
10154c3cc:     	mov	w8, #0x6                ; =6
10154c3d0:     	str	w8, [x23]
10154c3d4:     	add	x0, sp, #0x550
10154c3d8:     	bl	0x101529bf4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
10154c3dc:     	b	0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154c3e0:     	str	wzr, [x19]
10154c3e4:     	mov	w9, #0xc                ; =12
10154c3e8:     	str	x9, [x19, #0x8]
10154c3ec:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154c3f0:     	add	x8, x8, #0xb3e
10154c3f4:     	mov	w9, #0x1e               ; =30
10154c3f8:     	b	0x10154b660 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2740>
10154c3fc:     	adrp	x2, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
10154c400:     	add	x2, x2, #0x260
10154c404:     	mov	x0, x19
10154c408:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c40c:     	ldr	w9, [sp, #0x554]
10154c410:     	ldr	x10, [sp, #0x558]
10154c414:     	ldr	q0, [sp, #0x560]
10154c418:     	ldr	q1, [sp, #0x570]
10154c41c:     	stp	q0, q1, [x23, #0x10]
10154c420:     	ldr	q0, [sp, #0x580]
10154c424:     	ldr	q1, [sp, #0x590]
10154c428:     	stp	q0, q1, [x23, #0x30]
10154c42c:     	stp	w8, w9, [x23]
10154c430:     	str	x10, [x23, #0x8]
10154c434:     	b	0x10154c470 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3550>
10154c438:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c43c:     	add	x2, x2, #0x2e0
10154c440:     	mov	x0, x8
10154c444:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c448:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c44c:     	add	x2, x2, #0xed0
10154c450:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c454:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154c458:     	ldr	q0, [x8, #0x9c0]
10154c45c:     	stur	q0, [x23, #0x8]
10154c460:     	mov	w8, #0x6                ; =6
10154c464:     	str	w8, [x23]
10154c468:     	add	x0, sp, #0x440
10154c46c:     	bl	0x101529b1c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
10154c470:     	add	x0, sp, #0x680
10154c474:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154c478:     	ldr	x8, [sp, #0x668]
10154c47c:     	mov	x9, #-0x1               ; =-1
10154c480:     	ldaddl	x9, x8, [x8]
10154c484:     	cmp	x8, #0x1
10154c488:     	b.ne	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154c48c:     	dmb	ishld
10154c490:     	add	x0, sp, #0x668
10154c494:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154c498:     	b	0x1015491f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154c49c:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c4a0:     	add	x2, x2, #0xf78
10154c4a4:     	mov	x0, x19
10154c4a8:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c4ac:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c4b0:     	add	x2, x2, #0x100
10154c4b4:     	ldr	x0, [sp, #0x50]
10154c4b8:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c4bc:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c4c0:     	add	x2, x2, #0x118
10154c4c4:     	ldr	x0, [sp, #0x50]
10154c4c8:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c4cc:     	ldr	w5, [x25, #0x130]
10154c4d0:     	mov	x0, x19
10154c4d4:     	ldr	x1, [sp, #0x58]
10154c4d8:     	mov	x2, x20
10154c4dc:     	mov	x3, x23
10154c4e0:     	mov	x4, x22
10154c4e4:     	mov	x6, x21
10154c4e8:     	mov	x7, x22
10154c4ec:     	add	sp, sp, #0x800
10154c4f0:     	ldp	x29, x30, [sp, #0x50]
10154c4f4:     	ldp	x20, x19, [sp, #0x40]
10154c4f8:     	ldp	x22, x21, [sp, #0x30]
10154c4fc:     	ldp	x24, x23, [sp, #0x20]
10154c500:     	ldp	x26, x25, [sp, #0x10]
10154c504:     	ldp	x28, x27, [sp], #0x60
10154c508:     	b	0x1015374e8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call>
10154c50c:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c510:     	add	x2, x2, #0xf90
10154c514:     	mov	x0, x1
10154c518:     	mov	x1, x8
10154c51c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c520:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c524:     	add	x2, x2, #0xf48
10154c528:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c52c:     	add	x0, sp, #0x550
10154c530:     	mov	x1, #0x0                ; =0
10154c534:     	mov	w2, #0x8                ; =8
10154c538:     	ldr	x3, [sp, #0x50]
10154c53c:     	mov	w4, #0x8                ; =8
10154c540:     	mov	w5, #0x68               ; =104
10154c544:     	bl	0x1039e2a9c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
10154c548:     	ldr	w8, [sp, #0x550]
10154c54c:     	tbz	w8, #0x0, 0x10154c580 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3660>
10154c550:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154c554:     	add	x8, x8, #0x967
10154c558:     	mov	w9, #0xc                ; =12
10154c55c:     	stp	x9, x8, [x23, #0x8]
10154c560:     	mov	w8, #0x1a               ; =26
10154c564:     	str	x8, [x23, #0x18]
10154c568:     	str	wzr, [x23]
10154c56c:     	b	0x10154c1f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d8>
10154c570:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154c574:     	add	x2, x2, #0x130
10154c578:     	ldr	x1, [sp, #0x28]
10154c57c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154c580:     	str	xzr, [sp]
10154c584:     	str	xzr, [sp, #0x18]
10154c588:     	ldr	x8, [sp, #0x558]
10154c58c:     	ldr	x9, [sp, #0x50]
10154c590:     	str	x9, [sp, #0x6c0]
10154c594:     	str	x8, [sp, #0x6c8]
10154c598:     	str	xzr, [sp, #0x6d0]
10154c59c:     	ldr	x8, [sp, #0x48]
10154c5a0:     	ldr	w9, [x8], #0x4
10154c5a4:     	str	x8, [sp, #0x48]
10154c5a8:     	ldr	x8, [sp, #0x660]
10154c5ac:     	ldr	x1, [x8, #0x5a0]
10154c5b0:     	str	x9, [sp, #0x38]
10154c5b4:     	cmp	x1, x9
10154c5b8:     	b.ls	0x10154d074 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4154>
10154c5bc:     	ldr	x8, [x8, #0x598]
10154c5c0:     	mov	w9, #0x58               ; =88
10154c5c4:     	ldr	x10, [sp, #0x38]
10154c5c8:     	umaddl	x8, w10, w9, x8
10154c5cc:     	str	x8, [sp, #0x30]
10154c5d0:     	ldr	w1, [x8, #0x50]
10154c5d4:     	add	x8, sp, #0x550
10154c5d8:     	ldr	x9, [sp, #0x20]
10154c5dc:     	add	x0, x9, #0xf0
10154c5e0:     	add	x2, x9, #0x2f8
10154c5e4:     	bl	0x10154fa14 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10154c5e8:     	ldr	x8, [sp, #0x550]
10154c5ec:     	add	x9, sp, #0x550
10154c5f0:     	ldur	q0, [x9, #0x8]
10154c5f4:     	ldur	q1, [x9, #0x18]
10154c5f8:     	stp	q0, q1, [sp, #0x3f0]
10154c5fc:     	ldur	q0, [x9, #0x28]
10154c600:     	str	q0, [sp, #0x410]
10154c604:     	ldur	x9, [x9, #0x38]
10154c608:     	str	x9, [sp, #0x420]
10154c60c:     	cbz	x8, 0x10154c8a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3984>
10154c610:     	ldr	x9, [sp, #0x420]
10154c614:     	add	x10, sp, #0x220
10154c618:     	stur	x9, [x10, #0x38]
10154c61c:     	ldr	q0, [sp, #0x410]
10154c620:     	stur	q0, [x10, #0x28]
10154c624:     	ldp	q1, q0, [sp, #0x3f0]
10154c628:     	stur	q0, [x10, #0x18]
10154c62c:     	stur	q1, [x10, #0x8]
10154c630:     	str	x8, [sp, #0x220]
10154c634:     	ldr	x8, [sp, #0x228]
10154c638:     	ldr	x8, [x8, #0x10]
10154c63c:     	ldrb	w8, [x8, #0x10]
10154c640:     	orr	w8, w8, #0x2
10154c644:     	cmp	w8, #0x1b
10154c648:     	b.ne	0x10154cb40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c20>
10154c64c:     	add	x8, sp, #0x550
10154c650:     	add	x0, sp, #0x220
10154c654:     	bl	0x101586cd8 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections12source_count>
10154c658:     	ldr	w8, [sp, #0x550]
10154c65c:     	cmp	w8, #0x6
10154c660:     	b.ne	0x10154c8ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39cc>
10154c664:     	ldr	x8, [sp, #0x558]
10154c668:     	str	x8, [sp, #0x50]
10154c66c:     	ldr	x8, [sp, #0x38]
10154c670:     	cmp	x19, x8
10154c674:     	b.ne	0x10154c684 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3764>
10154c678:     	ldr	x8, [sp, #0x50]
10154c67c:     	cmp	x8, x28
10154c680:     	b.ne	0x10154c918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39f8>
10154c684:     	ldr	x8, [sp, #0x18]
10154c688:     	ldr	x9, [sp, #0x50]
10154c68c:     	adds	x8, x9, x8
10154c690:     	str	x8, [sp, #0x18]
10154c694:     	b.hs	0x10154cca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d88>
10154c698:     	ldr	x8, [sp, #0x50]
10154c69c:     	cbz	x8, 0x10154c934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a14>
10154c6a0:     	ldr	x8, [sp, #0x18]
10154c6a4:     	cmp	x8, x20
10154c6a8:     	b.hi	0x10154c934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a14>
10154c6ac:     	ldr	x8, [sp, #0x30]
10154c6b0:     	ldr	x8, [x8, #0x8]
10154c6b4:     	str	x8, [sp, #0x8]
10154c6b8:     	cbnz	x8, 0x10154c72c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x380c>
10154c6bc:     	str	xzr, [sp]
10154c6c0:     	ldr	x9, [sp, #0x8]
10154c6c4:     	mov	w8, #0x8                ; =8
10154c6c8:     	stp	x9, x8, [sp, #0x110]
10154c6cc:     	str	xzr, [sp, #0x120]
10154c6d0:     	ldp	q0, q1, [sp, #0x220]
10154c6d4:     	add	x8, sp, #0x550
10154c6d8:     	stur	q0, [x8, #0x18]
10154c6dc:     	stur	q1, [x8, #0x28]
10154c6e0:     	ldp	q0, q1, [sp, #0x240]
10154c6e4:     	stur	q0, [x8, #0x38]
10154c6e8:     	stur	q1, [x8, #0x48]
10154c6ec:     	ldr	q0, [sp, #0x110]
10154c6f0:     	str	q0, [sp, #0x550]
10154c6f4:     	ldr	x8, [sp, #0x120]
10154c6f8:     	str	x8, [sp, #0x560]
10154c6fc:     	ldr	x8, [sp, #0x38]
10154c700:     	str	x8, [sp, #0x5a8]
10154c704:     	ldr	x8, [sp, #0x50]
10154c708:     	str	x8, [sp, #0x5b0]
10154c70c:     	add	x0, sp, #0x6c0
10154c710:     	add	x1, sp, #0x550
10154c714:     	bl	0x101552e7c <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionE8push_mutBR_>
10154c718:     	ldr	x8, [sp, #0x48]
10154c71c:     	ldr	x9, [sp, #0x28]
10154c720:     	cmp	x8, x9
10154c724:     	b.ne	0x10154c59c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x367c>
10154c728:     	b	0x10154c94c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a2c>
10154c72c:     	ldr	x8, [sp, #0x30]
10154c730:     	ldr	x8, [x8]
10154c734:     	str	x8, [sp, #0x10]
10154c738:     	add	x0, sp, #0x550
10154c73c:     	mov	x1, #0x0                ; =0
10154c740:     	mov	w2, #0x8                ; =8
10154c744:     	ldr	x3, [sp, #0x8]
10154c748:     	mov	w4, #0x8                ; =8
10154c74c:     	mov	w5, #0x48               ; =72
10154c750:     	bl	0x1039e2a9c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
10154c754:     	ldr	x8, [sp, #0x550]
10154c758:     	cmp	x8, #0x1
10154c75c:     	b.eq	0x10154cc08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ce8>
10154c760:     	ldr	x8, [sp, #0x558]
10154c764:     	ldr	x10, [sp, #0x8]
10154c768:     	and	x9, x10, #0x7fffffffffffff00
10154c76c:     	stp	x10, x8, [sp, #0x110]
10154c770:     	str	xzr, [sp, #0x120]
10154c774:     	lsl	x8, x10, #2
10154c778:     	stp	x9, x8, [sp]
10154c77c:     	b	0x10154c7b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3894>
10154c780:     	ldr	x8, [x21, #0x28]
10154c784:     	ldr	x9, [sp, #0x30]
10154c788:     	ldr	x8, [x8, x9, lsl #3]
10154c78c:     	str	x8, [sp, #0x558]
10154c790:     	str	w9, [sp, #0x554]
10154c794:     	str	wzr, [sp, #0x550]
10154c798:     	add	x0, sp, #0x110
10154c79c:     	add	x1, sp, #0x550
10154c7a0:     	bl	0x101552f10 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
10154c7a4:     	ldr	x8, [sp, #0x8]
10154c7a8:     	subs	x8, x8, #0x4
10154c7ac:     	str	x8, [sp, #0x8]
10154c7b0:     	b.eq	0x10154c6d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37b0>
10154c7b4:     	ldr	x8, [sp, #0x10]
10154c7b8:     	ldr	w9, [x8], #0x4
10154c7bc:     	str	x8, [sp, #0x10]
10154c7c0:     	ldr	x8, [sp, #0x660]
10154c7c4:     	ldr	x1, [x8, #0x360]
10154c7c8:     	str	x9, [sp, #0x30]
10154c7cc:     	cmp	x1, x9
10154c7d0:     	b.ls	0x10154d088 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4168>
10154c7d4:     	ldr	x8, [x8, #0x358]
10154c7d8:     	mov	w9, #0x140              ; =320
10154c7dc:     	ldr	x10, [sp, #0x30]
10154c7e0:     	umaddl	x8, w10, w9, x8
10154c7e4:     	ldrb	w8, [x8, #0x124]
10154c7e8:     	cmp	w8, #0x7
10154c7ec:     	b.ne	0x10154c780 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3860>
10154c7f0:     	add	x8, sp, #0x440
10154c7f4:     	ldr	x9, [sp, #0x20]
10154c7f8:     	add	x0, x9, #0xf0
10154c7fc:     	add	x2, x9, #0x2f8
10154c800:     	ldr	x1, [sp, #0x30]
10154c804:     	bl	0x10154fa14 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10154c808:     	ldr	x8, [sp, #0x440]
10154c80c:     	add	x9, sp, #0x440
10154c810:     	ldur	q0, [x9, #0x8]
10154c814:     	ldur	q1, [x9, #0x18]
10154c818:     	stp	q0, q1, [sp, #0xa0]
10154c81c:     	ldur	q0, [x9, #0x28]
10154c820:     	str	q0, [sp, #0xc0]
10154c824:     	ldur	x9, [x9, #0x38]
10154c828:     	str	x9, [sp, #0xd0]
10154c82c:     	cbz	x8, 0x10154caec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3bcc>
10154c830:     	ldp	q0, q1, [sp, #0xa0]
10154c834:     	add	x10, sp, #0x550
10154c838:     	stp	q0, q1, [x10, #0x10]
10154c83c:     	ldr	q0, [sp, #0xc0]
10154c840:     	stur	q0, [x10, #0x30]
10154c844:     	ldr	x9, [sp, #0xd0]
10154c848:     	stur	x9, [x10, #0x40]
10154c84c:     	str	x8, [sp, #0x558]
10154c850:     	ldr	x8, [sp, #0x30]
10154c854:     	str	w8, [sp, #0x554]
10154c858:     	mov	w8, #0x1                ; =1
10154c85c:     	str	w8, [sp, #0x550]
10154c860:     	add	x0, sp, #0x110
10154c864:     	add	x1, sp, #0x550
10154c868:     	bl	0x101552f10 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
10154c86c:     	b	0x10154c7a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3884>
10154c870:     	str	wzr, [x23]
10154c874:     	mov	w8, #0xc                ; =12
10154c878:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
10154c87c:     	add	x9, x9, #0x10
10154c880:     	b	0x10154c894 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3974>
10154c884:     	str	wzr, [x23]
10154c888:     	mov	w8, #0xc                ; =12
10154c88c:     	adrp	x9, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154c890:     	add	x9, x9, #0xd7
10154c894:     	stp	x8, x9, [x23, #0x8]
10154c898:     	mov	w8, #0x1a               ; =26
10154c89c:     	str	x8, [x23, #0x18]
10154c8a0:     	b	0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154c8a4:     	ldp	q0, q1, [sp, #0x3f0]
10154c8a8:     	stur	q0, [x27, #0x4]
10154c8ac:     	stur	q1, [x27, #0x14]
10154c8b0:     	ldr	q0, [sp, #0x410]
10154c8b4:     	stur	q0, [x27, #0x24]
10154c8b8:     	ldr	x8, [sp, #0x420]
10154c8bc:     	stur	x8, [x27, #0x34]
10154c8c0:     	ldr	q0, [sp, #0x550]
10154c8c4:     	ldr	q1, [sp, #0x560]
10154c8c8:     	stur	q0, [x23, #0x4]
10154c8cc:     	mov	w8, #0x2                ; =2
10154c8d0:     	str	w8, [x23]
10154c8d4:     	stur	q1, [x23, #0x14]
10154c8d8:     	ldr	q0, [sp, #0x570]
10154c8dc:     	stur	q0, [x23, #0x24]
10154c8e0:     	ldur	q0, [x27, #0x2c]
10154c8e4:     	str	q0, [x23, #0x30]
10154c8e8:     	b	0x10154c1f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d0>
10154c8ec:     	ldr	w9, [sp, #0x554]
10154c8f0:     	ldr	x10, [sp, #0x558]
10154c8f4:     	ldr	q0, [sp, #0x560]
10154c8f8:     	ldr	q1, [sp, #0x570]
10154c8fc:     	stp	q0, q1, [x23, #0x10]
10154c900:     	ldr	q0, [sp, #0x580]
10154c904:     	ldr	q1, [sp, #0x590]
10154c908:     	stp	q0, q1, [x23, #0x30]
10154c90c:     	stp	w8, w9, [x23]
10154c910:     	str	x10, [x23, #0x8]
10154c914:     	b	0x10154cb5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c3c>
10154c918:     	str	wzr, [x23]
10154c91c:     	mov	w8, #0xc                ; =12
10154c920:     	strb	w8, [x23, #0x8]
10154c924:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154c928:     	add	x8, x8, #0x99c
10154c92c:     	mov	w9, #0x24               ; =36
10154c930:     	b	0x10154cb58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c38>
10154c934:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154c938:     	ldr	q0, [x8, #0x9c0]
10154c93c:     	stur	q0, [x23, #0x8]
10154c940:     	mov	w8, #0x6                ; =6
10154c944:     	str	w8, [x23]
10154c948:     	b	0x10154cb5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c3c>
10154c94c:     	ldr	x8, [sp, #0x18]
10154c950:     	cmp	x8, #0x2
10154c954:     	b.lo	0x10154c1dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32bc>
10154c958:     	ldr	x8, [sp, #0x18]
10154c95c:     	str	x8, [sp, #0x6d8]
10154c960:     	add	x8, x8, x8, lsl #5
10154c964:     	lsl	x1, x8, #16
10154c968:     	add	x8, sp, #0x550
10154c96c:     	add	x0, sp, #0x668
10154c970:     	bl	0x102d56530 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
10154c974:     	ldr	w8, [sp, #0x550]
10154c978:     	cmp	w8, #0x1a
10154c97c:     	b.ne	0x10154cb94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c74>
10154c980:     	ldur	q0, [x27, #0x8]
10154c984:     	ldur	q1, [x27, #0x18]
10154c988:     	str	q0, [sp, #0x6e0]
10154c98c:     	str	q1, [sp, #0x6f0]
10154c990:     	ldr	x20, [sp, #0x6d0]
10154c994:     	cbnz	x20, 0x10154ccc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3da8>
10154c998:     	mov	x8, #0x0                ; =0
10154c99c:     	mov	w9, #0x8                ; =8
10154c9a0:     	str	x20, [sp, #0x708]
10154c9a4:     	str	x9, [sp, #0x710]
10154c9a8:     	str	xzr, [sp, #0x718]
10154c9ac:     	ldr	x1, [sp, #0x6c8]
10154c9b0:     	mov	w9, #0x68               ; =104
10154c9b4:     	madd	x2, x8, x9, x1
10154c9b8:     	mov	w19, #0x1               ; =1
10154c9bc:     	add	x0, sp, #0x708
10154c9c0:     	mov	w28, #0x1               ; =1
10154c9c4:     	bl	0x101498a18 <__RINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENCNvMs0_B2f_NtB2h_10Invocation12run_parallels9_0EEB2p_>
10154c9c8:     	ldr	x2, [sp, #0x710]
10154c9cc:     	ldr	x3, [sp, #0x718]
10154c9d0:     	add	x0, sp, #0x550
10154c9d4:     	ldr	x1, [sp, #0x58]
10154c9d8:     	bl	0x101541db0 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel9admissionNtB6_10Invocation18parallel_admission>
10154c9dc:     	ldr	w8, [sp, #0x550]
10154c9e0:     	cmp	w8, #0x6
10154c9e4:     	b.ne	0x10154cbb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c94>
10154c9e8:     	ldr	x8, [sp, #0x558]
10154c9ec:     	ldr	q0, [sp, #0x560]
10154c9f0:     	str	q0, [sp, #0x740]
10154c9f4:     	ldr	x9, [sp, #0x570]
10154c9f8:     	str	x9, [sp, #0x750]
10154c9fc:     	cbz	x8, 0x10154cc2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d0c>
10154ca00:     	ldr	q0, [sp, #0x740]
10154ca04:     	stur	q0, [x24, #0x8]
10154ca08:     	ldr	x9, [sp, #0x750]
10154ca0c:     	str	x8, [sp, #0x720]
10154ca10:     	str	x9, [sp, #0x738]
10154ca14:     	ldr	x0, [sp, #0x660]
10154ca18:     	add	x8, sp, #0x550
10154ca1c:     	add	x1, sp, #0x668
10154ca20:     	ldr	x2, [sp, #0x18]
10154ca24:     	bl	0x1014c6734 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel17worker_setup_fits>
10154ca28:     	ldr	w9, [sp, #0x550]
10154ca2c:     	ldrb	w8, [sp, #0x554]
10154ca30:     	cmp	w9, #0x6
10154ca34:     	b.ne	0x10154cc5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d3c>
10154ca38:     	tbz	w8, #0x0, 0x10154cc90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d70>
10154ca3c:     	ldr	x8, [sp, #0x660]
10154ca40:     	ldr	x1, [x8, #0x3a0]
10154ca44:     	ldr	w0, [x22, #0x30]
10154ca48:     	cmp	x1, x0
10154ca4c:     	b.ls	0x10154d09c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x417c>
10154ca50:     	ldr	x8, [x8, #0x398]
10154ca54:     	mov	w9, #0x540              ; =1344
10154ca58:     	umaddl	x8, w0, w9, x8
10154ca5c:     	ldr	w9, [x8, #0x520]
10154ca60:     	ldr	q0, [x8, #0x510]
10154ca64:     	stur	q0, [x29, #-0xf0]
10154ca68:     	stur	w9, [x29, #-0xe0]
10154ca6c:     	add	x8, sp, #0x550
10154ca70:     	ldr	x9, [sp, #0x20]
10154ca74:     	add	x0, x9, #0x3b8
10154ca78:     	bl	0x10236980c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
10154ca7c:     	ldr	x8, [sp, #0x550]
10154ca80:     	cmp	x8, #0x1
10154ca84:     	b.ne	0x10154cd1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3dfc>
10154ca88:     	ldr	x1, [sp, #0x558]
10154ca8c:     	ldr	x2, [sp, #0x560]
10154ca90:     	add	x19, sp, #0x550
10154ca94:     	add	x8, sp, #0x550
10154ca98:     	ldr	x9, [sp, #0x20]
10154ca9c:     	add	x0, x9, #0x3b8
10154caa0:     	add	x3, sp, #0x668
10154caa4:     	bl	0x10236b498 <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget32reserve_worker_group_with_memory>
10154caa8:     	ldrb	w8, [sp, #0x588]
10154caac:     	cmp	w8, #0x2
10154cab0:     	b.ne	0x10154cd5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e3c>
10154cab4:     	ldr	w8, [sp, #0x550]
10154cab8:     	cmp	w8, #0x1a
10154cabc:     	b.ne	0x10154cf08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3fe8>
10154cac0:     	ldur	w9, [x29, #-0xf0]
10154cac4:     	ldurb	w8, [x29, #-0xec]
10154cac8:     	add	x12, sp, #0x720
10154cacc:     	ldur	w10, [x12, #0x45]
10154cad0:     	str	w10, [sp, #0x110]
10154cad4:     	ldur	w11, [x29, #-0xe8]
10154cad8:     	add	x10, sp, #0x110
10154cadc:     	stur	w11, [x10, #0x3]
10154cae0:     	mov	w10, #0x4               ; =4
10154cae4:     	ldur	d0, [x12, #0x4c]
10154cae8:     	b	0x10154cf14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ff4>
10154caec:     	ldp	q0, q1, [sp, #0xa0]
10154caf0:     	add	x8, sp, #0x440
10154caf4:     	stur	q0, [x8, #0x4]
10154caf8:     	stur	q1, [x8, #0x14]
10154cafc:     	ldr	q0, [sp, #0xc0]
10154cb00:     	stur	q0, [x8, #0x24]
10154cb04:     	ldr	x9, [sp, #0xd0]
10154cb08:     	stur	x9, [x8, #0x34]
10154cb0c:     	ldr	q0, [sp, #0x440]
10154cb10:     	ldr	q1, [sp, #0x450]
10154cb14:     	stur	q0, [x23, #0x4]
10154cb18:     	mov	w9, #0x2                ; =2
10154cb1c:     	str	w9, [x23]
10154cb20:     	stur	q1, [x23, #0x14]
10154cb24:     	ldr	q0, [sp, #0x460]
10154cb28:     	stur	q0, [x23, #0x24]
10154cb2c:     	ldur	q0, [x8, #0x2c]
10154cb30:     	str	q0, [x23, #0x30]
10154cb34:     	add	x0, sp, #0x110
10154cb38:     	bl	0x10152a450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10154cb3c:     	b	0x10154cb5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c3c>
10154cb40:     	str	wzr, [x23]
10154cb44:     	mov	w8, #0xc                ; =12
10154cb48:     	strb	w8, [x23, #0x8]
10154cb4c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154cb50:     	add	x8, x8, #0x9c0
10154cb54:     	mov	w9, #0x30               ; =48
10154cb58:     	stp	x8, x9, [x23, #0x10]
10154cb5c:     	add	x0, sp, #0x220
10154cb60:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154cb64:     	b	0x10154c1f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d0>
10154cb68:     	mov	w24, #0x1               ; =1
10154cb6c:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154cb70:     	add	x2, x2, #0xf60
10154cb74:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154cb78:     	b	0x10154d0a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
10154cb7c:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154cb80:     	add	x2, x2, #0x148
10154cb84:     	mov	x0, x1
10154cb88:     	ldr	x1, [sp, #0x28]
10154cb8c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154cb90:     	b	0x10154d0a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
10154cb94:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154cb98:     	ldr	q0, [x8, #0x9c0]
10154cb9c:     	stur	q0, [x23, #0x8]
10154cba0:     	mov	w8, #0x6                ; =6
10154cba4:     	str	w8, [x23]
10154cba8:     	add	x0, sp, #0x550
10154cbac:     	bl	0x101529bf4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
10154cbb0:     	b	0x10154c1f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d0>
10154cbb4:     	ldr	w9, [sp, #0x554]
10154cbb8:     	ldr	x10, [sp, #0x558]
10154cbbc:     	ldr	q0, [sp, #0x560]
10154cbc0:     	str	q0, [sp, #0x740]
10154cbc4:     	ldur	q1, [x27, #0x28]
10154cbc8:     	stur	q1, [x23, #0x28]
10154cbcc:     	ldur	q1, [x27, #0x38]
10154cbd0:     	ldr	x11, [sp, #0x570]
10154cbd4:     	ldr	x12, [sp, #0x598]
10154cbd8:     	str	x11, [sp, #0x750]
10154cbdc:     	stur	q1, [x23, #0x38]
10154cbe0:     	str	x12, [x23, #0x48]
10154cbe4:     	str	q0, [x23, #0x10]
10154cbe8:     	str	x11, [x23, #0x20]
10154cbec:     	stp	w8, w9, [x23]
10154cbf0:     	str	x10, [x23, #0x8]
10154cbf4:     	b	0x10154cc40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d20>
10154cbf8:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154cbfc:     	add	x2, x2, #0xea0
10154cc00:     	mov	x0, x20
10154cc04:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154cc08:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154cc0c:     	add	x8, x8, #0x981
10154cc10:     	ldr	x9, [sp]
10154cc14:     	orr	x9, x9, #0xc
10154cc18:     	stp	x9, x8, [x23, #0x8]
10154cc1c:     	mov	w8, #0x1b               ; =27
10154cc20:     	str	x8, [x23, #0x18]
10154cc24:     	str	wzr, [x23]
10154cc28:     	b	0x10154cb5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c3c>
10154cc2c:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154cc30:     	ldr	q0, [x8, #0x9c0]
10154cc34:     	stur	q0, [x23, #0x8]
10154cc38:     	mov	w8, #0x6                ; =6
10154cc3c:     	str	w8, [x23]
10154cc40:     	ldr	x8, [sp, #0x708]
10154cc44:     	cbz	x8, 0x10154cfb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4094>
10154cc48:     	ldr	x0, [sp, #0x710]
10154cc4c:     	lsl	x1, x8, #3
10154cc50:     	mov	w2, #0x8                ; =8
10154cc54:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10154cc58:     	b	0x10154cfb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4094>
10154cc5c:     	ldur	q0, [x27, #0x15]
10154cc60:     	stur	q0, [x23, #0x15]
10154cc64:     	ldur	q0, [x27, #0x25]
10154cc68:     	stur	q0, [x23, #0x25]
10154cc6c:     	ldur	q0, [x27, #0x35]
10154cc70:     	stur	q0, [x23, #0x35]
10154cc74:     	ldr	q0, [sp, #0x590]
10154cc78:     	str	q0, [x23, #0x40]
10154cc7c:     	ldur	q0, [x27, #0x5]
10154cc80:     	stur	q0, [x23, #0x5]
10154cc84:     	str	w9, [x23]
10154cc88:     	strb	w8, [x23, #0x4]
10154cc8c:     	b	0x10154cf8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x406c>
10154cc90:     	adrp	x8, 0x10751f000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2c72>
10154cc94:     	ldr	q0, [x8, #0x9c0]
10154cc98:     	stur	q0, [x23, #0x8]
10154cc9c:     	mov	w8, #0x6                ; =6
10154cca0:     	str	w8, [x23]
10154cca4:     	b	0x10154cf8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x406c>
10154cca8:     	str	wzr, [x23]
10154ccac:     	mov	w8, #0xc                ; =12
10154ccb0:     	adrp	x9, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154ccb4:     	add	x9, x9, #0x108
10154ccb8:     	stp	x8, x9, [x23, #0x8]
10154ccbc:     	mov	w8, #0x1c               ; =28
10154ccc0:     	str	x8, [x23, #0x18]
10154ccc4:     	b	0x10154cb5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c3c>
10154ccc8:     	add	x0, sp, #0x550
10154cccc:     	mov	x1, #0x0                ; =0
10154ccd0:     	mov	w2, #0x8                ; =8
10154ccd4:     	mov	x3, x20
10154ccd8:     	mov	w4, #0x8                ; =8
10154ccdc:     	mov	w5, #0x8                ; =8
10154cce0:     	bl	0x1039e2a9c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
10154cce4:     	ldr	w8, [sp, #0x550]
10154cce8:     	tbz	w8, #0x0, 0x10154cd3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e1c>
10154ccec:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154ccf0:     	add	x8, x8, #0x9f0
10154ccf4:     	mov	w9, #0xc                ; =12
10154ccf8:     	stp	x9, x8, [x23, #0x8]
10154ccfc:     	mov	w8, #0x27               ; =39
10154cd00:     	str	x8, [x23, #0x18]
10154cd04:     	str	wzr, [x23]
10154cd08:     	b	0x10154cfb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4094>
10154cd0c:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154cd10:     	add	x2, x2, #0xe70
10154cd14:     	mov	x0, x20
10154cd18:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154cd1c:     	str	wzr, [x23]
10154cd20:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154cd24:     	add	x8, x8, #0x167
10154cd28:     	mov	w9, #0xc                ; =12
10154cd2c:     	stp	x9, x8, [x23, #0x8]
10154cd30:     	mov	w8, #0x27               ; =39
10154cd34:     	str	x8, [x23, #0x18]
10154cd38:     	b	0x10154cf8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x406c>
10154cd3c:     	ldr	x9, [sp, #0x558]
10154cd40:     	ldr	x8, [sp, #0x6d0]
10154cd44:     	b	0x10154c9a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a80>
10154cd48:     	adrp	x8, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154cd4c:     	add	x8, x8, #0xe88
10154cd50:     	mov	x0, x2
10154cd54:     	mov	x2, x8
10154cd58:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154cd5c:     	ldrb	w8, [sp, #0x550]
10154cd60:     	ldr	w9, [sp, #0x554]
10154cd64:     	add	x12, sp, #0x720
10154cd68:     	stur	w9, [x12, #0xb3]
10154cd6c:     	ldur	w9, [x27, #0x1]
10154cd70:     	stur	w9, [x29, #-0x80]
10154cd74:     	ldr	q0, [sp, #0x560]
10154cd78:     	ldr	q1, [sp, #0x570]
10154cd7c:     	str	q0, [sp, #0x440]
10154cd80:     	str	q1, [sp, #0x450]
10154cd84:     	ldr	x10, [sp, #0x580]
10154cd88:     	ldr	x9, [sp, #0x588]
10154cd8c:     	sub	x11, x29, #0xd0
10154cd90:     	str	x10, [sp, #0x460]
10154cd94:     	ldr	d0, [sp, #0x558]
10154cd98:     	ldur	w10, [x12, #0xb3]
10154cd9c:     	stur	w10, [x12, #0x93]
10154cda0:     	ldur	w10, [x29, #-0x80]
10154cda4:     	stur	w10, [x29, #-0xa0]
10154cda8:     	ldr	q1, [sp, #0x440]
10154cdac:     	ldr	q2, [sp, #0x450]
10154cdb0:     	ldr	x10, [sp, #0x460]
10154cdb4:     	str	x10, [sp, #0x240]
10154cdb8:     	stp	q1, q2, [sp, #0x220]
10154cdbc:     	add	x20, sp, #0x720
10154cdc0:     	ldur	w10, [x12, #0x93]
10154cdc4:     	str	w10, [sp, #0x334]
10154cdc8:     	ldur	w10, [x29, #-0xa0]
10154cdcc:     	stur	w10, [x26, #0x1]
10154cdd0:     	ldp	q1, q2, [sp, #0x220]
10154cdd4:     	ldr	x10, [sp, #0x240]
10154cdd8:     	stp	q1, q2, [sp, #0x340]
10154cddc:     	strb	w8, [sp, #0x330]
10154cde0:     	str	d0, [sp, #0x338]
10154cde4:     	str	x10, [sp, #0x360]
10154cde8:     	str	x9, [sp, #0x368]
10154cdec:     	ldr	x8, [sp, #0x58]
10154cdf0:     	ldr	q0, [x8, #0x4e0]
10154cdf4:     	stur	q0, [x27, #0xa8]
10154cdf8:     	ldr	x9, [x8, #0x4f0]
10154cdfc:     	ldp	q0, q1, [x8, #0x80]
10154ce00:     	str	q0, [sp, #0x5d0]
10154ce04:     	str	q1, [sp, #0x5e0]
10154ce08:     	ldr	x10, [x8, #0xa0]
10154ce0c:     	str	x9, [sp, #0x608]
10154ce10:     	str	x10, [sp, #0x5f0]
10154ce14:     	ldp	q0, q1, [x8, #0x40]
10154ce18:     	str	q0, [sp, #0x590]
10154ce1c:     	str	q1, [sp, #0x5a0]
10154ce20:     	ldp	q1, q0, [x8, #0x60]
10154ce24:     	str	q0, [sp, #0x5c0]
10154ce28:     	str	q1, [sp, #0x5b0]
10154ce2c:     	ldp	q0, q1, [x8]
10154ce30:     	str	q0, [sp, #0x550]
10154ce34:     	str	q1, [sp, #0x560]
10154ce38:     	ldp	q1, q0, [x8, #0x20]
10154ce3c:     	str	q0, [sp, #0x580]
10154ce40:     	str	q1, [sp, #0x570]
10154ce44:     	ldr	x8, [sp, #0x40]
10154ce48:     	stp	x8, xzr, [x29, #-0xd8]
10154ce4c:     	stur	xzr, [x29, #-0xc8]
10154ce50:     	add	x8, sp, #0x6d8
10154ce54:     	add	x9, sp, #0x6c0
10154ce58:     	str	x8, [sp, #0x440]
10154ce5c:     	str	x9, [sp, #0x448]
10154ce60:     	add	x8, sp, #0x330
10154ce64:     	add	x9, sp, #0x668
10154ce68:     	str	x8, [sp, #0x450]
10154ce6c:     	str	x9, [sp, #0x458]
10154ce70:     	sub	x8, x29, #0xf0
10154ce74:     	str	x11, [sp, #0x468]
10154ce78:     	add	x9, sp, #0x660
10154ce7c:     	str	x8, [sp, #0x460]
10154ce80:     	str	x9, [sp, #0x470]
10154ce84:     	sub	x8, x29, #0xd8
10154ce88:     	add	x9, sp, #0x550
10154ce8c:     	str	x8, [sp, #0x478]
10154ce90:     	str	x9, [sp, #0x480]
10154ce94:     	adrp	x1, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154ce98:     	add	x1, x1, #0xf30
10154ce9c:     	add	x8, sp, #0x110
10154cea0:     	add	x0, sp, #0x440
10154cea4:     	bl	0x1014b5004 <__RINvNtNtCsgirOGyZpP7g_3std6thread6scoped5scopeNCNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallelNtBS_10Invocation12run_parallelsc_0INtNtCsgDHHaSskbIF_4core6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIB2P_NtBQ_7ReceiptNtBU_27NativeProgramExecutionErrorEEB4f_EEB10_>
10154cea8:     	ldp	q0, q1, [sp, #0x330]
10154ceac:     	str	q0, [sp, #0x440]
10154ceb0:     	str	q1, [sp, #0x450]
10154ceb4:     	ldp	q0, q1, [sp, #0x350]
10154ceb8:     	str	q0, [sp, #0x460]
10154cebc:     	str	q1, [sp, #0x470]
10154cec0:     	mov	w19, #0x1               ; =1
10154cec4:     	add	x8, sp, #0x220
10154cec8:     	add	x0, sp, #0x440
10154cecc:     	bl	0x102921034 <__RNvMs4_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_15NativeWorkGroup29finish_with_credit_statistics>
10154ced0:     	ldr	w8, [sp, #0x220]
10154ced4:     	tbz	w8, #0x0, 0x10154cfc0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40a0>
10154ced8:     	ldr	x8, [sp, #0x238]
10154cedc:     	ldr	q0, [sp, #0x240]
10154cee0:     	str	q0, [x23, #0x30]
10154cee4:     	ldur	w10, [x29, #-0xf0]
10154cee8:     	ldur	q0, [x25, #0x8]
10154ceec:     	mov	w11, #0x4               ; =4
10154cef0:     	stp	w11, w10, [x23]
10154cef4:     	ldur	q1, [x20, #0x44]
10154cef8:     	stur	q1, [x23, #0x8]
10154cefc:     	stur	q0, [x23, #0x18]
10154cf00:     	mov	w9, #0x28               ; =40
10154cf04:     	b	0x10154d0f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d8>
10154cf08:     	mov	w10, #0x0               ; =0
10154cf0c:     	ldr	d0, [sp, #0x550]
10154cf10:     	mov	w8, #0xd                ; =13
10154cf14:     	add	x11, sp, #0x110
10154cf18:     	ldur	w11, [x11, #0x3]
10154cf1c:     	add	x13, sp, #0x720
10154cf20:     	stur	w11, [x13, #0xb3]
10154cf24:     	ldr	w11, [sp, #0x110]
10154cf28:     	stur	w11, [x29, #-0x80]
10154cf2c:     	ldur	q1, [x19, #0x8]
10154cf30:     	ldur	q2, [x19, #0x18]
10154cf34:     	str	q1, [sp, #0x440]
10154cf38:     	str	q2, [sp, #0x450]
10154cf3c:     	ldur	x11, [x19, #0x28]
10154cf40:     	str	x11, [sp, #0x460]
10154cf44:     	ldur	w12, [x13, #0xb3]
10154cf48:     	stur	w12, [x13, #0x93]
10154cf4c:     	ldur	w12, [x29, #-0x80]
10154cf50:     	stur	w12, [x29, #-0xa0]
10154cf54:     	str	x11, [sp, #0x240]
10154cf58:     	stp	q1, q2, [sp, #0x220]
10154cf5c:     	stur	w12, [x23, #0x9]
10154cf60:     	ldur	w11, [x13, #0x93]
10154cf64:     	str	w11, [x23, #0xc]
10154cf68:     	ldp	q1, q2, [sp, #0x220]
10154cf6c:     	stur	q1, [x23, #0x18]
10154cf70:     	stur	q2, [x23, #0x28]
10154cf74:     	ldr	x11, [sp, #0x240]
10154cf78:     	str	x11, [x23, #0x38]
10154cf7c:     	stp	w10, w9, [x23]
10154cf80:     	strb	w8, [x23, #0x8]
10154cf84:     	mov	w19, #0x1               ; =1
10154cf88:     	str	d0, [x23, #0x10]
10154cf8c:     	mov	w28, #0x1               ; =1
10154cf90:     	add	x0, sp, #0x720
10154cf94:     	bl	0x10152b450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10154cf98:     	ldr	x8, [sp, #0x708]
10154cf9c:     	cbz	x8, 0x10154cfb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4090>
10154cfa0:     	ldr	x0, [sp, #0x710]
10154cfa4:     	lsl	x1, x8, #3
10154cfa8:     	mov	w2, #0x8                ; =8
10154cfac:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10154cfb0:     	tbz	w19, #0x0, 0x10154c1f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d0>
10154cfb4:     	add	x0, sp, #0x6e0
10154cfb8:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154cfbc:     	b	0x10154c1f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d0>
10154cfc0:     	ldr	x8, [sp, #0x238]
10154cfc4:     	ldr	x9, [sp, #0x20]
10154cfc8:     	ldr	x9, [x9, #0x418]
10154cfcc:     	adds	x9, x9, x8
10154cfd0:     	b.hs	0x10154d0ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x418c>
10154cfd4:     	ldr	x10, [sp, #0x240]
10154cfd8:     	ldr	x8, [sp, #0x248]
10154cfdc:     	ldr	x11, [sp, #0x20]
10154cfe0:     	str	x9, [x11, #0x418]
10154cfe4:     	ldr	x9, [x11, #0x420]
10154cfe8:     	adds	x9, x9, x10
10154cfec:     	b.hs	0x10154d0c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41a0>
10154cff0:     	ldr	x10, [sp, #0x20]
10154cff4:     	str	x9, [x10, #0x420]
10154cff8:     	ldr	x9, [x10, #0x428]
10154cffc:     	adds	x8, x9, x8
10154d000:     	b.hs	0x10154d0dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41bc>
10154d004:     	ldr	x9, [sp, #0x20]
10154d008:     	str	x8, [x9, #0x428]
10154d00c:     	ldr	q0, [sp, #0x6e0]
10154d010:     	ldr	q1, [sp, #0x6f0]
10154d014:     	str	q0, [sp, #0x440]
10154d018:     	str	q1, [sp, #0x450]
10154d01c:     	mov	w19, #0x0               ; =0
10154d020:     	add	x0, sp, #0x440
10154d024:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154d028:     	ldr	w8, [sp, #0x110]
10154d02c:     	cmp	w8, #0x6
10154d030:     	b.ne	0x10154d108 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41e8>
10154d034:     	mov	x9, #0x0                ; =0
10154d038:     	add	x8, sp, #0x110
10154d03c:     	ldur	q0, [x8, #0x8]
10154d040:     	stur	q0, [x29, #-0xc0]
10154d044:     	ldr	x8, [sp, #0x128]
10154d048:     	stur	x8, [x29, #-0xb0]
10154d04c:     	ldur	x20, [x29, #-0xb8]
10154d050:     	mov	w10, #0xc8              ; =200
10154d054:     	mul	x10, x8, x10
10154d058:     	add	x21, x20, x10
10154d05c:     	cmp	x10, x9
10154d060:     	b.eq	0x10154d130 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4210>
10154d064:     	ldr	x11, [x20, x9]
10154d068:     	add	x9, x9, #0xc8
10154d06c:     	cbz	x11, 0x10154d05c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x413c>
10154d070:     	b	0x10154d18c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x426c>
10154d074:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154d078:     	add	x2, x2, #0xee8
10154d07c:     	ldr	x0, [sp, #0x38]
10154d080:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154d084:     	b	0x10154d0a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
10154d088:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154d08c:     	add	x2, x2, #0xf00
10154d090:     	ldr	x0, [sp, #0x30]
10154d094:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154d098:     	b	0x10154d0a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
10154d09c:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
10154d0a0:     	add	x2, x2, #0xf18
10154d0a4:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154d0a8:     	brk	#0x1
10154d0ac:     	str	wzr, [x23]
10154d0b0:     	mov	w9, #0xc                ; =12
10154d0b4:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d0b8:     	add	x10, x10, #0x18e
10154d0bc:     	b	0x10154d0d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41b0>
10154d0c0:     	str	wzr, [x23]
10154d0c4:     	mov	w9, #0xc                ; =12
10154d0c8:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d0cc:     	add	x10, x10, #0x1b7
10154d0d0:     	stp	x9, x10, [x23, #0x8]
10154d0d4:     	mov	w8, #0x29               ; =41
10154d0d8:     	b	0x10154d0f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d4>
10154d0dc:     	str	wzr, [x23]
10154d0e0:     	mov	w9, #0xc                ; =12
10154d0e4:     	adrp	x10, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d0e8:     	add	x10, x10, #0x1e0
10154d0ec:     	stp	x9, x10, [x23, #0x8]
10154d0f0:     	mov	w8, #0x2b               ; =43
10154d0f4:     	mov	w9, #0x18               ; =24
10154d0f8:     	str	x8, [x23, x9]
10154d0fc:     	add	x0, sp, #0x110
10154d100:     	bl	0x10152995c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
10154d104:     	b	0x10154cf8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x406c>
10154d108:     	ldp	q0, q1, [sp, #0x140]
10154d10c:     	stp	q0, q1, [x23, #0x30]
10154d110:     	add	x9, sp, #0x110
10154d114:     	ldur	q0, [x9, #0x4]
10154d118:     	stur	q0, [x23, #0x4]
10154d11c:     	ldp	q1, q0, [sp, #0x120]
10154d120:     	stp	q1, q0, [x23, #0x10]
10154d124:     	str	w8, [x23]
10154d128:     	mov	w19, #0x0               ; =0
10154d12c:     	b	0x10154cf8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x406c>
10154d130:     	ldr	x9, [sp, #0x20]
10154d134:     	ldr	x9, [x9, #0x440]
10154d138:     	cmn	x9, #0x1
10154d13c:     	b.eq	0x10154d390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4470>
10154d140:     	add	x9, x9, #0x1
10154d144:     	ldr	x10, [sp, #0x20]
10154d148:     	str	x9, [x10, #0x440]
10154d14c:     	ldr	x9, [x10, #0x438]
10154d150:     	ldr	x10, [sp, #0x6d0]
10154d154:     	adds	x9, x10, x9
10154d158:     	b.hs	0x10154d390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4470>
10154d15c:     	ldp	x10, x11, [sp, #0x18]
10154d160:     	str	x9, [x11, #0x438]
10154d164:     	ldr	x9, [x11, #0x448]
10154d168:     	adds	x9, x9, x10
10154d16c:     	b.hs	0x10154d3a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4480>
10154d170:     	ldr	x11, [sp, #0x20]
10154d174:     	str	x9, [x11, #0x448]
10154d178:     	ldr	x9, [x11, #0x450]
10154d17c:     	ldur	x10, [x29, #-0xc8]
10154d180:     	cmp	x10, x9
10154d184:     	csel	x9, x10, x9, hi
10154d188:     	str	x9, [x11, #0x450]
10154d18c:     	mov	w9, #0xc8               ; =200
10154d190:     	mul	x10, x8, x9
10154d194:     	add	x11, x20, #0x60
10154d198:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d19c:     	add	x8, x8, #0x228
10154d1a0:     	mov	w9, #0x17               ; =23
10154d1a4:     	adrp	x12, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1a8:     	add	x12, x12, #0x23f
10154d1ac:     	adrp	x13, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1b0:     	add	x13, x13, #0x257
10154d1b4:     	adrp	x14, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1b8:     	add	x14, x14, #0x26f
10154d1bc:     	adrp	x15, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1c0:     	add	x15, x15, #0x28e
10154d1c4:     	adrp	x16, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1c8:     	add	x16, x16, #0x2b4
10154d1cc:     	adrp	x17, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1d0:     	add	x17, x17, #0x2d3
10154d1d4:     	adrp	x1, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1d8:     	add	x1, x1, #0x2ef
10154d1dc:     	adrp	x2, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1e0:     	add	x2, x2, #0x313
10154d1e4:     	adrp	x3, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1e8:     	add	x3, x3, #0x337
10154d1ec:     	adrp	x4, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1f0:     	add	x4, x4, #0x356
10154d1f4:     	adrp	x0, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d1f8:     	add	x0, x0, #0x373
10154d1fc:     	adrp	x5, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d200:     	add	x5, x5, #0x39b
10154d204:     	b	0x10154d210 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42f0>
10154d208:     	sub	x10, x10, #0xc8
10154d20c:     	add	x11, x11, #0xc8
10154d210:     	cbz	x10, 0x10154d3b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4490>
10154d214:     	ldur	x6, [x11, #-0x60]
10154d218:     	cmp	x6, #0x1
10154d21c:     	b.eq	0x10154d208 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
10154d220:     	ldr	x6, [sp, #0x20]
10154d224:     	ldr	x6, [x6, #0x330]
10154d228:     	ldur	x7, [x11, #-0x18]
10154d22c:     	adds	x6, x7, x6
10154d230:     	b.hs	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d234:     	ldr	x7, [sp, #0x20]
10154d238:     	str	x6, [x7, #0x330]
10154d23c:     	ldr	x6, [x7, #0x3c8]
10154d240:     	ldur	x7, [x11, #-0x10]
10154d244:     	adds	x6, x7, x6
10154d248:     	b.hs	0x10154d56c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x464c>
10154d24c:     	ldr	x7, [sp, #0x20]
10154d250:     	str	x6, [x7, #0x3c8]
10154d254:     	ldr	x6, [x7, #0x3d0]
10154d258:     	ldur	x7, [x11, #-0x8]
10154d25c:     	adds	x6, x7, x6
10154d260:     	b.hs	0x10154d578 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4658>
10154d264:     	ldr	x7, [sp, #0x20]
10154d268:     	str	x6, [x7, #0x3d0]
10154d26c:     	ldr	x6, [x7, #0x3d8]
10154d270:     	ldr	x7, [x11]
10154d274:     	adds	x6, x7, x6
10154d278:     	b.hs	0x10154d584 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4664>
10154d27c:     	ldr	x7, [sp, #0x20]
10154d280:     	str	x6, [x7, #0x3d8]
10154d284:     	ldr	x6, [x7, #0x3e0]
10154d288:     	ldr	x7, [x11, #0x8]
10154d28c:     	adds	x6, x7, x6
10154d290:     	b.hs	0x10154d590 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4670>
10154d294:     	ldr	x7, [sp, #0x20]
10154d298:     	str	x6, [x7, #0x3e0]
10154d29c:     	ldr	x6, [x7, #0x3e8]
10154d2a0:     	ldr	x7, [x11, #0x10]
10154d2a4:     	adds	x6, x7, x6
10154d2a8:     	b.hs	0x10154d59c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x467c>
10154d2ac:     	ldr	x7, [sp, #0x20]
10154d2b0:     	str	x6, [x7, #0x3e8]
10154d2b4:     	ldr	x6, [x7, #0x3f0]
10154d2b8:     	ldr	x7, [x11, #0x18]
10154d2bc:     	adds	x6, x7, x6
10154d2c0:     	b.hs	0x10154d5a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4688>
10154d2c4:     	ldr	x7, [sp, #0x20]
10154d2c8:     	str	x6, [x7, #0x3f0]
10154d2cc:     	ldr	x6, [x7, #0x3f8]
10154d2d0:     	ldr	x7, [x11, #0x20]
10154d2d4:     	adds	x6, x7, x6
10154d2d8:     	b.hs	0x10154d5b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4694>
10154d2dc:     	ldr	x7, [sp, #0x20]
10154d2e0:     	str	x6, [x7, #0x3f8]
10154d2e4:     	ldr	x6, [x7, #0x400]
10154d2e8:     	ldr	x7, [x11, #0x28]
10154d2ec:     	adds	x6, x7, x6
10154d2f0:     	b.hs	0x10154d5c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46a0>
10154d2f4:     	ldr	x7, [sp, #0x20]
10154d2f8:     	str	x6, [x7, #0x400]
10154d2fc:     	ldr	x6, [x7, #0x408]
10154d300:     	ldr	x7, [x11, #0x30]
10154d304:     	adds	x6, x7, x6
10154d308:     	b.hs	0x10154d5cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46ac>
10154d30c:     	ldr	x7, [sp, #0x20]
10154d310:     	str	x6, [x7, #0x408]
10154d314:     	ldr	x6, [x7, #0x410]
10154d318:     	ldr	x7, [x11, #0x38]
10154d31c:     	adds	x6, x7, x6
10154d320:     	b.hs	0x10154d5d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46b8>
10154d324:     	ldr	x7, [sp, #0x20]
10154d328:     	str	x6, [x7, #0x410]
10154d32c:     	ldr	x6, [x7, #0x418]
10154d330:     	ldr	x7, [x11, #0x40]
10154d334:     	adds	x6, x7, x6
10154d338:     	b.hs	0x10154d5e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46c4>
10154d33c:     	ldr	x7, [sp, #0x20]
10154d340:     	str	x6, [x7, #0x418]
10154d344:     	ldr	x6, [x7, #0x420]
10154d348:     	ldr	x7, [x11, #0x48]
10154d34c:     	adds	x6, x7, x6
10154d350:     	b.hs	0x10154d5e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46c4>
10154d354:     	ldr	x7, [sp, #0x20]
10154d358:     	str	x6, [x7, #0x420]
10154d35c:     	ldr	x6, [x7, #0x428]
10154d360:     	ldr	x7, [x11, #0x50]
10154d364:     	adds	x6, x7, x6
10154d368:     	b.hs	0x10154d5e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46c4>
10154d36c:     	ldr	x7, [sp, #0x20]
10154d370:     	str	x6, [x7, #0x428]
10154d374:     	ldr	x6, [x7, #0x430]
10154d378:     	ldr	x7, [x11, #0x58]
10154d37c:     	adds	x6, x7, x6
10154d380:     	b.hs	0x10154d5f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d0>
10154d384:     	ldr	x7, [sp, #0x20]
10154d388:     	str	x6, [x7, #0x430]
10154d38c:     	b	0x10154d208 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42e8>
10154d390:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d394:     	add	x8, x8, #0x20b
10154d398:     	mov	w9, #0x1d               ; =29
10154d39c:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d3a0:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d3a4:     	add	x8, x8, #0x108
10154d3a8:     	mov	w9, #0x1c               ; =28
10154d3ac:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d3b0:     	stp	xzr, xzr, [x29, #-0x90]
10154d3b4:     	mov	w8, #0x8                ; =8
10154d3b8:     	stp	xzr, x8, [x29, #-0xa0]
10154d3bc:     	mov	w28, #0x1               ; =1
10154d3c0:     	ldr	x1, [sp, #0x6d0]
10154d3c4:     	sub	x0, x29, #0xa0
10154d3c8:     	bl	0x101628010 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE17try_reserve_exactB1h_>
10154d3cc:     	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
10154d3d0:     	cmp	x0, x8
10154d3d4:     	b.ne	0x10154d60c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46ec>
10154d3d8:     	ldur	x8, [x29, #-0xa0]
10154d3dc:     	ldr	x9, [sp, #0x6d0]
10154d3e0:     	cmp	x8, x9
10154d3e4:     	b.ne	0x10154d61c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46fc>
10154d3e8:     	ldr	x9, [sp, #0x6c8]
10154d3ec:     	ldr	x10, [sp, #0x6c0]
10154d3f0:     	mov	w11, #0x68              ; =104
10154d3f4:     	madd	x22, x8, x11, x9
10154d3f8:     	stp	x9, x9, [x29, #-0x80]
10154d3fc:     	stp	x10, x22, [x29, #-0x70]
10154d400:     	cbz	x8, 0x10154d4b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4594>
10154d404:     	add	x24, sp, #0x440
10154d408:     	add	x19, x9, #0x68
10154d40c:     	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
10154d410:     	mov	x26, x19
10154d414:     	ldr	x8, [x26, #-0x68]!
10154d418:     	cmp	x8, x25
10154d41c:     	b.eq	0x10154d4b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4590>
10154d420:     	str	x8, [sp, #0x440]
10154d424:     	ldur	q0, [x26, #0x58]
10154d428:     	stur	q0, [x24, #0x58]
10154d42c:     	ldur	q0, [x26, #0x28]
10154d430:     	stur	q0, [x24, #0x28]
10154d434:     	ldur	q0, [x26, #0x38]
10154d438:     	stur	q0, [x24, #0x38]
10154d43c:     	ldur	q0, [x26, #0x48]
10154d440:     	stur	q0, [x24, #0x48]
10154d444:     	ldur	q0, [x26, #0x8]
10154d448:     	stur	q0, [x24, #0x8]
10154d44c:     	ldur	q0, [x26, #0x18]
10154d450:     	stur	q0, [x24, #0x18]
10154d454:     	ldr	x8, [sp, #0x498]
10154d458:     	ldr	x9, [sp, #0x4a0]
10154d45c:     	ldur	q0, [x26, #0x18]
10154d460:     	str	q0, [sp, #0x220]
10154d464:     	ldur	q0, [x26, #0x28]
10154d468:     	str	q0, [sp, #0x230]
10154d46c:     	ldur	q0, [x26, #0x38]
10154d470:     	str	q0, [sp, #0x240]
10154d474:     	ldur	q0, [x26, #0x48]
10154d478:     	str	q0, [sp, #0x250]
10154d47c:     	str	x8, [sp, #0x260]
10154d480:     	str	xzr, [sp, #0x268]
10154d484:     	str	x9, [sp, #0x270]
10154d488:     	sub	x0, x29, #0xa0
10154d48c:     	add	x1, sp, #0x220
10154d490:     	bl	0x101627f74 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE13push_back_mutB1h_>
10154d494:     	add	x0, sp, #0x440
10154d498:     	bl	0x10152a450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10154d49c:     	add	x19, x26, #0xd0
10154d4a0:     	add	x8, x26, #0x68
10154d4a4:     	cmp	x8, x22
10154d4a8:     	b.ne	0x10154d410 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44f0>
10154d4ac:     	mov	x19, x22
10154d4b0:     	stur	x19, [x29, #-0x78]
10154d4b4:     	mov	w28, #0x0               ; =0
10154d4b8:     	sub	x0, x29, #0x80
10154d4bc:     	bl	0x1014e2898 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
10154d4c0:     	ldp	q0, q1, [x29, #-0xa0]
10154d4c4:     	str	q0, [sp, #0x440]
10154d4c8:     	str	q1, [sp, #0x450]
10154d4cc:     	ldur	x24, [x29, #-0xc0]
10154d4d0:     	ldr	q0, [sp, #0x680]
10154d4d4:     	ldr	q1, [sp, #0x690]
10154d4d8:     	stp	q0, q1, [sp, #0x220]
10154d4dc:     	ldr	q0, [sp, #0x6a0]
10154d4e0:     	ldr	q1, [sp, #0x6b0]
10154d4e4:     	stp	q0, q1, [x29, #-0x80]
10154d4e8:     	ldr	x8, [sp, #0x58]
10154d4ec:     	add	x0, x8, #0x3c0
10154d4f0:     	bl	0x101529668 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
10154d4f4:     	ldr	q0, [sp, #0x440]
10154d4f8:     	ldr	q1, [sp, #0x450]
10154d4fc:     	ldr	x8, [sp, #0x58]
10154d500:     	stp	q0, q1, [x8, #0x3c0]
10154d504:     	ldp	q0, q1, [sp, #0x220]
10154d508:     	str	q0, [x8, #0x400]
10154d50c:     	str	q1, [x8, #0x410]
10154d510:     	ldp	q0, q1, [x29, #-0x80]
10154d514:     	str	q0, [x8, #0x420]
10154d518:     	str	x20, [x8, #0x3e0]
10154d51c:     	str	x20, [x8, #0x3e8]
10154d520:     	str	x24, [x8, #0x3f0]
10154d524:     	str	x21, [x8, #0x3f8]
10154d528:     	str	q1, [x8, #0x430]
10154d52c:     	mov	w8, #0x1                ; =1
10154d530:     	dup.2d	v0, x8
10154d534:     	stur	q0, [x23, #0x8]
10154d538:     	mov	w8, #0x6                ; =6
10154d53c:     	str	w8, [x23]
10154d540:     	mov	w19, #0x0               ; =0
10154d544:     	mov	w28, #0x0               ; =0
10154d548:     	add	x0, sp, #0x720
10154d54c:     	bl	0x10152b450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10154d550:     	ldr	x8, [sp, #0x708]
10154d554:     	cbz	x8, 0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154d558:     	ldr	x0, [sp, #0x710]
10154d55c:     	lsl	x1, x8, #3
10154d560:     	mov	w2, #0x8                ; =8
10154d564:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10154d568:     	b	0x10154c478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3558>
10154d56c:     	mov	x8, x12
10154d570:     	mov	w9, #0x18               ; =24
10154d574:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d578:     	mov	x8, x13
10154d57c:     	mov	w9, #0x18               ; =24
10154d580:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d584:     	mov	x8, x14
10154d588:     	mov	w9, #0x1f               ; =31
10154d58c:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d590:     	mov	x8, x15
10154d594:     	mov	w9, #0x26               ; =38
10154d598:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d59c:     	mov	x8, x16
10154d5a0:     	mov	w9, #0x1f               ; =31
10154d5a4:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d5a8:     	mov	x8, x17
10154d5ac:     	mov	w9, #0x1c               ; =28
10154d5b0:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d5b4:     	mov	x8, x1
10154d5b8:     	mov	w9, #0x24               ; =36
10154d5bc:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d5c0:     	mov	x8, x2
10154d5c4:     	mov	w9, #0x24               ; =36
10154d5c8:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d5cc:     	mov	x8, x3
10154d5d0:     	mov	w9, #0x1f               ; =31
10154d5d4:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d5d8:     	mov	x8, x4
10154d5dc:     	mov	w9, #0x1d               ; =29
10154d5e0:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d5e4:     	mov	x8, x0
10154d5e8:     	mov	w9, #0x28               ; =40
10154d5ec:     	b	0x10154d5f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
10154d5f0:     	mov	x8, x5
10154d5f4:     	mov	w9, #0x21               ; =33
10154d5f8:     	str	wzr, [x23]
10154d5fc:     	mov	w10, #0xc               ; =12
10154d600:     	stp	x10, x8, [x23, #0x8]
10154d604:     	str	x9, [x23, #0x18]
10154d608:     	b	0x10154d640 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4720>
10154d60c:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
10154d610:     	add	x8, x8, #0x124
10154d614:     	mov	w9, #0x21               ; =33
10154d618:     	b	0x10154d628 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4708>
10154d61c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154d620:     	add	x8, x8, #0xa17
10154d624:     	mov	w9, #0x30               ; =48
10154d628:     	str	wzr, [x23]
10154d62c:     	mov	w10, #0xc               ; =12
10154d630:     	strb	w10, [x23, #0x8]
10154d634:     	stp	x8, x9, [x23, #0x10]
10154d638:     	sub	x0, x29, #0xa0
10154d63c:     	bl	0x10152acd8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
10154d640:     	sub	x0, x29, #0xc0
10154d644:     	bl	0x10152a1d4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
10154d648:     	mov	w19, #0x0               ; =0
10154d64c:     	b	0x10154cf8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x406c>
10154d650:     	mov	x22, x0
10154d654:     	mov	w19, #0x0               ; =0
10154d658:     	b	0x10154d740 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4820>
10154d65c:     	mov	x22, x0
10154d660:     	mov	w28, #0x1               ; =1
10154d664:     	b	0x10154d6f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47d8>
10154d668:     	mov	x22, x0
10154d66c:     	mov	x23, x28
10154d670:     	b	0x10154d750 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4830>
10154d674:     	mov	x22, x0
10154d678:     	mov	w19, #0x0               ; =0
10154d67c:     	mov	w28, #0x0               ; =0
10154d680:     	mov	w23, #0x0               ; =0
10154d684:     	ldr	q0, [sp, #0x440]
10154d688:     	ldr	q1, [sp, #0x450]
10154d68c:     	ldr	x8, [sp, #0x58]
10154d690:     	stp	q0, q1, [x8, #0x3c0]
10154d694:     	ldp	q0, q1, [sp, #0x220]
10154d698:     	str	q0, [x8, #0x400]
10154d69c:     	str	q1, [x8, #0x410]
10154d6a0:     	ldp	q0, q1, [x29, #-0x80]
10154d6a4:     	str	q0, [x8, #0x420]
10154d6a8:     	str	x20, [x8, #0x3e0]
10154d6ac:     	str	x20, [x8, #0x3e8]
10154d6b0:     	str	x24, [x8, #0x3f0]
10154d6b4:     	str	x21, [x8, #0x3f8]
10154d6b8:     	str	q1, [x8, #0x430]
10154d6bc:     	b	0x10154d748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4828>
10154d6c0:     	mov	x22, x0
10154d6c4:     	b	0x10154d6f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47d0>
10154d6c8:     	mov	x22, x0
10154d6cc:     	stur	x19, [x29, #-0x78]
10154d6d0:     	b	0x10154d6e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47c4>
10154d6d4:     	mov	x22, x0
10154d6d8:     	stur	x19, [x29, #-0x78]
10154d6dc:     	add	x0, sp, #0x440
10154d6e0:     	bl	0x10152a450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10154d6e4:     	sub	x0, x29, #0x80
10154d6e8:     	bl	0x1014e2898 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
10154d6ec:     	mov	w28, #0x0               ; =0
10154d6f0:     	sub	x0, x29, #0xa0
10154d6f4:     	bl	0x10152acd8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
10154d6f8:     	sub	x0, x29, #0xc0
10154d6fc:     	bl	0x10152a1d4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
10154d700:     	mov	w19, #0x0               ; =0
10154d704:     	b	0x10154d744 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4824>
10154d708:     	mov	x22, x0
10154d70c:     	b	0x10154d73c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x481c>
10154d710:     	mov	x22, x0
10154d714:     	b	0x10154d73c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x481c>
10154d718:     	b	0x10154d780 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4860>
10154d71c:     	b	0x10154d7a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4884>
10154d720:     	mov	x22, x0
10154d724:     	add	x0, sp, #0x110
10154d728:     	bl	0x10152995c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
10154d72c:     	b	0x10154d740 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4820>
10154d730:     	mov	x22, x0
10154d734:     	add	x0, sp, #0x330
10154d738:     	bl	0x10152bef4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers15NativeWorkGroupECs7fdMCt8k5K6_8mech_gpu>
10154d73c:     	mov	w19, #0x1               ; =1
10154d740:     	mov	w28, #0x1               ; =1
10154d744:     	mov	w23, #0x1               ; =1
10154d748:     	add	x0, sp, #0x720
10154d74c:     	bl	0x10152b450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10154d750:     	ldr	x8, [sp, #0x708]
10154d754:     	cbz	x8, 0x10154d768 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4848>
10154d758:     	ldr	x0, [sp, #0x710]
10154d75c:     	lsl	x1, x8, #3
10154d760:     	mov	w2, #0x8                ; =8
10154d764:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10154d768:     	tbz	w19, #0x0, 0x10154d774 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4854>
10154d76c:     	add	x0, sp, #0x6e0
10154d770:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154d774:     	tbnz	w28, #0x0, 0x10154d7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x488c>
10154d778:     	b	0x10154d7b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4894>
10154d77c:     	b	0x10154d794 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4874>
10154d780:     	mov	x22, x0
10154d784:     	add	x0, sp, #0x110
10154d788:     	bl	0x10152a450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
10154d78c:     	b	0x10154d798 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4878>
10154d790:     	b	0x10154d7a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4884>
10154d794:     	mov	x22, x0
10154d798:     	add	x0, sp, #0x220
10154d79c:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154d7a0:     	b	0x10154d7a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4888>
10154d7a4:     	mov	x22, x0
10154d7a8:     	mov	w23, #0x1               ; =1
10154d7ac:     	add	x0, sp, #0x6c0
10154d7b0:     	bl	0x10152a36c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
10154d7b4:     	tbnz	w23, #0x0, 0x10154d7c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48a0>
10154d7b8:     	b	0x10154d7fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48dc>
10154d7bc:     	mov	x22, x0
10154d7c0:     	add	x0, sp, #0x6a0
10154d7c4:     	bl	0x10152b450 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10154d7c8:     	b	0x10154d7d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48b0>
10154d7cc:     	mov	x22, x0
10154d7d0:     	add	x0, sp, #0x680
10154d7d4:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154d7d8:     	b	0x10154d7fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48dc>
10154d7dc:     	mov	x22, x0
10154d7e0:     	add	x1, sp, #0x550
10154d7e4:     	mov	x0, x20
10154d7e8:     	mov	w2, #0x108              ; =264
10154d7ec:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
10154d7f0:     	mov	w19, #0x0               ; =0
10154d7f4:     	b	0x10154d87c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x495c>
10154d7f8:     	mov	x22, x0
10154d7fc:     	ldr	x8, [sp, #0x668]
10154d800:     	mov	x9, #-0x1               ; =-1
10154d804:     	ldaddl	x9, x8, [x8]
10154d808:     	cmp	x8, #0x1
10154d80c:     	b.ne	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d810:     	dmb	ishld
10154d814:     	add	x0, sp, #0x668
10154d818:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154d81c:     	b	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d820:     	mov	x22, x0
10154d824:     	ldr	x8, [sp, #0x550]
10154d828:     	mov	x9, #-0x1               ; =-1
10154d82c:     	ldaddl	x9, x8, [x8]
10154d830:     	cmp	x8, #0x1
10154d834:     	b.ne	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d838:     	dmb	ishld
10154d83c:     	add	x0, sp, #0x550
10154d840:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154d844:     	b	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d848:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10154d84c:     	mov	x22, x0
10154d850:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
10154d854:     	str	x8, [x20]
10154d858:     	b	0x10154d890 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4970>
10154d85c:     	mov	x22, x0
10154d860:     	add	x0, sp, #0x440
10154d864:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154d868:     	b	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d86c:     	mov	x22, x0
10154d870:     	tbnz	w19, #0x0, 0x10154d8dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49bc>
10154d874:     	b	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d878:     	mov	x22, x0
10154d87c:     	sub	x0, x29, #0x80
10154d880:     	bl	0x10152b4c8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154d884:     	b	0x10154d8b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4998>
10154d888:     	mov	x22, x0
10154d88c:     	mov	x23, x24
10154d890:     	cbz	w23, 0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d894:     	ldr	x8, [sp, #0x550]
10154d898:     	cbz	x8, 0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d89c:     	add	x0, sp, #0x550
10154d8a0:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154d8a4:     	b	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d8a8:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10154d8ac:     	mov	x22, x0
10154d8b0:     	b	0x10154d8dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49bc>
10154d8b4:     	mov	x22, x0
10154d8b8:     	ldur	x8, [x29, #-0xa0]
10154d8bc:     	mov	x9, #-0x1               ; =-1
10154d8c0:     	ldaddl	x9, x8, [x8]
10154d8c4:     	cmp	x8, #0x1
10154d8c8:     	b.ne	0x10154d8d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49b8>
10154d8cc:     	dmb	ishld
10154d8d0:     	sub	x0, x29, #0xa0
10154d8d4:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
10154d8d8:     	tbz	w19, #0x0, 0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d8dc:     	add	x0, sp, #0x220
10154d8e0:     	bl	0x10152c114 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
10154d8e4:     	b	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d8e8:     	mov	x22, x0
10154d8ec:     	add	x0, sp, #0x60
10154d8f0:     	bl	0x10152b6f0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10154d8f4:     	b	0x10154d924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a04>
10154d8f8:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10154d8fc:     	mov	w8, #0x2                ; =2
10154d900:     	str	x8, [x20, #0x220]
10154d904:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
10154d908:     	mov	w8, #0x2                ; =2
10154d90c:     	str	x8, [x20, #0x220]
10154d910:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
10154d914:     	mov	x22, x0
10154d918:     	ldr	w8, [sp, #0x550]
10154d91c:     	cmp	w8, #0x6
10154d920:     	b.ne	0x10154d92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a0c>
10154d924:     	mov	x0, x22
10154d928:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
10154d92c:     	add	x0, sp, #0x550
10154d930:     	bl	0x10152bff0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10154d934:     	mov	x0, x22
10154d938:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
