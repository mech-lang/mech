
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152f1ac <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>:
10152f1ac:     	stp	x20, x19, [sp, #-0x20]!
10152f1b0:     	stp	x29, x30, [sp, #0x10]
10152f1b4:     	add	x29, sp, #0x10
10152f1b8:     	mov	x19, x4
10152f1bc:     	cmp	x3, x2
10152f1c0:     	b.hs	0x10152f210 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_+0x64>
10152f1c4:     	mov	w8, #0x170              ; =368
10152f1c8:     	madd	x8, x3, x8, x1
10152f1cc:     	add	x9, x8, #0x148
10152f1d0:     	ldr	q0, [x9]
10152f1d4:     	stur	q0, [x0, #0x4]
10152f1d8:     	ldp	q0, q1, [x19]
10152f1dc:     	stur	q0, [x0, #0x18]
10152f1e0:     	ldr	w8, [x8, #0x158]
10152f1e4:     	str	w8, [x0, #0x14]
10152f1e8:     	stur	q1, [x0, #0x28]
10152f1ec:     	ldr	q0, [x19, #0x20]
10152f1f0:     	stur	q0, [x0, #0x38]
10152f1f4:     	ldr	x8, [x19, #0x30]
10152f1f8:     	str	x8, [x0, #0x48]
10152f1fc:     	mov	w8, #0x3                ; =3
10152f200:     	str	w8, [x0]
10152f204:     	ldp	x29, x30, [sp, #0x10]
10152f208:     	ldp	x20, x19, [sp], #0x20
10152f20c:     	ret
10152f210:     	adrp	x8, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
10152f214:     	add	x8, x8, #0x870
10152f218:     	mov	x0, x3
10152f21c:     	mov	x1, x2
10152f220:     	mov	x2, x8
10152f224:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152f228:     	brk	#0x1
10152f22c:     	mov	x20, x0
10152f230:     	mov	x0, x19
10152f234:     	bl	0x10152c184 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10152f238:     	mov	x0, x20
10152f23c:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
