
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015cd100 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu>:
1015cd100:     	sub	sp, sp, #0x80
1015cd104:     	stp	x24, x23, [sp, #0x40]
1015cd108:     	stp	x22, x21, [sp, #0x50]
1015cd10c:     	stp	x20, x19, [sp, #0x60]
1015cd110:     	stp	x29, x30, [sp, #0x70]
1015cd114:     	add	x29, sp, #0x70
1015cd118:     	mov	x19, x8
1015cd11c:     	ldr	x8, [x0]
1015cd120:     	ldr	x21, [x1]
1015cd124:     	ldr	x20, [x2]
1015cd128:     	mov	x0, #0x0                ; =0
1015cd12c:     	blr	x8
1015cd130:     	cbz	x0, 0x1015cd2bc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x1bc>
1015cd134:     	ldr	x8, [x0, #0x20]
1015cd138:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1015cd13c:     	cmp	x8, x9
1015cd140:     	b.hs	0x1015cd2a4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x1a4>
1015cd144:     	ldr	x8, [x0, #0x28]
1015cd148:     	cmp	x8, #0x0
1015cd14c:     	ccmp	x8, x21, #0x4, ne
1015cd150:     	b.ne	0x1015cd1cc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0xcc>
1015cd154:     	ldr	x8, [x21, #0x10]
1015cd158:     	cbnz	x8, 0x1015cd2b0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x1b0>
1015cd15c:     	mov	x8, #-0x1               ; =-1
1015cd160:     	str	x8, [x21, #0x10]
1015cd164:     	ldr	w8, [x0, #0x30]
1015cd168:     	ldp	x9, x10, [x0, #0x38]
1015cd16c:     	ldp	x11, x12, [x21, #0x60]
1015cd170:     	cmp	x9, x11
1015cd174:     	csel	x9, x9, x11, lo
1015cd178:     	cmp	x10, x12
1015cd17c:     	csel	x10, x10, x12, lo
1015cd180:     	tst	w8, #0x1
1015cd184:     	csel	x9, x9, x11, ne
1015cd188:     	csel	x13, x10, x12, ne
1015cd18c:     	ldr	x8, [x21, #0x38]
1015cd190:     	adds	x22, x8, x20
1015cd194:     	b.hs	0x1015cd298 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x198>
1015cd198:     	ldr	x8, [x21, #0x48]
1015cd19c:     	adds	x10, x8, x22
1015cd1a0:     	b.hs	0x1015cd298 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x198>
1015cd1a4:     	ldr	x23, [x21, #0x40]
1015cd1a8:     	ldr	x8, [x21, #0x50]
1015cd1ac:     	adds	x14, x8, x23
1015cd1b0:     	b.hs	0x1015cd298 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x198>
1015cd1b4:     	cmp	x10, x9
1015cd1b8:     	b.ls	0x1015cd1d4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0xd4>
1015cd1bc:     	mov	w12, #0x6               ; =6
1015cd1c0:     	mov	w11, #0x1               ; =1
1015cd1c4:     	mov	w8, #0x6                ; =6
1015cd1c8:     	b	0x1015cd24c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x14c>
1015cd1cc:     	mov	w8, #0x0                ; =0
1015cd1d0:     	b	0x1015cd258 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x158>
1015cd1d4:     	cmp	x14, x13
1015cd1d8:     	b.ls	0x1015cd1f4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0xf4>
1015cd1dc:     	mov	w8, #0x6                ; =6
1015cd1e0:     	mov	w12, #0x5               ; =5
1015cd1e4:     	mov	w11, #0x1               ; =1
1015cd1e8:     	mov	x9, x13
1015cd1ec:     	mov	x10, x14
1015cd1f0:     	b	0x1015cd24c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x14c>
1015cd1f4:     	mov	x0, x21
1015cd1f8:     	ldr	x8, [x0, #0x70]!
1015cd1fc:     	cbz	x8, 0x1015cd21c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x11c>
1015cd200:     	add	x8, sp, #0x18
1015cd204:     	mov	x1, x20
1015cd208:     	mov	x2, #0x0                ; =0
1015cd20c:     	bl	0x1029205ac <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
1015cd210:     	ldrb	w8, [sp, #0x18]
1015cd214:     	cmp	w8, #0x8
1015cd218:     	b.ne	0x1015cd228 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x128>
1015cd21c:     	stp	x22, x23, [x21, #0x38]
1015cd220:     	mov	w8, #0x8                ; =8
1015cd224:     	b	0x1015cd24c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x14c>
1015cd228:     	ldrb	w12, [sp, #0x19]
1015cd22c:     	ldrb	w11, [sp, #0x1a]
1015cd230:     	ldur	w9, [sp, #0x1b]
1015cd234:     	str	w9, [sp, #0x10]
1015cd238:     	ldrb	w9, [sp, #0x1f]
1015cd23c:     	strb	w9, [sp, #0x14]
1015cd240:     	ldp	x10, x9, [sp, #0x20]
1015cd244:     	ldur	q0, [sp, #0x30]
1015cd248:     	str	q0, [sp]
1015cd24c:     	ldr	x13, [x21, #0x10]
1015cd250:     	add	x13, x13, #0x1
1015cd254:     	str	x13, [x21, #0x10]
1015cd258:     	strb	w8, [x19]
1015cd25c:     	strb	w12, [x19, #0x1]
1015cd260:     	strb	w11, [x19, #0x2]
1015cd264:     	ldr	w8, [sp, #0x10]
1015cd268:     	stur	w8, [x19, #0x3]
1015cd26c:     	ldrb	w8, [sp, #0x14]
1015cd270:     	strb	w8, [x19, #0x7]
1015cd274:     	stp	x10, x9, [x19, #0x8]
1015cd278:     	ldr	q0, [sp]
1015cd27c:     	stur	q0, [x19, #0x18]
1015cd280:     	ldp	x29, x30, [sp, #0x70]
1015cd284:     	ldp	x20, x19, [sp, #0x60]
1015cd288:     	ldp	x22, x21, [sp, #0x50]
1015cd28c:     	ldp	x24, x23, [sp, #0x40]
1015cd290:     	add	sp, sp, #0x80
1015cd294:     	ret
1015cd298:     	mov	w8, #0x2                ; =2
1015cd29c:     	mov	w11, #0x1               ; =1
1015cd2a0:     	b	0x1015cd224 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCNvMs0_BW_NtBW_23NativeLibraryWorkBudget25charge_compute_with_limits0_0INtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEECs7fdMCt8k5K6_8mech_gpu+0x124>
1015cd2a4:     	adrp	x0, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015cd2a8:     	add	x0, x0, #0xc28
1015cd2ac:     	bl	0x103a07930 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1015cd2b0:     	adrp	x0, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015cd2b4:     	add	x0, x0, #0xc40
1015cd2b8:     	bl	0x103a07900 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1015cd2bc:     	adrp	x0, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015cd2c0:     	add	x0, x0, #0x808
1015cd2c4:     	bl	0x103a0727c <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
1015cd2c8:     	ldr	x8, [x21, #0x10]
1015cd2cc:     	add	x8, x8, #0x1
1015cd2d0:     	str	x8, [x21, #0x10]
1015cd2d4:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
