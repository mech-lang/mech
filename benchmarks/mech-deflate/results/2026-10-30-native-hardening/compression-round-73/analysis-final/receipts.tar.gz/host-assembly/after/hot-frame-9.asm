
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015c96f8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>:
1015c96f8:     	stp	x28, x27, [sp, #-0x60]!
1015c96fc:     	stp	x26, x25, [sp, #0x10]
1015c9700:     	stp	x24, x23, [sp, #0x20]
1015c9704:     	stp	x22, x21, [sp, #0x30]
1015c9708:     	stp	x20, x19, [sp, #0x40]
1015c970c:     	stp	x29, x30, [sp, #0x50]
1015c9710:     	add	x29, sp, #0x50
1015c9714:     	sub	sp, sp, #0x610
1015c9718:     	str	xzr, [sp]
1015c971c:     	mov	x23, x1
1015c9720:     	mov	x20, x8
1015c9724:     	ldr	x8, [x0]
1015c9728:     	mov	x0, #0x0                ; =0
1015c972c:     	blr	x8
1015c9730:     	cbz	x0, 0x1015ca1dc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xae4>
1015c9734:     	mov	x19, x0
1015c9738:     	mov	x8, x0
1015c973c:     	ldr	x9, [x8, #0x20]!
1015c9740:     	cbnz	x9, 0x1015ca168 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa70>
1015c9744:     	ldp	x0, x21, [x23]
1015c9748:     	ldp	x28, x24, [x23, #0x10]
1015c974c:     	ldp	x26, x22, [x23, #0x20]
1015c9750:     	ldp	x27, x16, [x23, #0x38]
1015c9754:     	ldp	x17, x14, [x23, #0x48]
1015c9758:     	ldp	x9, x25, [x23, #0x58]
1015c975c:     	str	x9, [sp, #0x70]
1015c9760:     	ldp	x9, x11, [x23, #0x68]
1015c9764:     	str	x9, [sp, #0x60]
1015c9768:     	ldp	x12, x1, [x23, #0x78]
1015c976c:     	ldp	x13, x15, [x23, #0x88]
1015c9770:     	mov	x9, #-0x1               ; =-1
1015c9774:     	str	x9, [x19, #0x20]
1015c9778:     	ldr	x10, [x19, #0x28]
1015c977c:     	ldr	x9, [x0]
1015c9780:     	cbz	x10, 0x1015c979c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
1015c9784:     	cmp	x10, x9
1015c9788:     	b.eq	0x1015c979c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
1015c978c:     	mov	x9, #0x0                ; =0
1015c9790:     	str	xzr, [x8]
1015c9794:     	mov	w26, #0x2f              ; =47
1015c9798:     	b	0x1015c9bc0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4c8>
1015c979c:     	ldr	x10, [x9]
1015c97a0:     	adds	x10, x10, #0x1
1015c97a4:     	str	x10, [x9]
1015c97a8:     	b.hs	0x1015ca214 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
1015c97ac:     	str	x11, [sp, #0x10]
1015c97b0:     	ldp	x11, x10, [x19, #0x20]
1015c97b4:     	add	x11, x11, #0x1
1015c97b8:     	stp	x11, x9, [x19, #0x20]
1015c97bc:     	stp	x8, x10, [sp, #0x88]
1015c97c0:     	ldr	x23, [x0]
1015c97c4:     	ldr	x8, [x23]
1015c97c8:     	adds	x8, x8, #0x1
1015c97cc:     	str	x8, [x23]
1015c97d0:     	b.hs	0x1015ca214 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
1015c97d4:     	stp	xzr, xzr, [sp, #0xd8]
1015c97d8:     	str	x23, [sp, #0xd0]
1015c97dc:     	ldr	x8, [x19]
1015c97e0:     	cbnz	x8, 0x1015ca1ac <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xab4>
1015c97e4:     	stp	x13, x1, [sp, #0x38]
1015c97e8:     	stp	x17, x14, [sp, #0x18]
1015c97ec:     	stp	x16, x15, [sp, #0x28]
1015c97f0:     	str	x12, [sp, #0x8]
1015c97f4:     	ldur	q0, [x19, #0x8]
1015c97f8:     	ldr	x8, [x19, #0x18]
1015c97fc:     	str	x8, [sp, #0xb0]
1015c9800:     	stur	q0, [sp, #0xa0]
1015c9804:     	ldr	q0, [sp, #0xd0]
1015c9808:     	ldr	x8, [sp, #0xe0]
1015c980c:     	str	x8, [x19, #0x18]
1015c9810:     	stur	q0, [x19, #0x8]
1015c9814:     	str	x19, [sp, #0x98]
1015c9818:     	bl	0x102369f74 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
1015c981c:     	ldp	x12, x9, [x19, #0x30]
1015c9820:     	ldr	x11, [x19, #0x40]
1015c9824:     	ldr	x8, [x21]
1015c9828:     	adds	x8, x0, x8
1015c982c:     	csinv	x8, x8, xzr, lo
1015c9830:     	cmp	x9, x8
1015c9834:     	stp	x11, x9, [sp, #0x48]
1015c9838:     	csel	x9, x9, x8, lo
1015c983c:     	ldr	x10, [x28]
1015c9840:     	adds	x10, x1, x10
1015c9844:     	csinv	x10, x10, xzr, lo
1015c9848:     	cmp	x11, x10
1015c984c:     	csel	x11, x11, x10, lo
1015c9850:     	str	x12, [sp, #0x58]
1015c9854:     	tst	w12, #0x1
1015c9858:     	csel	x8, x9, x8, ne
1015c985c:     	csel	x9, x11, x10, ne
1015c9860:     	mov	w10, #0x1               ; =1
1015c9864:     	stp	x10, x8, [x19, #0x30]
1015c9868:     	str	x9, [x19, #0x40]
1015c986c:     	add	x8, sp, #0xb8
1015c9870:     	mov	x0, x24
1015c9874:     	bl	0x1023696e8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015c9878:     	add	x23, sp, #0x320
1015c987c:     	add	x28, sp, #0x230
1015c9880:     	ldp	q0, q1, [x26, #0x80]
1015c9884:     	stp	q0, q1, [x28, #0x80]
1015c9888:     	ldr	x8, [x26, #0xa0]
1015c988c:     	str	x8, [sp, #0x2d0]
1015c9890:     	ldp	q0, q1, [x26, #0x40]
1015c9894:     	stp	q0, q1, [x28, #0x40]
1015c9898:     	ldp	q1, q0, [x26, #0x60]
1015c989c:     	stp	q1, q0, [x28, #0x60]
1015c98a0:     	ldp	q0, q1, [x26]
1015c98a4:     	stp	q0, q1, [x28]
1015c98a8:     	ldp	q1, q0, [x26, #0x20]
1015c98ac:     	stp	q1, q0, [x28, #0x20]
1015c98b0:     	ldr	q0, [x22, #0x30]
1015c98b4:     	str	q0, [x28, #0x120]
1015c98b8:     	ldr	q0, [x22, #0x40]
1015c98bc:     	str	q0, [x28, #0x130]
1015c98c0:     	ldr	q0, [x22, #0x50]
1015c98c4:     	str	q0, [x28, #0x140]
1015c98c8:     	ldr	x8, [x22, #0x60]
1015c98cc:     	str	x8, [sp, #0x380]
1015c98d0:     	ldr	q0, [x22]
1015c98d4:     	str	q0, [x28, #0xf0]
1015c98d8:     	ldr	q0, [x22, #0x10]
1015c98dc:     	str	q0, [x28, #0x100]
1015c98e0:     	ldr	q0, [x22, #0x20]
1015c98e4:     	str	q0, [x28, #0x110]
1015c98e8:     	ldr	q0, [x26, #0x70]
1015c98ec:     	str	q0, [x23, #0x1a0]
1015c98f0:     	ldr	q0, [x26, #0x80]
1015c98f4:     	str	q0, [x23, #0x1b0]
1015c98f8:     	ldr	q0, [x26, #0x90]
1015c98fc:     	str	q0, [x23, #0x1c0]
1015c9900:     	ldr	x8, [x26, #0xa0]
1015c9904:     	str	x8, [sp, #0x4f0]
1015c9908:     	ldr	q0, [x26, #0x30]
1015c990c:     	str	q0, [x23, #0x160]
1015c9910:     	ldr	q0, [x26, #0x40]
1015c9914:     	str	q0, [x23, #0x170]
1015c9918:     	ldr	q0, [x26, #0x50]
1015c991c:     	str	q0, [x23, #0x180]
1015c9920:     	ldr	q0, [x26, #0x60]
1015c9924:     	str	q0, [x23, #0x190]
1015c9928:     	ldr	q0, [x26]
1015c992c:     	str	q0, [x23, #0x130]
1015c9930:     	ldr	q0, [x26, #0x10]
1015c9934:     	str	q0, [x23, #0x140]
1015c9938:     	ldr	q0, [x26, #0x20]
1015c993c:     	str	q0, [x23, #0x150]
1015c9940:     	add	x8, sp, #0xd0
1015c9944:     	add	x1, sp, #0x450
1015c9948:     	add	x2, sp, #0x320
1015c994c:     	mov	x0, x24
1015c9950:     	bl	0x102368e00 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext3new>
1015c9954:     	ldr	x25, [x25]
1015c9958:     	lsr	x8, x25, #61
1015c995c:     	cbnz	x8, 0x1015ca1bc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xac4>
1015c9960:     	lsl	x26, x25, #3
1015c9964:     	mov	w8, #0x2c               ; =44
1015c9968:     	strb	w8, [sp, #0x450]
1015c996c:     	add	x0, sp, #0x450
1015c9970:     	bl	0x1015d6d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015c9974:     	add	x8, sp, #0x320
1015c9978:     	add	x0, sp, #0xd0
1015c997c:     	mov	x1, x26
1015c9980:     	mov	x2, #0x0                ; =0
1015c9984:     	bl	0x1023690cc <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
1015c9988:     	ldrb	w8, [sp, #0x320]
1015c998c:     	cmp	w8, #0x8
1015c9990:     	b.ne	0x1015c9a74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x37c>
1015c9994:     	add	x8, sp, #0x450
1015c9998:     	add	x0, sp, #0xd0
1015c999c:     	add	x2, x27, #0x8
1015c99a0:     	mov	x1, x25
1015c99a4:     	bl	0x102368b98 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext14check_capacity>
1015c99a8:     	add	x21, sp, #0x450
1015c99ac:     	ldrb	w8, [sp, #0x450]
1015c99b0:     	cmp	w8, #0x8
1015c99b4:     	b.ne	0x1015c9a8c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x394>
1015c99b8:     	add	x8, sp, #0x450
1015c99bc:     	add	x0, sp, #0xb8
1015c99c0:     	mov	x1, x25
1015c99c4:     	bl	0x102d56530 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1015c99c8:     	ldr	w25, [sp, #0x450]
1015c99cc:     	cmp	w25, #0x1a
1015c99d0:     	b.ne	0x1015c9c04 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x50c>
1015c99d4:     	ldur	q0, [x21, #0x8]
1015c99d8:     	ldur	q1, [x21, #0x18]
1015c99dc:     	stp	q0, q1, [x28, #0xb0]
1015c99e0:     	add	x8, sp, #0x450
1015c99e4:     	add	x0, sp, #0xb8
1015c99e8:     	add	x1, x27, #0x8
1015c99ec:     	bl	0x102d56404 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
1015c99f0:     	ldr	w25, [sp, #0x450]
1015c99f4:     	cmp	w25, #0x1a
1015c99f8:     	ldr	x8, [sp, #0x40]
1015c99fc:     	b.ne	0x1015c9c28 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x530>
1015c9a00:     	ldur	q0, [x21, #0x8]
1015c9a04:     	ldur	q1, [x21, #0x18]
1015c9a08:     	stp	q0, q1, [x28, #0xd0]
1015c9a0c:     	ldr	x1, [x8]
1015c9a10:     	cbz	x1, 0x1015c9a38 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x340>
1015c9a14:     	ldr	x2, [x8, #0x8]
1015c9a18:     	add	x8, sp, #0x450
1015c9a1c:     	add	x3, sp, #0xb8
1015c9a20:     	add	x4, sp, #0xd0
1015c9a24:     	ldr	x0, [sp, #0x38]
1015c9a28:     	bl	0x1027c8e0c <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB6_25NativePreparedLibraryCall23admit_composed_selector>
1015c9a2c:     	ldrb	w26, [sp, #0x450]
1015c9a30:     	cmp	w26, #0x2e
1015c9a34:     	b.ne	0x1015ca024 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x92c>
1015c9a38:     	add	x8, sp, #0x450
1015c9a3c:     	add	x1, sp, #0x230
1015c9a40:     	mov	x0, x24
1015c9a44:     	bl	0x1023700c8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter21for_native_projection>
1015c9a48:     	ldr	x9, [sp, #0x450]
1015c9a4c:     	ldr	x8, [sp, #0x458]
1015c9a50:     	ldp	q2, q3, [x21, #0x10]
1015c9a54:     	cmp	x9, #0x2
1015c9a58:     	b.ne	0x1015c9c4c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x554>
1015c9a5c:     	stp	q3, q2, [sp, #0x60]
1015c9a60:     	and	w25, w8, #0xff
1015c9a64:     	lsr	w21, w8, #8
1015c9a68:     	lsr	x22, x8, #32
1015c9a6c:     	mov	w26, #0x29              ; =41
1015c9a70:     	b	0x1015ca06c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015c9a74:     	ldr	w22, [sp, #0x324]
1015c9a78:     	ldr	w8, [sp, #0x320]
1015c9a7c:     	ldur	q0, [x23, #0x18]
1015c9a80:     	str	q0, [sp, #0x60]
1015c9a84:     	ldur	q0, [x23, #0x8]
1015c9a88:     	b	0x1015c9aa0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3a8>
1015c9a8c:     	ldr	w22, [sp, #0x454]
1015c9a90:     	ldr	w8, [sp, #0x450]
1015c9a94:     	ldur	q0, [x21, #0x18]
1015c9a98:     	str	q0, [sp, #0x60]
1015c9a9c:     	ldur	q0, [x21, #0x8]
1015c9aa0:     	str	q0, [sp, #0x70]
1015c9aa4:     	and	w25, w8, #0xff
1015c9aa8:     	lsr	w21, w8, #8
1015c9aac:     	mov	w26, #0x29              ; =41
1015c9ab0:     	ldr	w8, [sp, #0x200]
1015c9ab4:     	cmp	w8, #0x1a
1015c9ab8:     	b.eq	0x1015c9b0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
1015c9abc:     	cmp	w8, #0xa
1015c9ac0:     	b.eq	0x1015c9adc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3e4>
1015c9ac4:     	cmp	w8, #0x13
1015c9ac8:     	b.ne	0x1015c9b0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
1015c9acc:     	ldr	x1, [sp, #0x210]
1015c9ad0:     	mov	w8, #0x10               ; =16
1015c9ad4:     	cbnz	x1, 0x1015c9af4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3fc>
1015c9ad8:     	b	0x1015c9b0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
1015c9adc:     	ldr	x1, [sp, #0x218]
1015c9ae0:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1015c9ae4:     	cmp	x1, x8
1015c9ae8:     	b.eq	0x1015c9b0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
1015c9aec:     	mov	w8, #0x18               ; =24
1015c9af0:     	cbz	x1, 0x1015c9b0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
1015c9af4:     	add	x9, sp, #0xd0
1015c9af8:     	add	x9, x9, #0x130
1015c9afc:     	add	x8, x9, x8
1015c9b00:     	ldr	x0, [x8, #0x8]
1015c9b04:     	mov	w2, #0x1                ; =1
1015c9b08:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015c9b0c:     	ldr	x8, [sp, #0xb8]
1015c9b10:     	mov	x9, #-0x1               ; =-1
1015c9b14:     	ldaddl	x9, x8, [x8]
1015c9b18:     	cmp	x8, #0x1
1015c9b1c:     	b.ne	0x1015c9b2c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
1015c9b20:     	dmb	ishld
1015c9b24:     	add	x0, sp, #0xb8
1015c9b28:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015c9b2c:     	add	x27, sp, #0x98
1015c9b30:     	ldur	w8, [x29, #-0xe0]
1015c9b34:     	str	w8, [sp, #0xd0]
1015c9b38:     	ldurh	w8, [x29, #-0xdc]
1015c9b3c:     	strh	w8, [sp, #0xd4]
1015c9b40:     	ldp	x8, x9, [sp, #0x50]
1015c9b44:     	stp	x9, x8, [x19, #0x30]
1015c9b48:     	ldr	x8, [sp, #0x48]
1015c9b4c:     	str	x8, [x19, #0x40]
1015c9b50:     	add	x0, sp, #0x98
1015c9b54:     	bl	0x1023ad060 <__RNvXs_NvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBa_23NativeLibraryWorkBudget16with_call_limitsNtB4_10ScopeGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
1015c9b58:     	ldr	x8, [sp, #0xa0]
1015c9b5c:     	cbz	x8, 0x1015c9b78 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
1015c9b60:     	ldr	x9, [x8]
1015c9b64:     	subs	x9, x9, #0x1
1015c9b68:     	str	x9, [x8]
1015c9b6c:     	b.ne	0x1015c9b78 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
1015c9b70:     	add	x0, x27, #0x8
1015c9b74:     	bl	0x10236cb9c <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1015c9b78:     	add	x19, sp, #0x88
1015c9b7c:     	add	x0, sp, #0x88
1015c9b80:     	bl	0x10239282c <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
1015c9b84:     	and	x27, x21, #0xffffff
1015c9b88:     	mov	w21, w22
1015c9b8c:     	ldr	x8, [sp, #0x90]
1015c9b90:     	cbz	x8, 0x1015c9bac <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
1015c9b94:     	ldr	x9, [x8]
1015c9b98:     	subs	x9, x9, #0x1
1015c9b9c:     	str	x9, [x8]
1015c9ba0:     	b.ne	0x1015c9bac <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
1015c9ba4:     	add	x0, x19, #0x8
1015c9ba8:     	bl	0x10236cb9c <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1015c9bac:     	lsl	x8, x27, #8
1015c9bb0:     	orr	x8, x8, x21, lsl #32
1015c9bb4:     	mov	w9, w25
1015c9bb8:     	orr	x9, x8, x9
1015c9bbc:     	ldp	q1, q0, [sp, #0x60]
1015c9bc0:     	ldr	w8, [sp, #0xd0]
1015c9bc4:     	stur	w8, [x20, #0x2]
1015c9bc8:     	ldrh	w8, [sp, #0xd4]
1015c9bcc:     	strh	w8, [x20, #0x6]
1015c9bd0:     	strb	w26, [x20]
1015c9bd4:     	strb	w23, [x20, #0x1]
1015c9bd8:     	str	x9, [x20, #0x8]
1015c9bdc:     	stp	q0, q1, [x20, #0x10]
1015c9be0:     	str	x24, [x20, #0x30]
1015c9be4:     	add	sp, sp, #0x610
1015c9be8:     	ldp	x29, x30, [sp, #0x50]
1015c9bec:     	ldp	x20, x19, [sp, #0x40]
1015c9bf0:     	ldp	x22, x21, [sp, #0x30]
1015c9bf4:     	ldp	x24, x23, [sp, #0x20]
1015c9bf8:     	ldp	x26, x25, [sp, #0x10]
1015c9bfc:     	ldp	x28, x27, [sp], #0x60
1015c9c00:     	ret
1015c9c04:     	add	x8, sp, #0x450
1015c9c08:     	mov	w21, #0x0               ; =0
1015c9c0c:     	ldr	w22, [sp, #0x454]
1015c9c10:     	ldur	q1, [x8, #0x18]
1015c9c14:     	ldur	q0, [x8, #0x8]
1015c9c18:     	stp	q1, q0, [sp, #0x60]
1015c9c1c:     	mov	w26, #0x2b              ; =43
1015c9c20:     	ldr	x24, [sp, #0x478]
1015c9c24:     	b	0x1015c9ab0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
1015c9c28:     	add	x8, sp, #0x450
1015c9c2c:     	mov	w21, #0x0               ; =0
1015c9c30:     	ldr	w22, [sp, #0x454]
1015c9c34:     	ldur	q1, [x8, #0x18]
1015c9c38:     	ldur	q0, [x8, #0x8]
1015c9c3c:     	stp	q1, q0, [sp, #0x60]
1015c9c40:     	mov	w26, #0x2b              ; =43
1015c9c44:     	ldr	x24, [sp, #0x478]
1015c9c48:     	b	0x1015ca094 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x99c>
1015c9c4c:     	ldp	q0, q1, [x21, #0xf0]
1015c9c50:     	stp	q0, q1, [x28, #0x1e0]
1015c9c54:     	ldp	q0, q1, [x21, #0x110]
1015c9c58:     	stp	q0, q1, [x28, #0x200]
1015c9c5c:     	ldp	q0, q1, [x21, #0xb0]
1015c9c60:     	stp	q0, q1, [x28, #0x1a0]
1015c9c64:     	ldp	q0, q1, [x21, #0xd0]
1015c9c68:     	stp	q0, q1, [x28, #0x1c0]
1015c9c6c:     	ldp	q0, q1, [x21, #0x70]
1015c9c70:     	stp	q0, q1, [x28, #0x160]
1015c9c74:     	ldp	q0, q1, [x21, #0x90]
1015c9c78:     	stp	q0, q1, [x28, #0x180]
1015c9c7c:     	ldp	q0, q1, [x21, #0x30]
1015c9c80:     	stp	q0, q1, [x28, #0x120]
1015c9c84:     	ldp	q0, q1, [x21, #0x50]
1015c9c88:     	stp	q0, q1, [x28, #0x140]
1015c9c8c:     	stp	q2, q3, [x28, #0x100]
1015c9c90:     	str	x8, [sp, #0x328]
1015c9c94:     	str	x9, [sp, #0x320]
1015c9c98:     	ldr	x10, [sp, #0x70]
1015c9c9c:     	ldr	x1, [x10]
1015c9ca0:     	cbz	x1, 0x1015c9d08 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
1015c9ca4:     	ldp	x9, x8, [sp, #0x30]
1015c9ca8:     	ldr	x8, [x8, #0x190]
1015c9cac:     	ldr	q0, [x9]
1015c9cb0:     	str	q0, [x21]
1015c9cb4:     	ldr	q0, [x9, #0x10]
1015c9cb8:     	str	q0, [x21, #0x10]
1015c9cbc:     	ldr	q0, [x9, #0x20]
1015c9cc0:     	str	q0, [x21, #0x20]
1015c9cc4:     	ldr	x9, [x9, #0x30]
1015c9cc8:     	str	x9, [sp, #0x480]
1015c9ccc:     	ldr	x2, [x10, #0x8]
1015c9cd0:     	sub	x0, x29, #0xe0
1015c9cd4:     	add	x3, x8, #0x10
1015c9cd8:     	add	x4, sp, #0x450
1015c9cdc:     	add	x5, sp, #0xb8
1015c9ce0:     	add	x6, sp, #0x320
1015c9ce4:     	bl	0x1015c3910 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>
1015c9ce8:     	ldurb	w25, [x29, #-0xe0]
1015c9cec:     	cmp	w25, #0x8
1015c9cf0:     	b.ne	0x1015c9f6c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x874>
1015c9cf4:     	ldur	x8, [x29, #-0xd8]
1015c9cf8:     	cbz	x8, 0x1015c9d08 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
1015c9cfc:     	ldur	x22, [x29, #-0xd0]
1015c9d00:     	ldr	x11, [sp, #0x30]
1015c9d04:     	b	0x1015c9f9c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
1015c9d08:     	ldr	x11, [sp, #0x30]
1015c9d0c:     	ldr	x8, [sp, #0x18]
1015c9d10:     	cbz	x8, 0x1015c9f98 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a0>
1015c9d14:     	mov	x21, #0x0               ; =0
1015c9d18:     	mov	x22, #0x0               ; =0
1015c9d1c:     	mov	x24, #0x0               ; =0
1015c9d20:     	adrp	x9, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015c9d24:     	add	x9, x9, #0xa60
1015c9d28:     	str	x9, [sp, #0x40]
1015c9d2c:     	lsl	x28, x8, #2
1015c9d30:     	mov	w27, #0x2c              ; =44
1015c9d34:     	ldr	x1, [x11, #0x8]
1015c9d38:     	cmp	x24, x1
1015c9d3c:     	b.hs	0x1015ca208 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb10>
1015c9d40:     	ldr	x8, [x11]
1015c9d44:     	add	x8, x8, x21
1015c9d48:     	ldrb	w9, [x8]
1015c9d4c:     	cmp	w9, #0x3
1015c9d50:     	str	x22, [sp, #0x70]
1015c9d54:     	b.ne	0x1015c9d98 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6a0>
1015c9d58:     	ldr	x8, [x8, #0x8]
1015c9d5c:     	ldr	x1, [x11, #0x18]
1015c9d60:     	cmp	x8, x1
1015c9d64:     	b.hs	0x1015ca1e8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xaf0>
1015c9d68:     	ldr	x1, [x11, #0x28]
1015c9d6c:     	cmp	x8, x1
1015c9d70:     	b.hs	0x1015ca1f8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb00>
1015c9d74:     	ldr	x9, [x11, #0x10]
1015c9d78:     	add	x9, x9, x8, lsl #6
1015c9d7c:     	ldr	x10, [x9]
1015c9d80:     	cmp	x10, #0x0
1015c9d84:     	csel	x26, xzr, x9, eq
1015c9d88:     	ldr	x9, [x11, #0x20]
1015c9d8c:     	ldr	x25, [x9, x8, lsl #3]
1015c9d90:     	strb	w27, [sp, #0x450]
1015c9d94:     	b	0x1015c9dd8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6e0>
1015c9d98:     	ldr	q0, [x8]
1015c9d9c:     	add	x9, sp, #0x450
1015c9da0:     	str	q0, [x9]
1015c9da4:     	ldr	q0, [x8, #0x10]
1015c9da8:     	str	q0, [x9, #0x10]
1015c9dac:     	ldr	x8, [x11, #0x30]
1015c9db0:     	ldr	x8, [x8]
1015c9db4:     	ldr	x1, [x8]
1015c9db8:     	sub	x0, x29, #0xe0
1015c9dbc:     	add	x2, sp, #0x450
1015c9dc0:     	bl	0x1015dd604 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1015c9dc4:     	ldur	x8, [x29, #-0xe0]
1015c9dc8:     	strb	w27, [sp, #0x450]
1015c9dcc:     	cmp	x8, #0x1
1015c9dd0:     	b.ne	0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9dd4:     	ldp	x26, x25, [x29, #-0xd8]
1015c9dd8:     	add	x0, sp, #0x450
1015c9ddc:     	bl	0x1015d6d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015c9de0:     	ldr	x8, [sp, #0x38]
1015c9de4:     	ldr	x23, [x8, #0x190]
1015c9de8:     	ldr	x8, [sp, #0x28]
1015c9dec:     	ldr	w22, [x8, x24, lsl #2]
1015c9df0:     	ldr	x8, [x23, #0x28]
1015c9df4:     	cmp	x8, x22
1015c9df8:     	b.ls	0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9dfc:     	ldr	x8, [x23, #0x20]
1015c9e00:     	mov	w9, #0x2c               ; =44
1015c9e04:     	add	x27, x8, x22, lsl #7
1015c9e08:     	strb	w9, [sp, #0x450]
1015c9e0c:     	add	x0, sp, #0x450
1015c9e10:     	bl	0x1015d6d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015c9e14:     	cbz	x26, 0x1015c9ebc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x7c4>
1015c9e18:     	cbnz	x25, 0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9e1c:     	ldr	w8, [x26, #0x38]
1015c9e20:     	cmp	w8, w22
1015c9e24:     	b.ne	0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9e28:     	ldp	q1, q0, [x26, #0x10]
1015c9e2c:     	add	x8, sp, #0x450
1015c9e30:     	stp	q1, q0, [x8, #0x130]
1015c9e34:     	ldur	q0, [x27, #0x70]
1015c9e38:     	str	q0, [x8]
1015c9e3c:     	ldur	q0, [x27, #0x80]
1015c9e40:     	str	q0, [x8, #0x10]
1015c9e44:     	ldp	x8, x9, [x29, #-0xe0]
1015c9e48:     	ldr	x10, [sp, #0x450]
1015c9e4c:     	ldr	x11, [sp, #0x458]
1015c9e50:     	ldp	x12, x13, [x29, #-0xd0]
1015c9e54:     	ldr	x14, [sp, #0x460]
1015c9e58:     	ldr	x15, [sp, #0x468]
1015c9e5c:     	cmp	x8, x10
1015c9e60:     	ccmp	x9, x11, #0x0, eq
1015c9e64:     	ccmp	x12, x14, #0x0, eq
1015c9e68:     	ccmp	x13, x15, #0x0, eq
1015c9e6c:     	b.ne	0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9e70:     	add	x1, sp, #0xb8
1015c9e74:     	mov	x0, x26
1015c9e78:     	bl	0x102e16620 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
1015c9e7c:     	mov	w27, #0x2c              ; =44
1015c9e80:     	cmp	x0, #0x1
1015c9e84:     	b.ne	0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9e88:     	sub	x8, x29, #0xb8
1015c9e8c:     	add	x1, x23, #0x10
1015c9e90:     	mov	x0, x26
1015c9e94:     	bl	0x102e14704 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
1015c9e98:     	ldurb	w8, [x29, #-0xb8]
1015c9e9c:     	cmp	w8, #0x16
1015c9ea0:     	b.ne	0x1015ca1c8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad0>
1015c9ea4:     	add	x8, sp, #0x450
1015c9ea8:     	add	x0, sp, #0x320
1015c9eac:     	add	x2, x23, #0x10
1015c9eb0:     	mov	x1, x26
1015c9eb4:     	bl	0x102380cd0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget42measure_borrowed_canonical_value_footprint>
1015c9eb8:     	b	0x1015c9f2c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x834>
1015c9ebc:     	ldur	x8, [x27, #0x58]
1015c9ec0:     	cbnz	x8, 0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9ec4:     	ldurh	w1, [x27, #0x12]
1015c9ec8:     	ldurb	w0, [x27, #0x10]
1015c9ecc:     	bl	0x1015db0d8 <__RNvMNtCs1qJAwyMG1lC_11mech_engine13native_scalarNtB2_16NativeScalarKind16from_schema_body>
1015c9ed0:     	and	w26, w0, #0xff
1015c9ed4:     	mov	w22, #0x2c              ; =44
1015c9ed8:     	strb	w22, [sp, #0x450]
1015c9edc:     	cmp	w26, #0x7
1015c9ee0:     	b.eq	0x1015ca1d0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad8>
1015c9ee4:     	add	x0, sp, #0x450
1015c9ee8:     	bl	0x1015d6d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015c9eec:     	sub	x0, x29, #0x70
1015c9ef0:     	mov	x1, x26
1015c9ef4:     	mov	x2, x25
1015c9ef8:     	bl	0x1015db148 <__RNvMNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact2irNtB2_17NativeScalarValue9from_bits>
1015c9efc:     	strb	w22, [sp, #0x450]
1015c9f00:     	ldurb	w8, [x29, #-0x70]
1015c9f04:     	cmp	w8, #0x7
1015c9f08:     	b.eq	0x1015ca1d0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad8>
1015c9f0c:     	add	x0, sp, #0x450
1015c9f10:     	bl	0x1015d6d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015c9f14:     	add	x8, sp, #0x450
1015c9f18:     	add	x0, sp, #0x320
1015c9f1c:     	add	x1, x27, #0x10
1015c9f20:     	sub	x2, x29, #0x70
1015c9f24:     	bl	0x1023801d8 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget37measure_native_scalar_frame_footprint>
1015c9f28:     	mov	w27, #0x2c              ; =44
1015c9f2c:     	ldrb	w25, [sp, #0x450]
1015c9f30:     	cmp	w25, #0x8
1015c9f34:     	b.ne	0x1015ca188 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa90>
1015c9f38:     	ldr	x8, [sp, #0x460]
1015c9f3c:     	ldr	x22, [sp, #0x70]
1015c9f40:     	adds	x22, x8, x22
1015c9f44:     	b.hs	0x1015ca05c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x964>
1015c9f48:     	strb	w27, [sp, #0x450]
1015c9f4c:     	add	x0, sp, #0x450
1015c9f50:     	bl	0x1015d6d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015c9f54:     	add	x21, x21, #0x20
1015c9f58:     	add	x24, x24, #0x1
1015c9f5c:     	subs	x28, x28, #0x4
1015c9f60:     	ldr	x11, [sp, #0x30]
1015c9f64:     	b.ne	0x1015c9d34 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x63c>
1015c9f68:     	b	0x1015c9f9c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
1015c9f6c:     	sub	x8, x29, #0xe0
1015c9f70:     	ldurb	w9, [x29, #-0xdd]
1015c9f74:     	ldurh	w10, [x8, #0x1]
1015c9f78:     	orr	w21, w10, w9, lsl #16
1015c9f7c:     	ldur	w22, [x29, #-0xdc]
1015c9f80:     	ldur	q0, [x8, #0x18]
1015c9f84:     	str	q0, [sp, #0x60]
1015c9f88:     	ldur	q0, [x8, #0x8]
1015c9f8c:     	str	q0, [sp, #0x70]
1015c9f90:     	mov	w26, #0x29              ; =41
1015c9f94:     	b	0x1015ca06c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015c9f98:     	mov	x22, #0x0               ; =0
1015c9f9c:     	ldr	x0, [sp, #0x20]
1015c9fa0:     	mov	x1, x11
1015c9fa4:     	bl	0x1014c8b58 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_>
1015c9fa8:     	add	x21, sp, #0x450
1015c9fac:     	tbnz	w0, #0x0, 0x1015c9fd4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8dc>
1015c9fb0:     	ldp	x2, x8, [sp, #0x30]
1015c9fb4:     	ldr	x9, [x8, #0x190]
1015c9fb8:     	add	x8, sp, #0x450
1015c9fbc:     	add	x1, x9, #0x10
1015c9fc0:     	ldr	x0, [sp, #0x20]
1015c9fc4:     	bl	0x1014c8df4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions5_0Es_0s0_0EB41_>
1015c9fc8:     	ldrb	w26, [sp, #0x450]
1015c9fcc:     	cmp	w26, #0x2e
1015c9fd0:     	b.ne	0x1015ca024 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x92c>
1015c9fd4:     	ldr	x8, [sp, #0x60]
1015c9fd8:     	ldr	x8, [x8]
1015c9fdc:     	subs	x8, x22, x8
1015c9fe0:     	ldr	x11, [sp, #0x38]
1015c9fe4:     	add	x12, sp, #0x450
1015c9fe8:     	b.lo	0x1015ca004 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x90c>
1015c9fec:     	ldr	x9, [sp, #0x10]
1015c9ff0:     	ldr	x9, [x9]
1015c9ff4:     	mov	w10, #0x2c              ; =44
1015c9ff8:     	strb	w10, [sp, #0x450]
1015c9ffc:     	adds	x22, x9, x8
1015ca000:     	b.lo	0x1015ca0c0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x9c8>
1015ca004:     	mov	w21, #0x0               ; =0
1015ca008:     	mov	w25, #0x0               ; =0
1015ca00c:     	mov	w22, #0x0               ; =0
1015ca010:     	ldur	w8, [x12, #0x2]
1015ca014:     	stur	w8, [x29, #-0xe0]
1015ca018:     	ldrh	w8, [sp, #0x456]
1015ca01c:     	sturh	w8, [x29, #-0xdc]
1015ca020:     	b	0x1015ca068 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
1015ca024:     	ldrb	w23, [sp, #0x451]
1015ca028:     	ldur	w8, [x21, #0x2]
1015ca02c:     	stur	w8, [x29, #-0xe0]
1015ca030:     	ldrh	w8, [sp, #0x456]
1015ca034:     	sturh	w8, [x29, #-0xdc]
1015ca038:     	ldr	w22, [sp, #0x45c]
1015ca03c:     	ldr	w8, [sp, #0x458]
1015ca040:     	and	w25, w8, #0xff
1015ca044:     	add	x9, sp, #0x450
1015ca048:     	lsr	w21, w8, #8
1015ca04c:     	ldp	q0, q1, [x9, #0x10]
1015ca050:     	stp	q1, q0, [sp, #0x60]
1015ca054:     	ldr	x24, [sp, #0x480]
1015ca058:     	b	0x1015ca06c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015ca05c:     	mov	w21, #0x0               ; =0
1015ca060:     	mov	w25, #0x0               ; =0
1015ca064:     	mov	w22, #0x0               ; =0
1015ca068:     	mov	w26, #0x2c              ; =44
1015ca06c:     	add	x0, sp, #0x300
1015ca070:     	bl	0x102d5b9bc <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_22ManagedNodeReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
1015ca074:     	ldr	x8, [sp, #0x300]
1015ca078:     	mov	x9, #-0x1               ; =-1
1015ca07c:     	ldaddl	x9, x8, [x8]
1015ca080:     	cmp	x8, #0x1
1015ca084:     	b.ne	0x1015ca094 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x99c>
1015ca088:     	dmb	ishld
1015ca08c:     	add	x0, sp, #0x300
1015ca090:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ca094:     	add	x0, sp, #0x2e0
1015ca098:     	bl	0x102d5bc8c <__RNvXs6_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
1015ca09c:     	ldr	x8, [sp, #0x2e0]
1015ca0a0:     	mov	x9, #-0x1               ; =-1
1015ca0a4:     	ldaddl	x9, x8, [x8]
1015ca0a8:     	cmp	x8, #0x1
1015ca0ac:     	b.ne	0x1015c9ab0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
1015ca0b0:     	dmb	ishld
1015ca0b4:     	add	x0, sp, #0x2e0
1015ca0b8:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ca0bc:     	b	0x1015c9ab0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
1015ca0c0:     	add	x0, sp, #0x450
1015ca0c4:     	mov	x21, x11
1015ca0c8:     	bl	0x1015d6d5c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015ca0cc:     	ldr	w8, [x21, #0x110]
1015ca0d0:     	ldr	x9, [sp, #0x8]
1015ca0d4:     	ldr	x9, [x9]
1015ca0d8:     	movi.2d	v0, #0000000000000000
1015ca0dc:     	add	x21, sp, #0x450
1015ca0e0:     	stp	q0, q0, [x21, #0x20]
1015ca0e4:     	str	q0, [x21, #0x40]
1015ca0e8:     	str	xzr, [sp, #0x4a0]
1015ca0ec:     	str	x9, [sp, #0x4a8]
1015ca0f0:     	str	wzr, [sp, #0x4b0]
1015ca0f4:     	stp	q0, q0, [x21]
1015ca0f8:     	mov	w9, #0x3                ; =3
1015ca0fc:     	orr	x1, x9, x8, lsl #32
1015ca100:     	sub	x0, x29, #0xe0
1015ca104:     	add	x2, sp, #0x450
1015ca108:     	add	x4, sp, #0x230
1015ca10c:     	mov	x3, x22
1015ca110:     	bl	0x1015d9214 <__RINvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget30visit_memory_budget_violationsNtB2_21MemoryBudgetViolationNcNtINtNtNtCsgDHHaSskbIF_4core3ops12control_flow11ControlFlowB1k_E5Break0ECs7fdMCt8k5K6_8mech_gpu>
1015ca114:     	ldurb	w8, [x29, #-0xe0]
1015ca118:     	cmp	w8, #0x8
1015ca11c:     	b.ne	0x1015ca174 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa7c>
1015ca120:     	add	x0, sp, #0x300
1015ca124:     	bl	0x1015d4cb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015ca128:     	add	x0, sp, #0x2e0
1015ca12c:     	bl	0x1015d4d2c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015ca130:     	ldr	w8, [sp, #0x200]
1015ca134:     	cmp	w8, #0x1a
1015ca138:     	b.eq	0x1015ca148 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa50>
1015ca13c:     	add	x8, sp, #0xd0
1015ca140:     	add	x0, x8, #0x130
1015ca144:     	bl	0x1015d4c64 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
1015ca148:     	mov	w25, #0x0               ; =0
1015ca14c:     	ldr	x8, [sp, #0xb8]
1015ca150:     	mov	x9, #-0x1               ; =-1
1015ca154:     	ldaddl	x9, x8, [x8]
1015ca158:     	mov	w26, #0x2e              ; =46
1015ca15c:     	cmp	x8, #0x1
1015ca160:     	b.eq	0x1015c9b20 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x428>
1015ca164:     	b	0x1015c9b2c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
1015ca168:     	adrp	x0, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015ca16c:     	add	x0, x0, #0x9d0
1015ca170:     	bl	0x103a07900 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1015ca174:     	ldp	q0, q1, [x21, #0x130]
1015ca178:     	stp	q1, q0, [sp, #0x60]
1015ca17c:     	mov	w26, #0x2a              ; =42
1015ca180:     	mov	w25, #0x12              ; =18
1015ca184:     	b	0x1015ca06c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015ca188:     	ldrb	w8, [sp, #0x453]
1015ca18c:     	add	x10, sp, #0x450
1015ca190:     	ldurh	w9, [x10, #0x1]
1015ca194:     	orr	w21, w9, w8, lsl #16
1015ca198:     	ldr	w22, [sp, #0x454]
1015ca19c:     	ldur	q0, [x10, #0x18]
1015ca1a0:     	str	q0, [sp, #0x60]
1015ca1a4:     	ldur	q0, [x10, #0x8]
1015ca1a8:     	b	0x1015c9f8c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x894>
1015ca1ac:     	adrp	x0, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015ca1b0:     	add	x0, x0, #0x9b8
1015ca1b4:     	bl	0x103a07900 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1015ca1b8:     	b	0x1015ca214 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb1c>
1015ca1bc:     	mov	w25, #0x0               ; =0
1015ca1c0:     	mov	w26, #0x2c              ; =44
1015ca1c4:     	b	0x1015c9ab0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
1015ca1c8:     	sub	x0, x29, #0xb8
1015ca1cc:     	bl	0x1015d5eec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
1015ca1d0:     	mov	w25, #0x0               ; =0
1015ca1d4:     	mov	w26, #0x2c              ; =44
1015ca1d8:     	b	0x1015ca06c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x974>
1015ca1dc:     	adrp	x0, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015ca1e0:     	add	x0, x0, #0x808
1015ca1e4:     	bl	0x103a0727c <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
1015ca1e8:     	mov	x24, x8
1015ca1ec:     	adrp	x8, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015ca1f0:     	add	x8, x8, #0xa78
1015ca1f4:     	b	0x1015ca204 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb0c>
1015ca1f8:     	mov	x24, x8
1015ca1fc:     	adrp	x8, 0x107f11000 <_anon.b6eeb41759bf5ac115aa758b9144c375.734+0x3d0>
1015ca200:     	add	x8, x8, #0xa90
1015ca204:     	str	x8, [sp, #0x40]
1015ca208:     	mov	x0, x24
1015ca20c:     	ldr	x2, [sp, #0x40]
1015ca210:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ca214:     	brk	#0x1
1015ca218:     	mov	x20, x0
1015ca21c:     	ldr	x8, [sp, #0x300]
1015ca220:     	mov	x9, #-0x1               ; =-1
1015ca224:     	ldaddl	x9, x8, [x8]
1015ca228:     	cmp	x8, #0x1
1015ca22c:     	b.ne	0x1015ca288 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
1015ca230:     	dmb	ishld
1015ca234:     	add	x0, sp, #0x300
1015ca238:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ca23c:     	b	0x1015ca288 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
1015ca240:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ca244:     	b	0x1015ca27c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb84>
1015ca248:     	mov	x20, x0
1015ca24c:     	ldr	x8, [sp, #0x2e0]
1015ca250:     	mov	x9, #-0x1               ; =-1
1015ca254:     	ldaddl	x9, x8, [x8]
1015ca258:     	cmp	x8, #0x1
1015ca25c:     	b.ne	0x1015ca310 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015ca260:     	dmb	ishld
1015ca264:     	add	x0, sp, #0x2e0
1015ca268:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ca26c:     	b	0x1015ca310 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015ca270:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ca274:     	mov	x20, x0
1015ca278:     	b	0x1015ca288 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb90>
1015ca27c:     	mov	x20, x0
1015ca280:     	add	x0, sp, #0x300
1015ca284:     	bl	0x1015d4cb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015ca288:     	add	x0, sp, #0x2e0
1015ca28c:     	bl	0x1015d4d2c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015ca290:     	b	0x1015ca310 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc18>
1015ca294:     	mov	x20, x0
1015ca298:     	b	0x1015ca384 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015ca29c:     	mov	x20, x0
1015ca2a0:     	ldr	x8, [sp, #0x90]
1015ca2a4:     	cbz	x8, 0x1015ca38c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
1015ca2a8:     	ldr	x9, [x8]
1015ca2ac:     	subs	x9, x9, #0x1
1015ca2b0:     	str	x9, [x8]
1015ca2b4:     	b.ne	0x1015ca38c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
1015ca2b8:     	add	x0, x19, #0x8
1015ca2bc:     	bl	0x10236cb9c <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1015ca2c0:     	b	0x1015ca38c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc94>
1015ca2c4:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ca2c8:     	mov	x20, x0
1015ca2cc:     	ldr	x8, [sp, #0xa0]
1015ca2d0:     	cbz	x8, 0x1015ca384 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015ca2d4:     	ldr	x9, [x8]
1015ca2d8:     	subs	x9, x9, #0x1
1015ca2dc:     	str	x9, [x8]
1015ca2e0:     	b.ne	0x1015ca384 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015ca2e4:     	add	x0, x27, #0x8
1015ca2e8:     	bl	0x10236cb9c <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1015ca2ec:     	b	0x1015ca384 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015ca2f0:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ca2f4:     	mov	x20, x0
1015ca2f8:     	b	0x1015ca328 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc30>
1015ca2fc:     	mov	x20, x0
1015ca300:     	b	0x1015ca358 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc60>
1015ca304:     	mov	x20, x0
1015ca308:     	b	0x1015ca348 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc50>
1015ca30c:     	mov	x20, x0
1015ca310:     	ldr	w8, [sp, #0x200]
1015ca314:     	cmp	w8, #0x1a
1015ca318:     	b.eq	0x1015ca328 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc30>
1015ca31c:     	add	x8, sp, #0xd0
1015ca320:     	add	x0, x8, #0x130
1015ca324:     	bl	0x1015d4c64 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
1015ca328:     	ldr	x8, [sp, #0xb8]
1015ca32c:     	mov	x9, #-0x1               ; =-1
1015ca330:     	ldaddl	x9, x8, [x8]
1015ca334:     	cmp	x8, #0x1
1015ca338:     	b.ne	0x1015ca348 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc50>
1015ca33c:     	dmb	ishld
1015ca340:     	add	x0, sp, #0xb8
1015ca344:     	bl	0x102e1c188 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ca348:     	ldp	x8, x9, [sp, #0x50]
1015ca34c:     	stp	x9, x8, [x19, #0x30]
1015ca350:     	ldr	x8, [sp, #0x48]
1015ca354:     	str	x8, [x19, #0x40]
1015ca358:     	add	x0, sp, #0x98
1015ca35c:     	bl	0x1015d9124 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits10ScopeGuardECs7fdMCt8k5K6_8mech_gpu>
1015ca360:     	b	0x1015ca384 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015ca364:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ca368:     	mov	x20, x0
1015ca36c:     	ldr	x8, [x23]
1015ca370:     	subs	x8, x8, #0x1
1015ca374:     	str	x8, [x23]
1015ca378:     	b.ne	0x1015ca384 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions0_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc8c>
1015ca37c:     	add	x0, sp, #0xd0
1015ca380:     	bl	0x10236cb9c <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1015ca384:     	add	x0, sp, #0x88
1015ca388:     	bl	0x1015d919c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits12AccountGuardECs7fdMCt8k5K6_8mech_gpu>
1015ca38c:     	mov	x0, x20
1015ca390:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
1015ca394:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ca398:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
