
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010161abd0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>:
10161abd0:     	sub	sp, sp, #0x1d0
10161abd4:     	stp	x28, x27, [sp, #0x170]
10161abd8:     	stp	x26, x25, [sp, #0x180]
10161abdc:     	stp	x24, x23, [sp, #0x190]
10161abe0:     	stp	x22, x21, [sp, #0x1a0]
10161abe4:     	stp	x20, x19, [sp, #0x1b0]
10161abe8:     	stp	x29, x30, [sp, #0x1c0]
10161abec:     	add	x29, sp, #0x1c0
10161abf0:     	mov	x25, x6
10161abf4:     	mov	x26, x4
10161abf8:     	mov	x23, x3
10161abfc:     	mov	x22, x2
10161ac00:     	mov	x24, x1
10161ac04:     	mov	x20, x0
10161ac08:     	mov	x19, x8
10161ac0c:     	ldr	x21, [x29, #0x10]
10161ac10:     	stp	x5, x6, [sp]
10161ac14:     	str	x7, [sp, #0x10]
10161ac18:     	add	x27, sp, #0x80
10161ac1c:     	ldr	w0, [x0, #0x110]
10161ac20:     	add	x8, sp, #0xc8
10161ac24:     	mov	x1, x21
10161ac28:     	bl	0x1027db718 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
10161ac2c:     	ldrb	w8, [sp, #0xc8]
10161ac30:     	cmp	w8, #0x29
10161ac34:     	b.ne	0x10161ac88 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb8>
10161ac38:     	ldr	x28, [x20, #0x1d8]
10161ac3c:     	cbz	x28, 0x10161aca8 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xd8>
10161ac40:     	mov	w27, #0x2c              ; =44
10161ac44:     	strb	w27, [sp, #0xc8]
10161ac48:     	add	x0, sp, #0xc8
10161ac4c:     	bl	0x1016209f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10161ac50:     	cmp	x22, x26
10161ac54:     	b.ne	0x10161ac80 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb0>
10161ac58:     	ldr	x8, [x20, #0x78]
10161ac5c:     	cmp	x22, x8
10161ac60:     	b.ne	0x10161ac80 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb0>
10161ac64:     	cmp	x25, #0x0
10161ac68:     	cset	w8, ne
10161ac6c:     	ldr	x9, [x20, #0x10]
10161ac70:     	cmp	x9, #0xb
10161ac74:     	cset	w9, eq
10161ac78:     	eor	w8, w8, w9
10161ac7c:     	tbz	w8, #0x0, 0x10161acd0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x100>
10161ac80:     	strb	w27, [x19]
10161ac84:     	b	0x10161acb0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10161ac88:     	ldur	q0, [x27, #0x48]
10161ac8c:     	ldur	q1, [x27, #0x58]
10161ac90:     	stp	q0, q1, [x19]
10161ac94:     	ldur	q0, [x27, #0x68]
10161ac98:     	str	q0, [x19, #0x20]
10161ac9c:     	ldr	x8, [sp, #0xf8]
10161aca0:     	str	x8, [x19, #0x30]
10161aca4:     	b	0x10161acb0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10161aca8:     	mov	w8, #0x2c               ; =44
10161acac:     	strb	w8, [x19]
10161acb0:     	ldp	x29, x30, [sp, #0x1c0]
10161acb4:     	ldp	x20, x19, [sp, #0x1b0]
10161acb8:     	ldp	x22, x21, [sp, #0x1a0]
10161acbc:     	ldp	x24, x23, [sp, #0x190]
10161acc0:     	ldp	x26, x25, [sp, #0x180]
10161acc4:     	ldp	x28, x27, [sp, #0x170]
10161acc8:     	add	sp, sp, #0x1d0
10161accc:     	ret
10161acd0:     	ldp	x8, x9, [x28, #0x10]
10161acd4:     	stp	x8, x9, [sp, #0x18]
10161acd8:     	stp	x24, x22, [sp, #0x28]
10161acdc:     	stp	x23, x22, [sp, #0x38]
10161ace0:     	mov	x10, sp
10161ace4:     	str	x10, [sp, #0x48]
10161ace8:     	ldr	x10, [x21, #0x60]
10161acec:     	cmp	x10, #0x1
10161acf0:     	b.ne	0x10161ae00 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x230>
10161acf4:     	ldr	w10, [x21, #0x50]
10161acf8:     	add	x22, sp, #0x80
10161acfc:     	tbz	w10, #0x0, 0x10161ae0c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x23c>
10161ad00:     	ldp	x11, x10, [x29, #0x18]
10161ad04:     	ldr	x12, [x21, #0x68]
10161ad08:     	ldr	x13, [x21, #0x58]
10161ad0c:     	ldp	x14, x15, [x28, #0x20]
10161ad10:     	add	x16, x28, #0x50
10161ad14:     	add	x17, x28, #0x30
10161ad18:     	add	x0, x28, #0x38
10161ad1c:     	add	x1, x28, #0x40
10161ad20:     	add	x2, x28, #0x48
10161ad24:     	stp	x12, x13, [sp, #0xb8]
10161ad28:     	add	x12, sp, #0xb8
10161ad2c:     	stp	x11, x12, [sp, #0xc8]
10161ad30:     	add	x12, sp, #0xc0
10161ad34:     	stp	x12, x11, [sp, #0xd8]
10161ad38:     	stp	x21, x10, [sp, #0xe8]
10161ad3c:     	stp	x8, x9, [sp, #0xf8]
10161ad40:     	stp	x14, x15, [sp, #0x108]
10161ad44:     	stp	x16, x28, [sp, #0x118]
10161ad48:     	stp	x17, x0, [sp, #0x128]
10161ad4c:     	stp	x1, x2, [sp, #0x138]
10161ad50:     	add	x8, sp, #0x8
10161ad54:     	stp	x8, x20, [sp, #0x148]
10161ad58:     	add	x8, sp, #0x18
10161ad5c:     	str	x8, [sp, #0x158]
10161ad60:     	adrp	x0, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
10161ad64:     	add	x0, x0, #0x5d8
10161ad68:     	add	x8, sp, #0x80
10161ad6c:     	add	x1, sp, #0xc8
10161ad70:     	bl	0x1015ca39c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
10161ad74:     	ldrb	w8, [sp, #0x80]
10161ad78:     	cmp	w8, #0x2f
10161ad7c:     	b.ne	0x10161adc8 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1f8>
10161ad80:     	ldur	q0, [x22, #0x8]
10161ad84:     	stur	q0, [sp, #0x57]
10161ad88:     	ldur	q1, [x22, #0x18]
10161ad8c:     	stur	q1, [sp, #0x67]
10161ad90:     	ldr	x8, [sp, #0xa8]
10161ad94:     	stur	x8, [sp, #0x77]
10161ad98:     	stur	q0, [x22, #0x4f]
10161ad9c:     	stur	q1, [x22, #0x5f]
10161ada0:     	stur	x8, [x22, #0x6f]
10161ada4:     	mov	w8, #0x29               ; =41
10161ada8:     	strb	w8, [x19]
10161adac:     	ldur	q0, [x22, #0x48]
10161adb0:     	stur	q0, [x19, #0x1]
10161adb4:     	ldur	q0, [x22, #0x58]
10161adb8:     	stur	q0, [x19, #0x11]
10161adbc:     	ldur	q0, [x22, #0x67]
10161adc0:     	str	q0, [x19, #0x20]
10161adc4:     	b	0x10161acb0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10161adc8:     	ldr	q0, [sp, #0xa0]
10161adcc:     	stur	q0, [sp, #0x6f]
10161add0:     	ldur	q0, [x22, #0x11]
10161add4:     	ldur	q1, [x22, #0x1]
10161add8:     	stp	q1, q0, [sp, #0x50]
10161addc:     	ldr	x9, [sp, #0xb0]
10161ade0:     	strb	w8, [x19]
10161ade4:     	stur	q1, [x19, #0x1]
10161ade8:     	ldr	q0, [sp, #0x60]
10161adec:     	stur	q0, [x19, #0x11]
10161adf0:     	ldur	q0, [sp, #0x6f]
10161adf4:     	str	q0, [x19, #0x20]
10161adf8:     	str	x9, [x19, #0x30]
10161adfc:     	b	0x10161acb0 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10161ae00:     	adrp	x0, 0x107f13000 <_anon.05a6795a892e9990141ceecb5b939896.82+0x2e0>
10161ae04:     	add	x0, x0, #0x980
10161ae08:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10161ae0c:     	adrp	x0, 0x107f13000 <_anon.05a6795a892e9990141ceecb5b939896.82+0x2e0>
10161ae10:     	add	x0, x0, #0x998
10161ae14:     	bl	0x103a07990 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
