
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015480e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>:
1015480e8:     	stp	x28, x27, [sp, #-0x60]!
1015480ec:     	stp	x26, x25, [sp, #0x10]
1015480f0:     	stp	x24, x23, [sp, #0x20]
1015480f4:     	stp	x22, x21, [sp, #0x30]
1015480f8:     	stp	x20, x19, [sp, #0x40]
1015480fc:     	stp	x29, x30, [sp, #0x50]
101548100:     	add	x29, sp, #0x50
101548104:     	sub	sp, sp, #0x2e0
101548108:     	mov	x19, x8
10154810c:     	ldr	x8, [x0, #0x238]
101548110:     	ldr	w9, [x0, #0x268]
101548114:     	cmp	x8, #0x3
101548118:     	ccmp	w9, #0x0, #0x4, ne
10154811c:     	b.ne	0x101548150 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x68>
101548120:     	ldr	x8, [x0, #0xc0]
101548124:     	cmp	x8, #0x2
101548128:     	b.ne	0x10154816c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84>
10154812c:     	ldr	x8, [x0, #0xa8]
101548130:     	cbz	x8, 0x1015481a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc0>
101548134:     	str	wzr, [x19]
101548138:     	mov	w8, #0xc                ; =12
10154813c:     	strb	w8, [x19, #0x8]
101548140:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548144:     	add	x8, x8, #0x4fb
101548148:     	mov	w9, #0x2a               ; =42
10154814c:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548150:     	str	wzr, [x19]
101548154:     	mov	w8, #0xc                ; =12
101548158:     	strb	w8, [x19, #0x8]
10154815c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548160:     	add	x8, x8, #0x683
101548164:     	mov	w9, #0x24               ; =36
101548168:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10154816c:     	str	wzr, [x19]
101548170:     	mov	w8, #0xc                ; =12
101548174:     	strb	w8, [x19, #0x8]
101548178:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154817c:     	add	x8, x8, #0x4c7
101548180:     	mov	w9, #0x34               ; =52
101548184:     	stp	x8, x9, [x19, #0x10]
101548188:     	add	sp, sp, #0x2e0
10154818c:     	ldp	x29, x30, [sp, #0x50]
101548190:     	ldp	x20, x19, [sp, #0x40]
101548194:     	ldp	x22, x21, [sp, #0x30]
101548198:     	ldp	x24, x23, [sp, #0x20]
10154819c:     	ldp	x26, x25, [sp, #0x10]
1015481a0:     	ldp	x28, x27, [sp], #0x60
1015481a4:     	ret
1015481a8:     	mov	x20, x1
1015481ac:     	ldrb	w8, [x0, #0x508]
1015481b0:     	tbz	w8, #0x0, 0x1015481ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
1015481b4:     	ldr	x8, [x0, #0x498]
1015481b8:     	ldr	w9, [x8, #0x300]
1015481bc:     	cmp	w9, #0x1
1015481c0:     	b.ne	0x1015481ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
1015481c4:     	ldr	w8, [x8, #0x304]
1015481c8:     	cmp	x20, x8
1015481cc:     	b.ne	0x1015481ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
1015481d0:     	str	wzr, [x19]
1015481d4:     	mov	w8, #0xc                ; =12
1015481d8:     	strb	w8, [x19, #0x8]
1015481dc:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
1015481e0:     	add	x8, x8, #0x64b
1015481e4:     	mov	w9, #0x38               ; =56
1015481e8:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
1015481ec:     	ldr	x24, [x0, #0x490]
1015481f0:     	ldr	w8, [x24, #0x2f0]
1015481f4:     	tbz	w8, #0x0, 0x10154821c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
1015481f8:     	ldr	w1, [x24, #0x2f4]
1015481fc:     	mov	x21, x0
101548200:     	bl	0x101547234 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
101548204:     	mov	x8, x0
101548208:     	mov	x0, x21
10154820c:     	ldr	x24, [x21, #0x490]
101548210:     	tbz	w8, #0x0, 0x10154821c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
101548214:     	ldrb	w8, [x24, #0x460]
101548218:     	tbz	w8, #0x0, 0x101548318 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x230>
10154821c:     	ldr	x21, [x0, #0x498]
101548220:     	ldr	w9, [x24, #0xb8]
101548224:     	ldr	w8, [x24, #0x2f0]
101548228:     	cmp	w9, #0x1
10154822c:     	b.ne	0x101548264 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x17c>
101548230:     	tbz	w8, #0x0, 0x101548248 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x160>
101548234:     	ldp	w22, w8, [x24, #0xbc]
101548238:     	ldr	w9, [x24, #0x2f4]
10154823c:     	cmp	x20, x8
101548240:     	ccmp	w9, w22, #0x0, eq
101548244:     	b.eq	0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101548248:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154824c:     	add	x8, x8, #0x419
101548250:     	mov	w9, #0x26               ; =38
101548254:     	str	wzr, [x19]
101548258:     	mov	w10, #0xc               ; =12
10154825c:     	str	w10, [x19, #0x8]
101548260:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548264:     	ldr	w22, [x24, #0x2f4]
101548268:     	tbz	w8, #0x0, 0x1015482f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x210>
10154826c:     	ldr	x8, [x21, #0x590]
101548270:     	cmp	x8, x22
101548274:     	b.ls	0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101548278:     	ldr	x8, [x21, #0x588]
10154827c:     	add	x8, x8, x22, lsl #4
101548280:     	ldr	x9, [x8]
101548284:     	cmp	x9, #0x1
101548288:     	b.ne	0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10154828c:     	ldr	x8, [x8, #0x8]
101548290:     	ldr	x1, [x21, #0x580]
101548294:     	cmp	x8, x1
101548298:     	b.hs	0x101548df0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd08>
10154829c:     	ldr	x9, [x21, #0x578]
1015482a0:     	mov	w10, #0x38              ; =56
1015482a4:     	madd	x8, x8, x10, x9
1015482a8:     	ldr	x9, [x8]
1015482ac:     	cmp	x9, #0x1
1015482b0:     	b.ne	0x101548334 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x24c>
1015482b4:     	ldr	x9, [x24, #0x10]
1015482b8:     	cmp	x9, #0x2
1015482bc:     	b.eq	0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015482c0:     	ldr	x9, [x8, #0x8]
1015482c4:     	ldr	x10, [x24, #0x40]
1015482c8:     	cmp	x9, x10
1015482cc:     	b.hs	0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015482d0:     	ldr	x10, [x24, #0x38]
1015482d4:     	mov	w11, #0x3c8             ; =968
1015482d8:     	madd	x9, x9, x11, x10
1015482dc:     	ldr	x9, [x9, #0x290]
1015482e0:     	cbz	x9, 0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
1015482e4:     	ldr	x9, [x8, #0x18]
1015482e8:     	cbz	x9, 0x101548ddc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015482ec:     	ldr	x9, [x8, #0x10]
1015482f0:     	ldr	w9, [x9]
1015482f4:     	b	0x101548358 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x270>
1015482f8:     	mov	w15, #0x0               ; =0
1015482fc:     	mov	w14, #0x0               ; =0
101548300:     	add	x23, sp, #0x120
101548304:     	mov	x28, x0
101548308:     	ldr	x26, [x28, #0xf8]!
10154830c:     	cmp	x26, #0x2
101548310:     	b.eq	0x101548394 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
101548314:     	b	0x1015484ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
101548318:     	str	wzr, [x19]
10154831c:     	mov	w8, #0xc                ; =12
101548320:     	strb	w8, [x19, #0x8]
101548324:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548328:     	add	x8, x8, #0x525
10154832c:     	mov	w9, #0x25               ; =37
101548330:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548334:     	ldr	x9, [x8, #0x18]
101548338:     	cbz	x9, 0x101548ddc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
10154833c:     	ldr	w9, [x24, #0x340]
101548340:     	tbz	w9, #0x0, 0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101548344:     	ldr	x9, [x8, #0x10]
101548348:     	ldr	w9, [x9]
10154834c:     	ldr	w10, [x24, #0x344]
101548350:     	cmp	w10, w9
101548354:     	b.ne	0x101548378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
101548358:     	cmp	w22, w9
10154835c:     	b.ne	0x101548464 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x37c>
101548360:     	lsr	x9, x20, #32
101548364:     	cbz	x9, 0x101548474 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x38c>
101548368:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
10154836c:     	add	x8, x8, #0x469
101548370:     	mov	w9, #0x1a               ; =26
101548374:     	b	0x101548254 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
101548378:     	mov	w15, #0x1               ; =1
10154837c:     	mov	w14, #0x1               ; =1
101548380:     	add	x23, sp, #0x120
101548384:     	mov	x28, x0
101548388:     	ldr	x26, [x28, #0xf8]!
10154838c:     	cmp	x26, #0x2
101548390:     	b.ne	0x1015484ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
101548394:     	cbz	w14, 0x101548448 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x360>
101548398:     	mov	w2, w22
10154839c:     	ldr	x8, [x21, #0x188]
1015483a0:     	cmp	x8, x2
1015483a4:     	b.ls	0x101548968 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
1015483a8:     	ldr	x8, [x21, #0x180]
1015483ac:     	ldr	x8, [x8, x2, lsl #3]
1015483b0:     	cbz	x8, 0x101548968 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
1015483b4:     	sub	x8, x8, #0x1
1015483b8:     	and	x9, x8, #0x3
1015483bc:     	cmp	x9, #0x2
1015483c0:     	b.ne	0x101548968 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x880>
1015483c4:     	lsr	x8, x8, #2
1015483c8:     	ldr	x1, [x21, #0x160]
1015483cc:     	cmp	x8, x1
1015483d0:     	b.hs	0x101548e00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd18>
1015483d4:     	ldr	x9, [x21, #0x158]
1015483d8:     	mov	w10, #0x48              ; =72
1015483dc:     	madd	x9, x8, x10, x9
1015483e0:     	ldr	w10, [x9, #0x40]
1015483e4:     	cmp	x20, x10
1015483e8:     	b.ne	0x101548438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015483ec:     	ldr	w10, [x24, #0x2e8]
1015483f0:     	cmp	w10, #0x1
1015483f4:     	b.ne	0x101548438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
1015483f8:     	ldr	w10, [x9, #0x30]
1015483fc:     	ldr	w11, [x24, #0x2ec]
101548400:     	cmp	w11, w10
101548404:     	b.ne	0x101548438 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
101548408:     	ldr	w9, [x9, #0x34]
10154840c:     	mov	w10, #0x1               ; =1
101548410:     	orr	x9, x10, x9, lsl #1
101548414:     	ldr	x1, [x0, #0x4b8]
101548418:     	cmp	x9, x1
10154841c:     	b.hs	0x101548e50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd68>
101548420:     	ldr	x10, [x0, #0x4b0]
101548424:     	ldr	x9, [x10, x9, lsl #3]
101548428:     	ldr	x10, [x0, #0xc0]
10154842c:     	cmp	x9, #0x0
101548430:     	ccmp	x10, #0x2, #0x0, eq
101548434:     	b.eq	0x101548950 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
101548438:     	adrp	x8, 0x107556000 <_anon.99617498846789129750b3326436f5d5.433+0x1e07>
10154843c:     	add	x8, x8, #0x2fc
101548440:     	mov	w9, #0x35               ; =53
101548444:     	b	0x101548988 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
101548448:     	ldrb	w8, [x24, #0x338]
10154844c:     	cmp	w8, #0x1
101548450:     	b.ne	0x10154845c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x374>
101548454:     	ldr	x8, [x0, #0x4c0]
101548458:     	cbnz	x8, 0x10154897c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x894>
10154845c:     	str	x20, [sp, #0x10]
101548460:     	b	0x101548648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x560>
101548464:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548468:     	add	x8, x8, #0x483
10154846c:     	mov	w9, #0x1a               ; =26
101548470:     	b	0x101548254 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
101548474:     	mov	x25, x0
101548478:     	mov	x0, x8
10154847c:     	mov	x1, x20
101548480:     	bl	0x1016376bc <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB2_5Group11predecessor>
101548484:     	tbz	w0, #0x0, 0x101548940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x858>
101548488:     	mov	x22, x1
10154848c:     	mov	w15, #0x1               ; =1
101548490:     	mov	w14, #0x1               ; =1
101548494:     	mov	x0, x25
101548498:     	add	x23, sp, #0x120
10154849c:     	mov	x28, x0
1015484a0:     	ldr	x26, [x28, #0xf8]!
1015484a4:     	cmp	x26, #0x2
1015484a8:     	b.eq	0x101548394 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
1015484ac:     	cbz	w14, 0x1015485dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4f4>
1015484b0:     	mov	w2, w22
1015484b4:     	ldr	x1, [x21, #0x380]
1015484b8:     	cmp	x1, x2
1015484bc:     	b.ls	0x101548db8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd0>
1015484c0:     	ldr	x8, [x21, #0x378]
1015484c4:     	mov	w9, #0x170              ; =368
1015484c8:     	umaddl	x8, w2, w9, x8
1015484cc:     	ldp	x10, x9, [x8]
1015484d0:     	mov	w11, #0x11              ; =17
1015484d4:     	eor	x10, x10, x11
1015484d8:     	orr	x9, x10, x9
1015484dc:     	cbnz	x9, 0x1015485cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
1015484e0:     	ldr	x1, [x21, #0x390]
1015484e4:     	ldr	w25, [x8, #0x10]
1015484e8:     	cmp	x1, x25
1015484ec:     	b.ls	0x101548dcc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xce4>
1015484f0:     	ldr	x8, [x21, #0x388]
1015484f4:     	mov	w9, #0x180              ; =384
1015484f8:     	umaddl	x27, w25, w9, x8
1015484fc:     	ldp	x9, x8, [x27]
101548500:     	mov	w10, #0x5               ; =5
101548504:     	eor	x9, x9, x10
101548508:     	orr	x8, x9, x8
10154850c:     	cbnz	x8, 0x1015485cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
101548510:     	ldr	x8, [x21, #0x558]
101548514:     	cmp	x8, x2
101548518:     	b.ls	0x101548534 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x44c>
10154851c:     	ldr	x8, [x21, #0x550]
101548520:     	mov	w9, #0x28               ; =40
101548524:     	umull	x9, w2, w9
101548528:     	ldr	w8, [x8, x9]
10154852c:     	cmp	w8, #0x5
101548530:     	b.ne	0x10154858c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4a4>
101548534:     	str	x0, [sp, #0x8]
101548538:     	mov	x0, x24
10154853c:     	mov	x1, x21
101548540:     	mov	x24, x14
101548544:     	mov	x23, x15
101548548:     	bl	0x10155ad5c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
10154854c:     	mov	x15, x23
101548550:     	mov	x14, x24
101548554:     	mov	x8, x0
101548558:     	ldr	x0, [sp, #0x8]
10154855c:     	add	x23, sp, #0x120
101548560:     	tbnz	w8, #0x0, 0x10154858c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4a4>
101548564:     	ldr	x1, [x21, #0x360]
101548568:     	ldr	w8, [x27, #0x30]
10154856c:     	cmp	x1, x8
101548570:     	b.ls	0x101548e10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd28>
101548574:     	ldr	x9, [x21, #0x358]
101548578:     	mov	w10, #0x140             ; =320
10154857c:     	umaddl	x8, w8, w10, x9
101548580:     	ldrb	w8, [x8, #0x124]
101548584:     	cmp	w8, #0x7
101548588:     	b.eq	0x1015485cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
10154858c:     	mov	x27, x15
101548590:     	mov	x24, x14
101548594:     	mov	x1, x0
101548598:     	add	x0, sp, #0x178
10154859c:     	mov	x21, x1
1015485a0:     	mov	x2, x25
1015485a4:     	mov	w3, #0x1                ; =1
1015485a8:     	bl	0x101547428 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
1015485ac:     	ldr	w8, [sp, #0x178]
1015485b0:     	cmp	w8, #0x6
1015485b4:     	b.ne	0x101548b70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015485b8:     	mov	x0, x21
1015485bc:     	ldr	x26, [x21, #0xf8]
1015485c0:     	ldr	x21, [x21, #0x498]
1015485c4:     	mov	x14, x24
1015485c8:     	mov	x15, x27
1015485cc:     	str	x20, [sp, #0x10]
1015485d0:     	cmp	x26, #0x2
1015485d4:     	b.ne	0x1015485e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4f8>
1015485d8:     	b	0x101548648 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x560>
1015485dc:     	str	x20, [sp, #0x10]
1015485e0:     	ldr	x9, [x21, #0x5a0]
1015485e4:     	ldr	x8, [x0, #0x1c0]
1015485e8:     	cmp	x8, x9
1015485ec:     	b.hs	0x101548768 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
1015485f0:     	ldr	x9, [x21, #0x598]
1015485f4:     	mov	w10, #0x58              ; =88
1015485f8:     	madd	x8, x8, x10, x9
1015485fc:     	ldr	x9, [x8, #0x18]
101548600:     	cbz	x9, 0x101548768 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
101548604:     	ldr	x8, [x8, #0x10]
101548608:     	cmp	x9, #0x1
10154860c:     	b.ne	0x101548618 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x530>
101548610:     	mov	x10, #0x0               ; =0
101548614:     	b	0x10154863c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x554>
101548618:     	mov	x10, #0x0               ; =0
10154861c:     	lsr	x11, x9, #1
101548620:     	add	x12, x11, x10
101548624:     	ldr	w13, [x8, x12, lsl #2]
101548628:     	cmp	w13, w20
10154862c:     	csel	x10, x10, x12, hi
101548630:     	sub	x9, x9, x11
101548634:     	cmp	x9, #0x1
101548638:     	b.hi	0x10154861c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x534>
10154863c:     	ldr	w8, [x8, x10, lsl #2]
101548640:     	cmp	w8, w20
101548644:     	b.ne	0x101548768 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
101548648:     	ldr	x8, [x21, #0x380]
10154864c:     	cmp	x20, x8
101548650:     	b.hs	0x101548784 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x69c>
101548654:     	mov	x25, x15
101548658:     	mov	x26, x14
10154865c:     	ldr	x24, [x21, #0x378]
101548660:     	mov	x1, x0
101548664:     	add	x0, sp, #0x178
101548668:     	mov	x21, x1
10154866c:     	mov	x2, x20
101548670:     	bl	0x101556acc <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation31validate_selected_join_boundary>
101548674:     	ldr	w8, [sp, #0x178]
101548678:     	cmp	w8, #0x6
10154867c:     	b.ne	0x101548b70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
101548680:     	mov	w8, #0x170              ; =368
101548684:     	madd	x24, x20, x8, x24
101548688:     	mov	x8, x21
10154868c:     	ldr	x9, [x21, #0x490]
101548690:     	ldr	x10, [x9, #0x1e0]
101548694:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
101548698:     	cmp	x10, x11
10154869c:     	b.eq	0x1015486c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x5e0>
1015486a0:     	ldr	x1, [x9, #0x2d0]
1015486a4:     	ldr	x2, [x9, #0x2e0]
1015486a8:     	ldp	x3, x4, [x24]
1015486ac:     	ldrb	w5, [x24, #0x10]
1015486b0:     	add	x0, sp, #0x178
1015486b4:     	bl	0x10154e0b8 <__RNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections11string_spanNtB7_5State22validate_span_boundary>
1015486b8:     	ldr	w8, [sp, #0x178]
1015486bc:     	cmp	w8, #0x6
1015486c0:     	b.ne	0x101548b70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015486c4:     	mov	x8, x21
1015486c8:     	ldr	x9, [x8, #0x498]
1015486cc:     	mov	x23, x8
1015486d0:     	add	x0, x9, #0x578
1015486d4:     	mov	x1, x20
1015486d8:     	bl	0x101552fa4 <__RNvMs_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB4_6Layout5group>
1015486dc:     	ldr	x8, [x23, #0x490]
1015486e0:     	add	x9, x8, #0x3b8
1015486e4:     	add	x10, x8, #0x2f8
1015486e8:     	stp	x8, x9, [sp, #0x178]
1015486ec:     	stp	x10, x28, [sp, #0x188]
1015486f0:     	add	x8, sp, #0x10
1015486f4:     	str	x8, [sp, #0x198]
1015486f8:     	add	x1, sp, #0x178
1015486fc:     	bl	0x101527598 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>
101548700:     	cbz	x0, 0x10154871c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x634>
101548704:     	ldr	x8, [x0, #0x18]
101548708:     	cbz	x8, 0x101548ddc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
10154870c:     	ldr	x8, [x0, #0x10]
101548710:     	ldr	w8, [x8]
101548714:     	cmp	x20, x8
101548718:     	b.ne	0x101548810 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x728>
10154871c:     	ldr	x8, [x28]
101548720:     	cmp	x8, #0x2
101548724:     	csinc	w8, w25, wzr, ne
101548728:     	tbz	w8, #0x0, 0x1015487a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x6bc>
10154872c:     	ldr	x8, [x21, #0x490]
101548730:     	add	x10, x8, #0x2e8
101548734:     	ldr	x8, [x21, #0x498]
101548738:     	ldr	x11, [x21, #0x4b0]
10154873c:     	ldr	x9, [x21, #0x4b8]
101548740:     	stp	x10, x8, [sp, #0x1b0]
101548744:     	stp	x11, x9, [sp, #0x1c0]
101548748:     	mov	w9, #0x13               ; =19
10154874c:     	strb	w9, [sp, #0x178]
101548750:     	add	x23, sp, #0x120
101548754:     	cbz	x0, 0x10154884c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x764>
101548758:     	mov	x25, x0
10154875c:     	ldr	x4, [x0, #0x30]
101548760:     	mov	w3, #0x1                ; =1
101548764:     	b	0x101548854 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x76c>
101548768:     	str	wzr, [x19]
10154876c:     	mov	w8, #0xc                ; =12
101548770:     	strb	w8, [x19, #0x8]
101548774:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548778:     	add	x8, x8, #0x54a
10154877c:     	mov	w9, #0x2f               ; =47
101548780:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548784:     	str	wzr, [x19]
101548788:     	mov	w8, #0xc                ; =12
10154878c:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101548790:     	add	x9, x9, #0xfc2
101548794:     	stp	x8, x9, [x19, #0x8]
101548798:     	mov	w8, #0x25               ; =37
10154879c:     	str	x8, [x19, #0x18]
1015487a0:     	b	0x101548188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
1015487a4:     	ldr	x8, [x21, #0x498]
1015487a8:     	ldr	x11, [x8, #0x5a0]
1015487ac:     	ldr	x10, [x21, #0x1c0]
1015487b0:     	cmp	x10, x11
1015487b4:     	add	x23, sp, #0x120
1015487b8:     	b.hs	0x10154882c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x744>
1015487bc:     	cbnz	x0, 0x101548918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x830>
1015487c0:     	ldr	x11, [x8, #0x598]
1015487c4:     	mov	w12, #0x58              ; =88
1015487c8:     	madd	x10, x10, x12, x11
1015487cc:     	ldr	w3, [x10, #0x38]
1015487d0:     	cmp	x20, x3
1015487d4:     	b.ne	0x101548918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x830>
1015487d8:     	mov	x25, x0
1015487dc:     	ldr	x10, [x21, #0x490]
1015487e0:     	add	x10, x10, #0x2e8
1015487e4:     	ldr	x11, [x21, #0x4b0]
1015487e8:     	ldr	x9, [x21, #0x4b8]
1015487ec:     	stp	x10, x8, [sp, #0x1b0]
1015487f0:     	stp	x11, x9, [sp, #0x1c0]
1015487f4:     	mov	w8, #0x13               ; =19
1015487f8:     	strb	w8, [sp, #0x178]
1015487fc:     	add	x0, sp, #0x18
101548800:     	add	x1, sp, #0x178
101548804:     	mov	x2, x20
101548808:     	bl	0x101552c18 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE20visit_outlined_entryB9_>
10154880c:     	b	0x101548870 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x788>
101548810:     	str	wzr, [x19]
101548814:     	mov	w8, #0xc                ; =12
101548818:     	strb	w8, [x19, #0x8]
10154881c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548820:     	add	x8, x8, #0x620
101548824:     	mov	w9, #0x2b               ; =43
101548828:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10154882c:     	str	wzr, [x19]
101548830:     	mov	w8, #0xc                ; =12
101548834:     	adrp	x9, 0x107552000 <_anon.cc6a64927a21d5449d5d90d0cd21adc0.400+0x216>
101548838:     	add	x9, x9, #0xfe7
10154883c:     	stp	x8, x9, [x19, #0x8]
101548840:     	mov	w8, #0x1a               ; =26
101548844:     	str	x8, [x19, #0x18]
101548848:     	b	0x101548188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10154884c:     	mov	x25, x0
101548850:     	mov	x3, #0x0                ; =0
101548854:     	ldr	w7, [x8, #0x3f0]
101548858:     	add	x0, sp, #0x18
10154885c:     	add	x1, sp, #0x178
101548860:     	mov	x2, x20
101548864:     	mov	x5, x26
101548868:     	mov	x6, x22
10154886c:     	bl	0x101552574 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>
101548870:     	ldrb	w8, [sp, #0x18]
101548874:     	cmp	w8, #0x13
101548878:     	b.ne	0x1015488b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x7d0>
10154887c:     	add	x0, sp, #0x178
101548880:     	bl	0x10152aaa4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
101548884:     	add	x0, sp, #0x178
101548888:     	mov	x1, x21
10154888c:     	mov	x2, x20
101548890:     	bl	0x1015544f0 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation12continuationNtB6_10Invocation23arm_parent_continuation>
101548894:     	ldr	w8, [sp, #0x178]
101548898:     	cmp	w8, #0x6
10154889c:     	b.ne	0x101548b70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
1015488a0:     	cbz	x25, 0x101548934 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84c>
1015488a4:     	ldr	x8, [x25]
1015488a8:     	mov	x0, x21
1015488ac:     	cbz	x8, 0x101548998 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8b0>
1015488b0:     	mov	w8, #0x0                ; =0
1015488b4:     	b	0x1015489ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8c4>
1015488b8:     	ldur	q0, [sp, #0x18]
1015488bc:     	ldur	q1, [sp, #0x28]
1015488c0:     	stp	q0, q1, [sp, #0x120]
1015488c4:     	ldur	q2, [sp, #0x38]
1015488c8:     	str	q2, [sp, #0x140]
1015488cc:     	ldr	x8, [sp, #0x48]
1015488d0:     	str	x8, [sp, #0x150]
1015488d4:     	stur	q0, [sp, #0x1c]
1015488d8:     	stur	q1, [sp, #0x2c]
1015488dc:     	stur	q2, [sp, #0x3c]
1015488e0:     	stur	x8, [sp, #0x4c]
1015488e4:     	mov	w8, #0x1                ; =1
1015488e8:     	str	w8, [x19]
1015488ec:     	ldur	q0, [sp, #0x18]
1015488f0:     	ldur	q1, [sp, #0x28]
1015488f4:     	stur	q0, [x19, #0x4]
1015488f8:     	stur	q1, [x19, #0x14]
1015488fc:     	ldur	q0, [sp, #0x38]
101548900:     	stur	q0, [x19, #0x24]
101548904:     	ldur	q0, [sp, #0x44]
101548908:     	str	q0, [x19, #0x30]
10154890c:     	add	x0, sp, #0x178
101548910:     	bl	0x10152aaa4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
101548914:     	b	0x101548188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101548918:     	str	wzr, [x19]
10154891c:     	mov	w8, #0xc                ; =12
101548920:     	strb	w8, [x19, #0x8]
101548924:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548928:     	add	x8, x8, #0x579
10154892c:     	mov	w9, #0x26               ; =38
101548930:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548934:     	mov	w8, #0x0                ; =0
101548938:     	mov	x0, x21
10154893c:     	b	0x1015489ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8c4>
101548940:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548944:     	add	x8, x8, #0x43f
101548948:     	mov	w9, #0x2a               ; =42
10154894c:     	b	0x101548254 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
101548950:     	ldr	x9, [x0, #0x4c0]
101548954:     	str	xzr, [x0, #0x4c0]
101548958:     	cbz	x9, 0x101548bdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaf4>
10154895c:     	sub	x9, x9, #0x1
101548960:     	cmp	x9, x8
101548964:     	b.ne	0x101548bec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xb04>
101548968:     	ldrb	w8, [x24, #0x338]
10154896c:     	cmp	w8, #0x1
101548970:     	b.ne	0x1015484b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
101548974:     	ldr	x8, [x0, #0x4c0]
101548978:     	cbz	x8, 0x1015484b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
10154897c:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548980:     	add	x8, x8, #0x59f
101548984:     	mov	w9, #0x29               ; =41
101548988:     	str	wzr, [x19]
10154898c:     	mov	w10, #0xc               ; =12
101548990:     	str	x10, [x19, #0x8]
101548994:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548998:     	ldr	x8, [x25, #0x18]
10154899c:     	cbz	x8, 0x101548ddc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcf4>
1015489a0:     	ldr	x8, [x25, #0x10]
1015489a4:     	ldr	w9, [x8]
1015489a8:     	mov	w8, #0x1                ; =1
1015489ac:     	ldr	x10, [x0, #0x490]
1015489b0:     	str	w8, [x10, #0x340]
1015489b4:     	str	w9, [x10, #0x344]
1015489b8:     	ldr	x8, [x0, #0x490]
1015489bc:     	str	wzr, [x8, #0xb8]
1015489c0:     	ldr	x22, [x0, #0x498]
1015489c4:     	mov	x1, x20
1015489c8:     	bl	0x10153d30c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
1015489cc:     	cbz	x0, 0x101548a00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x918>
1015489d0:     	ldrb	w8, [x0]
1015489d4:     	cmp	w8, #0x6
1015489d8:     	b.ne	0x101548a00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x918>
1015489dc:     	ldr	x9, [x21, #0x490]
1015489e0:     	add	x8, sp, #0x178
1015489e4:     	add	x0, x9, #0x3b8
1015489e8:     	mov	w1, #0x20               ; =32
1015489ec:     	mov	w2, #0x20               ; =32
1015489f0:     	bl	0x102369fa4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>
1015489f4:     	ldrb	w8, [sp, #0x178]
1015489f8:     	cmp	w8, #0x8
1015489fc:     	b.ne	0x101548b94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaac>
101548a00:     	ldr	x1, [x22, #0x458]
101548a04:     	cmp	x20, x1
101548a08:     	b.hs	0x101548e20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd38>
101548a0c:     	ldr	x8, [x22, #0x450]
101548a10:     	add	x10, x8, x20, lsl #6
101548a14:     	ldr	w8, [x10, #0x18]
101548a18:     	cmp	w8, #0x4
101548a1c:     	mov	x9, x21
101548a20:     	b.ne	0x101548a78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
101548a24:     	ldr	x8, [x9, #0x220]
101548a28:     	cmp	x8, #0x2
101548a2c:     	b.eq	0x101548a78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
101548a30:     	ldr	x8, [x22, #0x208]
101548a34:     	ldr	x0, [x9, #0x1d8]
101548a38:     	cmp	x0, x8
101548a3c:     	b.hs	0x101548e8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xda4>
101548a40:     	ldr	w8, [x10, #0x1c]
101548a44:     	ldr	x10, [x22, #0x200]
101548a48:     	mov	w11, #0x70              ; =112
101548a4c:     	madd	x10, x0, x11, x10
101548a50:     	ldr	w10, [x10, #0x40]
101548a54:     	cmp	w10, w8
101548a58:     	b.ne	0x101548a78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x990>
101548a5c:     	add	x0, x9, #0x1d8
101548a60:     	bl	0x10152d414 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
101548a64:     	mov	w8, #0x2                ; =2
101548a68:     	mov	x9, x21
101548a6c:     	str	x8, [x21, #0x220]
101548a70:     	ldr	x1, [x22, #0x458]
101548a74:     	add	x23, sp, #0x120
101548a78:     	cmp	x20, x1
101548a7c:     	b.hs	0x101548e30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd48>
101548a80:     	ldr	x8, [x22, #0x450]
101548a84:     	add	x8, x8, x20, lsl #6
101548a88:     	ldr	w10, [x8, #0x18]
101548a8c:     	cmp	w10, #0x4
101548a90:     	b.ne	0x101548ae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa00>
101548a94:     	ldr	w2, [x8, #0x1c]
101548a98:     	ldr	x8, [x22, #0x390]
101548a9c:     	cmp	x8, x2
101548aa0:     	b.ls	0x101548e60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd78>
101548aa4:     	ldr	x8, [x22, #0x388]
101548aa8:     	mov	w10, #0x180             ; =384
101548aac:     	umaddl	x8, w2, w10, x8
101548ab0:     	ldp	x8, x10, [x8]
101548ab4:     	mov	w11, #0x5               ; =5
101548ab8:     	eor	x8, x8, x11
101548abc:     	orr	x8, x8, x10
101548ac0:     	cbnz	x8, 0x101548ae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa00>
101548ac4:     	mov	x1, x9
101548ac8:     	add	x0, sp, #0x178
101548acc:     	mov	w3, #0x2                ; =2
101548ad0:     	bl	0x101547428 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
101548ad4:     	ldr	w8, [sp, #0x178]
101548ad8:     	cmp	w8, #0x6
101548adc:     	b.ne	0x101548b70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa88>
101548ae0:     	ldr	x1, [x22, #0x458]
101548ae4:     	mov	x9, x21
101548ae8:     	cmp	x20, x1
101548aec:     	b.hs	0x101548e40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd58>
101548af0:     	ldr	x8, [x22, #0x450]
101548af4:     	add	x8, x8, x20, lsl #6
101548af8:     	ldr	w10, [x8, #0x18]
101548afc:     	cmp	w10, #0x4
101548b00:     	b.ne	0x101548ce0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbf8>
101548b04:     	ldr	w2, [x8, #0x1c]
101548b08:     	ldr	x1, [x22, #0x390]
101548b0c:     	cmp	x1, x2
101548b10:     	b.ls	0x101548e78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd90>
101548b14:     	ldr	x8, [x22, #0x388]
101548b18:     	mov	w10, #0x180             ; =384
101548b1c:     	umaddl	x8, w2, w10, x8
101548b20:     	ldp	x8, x10, [x8]
101548b24:     	cmp	x8, #0x3
101548b28:     	sbcs	xzr, x10, xzr
101548b2c:     	b.hs	0x101548ce0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbf8>
101548b30:     	ldr	x12, [x9, #0x490]
101548b34:     	ldr	x8, [x12, #0x1e0]
101548b38:     	ldr	d0, [x12, #0x1e8]
101548b3c:     	ldrb	w9, [x12, #0x1f0]
101548b40:     	ldp	x10, x11, [x12, #0x1f8]
101548b44:     	mov	x13, #-0x8000000000000000 ; =-9223372036854775808
101548b48:     	str	x13, [x12, #0x1e0]
101548b4c:     	cmp	x8, x13
101548b50:     	b.ne	0x101548bfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xb14>
101548b54:     	str	wzr, [x19]
101548b58:     	mov	w8, #0xc                ; =12
101548b5c:     	strb	w8, [x19, #0x8]
101548b60:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101548b64:     	add	x8, x8, #0x1
101548b68:     	mov	w9, #0x1d               ; =29
101548b6c:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548b70:     	ldur	q0, [x23, #0x68]
101548b74:     	ldur	q1, [x23, #0x78]
101548b78:     	ldur	q2, [x23, #0x88]
101548b7c:     	stp	q1, q2, [x19, #0x20]
101548b80:     	ldur	q1, [x23, #0x98]
101548b84:     	str	q1, [x19, #0x40]
101548b88:     	ldur	q1, [x23, #0x58]
101548b8c:     	stp	q1, q0, [x19]
101548b90:     	b	0x101548188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101548b94:     	ldur	q0, [x23, #0x58]
101548b98:     	ldur	q1, [x23, #0x68]
101548b9c:     	stp	q0, q1, [x29, #-0xb0]
101548ba0:     	ldr	x8, [sp, #0x198]
101548ba4:     	stur	x8, [x29, #-0x90]
101548ba8:     	add	x9, x24, #0x148
101548bac:     	ldr	w10, [x24, #0x158]
101548bb0:     	stur	w10, [x29, #-0x70]
101548bb4:     	ldr	q2, [x9]
101548bb8:     	stur	q2, [x29, #-0x80]
101548bbc:     	mov	w9, #0x4                ; =4
101548bc0:     	str	w9, [x19]
101548bc4:     	stur	q2, [x19, #0x4]
101548bc8:     	str	w10, [x19, #0x14]
101548bcc:     	stur	q0, [x19, #0x18]
101548bd0:     	stur	q1, [x19, #0x28]
101548bd4:     	str	x8, [x19, #0x38]
101548bd8:     	b	0x101548188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101548bdc:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101548be0:     	add	x8, x8, #0xe02
101548be4:     	mov	w9, #0x2c               ; =44
101548be8:     	b	0x101548988 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
101548bec:     	adrp	x8, 0x107553000 <_anon.99617498846789129750b3326436f5d5.70+0xe4c>
101548bf0:     	add	x8, x8, #0xe2e
101548bf4:     	mov	w9, #0x31               ; =49
101548bf8:     	b	0x101548988 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8a0>
101548bfc:     	add	x13, sp, #0x18
101548c00:     	add	x14, x12, #0x238
101548c04:     	add	x15, x12, #0x208
101548c08:     	ldp	q1, q2, [x15]
101548c0c:     	stp	q1, q2, [sp, #0x40]
101548c10:     	ldr	q4, [x15, #0x20]
101548c14:     	ldp	q1, q2, [x14, #0x90]
101548c18:     	stur	q2, [x13, #0xf8]
101548c1c:     	ldr	q2, [x14, #0x80]
101548c20:     	stur	q1, [x13, #0xe8]
101548c24:     	stur	q2, [x13, #0xd8]
101548c28:     	ldp	q2, q1, [x14, #0x60]
101548c2c:     	stur	q1, [x13, #0xc8]
101548c30:     	stur	q2, [x13, #0xb8]
101548c34:     	ldp	q2, q1, [x14, #0x40]
101548c38:     	stur	q1, [x13, #0xa8]
101548c3c:     	stur	q2, [x13, #0x98]
101548c40:     	ldp	q2, q1, [x14, #0x20]
101548c44:     	stur	q1, [x13, #0x88]
101548c48:     	ldp	q1, q3, [x14]
101548c4c:     	stp	q4, q1, [sp, #0x60]
101548c50:     	stur	q3, [sp, #0x80]
101548c54:     	add	x14, x12, #0x1f1
101548c58:     	ldr	w12, [x12, #0x1f4]
101548c5c:     	str	w12, [sp, #0x2c]
101548c60:     	ldr	w12, [x14]
101548c64:     	stur	w12, [sp, #0x29]
101548c68:     	stur	q2, [x13, #0x78]
101548c6c:     	str	x8, [sp, #0x18]
101548c70:     	str	d0, [sp, #0x20]
101548c74:     	strb	w9, [sp, #0x28]
101548c78:     	stp	x10, x11, [sp, #0x30]
101548c7c:     	str	x21, [sp, #0x178]
101548c80:     	add	x8, sp, #0x120
101548c84:     	add	x0, sp, #0x18
101548c88:     	add	x1, sp, #0x178
101548c8c:     	bl	0x1015706c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections8lifetimeNtB4_5State14release_source>
101548c90:     	add	x0, sp, #0x178
101548c94:     	add	x1, sp, #0x18
101548c98:     	mov	w2, #0x108              ; =264
101548c9c:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
101548ca0:     	ldr	x8, [x21, #0x490]
101548ca4:     	ldr	x9, [x8, #0x1e0]
101548ca8:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101548cac:     	cmp	x9, x10
101548cb0:     	b.eq	0x101548cc0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbd8>
101548cb4:     	add	x0, x8, #0x1e0
101548cb8:     	bl	0x10152c34c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101548cbc:     	ldr	x8, [x21, #0x490]
101548cc0:     	add	x0, x8, #0x1e0
101548cc4:     	add	x1, sp, #0x178
101548cc8:     	mov	w2, #0x108              ; =264
101548ccc:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
101548cd0:     	ldr	w8, [sp, #0x120]
101548cd4:     	cmp	w8, #0x6
101548cd8:     	b.ne	0x101548d84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc9c>
101548cdc:     	mov	x9, x21
101548ce0:     	ldr	x20, [x9, #0x490]
101548ce4:     	ldrb	w8, [x20, #0x338]
101548ce8:     	tbz	w8, #0x0, 0x101548d58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc70>
101548cec:     	ldr	x8, [x20, #0x1e0]
101548cf0:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101548cf4:     	cmp	x8, x9
101548cf8:     	b.eq	0x101548d08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc20>
101548cfc:     	add	x0, x20, #0x1e0
101548d00:     	bl	0x101566f7c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collectionsNtB2_5State11is_complete>
101548d04:     	tbz	w0, #0x0, 0x101548d68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc80>
101548d08:     	ldr	x8, [x20, #0x10]
101548d0c:     	cmp	x8, #0x2
101548d10:     	b.eq	0x101548d34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc4c>
101548d14:     	ldr	x8, [x20, #0xa8]
101548d18:     	cbz	x8, 0x101548d34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc4c>
101548d1c:     	str	wzr, [x19]
101548d20:     	mov	w8, #0xc                ; =12
101548d24:     	strb	w8, [x19, #0x8]
101548d28:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548d2c:     	add	x8, x8, #0x5c8
101548d30:     	b	0x101548d7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc94>
101548d34:     	ldr	x8, [x21, #0x4c0]
101548d38:     	cbz	x8, 0x101548d58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc70>
101548d3c:     	str	wzr, [x19]
101548d40:     	mov	w8, #0xc                ; =12
101548d44:     	strb	w8, [x19, #0x8]
101548d48:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548d4c:     	add	x8, x8, #0x59f
101548d50:     	mov	w9, #0x29               ; =41
101548d54:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548d58:     	strb	wzr, [x20, #0x460]
101548d5c:     	mov	w8, #0x6                ; =6
101548d60:     	str	w8, [x19]
101548d64:     	b	0x101548188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101548d68:     	str	wzr, [x19]
101548d6c:     	mov	w8, #0xc                ; =12
101548d70:     	strb	w8, [x19, #0x8]
101548d74:     	adrp	x8, 0x107555000 <_anon.99617498846789129750b3326436f5d5.433+0xe07>
101548d78:     	add	x8, x8, #0x5f4
101548d7c:     	mov	w9, #0x2c               ; =44
101548d80:     	b	0x101548184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101548d84:     	add	x9, sp, #0x120
101548d88:     	ldur	q0, [x9, #0x14]
101548d8c:     	stur	q0, [x19, #0x14]
101548d90:     	ldur	q0, [x9, #0x24]
101548d94:     	stur	q0, [x19, #0x24]
101548d98:     	ldur	q0, [x9, #0x34]
101548d9c:     	stur	q0, [x19, #0x34]
101548da0:     	ldr	q0, [sp, #0x160]
101548da4:     	str	q0, [x19, #0x40]
101548da8:     	ldur	q0, [x9, #0x4]
101548dac:     	stur	q0, [x19, #0x4]
101548db0:     	str	w8, [x19]
101548db4:     	b	0x101548188 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101548db8:     	adrp	x8, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548dbc:     	add	x8, x8, #0xdb0
101548dc0:     	mov	x0, x2
101548dc4:     	mov	x2, x8
101548dc8:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548dcc:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548dd0:     	add	x2, x2, #0xdc8
101548dd4:     	mov	x0, x25
101548dd8:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548ddc:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
101548de0:     	add	x2, x2, #0xae0
101548de4:     	mov	x0, #0x0                ; =0
101548de8:     	mov	x1, #0x0                ; =0
101548dec:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548df0:     	adrp	x2, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
101548df4:     	add	x2, x2, #0x368
101548df8:     	mov	x0, x8
101548dfc:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e00:     	adrp	x2, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
101548e04:     	add	x2, x2, #0x4e8
101548e08:     	mov	x0, x8
101548e0c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e10:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548e14:     	add	x2, x2, #0xde0
101548e18:     	mov	x0, x8
101548e1c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e20:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548e24:     	add	x2, x2, #0xdf8
101548e28:     	mov	x0, x20
101548e2c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e30:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548e34:     	add	x2, x2, #0xe10
101548e38:     	mov	x0, x20
101548e3c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e40:     	adrp	x2, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548e44:     	add	x2, x2, #0xe40
101548e48:     	mov	x0, x20
101548e4c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e50:     	adrp	x2, 0x107f0d000 <_anon.99617498846789129750b3326436f5d5.679+0x310>
101548e54:     	add	x2, x2, #0x500
101548e58:     	mov	x0, x9
101548e5c:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e60:     	adrp	x9, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548e64:     	add	x9, x9, #0xe28
101548e68:     	mov	x0, x2
101548e6c:     	mov	x1, x8
101548e70:     	mov	x2, x9
101548e74:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e78:     	adrp	x8, 0x107f0c000 <_anon.99617498846789129750b3326436f5d5.224+0x520>
101548e7c:     	add	x8, x8, #0xe58
101548e80:     	mov	x0, x2
101548e84:     	mov	x2, x8
101548e88:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e8c:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
101548e90:     	add	x2, x2, #0xaf8
101548e94:     	mov	x1, x8
101548e98:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101548e9c:     	mov	x19, x0
101548ea0:     	ldr	x8, [x21, #0x490]
101548ea4:     	add	x0, x8, #0x1e0
101548ea8:     	add	x1, sp, #0x178
101548eac:     	mov	w2, #0x108              ; =264
101548eb0:     	bl	0x103a08fe4 <dyld_stub_binder+0x103a08fe4>
101548eb4:     	ldr	w8, [sp, #0x120]
101548eb8:     	cmp	w8, #0x6
101548ebc:     	b.eq	0x101548ef0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xe08>
101548ec0:     	add	x0, sp, #0x120
101548ec4:     	bl	0x10152bff0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101548ec8:     	mov	x0, x19
101548ecc:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
101548ed0:     	mov	x19, x0
101548ed4:     	add	x0, sp, #0x18
101548ed8:     	bl	0x10152c34c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101548edc:     	b	0x101548ef0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xe08>
101548ee0:     	bl	0x103a07a14 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101548ee4:     	mov	x19, x0
101548ee8:     	mov	w8, #0x2                ; =2
101548eec:     	str	x8, [x21, #0x220]
101548ef0:     	mov	x0, x19
101548ef4:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
101548ef8:     	mov	x19, x0
101548efc:     	add	x0, sp, #0x178
101548f00:     	bl	0x10152aaa4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
101548f04:     	mov	x0, x19
101548f08:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
101548f0c:     	mov	x19, x0
101548f10:     	add	x0, sp, #0x178
101548f14:     	bl	0x10152aaa4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
101548f18:     	mov	x0, x19
101548f1c:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
