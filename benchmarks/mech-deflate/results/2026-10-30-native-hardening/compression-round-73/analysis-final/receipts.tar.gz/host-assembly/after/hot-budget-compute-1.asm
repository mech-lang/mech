
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010236f294 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
10236f294:     	stp	x28, x27, [sp, #-0x60]!
10236f298:     	stp	x26, x25, [sp, #0x10]
10236f29c:     	stp	x24, x23, [sp, #0x20]
10236f2a0:     	stp	x22, x21, [sp, #0x30]
10236f2a4:     	stp	x20, x19, [sp, #0x40]
10236f2a8:     	stp	x29, x30, [sp, #0x50]
10236f2ac:     	add	x29, sp, #0x50
10236f2b0:     	sub	sp, sp, #0x1a0
10236f2b4:     	ldr	x9, [x0, #0xd0]
10236f2b8:     	adds	x13, x9, x1
10236f2bc:     	b.hs	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f2c0:     	ldr	x21, [x0, #0xc8]
10236f2c4:     	ldr	x26, [x0, #0xe8]
10236f2c8:     	ldr	x28, [x0, #0xf8]
10236f2cc:     	ldr	x25, [x0, #0x108]
10236f2d0:     	ldp	x22, x23, [x0, #0x118]
10236f2d4:     	ldr	x9, [x0]
10236f2d8:     	cmp	x9, #0x1
10236f2dc:     	b.ne	0x10236f348 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
10236f2e0:     	cmp	x23, #0x10, lsl #12     ; =0x10000
10236f2e4:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f2e8:     	mov	w9, #0x1000000          ; =16777216
10236f2ec:     	cmp	x26, x9
10236f2f0:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f2f4:     	mov	w9, #0x1000000          ; =16777216
10236f2f8:     	cmp	x13, x9
10236f2fc:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f300:     	mov	w9, #0x1000000          ; =16777216
10236f304:     	cmp	x28, x9
10236f308:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f30c:     	mov	w9, #0x1000000          ; =16777216
10236f310:     	cmp	x25, x9
10236f314:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f318:     	cmp	x22, #0x10, lsl #12     ; =0x10000
10236f31c:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f320:     	cmp	x21, #0x10, lsl #12     ; =0x10000
10236f324:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f328:     	ldr	x9, [x0, #0x8]
10236f32c:     	cmp	x13, x9
10236f330:     	b.hi	0x10236f340 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10236f334:     	ldr	x9, [x0, #0x10]
10236f338:     	cmp	x21, x9
10236f33c:     	b.ls	0x10236f480 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10236f340:     	mov	w9, #0x2                ; =2
10236f344:     	b	0x10236f488 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f4>
10236f348:     	ldp	x24, x2, [x0, #0xd8]
10236f34c:     	ldr	x20, [x0, #0xf0]
10236f350:     	ldr	x9, [x0, #0x100]
10236f354:     	ldr	x1, [x0, #0x110]
10236f358:     	ldr	x15, [x0, #0x128]
10236f35c:     	ldr	x27, [x0, #0x18]
10236f360:     	cmp	x27, #0x2
10236f364:     	b.ne	0x10236f3d8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x144>
10236f368:     	mov	x19, x0
10236f36c:     	mov	x27, x8
10236f370:     	stp	x21, x13, [x29, #-0xf0]
10236f374:     	mov	x21, x13
10236f378:     	stp	x24, x2, [x29, #-0xe0]
10236f37c:     	stp	x26, x20, [x29, #-0xd0]
10236f380:     	stp	x28, x9, [x29, #-0xc0]
10236f384:     	stp	x25, x1, [x29, #-0xb0]
10236f388:     	stp	x22, x23, [x29, #-0xa0]
10236f38c:     	stur	x15, [x29, #-0x90]
10236f390:     	sub	x8, x29, #0x88
10236f394:     	sub	x0, x29, #0xf0
10236f398:     	bl	0x10237dd3c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
10236f39c:     	ldurb	w8, [x29, #-0x88]
10236f3a0:     	cmp	w8, #0x8
10236f3a4:     	b.ne	0x10236f454 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1c0>
10236f3a8:     	add	x0, sp, #0xd0
10236f3ac:     	sub	x1, x29, #0xf0
10236f3b0:     	bl	0x10236b8dc <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
10236f3b4:     	mov	x8, x27
10236f3b8:     	ldrb	w9, [sp, #0xd0]
10236f3bc:     	cmp	w9, #0x8
10236f3c0:     	b.eq	0x10236f478 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e4>
10236f3c4:     	ldp	q0, q1, [sp, #0xd0]
10236f3c8:     	stp	q0, q1, [x8]
10236f3cc:     	ldr	x9, [sp, #0xf0]
10236f3d0:     	str	x9, [x8, #0x20]
10236f3d4:     	b	0x10236f48c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f3d8:     	str	x9, [sp, #0xc0]
10236f3dc:     	ldr	x10, [x0, #0x20]
10236f3e0:     	ldp	x11, x9, [x0, #0x38]
10236f3e4:     	stp	x9, x10, [sp, #0xb0]
10236f3e8:     	ldp	x10, x9, [x0, #0x48]
10236f3ec:     	stp	x9, x11, [sp, #0xa0]
10236f3f0:     	ldr	x9, [x0, #0x58]
10236f3f4:     	stp	x9, x10, [sp, #0x90]
10236f3f8:     	ldp	x10, x9, [x0, #0x60]
10236f3fc:     	str	x9, [sp, #0x88]
10236f400:     	ldp	x11, x9, [x0, #0x70]
10236f404:     	stp	x0, x9, [sp, #0x78]
10236f408:     	ldp	x6, x12, [x0, #0x80]
10236f40c:     	ldp	x4, x7, [x0, #0x90]
10236f410:     	ldr	x3, [x0, #0xa0]
10236f414:     	ldp	w5, w14, [x0, #0xb8]
10236f418:     	ldr	x9, [x0, #0xc0]
10236f41c:     	str	x9, [sp, #0xc8]
10236f420:     	adrp	x0, 0x108073000 <__mi_heap_main+0xb28>
10236f424:     	add	x0, x0, #0x550
10236f428:     	ldr	x9, [x0]
10236f42c:     	blr	x9
10236f430:     	mov	x19, x0
10236f434:     	ldrb	w9, [x0, #0x48]
10236f438:     	cmp	w9, #0x1
10236f43c:     	b.eq	0x10236f508 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x274>
10236f440:     	cmp	w9, #0x2
10236f444:     	b.ne	0x10236f4ac <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x218>
10236f448:     	adrp	x0, 0x108035000 <_anon.686517066f445f70c1782692b9896900.7+0x55ef8>
10236f44c:     	add	x0, x0, #0xc48
10236f450:     	bl	0x103a0727c <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10236f454:     	sub	x8, x29, #0x88
10236f458:     	ldp	q0, q1, [x8]
10236f45c:     	stp	q0, q1, [sp, #0xd0]
10236f460:     	ldur	x8, [x29, #-0x68]
10236f464:     	str	x8, [sp, #0xf0]
10236f468:     	mov	x8, x27
10236f46c:     	ldrb	w9, [sp, #0xd0]
10236f470:     	cmp	w9, #0x8
10236f474:     	b.ne	0x10236f3c4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x130>
10236f478:     	mov	x0, x19
10236f47c:     	mov	x13, x21
10236f480:     	str	x13, [x0, #0xd0]
10236f484:     	mov	w9, #0x8                ; =8
10236f488:     	strb	w9, [x8]
10236f48c:     	add	sp, sp, #0x1a0
10236f490:     	ldp	x29, x30, [sp, #0x50]
10236f494:     	ldp	x20, x19, [sp, #0x40]
10236f498:     	ldp	x22, x21, [sp, #0x30]
10236f49c:     	ldp	x24, x23, [sp, #0x20]
10236f4a0:     	ldp	x26, x25, [sp, #0x10]
10236f4a4:     	ldp	x28, x27, [sp], #0x60
10236f4a8:     	ret
10236f4ac:     	stp	x1, x15, [sp, #0x10]
10236f4b0:     	adrp	x1, 0x10274f000 <__RINvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local6native4lazy7destroyINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident10text_index6ActiveEEB1L_+0x9c>
10236f4b4:     	add	x1, x1, #0x164
10236f4b8:     	mov	x0, x19
10236f4bc:     	str	x8, [sp, #0x20]
10236f4c0:     	stp	x6, x13, [sp, #0x50]
10236f4c4:     	stp	x14, x7, [sp, #0x30]
10236f4c8:     	str	x2, [sp, #0x8]
10236f4cc:     	stp	x3, x4, [sp, #0x40]
10236f4d0:     	str	w5, [sp, #0x2c]
10236f4d4:     	stp	x12, x11, [sp, #0x60]
10236f4d8:     	str	x10, [sp, #0x70]
10236f4dc:     	bl	0x102e73e00 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10236f4e0:     	ldp	x11, x10, [sp, #0x68]
10236f4e4:     	ldp	x13, x12, [sp, #0x58]
10236f4e8:     	ldp	x7, x3, [sp, #0x38]
10236f4ec:     	ldp	x4, x6, [sp, #0x48]
10236f4f0:     	ldr	w5, [sp, #0x2c]
10236f4f4:     	ldp	x2, x1, [sp, #0x8]
10236f4f8:     	ldp	x15, x8, [sp, #0x18]
10236f4fc:     	ldr	x14, [sp, #0x30]
10236f500:     	mov	w9, #0x1                ; =1
10236f504:     	strb	w9, [x19, #0x48]
10236f508:     	str	x10, [sp, #0x70]
10236f50c:     	ldr	x9, [x19]
10236f510:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10236f514:     	cmp	x9, x10
10236f518:     	b.hs	0x10236f728 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x494>
10236f51c:     	add	x10, x9, #0x1
10236f520:     	str	x10, [x19]
10236f524:     	ldr	x10, [x19, #0x8]
10236f528:     	cbz	x10, 0x10236f5d0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x33c>
10236f52c:     	stp	x12, x11, [sp, #0x60]
10236f530:     	ldr	x11, [x10, #0x10]
10236f534:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
10236f538:     	cmp	x11, x12
10236f53c:     	b.hs	0x10236f734 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x4a0>
10236f540:     	ldr	x10, [x10, #0x58]
10236f544:     	str	x9, [x19]
10236f548:     	ldr	x9, [sp, #0xc8]
10236f54c:     	cmp	x10, x9
10236f550:     	b.ne	0x10236f5d4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x340>
10236f554:     	stp	x7, x3, [sp, #0x38]
10236f558:     	stp	x4, x6, [sp, #0x48]
10236f55c:     	str	w5, [sp, #0x2c]
10236f560:     	str	x14, [sp, #0x30]
10236f564:     	mov	x19, x8
10236f568:     	stp	x21, x13, [x29, #-0xf0]
10236f56c:     	str	x13, [sp, #0x58]
10236f570:     	stp	x24, x2, [x29, #-0xe0]
10236f574:     	mov	x24, x2
10236f578:     	stp	x26, x20, [x29, #-0xd0]
10236f57c:     	ldr	x8, [sp, #0xc0]
10236f580:     	stp	x28, x8, [x29, #-0xc0]
10236f584:     	stp	x25, x1, [x29, #-0xb0]
10236f588:     	mov	x26, x1
10236f58c:     	stp	x22, x23, [x29, #-0xa0]
10236f590:     	mov	x20, x15
10236f594:     	stur	x15, [x29, #-0x90]
10236f598:     	sub	x8, x29, #0x88
10236f59c:     	sub	x0, x29, #0xf0
10236f5a0:     	bl	0x10237dd3c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
10236f5a4:     	ldurb	w8, [x29, #-0x88]
10236f5a8:     	cmp	w8, #0x8
10236f5ac:     	b.ne	0x10236f5dc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
10236f5b0:     	cmp	x27, #0x1
10236f5b4:     	mov	x8, x19
10236f5b8:     	ldr	x11, [sp, #0xb8]
10236f5bc:     	b.ne	0x10236f5f4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
10236f5c0:     	cmp	x23, x11
10236f5c4:     	b.ls	0x10236f5f4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
10236f5c8:     	mov	w9, #0x0                ; =0
10236f5cc:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f5d0:     	str	x9, [x19]
10236f5d4:     	strb	wzr, [x8]
10236f5d8:     	b	0x10236f48c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f5dc:     	sub	x8, x29, #0x88
10236f5e0:     	ldp	q0, q1, [x8]
10236f5e4:     	stp	q0, q1, [x19]
10236f5e8:     	ldur	x8, [x29, #-0x68]
10236f5ec:     	str	x8, [x19, #0x20]
10236f5f0:     	b	0x10236f48c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f5f4:     	ldp	x9, x11, [sp, #0xa8]
10236f5f8:     	cmp	x9, #0x1
10236f5fc:     	b.ne	0x10236f614 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
10236f600:     	cmp	x28, x11
10236f604:     	b.ls	0x10236f614 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
10236f608:     	mov	w9, #0x2                ; =2
10236f60c:     	mov	x23, x28
10236f610:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f614:     	ldp	x9, x11, [sp, #0x98]
10236f618:     	cmp	x9, #0x1
10236f61c:     	b.ne	0x10236f634 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
10236f620:     	cmp	x25, x11
10236f624:     	b.ls	0x10236f634 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
10236f628:     	mov	w9, #0x3                ; =3
10236f62c:     	mov	x23, x25
10236f630:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f634:     	ldr	x9, [sp, #0x90]
10236f638:     	cmp	x9, #0x1
10236f63c:     	ldr	x11, [sp, #0x70]
10236f640:     	b.ne	0x10236f658 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
10236f644:     	cmp	x22, x11
10236f648:     	b.ls	0x10236f658 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
10236f64c:     	mov	w9, #0x4                ; =4
10236f650:     	mov	x23, x22
10236f654:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f658:     	ldr	x9, [sp, #0x88]
10236f65c:     	cmp	x9, #0x1
10236f660:     	ldr	x11, [sp, #0x68]
10236f664:     	b.ne	0x10236f67c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
10236f668:     	cmp	x21, x11
10236f66c:     	b.ls	0x10236f67c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
10236f670:     	mov	w9, #0x5                ; =5
10236f674:     	mov	x23, x21
10236f678:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f67c:     	ldr	x9, [sp, #0x80]
10236f680:     	cmp	x9, #0x1
10236f684:     	ldp	x11, x13, [sp, #0x50]
10236f688:     	b.ne	0x10236f6a0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
10236f68c:     	cmp	x13, x11
10236f690:     	b.ls	0x10236f6a0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
10236f694:     	mov	w9, #0x6                ; =6
10236f698:     	mov	x23, x13
10236f69c:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f6a0:     	ldr	x9, [sp, #0x60]
10236f6a4:     	cmp	x9, #0x1
10236f6a8:     	ldr	x11, [sp, #0x48]
10236f6ac:     	b.ne	0x10236f6c4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
10236f6b0:     	cmp	x24, x11
10236f6b4:     	b.ls	0x10236f6c4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
10236f6b8:     	mov	w9, #0x7                ; =7
10236f6bc:     	mov	x23, x24
10236f6c0:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f6c4:     	ldp	x9, x11, [sp, #0x38]
10236f6c8:     	cmp	x9, #0x1
10236f6cc:     	b.ne	0x10236f6e8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
10236f6d0:     	mov	x24, x26
10236f6d4:     	cmp	x26, x11
10236f6d8:     	b.ls	0x10236f6e8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
10236f6dc:     	mov	w9, #0x8                ; =8
10236f6e0:     	mov	x23, x24
10236f6e4:     	b	0x10236f70c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
10236f6e8:     	ldr	w9, [sp, #0x2c]
10236f6ec:     	cmp	w9, #0x1
10236f6f0:     	ldr	x0, [sp, #0x78]
10236f6f4:     	ldr	x11, [sp, #0x30]
10236f6f8:     	b.ne	0x10236f480 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10236f6fc:     	cmp	w11, w20
10236f700:     	b.hs	0x10236f480 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
10236f704:     	mov	w23, w20
10236f708:     	mov	w9, #0xa                ; =10
10236f70c:     	mov	w10, #0x6               ; =6
10236f710:     	strb	w10, [x8]
10236f714:     	strb	w9, [x8, #0x1]
10236f718:     	mov	w9, #0x1                ; =1
10236f71c:     	strb	w9, [x8, #0x2]
10236f720:     	stp	x23, x11, [x8, #0x8]
10236f724:     	b	0x10236f48c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
10236f728:     	adrp	x0, 0x108037000 <_anon.ba72328133aea471241396b2e22b4c0e.308+0x188>
10236f72c:     	add	x0, x0, #0x280
10236f730:     	bl	0x103a07930 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236f734:     	adrp	x0, 0x108037000 <_anon.ba72328133aea471241396b2e22b4c0e.308+0x188>
10236f738:     	add	x0, x0, #0x298
10236f73c:     	bl	0x103a07930 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236f740:     	brk	#0x1
10236f744:     	ldr	x8, [x19]
10236f748:     	sub	x8, x8, #0x1
10236f74c:     	str	x8, [x19]
10236f750:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
