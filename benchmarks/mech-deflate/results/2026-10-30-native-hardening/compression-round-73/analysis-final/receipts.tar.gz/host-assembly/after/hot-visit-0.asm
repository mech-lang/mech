
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101527598 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>:
101527598:     	sub	sp, sp, #0x50
10152759c:     	stp	x22, x21, [sp, #0x20]
1015275a0:     	stp	x20, x19, [sp, #0x30]
1015275a4:     	stp	x29, x30, [sp, #0x40]
1015275a8:     	add	x29, sp, #0x40
1015275ac:     	cbz	x0, 0x101527660 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015275b0:     	ldr	x8, [x0]
1015275b4:     	cmp	x8, #0x1
1015275b8:     	b.ne	0x1015275f8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x60>
1015275bc:     	ldr	x8, [x1]
1015275c0:     	ldr	x9, [x8, #0x10]
1015275c4:     	cmp	x9, #0x2
1015275c8:     	b.eq	0x101527660 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015275cc:     	ldr	x9, [x0, #0x8]
1015275d0:     	ldr	x10, [x8, #0x40]
1015275d4:     	cmp	x9, x10
1015275d8:     	b.hs	0x101527660 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015275dc:     	ldr	x8, [x8, #0x38]
1015275e0:     	mov	w10, #0x3c8             ; =968
1015275e4:     	madd	x8, x9, x10, x8
1015275e8:     	ldr	x8, [x8, #0x290]
1015275ec:     	cbz	x8, 0x101527660 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
1015275f0:     	mov	x1, x0
1015275f4:     	b	0x101527664 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
1015275f8:     	ldr	x8, [x0, #0x18]
1015275fc:     	cbz	x8, 0x1015276bc <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x124>
101527600:     	ldr	x8, [x0, #0x10]
101527604:     	ldr	w8, [x8]
101527608:     	ldr	x9, [x1, #0x20]
10152760c:     	ldr	x9, [x9]
101527610:     	cmp	x9, x8
101527614:     	b.ne	0x101527660 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101527618:     	ldr	x8, [x1, #0x18]
10152761c:     	ldr	x8, [x8]
101527620:     	cmp	x8, #0x2
101527624:     	b.ne	0x101527660 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101527628:     	mov	x21, x1
10152762c:     	ldr	x9, [x1, #0x8]
101527630:     	add	x8, sp, #0x8
101527634:     	mov	x20, x0
101527638:     	mov	x0, x9
10152763c:     	bl	0x10236980c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101527640:     	ldr	x8, [sp, #0x8]
101527644:     	cmp	x8, #0x1
101527648:     	b.ne	0x101527660 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
10152764c:     	mov	x0, x20
101527650:     	ldr	x8, [sp, #0x10]
101527654:     	ldr	x19, [x20, #0x30]
101527658:     	cmp	x8, x19
10152765c:     	b.hs	0x10152767c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xe4>
101527660:     	mov	x1, #0x0                ; =0
101527664:     	mov	x0, x1
101527668:     	ldp	x29, x30, [sp, #0x40]
10152766c:     	ldp	x20, x19, [sp, #0x30]
101527670:     	ldp	x22, x21, [sp, #0x20]
101527674:     	add	sp, sp, #0x50
101527678:     	ret
10152767c:     	ldr	x8, [x21, #0x10]
101527680:     	ldr	x9, [x8, #0x18]!
101527684:     	ldur	x21, [x8, #-0x8]
101527688:     	cbz	x9, 0x1015276a0 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x108>
10152768c:     	mov	x0, x8
101527690:     	bl	0x102369f74 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101527694:     	mov	x8, x0
101527698:     	mov	x0, x20
10152769c:     	b	0x1015276a4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x10c>
1015276a0:     	ldur	x8, [x8, #-0x10]
1015276a4:     	mov	x1, #0x0                ; =0
1015276a8:     	subs	x8, x21, x8
1015276ac:     	b.lo	0x101527664 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
1015276b0:     	cmp	x8, x19
1015276b4:     	b.hs	0x1015275f0 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x58>
1015276b8:     	b	0x101527664 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
1015276bc:     	adrp	x2, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
1015276c0:     	add	x2, x2, #0xae0
1015276c4:     	mov	x0, #0x0                ; =0
1015276c8:     	mov	x1, #0x0                ; =0
1015276cc:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
