
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014c8b58 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_>:
1014c8b58:     	sub	sp, sp, #0xd0
1014c8b5c:     	stp	x28, x27, [sp, #0x70]
1014c8b60:     	stp	x26, x25, [sp, #0x80]
1014c8b64:     	stp	x24, x23, [sp, #0x90]
1014c8b68:     	stp	x22, x21, [sp, #0xa0]
1014c8b6c:     	stp	x20, x19, [sp, #0xb0]
1014c8b70:     	stp	x29, x30, [sp, #0xc0]
1014c8b74:     	add	x29, sp, #0xc0
1014c8b78:     	ldrb	w8, [x0, #0x3c]
1014c8b7c:     	cmp	w8, #0x1
1014c8b80:     	b.ne	0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8b84:     	ldp	x21, x24, [x0, #0x10]
1014c8b88:     	ldp	x9, x8, [x0, #0x20]
1014c8b8c:     	stp	x9, x8, [sp]
1014c8b90:     	ldp	x27, x19, [x1]
1014c8b94:     	ldp	x8, x9, [x1, #0x28]
1014c8b98:     	stp	x9, x8, [sp, #0x18]
1014c8b9c:     	ldp	x8, x9, [x1, #0x10]
1014c8ba0:     	str	x9, [sp, #0x28]
1014c8ba4:     	str	x8, [sp, #0x10]
1014c8ba8:     	add	x26, x21, #0x8
1014c8bac:     	lsl	x8, x24, #6
1014c8bb0:     	sub	x20, x8, x24, lsl #3
1014c8bb4:     	mov	x23, x21
1014c8bb8:     	b	0x1014c8bf0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x98>
1014c8bbc:     	add	x8, sp, #0x30
1014c8bc0:     	add	x0, x9, #0x10
1014c8bc4:     	add	x1, x25, #0x18
1014c8bc8:     	bl	0x102e3238c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c8bcc:     	ldr	x8, [sp, #0x30]
1014c8bd0:     	cmp	x8, #0x1e
1014c8bd4:     	b.ne	0x1014c8d7c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x224>
1014c8bd8:     	ldr	x8, [sp, #0x38]
1014c8bdc:     	add	x23, x23, #0x38
1014c8be0:     	add	x26, x26, #0x38
1014c8be4:     	sub	x20, x20, #0x38
1014c8be8:     	cmp	x8, x28
1014c8bec:     	b.ne	0x1014c8da0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c8bf0:     	cmp	x20, #0x0
1014c8bf4:     	cset	w22, eq
1014c8bf8:     	cbz	x20, 0x1014c8da0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c8bfc:     	ldr	x0, [x23, #0x30]
1014c8c00:     	cmp	x0, x19
1014c8c04:     	b.hs	0x1014c8dc4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x26c>
1014c8c08:     	add	x8, x27, x0, lsl #5
1014c8c0c:     	ldrb	w9, [x8]
1014c8c10:     	cmp	w9, #0x3
1014c8c14:     	b.ne	0x1014c8c48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0xf0>
1014c8c18:     	ldr	x0, [x8, #0x8]
1014c8c1c:     	ldr	x8, [sp, #0x28]
1014c8c20:     	cmp	x0, x8
1014c8c24:     	b.hs	0x1014c8dd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x27c>
1014c8c28:     	ldr	x8, [sp, #0x20]
1014c8c2c:     	cmp	x0, x8
1014c8c30:     	b.hs	0x1014c8de4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x28c>
1014c8c34:     	lsl	x8, x0, #6
1014c8c38:     	ldr	x9, [sp, #0x10]
1014c8c3c:     	ldr	x9, [x9, x8]
1014c8c40:     	cbnz	x9, 0x1014c8c80 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x128>
1014c8c44:     	b	0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8c48:     	ldp	q0, q1, [x8]
1014c8c4c:     	stp	q0, q1, [sp, #0x30]
1014c8c50:     	ldr	x8, [sp, #0x18]
1014c8c54:     	ldr	x8, [x8]
1014c8c58:     	ldr	x1, [x8]
1014c8c5c:     	add	x0, sp, #0x58
1014c8c60:     	add	x2, sp, #0x30
1014c8c64:     	bl	0x1014cf64c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c8c68:     	ldr	x8, [sp, #0x58]
1014c8c6c:     	cmp	x8, #0x1
1014c8c70:     	b.ne	0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8c74:     	ldr	x8, [sp, #0x60]
1014c8c78:     	cbz	x8, 0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8c7c:     	ldr	x9, [x8]
1014c8c80:     	add	x8, sp, #0x30
1014c8c84:     	add	x0, x9, #0x10
1014c8c88:     	add	x1, x23, #0x18
1014c8c8c:     	bl	0x102e3238c <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014c8c90:     	ldr	x8, [sp, #0x30]
1014c8c94:     	cmp	x8, #0x1e
1014c8c98:     	b.ne	0x1014c8d7c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x224>
1014c8c9c:     	ldr	x28, [sp, #0x38]
1014c8ca0:     	ldr	w8, [x23]
1014c8ca4:     	cmp	w8, #0x2
1014c8ca8:     	b.eq	0x1014c8ccc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x174>
1014c8cac:     	cmp	w8, #0x1
1014c8cb0:     	b.ne	0x1014c8da0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c8cb4:     	ldr	x8, [x26], #0x38
1014c8cb8:     	add	x23, x23, #0x38
1014c8cbc:     	sub	x20, x20, #0x38
1014c8cc0:     	cmp	x8, x28
1014c8cc4:     	b.eq	0x1014c8bf0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x98>
1014c8cc8:     	b	0x1014c8da0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c8ccc:     	ldur	w8, [x26, #-0x4]
1014c8cd0:     	ldr	x9, [sp, #0x8]
1014c8cd4:     	cmp	x9, x8
1014c8cd8:     	b.ls	0x1014c8da0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c8cdc:     	ldr	x9, [sp]
1014c8ce0:     	ldr	x8, [x9, x8, lsl #3]
1014c8ce4:     	cmp	x8, x24
1014c8ce8:     	b.hs	0x1014c8da0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014c8cec:     	mov	w9, #0x38               ; =56
1014c8cf0:     	madd	x25, x8, x9, x21
1014c8cf4:     	ldr	x0, [x25, #0x30]
1014c8cf8:     	cmp	x0, x19
1014c8cfc:     	b.hs	0x1014c8dc4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x26c>
1014c8d00:     	add	x8, x27, x0, lsl #5
1014c8d04:     	ldrb	w9, [x8]
1014c8d08:     	cmp	w9, #0x3
1014c8d0c:     	b.ne	0x1014c8d40 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x1e8>
1014c8d10:     	ldr	x0, [x8, #0x8]
1014c8d14:     	ldr	x8, [sp, #0x28]
1014c8d18:     	cmp	x0, x8
1014c8d1c:     	b.hs	0x1014c8dd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x27c>
1014c8d20:     	ldr	x8, [sp, #0x20]
1014c8d24:     	cmp	x0, x8
1014c8d28:     	b.hs	0x1014c8de4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x28c>
1014c8d2c:     	lsl	x8, x0, #6
1014c8d30:     	ldr	x9, [sp, #0x10]
1014c8d34:     	ldr	x9, [x9, x8]
1014c8d38:     	cbnz	x9, 0x1014c8bbc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x64>
1014c8d3c:     	b	0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8d40:     	ldp	q0, q1, [x8]
1014c8d44:     	stp	q0, q1, [sp, #0x30]
1014c8d48:     	ldr	x8, [sp, #0x18]
1014c8d4c:     	ldr	x8, [x8]
1014c8d50:     	ldr	x1, [x8]
1014c8d54:     	add	x0, sp, #0x58
1014c8d58:     	add	x2, sp, #0x30
1014c8d5c:     	bl	0x1014cf64c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014c8d60:     	ldr	x8, [sp, #0x58]
1014c8d64:     	cmp	x8, #0x1
1014c8d68:     	b.ne	0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8d6c:     	ldr	x8, [sp, #0x60]
1014c8d70:     	cbz	x8, 0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8d74:     	ldr	x9, [x8]
1014c8d78:     	b	0x1014c8bbc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x64>
1014c8d7c:     	and	x8, x8, #0x1e
1014c8d80:     	cmp	x8, #0x14
1014c8d84:     	b.ne	0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8d88:     	ldr	x1, [sp, #0x38]
1014c8d8c:     	cbz	x1, 0x1014c8d9c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014c8d90:     	ldr	x0, [sp, #0x40]
1014c8d94:     	mov	w2, #0x1                ; =1
1014c8d98:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014c8d9c:     	mov	w22, #0x0               ; =0
1014c8da0:     	mov	x0, x22
1014c8da4:     	ldp	x29, x30, [sp, #0xc0]
1014c8da8:     	ldp	x20, x19, [sp, #0xb0]
1014c8dac:     	ldp	x22, x21, [sp, #0xa0]
1014c8db0:     	ldp	x24, x23, [sp, #0x90]
1014c8db4:     	ldp	x26, x25, [sp, #0x80]
1014c8db8:     	ldp	x28, x27, [sp, #0x70]
1014c8dbc:     	add	sp, sp, #0xd0
1014c8dc0:     	ret
1014c8dc4:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c8dc8:     	add	x2, x2, #0x968
1014c8dcc:     	mov	x1, x19
1014c8dd0:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c8dd4:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c8dd8:     	add	x2, x2, #0x980
1014c8ddc:     	ldr	x1, [sp, #0x28]
1014c8de0:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014c8de4:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014c8de8:     	add	x2, x2, #0x998
1014c8dec:     	ldr	x1, [sp, #0x20]
1014c8df0:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
