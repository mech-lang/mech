
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152f240 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>:
10152f240:     	stp	x20, x19, [sp, #-0x20]!
10152f244:     	stp	x29, x30, [sp, #0x10]
10152f248:     	add	x29, sp, #0x10
10152f24c:     	mov	x19, x4
10152f250:     	cmp	x3, x2
10152f254:     	b.hs	0x10152f2a4 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_+0x64>
10152f258:     	mov	w8, #0x170              ; =368
10152f25c:     	madd	x8, x3, x8, x1
10152f260:     	add	x9, x8, #0x148
10152f264:     	ldr	q0, [x9]
10152f268:     	stur	q0, [x0, #0x4]
10152f26c:     	ldp	q0, q1, [x19]
10152f270:     	stur	q0, [x0, #0x18]
10152f274:     	ldr	w8, [x8, #0x158]
10152f278:     	str	w8, [x0, #0x14]
10152f27c:     	stur	q1, [x0, #0x28]
10152f280:     	ldr	q0, [x19, #0x20]
10152f284:     	stur	q0, [x0, #0x38]
10152f288:     	ldr	x8, [x19, #0x30]
10152f28c:     	str	x8, [x0, #0x48]
10152f290:     	mov	w8, #0x3                ; =3
10152f294:     	str	w8, [x0]
10152f298:     	ldp	x29, x30, [sp, #0x10]
10152f29c:     	ldp	x20, x19, [sp], #0x20
10152f2a0:     	ret
10152f2a4:     	adrp	x8, 0x107f0b000 <_anon.e2ffb521149947bfd5635acf21d07e13.383+0x80>
10152f2a8:     	add	x8, x8, #0x888
10152f2ac:     	mov	x0, x3
10152f2b0:     	mov	x1, x2
10152f2b4:     	mov	x2, x8
10152f2b8:     	bl	0x103a07a2c <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152f2bc:     	brk	#0x1
10152f2c0:     	mov	x20, x0
10152f2c4:     	mov	x0, x19
10152f2c8:     	bl	0x10152c184 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10152f2cc:     	mov	x0, x20
10152f2d0:     	bl	0x103a08df8 <dyld_stub_binder+0x103a08df8>
