
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015ca160 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>:
1015ca160:     	stp	x28, x27, [sp, #-0x60]!
1015ca164:     	stp	x26, x25, [sp, #0x10]
1015ca168:     	stp	x24, x23, [sp, #0x20]
1015ca16c:     	stp	x22, x21, [sp, #0x30]
1015ca170:     	stp	x20, x19, [sp, #0x40]
1015ca174:     	stp	x29, x30, [sp, #0x50]
1015ca178:     	add	x29, sp, #0x50
1015ca17c:     	sub	sp, sp, #0x810
1015ca180:     	str	xzr, [sp]
1015ca184:     	add	x9, x2, #0x1d
1015ca188:     	cmp	x9, #0x1f
1015ca18c:     	b.hi	0x1015ca1b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
1015ca190:     	mov	w10, #-0x10000001       ; =-268435457
1015ca194:     	lsr	w10, w10, w9
1015ca198:     	tbz	w10, #0x0, 0x1015ca1b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
1015ca19c:     	adrp	x10, 0x10755a000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x2b98>
1015ca1a0:     	add	x10, x10, #0x6c0
1015ca1a4:     	ldr	x22, [x10, x9, lsl #3]
1015ca1a8:     	ldr	x9, [x0, #0x238]
1015ca1ac:     	cmp	x9, #0x3
1015ca1b0:     	b.ne	0x1015ca1cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6c>
1015ca1b4:     	b	0x1015ca1f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
1015ca1b8:     	sub	x21, x2, #0x3
1015ca1bc:     	mov	w22, #0x3               ; =3
1015ca1c0:     	ldr	x9, [x0, #0x238]
1015ca1c4:     	cmp	x9, #0x3
1015ca1c8:     	b.eq	0x1015ca1f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
1015ca1cc:     	ldr	w9, [x0, #0x268]
1015ca1d0:     	cbz	w9, 0x1015ca1f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
1015ca1d4:     	str	wzr, [x8]
1015ca1d8:     	mov	w9, #0xc                ; =12
1015ca1dc:     	strb	w9, [x8, #0x8]
1015ca1e0:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ca1e4:     	add	x9, x9, #0xc2
1015ca1e8:     	mov	w10, #0x25              ; =37
1015ca1ec:     	stp	x9, x10, [x8, #0x10]
1015ca1f0:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015ca1f4:     	cmp	x22, #0xb
1015ca1f8:     	b.eq	0x1015ca2d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
1015ca1fc:     	add	x27, sp, #0x550
1015ca200:     	add	x24, sp, #0x440
1015ca204:     	add	x26, sp, #0x330
1015ca208:     	add	x25, sp, #0x220
1015ca20c:     	cmp	x22, #0x1d
1015ca210:     	b.eq	0x1015ca264 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104>
1015ca214:     	cmp	x22, #0x1f
1015ca218:     	b.ne	0x1015ca300 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a0>
1015ca21c:     	ldp	x20, x28, [x3]
1015ca220:     	ldr	x10, [x3, #0x10]
1015ca224:     	ldp	x12, x11, [x0, #0xc0]
1015ca228:     	ldp	x26, x19, [x0, #0xd0]
1015ca22c:     	ldp	x22, x25, [x0, #0xe0]
1015ca230:     	ldr	w9, [x0, #0xf0]
1015ca234:     	mov	w13, #0x2               ; =2
1015ca238:     	str	x13, [x0, #0xc0]
1015ca23c:     	cbz	x12, 0x1015ca37c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x21c>
1015ca240:     	cmp	x12, #0x2
1015ca244:     	b.ne	0x1015ca398 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x238>
1015ca248:     	str	wzr, [x8]
1015ca24c:     	mov	w9, #0xc                ; =12
1015ca250:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015ca254:     	add	x10, x10, #0x9b9
1015ca258:     	stp	x9, x10, [x8, #0x8]
1015ca25c:     	mov	w9, #0x20               ; =32
1015ca260:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015ca264:     	ldr	x19, [x0, #0x498]
1015ca268:     	ldr	x9, [x19, #0x270]
1015ca26c:     	cmp	x1, x9
1015ca270:     	b.hs	0x1015ca344 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
1015ca274:     	ldr	x9, [x19, #0x268]
1015ca278:     	add	x9, x9, x1, lsl #4
1015ca27c:     	ldr	w10, [x9]
1015ca280:     	tbz	w10, #0x0, 0x1015ca344 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
1015ca284:     	ldr	x9, [x9, #0x8]
1015ca288:     	ldr	x10, [x19, #0x258]
1015ca28c:     	cmp	x9, x10
1015ca290:     	b.hs	0x1015cca60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2900>
1015ca294:     	ldr	x10, [x19, #0x250]
1015ca298:     	mov	w11, #0x160             ; =352
1015ca29c:     	madd	x21, x9, x11, x10
1015ca2a0:     	mov	x20, x21
1015ca2a4:     	ldr	x10, [x20, #0x30]!
1015ca2a8:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
1015ca2ac:     	cmp	x10, x11
1015ca2b0:     	b.ne	0x1015ca498 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x338>
1015ca2b4:     	str	wzr, [x8]
1015ca2b8:     	mov	w9, #0xc                ; =12
1015ca2bc:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015ca2c0:     	add	x10, x10, #0x941
1015ca2c4:     	stp	x9, x10, [x8, #0x8]
1015ca2c8:     	mov	w9, #0x23               ; =35
1015ca2cc:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015ca2d0:     	mov	x9, x0
1015ca2d4:     	mov	x0, x8
1015ca2d8:     	mov	x2, x1
1015ca2dc:     	mov	x1, x9
1015ca2e0:     	add	sp, sp, #0x810
1015ca2e4:     	ldp	x29, x30, [sp, #0x50]
1015ca2e8:     	ldp	x20, x19, [sp, #0x40]
1015ca2ec:     	ldp	x22, x21, [sp, #0x30]
1015ca2f0:     	ldp	x24, x23, [sp, #0x20]
1015ca2f4:     	ldp	x26, x25, [sp, #0x10]
1015ca2f8:     	ldp	x28, x27, [sp], #0x60
1015ca2fc:     	b	0x1015bccfc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
1015ca300:     	ldr	x9, [x0, #0xc0]
1015ca304:     	cmp	x9, #0x2
1015ca308:     	b.ne	0x1015ca360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x200>
1015ca30c:     	cmp	x22, #0x15
1015ca310:     	b.gt	0x1015ca454 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4>
1015ca314:     	sub	x9, x22, #0xc
1015ca318:     	cmp	x9, #0x4
1015ca31c:     	b.hs	0x1015ca720 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5c0>
1015ca320:     	lsr	x9, x1, #32
1015ca324:     	cbz	x9, 0x1015ca4d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x378>
1015ca328:     	str	wzr, [x8]
1015ca32c:     	mov	w9, #0xc                ; =12
1015ca330:     	strb	w9, [x8, #0x8]
1015ca334:     	adrp	x9, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ca338:     	add	x9, x9, #0xd2f
1015ca33c:     	mov	w10, #0x15              ; =21
1015ca340:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015ca344:     	str	wzr, [x8]
1015ca348:     	mov	w9, #0xc                ; =12
1015ca34c:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015ca350:     	add	x10, x10, #0x84d
1015ca354:     	stp	x9, x10, [x8, #0x8]
1015ca358:     	mov	w9, #0x2d               ; =45
1015ca35c:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015ca360:     	str	wzr, [x8]
1015ca364:     	mov	w9, #0xc                ; =12
1015ca368:     	strb	w9, [x8, #0x8]
1015ca36c:     	adrp	x9, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0xb98>
1015ca370:     	add	x9, x9, #0xf02
1015ca374:     	mov	w10, #0x35              ; =53
1015ca378:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015ca37c:     	str	wzr, [x8]
1015ca380:     	mov	w9, #0xc                ; =12
1015ca384:     	strb	w9, [x8, #0x8]
1015ca388:     	adrp	x9, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015ca38c:     	add	x9, x9, #0xb6c
1015ca390:     	mov	w10, #0x27              ; =39
1015ca394:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015ca398:     	ldr	x21, [x0, #0x498]
1015ca39c:     	ldr	x12, [x21, #0x178]
1015ca3a0:     	cmp	x11, x12
1015ca3a4:     	b.hs	0x1015ca418 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
1015ca3a8:     	ldr	x12, [x21, #0x170]
1015ca3ac:     	add	x12, x12, x11, lsl #4
1015ca3b0:     	ldr	x11, [x12]
1015ca3b4:     	ldr	x13, [x21, #0x160]
1015ca3b8:     	cmp	x11, x13
1015ca3bc:     	b.hs	0x1015ca418 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
1015ca3c0:     	ldr	x12, [x12, #0x8]
1015ca3c4:     	ldr	x13, [x21, #0x158]
1015ca3c8:     	mov	w14, #0x48              ; =72
1015ca3cc:     	madd	x11, x11, x14, x13
1015ca3d0:     	ldr	x13, [x11, #0x28]
1015ca3d4:     	cmp	x12, x13
1015ca3d8:     	b.hs	0x1015ca418 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
1015ca3dc:     	ldr	x13, [x11, #0x20]
1015ca3e0:     	mov	w14, #0x110             ; =272
1015ca3e4:     	madd	x23, x12, x14, x13
1015ca3e8:     	mov	x24, x23
1015ca3ec:     	ldr	x13, [x24, #0x30]!
1015ca3f0:     	mov	x12, #-0x8000000000000000 ; =-9223372036854775808
1015ca3f4:     	cmp	x13, x12
1015ca3f8:     	b.ne	0x1015ca990 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x830>
1015ca3fc:     	str	wzr, [x8]
1015ca400:     	mov	w9, #0xc                ; =12
1015ca404:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015ca408:     	add	x10, x10, #0x9d9
1015ca40c:     	stp	x9, x10, [x8, #0x8]
1015ca410:     	mov	w9, #0x1f               ; =31
1015ca414:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015ca418:     	str	wzr, [x8]
1015ca41c:     	mov	w9, #0xc                ; =12
1015ca420:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015ca424:     	add	x10, x10, #0xb36
1015ca428:     	stp	x9, x10, [x8, #0x8]
1015ca42c:     	mov	w9, #0x29               ; =41
1015ca430:     	str	x9, [x8, #0x18]
1015ca434:     	add	sp, sp, #0x810
1015ca438:     	ldp	x29, x30, [sp, #0x50]
1015ca43c:     	ldp	x20, x19, [sp, #0x40]
1015ca440:     	ldp	x22, x21, [sp, #0x30]
1015ca444:     	ldp	x24, x23, [sp, #0x20]
1015ca448:     	ldp	x26, x25, [sp, #0x10]
1015ca44c:     	ldp	x28, x27, [sp], #0x60
1015ca450:     	ret
1015ca454:     	sub	x9, x22, #0x17
1015ca458:     	cmp	x9, #0x4
1015ca45c:     	b.hs	0x1015ca758 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f8>
1015ca460:     	cmn	x2, #0x17
1015ca464:     	b.gt	0x1015ca550 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f0>
1015ca468:     	cmn	x2, #0x18
1015ca46c:     	b.eq	0x1015ca874 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x714>
1015ca470:     	cmn	x2, #0x17
1015ca474:     	b.ne	0x1015ca858 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f8>
1015ca478:     	ldr	x9, [x0, #0xf8]
1015ca47c:     	cmp	x9, #0x2
1015ca480:     	b.ne	0x1015ca9e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x880>
1015ca484:     	str	wzr, [x8]
1015ca488:     	mov	w9, #0xc                ; =12
1015ca48c:     	adrp	x10, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ca490:     	add	x10, x10, #0x410
1015ca494:     	b	0x1015ca9b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x850>
1015ca498:     	ldp	x10, x11, [x21, #0x68]
1015ca49c:     	sub	x23, x10, #0x18
1015ca4a0:     	lsl	x10, x11, #5
1015ca4a4:     	cbz	x10, 0x1015ca708 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a8>
1015ca4a8:     	ldr	x11, [x23, #0x18]
1015ca4ac:     	add	x23, x23, #0x20
1015ca4b0:     	sub	x10, x10, #0x20
1015ca4b4:     	cmp	x11, x1
1015ca4b8:     	b.ne	0x1015ca4a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344>
1015ca4bc:     	ldr	w10, [x23]
1015ca4c0:     	cmp	w10, #0x5
1015ca4c4:     	b.eq	0x1015ca9bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x85c>
1015ca4c8:     	cmp	w10, #0x6
1015ca4cc:     	b.ne	0x1015ca708 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a8>
1015ca4d0:     	mov	w22, #0x8               ; =8
1015ca4d4:     	b	0x1015ca9c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x860>
1015ca4d8:     	ldr	x9, [x0, #0x4b8]
1015ca4dc:     	lsr	x10, x9, #59
1015ca4e0:     	cbnz	x10, 0x1015cb748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15e8>
1015ca4e4:     	mov	x10, #-0x21             ; =-33
1015ca4e8:     	movk	x10, #0x7ff, lsl #48
1015ca4ec:     	cmp	x9, x10
1015ca4f0:     	b.hi	0x1015cb748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15e8>
1015ca4f4:     	mov	x25, x2
1015ca4f8:     	mov	x21, x3
1015ca4fc:     	mov	x19, x1
1015ca500:     	mov	x23, x8
1015ca504:     	mov	x20, x0
1015ca508:     	ldr	x26, [x0, #0x490]
1015ca50c:     	lsl	x8, x9, #5
1015ca510:     	and	x8, x8, #0xffffffffffffffc0
1015ca514:     	add	x22, x8, #0x400
1015ca518:     	ldr	x8, [x26, #0x310]
1015ca51c:     	cbz	x8, 0x1015ca920 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c0>
1015ca520:     	ldr	x2, [x26, #0x308]
1015ca524:     	add	x8, sp, #0x550
1015ca528:     	add	x0, x26, #0x310
1015ca52c:     	mov	x1, x22
1015ca530:     	bl	0x1023640c0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015ca534:     	ldrb	w8, [sp, #0x550]
1015ca538:     	cmp	w8, #0x8
1015ca53c:     	b.ne	0x1015ca940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7e0>
1015ca540:     	mov	x0, x20
1015ca544:     	mov	x1, x19
1015ca548:     	mov	x10, x25
1015ca54c:     	b	0x1015caed0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd70>
1015ca550:     	cmn	x2, #0x16
1015ca554:     	b.eq	0x1015ca89c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x73c>
1015ca558:     	cmn	x2, #0x15
1015ca55c:     	b.ne	0x1015ca858 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f8>
1015ca560:     	ldr	x9, [x0, #0x498]
1015ca564:     	str	x9, [sp, #0x660]
1015ca568:     	ldr	x19, [x3, #0x10]
1015ca56c:     	ldr	x10, [x9, #0x5a0]
1015ca570:     	cmp	x19, x10
1015ca574:     	b.hs	0x1015caa78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x918>
1015ca578:     	ldr	x9, [x9, #0x598]
1015ca57c:     	mov	w10, #0x58              ; =88
1015ca580:     	madd	x22, x19, x10, x9
1015ca584:     	ldr	w9, [x22, #0x3c]
1015ca588:     	cmp	x1, x9
1015ca58c:     	b.ne	0x1015cab48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
1015ca590:     	ldr	x24, [x0, #0x490]
1015ca594:     	ldr	w9, [x24, #0x2f0]
1015ca598:     	cmp	w9, #0x1
1015ca59c:     	b.ne	0x1015cab48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
1015ca5a0:     	ldr	w9, [x24, #0x2f4]
1015ca5a4:     	cmp	w9, w1
1015ca5a8:     	b.ne	0x1015cab48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
1015ca5ac:     	ldr	w9, [x24, #0x2e8]
1015ca5b0:     	cmp	w9, #0x1
1015ca5b4:     	b.ne	0x1015cab48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
1015ca5b8:     	ldr	w9, [x22, #0x34]
1015ca5bc:     	ldr	w10, [x24, #0x2ec]
1015ca5c0:     	cmp	w10, w9
1015ca5c4:     	b.ne	0x1015cab48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
1015ca5c8:     	ldrb	w10, [x24, #0x460]
1015ca5cc:     	cmp	w10, #0x1
1015ca5d0:     	b.ne	0x1015cab48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9e8>
1015ca5d4:     	mov	x23, x8
1015ca5d8:     	str	x0, [sp, #0x58]
1015ca5dc:     	ldr	x8, [x0, #0xf8]
1015ca5e0:     	cmp	x8, #0x2
1015ca5e4:     	b.ne	0x1015cb528 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015ca5e8:     	ldr	x8, [sp, #0x58]
1015ca5ec:     	ldrb	w8, [x8, #0x508]
1015ca5f0:     	tbnz	w8, #0x0, 0x1015cb528 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015ca5f4:     	lsl	x0, x9, #1
1015ca5f8:     	ldr	x8, [sp, #0x58]
1015ca5fc:     	ldr	x1, [x8, #0x4b8]
1015ca600:     	cmp	x0, x1
1015ca604:     	b.hs	0x1015cd77c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x361c>
1015ca608:     	ldr	x8, [sp, #0x58]
1015ca60c:     	ldr	x9, [x8, #0x4b0]
1015ca610:     	ldr	x28, [x9, x0, lsl #3]
1015ca614:     	ldr	x8, [x8, #0x3c0]
1015ca618:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015ca61c:     	cmp	x8, x9
1015ca620:     	b.ne	0x1015cb7dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x167c>
1015ca624:     	mov	x21, x3
1015ca628:     	bl	0x102e6f83c <__RNvNtNtCsgirOGyZpP7g_3std6thread9functions21available_parallelism>
1015ca62c:     	cmp	x0, #0x1
1015ca630:     	b.ne	0x1015ca640 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e0>
1015ca634:     	mov	x0, x1
1015ca638:     	bl	0x1015ac0b0 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtNtB4_3num7nonzero7NonZerojENtNtNtCsgirOGyZpP7g_3std2io5error5ErrorEECs7fdMCt8k5K6_8mech_gpu>
1015ca63c:     	mov	w1, #0x1                ; =1
1015ca640:     	mov	w8, #0x20               ; =32
1015ca644:     	cmp	x1, #0x20
1015ca648:     	csel	x20, x1, x8, lo
1015ca64c:     	sub	x8, x28, #0x1
1015ca650:     	cmp	x8, x20
1015ca654:     	b.hs	0x1015cb528 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015ca658:     	ldr	x8, [x22, #0x28]
1015ca65c:     	str	x8, [sp, #0x50]
1015ca660:     	cmp	x8, x20
1015ca664:     	b.hi	0x1015cb528 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015ca668:     	ldr	x8, [x22, #0x20]
1015ca66c:     	str	x8, [sp, #0x48]
1015ca670:     	add	x8, sp, #0x550
1015ca674:     	add	x0, x24, #0x3b8
1015ca678:     	bl	0x102363bdc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015ca67c:     	ldr	x8, [sp, #0x550]
1015ca680:     	cmp	x8, #0x1
1015ca684:     	b.ne	0x1015cb528 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015ca688:     	ldr	x8, [sp, #0x558]
1015ca68c:     	cbz	x8, 0x1015cb528 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13c8>
1015ca690:     	ldr	x8, [x21]
1015ca694:     	str	x8, [sp, #0x40]
1015ca698:     	cbz	x8, 0x1015cbdf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c98>
1015ca69c:     	ldr	x8, [x21, #0x8]
1015ca6a0:     	cbz	x8, 0x1015cbdf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c98>
1015ca6a4:     	mov	x21, x8
1015ca6a8:     	ldr	x9, [x8, #0x38]
1015ca6ac:     	ldr	x8, [sp, #0x58]
1015ca6b0:     	cmp	x9, x8
1015ca6b4:     	b.ne	0x1015ca6ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
1015ca6b8:     	ldr	x8, [x21]
1015ca6bc:     	cmp	x8, #0x25
1015ca6c0:     	b.ne	0x1015ca6ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
1015ca6c4:     	ldr	x8, [x21, #0x10]
1015ca6c8:     	ldr	x9, [sp, #0x660]
1015ca6cc:     	ldr	x9, [x9, #0x360]
1015ca6d0:     	cmp	x8, x9
1015ca6d4:     	b.lo	0x1015ca6ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
1015ca6d8:     	ldr	x8, [x21, #0x28]
1015ca6dc:     	cbz	x8, 0x1015ca6ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
1015ca6e0:     	ldr	x8, [x21, #0x70]
1015ca6e4:     	cmp	x8, #0x4
1015ca6e8:     	b.ne	0x1015ccd7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c1c>
1015ca6ec:     	str	wzr, [x23]
1015ca6f0:     	mov	w8, #0xc                ; =12
1015ca6f4:     	strb	w8, [x23, #0x8]
1015ca6f8:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ca6fc:     	add	x8, x8, #0x2a2
1015ca700:     	mov	w9, #0x28               ; =40
1015ca704:     	b	0x1015cb3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
1015ca708:     	str	wzr, [x8]
1015ca70c:     	mov	w9, #0xc                ; =12
1015ca710:     	strb	w9, [x8, #0x8]
1015ca714:     	adrp	x9, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015ca718:     	add	x9, x9, #0x87b
1015ca71c:     	b	0x1015cab24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
1015ca720:     	mov	x19, x2
1015ca724:     	mov	x23, x3
1015ca728:     	cmp	x22, #0x14
1015ca72c:     	b.ne	0x1015ca7cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
1015ca730:     	ldr	x9, [x0, #0x490]
1015ca734:     	ldr	x10, [x0, #0x498]
1015ca738:     	mov	x24, x0
1015ca73c:     	mov	x0, x9
1015ca740:     	mov	x20, x1
1015ca744:     	mov	x1, x10
1015ca748:     	mov	x2, x20
1015ca74c:     	mov	x25, x8
1015ca750:     	bl	0x1015db2fc <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015ca754:     	b	0x1015ca78c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x62c>
1015ca758:     	mov	x19, x2
1015ca75c:     	mov	x23, x3
1015ca760:     	cmp	x22, #0x16
1015ca764:     	b.ne	0x1015ca7cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
1015ca768:     	ldr	x9, [x0, #0x490]
1015ca76c:     	ldr	x10, [x0, #0x498]
1015ca770:     	mov	x24, x0
1015ca774:     	mov	x0, x9
1015ca778:     	mov	x20, x1
1015ca77c:     	mov	x1, x10
1015ca780:     	mov	x2, x20
1015ca784:     	mov	x25, x8
1015ca788:     	bl	0x1015c5790 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
1015ca78c:     	mov	x1, x20
1015ca790:     	mov	x8, x25
1015ca794:     	mov	x9, x0
1015ca798:     	mov	x0, x24
1015ca79c:     	tbz	w9, #0x0, 0x1015ca7cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x66c>
1015ca7a0:     	mov	x20, x8
1015ca7a4:     	add	x8, sp, #0x550
1015ca7a8:     	mov	x24, x0
1015ca7ac:     	mov	x25, x1
1015ca7b0:     	bl	0x1015c9328 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
1015ca7b4:     	ldr	w8, [sp, #0x550]
1015ca7b8:     	cmp	w8, #0x6
1015ca7bc:     	b.ne	0x1015ca96c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x80c>
1015ca7c0:     	mov	x8, x20
1015ca7c4:     	mov	x0, x24
1015ca7c8:     	mov	x1, x25
1015ca7cc:     	ldr	x9, [x0, #0x490]
1015ca7d0:     	ldr	w10, [x9, #0x2f0]
1015ca7d4:     	tbz	w10, #0x0, 0x1015ca83c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6dc>
1015ca7d8:     	ldr	w10, [x9, #0x2f4]
1015ca7dc:     	cmp	x1, x10
1015ca7e0:     	b.ne	0x1015ca83c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6dc>
1015ca7e4:     	mov	x3, x23
1015ca7e8:     	ldr	x23, [x0, #0x498]
1015ca7ec:     	mov	x20, x1
1015ca7f0:     	mov	x25, x0
1015ca7f4:     	cmp	x22, #0x1a
1015ca7f8:     	b.gt	0x1015cad38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbd8>
1015ca7fc:     	sub	x10, x22, #0x13
1015ca800:     	cmp	x10, #0x4
1015ca804:     	b.hs	0x1015cb014 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xeb4>
1015ca808:     	mov	x0, x8
1015ca80c:     	mov	x1, x25
1015ca810:     	mov	x2, x20
1015ca814:     	mov	x4, x3
1015ca818:     	mov	x3, x19
1015ca81c:     	add	sp, sp, #0x810
1015ca820:     	ldp	x29, x30, [sp, #0x50]
1015ca824:     	ldp	x20, x19, [sp, #0x40]
1015ca828:     	ldp	x22, x21, [sp, #0x30]
1015ca82c:     	ldp	x24, x23, [sp, #0x20]
1015ca830:     	ldp	x26, x25, [sp, #0x10]
1015ca834:     	ldp	x28, x27, [sp], #0x60
1015ca838:     	b	0x1015d989c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation19retained_map_helper>
1015ca83c:     	str	wzr, [x8]
1015ca840:     	mov	w9, #0xc                ; =12
1015ca844:     	strb	w9, [x8, #0x8]
1015ca848:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ca84c:     	add	x9, x9, #0x9f
1015ca850:     	mov	w10, #0x23              ; =35
1015ca854:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015ca858:     	str	wzr, [x8]
1015ca85c:     	mov	w9, #0xc                ; =12
1015ca860:     	strb	w9, [x8, #0x8]
1015ca864:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ca868:     	add	x9, x9, #0x4da
1015ca86c:     	mov	w10, #0x20              ; =32
1015ca870:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015ca874:     	ldr	x9, [x0, #0xf8]
1015ca878:     	cmp	x9, #0x2
1015ca87c:     	b.ne	0x1015caa94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x934>
1015ca880:     	str	wzr, [x8]
1015ca884:     	mov	w9, #0xc                ; =12
1015ca888:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ca88c:     	add	x10, x10, #0xab3
1015ca890:     	stp	x9, x10, [x8, #0x8]
1015ca894:     	mov	w9, #0x26               ; =38
1015ca898:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015ca89c:     	ldr	x9, [x3]
1015ca8a0:     	ldr	x22, [x0, #0x498]
1015ca8a4:     	ldr	x10, [x22, #0x5a0]
1015ca8a8:     	cmp	x9, x10
1015ca8ac:     	b.hs	0x1015cab2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
1015ca8b0:     	ldp	x11, x10, [x3, #0x8]
1015ca8b4:     	orr	x10, x11, x10
1015ca8b8:     	cbnz	x10, 0x1015cab64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
1015ca8bc:     	ldr	x10, [x22, #0x598]
1015ca8c0:     	mov	w11, #0x58              ; =88
1015ca8c4:     	madd	x21, x9, x11, x10
1015ca8c8:     	ldr	w10, [x21, #0x44]
1015ca8cc:     	cmp	x1, x10
1015ca8d0:     	b.ne	0x1015cab64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
1015ca8d4:     	ldr	x10, [x0, #0x490]
1015ca8d8:     	ldr	w11, [x10, #0x2f0]
1015ca8dc:     	cmp	w11, #0x1
1015ca8e0:     	b.ne	0x1015cab64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
1015ca8e4:     	ldr	w11, [x10, #0x2f4]
1015ca8e8:     	cmp	w11, w1
1015ca8ec:     	b.ne	0x1015cab64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
1015ca8f0:     	ldrb	w11, [x10, #0x460]
1015ca8f4:     	cmp	w11, #0x1
1015ca8f8:     	b.ne	0x1015cab64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa04>
1015ca8fc:     	mov	x19, x8
1015ca900:     	ldr	x8, [x0, #0x3c0]
1015ca904:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
1015ca908:     	cmp	x8, x11
1015ca90c:     	b.ne	0x1015cb458 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12f8>
1015ca910:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015ca914:     	ldr	q0, [x8, #0xdc0]
1015ca918:     	stur	q0, [x19, #0x8]
1015ca91c:     	b	0x1015cb5f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1490>
1015ca920:     	bl	0x102363b50 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
1015ca924:     	tbz	w0, #0x0, 0x1015cab80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa20>
1015ca928:     	mov	w11, #0x0               ; =0
1015ca92c:     	mov	w10, #0x0               ; =0
1015ca930:     	mov	x8, #0x0                ; =0
1015ca934:     	mov	w13, #0x7               ; =7
1015ca938:     	mov	x12, x23
1015ca93c:     	b	0x1015cacfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
1015ca940:     	ldr	x8, [sp, #0x550]
1015ca944:     	ldr	x14, [sp, #0x558]
1015ca948:     	ldr	x9, [sp, #0x560]
1015ca94c:     	and	x10, x8, #0xffff
1015ca950:     	cmp	x10, #0x606
1015ca954:     	mov	x12, x23
1015ca958:     	b.ne	0x1015cace4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb84>
1015ca95c:     	mov	w10, #0x0               ; =0
1015ca960:     	mov	w13, #0x6               ; =6
1015ca964:     	mov	x8, x14
1015ca968:     	b	0x1015cacfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
1015ca96c:     	ldr	q0, [sp, #0x570]
1015ca970:     	ldr	q1, [sp, #0x580]
1015ca974:     	stp	q0, q1, [x20, #0x20]
1015ca978:     	ldr	q0, [sp, #0x590]
1015ca97c:     	str	q0, [x20, #0x40]
1015ca980:     	ldr	q0, [sp, #0x560]
1015ca984:     	ldr	q1, [sp, #0x550]
1015ca988:     	stp	q1, q0, [x20]
1015ca98c:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015ca990:     	mov	x14, x23
1015ca994:     	ldr	x13, [x14, #0xb0]!
1015ca998:     	cmp	x13, x12
1015ca99c:     	b.ne	0x1015cad7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc1c>
1015ca9a0:     	str	wzr, [x8]
1015ca9a4:     	mov	w9, #0xc                ; =12
1015ca9a8:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015ca9ac:     	add	x10, x10, #0x9f8
1015ca9b0:     	stp	x9, x10, [x8, #0x8]
1015ca9b4:     	mov	w9, #0x21               ; =33
1015ca9b8:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015ca9bc:     	mov	w22, #0x10              ; =16
1015ca9c0:     	ldr	x10, [x3, #0x10]
1015ca9c4:     	cbz	x10, 0x1015cabac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa4c>
1015ca9c8:     	str	wzr, [x8]
1015ca9cc:     	mov	w9, #0xc                ; =12
1015ca9d0:     	strb	w9, [x8, #0x8]
1015ca9d4:     	adrp	x9, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015ca9d8:     	add	x9, x9, #0x84d
1015ca9dc:     	b	0x1015cab24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
1015ca9e0:     	ldr	x23, [x0, #0x498]
1015ca9e4:     	ldr	x11, [x23, #0x5a0]
1015ca9e8:     	ldr	x10, [x0, #0x1c0]
1015ca9ec:     	cmp	x10, x11
1015ca9f0:     	b.hs	0x1015cae88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd28>
1015ca9f4:     	ldr	x21, [x0, #0x490]
1015ca9f8:     	ldr	w11, [x21, #0x2f0]
1015ca9fc:     	cmp	w11, #0x1
1015caa00:     	b.ne	0x1015cb07c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf1c>
1015caa04:     	ldr	x11, [x3, #0x8]
1015caa08:     	cmp	x11, x10
1015caa0c:     	b.ne	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015caa10:     	ldr	x11, [x3, #0x10]
1015caa14:     	cbnz	x11, 0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015caa18:     	cbnz	x9, 0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015caa1c:     	ldr	x9, [x23, #0x598]
1015caa20:     	mov	w11, #0x58              ; =88
1015caa24:     	madd	x24, x10, x11, x9
1015caa28:     	ldr	w26, [x24, #0x48]
1015caa2c:     	cmp	x1, x26
1015caa30:     	b.ne	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015caa34:     	ldr	w9, [x21, #0x2e8]
1015caa38:     	tbz	w9, #0x0, 0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015caa3c:     	ldr	w9, [x24, #0x34]
1015caa40:     	ldr	w10, [x21, #0x2ec]
1015caa44:     	cmp	w10, w9
1015caa48:     	b.ne	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015caa4c:     	ldr	x9, [x24, #0x18]
1015caa50:     	cbz	x9, 0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015caa54:     	mov	x25, x3
1015caa58:     	mov	x20, x0
1015caa5c:     	mov	x22, x8
1015caa60:     	ldr	w19, [x21, #0x2f4]
1015caa64:     	ldr	x8, [x24, #0x10]
1015caa68:     	cmp	x9, #0x1
1015caa6c:     	b.ne	0x1015cb678 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1518>
1015caa70:     	mov	x10, #0x0               ; =0
1015caa74:     	b	0x1015cb69c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x153c>
1015caa78:     	str	wzr, [x8]
1015caa7c:     	mov	w9, #0xc                ; =12
1015caa80:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015caa84:     	add	x10, x10, #0x83c
1015caa88:     	stp	x9, x10, [x8, #0x8]
1015caa8c:     	mov	w9, #0x22               ; =34
1015caa90:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015caa94:     	ldr	x11, [x0, #0x498]
1015caa98:     	ldr	x12, [x11, #0x5a0]
1015caa9c:     	ldr	x10, [x0, #0x1c0]
1015caaa0:     	cmp	x10, x12
1015caaa4:     	b.hs	0x1015caea4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd44>
1015caaa8:     	ldr	x11, [x11, #0x598]
1015caaac:     	mov	w12, #0x58              ; =88
1015caab0:     	madd	x11, x10, x12, x11
1015caab4:     	ldr	w11, [x11, #0x38]
1015caab8:     	cmp	x1, x11
1015caabc:     	b.ne	0x1015cab10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
1015caac0:     	add	x11, x0, #0x1c8
1015caac4:     	ldr	q0, [x11]
1015caac8:     	stur	q0, [x27, #0x8]
1015caacc:     	ldp	x11, x12, [x3]
1015caad0:     	ldr	x13, [x3, #0x10]
1015caad4:     	ldr	x14, [sp, #0x558]
1015caad8:     	ldr	x15, [sp, #0x560]
1015caadc:     	cmp	x11, x10
1015caae0:     	ccmp	x12, x14, #0x0, eq
1015caae4:     	ccmp	x13, x15, #0x0, eq
1015caae8:     	cset	w10, ne
1015caaec:     	cbnz	x9, 0x1015cab10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
1015caaf0:     	cbnz	w10, 0x1015cab10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
1015caaf4:     	ldr	x9, [x0, #0x490]
1015caaf8:     	ldr	w10, [x9, #0x2f0]
1015caafc:     	cbnz	w10, 0x1015cab10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
1015cab00:     	ldr	w10, [x9, #0x2e8]
1015cab04:     	cbnz	w10, 0x1015cab10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
1015cab08:     	ldrb	w10, [x9, #0x338]
1015cab0c:     	tbz	w10, #0x0, 0x1015cb5cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x146c>
1015cab10:     	str	wzr, [x8]
1015cab14:     	mov	w9, #0xc                ; =12
1015cab18:     	strb	w9, [x8, #0x8]
1015cab1c:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cab20:     	add	x9, x9, #0x4ac
1015cab24:     	mov	w10, #0x2e              ; =46
1015cab28:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cab2c:     	str	wzr, [x8]
1015cab30:     	mov	w9, #0xc                ; =12
1015cab34:     	adrp	x10, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cab38:     	add	x10, x10, #0x300
1015cab3c:     	stp	x9, x10, [x8, #0x8]
1015cab40:     	mov	w9, #0x14               ; =20
1015cab44:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015cab48:     	str	wzr, [x8]
1015cab4c:     	mov	w9, #0xc                ; =12
1015cab50:     	strb	w9, [x8, #0x8]
1015cab54:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cab58:     	add	x9, x9, #0x2ca
1015cab5c:     	mov	w10, #0x36              ; =54
1015cab60:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cab64:     	str	wzr, [x8]
1015cab68:     	mov	w9, #0xc                ; =12
1015cab6c:     	strb	w9, [x8, #0x8]
1015cab70:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cab74:     	add	x9, x9, #0x3ea
1015cab78:     	mov	w10, #0x26              ; =38
1015cab7c:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cab80:     	ldr	x8, [x26, #0x300]
1015cab84:     	ldr	x9, [x26, #0x308]
1015cab88:     	adds	x8, x8, x22
1015cab8c:     	b.hs	0x1015cbc18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ab8>
1015cab90:     	cmp	x8, x9
1015cab94:     	b.ls	0x1015caec0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd60>
1015cab98:     	mov	x12, x23
1015cab9c:     	mov	w11, #0x0               ; =0
1015caba0:     	mov	w10, #0x0               ; =0
1015caba4:     	mov	w13, #0x6               ; =6
1015caba8:     	b	0x1015cacfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
1015cabac:     	ldr	x10, [x0, #0x490]
1015cabb0:     	ldr	x10, [x10, #0x3c0]
1015cabb4:     	cbz	x10, 0x1015cad1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
1015cabb8:     	ldr	x11, [x10, #0x40]
1015cabbc:     	cmp	x11, #0x2
1015cabc0:     	b.eq	0x1015cad1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
1015cabc4:     	ldr	x11, [x10, #0xd8]
1015cabc8:     	cmp	x11, x9
1015cabcc:     	b.ne	0x1015cad1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
1015cabd0:     	ldr	x11, [x23, x22]
1015cabd4:     	ldr	x12, [x10, #0x78]
1015cabd8:     	cmp	x11, x12
1015cabdc:     	b.hs	0x1015cad1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xbbc>
1015cabe0:     	ldr	x10, [x10, #0x70]
1015cabe4:     	mov	w12, #0x108             ; =264
1015cabe8:     	mul	x11, x11, x12
1015cabec:     	ldr	x10, [x10, x11]
1015cabf0:     	cbnz	x10, 0x1015ca9c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x868>
1015cabf4:     	add	x24, sp, #0x440
1015cabf8:     	stp	x9, x1, [sp, #0x48]
1015cabfc:     	mov	x28, x8
1015cac00:     	ldr	x8, [x0, #0x4d0]
1015cac04:     	cbz	x8, 0x1015cb3c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1260>
1015cac08:     	ldr	x10, [x21, #0xb8]
1015cac0c:     	add	x9, x10, #0x2
1015cac10:     	ldr	x11, [x0, #0x4d8]
1015cac14:     	cmp	x9, x11
1015cac18:     	b.hs	0x1015cb3c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1260>
1015cac1c:     	str	x0, [sp, #0x58]
1015cac20:     	add	x10, x10, #0x3
1015cac24:     	cmp	x10, x11
1015cac28:     	b.hs	0x1015cb3c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1260>
1015cac2c:     	ldr	x9, [x8, x9, lsl #3]
1015cac30:     	ldr	x8, [x8, x10, lsl #3]
1015cac34:     	stp	x9, x8, [sp, #0x38]
1015cac38:     	ldr	q0, [x3]
1015cac3c:     	str	q0, [sp, #0x440]
1015cac40:     	mov	w8, #0x5                ; =5
1015cac44:     	str	x8, [sp, #0x450]
1015cac48:     	add	x0, sp, #0x550
1015cac4c:     	add	x3, sp, #0x440
1015cac50:     	ldp	x2, x1, [sp, #0x50]
1015cac54:     	bl	0x1015bccfc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
1015cac58:     	ldr	w8, [sp, #0x550]
1015cac5c:     	cmp	w8, #0x6
1015cac60:     	b.ne	0x1015cb8bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x175c>
1015cac64:     	ldr	x1, [x19, #0x380]
1015cac68:     	ldr	x8, [sp, #0x50]
1015cac6c:     	cmp	x8, x1
1015cac70:     	b.hs	0x1015cd7e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3680>
1015cac74:     	ldr	x9, [x19, #0x378]
1015cac78:     	mov	w10, #0x170             ; =368
1015cac7c:     	ldr	x8, [sp, #0x50]
1015cac80:     	madd	x8, x8, x10, x9
1015cac84:     	ldp	x8, x9, [x8]
1015cac88:     	cmp	x8, #0x2
1015cac8c:     	sbcs	xzr, x9, xzr
1015cac90:     	b.hs	0x1015cb9f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1894>
1015cac94:     	ldr	x1, [x19, #0x408]
1015cac98:     	ldr	x8, [sp, #0x50]
1015cac9c:     	cmp	x8, x1
1015caca0:     	b.hs	0x1015cd7f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3690>
1015caca4:     	ldr	x9, [x19, #0x400]
1015caca8:     	ldr	x8, [sp, #0x50]
1015cacac:     	add	x9, x9, x8, lsl #9
1015cacb0:     	str	x9, [sp, #0x30]
1015cacb4:     	ldp	x9, x8, [x9]
1015cacb8:     	eor	x9, x9, #0x2
1015cacbc:     	orr	x8, x9, x8
1015cacc0:     	cbnz	x8, 0x1015cba54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18f4>
1015cacc4:     	str	wzr, [x28]
1015cacc8:     	mov	w8, #0xc                ; =12
1015caccc:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cacd0:     	add	x9, x9, #0x87a
1015cacd4:     	stp	x8, x9, [x28, #0x8]
1015cacd8:     	mov	w8, #0x23               ; =35
1015cacdc:     	str	x8, [x28, #0x18]
1015cace0:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cace4:     	mov	x10, x9
1015cace8:     	lsr	x11, x9, #32
1015cacec:     	ldur	q0, [x27, #0x18]
1015cacf0:     	stur	q0, [x29, #-0x70]
1015cacf4:     	mov	w13, #0x7               ; =7
1015cacf8:     	mov	x9, x14
1015cacfc:     	str	wzr, [x12]
1015cad00:     	strb	w13, [x12, #0x8]
1015cad04:     	stp	x8, x9, [x12, #0x10]
1015cad08:     	stp	w10, w11, [x12, #0x20]
1015cad0c:     	ldur	q0, [x29, #-0x70]
1015cad10:     	stur	q0, [x12, #0x28]
1015cad14:     	str	wzr, [x12, #0x38]
1015cad18:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cad1c:     	str	wzr, [x8]
1015cad20:     	mov	w9, #0xc                ; =12
1015cad24:     	adrp	x10, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cad28:     	add	x10, x10, #0x86
1015cad2c:     	stp	x9, x10, [x8, #0x8]
1015cad30:     	mov	w9, #0x2b               ; =43
1015cad34:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015cad38:     	sub	x10, x22, #0x1b
1015cad3c:     	cmp	x10, #0x2
1015cad40:     	b.hs	0x1015cb048 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xee8>
1015cad44:     	ldp	x5, x6, [x3, #0x8]
1015cad48:     	ldr	x4, [x3]
1015cad4c:     	mov	x0, x8
1015cad50:     	mov	x1, x25
1015cad54:     	mov	x2, x20
1015cad58:     	mov	x3, x19
1015cad5c:     	add	sp, sp, #0x810
1015cad60:     	ldp	x29, x30, [sp, #0x50]
1015cad64:     	ldp	x20, x19, [sp, #0x40]
1015cad68:     	ldp	x22, x21, [sp, #0x30]
1015cad6c:     	ldp	x24, x23, [sp, #0x20]
1015cad70:     	ldp	x26, x25, [sp, #0x10]
1015cad74:     	ldp	x28, x27, [sp], #0x60
1015cad78:     	b	0x1015c7d3c <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation17frozen_map_helper>
1015cad7c:     	cbnz	x10, 0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cad80:     	ldr	x12, [x0, #0x490]
1015cad84:     	ldr	w10, [x12, #0x2f0]
1015cad88:     	cmp	w10, #0x1
1015cad8c:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cad90:     	ldr	w10, [x12, #0x2f4]
1015cad94:     	cmp	w10, w9
1015cad98:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cad9c:     	ldr	w9, [x12, #0x2e8]
1015cada0:     	cmp	w9, #0x1
1015cada4:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cada8:     	ldr	w9, [x11, #0x30]
1015cadac:     	ldr	w10, [x12, #0x2ec]
1015cadb0:     	cmp	w10, w9
1015cadb4:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cadb8:     	stp	x14, x12, [sp, #0x38]
1015cadbc:     	stp	x8, x1, [sp, #0x48]
1015cadc0:     	mov	w8, #0x1                ; =1
1015cadc4:     	orr	x8, x8, x9, lsl #1
1015cadc8:     	str	x0, [sp, #0x58]
1015cadcc:     	ldr	x1, [x0, #0x4b8]
1015cadd0:     	cmp	x8, x1
1015cadd4:     	b.hs	0x1015cd75c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35fc>
1015cadd8:     	ldr	x9, [sp, #0x58]
1015caddc:     	ldr	x9, [x9, #0x4b0]
1015cade0:     	ldr	x8, [x9, x8, lsl #3]
1015cade4:     	cmp	x8, #0x1
1015cade8:     	ldp	x9, x8, [sp, #0x40]
1015cadec:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cadf0:     	add	x0, x9, #0x3b8
1015cadf4:     	bl	0x1023645bc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
1015cadf8:     	ldp	x9, x8, [sp, #0x40]
1015cadfc:     	cmp	x0, x26
1015cae00:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cae04:     	cmp	x1, x19
1015cae08:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cae0c:     	add	x8, sp, #0x550
1015cae10:     	add	x0, x9, #0x3b8
1015cae14:     	bl	0x102363bdc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015cae18:     	ldr	x8, [sp, #0x48]
1015cae1c:     	ldr	x9, [sp, #0x550]
1015cae20:     	cmp	x9, #0x1
1015cae24:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cae28:     	ldr	x9, [sp, #0x558]
1015cae2c:     	cmp	x9, x22
1015cae30:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cae34:     	ldr	x9, [sp, #0x560]
1015cae38:     	cmp	x9, x25
1015cae3c:     	b.ne	0x1015cae6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd0c>
1015cae40:     	cbz	x20, 0x1015cbc6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b0c>
1015cae44:     	cmp	x20, #0x2
1015cae48:     	b.eq	0x1015cbc30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ad0>
1015cae4c:     	cmp	x20, #0x3
1015cae50:     	b.ne	0x1015cbc4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015cae54:     	cbnz	x28, 0x1015cbc4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015cae58:     	ldp	x1, x2, [x23, #0x8]
1015cae5c:     	ldr	x0, [sp, #0x50]
1015cae60:     	bl	0x1015dec30 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
1015cae64:     	tbnz	w0, #0x0, 0x1015cbc44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ae4>
1015cae68:     	b	0x1015cbc4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015cae6c:     	str	wzr, [x8]
1015cae70:     	mov	w9, #0xc                ; =12
1015cae74:     	strb	w9, [x8, #0x8]
1015cae78:     	adrp	x9, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cae7c:     	add	x9, x9, #0xb2e
1015cae80:     	mov	w10, #0x3e              ; =62
1015cae84:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cae88:     	str	wzr, [x8]
1015cae8c:     	mov	w9, #0xc                ; =12
1015cae90:     	adrp	x10, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cae94:     	add	x10, x10, #0x431
1015cae98:     	stp	x9, x10, [x8, #0x8]
1015cae9c:     	mov	w9, #0x13               ; =19
1015caea0:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015caea4:     	str	wzr, [x8]
1015caea8:     	mov	w9, #0xc                ; =12
1015caeac:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015caeb0:     	add	x10, x10, #0xad9
1015caeb4:     	stp	x9, x10, [x8, #0x8]
1015caeb8:     	mov	w9, #0x19               ; =25
1015caebc:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015caec0:     	mov	x0, x20
1015caec4:     	mov	x1, x19
1015caec8:     	mov	x10, x25
1015caecc:     	str	x8, [x26, #0x300]
1015caed0:     	add	x8, sp, #0x550
1015caed4:     	cmn	x10, #0xd
1015caed8:     	b.ne	0x1015caef8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xd98>
1015caedc:     	bl	0x1015d2d08 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation17check_prefix_exit>
1015caee0:     	ldr	w8, [sp, #0x550]
1015caee4:     	cmp	w8, #0x6
1015caee8:     	b.ne	0x1015caf2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdcc>
1015caeec:     	mov	x8, x23
1015caef0:     	mov	x9, x25
1015caef4:     	b	0x1015caf50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdf0>
1015caef8:     	bl	0x1015d2e6c <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation19check_prefix_header>
1015caefc:     	ldr	w8, [sp, #0x550]
1015caf00:     	cmp	w8, #0x6
1015caf04:     	b.ne	0x1015caf2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdcc>
1015caf08:     	mov	x9, x25
1015caf0c:     	cmn	x25, #0xa
1015caf10:     	mov	x8, x23
1015caf14:     	b.ne	0x1015caf50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdf0>
1015caf18:     	mov	x1, x20
1015caf1c:     	ldr	x10, [x20, #0xa8]
1015caf20:     	mov	x3, x21
1015caf24:     	cbnz	x10, 0x1015caff8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe98>
1015caf28:     	b	0x1015caf74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe14>
1015caf2c:     	ldr	q0, [sp, #0x570]
1015caf30:     	ldr	q1, [sp, #0x580]
1015caf34:     	stp	q0, q1, [x23, #0x20]
1015caf38:     	ldr	q0, [sp, #0x590]
1015caf3c:     	str	q0, [x23, #0x40]
1015caf40:     	ldr	q0, [sp, #0x560]
1015caf44:     	ldr	q1, [sp, #0x550]
1015caf48:     	stp	q1, q0, [x23]
1015caf4c:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015caf50:     	mov	x3, x21
1015caf54:     	ldp	x10, x11, [x21]
1015caf58:     	ldr	x12, [x21, #0x10]
1015caf5c:     	orr	x10, x10, x11
1015caf60:     	mov	x1, x20
1015caf64:     	ldr	x11, [x20, #0xa8]
1015caf68:     	orr	x11, x12, x11
1015caf6c:     	orr	x10, x10, x11
1015caf70:     	cbnz	x10, 0x1015caff8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe98>
1015caf74:     	ldr	x10, [x1, #0x290]
1015caf78:     	cmp	x10, #0x6
1015caf7c:     	b.ne	0x1015caff8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe98>
1015caf80:     	ldr	x10, [x1, #0x498]
1015caf84:     	ldr	x11, [x10]
1015caf88:     	cmp	x11, #0x2
1015caf8c:     	b.eq	0x1015cbf1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dbc>
1015caf90:     	add	x25, x1, #0x238
1015caf94:     	ldr	x11, [x25]
1015caf98:     	cmp	x11, #0x3
1015caf9c:     	b.eq	0x1015cbf28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dc8>
1015cafa0:     	ldr	x22, [x10, #0x138]
1015cafa4:     	ldr	w11, [x1, #0x280]
1015cafa8:     	cmn	x9, #0xc
1015cafac:     	b.gt	0x1015cb134 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd4>
1015cafb0:     	cmn	x9, #0xd
1015cafb4:     	b.eq	0x1015cb25c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10fc>
1015cafb8:     	cmn	x9, #0xc
1015cafbc:     	b.ne	0x1015cb240 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10e0>
1015cafc0:     	mov	x9, x19
1015cafc4:     	cmp	w11, w9
1015cafc8:     	b.ne	0x1015cafdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe7c>
1015cafcc:     	ldrb	w11, [x1, #0x288]
1015cafd0:     	tbz	w11, #0x0, 0x1015cafdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe7c>
1015cafd4:     	ldrb	w11, [x1, #0x289]
1015cafd8:     	tbz	w11, #0x0, 0x1015cb400 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12a0>
1015cafdc:     	str	wzr, [x8]
1015cafe0:     	mov	w9, #0xc                ; =12
1015cafe4:     	strb	w9, [x8, #0x8]
1015cafe8:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cafec:     	add	x9, x9, #0x7dc
1015caff0:     	mov	w10, #0x29              ; =41
1015caff4:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015caff8:     	str	wzr, [x8]
1015caffc:     	mov	w9, #0xc                ; =12
1015cb000:     	strb	w9, [x8, #0x8]
1015cb004:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb008:     	add	x9, x9, #0x821
1015cb00c:     	mov	w10, #0x24              ; =36
1015cb010:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cb014:     	cmp	x22, #0xa
1015cb018:     	b.ne	0x1015cb098 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf38>
1015cb01c:     	mov	x0, x8
1015cb020:     	mov	x1, x25
1015cb024:     	mov	x2, x20
1015cb028:     	add	sp, sp, #0x810
1015cb02c:     	ldp	x29, x30, [sp, #0x50]
1015cb030:     	ldp	x20, x19, [sp, #0x40]
1015cb034:     	ldp	x22, x21, [sp, #0x30]
1015cb038:     	ldp	x24, x23, [sp, #0x20]
1015cb03c:     	ldp	x26, x25, [sp, #0x10]
1015cb040:     	ldp	x28, x27, [sp], #0x60
1015cb044:     	b	0x1015bd340 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation17begin_closed_tail>
1015cb048:     	cmp	x22, #0x1e
1015cb04c:     	b.ne	0x1015cb098 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf38>
1015cb050:     	mov	x0, x8
1015cb054:     	mov	x1, x25
1015cb058:     	mov	x2, x20
1015cb05c:     	add	sp, sp, #0x810
1015cb060:     	ldp	x29, x30, [sp, #0x50]
1015cb064:     	ldp	x20, x19, [sp, #0x40]
1015cb068:     	ldp	x22, x21, [sp, #0x30]
1015cb06c:     	ldp	x24, x23, [sp, #0x20]
1015cb070:     	ldp	x26, x25, [sp, #0x10]
1015cb074:     	ldp	x28, x27, [sp], #0x60
1015cb078:     	b	0x1015ba0b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB4_10Invocation21begin_numeric_segment>
1015cb07c:     	str	wzr, [x8]
1015cb080:     	mov	w9, #0xc                ; =12
1015cb084:     	strb	w9, [x8, #0x8]
1015cb088:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb08c:     	add	x9, x9, #0x444
1015cb090:     	mov	w10, #0x18              ; =24
1015cb094:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cb098:     	mov	x24, x3
1015cb09c:     	mov	x19, x8
1015cb0a0:     	mov	x0, x9
1015cb0a4:     	mov	x1, x23
1015cb0a8:     	mov	x2, x20
1015cb0ac:     	bl	0x1015c7f90 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation20frozen_native_action>
1015cb0b0:     	tbnz	w0, #0x0, 0x1015cb114 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
1015cb0b4:     	mov	x8, x25
1015cb0b8:     	ldr	x25, [x25, #0x490]
1015cb0bc:     	str	x8, [sp, #0x58]
1015cb0c0:     	ldr	x26, [x8, #0x498]
1015cb0c4:     	mov	x0, x25
1015cb0c8:     	mov	x1, x26
1015cb0cc:     	mov	x2, x20
1015cb0d0:     	bl	0x1015db3cc <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
1015cb0d4:     	tbnz	w0, #0x0, 0x1015cb114 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
1015cb0d8:     	mov	x0, x25
1015cb0dc:     	mov	x1, x26
1015cb0e0:     	mov	x2, x20
1015cb0e4:     	bl	0x1015db2fc <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015cb0e8:     	tbnz	w0, #0x0, 0x1015cb114 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
1015cb0ec:     	mov	x0, x25
1015cb0f0:     	mov	x1, x26
1015cb0f4:     	mov	x2, x20
1015cb0f8:     	bl	0x1015db364 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_exit>
1015cb0fc:     	tbnz	w0, #0x0, 0x1015cb114 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
1015cb100:     	mov	x0, x25
1015cb104:     	mov	x1, x26
1015cb108:     	mov	x2, x20
1015cb10c:     	bl	0x1015c5790 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
1015cb110:     	tbz	w0, #0x0, 0x1015cb638 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14d8>
1015cb114:     	str	wzr, [x19]
1015cb118:     	mov	w8, #0xc                ; =12
1015cb11c:     	strb	w8, [x19, #0x8]
1015cb120:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb124:     	add	x8, x8, #0x74
1015cb128:     	mov	w9, #0x2b               ; =43
1015cb12c:     	stp	x8, x9, [x19, #0x10]
1015cb130:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb134:     	cmn	x9, #0xb
1015cb138:     	b.eq	0x1015cb304 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11a4>
1015cb13c:     	cmn	x9, #0xa
1015cb140:     	b.ne	0x1015cb240 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x10e0>
1015cb144:     	ldrb	w21, [x1, #0x284]
1015cb148:     	ldr	x2, [x1, #0x278]
1015cb14c:     	mov	x8, x1
1015cb150:     	add	x0, sp, #0x550
1015cb154:     	mov	x1, x3
1015cb158:     	add	x3, x8, #0x250
1015cb15c:     	bl	0x1015d7404 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB4_9Retention7checked>
1015cb160:     	ldr	w8, [sp, #0x550]
1015cb164:     	cmp	w8, #0x6
1015cb168:     	b.ne	0x1015cb388 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1228>
1015cb16c:     	ldr	x8, [sp, #0x568]
1015cb170:     	ldur	q0, [x27, #0x8]
1015cb174:     	str	q0, [sp, #0x220]
1015cb178:     	str	x8, [sp, #0x230]
1015cb17c:     	tbnz	w21, #0x0, 0x1015cb3e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
1015cb180:     	mov	x8, x20
1015cb184:     	ldr	x9, [x20, #0xc0]
1015cb188:     	cmp	x9, #0x2
1015cb18c:     	b.ne	0x1015cb3e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
1015cb190:     	ldr	x9, [x8, #0x220]
1015cb194:     	cmp	x9, #0x2
1015cb198:     	b.eq	0x1015cb3e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
1015cb19c:     	ldr	x9, [x8, #0x1d8]
1015cb1a0:     	cmp	x9, x22
1015cb1a4:     	b.ne	0x1015cb3e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1280>
1015cb1a8:     	ldr	x21, [x8, #0x4d8]
1015cb1ac:     	mov	x8, #-0x41              ; =-65
1015cb1b0:     	movk	x8, #0xfff, lsl #48
1015cb1b4:     	cmp	x21, x8
1015cb1b8:     	b.hi	0x1015cc858 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26f8>
1015cb1bc:     	ldr	x8, [x20, #0x490]
1015cb1c0:     	lsl	x9, x21, #4
1015cb1c4:     	add	x0, sp, #0x550
1015cb1c8:     	add	x1, x8, #0x2f8
1015cb1cc:     	add	x2, x9, #0x400
1015cb1d0:     	bl	0x1015b2708 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015cb1d4:     	ldrb	w8, [sp, #0x550]
1015cb1d8:     	cmp	w8, #0xe
1015cb1dc:     	b.ne	0x1015cb574 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1414>
1015cb1e0:     	cbz	x21, 0x1015cb1f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1094>
1015cb1e4:     	ldr	x0, [x20, #0x4d0]
1015cb1e8:     	cbz	x0, 0x1015cb90c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17ac>
1015cb1ec:     	lsl	x1, x21, #3
1015cb1f0:     	bl	0x103a071b4 <dyld_stub_binder+0x103a071b4>
1015cb1f4:     	add	x0, x20, #0x1d8
1015cb1f8:     	bl	0x1015af860 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
1015cb1fc:     	mov	w8, #0x2                ; =2
1015cb200:     	str	x8, [x20, #0x220]
1015cb204:     	ldr	x8, [x20, #0x238]
1015cb208:     	cmp	x8, #0x3
1015cb20c:     	b.eq	0x1015cd16c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x300c>
1015cb210:     	ldr	q0, [sp, #0x220]
1015cb214:     	str	q0, [x25]
1015cb218:     	ldr	x8, [sp, #0x230]
1015cb21c:     	str	x8, [x25, #0x10]
1015cb220:     	ldr	x8, [x25]
1015cb224:     	cmp	x8, #0x3
1015cb228:     	b.eq	0x1015cd178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3018>
1015cb22c:     	mov	w8, #0x1                ; =1
1015cb230:     	str	w8, [x20, #0x268]
1015cb234:     	str	w19, [x20, #0x26c]
1015cb238:     	str	xzr, [x23, #0x8]
1015cb23c:     	b	0x1015cb534 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d4>
1015cb240:     	str	wzr, [x8]
1015cb244:     	mov	w9, #0xc                ; =12
1015cb248:     	strb	w9, [x8, #0x8]
1015cb24c:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb250:     	add	x9, x9, #0x805
1015cb254:     	mov	w10, #0x1c              ; =28
1015cb258:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cb25c:     	ldr	w9, [x1, #0x270]
1015cb260:     	cbnz	w9, 0x1015cb354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
1015cb264:     	ldr	x9, [x1, #0xc0]
1015cb268:     	cmp	x9, #0x2
1015cb26c:     	b.ne	0x1015cb354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
1015cb270:     	ldr	x9, [x1, #0x220]
1015cb274:     	cmp	x9, #0x2
1015cb278:     	b.eq	0x1015cb354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
1015cb27c:     	ldr	x9, [x1, #0x1d8]
1015cb280:     	cmp	x9, x22
1015cb284:     	b.ne	0x1015cb354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x11f4>
1015cb288:     	ldr	x21, [x1, #0x4d8]
1015cb28c:     	mov	x8, #-0x41              ; =-65
1015cb290:     	movk	x8, #0xfff, lsl #48
1015cb294:     	cmp	x21, x8
1015cb298:     	b.hi	0x1015cc858 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26f8>
1015cb29c:     	ldr	x8, [x20, #0x490]
1015cb2a0:     	lsl	x9, x21, #4
1015cb2a4:     	add	x0, sp, #0x550
1015cb2a8:     	add	x1, x8, #0x2f8
1015cb2ac:     	add	x2, x9, #0x400
1015cb2b0:     	bl	0x1015b2708 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015cb2b4:     	ldrb	w8, [sp, #0x550]
1015cb2b8:     	cmp	w8, #0xe
1015cb2bc:     	b.ne	0x1015cb574 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1414>
1015cb2c0:     	cbz	x21, 0x1015cb2d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1174>
1015cb2c4:     	ldr	x0, [x20, #0x4d0]
1015cb2c8:     	cbz	x0, 0x1015cb90c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17ac>
1015cb2cc:     	lsl	x1, x21, #3
1015cb2d0:     	bl	0x103a071b4 <dyld_stub_binder+0x103a071b4>
1015cb2d4:     	add	x0, x20, #0x1d8
1015cb2d8:     	bl	0x1015af860 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
1015cb2dc:     	mov	w8, #0x2                ; =2
1015cb2e0:     	str	x8, [x20, #0x220]
1015cb2e4:     	ldr	x8, [x20, #0x238]
1015cb2e8:     	cmp	x8, #0x3
1015cb2ec:     	b.eq	0x1015cd0a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f44>
1015cb2f0:     	mov	w8, #0x1                ; =1
1015cb2f4:     	str	w8, [x20, #0x270]
1015cb2f8:     	str	w19, [x20, #0x274]
1015cb2fc:     	str	xzr, [x23, #0x8]
1015cb300:     	b	0x1015cb534 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d4>
1015cb304:     	cmp	w11, w19
1015cb308:     	b.ne	0x1015cb370 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1210>
1015cb30c:     	ldrb	w9, [x1, #0x288]
1015cb310:     	tbnz	w9, #0x0, 0x1015cb370 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1210>
1015cb314:     	ldrb	w9, [x1, #0x289]
1015cb318:     	tbnz	w9, #0x0, 0x1015cb370 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1210>
1015cb31c:     	add	x0, sp, #0x550
1015cb320:     	mov	x2, x19
1015cb324:     	mov	x4, x22
1015cb328:     	bl	0x1015bfc1c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23prepare_borrowed_region>
1015cb32c:     	ldr	w8, [sp, #0x550]
1015cb330:     	cmp	w8, #0x6
1015cb334:     	b.ne	0x1015cb540 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13e0>
1015cb338:     	ldr	x8, [x25]
1015cb33c:     	cmp	x8, #0x3
1015cb340:     	b.eq	0x1015cce04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ca4>
1015cb344:     	ldur	q0, [x27, #0x8]
1015cb348:     	mov	w8, #0x1                ; =1
1015cb34c:     	strb	w8, [x20, #0x288]
1015cb350:     	b	0x1015cb530 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d0>
1015cb354:     	str	wzr, [x8]
1015cb358:     	mov	w9, #0xc                ; =12
1015cb35c:     	strb	w9, [x8, #0x8]
1015cb360:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb364:     	add	x9, x9, #0x74d
1015cb368:     	mov	w10, #0x2f              ; =47
1015cb36c:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cb370:     	str	wzr, [x8]
1015cb374:     	mov	w9, #0xc                ; =12
1015cb378:     	strb	w9, [x8, #0x8]
1015cb37c:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb380:     	add	x9, x9, #0x7ae
1015cb384:     	b	0x1015cab24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9c4>
1015cb388:     	ldr	q0, [sp, #0x560]
1015cb38c:     	ldr	q1, [sp, #0x570]
1015cb390:     	stur	q0, [x24, #0xc]
1015cb394:     	ldur	q0, [x27, #0x4]
1015cb398:     	str	q0, [sp, #0x440]
1015cb39c:     	ldr	q0, [sp, #0x580]
1015cb3a0:     	ldr	q2, [sp, #0x590]
1015cb3a4:     	stp	q0, q2, [x23, #0x30]
1015cb3a8:     	ldr	q0, [sp, #0x440]
1015cb3ac:     	stur	q0, [x23, #0x4]
1015cb3b0:     	ldur	q0, [x24, #0xc]
1015cb3b4:     	stp	q0, q1, [x23, #0x10]
1015cb3b8:     	str	w8, [x23]
1015cb3bc:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb3c0:     	str	wzr, [x28]
1015cb3c4:     	mov	w8, #0xc                ; =12
1015cb3c8:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cb3cc:     	add	x9, x9, #0xa94
1015cb3d0:     	stp	x8, x9, [x28, #0x8]
1015cb3d4:     	mov	w8, #0x30               ; =48
1015cb3d8:     	str	x8, [x28, #0x18]
1015cb3dc:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb3e0:     	str	wzr, [x23]
1015cb3e4:     	mov	w8, #0xc                ; =12
1015cb3e8:     	strb	w8, [x23, #0x8]
1015cb3ec:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb3f0:     	add	x8, x8, #0x77c
1015cb3f4:     	mov	w9, #0x32               ; =50
1015cb3f8:     	stp	x8, x9, [x23, #0x10]
1015cb3fc:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb400:     	ldr	x1, [x10, #0x270]
1015cb404:     	cmp	x9, x1
1015cb408:     	b.hs	0x1015cd76c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x360c>
1015cb40c:     	ldr	x8, [x10, #0x268]
1015cb410:     	add	x8, x8, x19, lsl #4
1015cb414:     	ldr	w9, [x8]
1015cb418:     	tbz	w9, #0x0, 0x1015cb618 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14b8>
1015cb41c:     	ldr	x3, [x8, #0x8]
1015cb420:     	add	x0, sp, #0x550
1015cb424:     	mov	x1, x20
1015cb428:     	mov	x2, x21
1015cb42c:     	bl	0x1015bd390 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation19begin_closed_region>
1015cb430:     	ldr	w8, [sp, #0x550]
1015cb434:     	cmp	w8, #0x6
1015cb438:     	b.ne	0x1015cb540 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13e0>
1015cb43c:     	ldr	x8, [x25]
1015cb440:     	cmp	x8, #0x3
1015cb444:     	b.eq	0x1015cd12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fcc>
1015cb448:     	ldur	q0, [x27, #0x8]
1015cb44c:     	mov	w8, #0x1                ; =1
1015cb450:     	strb	w8, [x20, #0x289]
1015cb454:     	b	0x1015cb530 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13d0>
1015cb458:     	mov	x20, x0
1015cb45c:     	ldr	x11, [x0, #0x3d8]
1015cb460:     	cbz	x11, 0x1015cb764 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1604>
1015cb464:     	ldr	x12, [x20, #0x3d0]
1015cb468:     	cmp	x12, x8
1015cb46c:     	csel	x8, xzr, x8, lo
1015cb470:     	sub	x8, x12, x8
1015cb474:     	ldr	x11, [x20, #0x3c8]
1015cb478:     	mov	w12, #0x58              ; =88
1015cb47c:     	madd	x8, x8, x12, x11
1015cb480:     	ldr	x11, [x8, #0x40]
1015cb484:     	cmp	x11, x9
1015cb488:     	b.ne	0x1015cb5fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
1015cb48c:     	ldr	w9, [x10, #0x2e8]
1015cb490:     	cmp	w9, #0x1
1015cb494:     	b.ne	0x1015cb5fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
1015cb498:     	ldr	w9, [x21, #0x34]
1015cb49c:     	ldr	w10, [x10, #0x2ec]
1015cb4a0:     	cmp	w10, w9
1015cb4a4:     	b.ne	0x1015cb5fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
1015cb4a8:     	lsl	x0, x9, #1
1015cb4ac:     	ldr	x1, [x20, #0x4b8]
1015cb4b0:     	cmp	x0, x1
1015cb4b4:     	b.hs	0x1015cd854 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36f4>
1015cb4b8:     	ldr	x9, [x8, #0x50]
1015cb4bc:     	ldr	x10, [x20, #0x4b0]
1015cb4c0:     	ldr	x10, [x10, x0, lsl #3]
1015cb4c4:     	subs	x9, x9, x10
1015cb4c8:     	b.lo	0x1015cb5fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
1015cb4cc:     	ldr	x10, [x8, #0x48]
1015cb4d0:     	cmp	x9, x10
1015cb4d4:     	b.ne	0x1015cb5fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x149c>
1015cb4d8:     	ldr	x10, [x20, #0x3f8]
1015cb4dc:     	ldr	x9, [x20, #0x3e8]
1015cb4e0:     	cmp	x9, x10
1015cb4e4:     	b.eq	0x1015cb50c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x13ac>
1015cb4e8:     	add	x10, x9, #0xc8
1015cb4ec:     	str	x10, [x20, #0x3e8]
1015cb4f0:     	ldr	x15, [x9]
1015cb4f4:     	ldp	w14, w13, [x9, #0x8]
1015cb4f8:     	ldrb	w12, [x9, #0x10]
1015cb4fc:     	ldp	x11, x10, [x9, #0x18]
1015cb500:     	cbz	x15, 0x1015cc608 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x24a8>
1015cb504:     	cmp	x15, #0x2
1015cb508:     	b.ne	0x1015cc730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25d0>
1015cb50c:     	str	wzr, [x19]
1015cb510:     	mov	w8, #0xc                ; =12
1015cb514:     	strb	w8, [x19, #0x8]
1015cb518:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb51c:     	add	x8, x8, #0x331
1015cb520:     	mov	w9, #0x16               ; =22
1015cb524:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cb528:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cb52c:     	ldr	q0, [x8, #0xdc0]
1015cb530:     	stur	q0, [x23, #0x8]
1015cb534:     	mov	w8, #0x6                ; =6
1015cb538:     	str	w8, [x23]
1015cb53c:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb540:     	ldr	w9, [sp, #0x554]
1015cb544:     	ldur	q0, [x27, #0x18]
1015cb548:     	stur	q0, [x23, #0x18]
1015cb54c:     	ldur	q0, [x27, #0x28]
1015cb550:     	stur	q0, [x23, #0x28]
1015cb554:     	ldur	q0, [x27, #0x38]
1015cb558:     	stur	q0, [x23, #0x38]
1015cb55c:     	ldr	x10, [sp, #0x598]
1015cb560:     	str	x10, [x23, #0x48]
1015cb564:     	ldur	q0, [x27, #0x8]
1015cb568:     	stp	w8, w9, [x23]
1015cb56c:     	stur	q0, [x23, #0x8]
1015cb570:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb574:     	ldr	q0, [sp, #0x550]
1015cb578:     	ldr	q1, [sp, #0x560]
1015cb57c:     	str	q0, [sp, #0x440]
1015cb580:     	str	q1, [sp, #0x450]
1015cb584:     	ldr	q2, [sp, #0x570]
1015cb588:     	str	q2, [sp, #0x460]
1015cb58c:     	ldr	x8, [sp, #0x580]
1015cb590:     	str	x8, [sp, #0x470]
1015cb594:     	stur	q0, [x27, #0x4]
1015cb598:     	stur	q1, [x27, #0x14]
1015cb59c:     	stur	q2, [x27, #0x24]
1015cb5a0:     	stur	x8, [x27, #0x34]
1015cb5a4:     	str	wzr, [x23]
1015cb5a8:     	ldr	q0, [sp, #0x550]
1015cb5ac:     	ldr	q1, [sp, #0x560]
1015cb5b0:     	stur	q0, [x23, #0x4]
1015cb5b4:     	stur	q1, [x23, #0x14]
1015cb5b8:     	ldr	q0, [sp, #0x570]
1015cb5bc:     	stur	q0, [x23, #0x24]
1015cb5c0:     	ldur	q0, [x27, #0x2c]
1015cb5c4:     	str	q0, [x23, #0x30]
1015cb5c8:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb5cc:     	mov	x19, x8
1015cb5d0:     	add	x0, sp, #0x550
1015cb5d4:     	add	x1, x9, #0x2f8
1015cb5d8:     	mov	w2, #0x100              ; =256
1015cb5dc:     	bl	0x1015b2708 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015cb5e0:     	ldrb	w8, [sp, #0x550]
1015cb5e4:     	cmp	w8, #0xe
1015cb5e8:     	b.ne	0x1015cb784 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1624>
1015cb5ec:     	str	xzr, [x19, #0x8]
1015cb5f0:     	mov	w8, #0x6                ; =6
1015cb5f4:     	str	w8, [x19]
1015cb5f8:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb5fc:     	str	wzr, [x19]
1015cb600:     	mov	w8, #0xc                ; =12
1015cb604:     	strb	w8, [x19, #0x8]
1015cb608:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb60c:     	add	x8, x8, #0x3b7
1015cb610:     	mov	w9, #0x33               ; =51
1015cb614:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cb618:     	str	wzr, [x23]
1015cb61c:     	mov	w8, #0xc                ; =12
1015cb620:     	adrp	x9, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cb624:     	add	x9, x9, #0xd44
1015cb628:     	stp	x8, x9, [x23, #0x8]
1015cb62c:     	mov	w8, #0x26               ; =38
1015cb630:     	str	x8, [x23, #0x18]
1015cb634:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb638:     	cmp	x22, #0x9
1015cb63c:     	b.eq	0x1015cb998 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1838>
1015cb640:     	cmp	x22, #0x8
1015cb644:     	b.ne	0x1015cb9c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1868>
1015cb648:     	mov	x0, x19
1015cb64c:     	ldr	x1, [sp, #0x58]
1015cb650:     	mov	x2, x20
1015cb654:     	mov	x3, x24
1015cb658:     	add	sp, sp, #0x810
1015cb65c:     	ldp	x29, x30, [sp, #0x50]
1015cb660:     	ldp	x20, x19, [sp, #0x40]
1015cb664:     	ldp	x22, x21, [sp, #0x30]
1015cb668:     	ldp	x24, x23, [sp, #0x20]
1015cb66c:     	ldp	x26, x25, [sp, #0x10]
1015cb670:     	ldp	x28, x27, [sp], #0x60
1015cb674:     	b	0x1015c0d98 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation24prepare_borrowed_strings>
1015cb678:     	mov	x10, #0x0               ; =0
1015cb67c:     	lsr	x11, x9, #1
1015cb680:     	add	x12, x11, x10
1015cb684:     	ldr	w13, [x8, x12, lsl #2]
1015cb688:     	cmp	w13, w19
1015cb68c:     	csel	x10, x10, x12, hi
1015cb690:     	sub	x9, x9, x11
1015cb694:     	cmp	x9, #0x1
1015cb698:     	b.hi	0x1015cb67c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x151c>
1015cb69c:     	ldr	w8, [x8, x10, lsl #2]
1015cb6a0:     	cmp	w8, w19
1015cb6a4:     	mov	x8, x22
1015cb6a8:     	b.ne	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015cb6ac:     	ldr	x1, [x23, #0x380]
1015cb6b0:     	cmp	x1, x19
1015cb6b4:     	b.ls	0x1015cd7d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3670>
1015cb6b8:     	ldr	x8, [x23, #0x378]
1015cb6bc:     	mov	w9, #0x170              ; =368
1015cb6c0:     	umaddl	x8, w19, w9, x8
1015cb6c4:     	add	x9, x8, #0x15c
1015cb6c8:     	ldr	w8, [x8, #0x16c]
1015cb6cc:     	str	w8, [sp, #0x560]
1015cb6d0:     	ldr	q0, [x9]
1015cb6d4:     	str	q0, [sp, #0x550]
1015cb6d8:     	add	x8, sp, #0x440
1015cb6dc:     	add	x0, sp, #0x550
1015cb6e0:     	bl	0x102736074 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
1015cb6e4:     	ldr	w8, [sp, #0x440]
1015cb6e8:     	cmp	w8, #0x1
1015cb6ec:     	b.ne	0x1015cb6fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x159c>
1015cb6f0:     	ldr	w8, [sp, #0x444]
1015cb6f4:     	cmp	w8, w26
1015cb6f8:     	b.eq	0x1015cb714 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15b4>
1015cb6fc:     	ldr	w8, [sp, #0x448]
1015cb700:     	cmp	w8, #0x1
1015cb704:     	b.ne	0x1015cba34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d4>
1015cb708:     	ldr	w8, [sp, #0x44c]
1015cb70c:     	cmp	w8, w26
1015cb710:     	b.ne	0x1015cba34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d4>
1015cb714:     	mov	x0, x20
1015cb718:     	mov	x1, x19
1015cb71c:     	bl	0x1015c8548 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
1015cb720:     	cbz	w0, 0x1015cb928 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c8>
1015cb724:     	ldrb	w8, [x21, #0x460]
1015cb728:     	cmp	w8, #0x1
1015cb72c:     	mov	x8, x22
1015cb730:     	b.ne	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015cb734:     	mov	x9, x20
1015cb738:     	ldr	x10, [x20, #0xc0]
1015cb73c:     	cmp	x10, #0x2
1015cb740:     	b.eq	0x1015cb93c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17dc>
1015cb744:     	b	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015cb748:     	str	wzr, [x8]
1015cb74c:     	mov	w9, #0xc                ; =12
1015cb750:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cb754:     	add	x10, x10, #0x620
1015cb758:     	stp	x9, x10, [x8, #0x8]
1015cb75c:     	mov	w9, #0x1a               ; =26
1015cb760:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015cb764:     	str	wzr, [x19]
1015cb768:     	mov	w8, #0xc                ; =12
1015cb76c:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb770:     	add	x9, x9, #0x314
1015cb774:     	stp	x8, x9, [x19, #0x8]
1015cb778:     	mov	w8, #0x1d               ; =29
1015cb77c:     	str	x8, [x19, #0x18]
1015cb780:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb784:     	ldr	q0, [sp, #0x550]
1015cb788:     	ldr	q1, [sp, #0x560]
1015cb78c:     	str	q0, [sp, #0x440]
1015cb790:     	str	q1, [sp, #0x450]
1015cb794:     	ldr	q2, [sp, #0x570]
1015cb798:     	str	q2, [sp, #0x460]
1015cb79c:     	ldr	x8, [sp, #0x580]
1015cb7a0:     	str	x8, [sp, #0x470]
1015cb7a4:     	stur	q0, [x27, #0x4]
1015cb7a8:     	stur	q1, [x27, #0x14]
1015cb7ac:     	stur	q2, [x27, #0x24]
1015cb7b0:     	stur	x8, [x27, #0x34]
1015cb7b4:     	str	wzr, [x19]
1015cb7b8:     	ldr	q0, [sp, #0x550]
1015cb7bc:     	ldr	q1, [sp, #0x560]
1015cb7c0:     	stur	q0, [x19, #0x4]
1015cb7c4:     	stur	q1, [x19, #0x14]
1015cb7c8:     	ldr	q0, [sp, #0x570]
1015cb7cc:     	stur	q0, [x19, #0x24]
1015cb7d0:     	ldur	q0, [x27, #0x2c]
1015cb7d4:     	str	q0, [x19, #0x30]
1015cb7d8:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb7dc:     	ldr	x9, [sp, #0x58]
1015cb7e0:     	ldr	x9, [x9, #0x3d8]
1015cb7e4:     	cbz	x9, 0x1015cba14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18b4>
1015cb7e8:     	ldr	x9, [sp, #0x58]
1015cb7ec:     	ldr	x10, [x9, #0x3d0]
1015cb7f0:     	cmp	x10, x8
1015cb7f4:     	csel	x8, xzr, x8, lo
1015cb7f8:     	sub	x8, x10, x8
1015cb7fc:     	ldr	x9, [x9, #0x3c8]
1015cb800:     	mov	w10, #0x58              ; =88
1015cb804:     	madd	x20, x8, x10, x9
1015cb808:     	ldr	x8, [x20, #0x40]
1015cb80c:     	cmp	x8, x19
1015cb810:     	b.ne	0x1015cb8f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1790>
1015cb814:     	ldr	x8, [x20, #0x48]
1015cb818:     	cbnz	x8, 0x1015cb8f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1790>
1015cb81c:     	ldr	x8, [x20, #0x50]
1015cb820:     	cmp	x8, x28
1015cb824:     	b.ne	0x1015cb8f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1790>
1015cb828:     	ldr	w1, [x22, #0x50]
1015cb82c:     	add	x8, sp, #0x550
1015cb830:     	add	x0, x24, #0xf0
1015cb834:     	add	x2, x24, #0x2f8
1015cb838:     	bl	0x1015d0bac <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015cb83c:     	ldur	q0, [x27, #0x8]
1015cb840:     	ldur	q1, [x27, #0x18]
1015cb844:     	stp	q0, q1, [sp, #0x3a0]
1015cb848:     	ldur	q0, [x27, #0x28]
1015cb84c:     	str	q0, [sp, #0x3c0]
1015cb850:     	ldr	x8, [sp, #0x550]
1015cb854:     	ldr	x9, [sp, #0x588]
1015cb858:     	str	x9, [sp, #0x3d0]
1015cb85c:     	cbz	x8, 0x1015cc00c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1eac>
1015cb860:     	ldp	q0, q1, [sp, #0x3a0]
1015cb864:     	add	x9, sp, #0x440
1015cb868:     	stur	q0, [x9, #0x8]
1015cb86c:     	ldr	x10, [sp, #0x3d0]
1015cb870:     	ldr	q0, [sp, #0x3c0]
1015cb874:     	stur	q0, [x9, #0x28]
1015cb878:     	stur	q1, [x9, #0x18]
1015cb87c:     	str	x10, [sp, #0x478]
1015cb880:     	str	x8, [sp, #0x440]
1015cb884:     	ldr	x8, [sp, #0x448]
1015cb888:     	ldr	x9, [x20, #0x8]
1015cb88c:     	ldr	x8, [x8, #0x10]
1015cb890:     	ldr	x9, [x9, #0x10]
1015cb894:     	cmp	x8, x9
1015cb898:     	b.eq	0x1015cc180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2020>
1015cb89c:     	mov	w8, #0x0                ; =0
1015cb8a0:     	mov	w9, #0xc                ; =12
1015cb8a4:     	strb	w9, [x23, #0x8]
1015cb8a8:     	mov	w9, #0x27               ; =39
1015cb8ac:     	str	x9, [x23, #0x18]
1015cb8b0:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb8b4:     	add	x9, x9, #0x141
1015cb8b8:     	b	0x1015cc190 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2030>
1015cb8bc:     	ldr	w9, [sp, #0x554]
1015cb8c0:     	ldur	q0, [x27, #0x18]
1015cb8c4:     	stur	q0, [x28, #0x18]
1015cb8c8:     	ldur	q0, [x27, #0x28]
1015cb8cc:     	stur	q0, [x28, #0x28]
1015cb8d0:     	ldur	q0, [x27, #0x38]
1015cb8d4:     	stur	q0, [x28, #0x38]
1015cb8d8:     	ldr	x10, [sp, #0x598]
1015cb8dc:     	str	x10, [x28, #0x48]
1015cb8e0:     	ldur	q0, [x27, #0x8]
1015cb8e4:     	stp	w8, w9, [x28]
1015cb8e8:     	stur	q0, [x28, #0x8]
1015cb8ec:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb8f0:     	str	wzr, [x23]
1015cb8f4:     	mov	w8, #0xc                ; =12
1015cb8f8:     	strb	w8, [x23, #0x8]
1015cb8fc:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb900:     	add	x8, x8, #0x168
1015cb904:     	mov	w9, #0x36               ; =54
1015cb908:     	b	0x1015cb3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
1015cb90c:     	str	wzr, [x23]
1015cb910:     	mov	w8, #0xc                ; =12
1015cb914:     	strb	w8, [x23, #0x8]
1015cb918:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cb91c:     	add	x8, x8, #0xc56
1015cb920:     	mov	w9, #0x29               ; =41
1015cb924:     	b	0x1015cb3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
1015cb928:     	mov	x9, x20
1015cb92c:     	ldr	x8, [x20, #0xc0]
1015cb930:     	cmp	x8, #0x2
1015cb934:     	mov	x8, x22
1015cb938:     	b.ne	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015cb93c:     	ldr	x9, [x9, #0x220]
1015cb940:     	cmp	x9, #0x2
1015cb944:     	b.ne	0x1015cba38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18d8>
1015cb948:     	ldr	x8, [x23, #0x360]
1015cb94c:     	ldr	w1, [x24, #0x4c]
1015cb950:     	cmp	x8, x1
1015cb954:     	b.ls	0x1015cd840 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36e0>
1015cb958:     	ldr	x8, [x23, #0x358]
1015cb95c:     	mov	w9, #0x140              ; =320
1015cb960:     	umaddl	x8, w1, w9, x8
1015cb964:     	ldrb	w9, [x8, #0x124]
1015cb968:     	ldr	x8, [x25]
1015cb96c:     	cmp	w9, #0x7
1015cb970:     	b.ne	0x1015cbbb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a50>
1015cb974:     	cbz	x8, 0x1015cbe14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cb4>
1015cb978:     	str	wzr, [x22]
1015cb97c:     	mov	w8, #0xc                ; =12
1015cb980:     	strb	w8, [x22, #0x8]
1015cb984:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cb988:     	add	x8, x8, #0x45c
1015cb98c:     	mov	w9, #0x28               ; =40
1015cb990:     	stp	x8, x9, [x22, #0x10]
1015cb994:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cb998:     	mov	x0, x19
1015cb99c:     	ldr	x1, [sp, #0x58]
1015cb9a0:     	mov	x2, x20
1015cb9a4:     	mov	x3, x24
1015cb9a8:     	add	sp, sp, #0x810
1015cb9ac:     	ldp	x29, x30, [sp, #0x50]
1015cb9b0:     	ldp	x20, x19, [sp, #0x40]
1015cb9b4:     	ldp	x22, x21, [sp, #0x30]
1015cb9b8:     	ldp	x24, x23, [sp, #0x20]
1015cb9bc:     	ldp	x26, x25, [sp, #0x10]
1015cb9c0:     	ldp	x28, x27, [sp], #0x60
1015cb9c4:     	b	0x1015be8a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23borrowed_string_failure>
1015cb9c8:     	ldr	x0, [sp, #0x58]
1015cb9cc:     	mov	x1, x20
1015cb9d0:     	bl	0x1015be7e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
1015cb9d4:     	cbz	x0, 0x1015cbb44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19e4>
1015cb9d8:     	str	wzr, [x19]
1015cb9dc:     	mov	w8, #0xc                ; =12
1015cb9e0:     	strb	w8, [x19, #0x8]
1015cb9e4:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0xb98>
1015cb9e8:     	add	x8, x8, #0xf37
1015cb9ec:     	mov	w9, #0x2e               ; =46
1015cb9f0:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cb9f4:     	str	wzr, [x28]
1015cb9f8:     	mov	w8, #0xc                ; =12
1015cb9fc:     	strb	w8, [x28, #0x8]
1015cba00:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cba04:     	add	x8, x8, #0x82a
1015cba08:     	mov	w9, #0x23               ; =35
1015cba0c:     	stp	x8, x9, [x28, #0x10]
1015cba10:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cba14:     	str	wzr, [x23]
1015cba18:     	mov	w8, #0xc                ; =12
1015cba1c:     	adrp	x9, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cba20:     	add	x9, x9, #0x736
1015cba24:     	stp	x8, x9, [x23, #0x8]
1015cba28:     	mov	w8, #0x14               ; =20
1015cba2c:     	str	x8, [x23, #0x18]
1015cba30:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cba34:     	mov	x8, x22
1015cba38:     	str	wzr, [x8]
1015cba3c:     	mov	w9, #0xc                ; =12
1015cba40:     	strb	w9, [x8, #0x8]
1015cba44:     	adrp	x9, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cba48:     	add	x9, x9, #0x484
1015cba4c:     	mov	w10, #0x28              ; =40
1015cba50:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cba54:     	ldr	x8, [sp, #0x58]
1015cba58:     	ldr	x8, [x8, #0x490]
1015cba5c:     	add	x0, sp, #0x550
1015cba60:     	add	x1, x8, #0x2f8
1015cba64:     	mov	w2, #0x40               ; =64
1015cba68:     	bl	0x1015b2708 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015cba6c:     	ldrb	w8, [sp, #0x550]
1015cba70:     	cmp	w8, #0xe
1015cba74:     	b.ne	0x1015cbce8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b88>
1015cba78:     	ldr	x0, [x23, x22]
1015cba7c:     	ldr	x8, [x21, #0x40]
1015cba80:     	str	x8, [sp, #0x28]
1015cba84:     	cmp	x0, x8
1015cba88:     	b.hs	0x1015cd8a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3744>
1015cba8c:     	ldr	x10, [x21, #0x38]
1015cba90:     	ldr	w3, [x21, #0xe0]
1015cba94:     	ldr	x8, [sp, #0x58]
1015cba98:     	ldr	x8, [x8, #0x490]
1015cba9c:     	mov	w9, #0x18               ; =24
1015cbaa0:     	mul	x9, x0, x9
1015cbaa4:     	str	x10, [sp, #0x20]
1015cbaa8:     	ldr	x4, [x10, x9]
1015cbaac:     	ldr	x1, [x8, #0x3c0]
1015cbab0:     	add	x0, sp, #0x550
1015cbab4:     	add	x2, x19, #0x488
1015cbab8:     	bl	0x1015b3a7c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames18take_managed_owner>
1015cbabc:     	ldr	w8, [sp, #0x550]
1015cbac0:     	cmp	w8, #0x6
1015cbac4:     	b.ne	0x1015cbdac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c4c>
1015cbac8:     	ldur	q0, [x27, #0x28]
1015cbacc:     	stur	q0, [x24, #0x24]
1015cbad0:     	ldur	q1, [x27, #0x38]
1015cbad4:     	ldur	q2, [x27, #0x18]
1015cbad8:     	ldur	q3, [x27, #0x8]
1015cbadc:     	stp	q3, q2, [sp, #0x60]
1015cbae0:     	stp	q0, q1, [sp, #0x80]
1015cbae4:     	add	x24, sp, #0x550
1015cbae8:     	add	x8, sp, #0x550
1015cbaec:     	ldr	x0, [sp, #0x58]
1015cbaf0:     	mov	w1, #0x0                ; =0
1015cbaf4:     	bl	0x1015d7004 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
1015cbaf8:     	ldr	x8, [sp, #0x550]
1015cbafc:     	cmp	x8, #0x1
1015cbb00:     	b.ne	0x1015cbf34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1dd4>
1015cbb04:     	ldur	q0, [x24, #0x18]
1015cbb08:     	ldur	q1, [x24, #0x28]
1015cbb0c:     	ldur	q2, [x24, #0x38]
1015cbb10:     	str	q1, [sp, #0x460]
1015cbb14:     	str	q2, [sp, #0x470]
1015cbb18:     	ldur	q3, [x24, #0x48]
1015cbb1c:     	str	q3, [sp, #0x480]
1015cbb20:     	ldur	q4, [x24, #0x8]
1015cbb24:     	str	q0, [sp, #0x450]
1015cbb28:     	str	q4, [sp, #0x440]
1015cbb2c:     	stp	q1, q2, [x28, #0x20]
1015cbb30:     	str	q3, [x28, #0x40]
1015cbb34:     	stp	q4, q0, [x28]
1015cbb38:     	add	x0, sp, #0x60
1015cbb3c:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cbb40:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cbb44:     	ldr	x8, [x23, #0x558]
1015cbb48:     	cmp	x20, x8
1015cbb4c:     	b.hs	0x1015cbb68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a08>
1015cbb50:     	ldr	x8, [x23, #0x550]
1015cbb54:     	mov	w9, #0x28               ; =40
1015cbb58:     	mul	x9, x20, x9
1015cbb5c:     	ldr	w8, [x8, x9]
1015cbb60:     	cmp	w8, #0x5
1015cbb64:     	b.ne	0x1015cbe60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d00>
1015cbb68:     	cmp	x22, #0x6
1015cbb6c:     	b.gt	0x1015cbd60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c00>
1015cbb70:     	cmp	x22, #0x4
1015cbb74:     	b.eq	0x1015cc040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ee0>
1015cbb78:     	cmp	x22, #0x5
1015cbb7c:     	b.eq	0x1015cc0c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f68>
1015cbb80:     	cmp	x22, #0x6
1015cbb84:     	b.ne	0x1015cc0a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f40>
1015cbb88:     	ldr	q0, [x24]
1015cbb8c:     	str	q0, [sp, #0x550]
1015cbb90:     	ldr	x8, [x24, #0x10]
1015cbb94:     	str	x8, [sp, #0x560]
1015cbb98:     	add	x3, sp, #0x550
1015cbb9c:     	mov	x0, x19
1015cbba0:     	ldr	x1, [sp, #0x58]
1015cbba4:     	mov	x2, x20
1015cbba8:     	bl	0x1015c2d94 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation25prepare_string_map_region>
1015cbbac:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cbbb0:     	mov	x9, #0x0                ; =0
1015cbbb4:     	ldr	x10, [x21, #0x330]
1015cbbb8:     	ldr	x11, [x21, #0x3c8]
1015cbbbc:     	ldr	x12, [x21, #0x430]
1015cbbc0:     	ldp	q0, q1, [x21, #0x3d0]
1015cbbc4:     	ldp	q2, q3, [x21, #0x3f0]
1015cbbc8:     	ldr	q4, [x21, #0x410]
1015cbbcc:     	ldr	q5, [x21, #0x420]
1015cbbd0:     	mov	w13, #0x1               ; =1
1015cbbd4:     	stp	x13, x9, [x20, #0xf8]
1015cbbd8:     	str	x8, [x20, #0x108]
1015cbbdc:     	ldp	q6, q7, [sp, #0x60]
1015cbbe0:     	stp	q6, q7, [x20, #0x110]
1015cbbe4:     	ldr	q6, [sp, #0x80]
1015cbbe8:     	str	q6, [x20, #0x130]
1015cbbec:     	stp	x10, x11, [x20, #0x140]
1015cbbf0:     	stp	q0, q1, [x20, #0x150]
1015cbbf4:     	stp	q2, q3, [x20, #0x170]
1015cbbf8:     	stp	q4, q5, [x20, #0x190]
1015cbbfc:     	str	x12, [x20, #0x1b0]
1015cbc00:     	str	w19, [x20, #0x1b8]
1015cbc04:     	dup.2d	v0, x13
1015cbc08:     	stur	q0, [x22, #0x8]
1015cbc0c:     	mov	w8, #0x6                ; =6
1015cbc10:     	str	w8, [x22]
1015cbc14:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cbc18:     	mov	w11, #0x0               ; =0
1015cbc1c:     	mov	w10, #0x0               ; =0
1015cbc20:     	mov	w13, #0x6               ; =6
1015cbc24:     	mov	x8, #-0x1               ; =-1
1015cbc28:     	mov	x12, x23
1015cbc2c:     	b	0x1015cacfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xb9c>
1015cbc30:     	cbnz	x28, 0x1015cbc4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015cbc34:     	ldp	x1, x2, [x23, #0x8]
1015cbc38:     	ldr	x0, [sp, #0x50]
1015cbc3c:     	bl	0x1015dec30 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
1015cbc40:     	tbz	w0, #0x0, 0x1015cbc4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aec>
1015cbc44:     	mov	x8, #0x0                ; =0
1015cbc48:     	b	0x1015cbca8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b48>
1015cbc4c:     	ldr	x8, [sp, #0x48]
1015cbc50:     	str	wzr, [x8]
1015cbc54:     	mov	w9, #0xc                ; =12
1015cbc58:     	strb	w9, [x8, #0x8]
1015cbc5c:     	adrp	x9, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cbc60:     	add	x9, x9, #0xaf6
1015cbc64:     	mov	w10, #0x38              ; =56
1015cbc68:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cbc6c:     	ldr	x9, [x23, #0xa0]
1015cbc70:     	cbz	x9, 0x1015cbd40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1be0>
1015cbc74:     	ldr	x8, [x23, #0x98]
1015cbc78:     	lsl	x9, x9, #5
1015cbc7c:     	b	0x1015cbc8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b2c>
1015cbc80:     	add	x8, x8, #0x20
1015cbc84:     	subs	x9, x9, #0x20
1015cbc88:     	b.eq	0x1015cbd40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1be0>
1015cbc8c:     	ldr	w11, [x8, #0x18]
1015cbc90:     	ldr	x10, [sp, #0x50]
1015cbc94:     	cmp	x10, x11
1015cbc98:     	b.ne	0x1015cbc80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b20>
1015cbc9c:     	ldr	w10, [x8, #0x1c]
1015cbca0:     	cmp	x28, x10
1015cbca4:     	b.ne	0x1015cbc80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b20>
1015cbca8:     	str	x8, [sp, #0x220]
1015cbcac:     	ldr	x9, [sp, #0x40]
1015cbcb0:     	ldp	x8, x9, [x9, #0xd0]
1015cbcb4:     	lsl	x9, x9, #6
1015cbcb8:     	cbz	x9, 0x1015cbe7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d1c>
1015cbcbc:     	ldr	x10, [x8], #0x40
1015cbcc0:     	sub	x9, x9, #0x40
1015cbcc4:     	cbz	x10, 0x1015cbcb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b58>
1015cbcc8:     	ldr	x8, [sp, #0x48]
1015cbccc:     	str	wzr, [x8]
1015cbcd0:     	mov	w9, #0xc                ; =12
1015cbcd4:     	strb	w9, [x8, #0x8]
1015cbcd8:     	adrp	x9, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cbcdc:     	add	x9, x9, #0xac4
1015cbce0:     	mov	w10, #0x32              ; =50
1015cbce4:     	b	0x1015ca1ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015cbce8:     	ldr	q0, [sp, #0x550]
1015cbcec:     	ldr	q1, [sp, #0x560]
1015cbcf0:     	str	q0, [sp, #0x440]
1015cbcf4:     	str	q1, [sp, #0x450]
1015cbcf8:     	ldr	q2, [sp, #0x570]
1015cbcfc:     	str	q2, [sp, #0x460]
1015cbd00:     	ldr	x8, [sp, #0x580]
1015cbd04:     	str	x8, [sp, #0x470]
1015cbd08:     	stur	q0, [x27, #0x4]
1015cbd0c:     	stur	q1, [x27, #0x14]
1015cbd10:     	stur	q2, [x27, #0x24]
1015cbd14:     	stur	x8, [x27, #0x34]
1015cbd18:     	str	wzr, [x28]
1015cbd1c:     	ldr	q0, [sp, #0x550]
1015cbd20:     	ldr	q1, [sp, #0x560]
1015cbd24:     	stur	q0, [x28, #0x4]
1015cbd28:     	stur	q1, [x28, #0x14]
1015cbd2c:     	ldr	q0, [sp, #0x570]
1015cbd30:     	stur	q0, [x28, #0x24]
1015cbd34:     	ldur	q0, [x27, #0x2c]
1015cbd38:     	str	q0, [x28, #0x30]
1015cbd3c:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cbd40:     	ldr	x8, [sp, #0x48]
1015cbd44:     	str	wzr, [x8]
1015cbd48:     	mov	w9, #0xc                ; =12
1015cbd4c:     	adrp	x10, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cbd50:     	add	x10, x10, #0xa19
1015cbd54:     	stp	x9, x10, [x8, #0x8]
1015cbd58:     	mov	w9, #0x31               ; =49
1015cbd5c:     	b	0x1015ca430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015cbd60:     	cmp	x22, #0x7
1015cbd64:     	b.eq	0x1015cc070 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f10>
1015cbd68:     	cmp	x22, #0x10
1015cbd6c:     	b.eq	0x1015cc0f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f98>
1015cbd70:     	cmp	x22, #0x11
1015cbd74:     	b.ne	0x1015cc0a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f40>
1015cbd78:     	ldp	x4, x5, [x24, #0x8]
1015cbd7c:     	ldr	x3, [x24]
1015cbd80:     	mov	x0, x19
1015cbd84:     	ldr	x1, [sp, #0x58]
1015cbd88:     	mov	x2, x20
1015cbd8c:     	add	sp, sp, #0x810
1015cbd90:     	ldp	x29, x30, [sp, #0x50]
1015cbd94:     	ldp	x20, x19, [sp, #0x40]
1015cbd98:     	ldp	x22, x21, [sp, #0x30]
1015cbd9c:     	ldp	x24, x23, [sp, #0x20]
1015cbda0:     	ldp	x26, x25, [sp, #0x10]
1015cbda4:     	ldp	x28, x27, [sp], #0x60
1015cbda8:     	b	0x1015d9048 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation21finish_join_map_chunk>
1015cbdac:     	ldur	q0, [x27, #0x14]
1015cbdb0:     	ldur	q1, [x27, #0x24]
1015cbdb4:     	ldur	q2, [x27, #0x34]
1015cbdb8:     	str	q1, [sp, #0x460]
1015cbdbc:     	str	q2, [sp, #0x470]
1015cbdc0:     	ldr	w9, [sp, #0x594]
1015cbdc4:     	str	w9, [sp, #0x480]
1015cbdc8:     	ldur	q3, [x27, #0x4]
1015cbdcc:     	str	q0, [sp, #0x450]
1015cbdd0:     	str	q3, [sp, #0x440]
1015cbdd4:     	ldr	x10, [sp, #0x598]
1015cbdd8:     	stur	q0, [x28, #0x14]
1015cbddc:     	stur	q1, [x28, #0x24]
1015cbde0:     	stur	q2, [x28, #0x34]
1015cbde4:     	str	w9, [x28, #0x44]
1015cbde8:     	stur	q3, [x28, #0x4]
1015cbdec:     	str	w8, [x28]
1015cbdf0:     	str	x10, [x28, #0x48]
1015cbdf4:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cbdf8:     	str	wzr, [x23]
1015cbdfc:     	mov	w8, #0xc                ; =12
1015cbe00:     	strb	w8, [x23, #0x8]
1015cbe04:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cbe08:     	add	x8, x8, #0x19e
1015cbe0c:     	mov	w9, #0x24               ; =36
1015cbe10:     	b	0x1015cb3f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1298>
1015cbe14:     	add	x8, sp, #0x550
1015cbe18:     	add	x0, x21, #0xf0
1015cbe1c:     	add	x2, x21, #0x2f8
1015cbe20:     	bl	0x1015d0bac <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015cbe24:     	ldr	x9, [sp, #0x550]
1015cbe28:     	ldr	x8, [sp, #0x558]
1015cbe2c:     	ldr	q0, [sp, #0x560]
1015cbe30:     	ldr	q1, [sp, #0x570]
1015cbe34:     	str	q0, [sp, #0x440]
1015cbe38:     	str	q1, [sp, #0x450]
1015cbe3c:     	ldr	q0, [sp, #0x580]
1015cbe40:     	str	q0, [sp, #0x460]
1015cbe44:     	cbz	x9, 0x1015cc128 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fc8>
1015cbe48:     	ldr	q0, [sp, #0x440]
1015cbe4c:     	ldr	q1, [sp, #0x450]
1015cbe50:     	stp	q0, q1, [sp, #0x60]
1015cbe54:     	ldr	q0, [sp, #0x460]
1015cbe58:     	str	q0, [sp, #0x80]
1015cbe5c:     	b	0x1015cbbb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a54>
1015cbe60:     	str	wzr, [x19]
1015cbe64:     	mov	w8, #0xc                ; =12
1015cbe68:     	strb	w8, [x19, #0x8]
1015cbe6c:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cbe70:     	add	x8, x8, #0x50
1015cbe74:     	mov	w9, #0x24               ; =36
1015cbe78:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cbe7c:     	add	x8, sp, #0x220
1015cbe80:     	str	x8, [sp, #0x440]
1015cbe84:     	str	x24, [sp, #0x448]
1015cbe88:     	ldr	x19, [sp, #0x58]
1015cbe8c:     	str	x19, [sp, #0x450]
1015cbe90:     	ldr	x8, [sp, #0x38]
1015cbe94:     	str	x8, [sp, #0x458]
1015cbe98:     	str	x21, [sp, #0x460]
1015cbe9c:     	add	x0, sp, #0x550
1015cbea0:     	add	x1, sp, #0x440
1015cbea4:     	bl	0x1015b1940 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB6_10Invocation19end_numeric_segments4_0Be_>
1015cbea8:     	ldr	x8, [x19, #0x490]
1015cbeac:     	ldr	x2, [x8, #0xd8]
1015cbeb0:     	ldr	x1, [x23, #0x40]
1015cbeb4:     	cmp	x1, x2
1015cbeb8:     	b.hi	0x1015cd41c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32bc>
1015cbebc:     	ldr	x0, [x8, #0xd0]
1015cbec0:     	str	xzr, [sp, #0x440]
1015cbec4:     	add	x2, sp, #0x440
1015cbec8:     	bl	0x1015e41f4 <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
1015cbecc:     	ldr	w8, [sp, #0x550]
1015cbed0:     	cmp	w8, #0x6
1015cbed4:     	b.ne	0x1015cc14c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fec>
1015cbed8:     	ldr	x9, [sp, #0x58]
1015cbedc:     	ldr	x8, [x9, #0x490]
1015cbee0:     	str	wzr, [x8, #0x340]
1015cbee4:     	ldr	x10, [x9, #0x490]
1015cbee8:     	mov	w8, #0x1                ; =1
1015cbeec:     	str	w8, [x10, #0x2f0]
1015cbef0:     	ldr	x8, [sp, #0x50]
1015cbef4:     	str	w8, [x10, #0x2f4]
1015cbef8:     	ldr	x8, [x9, #0x490]
1015cbefc:     	cmp	x20, #0x2
1015cbf00:     	cset	w9, ne
1015cbf04:     	strb	w9, [x8, #0x460]
1015cbf08:     	ldr	x8, [sp, #0x48]
1015cbf0c:     	str	xzr, [x8, #0x8]
1015cbf10:     	mov	w9, #0x6                ; =6
1015cbf14:     	str	w9, [x8]
1015cbf18:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cbf1c:     	adrp	x0, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cbf20:     	add	x0, x0, #0x840
1015cbf24:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015cbf28:     	adrp	x0, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cbf2c:     	add	x0, x0, #0x858
1015cbf30:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015cbf34:     	ldur	q0, [x24, #0x48]
1015cbf38:     	ldur	q1, [x24, #0x58]
1015cbf3c:     	str	q0, [sp, #0x480]
1015cbf40:     	str	q1, [sp, #0x490]
1015cbf44:     	ldur	x8, [x24, #0x68]
1015cbf48:     	str	x8, [sp, #0x4a0]
1015cbf4c:     	ldur	q2, [x24, #0x8]
1015cbf50:     	ldur	q3, [x24, #0x18]
1015cbf54:     	str	q2, [sp, #0x440]
1015cbf58:     	str	q3, [sp, #0x450]
1015cbf5c:     	ldur	q4, [x24, #0x38]
1015cbf60:     	ldur	q5, [x24, #0x28]
1015cbf64:     	stp	q2, q3, [sp, #0xa0]
1015cbf68:     	stp	q5, q4, [sp, #0xc0]
1015cbf6c:     	str	x8, [sp, #0x100]
1015cbf70:     	stp	q0, q1, [sp, #0xe0]
1015cbf74:     	ldr	w8, [x23]
1015cbf78:     	cmp	w8, #0x6
1015cbf7c:     	b.ne	0x1015cc1a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2044>
1015cbf80:     	ldp	q0, q1, [sp, #0x60]
1015cbf84:     	str	q0, [sp, #0x440]
1015cbf88:     	str	q1, [sp, #0x450]
1015cbf8c:     	ldp	q0, q1, [sp, #0x80]
1015cbf90:     	str	q0, [sp, #0x460]
1015cbf94:     	str	q1, [sp, #0x470]
1015cbf98:     	ldr	x8, [sp, #0x58]
1015cbf9c:     	ldp	q0, q1, [x8, #0x80]
1015cbfa0:     	str	q0, [sp, #0x5d0]
1015cbfa4:     	str	q1, [sp, #0x5e0]
1015cbfa8:     	ldr	x9, [x8, #0xa0]
1015cbfac:     	str	x9, [sp, #0x5f0]
1015cbfb0:     	ldp	q0, q1, [x8, #0x40]
1015cbfb4:     	str	q0, [sp, #0x590]
1015cbfb8:     	str	q1, [sp, #0x5a0]
1015cbfbc:     	ldp	q1, q0, [x8, #0x60]
1015cbfc0:     	str	q0, [sp, #0x5c0]
1015cbfc4:     	str	q1, [sp, #0x5b0]
1015cbfc8:     	ldp	q0, q1, [x8]
1015cbfcc:     	str	q0, [sp, #0x550]
1015cbfd0:     	str	q1, [sp, #0x560]
1015cbfd4:     	ldp	q1, q0, [x8, #0x20]
1015cbfd8:     	str	q0, [sp, #0x580]
1015cbfdc:     	str	q1, [sp, #0x570]
1015cbfe0:     	ldr	x9, [x8, #0x490]
1015cbfe4:     	add	x8, sp, #0x110
1015cbfe8:     	add	x1, sp, #0x440
1015cbfec:     	add	x4, sp, #0x550
1015cbff0:     	add	x5, x9, #0x3b8
1015cbff4:     	add	x6, sp, #0xa0
1015cbff8:     	ldr	x0, [sp, #0x30]
1015cbffc:     	ldr	x2, [sp, #0x40]
1015cc000:     	mov	w3, #0x1                ; =1
1015cc004:     	bl	0x1027ed80c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private>
1015cc008:     	b	0x1015cc22c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x20cc>
1015cc00c:     	ldp	q0, q1, [sp, #0x3a0]
1015cc010:     	stur	q0, [x27, #0x4]
1015cc014:     	stur	q1, [x27, #0x14]
1015cc018:     	ldr	q0, [sp, #0x3c0]
1015cc01c:     	stur	q0, [x27, #0x24]
1015cc020:     	ldr	x8, [sp, #0x3d0]
1015cc024:     	stur	x8, [x27, #0x34]
1015cc028:     	ldr	q0, [sp, #0x550]
1015cc02c:     	ldr	q1, [sp, #0x560]
1015cc030:     	stur	q0, [x23, #0x4]
1015cc034:     	mov	w8, #0x2                ; =2
1015cc038:     	str	w8, [x23]
1015cc03c:     	b	0x1015cb5b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1454>
1015cc040:     	mov	x0, x19
1015cc044:     	ldr	x1, [sp, #0x58]
1015cc048:     	mov	x2, x20
1015cc04c:     	mov	x3, x24
1015cc050:     	add	sp, sp, #0x810
1015cc054:     	ldp	x29, x30, [sp, #0x50]
1015cc058:     	ldp	x20, x19, [sp, #0x40]
1015cc05c:     	ldp	x22, x21, [sp, #0x30]
1015cc060:     	ldp	x24, x23, [sp, #0x20]
1015cc064:     	ldp	x26, x25, [sp, #0x10]
1015cc068:     	ldp	x28, x27, [sp], #0x60
1015cc06c:     	b	0x1015bdfc4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation21prepare_window_region>
1015cc070:     	mov	x0, x19
1015cc074:     	ldr	x1, [sp, #0x58]
1015cc078:     	mov	x2, x20
1015cc07c:     	mov	x3, x24
1015cc080:     	add	sp, sp, #0x810
1015cc084:     	ldp	x29, x30, [sp, #0x50]
1015cc088:     	ldp	x20, x19, [sp, #0x40]
1015cc08c:     	ldp	x22, x21, [sp, #0x30]
1015cc090:     	ldp	x24, x23, [sp, #0x20]
1015cc094:     	ldp	x26, x25, [sp, #0x10]
1015cc098:     	ldp	x28, x27, [sp], #0x60
1015cc09c:     	b	0x1015c29ec <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation24finish_string_map_region>
1015cc0a0:     	ldr	x8, [sp, #0x58]
1015cc0a4:     	ldr	x8, [x8, #0xa8]
1015cc0a8:     	cbz	x8, 0x1015cc818 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26b8>
1015cc0ac:     	str	wzr, [x19]
1015cc0b0:     	mov	w8, #0xc                ; =12
1015cc0b4:     	strb	w8, [x19, #0x8]
1015cc0b8:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0xb98>
1015cc0bc:     	add	x8, x8, #0xf65
1015cc0c0:     	mov	w9, #0x2d               ; =45
1015cc0c4:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cc0c8:     	mov	x0, x19
1015cc0cc:     	ldr	x1, [sp, #0x58]
1015cc0d0:     	mov	x2, x20
1015cc0d4:     	mov	x3, x24
1015cc0d8:     	add	sp, sp, #0x810
1015cc0dc:     	ldp	x29, x30, [sp, #0x50]
1015cc0e0:     	ldp	x20, x19, [sp, #0x40]
1015cc0e4:     	ldp	x22, x21, [sp, #0x30]
1015cc0e8:     	ldp	x24, x23, [sp, #0x20]
1015cc0ec:     	ldp	x26, x25, [sp, #0x10]
1015cc0f0:     	ldp	x28, x27, [sp], #0x60
1015cc0f4:     	b	0x1015bd9c8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation20finish_window_region>
1015cc0f8:     	mov	x0, x19
1015cc0fc:     	ldr	x1, [sp, #0x58]
1015cc100:     	mov	x2, x20
1015cc104:     	mov	x3, x24
1015cc108:     	add	sp, sp, #0x810
1015cc10c:     	ldp	x29, x30, [sp, #0x50]
1015cc110:     	ldp	x20, x19, [sp, #0x40]
1015cc114:     	ldp	x22, x21, [sp, #0x30]
1015cc118:     	ldp	x24, x23, [sp, #0x20]
1015cc11c:     	ldp	x26, x25, [sp, #0x10]
1015cc120:     	ldp	x28, x27, [sp], #0x60
1015cc124:     	b	0x1015d93a8 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation22prepare_join_map_chunk>
1015cc128:     	ldr	q0, [sp, #0x440]
1015cc12c:     	ldr	q1, [sp, #0x450]
1015cc130:     	stp	q0, q1, [x22, #0x10]
1015cc134:     	ldr	q0, [sp, #0x460]
1015cc138:     	str	q0, [x22, #0x30]
1015cc13c:     	mov	w9, #0x2                ; =2
1015cc140:     	str	w9, [x22]
1015cc144:     	str	x8, [x22, #0x8]
1015cc148:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc14c:     	ldur	q0, [x27, #0x14]
1015cc150:     	ldr	x9, [sp, #0x48]
1015cc154:     	stur	q0, [x9, #0x14]
1015cc158:     	ldur	q0, [x27, #0x24]
1015cc15c:     	stur	q0, [x9, #0x24]
1015cc160:     	ldur	q0, [x27, #0x34]
1015cc164:     	stur	q0, [x9, #0x34]
1015cc168:     	ldr	q0, [sp, #0x590]
1015cc16c:     	str	q0, [x9, #0x40]
1015cc170:     	ldur	q0, [x27, #0x4]
1015cc174:     	stur	q0, [x9, #0x4]
1015cc178:     	str	w8, [x9]
1015cc17c:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc180:     	mov	w8, #0x1                ; =1
1015cc184:     	str	x8, [x23, #0x8]
1015cc188:     	mov	w8, #0x6                ; =6
1015cc18c:     	mov	w9, #0x2                ; =2
1015cc190:     	str	x9, [x23, #0x10]
1015cc194:     	str	w8, [x23]
1015cc198:     	add	x0, sp, #0x440
1015cc19c:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cc1a0:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc1a4:     	ldp	q0, q1, [sp, #0x60]
1015cc1a8:     	str	q0, [sp, #0x440]
1015cc1ac:     	str	q1, [sp, #0x450]
1015cc1b0:     	ldp	q0, q1, [sp, #0x80]
1015cc1b4:     	str	q0, [sp, #0x460]
1015cc1b8:     	str	q1, [sp, #0x470]
1015cc1bc:     	ldr	x8, [sp, #0x58]
1015cc1c0:     	ldp	q0, q1, [x8, #0x80]
1015cc1c4:     	str	q0, [sp, #0x5d0]
1015cc1c8:     	str	q1, [sp, #0x5e0]
1015cc1cc:     	ldr	x9, [x8, #0xa0]
1015cc1d0:     	str	x9, [sp, #0x5f0]
1015cc1d4:     	ldp	q0, q1, [x8, #0x40]
1015cc1d8:     	str	q0, [sp, #0x590]
1015cc1dc:     	str	q1, [sp, #0x5a0]
1015cc1e0:     	ldp	q1, q0, [x8, #0x60]
1015cc1e4:     	str	q0, [sp, #0x5c0]
1015cc1e8:     	str	q1, [sp, #0x5b0]
1015cc1ec:     	ldp	q0, q1, [x8]
1015cc1f0:     	str	q0, [sp, #0x550]
1015cc1f4:     	str	q1, [sp, #0x560]
1015cc1f8:     	ldp	q1, q0, [x8, #0x20]
1015cc1fc:     	str	q0, [sp, #0x580]
1015cc200:     	str	q1, [sp, #0x570]
1015cc204:     	ldr	x9, [x8, #0x490]
1015cc208:     	add	x8, sp, #0x110
1015cc20c:     	add	x1, sp, #0x440
1015cc210:     	add	x5, sp, #0x550
1015cc214:     	add	x6, x9, #0x3b8
1015cc218:     	add	x7, sp, #0xa0
1015cc21c:     	ldp	x0, x2, [sp, #0x30]
1015cc220:     	ldr	x3, [sp, #0x40]
1015cc224:     	mov	w4, #0x1                ; =1
1015cc228:     	bl	0x1027ec854 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private>
1015cc22c:     	ldr	x9, [sp, #0x110]
1015cc230:     	add	x8, sp, #0x110
1015cc234:     	cbz	x9, 0x1015cc784 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2624>
1015cc238:     	add	x10, sp, #0x110
1015cc23c:     	ldur	q0, [x10, #0xc8]
1015cc240:     	stur	q0, [x25, #0xc8]
1015cc244:     	ldur	q0, [x10, #0xd8]
1015cc248:     	stur	q0, [x25, #0xd8]
1015cc24c:     	ldur	q0, [x10, #0xe8]
1015cc250:     	stur	q0, [x25, #0xe8]
1015cc254:     	ldur	q0, [x10, #0xf8]
1015cc258:     	stur	q0, [x25, #0xf8]
1015cc25c:     	ldur	q0, [x10, #0x88]
1015cc260:     	stur	q0, [x25, #0x88]
1015cc264:     	ldur	q0, [x10, #0x98]
1015cc268:     	stur	q0, [x25, #0x98]
1015cc26c:     	ldur	q0, [x10, #0xa8]
1015cc270:     	stur	q0, [x25, #0xa8]
1015cc274:     	ldur	q0, [x10, #0xb8]
1015cc278:     	stur	q0, [x25, #0xb8]
1015cc27c:     	ldur	q0, [x10, #0x58]
1015cc280:     	stur	q0, [x25, #0x58]
1015cc284:     	ldur	q0, [x10, #0x68]
1015cc288:     	stur	q0, [x25, #0x68]
1015cc28c:     	ldur	q0, [x10, #0x78]
1015cc290:     	stur	q0, [x25, #0x78]
1015cc294:     	ldur	q0, [x8, #0x18]
1015cc298:     	stur	q0, [x25, #0x18]
1015cc29c:     	ldur	q0, [x8, #0x28]
1015cc2a0:     	stur	q0, [x25, #0x28]
1015cc2a4:     	ldur	q0, [x8, #0x38]
1015cc2a8:     	stur	q0, [x25, #0x38]
1015cc2ac:     	ldur	q0, [x8, #0x48]
1015cc2b0:     	stur	q0, [x25, #0x48]
1015cc2b4:     	ldur	q0, [x8, #0x8]
1015cc2b8:     	stur	q0, [x25, #0x8]
1015cc2bc:     	str	x9, [sp, #0x220]
1015cc2c0:     	ldr	x8, [sp, #0x58]
1015cc2c4:     	ldr	x9, [x8, #0x490]
1015cc2c8:     	sub	x8, x29, #0xb0
1015cc2cc:     	add	x0, x9, #0x3b8
1015cc2d0:     	bl	0x102363ab8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015cc2d4:     	ldr	x8, [x19, #0x5e8]
1015cc2d8:     	cmn	x8, #0x1, lsl #12       ; =0x1000
1015cc2dc:     	b.hs	0x1015cd6b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3554>
1015cc2e0:     	add	x24, x8, #0x1, lsl #12  ; =0x1000
1015cc2e4:     	lsr	x8, x24, #60
1015cc2e8:     	cbnz	x8, 0x1015cd6d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3574>
1015cc2ec:     	ldr	x8, [sp, #0x58]
1015cc2f0:     	ldr	x8, [x8, #0x490]
1015cc2f4:     	lsl	x2, x24, #4
1015cc2f8:     	mov	w19, #0x1               ; =1
1015cc2fc:     	add	x0, sp, #0x550
1015cc300:     	add	x1, x8, #0x2f8
1015cc304:     	bl	0x1015b2708 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015cc308:     	ldrb	w8, [sp, #0x550]
1015cc30c:     	cmp	w8, #0xe
1015cc310:     	b.ne	0x1015cc7c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2660>
1015cc314:     	add	x8, sp, #0x550
1015cc318:     	sub	x0, x29, #0xb0
1015cc31c:     	mov	x1, x24
1015cc320:     	bl	0x102d54f5c <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1015cc324:     	ldr	w8, [sp, #0x550]
1015cc328:     	cmp	w8, #0x1a
1015cc32c:     	b.ne	0x1015cc9b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2850>
1015cc330:     	ldur	q0, [x27, #0x18]
1015cc334:     	ldur	q1, [x27, #0x8]
1015cc338:     	stp	q1, q0, [x29, #-0x90]
1015cc33c:     	ldr	x1, [x23, x22]
1015cc340:     	ldr	x8, [sp, #0x28]
1015cc344:     	cmp	x1, x8
1015cc348:     	b.hs	0x1015cdeb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d50>
1015cc34c:     	mov	w8, #0x18               ; =24
1015cc350:     	ldr	x9, [sp, #0x20]
1015cc354:     	madd	x8, x1, x8, x9
1015cc358:     	ldrb	w8, [x8, #0x12]
1015cc35c:     	tbz	w8, #0x0, 0x1015cc514 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x23b4>
1015cc360:     	ldr	x8, [sp, #0x58]
1015cc364:     	ldr	x8, [x8, #0x490]
1015cc368:     	ldr	x8, [x8, #0x3c0]
1015cc36c:     	cbz	x8, 0x1015cca74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2914>
1015cc370:     	ldr	x9, [x8, #0x40]
1015cc374:     	cmp	x9, #0x2
1015cc378:     	b.eq	0x1015cca74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2914>
1015cc37c:     	ldr	x10, [x8, #0xd8]
1015cc380:     	ldr	x9, [sp, #0x48]
1015cc384:     	cmp	x10, x9
1015cc388:     	b.ne	0x1015cca74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2914>
1015cc38c:     	ldr	x9, [x8, #0x80]
1015cc390:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1015cc394:     	cmp	x9, x10
1015cc398:     	b.eq	0x1015cca74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2914>
1015cc39c:     	ldr	x9, [x8, #0x90]
1015cc3a0:     	cmp	x1, x9
1015cc3a4:     	b.hs	0x1015cca74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2914>
1015cc3a8:     	ldr	x8, [x8, #0x88]
1015cc3ac:     	mov	w9, #0x70               ; =112
1015cc3b0:     	madd	x8, x1, x9, x8
1015cc3b4:     	ldr	x11, [x8]
1015cc3b8:     	ldr	d0, [x8, #0x8]
1015cc3bc:     	ldrb	w12, [x8, #0x10]
1015cc3c0:     	ldp	x9, x10, [x8, #0x18]
1015cc3c4:     	str	xzr, [x8]
1015cc3c8:     	cbz	x11, 0x1015cd430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32d0>
1015cc3cc:     	ldur	q1, [x8, #0x58]
1015cc3d0:     	stur	q1, [x26, #0x58]
1015cc3d4:     	ldr	x13, [x8, #0x68]
1015cc3d8:     	str	x13, [sp, #0x398]
1015cc3dc:     	str	x11, [sp, #0x330]
1015cc3e0:     	str	d0, [sp, #0x338]
1015cc3e4:     	strb	w12, [sp, #0x340]
1015cc3e8:     	ldur	w11, [x8, #0x11]
1015cc3ec:     	stur	w11, [x26, #0x11]
1015cc3f0:     	ldr	w11, [x8, #0x14]
1015cc3f4:     	str	w11, [sp, #0x344]
1015cc3f8:     	str	x9, [sp, #0x348]
1015cc3fc:     	str	x10, [sp, #0x350]
1015cc400:     	ldur	q0, [x8, #0x28]
1015cc404:     	stur	q0, [x26, #0x28]
1015cc408:     	ldur	q0, [x8, #0x38]
1015cc40c:     	stur	q0, [x26, #0x38]
1015cc410:     	ldur	q0, [x8, #0x48]
1015cc414:     	stur	q0, [x26, #0x48]
1015cc418:     	add	x0, sp, #0x550
1015cc41c:     	add	x1, sp, #0x220
1015cc420:     	mov	w2, #0x108              ; =264
1015cc424:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1015cc428:     	mov	w19, #0x0               ; =0
1015cc42c:     	add	x24, sp, #0x440
1015cc430:     	add	x8, sp, #0x440
1015cc434:     	add	x0, sp, #0x550
1015cc438:     	add	x1, sp, #0x330
1015cc43c:     	bl	0x102e12758 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix23with_append_preparation>
1015cc440:     	ldr	x8, [sp, #0x440]
1015cc444:     	cbz	x8, 0x1015cd538 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33d8>
1015cc448:     	add	x9, sp, #0x220
1015cc44c:     	ldr	w10, [sp, #0x448]
1015cc450:     	add	x11, sp, #0x440
1015cc454:     	ldur	q0, [x11, #0x1c]
1015cc458:     	ldur	q1, [x11, #0x2c]
1015cc45c:     	ldur	q2, [x11, #0x3c]
1015cc460:     	str	q1, [sp, #0x410]
1015cc464:     	str	q2, [sp, #0x420]
1015cc468:     	ldur	q1, [x11, #0x48]
1015cc46c:     	stur	q1, [x26, #0xfc]
1015cc470:     	ldur	q1, [x11, #0xc]
1015cc474:     	stp	q1, q0, [sp, #0x3f0]
1015cc478:     	ldur	q0, [x11, #0xc8]
1015cc47c:     	stur	q0, [x9, #0xc8]
1015cc480:     	ldur	q0, [x11, #0xd8]
1015cc484:     	stur	q0, [x9, #0xd8]
1015cc488:     	ldur	q0, [x11, #0xe8]
1015cc48c:     	stur	q0, [x9, #0xe8]
1015cc490:     	ldur	q0, [x11, #0xf8]
1015cc494:     	stur	q0, [x9, #0xf8]
1015cc498:     	ldur	q0, [x11, #0x88]
1015cc49c:     	stur	q0, [x9, #0x88]
1015cc4a0:     	ldur	q0, [x11, #0x98]
1015cc4a4:     	stur	q0, [x9, #0x98]
1015cc4a8:     	ldur	q0, [x11, #0xa8]
1015cc4ac:     	stur	q0, [x9, #0xa8]
1015cc4b0:     	ldur	q0, [x11, #0xb8]
1015cc4b4:     	stur	q0, [x9, #0xb8]
1015cc4b8:     	ldur	q0, [x11, #0x58]
1015cc4bc:     	stur	q0, [x9, #0x58]
1015cc4c0:     	ldur	q0, [x11, #0x68]
1015cc4c4:     	stur	q0, [x9, #0x68]
1015cc4c8:     	ldur	q0, [x11, #0x78]
1015cc4cc:     	stur	q0, [x9, #0x78]
1015cc4d0:     	ldur	q0, [x26, #0xfc]
1015cc4d4:     	stur	q0, [x26, #0xac]
1015cc4d8:     	ldr	q0, [sp, #0x420]
1015cc4dc:     	ldr	q1, [sp, #0x410]
1015cc4e0:     	stp	q1, q0, [sp, #0x3c0]
1015cc4e4:     	ldp	q2, q0, [sp, #0x3f0]
1015cc4e8:     	stp	q2, q0, [sp, #0x3a0]
1015cc4ec:     	stur	q0, [x25, #0x1c]
1015cc4f0:     	stur	q1, [x25, #0x2c]
1015cc4f4:     	stur	q2, [x25, #0xc]
1015cc4f8:     	ldr	q0, [sp, #0x3d0]
1015cc4fc:     	stur	q0, [x25, #0x3c]
1015cc500:     	ldur	q0, [x26, #0xac]
1015cc504:     	stur	q0, [x25, #0x48]
1015cc508:     	str	x8, [sp, #0x220]
1015cc50c:     	str	w10, [sp, #0x228]
1015cc510:     	ldr	x1, [x23, x22]
1015cc514:     	mov	w19, #0x1               ; =1
1015cc518:     	mov	x0, x20
1015cc51c:     	bl	0x101510250 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare16readonly_numericNtB2_5Proof8capacity>
1015cc520:     	cmp	x0, #0x1
1015cc524:     	b.ne	0x1015ccbbc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a5c>
1015cc528:     	mov	x20, x1
1015cc52c:     	add	x8, sp, #0x550
1015cc530:     	add	x0, sp, #0x220
1015cc534:     	bl	0x102e12640 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix20reserved_native_view>
1015cc538:     	ldr	w8, [sp, #0x550]
1015cc53c:     	tbz	w8, #0x0, 0x1015cd0cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f6c>
1015cc540:     	ldr	x8, [sp, #0x58]
1015cc544:     	ldr	x10, [x8, #0x4d0]
1015cc548:     	cbz	x10, 0x1015cd358 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f8>
1015cc54c:     	ldr	x8, [x23, x22]
1015cc550:     	ldr	x9, [x21, #0xb0]
1015cc554:     	add	x8, x9, x8, lsl #2
1015cc558:     	add	x11, x8, #0x3
1015cc55c:     	ldr	x8, [sp, #0x58]
1015cc560:     	ldr	x8, [x8, #0x4d8]
1015cc564:     	cmp	x11, x8
1015cc568:     	b.hs	0x1015cd358 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f8>
1015cc56c:     	ldr	x19, [sp, #0x558]
1015cc570:     	ldr	x9, [sp, #0x560]
1015cc574:     	ldr	x8, [sp, #0x568]
1015cc578:     	str	x9, [x10, x11, lsl #3]
1015cc57c:     	ldr	x10, [sp, #0x58]
1015cc580:     	ldr	x10, [x10, #0x4d0]
1015cc584:     	cbz	x10, 0x1015cd290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3130>
1015cc588:     	ldr	x11, [x23, x22]
1015cc58c:     	ldr	x12, [x21, #0xb0]
1015cc590:     	add	x11, x12, x11, lsl #2
1015cc594:     	add	x11, x11, #0x4
1015cc598:     	ldr	x12, [sp, #0x58]
1015cc59c:     	ldr	x12, [x12, #0x4d8]
1015cc5a0:     	cmp	x11, x12
1015cc5a4:     	b.hs	0x1015cd290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3130>
1015cc5a8:     	mov	w12, #0x1               ; =1
1015cc5ac:     	str	x12, [x10, x11, lsl #3]
1015cc5b0:     	ldr	x10, [sp, #0x58]
1015cc5b4:     	ldr	x10, [x10, #0x4d0]
1015cc5b8:     	cbz	x10, 0x1015cd290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3130>
1015cc5bc:     	ldr	x11, [x23, x22]
1015cc5c0:     	ldr	x12, [x21, #0xb0]
1015cc5c4:     	add	x11, x12, x11, lsl #2
1015cc5c8:     	add	x11, x11, #0x5
1015cc5cc:     	ldr	x12, [sp, #0x58]
1015cc5d0:     	ldr	x12, [x12, #0x4d8]
1015cc5d4:     	cmp	x11, x12
1015cc5d8:     	b.hs	0x1015cd290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3130>
1015cc5dc:     	str	x9, [x10, x11, lsl #3]
1015cc5e0:     	ldr	x9, [sp, #0x58]
1015cc5e4:     	ldr	x9, [x9, #0x4d0]
1015cc5e8:     	cbz	x9, 0x1015cd290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3130>
1015cc5ec:     	add	x10, x20, #0x2
1015cc5f0:     	ldr	x11, [sp, #0x58]
1015cc5f4:     	ldr	x11, [x11, #0x4d8]
1015cc5f8:     	cmp	x10, x11
1015cc5fc:     	b.hs	0x1015cd290 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3130>
1015cc600:     	str	x8, [x9, x10, lsl #3]
1015cc604:     	b	0x1015ccbcc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a6c>
1015cc608:     	ldur	w15, [x9, #0x11]
1015cc60c:     	stur	w15, [x27, #0x9]
1015cc610:     	ldur	w15, [x9, #0x14]
1015cc614:     	str	w15, [sp, #0x55c]
1015cc618:     	str	w14, [sp, #0x550]
1015cc61c:     	str	w13, [sp, #0x554]
1015cc620:     	strb	w12, [sp, #0x558]
1015cc624:     	str	x11, [sp, #0x560]
1015cc628:     	str	x10, [sp, #0x568]
1015cc62c:     	ldur	q0, [x9, #0x28]
1015cc630:     	ldur	q1, [x9, #0x38]
1015cc634:     	str	q1, [sp, #0x580]
1015cc638:     	str	q0, [sp, #0x570]
1015cc63c:     	ldur	q0, [x9, #0x48]
1015cc640:     	ldur	q1, [x9, #0x58]
1015cc644:     	ldur	q2, [x9, #0x68]
1015cc648:     	ldur	q3, [x9, #0x78]
1015cc64c:     	ldur	q4, [x9, #0x88]
1015cc650:     	ldur	q5, [x9, #0x98]
1015cc654:     	ldur	q6, [x9, #0xa8]
1015cc658:     	ldur	q7, [x9, #0xb8]
1015cc65c:     	str	q7, [sp, #0x600]
1015cc660:     	str	q6, [sp, #0x5f0]
1015cc664:     	str	q5, [sp, #0x5e0]
1015cc668:     	str	q4, [sp, #0x5d0]
1015cc66c:     	str	q3, [sp, #0x5c0]
1015cc670:     	str	q2, [sp, #0x5b0]
1015cc674:     	str	q0, [sp, #0x590]
1015cc678:     	str	q1, [sp, #0x5a0]
1015cc67c:     	ldr	x9, [x8, #0x48]
1015cc680:     	cmn	x9, #0x1
1015cc684:     	b.eq	0x1015cd714 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35b4>
1015cc688:     	add	x9, x9, #0x1
1015cc68c:     	str	x9, [x8, #0x48]
1015cc690:     	ldr	x8, [x8, #0x50]
1015cc694:     	cmp	x9, x8
1015cc698:     	b.ne	0x1015cc710 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25b0>
1015cc69c:     	ldr	x8, [x20, #0x3d8]
1015cc6a0:     	cbz	x8, 0x1015cc710 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25b0>
1015cc6a4:     	ldr	x10, [x20, #0x3d0]
1015cc6a8:     	add	x11, x10, #0x1
1015cc6ac:     	ldr	x12, [x20, #0x3c0]
1015cc6b0:     	cmp	x11, x12
1015cc6b4:     	csel	x12, xzr, x12, lo
1015cc6b8:     	sub	x11, x11, x12
1015cc6bc:     	str	x11, [x20, #0x3d0]
1015cc6c0:     	sub	x8, x8, #0x1
1015cc6c4:     	str	x8, [x20, #0x3d8]
1015cc6c8:     	ldr	x8, [x20, #0x3c8]
1015cc6cc:     	mov	w9, #0x58               ; =88
1015cc6d0:     	madd	x8, x10, x9, x8
1015cc6d4:     	ldp	q1, q0, [x8]
1015cc6d8:     	str	q1, [sp, #0x440]
1015cc6dc:     	str	q0, [sp, #0x450]
1015cc6e0:     	ldp	q1, q0, [x8, #0x30]
1015cc6e4:     	ldr	x9, [x8, #0x50]
1015cc6e8:     	ldr	q2, [x8, #0x20]
1015cc6ec:     	str	x9, [sp, #0x490]
1015cc6f0:     	str	q0, [sp, #0x480]
1015cc6f4:     	str	q2, [sp, #0x460]
1015cc6f8:     	str	q1, [sp, #0x470]
1015cc6fc:     	ldr	x8, [sp, #0x440]
1015cc700:     	cbz	x8, 0x1015cc710 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25b0>
1015cc704:     	mov	w24, #0x1               ; =1
1015cc708:     	add	x0, sp, #0x440
1015cc70c:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cc710:     	ldr	x9, [x21, #0x18]
1015cc714:     	cbz	x9, 0x1015cc980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2820>
1015cc718:     	ldr	w0, [sp, #0x608]
1015cc71c:     	ldr	x8, [x21, #0x10]
1015cc720:     	cmp	x9, #0x1
1015cc724:     	b.ne	0x1015cc878 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2718>
1015cc728:     	mov	x10, #0x0               ; =0
1015cc72c:     	b	0x1015cc89c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x273c>
1015cc730:     	ldur	w8, [x9, #0x11]
1015cc734:     	str	w8, [sp, #0xa0]
1015cc738:     	ldur	w8, [x9, #0x14]
1015cc73c:     	stur	w8, [sp, #0xa3]
1015cc740:     	ldur	q0, [x9, #0x28]
1015cc744:     	ldur	q1, [x9, #0x38]
1015cc748:     	stp	q0, q1, [sp, #0x110]
1015cc74c:     	ldur	q0, [x9, #0x48]
1015cc750:     	str	q0, [sp, #0x330]
1015cc754:     	stp	w14, w13, [x19]
1015cc758:     	strb	w12, [x19, #0x8]
1015cc75c:     	mov	w8, w8
1015cc760:     	str	w8, [x19, #0xc]
1015cc764:     	ldr	w8, [sp, #0xa0]
1015cc768:     	stur	w8, [x19, #0x9]
1015cc76c:     	stp	x11, x10, [x19, #0x10]
1015cc770:     	ldp	q1, q0, [sp, #0x110]
1015cc774:     	stp	q1, q0, [x19, #0x20]
1015cc778:     	ldr	q0, [sp, #0x330]
1015cc77c:     	str	q0, [x19, #0x40]
1015cc780:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc784:     	ldr	x1, [x19, #0x378]
1015cc788:     	ldr	x2, [x19, #0x380]
1015cc78c:     	add	x0, sp, #0x550
1015cc790:     	add	x4, x8, #0x8
1015cc794:     	ldr	x3, [sp, #0x50]
1015cc798:     	bl	0x1015b178c <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14numeric_writesNtB6_10Invocation21prepare_numeric_writes1_0Be_>
1015cc79c:     	ldr	q0, [sp, #0x570]
1015cc7a0:     	ldr	q1, [sp, #0x580]
1015cc7a4:     	stp	q0, q1, [x28, #0x20]
1015cc7a8:     	ldr	q0, [sp, #0x590]
1015cc7ac:     	str	q0, [x28, #0x40]
1015cc7b0:     	ldr	q0, [sp, #0x560]
1015cc7b4:     	ldr	q1, [sp, #0x550]
1015cc7b8:     	stp	q1, q0, [x28]
1015cc7bc:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc7c0:     	ldr	q0, [sp, #0x550]
1015cc7c4:     	ldr	q1, [sp, #0x560]
1015cc7c8:     	str	q0, [sp, #0x440]
1015cc7cc:     	str	q1, [sp, #0x450]
1015cc7d0:     	ldr	q2, [sp, #0x570]
1015cc7d4:     	str	q2, [sp, #0x460]
1015cc7d8:     	ldr	x8, [sp, #0x580]
1015cc7dc:     	str	x8, [sp, #0x470]
1015cc7e0:     	stur	q0, [x27, #0x4]
1015cc7e4:     	stur	q1, [x27, #0x14]
1015cc7e8:     	stur	q2, [x27, #0x24]
1015cc7ec:     	stur	x8, [x27, #0x34]
1015cc7f0:     	str	wzr, [x28]
1015cc7f4:     	ldr	q0, [sp, #0x550]
1015cc7f8:     	ldr	q1, [sp, #0x560]
1015cc7fc:     	stur	q0, [x28, #0x4]
1015cc800:     	stur	q1, [x28, #0x14]
1015cc804:     	ldr	q0, [sp, #0x570]
1015cc808:     	stur	q0, [x28, #0x24]
1015cc80c:     	ldur	q0, [x27, #0x2c]
1015cc810:     	str	q0, [x28, #0x30]
1015cc814:     	b	0x1015cc9ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x288c>
1015cc818:     	cmp	x22, #0x1
1015cc81c:     	b.gt	0x1015cca10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28b0>
1015cc820:     	cbz	x22, 0x1015cca90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2930>
1015cc824:     	cmp	x22, #0x1
1015cc828:     	b.ne	0x1015ccb04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29a4>
1015cc82c:     	ldr	x8, [sp, #0x58]
1015cc830:     	ldr	x8, [x8, #0x490]
1015cc834:     	ldrb	w8, [x8, #0x460]
1015cc838:     	tbz	w8, #0x0, 0x1015cce10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2cb0>
1015cc83c:     	str	wzr, [x19]
1015cc840:     	mov	w8, #0xc                ; =12
1015cc844:     	strb	w8, [x19, #0x8]
1015cc848:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0xb98>
1015cc84c:     	add	x8, x8, #0xfad
1015cc850:     	mov	w9, #0x16               ; =22
1015cc854:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cc858:     	str	wzr, [x23]
1015cc85c:     	mov	w8, #0xc                ; =12
1015cc860:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cc864:     	add	x9, x9, #0x620
1015cc868:     	stp	x8, x9, [x23, #0x8]
1015cc86c:     	mov	w8, #0x1a               ; =26
1015cc870:     	str	x8, [x23, #0x18]
1015cc874:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc878:     	mov	x10, #0x0               ; =0
1015cc87c:     	lsr	x11, x9, #1
1015cc880:     	add	x12, x11, x10
1015cc884:     	ldr	w13, [x8, x12, lsl #2]
1015cc888:     	cmp	w13, w0
1015cc88c:     	csel	x10, x10, x12, hi
1015cc890:     	sub	x9, x9, x11
1015cc894:     	cmp	x9, #0x1
1015cc898:     	b.hi	0x1015cc87c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x271c>
1015cc89c:     	ldr	w8, [x8, x10, lsl #2]
1015cc8a0:     	cmp	w8, w0
1015cc8a4:     	b.ne	0x1015cc980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2820>
1015cc8a8:     	ldr	x1, [x22, #0x380]
1015cc8ac:     	cmp	x1, x0
1015cc8b0:     	b.ls	0x1015cde9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d3c>
1015cc8b4:     	ldr	x8, [x22, #0x378]
1015cc8b8:     	mov	w9, #0x170              ; =368
1015cc8bc:     	umaddl	x8, w0, w9, x8
1015cc8c0:     	add	x9, x8, #0x15c
1015cc8c4:     	ldr	w8, [x8, #0x16c]
1015cc8c8:     	str	w8, [sp, #0x450]
1015cc8cc:     	ldr	q0, [x9]
1015cc8d0:     	str	q0, [sp, #0x440]
1015cc8d4:     	mov	w24, #0x1               ; =1
1015cc8d8:     	add	x8, sp, #0x220
1015cc8dc:     	add	x0, sp, #0x440
1015cc8e0:     	bl	0x102736074 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
1015cc8e4:     	ldr	w8, [x21, #0x48]
1015cc8e8:     	ldr	w9, [sp, #0x220]
1015cc8ec:     	cmp	w9, #0x1
1015cc8f0:     	b.ne	0x1015cc900 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27a0>
1015cc8f4:     	ldr	w9, [sp, #0x224]
1015cc8f8:     	cmp	w9, w8
1015cc8fc:     	b.eq	0x1015cc918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27b8>
1015cc900:     	ldr	w9, [sp, #0x228]
1015cc904:     	cmp	w9, #0x1
1015cc908:     	b.ne	0x1015cc980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2820>
1015cc90c:     	ldr	w9, [sp, #0x22c]
1015cc910:     	cmp	w9, w8
1015cc914:     	b.ne	0x1015cc980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2820>
1015cc918:     	ldr	x22, [sp, #0x550]
1015cc91c:     	cmp	x22, #0x0
1015cc920:     	cset	w23, eq
1015cc924:     	cbz	x22, 0x1015ccb3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29dc>
1015cc928:     	ldr	q0, [sp, #0x550]
1015cc92c:     	ldr	q1, [sp, #0x560]
1015cc930:     	str	q0, [sp, #0x440]
1015cc934:     	str	q1, [sp, #0x450]
1015cc938:     	ldr	q0, [sp, #0x570]
1015cc93c:     	ldr	q1, [sp, #0x580]
1015cc940:     	str	q0, [sp, #0x460]
1015cc944:     	str	q1, [sp, #0x470]
1015cc948:     	ldr	x9, [x20, #0x490]
1015cc94c:     	ldr	w1, [x21, #0x4c]
1015cc950:     	add	x8, sp, #0x220
1015cc954:     	add	x0, x9, #0xf0
1015cc958:     	add	x2, sp, #0x440
1015cc95c:     	add	x3, x9, #0x2f8
1015cc960:     	bl	0x1015d26b4 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
1015cc964:     	ldrb	w8, [sp, #0x220]
1015cc968:     	cmp	w8, #0x14
1015cc96c:     	b.ne	0x1015ccd00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ba0>
1015cc970:     	mov	w24, #0x0               ; =0
1015cc974:     	add	x0, sp, #0x440
1015cc978:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cc97c:     	b	0x1015ccb54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29f4>
1015cc980:     	str	wzr, [x19]
1015cc984:     	mov	w9, #0xc                ; =12
1015cc988:     	strb	w9, [x19, #0x8]
1015cc98c:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cc990:     	add	x8, x8, #0x347
1015cc994:     	mov	w9, #0x2d               ; =45
1015cc998:     	stp	x8, x9, [x19, #0x10]
1015cc99c:     	ldr	x8, [sp, #0x550]
1015cc9a0:     	cbz	x8, 0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc9a4:     	add	x0, sp, #0x550
1015cc9a8:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cc9ac:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cc9b0:     	ldur	q0, [x27, #0x4]
1015cc9b4:     	ldur	q1, [x27, #0x14]
1015cc9b8:     	str	q0, [sp, #0x440]
1015cc9bc:     	str	q1, [sp, #0x450]
1015cc9c0:     	ldr	w9, [sp, #0x574]
1015cc9c4:     	str	w9, [sp, #0x460]
1015cc9c8:     	ldr	x10, [sp, #0x578]
1015cc9cc:     	stur	q0, [x28, #0x14]
1015cc9d0:     	stur	q1, [x28, #0x24]
1015cc9d4:     	str	w9, [x28, #0x34]
1015cc9d8:     	str	wzr, [x28]
1015cc9dc:     	mov	w9, #0xd                ; =13
1015cc9e0:     	strb	w9, [x28, #0x8]
1015cc9e4:     	str	w8, [x28, #0x10]
1015cc9e8:     	str	x10, [x28, #0x38]
1015cc9ec:     	ldur	x8, [x29, #-0xb0]
1015cc9f0:     	mov	x9, #-0x1               ; =-1
1015cc9f4:     	ldaddl	x9, x8, [x8]
1015cc9f8:     	cmp	x8, #0x1
1015cc9fc:     	b.ne	0x1015cd114 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fb4>
1015cca00:     	dmb	ishld
1015cca04:     	sub	x0, x29, #0xb0
1015cca08:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015cca0c:     	b	0x1015cd114 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fb4>
1015cca10:     	cmp	x22, #0x2
1015cca14:     	b.eq	0x1015ccabc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x295c>
1015cca18:     	cmp	x22, #0x12
1015cca1c:     	b.ne	0x1015ccb04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29a4>
1015cca20:     	ldr	x8, [sp, #0x58]
1015cca24:     	ldr	x8, [x8, #0x490]
1015cca28:     	ldrb	w8, [x8, #0x460]
1015cca2c:     	tbnz	w8, #0x0, 0x1015cca44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28e4>
1015cca30:     	ldp	x8, x9, [x24]
1015cca34:     	ldr	x10, [x24, #0x10]
1015cca38:     	orr	x8, x8, x9
1015cca3c:     	orr	x8, x8, x10
1015cca40:     	cbz	x8, 0x1015cd1a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3044>
1015cca44:     	str	wzr, [x19]
1015cca48:     	mov	w8, #0xc                ; =12
1015cca4c:     	strb	w8, [x19, #0x8]
1015cca50:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cca54:     	add	x8, x8, #0x23
1015cca58:     	mov	w9, #0x2d               ; =45
1015cca5c:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cca60:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015cca64:     	add	x2, x2, #0x728
1015cca68:     	mov	x0, x9
1015cca6c:     	mov	x1, x10
1015cca70:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cca74:     	str	wzr, [x28]
1015cca78:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cca7c:     	add	x8, x8, #0x29d
1015cca80:     	mov	w9, #0xc                ; =12
1015cca84:     	stp	x9, x8, [x28, #0x8]
1015cca88:     	mov	w8, #0x30               ; =48
1015cca8c:     	b	0x1015cd0e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f84>
1015cca90:     	ldr	x8, [sp, #0x58]
1015cca94:     	ldr	x8, [x8, #0x490]
1015cca98:     	ldrb	w8, [x8, #0x460]
1015cca9c:     	tbz	w8, #0x0, 0x1015ccf44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2de4>
1015ccaa0:     	str	wzr, [x19]
1015ccaa4:     	mov	w8, #0xc                ; =12
1015ccaa8:     	strb	w8, [x19, #0x8]
1015ccaac:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ccab0:     	add	x8, x8, #0xb
1015ccab4:     	mov	w9, #0x18               ; =24
1015ccab8:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015ccabc:     	ldr	x8, [sp, #0x58]
1015ccac0:     	ldr	x8, [x8, #0x490]
1015ccac4:     	ldrb	w8, [x8, #0x460]
1015ccac8:     	tbnz	w8, #0x0, 0x1015cd088 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f28>
1015ccacc:     	ldr	x8, [x24, #0x10]
1015ccad0:     	cbnz	x8, 0x1015cd088 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f28>
1015ccad4:     	ldp	x3, x4, [x24]
1015ccad8:     	mov	x0, x19
1015ccadc:     	ldr	x1, [sp, #0x58]
1015ccae0:     	mov	x2, x20
1015ccae4:     	add	sp, sp, #0x810
1015ccae8:     	ldp	x29, x30, [sp, #0x50]
1015ccaec:     	ldp	x20, x19, [sp, #0x40]
1015ccaf0:     	ldp	x22, x21, [sp, #0x30]
1015ccaf4:     	ldp	x24, x23, [sp, #0x20]
1015ccaf8:     	ldp	x26, x25, [sp, #0x10]
1015ccafc:     	ldp	x28, x27, [sp], #0x60
1015ccb00:     	b	0x1015b892c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper>
1015ccb04:     	ldr	x5, [x24]
1015ccb08:     	mov	x0, x19
1015ccb0c:     	ldr	x1, [sp, #0x58]
1015ccb10:     	mov	x2, x20
1015ccb14:     	mov	x3, x22
1015ccb18:     	mov	x4, x21
1015ccb1c:     	add	sp, sp, #0x810
1015ccb20:     	ldp	x29, x30, [sp, #0x50]
1015ccb24:     	ldp	x20, x19, [sp, #0x40]
1015ccb28:     	ldp	x22, x21, [sp, #0x30]
1015ccb2c:     	ldp	x24, x23, [sp, #0x20]
1015ccb30:     	ldp	x26, x25, [sp, #0x10]
1015ccb34:     	ldp	x28, x27, [sp], #0x60
1015ccb38:     	b	0x1015b8c1c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper>
1015ccb3c:     	ldr	x8, [x20, #0x4d0]
1015ccb40:     	cbz	x8, 0x1015cd0b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f50>
1015ccb44:     	ldr	x9, [x20, #0x4d8]
1015ccb48:     	cbz	x9, 0x1015cd0b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f50>
1015ccb4c:     	ldr	x9, [sp, #0x558]
1015ccb50:     	str	x9, [x8]
1015ccb54:     	ldr	w8, [sp, #0x608]
1015ccb58:     	ldr	x10, [x20, #0x490]
1015ccb5c:     	mov	w11, #0x1               ; =1
1015ccb60:     	str	w11, [x10, #0x2f0]
1015ccb64:     	str	w8, [x10, #0x2f4]
1015ccb68:     	ldr	x8, [x20, #0x490]
1015ccb6c:     	strb	w11, [x8, #0x460]
1015ccb70:     	ldr	x8, [x20, #0x3c0]
1015ccb74:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015ccb78:     	cmp	x8, x9
1015ccb7c:     	b.eq	0x1015cd198 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
1015ccb80:     	ldr	x8, [x20, #0x3d8]
1015ccb84:     	cbnz	x8, 0x1015cd198 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3038>
1015ccb88:     	ldr	x9, [x20, #0x3e8]
1015ccb8c:     	ldr	x8, [x20, #0x3f8]
1015ccb90:     	cmp	x8, x9
1015ccb94:     	b.eq	0x1015cd184 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3024>
1015ccb98:     	str	wzr, [x19]
1015ccb9c:     	mov	w8, #0xc                ; =12
1015ccba0:     	strb	w8, [x19, #0x8]
1015ccba4:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ccba8:     	add	x8, x8, #0x374
1015ccbac:     	mov	w9, #0x25               ; =37
1015ccbb0:     	stp	x8, x9, [x19, #0x10]
1015ccbb4:     	cbz	x22, 0x1015cc99c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x283c>
1015ccbb8:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015ccbbc:     	add	x8, sp, #0x550
1015ccbc0:     	add	x0, sp, #0x220
1015ccbc4:     	bl	0x102e0d7d4 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix12elements_mut>
1015ccbc8:     	ldr	x19, [sp, #0x558]
1015ccbcc:     	add	x0, sp, #0x550
1015ccbd0:     	add	x1, sp, #0x220
1015ccbd4:     	mov	w2, #0x108              ; =264
1015ccbd8:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1015ccbdc:     	ldr	x8, [sp, #0x58]
1015ccbe0:     	ldr	x8, [x8, #0x490]
1015ccbe4:     	ldr	x8, [x8, #0x3c0]
1015ccbe8:     	cbz	x8, 0x1015ccd4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bec>
1015ccbec:     	ldr	x9, [x8, #0x40]
1015ccbf0:     	cmp	x9, #0x2
1015ccbf4:     	b.eq	0x1015ccd4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bec>
1015ccbf8:     	ldr	x10, [x8, #0xd8]
1015ccbfc:     	ldr	x9, [sp, #0x48]
1015ccc00:     	cmp	x10, x9
1015ccc04:     	b.ne	0x1015ccd4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bec>
1015ccc08:     	ldr	x9, [x23, x22]
1015ccc0c:     	ldr	x10, [x8, #0x78]
1015ccc10:     	cmp	x9, x10
1015ccc14:     	b.hs	0x1015ccd4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bec>
1015ccc18:     	ldr	x8, [x8, #0x70]
1015ccc1c:     	mov	w10, #0x108             ; =264
1015ccc20:     	madd	x20, x9, x10, x8
1015ccc24:     	mov	x0, x20
1015ccc28:     	bl	0x1015abc3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
1015ccc2c:     	add	x1, sp, #0x550
1015ccc30:     	mov	x0, x20
1015ccc34:     	mov	w2, #0x108              ; =264
1015ccc38:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1015ccc3c:     	ldr	x8, [sp, #0x58]
1015ccc40:     	ldr	x8, [x8, #0x4d0]
1015ccc44:     	cbz	x8, 0x1015cd354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f4>
1015ccc48:     	ldr	x9, [x23, x22]
1015ccc4c:     	ldr	x10, [x21, #0xb0]
1015ccc50:     	add	x9, x10, x9, lsl #2
1015ccc54:     	add	x9, x9, #0x2
1015ccc58:     	ldr	x10, [sp, #0x58]
1015ccc5c:     	ldr	x10, [x10, #0x4d8]
1015ccc60:     	cmp	x9, x10
1015ccc64:     	b.hs	0x1015cd354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f4>
1015ccc68:     	str	x19, [x8, x9, lsl #3]
1015ccc6c:     	ldr	x8, [sp, #0x58]
1015ccc70:     	ldr	x8, [x8, #0x4d0]
1015ccc74:     	cbz	x8, 0x1015cd354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f4>
1015ccc78:     	ldr	x9, [x23, x22]
1015ccc7c:     	ldr	x10, [x21, #0x40]
1015ccc80:     	ldr	x11, [x21, #0xb0]
1015ccc84:     	add	x9, x9, x10, lsl #2
1015ccc88:     	add	x9, x9, x11
1015ccc8c:     	add	x9, x9, #0x2
1015ccc90:     	ldr	x10, [sp, #0x58]
1015ccc94:     	ldr	x10, [x10, #0x4d8]
1015ccc98:     	cmp	x9, x10
1015ccc9c:     	b.hs	0x1015cd354 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31f4>
1015ccca0:     	mov	w10, #0x1               ; =1
1015ccca4:     	str	x10, [x8, x9, lsl #3]
1015ccca8:     	mov	w19, #0x0               ; =0
1015cccac:     	add	x0, sp, #0x550
1015cccb0:     	ldp	x3, x1, [sp, #0x50]
1015cccb4:     	ldr	x2, [sp, #0x48]
1015cccb8:     	bl	0x1015bd890 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation26resume_numeric_after_write>
1015cccbc:     	ldr	w8, [sp, #0x550]
1015cccc0:     	cmp	w8, #0x6
1015cccc4:     	b.ne	0x1015cd68c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x352c>
1015cccc8:     	str	xzr, [x28, #0x8]
1015ccccc:     	str	w8, [x28]
1015cccd0:     	mov	w19, #0x0               ; =0
1015cccd4:     	sub	x0, x29, #0x90
1015cccd8:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015cccdc:     	ldur	x8, [x29, #-0xb0]
1015ccce0:     	mov	x9, #-0x1               ; =-1
1015ccce4:     	ldaddl	x9, x8, [x8]
1015ccce8:     	cmp	x8, #0x1
1015cccec:     	b.ne	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cccf0:     	dmb	ishld
1015cccf4:     	sub	x0, x29, #0xb0
1015cccf8:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015cccfc:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015ccd00:     	ldur	w9, [x25, #0x1]
1015ccd04:     	stur	w9, [x19, #0x9]
1015ccd08:     	ldr	w9, [sp, #0x224]
1015ccd0c:     	str	w9, [x19, #0xc]
1015ccd10:     	ldr	q0, [sp, #0x240]
1015ccd14:     	stur	q0, [x19, #0x28]
1015ccd18:     	ldr	x9, [sp, #0x250]
1015ccd1c:     	str	x9, [x19, #0x38]
1015ccd20:     	ldr	d0, [sp, #0x238]
1015ccd24:     	ldur	q1, [x25, #0x8]
1015ccd28:     	mov	w9, #0x2                ; =2
1015ccd2c:     	str	w9, [x19]
1015ccd30:     	strb	w8, [x19, #0x8]
1015ccd34:     	str	q1, [x19, #0x10]
1015ccd38:     	str	d0, [x19, #0x20]
1015ccd3c:     	mov	w24, #0x0               ; =0
1015ccd40:     	add	x0, sp, #0x440
1015ccd44:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015ccd48:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015ccd4c:     	str	wzr, [x28]
1015ccd50:     	mov	w8, #0xc                ; =12
1015ccd54:     	adrp	x9, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015ccd58:     	add	x9, x9, #0x86
1015ccd5c:     	stp	x8, x9, [x28, #0x8]
1015ccd60:     	mov	w8, #0x2b               ; =43
1015ccd64:     	str	x8, [x28, #0x18]
1015ccd68:     	mov	w19, #0x0               ; =0
1015ccd6c:     	add	x0, sp, #0x550
1015ccd70:     	bl	0x1015abc3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
1015ccd74:     	mov	w19, #0x0               ; =0
1015ccd78:     	b	0x1015cd0e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f88>
1015ccd7c:     	add	x8, sp, #0x550
1015ccd80:     	add	x0, x24, #0x3b8
1015ccd84:     	bl	0x102363ab8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1015ccd88:     	ldr	x8, [sp, #0x58]
1015ccd8c:     	ldr	x8, [x8, #0x20]
1015ccd90:     	cmp	x8, #0x1
1015ccd94:     	b.ne	0x1015cd120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc0>
1015ccd98:     	ldr	x8, [sp, #0x58]
1015ccd9c:     	ldr	w8, [x8, #0x40]
1015ccda0:     	tbz	w8, #0x0, 0x1015cd250 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30f0>
1015ccda4:     	ldr	x8, [sp, #0x58]
1015ccda8:     	ldr	x1, [x8, #0x28]
1015ccdac:     	ldr	x2, [x8, #0x48]
1015ccdb0:     	add	x8, sp, #0x668
1015ccdb4:     	add	x0, sp, #0x550
1015ccdb8:     	bl	0x102d54df0 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget11with_limits>
1015ccdbc:     	ldr	x8, [sp, #0x550]
1015ccdc0:     	mov	x9, #-0x1               ; =-1
1015ccdc4:     	ldaddl	x9, x8, [x8]
1015ccdc8:     	cmp	x8, #0x1
1015ccdcc:     	b.ne	0x1015ccddc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c7c>
1015ccdd0:     	dmb	ishld
1015ccdd4:     	add	x0, sp, #0x550
1015ccdd8:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ccddc:     	ldr	x8, [sp, #0x660]
1015ccde0:     	ldr	x9, [x8, #0x6c0]
1015ccde4:     	cmp	x9, #0x100, lsl #12     ; =0x100000
1015ccde8:     	b.ls	0x1015cd2b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3154>
1015ccdec:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015ccdf0:     	ldr	q0, [x8, #0xdc0]
1015ccdf4:     	stur	q0, [x23, #0x8]
1015ccdf8:     	mov	w8, #0x6                ; =6
1015ccdfc:     	str	w8, [x23]
1015cce00:     	b	0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015cce04:     	adrp	x0, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cce08:     	add	x0, x0, #0x8b8
1015cce0c:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015cce10:     	add	x0, sp, #0x550
1015cce14:     	ldr	x1, [sp, #0x58]
1015cce18:     	mov	x2, x20
1015cce1c:     	bl	0x1015c8104 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
1015cce20:     	ldr	w8, [sp, #0x550]
1015cce24:     	tbz	w8, #0x0, 0x1015cd138 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fd8>
1015cce28:     	ldr	w21, [sp, #0x554]
1015cce2c:     	ldr	w22, [sp, #0x558]
1015cce30:     	add	x0, sp, #0x550
1015cce34:     	ldr	x1, [sp, #0x58]
1015cce38:     	mov	x2, x20
1015cce3c:     	mov	w3, #0x1                ; =1
1015cce40:     	mov	w4, #0x8                ; =8
1015cce44:     	mov	x5, #0x0                ; =0
1015cce48:     	bl	0x1015b4ec4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015cce4c:     	ldr	w8, [sp, #0x550]
1015cce50:     	cmp	w8, #0x6
1015cce54:     	b.ne	0x1015cd204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30a4>
1015cce58:     	ldr	x8, [sp, #0x558]
1015cce5c:     	cmp	x8, #0x2
1015cce60:     	b.ne	0x1015cceb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d58>
1015cce64:     	add	x0, sp, #0x550
1015cce68:     	ldr	x1, [sp, #0x58]
1015cce6c:     	mov	x2, x21
1015cce70:     	mov	x3, x22
1015cce74:     	bl	0x1015d75a8 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation15move_joined_map>
1015cce78:     	ldr	w9, [sp, #0x550]
1015cce7c:     	ldrb	w8, [sp, #0x554]
1015cce80:     	cmp	w9, #0x6
1015cce84:     	b.ne	0x1015cd3e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3288>
1015cce88:     	tbnz	w8, #0x0, 0x1015ccf30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dd0>
1015cce8c:     	ldr	x8, [sp, #0x58]
1015cce90:     	ldr	x8, [x8, #0x490]
1015cce94:     	add	x0, sp, #0x550
1015cce98:     	add	x1, x8, #0xf0
1015cce9c:     	add	x4, x8, #0x2f8
1015ccea0:     	mov	x2, x21
1015ccea4:     	mov	x3, x22
1015ccea8:     	bl	0x1015d1624 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena15copy_current_to>
1015cceac:     	ldrb	w8, [sp, #0x550]
1015cceb0:     	cmp	w8, #0x14
1015cceb4:     	b.ne	0x1015cd64c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34ec>
1015cceb8:     	ldr	x1, [x23, #0x380]
1015ccebc:     	cmp	x20, x1
1015ccec0:     	b.hs	0x1015ce040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ee0>
1015ccec4:     	ldr	x8, [x23, #0x378]
1015ccec8:     	mov	w9, #0x170              ; =368
1015ccecc:     	madd	x8, x20, x9, x8
1015cced0:     	ldp	x10, x9, [x8]
1015cced4:     	mov	w11, #0x11              ; =17
1015cced8:     	eor	x10, x10, x11
1015ccedc:     	orr	x9, x10, x9
1015ccee0:     	cbnz	x9, 0x1015ccf30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dd0>
1015ccee4:     	ldr	x1, [x23, #0x390]
1015ccee8:     	ldr	w2, [x8, #0x10]
1015cceec:     	cmp	x1, x2
1015ccef0:     	b.ls	0x1015ce07c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f1c>
1015ccef4:     	ldr	x8, [x23, #0x388]
1015ccef8:     	mov	w9, #0x180              ; =384
1015ccefc:     	umaddl	x8, w2, w9, x8
1015ccf00:     	ldp	x8, x9, [x8]
1015ccf04:     	mov	w10, #0x5               ; =5
1015ccf08:     	eor	x8, x8, x10
1015ccf0c:     	orr	x8, x8, x9
1015ccf10:     	cbnz	x8, 0x1015ccf30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dd0>
1015ccf14:     	add	x0, sp, #0x550
1015ccf18:     	ldr	x1, [sp, #0x58]
1015ccf1c:     	mov	w3, #0x1                ; =1
1015ccf20:     	bl	0x1015c873c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
1015ccf24:     	ldr	w8, [sp, #0x550]
1015ccf28:     	cmp	w8, #0x6
1015ccf2c:     	b.ne	0x1015cd628 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34c8>
1015ccf30:     	ldr	x8, [sp, #0x58]
1015ccf34:     	ldr	x8, [x8, #0x490]
1015ccf38:     	mov	w9, #0x1                ; =1
1015ccf3c:     	strb	w9, [x8, #0x460]
1015ccf40:     	b	0x1015cb5ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x148c>
1015ccf44:     	ldr	x1, [x23, #0x380]
1015ccf48:     	cmp	x20, x1
1015ccf4c:     	b.hs	0x1015cdf2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3dcc>
1015ccf50:     	ldr	x8, [x23, #0x378]
1015ccf54:     	mov	w9, #0x170              ; =368
1015ccf58:     	madd	x25, x20, x9, x8
1015ccf5c:     	ldp	x9, x8, [x25]
1015ccf60:     	cmp	x9, #0x2
1015ccf64:     	sbcs	xzr, x8, xzr
1015ccf68:     	b.hs	0x1015cd154 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ff4>
1015ccf6c:     	ldr	x9, [x24]
1015ccf70:     	ldr	x8, [sp, #0x58]
1015ccf74:     	ldr	x21, [x8, #0x4d0]
1015ccf78:     	cmp	x9, x21
1015ccf7c:     	b.ne	0x1015cd238 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30d8>
1015ccf80:     	ldr	x22, [x24, #0x8]
1015ccf84:     	ldr	x8, [x25, #0x128]
1015ccf88:     	cmp	x22, x8
1015ccf8c:     	b.ne	0x1015cd238 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30d8>
1015ccf90:     	ldr	x9, [x24, #0x10]
1015ccf94:     	cbnz	x9, 0x1015cd238 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30d8>
1015ccf98:     	ldr	x9, [sp, #0x58]
1015ccf9c:     	ldr	x9, [x9, #0x4d8]
1015ccfa0:     	cmp	x8, x9
1015ccfa4:     	b.hi	0x1015cd238 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30d8>
1015ccfa8:     	ldr	x23, [x25, #0x120]
1015ccfac:     	add	x0, sp, #0x550
1015ccfb0:     	ldr	x1, [sp, #0x58]
1015ccfb4:     	mov	x2, x20
1015ccfb8:     	mov	x3, x21
1015ccfbc:     	mov	x4, x22
1015ccfc0:     	bl	0x1015b63e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14selected_callsNtB4_10Invocation21prepared_library_call>
1015ccfc4:     	ldr	w8, [sp, #0x550]
1015ccfc8:     	cmp	w8, #0x6
1015ccfcc:     	b.ne	0x1015cd204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30a4>
1015ccfd0:     	ldr	x8, [sp, #0x558]
1015ccfd4:     	cmp	x8, #0x2
1015ccfd8:     	b.ne	0x1015cd33c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31dc>
1015ccfdc:     	add	x0, sp, #0x550
1015ccfe0:     	ldr	x1, [sp, #0x58]
1015ccfe4:     	mov	x2, x20
1015ccfe8:     	mov	x3, x21
1015ccfec:     	mov	x4, x22
1015ccff0:     	bl	0x1015c14b8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5lines10line_callsNtNtB6_10invocation10Invocation16line_matrix_call>
1015ccff4:     	ldr	w8, [sp, #0x550]
1015ccff8:     	cmp	w8, #0x6
1015ccffc:     	b.ne	0x1015cd204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30a4>
1015cd000:     	ldr	x8, [sp, #0x558]
1015cd004:     	cmp	x8, #0x2
1015cd008:     	b.ne	0x1015cd33c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31dc>
1015cd00c:     	add	x0, sp, #0x550
1015cd010:     	ldr	x1, [sp, #0x58]
1015cd014:     	mov	x2, x20
1015cd018:     	mov	x3, x21
1015cd01c:     	mov	x4, x22
1015cd020:     	bl	0x1015c589c <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime7session7capture14captured_callsNtNtB8_10invocation10Invocation26captured_line_element_call>
1015cd024:     	ldr	w9, [sp, #0x550]
1015cd028:     	ldrb	w8, [sp, #0x554]
1015cd02c:     	cmp	w9, #0x6
1015cd030:     	b.ne	0x1015cd3e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3288>
1015cd034:     	tbnz	w8, #0x0, 0x1015ccf30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2dd0>
1015cd038:     	add	x0, sp, #0x550
1015cd03c:     	ldr	x1, [sp, #0x58]
1015cd040:     	mov	x2, x20
1015cd044:     	mov	x3, x21
1015cd048:     	mov	x4, x22
1015cd04c:     	bl	0x1015d4e7c <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation18selected_join_call>
1015cd050:     	ldr	w9, [sp, #0x550]
1015cd054:     	ldrb	w8, [sp, #0x554]
1015cd058:     	cmp	w9, #0x6
1015cd05c:     	b.ne	0x1015cd3e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3288>
1015cd060:     	tbz	w8, #0x0, 0x1015cd800 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36a0>
1015cd064:     	ldr	x8, [sp, #0x58]
1015cd068:     	ldr	x9, [x8, #0x490]
1015cd06c:     	mov	w10, #0x1               ; =1
1015cd070:     	strb	w10, [x9, #0x460]
1015cd074:     	ldr	x8, [x8, #0x290]
1015cd078:     	cmp	x8, #0x4
1015cd07c:     	cset	w8, eq
1015cd080:     	stp	x8, x10, [x19, #0x8]
1015cd084:     	b	0x1015cb5f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1490>
1015cd088:     	str	wzr, [x19]
1015cd08c:     	mov	w8, #0xc                ; =12
1015cd090:     	strb	w8, [x19, #0x8]
1015cd094:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0xb98>
1015cd098:     	add	x8, x8, #0xf92
1015cd09c:     	mov	w9, #0x1b               ; =27
1015cd0a0:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cd0a4:     	adrp	x0, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd0a8:     	add	x0, x0, #0x870
1015cd0ac:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015cd0b0:     	str	wzr, [x19]
1015cd0b4:     	mov	w9, #0xc                ; =12
1015cd0b8:     	strb	w9, [x19, #0x8]
1015cd0bc:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cd0c0:     	add	x8, x8, #0xc56
1015cd0c4:     	mov	w9, #0x29               ; =41
1015cd0c8:     	b	0x1015cc998 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2838>
1015cd0cc:     	str	wzr, [x28]
1015cd0d0:     	adrp	x8, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cd0d4:     	add	x8, x8, #0x919
1015cd0d8:     	mov	w9, #0xc                ; =12
1015cd0dc:     	stp	x9, x8, [x28, #0x8]
1015cd0e0:     	mov	w8, #0x28               ; =40
1015cd0e4:     	str	x8, [x28, #0x18]
1015cd0e8:     	sub	x0, x29, #0x90
1015cd0ec:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015cd0f0:     	ldur	x8, [x29, #-0xb0]
1015cd0f4:     	mov	x9, #-0x1               ; =-1
1015cd0f8:     	ldaddl	x9, x8, [x8]
1015cd0fc:     	cmp	x8, #0x1
1015cd100:     	b.ne	0x1015cd110 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fb0>
1015cd104:     	dmb	ishld
1015cd108:     	sub	x0, x29, #0xb0
1015cd10c:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015cd110:     	tbz	w19, #0x0, 0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd114:     	add	x0, sp, #0x220
1015cd118:     	bl	0x1015ae760 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
1015cd11c:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd120:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cd124:     	add	x8, x8, #0x74a
1015cd128:     	b	0x1015cd258 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30f8>
1015cd12c:     	adrp	x0, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd130:     	add	x0, x0, #0x8e8
1015cd134:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015cd138:     	str	wzr, [x19]
1015cd13c:     	mov	w8, #0xc                ; =12
1015cd140:     	str	w8, [x19, #0x8]
1015cd144:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cd148:     	add	x8, x8, #0x715
1015cd14c:     	mov	w9, #0x21               ; =33
1015cd150:     	b	0x1015cb12c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfcc>
1015cd154:     	str	wzr, [x19]
1015cd158:     	mov	w8, #0xc                ; =12
1015cd15c:     	strb	w8, [x19, #0x8]
1015cd160:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0xb98>
1015cd164:     	add	x8, x8, #0xfe7
1015cd168:     	b	0x1015cbe74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d14>
1015cd16c:     	adrp	x0, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd170:     	add	x0, x0, #0x888
1015cd174:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015cd178:     	adrp	x0, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd17c:     	add	x0, x0, #0x8a0
1015cd180:     	bl	0x103a05ca4 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015cd184:     	add	x20, x20, #0x3c0
1015cd188:     	mov	x0, x20
1015cd18c:     	bl	0x1015abcb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
1015cd190:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1015cd194:     	str	x8, [x20]
1015cd198:     	mov	w8, #0x1                ; =1
1015cd19c:     	dup.2d	v0, x8
1015cd1a0:     	b	0x1015ca918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b8>
1015cd1a4:     	add	x0, sp, #0x550
1015cd1a8:     	ldr	x1, [sp, #0x58]
1015cd1ac:     	mov	x2, x20
1015cd1b0:     	mov	w3, #0x12               ; =18
1015cd1b4:     	mov	w4, #0x8                ; =8
1015cd1b8:     	mov	x5, #0x0                ; =0
1015cd1bc:     	bl	0x1015b4ec4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015cd1c0:     	ldr	w8, [sp, #0x550]
1015cd1c4:     	cmp	w8, #0x6
1015cd1c8:     	b.ne	0x1015cd204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30a4>
1015cd1cc:     	ldr	x8, [sp, #0x558]
1015cd1d0:     	cmp	x8, #0x2
1015cd1d4:     	b.ne	0x1015cd33c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31dc>
1015cd1d8:     	mov	x0, x19
1015cd1dc:     	ldr	x1, [sp, #0x58]
1015cd1e0:     	mov	x2, x20
1015cd1e4:     	add	sp, sp, #0x810
1015cd1e8:     	ldp	x29, x30, [sp, #0x50]
1015cd1ec:     	ldp	x20, x19, [sp, #0x40]
1015cd1f0:     	ldp	x22, x21, [sp, #0x30]
1015cd1f4:     	ldp	x24, x23, [sp, #0x20]
1015cd1f8:     	ldp	x26, x25, [sp, #0x10]
1015cd1fc:     	ldp	x28, x27, [sp], #0x60
1015cd200:     	b	0x1015b96bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation>
1015cd204:     	ldr	w9, [sp, #0x554]
1015cd208:     	ldur	q0, [x27, #0x18]
1015cd20c:     	stur	q0, [x19, #0x18]
1015cd210:     	ldur	q0, [x27, #0x28]
1015cd214:     	stur	q0, [x19, #0x28]
1015cd218:     	ldur	q0, [x27, #0x38]
1015cd21c:     	stur	q0, [x19, #0x38]
1015cd220:     	ldr	x10, [sp, #0x598]
1015cd224:     	str	x10, [x19, #0x48]
1015cd228:     	ldur	q0, [x27, #0x8]
1015cd22c:     	stp	w8, w9, [x19]
1015cd230:     	stur	q0, [x19, #0x8]
1015cd234:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd238:     	str	wzr, [x19]
1015cd23c:     	mov	w8, #0xc                ; =12
1015cd240:     	strb	w8, [x19, #0x8]
1015cd244:     	adrp	x8, 0x107558000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0xb98>
1015cd248:     	add	x8, x8, #0xfc3
1015cd24c:     	b	0x1015cbe74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d14>
1015cd250:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cd254:     	add	x8, x8, #0x768
1015cd258:     	str	wzr, [x23]
1015cd25c:     	mov	w9, #0xc                ; =12
1015cd260:     	stp	x9, x8, [x23, #0x8]
1015cd264:     	mov	w8, #0x1e               ; =30
1015cd268:     	str	x8, [x23, #0x18]
1015cd26c:     	ldr	x8, [sp, #0x550]
1015cd270:     	mov	x9, #-0x1               ; =-1
1015cd274:     	ldaddl	x9, x8, [x8]
1015cd278:     	cmp	x8, #0x1
1015cd27c:     	b.ne	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd280:     	dmb	ishld
1015cd284:     	add	x0, sp, #0x550
1015cd288:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015cd28c:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd290:     	str	wzr, [x28]
1015cd294:     	mov	w8, #0xc                ; =12
1015cd298:     	strb	w8, [x28, #0x8]
1015cd29c:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cd2a0:     	add	x8, x8, #0xc56
1015cd2a4:     	mov	w9, #0x29               ; =41
1015cd2a8:     	stp	x8, x9, [x28, #0x10]
1015cd2ac:     	mov	w19, #0x1               ; =1
1015cd2b0:     	b	0x1015cd0e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f88>
1015cd2b4:     	str	xzr, [sp, #0x38]
1015cd2b8:     	add	x24, sp, #0x720
1015cd2bc:     	ldp	x15, x9, [sp, #0x48]
1015cd2c0:     	lsl	x11, x9, #2
1015cd2c4:     	add	x9, x15, x11
1015cd2c8:     	str	x9, [sp, #0x28]
1015cd2cc:     	ldr	x12, [x8, #0x5a0]
1015cd2d0:     	ldr	x13, [x8, #0x598]
1015cd2d4:     	mov	w8, #0xc                ; =12
1015cd2d8:     	mov	w9, #0x29               ; =41
1015cd2dc:     	mov	w14, #0x58              ; =88
1015cd2e0:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cd2e4:     	add	x10, x10, #0x786
1015cd2e8:     	ldr	x16, [sp, #0x38]
1015cd2ec:     	cbz	x11, 0x1015cd378 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3218>
1015cd2f0:     	ldr	w17, [x15], #0x4
1015cd2f4:     	cmp	x12, x17
1015cd2f8:     	b.ls	0x1015cd32c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x31cc>
1015cd2fc:     	umaddl	x17, w17, w14, x13
1015cd300:     	ldr	x17, [x17, #0x8]
1015cd304:     	sub	x11, x11, #0x4
1015cd308:     	ldr	x0, [sp, #0x38]
1015cd30c:     	adds	x0, x17, x0
1015cd310:     	str	x0, [sp, #0x38]
1015cd314:     	b.lo	0x1015cd2e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3188>
1015cd318:     	and	x8, x16, #0xffffffffffffff00
1015cd31c:     	orr	x8, x8, #0xc
1015cd320:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cd324:     	add	x10, x10, #0x7af
1015cd328:     	mov	w9, #0x1f               ; =31
1015cd32c:     	str	wzr, [x23]
1015cd330:     	stp	x8, x10, [x23, #0x8]
1015cd334:     	str	x9, [x23, #0x18]
1015cd338:     	b	0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015cd33c:     	ldur	q0, [x27, #0x8]
1015cd340:     	ldr	x8, [sp, #0x58]
1015cd344:     	ldr	x8, [x8, #0x490]
1015cd348:     	mov	w9, #0x1                ; =1
1015cd34c:     	strb	w9, [x8, #0x460]
1015cd350:     	b	0x1015ca918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b8>
1015cd354:     	mov	w19, #0x0               ; =0
1015cd358:     	str	wzr, [x28]
1015cd35c:     	mov	w8, #0xc                ; =12
1015cd360:     	strb	w8, [x28, #0x8]
1015cd364:     	adrp	x8, 0x107557000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.326+0x1>
1015cd368:     	add	x8, x8, #0xc56
1015cd36c:     	mov	w9, #0x29               ; =41
1015cd370:     	stp	x8, x9, [x28, #0x10]
1015cd374:     	b	0x1015cd0e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f88>
1015cd378:     	mov	w8, #0x48               ; =72
1015cd37c:     	mov	x9, #0x48               ; =72
1015cd380:     	madd	x8, x20, x8, x9
1015cd384:     	ldr	x9, [sp, #0x38]
1015cd388:     	umulh	x9, x9, x8
1015cd38c:     	cmp	xzr, x9
1015cd390:     	b.ne	0x1015cdba4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a44>
1015cd394:     	ldr	x9, [sp, #0x38]
1015cd398:     	mul	x8, x9, x8
1015cd39c:     	mov	w9, #0x580              ; =1408
1015cd3a0:     	mov	x10, #0x400             ; =1024
1015cd3a4:     	madd	x9, x20, x9, x10
1015cd3a8:     	adds	x8, x8, x9
1015cd3ac:     	str	x8, [sp, #0x30]
1015cd3b0:     	b.hs	0x1015cdbb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a58>
1015cd3b4:     	mov	x8, #-0x201             ; =-513
1015cd3b8:     	movk	x8, #0x1fff, lsl #48
1015cd3bc:     	ldr	x9, [sp, #0x30]
1015cd3c0:     	cmp	x9, x8
1015cd3c4:     	b.ls	0x1015cd44c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x32ec>
1015cd3c8:     	str	wzr, [x23]
1015cd3cc:     	mov	w8, #0xc                ; =12
1015cd3d0:     	adrp	x9, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cd3d4:     	add	x9, x9, #0x7e8
1015cd3d8:     	stp	x8, x9, [x23, #0x8]
1015cd3dc:     	mov	w8, #0x17               ; =23
1015cd3e0:     	str	x8, [x23, #0x18]
1015cd3e4:     	b	0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015cd3e8:     	ldur	q0, [x27, #0x15]
1015cd3ec:     	stur	q0, [x19, #0x15]
1015cd3f0:     	ldur	q0, [x27, #0x25]
1015cd3f4:     	stur	q0, [x19, #0x25]
1015cd3f8:     	ldur	q0, [x27, #0x35]
1015cd3fc:     	stur	q0, [x19, #0x35]
1015cd400:     	ldr	q0, [sp, #0x590]
1015cd404:     	str	q0, [x19, #0x40]
1015cd408:     	ldur	q0, [x27, #0x5]
1015cd40c:     	stur	q0, [x19, #0x5]
1015cd410:     	str	w9, [x19]
1015cd414:     	strb	w8, [x19, #0x4]
1015cd418:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd41c:     	adrp	x3, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015cd420:     	add	x3, x3, #0x938
1015cd424:     	mov	x0, #0x0                ; =0
1015cd428:     	bl	0x103a05ef4 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
1015cd42c:     	b	0x1015ce3dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x427c>
1015cd430:     	str	wzr, [x28]
1015cd434:     	mov	w8, #0xc                ; =12
1015cd438:     	strb	w8, [x28, #0x8]
1015cd43c:     	adrp	x8, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cd440:     	add	x8, x8, #0x8ed
1015cd444:     	mov	w9, #0x2c               ; =44
1015cd448:     	b	0x1015cd370 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3210>
1015cd44c:     	ldr	x8, [sp, #0x58]
1015cd450:     	ldr	x9, [x8, #0x490]
1015cd454:     	ldr	x8, [sp, #0x30]
1015cd458:     	lsl	x8, x8, #3
1015cd45c:     	add	x0, sp, #0x550
1015cd460:     	str	x9, [sp, #0x20]
1015cd464:     	add	x1, x9, #0x2f8
1015cd468:     	add	x2, x8, #0x1, lsl #12   ; =0x1000
1015cd46c:     	bl	0x1015b2708 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015cd470:     	ldrb	w8, [sp, #0x550]
1015cd474:     	cmp	w8, #0xe
1015cd478:     	b.ne	0x1015cd5d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3470>
1015cd47c:     	add	x8, sp, #0x550
1015cd480:     	add	x0, sp, #0x668
1015cd484:     	ldr	x1, [sp, #0x30]
1015cd488:     	bl	0x102d54f5c <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1015cd48c:     	ldr	w8, [sp, #0x550]
1015cd490:     	cmp	w8, #0x1a
1015cd494:     	b.ne	0x1015cd6f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3594>
1015cd498:     	ldur	q0, [x27, #0x8]
1015cd49c:     	ldur	q1, [x27, #0x18]
1015cd4a0:     	str	q0, [sp, #0x680]
1015cd4a4:     	str	q1, [sp, #0x690]
1015cd4a8:     	add	x8, sp, #0x550
1015cd4ac:     	mov	x0, x20
1015cd4b0:     	ldr	x1, [sp, #0x50]
1015cd4b4:     	ldr	x2, [sp, #0x38]
1015cd4b8:     	bl	0x1015e3dd8 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel15scheduler_nodes>
1015cd4bc:     	ldr	w8, [sp, #0x550]
1015cd4c0:     	cmp	w8, #0x6
1015cd4c4:     	b.ne	0x1015cd730 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35d0>
1015cd4c8:     	ldr	x1, [sp, #0x558]
1015cd4cc:     	add	x8, sp, #0x440
1015cd4d0:     	add	x0, sp, #0x668
1015cd4d4:     	bl	0x102d54e30 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
1015cd4d8:     	ldr	w8, [sp, #0x440]
1015cd4dc:     	cmp	w8, #0x1a
1015cd4e0:     	b.ne	0x1015cd788 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3628>
1015cd4e4:     	add	x8, sp, #0x440
1015cd4e8:     	ldur	q0, [x8, #0x8]
1015cd4ec:     	ldur	q1, [x8, #0x18]
1015cd4f0:     	str	q0, [sp, #0x6a0]
1015cd4f4:     	str	q1, [sp, #0x6b0]
1015cd4f8:     	ldr	x8, [sp, #0x50]
1015cd4fc:     	cbnz	x8, 0x1015cd860 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3700>
1015cd500:     	mov	w8, #0x8                ; =8
1015cd504:     	str	xzr, [sp, #0x6c0]
1015cd508:     	str	x8, [sp, #0x6c8]
1015cd50c:     	str	xzr, [sp, #0x6d0]
1015cd510:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cd514:     	ldr	q0, [x8, #0xdc0]
1015cd518:     	stur	q0, [x23, #0x8]
1015cd51c:     	mov	w8, #0x6                ; =6
1015cd520:     	str	w8, [x23]
1015cd524:     	add	x0, sp, #0x6c0
1015cd528:     	bl	0x1015ac9b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
1015cd52c:     	add	x0, sp, #0x6a0
1015cd530:     	bl	0x1015ada9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015cd534:     	b	0x1015cd7a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3644>
1015cd538:     	mov	w19, #0x0               ; =0
1015cd53c:     	ldur	q0, [x24, #0x8]
1015cd540:     	ldur	q1, [x24, #0x18]
1015cd544:     	ldur	q2, [x24, #0x28]
1015cd548:     	ldur	q3, [x24, #0x38]
1015cd54c:     	ldur	x8, [x24, #0x48]
1015cd550:     	stur	x8, [x27, #0x44]
1015cd554:     	stur	q0, [x27, #0x4]
1015cd558:     	stur	q1, [x27, #0x14]
1015cd55c:     	stur	q2, [x27, #0x24]
1015cd560:     	stur	q3, [x27, #0x34]
1015cd564:     	ldr	q0, [sp, #0x570]
1015cd568:     	ldr	q1, [sp, #0x580]
1015cd56c:     	str	q0, [sp, #0x410]
1015cd570:     	str	q1, [sp, #0x420]
1015cd574:     	ldur	q0, [x27, #0x3c]
1015cd578:     	stur	q0, [x26, #0xfc]
1015cd57c:     	ldr	q0, [sp, #0x560]
1015cd580:     	ldr	q1, [sp, #0x550]
1015cd584:     	stp	q1, q0, [sp, #0x3f0]
1015cd588:     	ldp	q0, q1, [sp, #0x3f0]
1015cd58c:     	ldur	q2, [x26, #0xfc]
1015cd590:     	stur	q2, [x26, #0xac]
1015cd594:     	ldr	q2, [sp, #0x410]
1015cd598:     	ldr	q3, [sp, #0x420]
1015cd59c:     	stp	q2, q3, [sp, #0x3c0]
1015cd5a0:     	stp	q0, q1, [sp, #0x3a0]
1015cd5a4:     	ldp	q1, q0, [sp, #0x3a0]
1015cd5a8:     	stur	q0, [x28, #0x14]
1015cd5ac:     	ldp	q0, q2, [sp, #0x3c0]
1015cd5b0:     	stur	q0, [x28, #0x24]
1015cd5b4:     	stur	q2, [x28, #0x34]
1015cd5b8:     	ldur	q0, [x26, #0xac]
1015cd5bc:     	str	q0, [x28, #0x40]
1015cd5c0:     	stur	q1, [x28, #0x4]
1015cd5c4:     	mov	w8, #0x5                ; =5
1015cd5c8:     	str	w8, [x28]
1015cd5cc:     	b	0x1015cd0e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f88>
1015cd5d0:     	ldr	q0, [sp, #0x550]
1015cd5d4:     	ldr	q1, [sp, #0x560]
1015cd5d8:     	str	q0, [sp, #0x440]
1015cd5dc:     	str	q1, [sp, #0x450]
1015cd5e0:     	ldr	q2, [sp, #0x570]
1015cd5e4:     	str	q2, [sp, #0x460]
1015cd5e8:     	ldr	x8, [sp, #0x580]
1015cd5ec:     	str	x8, [sp, #0x470]
1015cd5f0:     	stur	q0, [x27, #0x4]
1015cd5f4:     	stur	q1, [x27, #0x14]
1015cd5f8:     	stur	q2, [x27, #0x24]
1015cd5fc:     	stur	x8, [x27, #0x34]
1015cd600:     	str	wzr, [x23]
1015cd604:     	ldr	q0, [sp, #0x550]
1015cd608:     	ldr	q1, [sp, #0x560]
1015cd60c:     	stur	q0, [x23, #0x4]
1015cd610:     	stur	q1, [x23, #0x14]
1015cd614:     	ldr	q0, [sp, #0x570]
1015cd618:     	stur	q0, [x23, #0x24]
1015cd61c:     	ldur	q0, [x27, #0x2c]
1015cd620:     	str	q0, [x23, #0x30]
1015cd624:     	b	0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015cd628:     	ldr	q0, [sp, #0x570]
1015cd62c:     	ldr	q1, [sp, #0x580]
1015cd630:     	stp	q0, q1, [x19, #0x20]
1015cd634:     	ldr	q0, [sp, #0x590]
1015cd638:     	str	q0, [x19, #0x40]
1015cd63c:     	ldr	q0, [sp, #0x560]
1015cd640:     	ldr	q1, [sp, #0x550]
1015cd644:     	stp	q1, q0, [x19]
1015cd648:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd64c:     	ldur	w9, [x27, #0x1]
1015cd650:     	stur	w9, [x19, #0x9]
1015cd654:     	ldr	w9, [sp, #0x554]
1015cd658:     	str	w9, [x19, #0xc]
1015cd65c:     	ldr	q0, [sp, #0x570]
1015cd660:     	stur	q0, [x19, #0x28]
1015cd664:     	ldr	x9, [sp, #0x580]
1015cd668:     	str	x9, [x19, #0x38]
1015cd66c:     	ldr	d0, [sp, #0x568]
1015cd670:     	ldur	q1, [x27, #0x8]
1015cd674:     	mov	w9, #0x2                ; =2
1015cd678:     	str	w9, [x19]
1015cd67c:     	strb	w8, [x19, #0x8]
1015cd680:     	str	q1, [x19, #0x10]
1015cd684:     	str	d0, [x19, #0x20]
1015cd688:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd68c:     	mov	w19, #0x0               ; =0
1015cd690:     	ldr	q0, [sp, #0x570]
1015cd694:     	ldr	q1, [sp, #0x580]
1015cd698:     	stp	q0, q1, [x28, #0x20]
1015cd69c:     	ldr	q0, [sp, #0x590]
1015cd6a0:     	str	q0, [x28, #0x40]
1015cd6a4:     	ldr	q0, [sp, #0x560]
1015cd6a8:     	ldr	q1, [sp, #0x550]
1015cd6ac:     	stp	q1, q0, [x28]
1015cd6b0:     	b	0x1015cd0e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f88>
1015cd6b4:     	str	wzr, [x28]
1015cd6b8:     	mov	w8, #0xc                ; =12
1015cd6bc:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cd6c0:     	add	x9, x9, #0x89d
1015cd6c4:     	stp	x8, x9, [x28, #0x8]
1015cd6c8:     	mov	w8, #0x2a               ; =42
1015cd6cc:     	str	x8, [x28, #0x18]
1015cd6d0:     	b	0x1015cc9ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x288c>
1015cd6d4:     	str	wzr, [x28]
1015cd6d8:     	mov	w8, #0xc                ; =12
1015cd6dc:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cd6e0:     	add	x9, x9, #0x8c7
1015cd6e4:     	stp	x8, x9, [x28, #0x8]
1015cd6e8:     	mov	w8, #0x26               ; =38
1015cd6ec:     	str	x8, [x28, #0x18]
1015cd6f0:     	b	0x1015cc9ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x288c>
1015cd6f4:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cd6f8:     	ldr	q0, [x8, #0xdc0]
1015cd6fc:     	stur	q0, [x23, #0x8]
1015cd700:     	mov	w8, #0x6                ; =6
1015cd704:     	str	w8, [x23]
1015cd708:     	add	x0, sp, #0x550
1015cd70c:     	bl	0x1015ac240 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
1015cd710:     	b	0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015cd714:     	str	wzr, [x19]
1015cd718:     	mov	w9, #0xc                ; =12
1015cd71c:     	str	x9, [x19, #0x8]
1015cd720:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cd724:     	add	x8, x8, #0x399
1015cd728:     	mov	w9, #0x1e               ; =30
1015cd72c:     	b	0x1015cc998 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2838>
1015cd730:     	ldr	w9, [sp, #0x554]
1015cd734:     	ldr	x10, [sp, #0x558]
1015cd738:     	ldr	q0, [sp, #0x560]
1015cd73c:     	ldr	q1, [sp, #0x570]
1015cd740:     	stp	q0, q1, [x23, #0x10]
1015cd744:     	ldr	q0, [sp, #0x580]
1015cd748:     	ldr	q1, [sp, #0x590]
1015cd74c:     	stp	q0, q1, [x23, #0x30]
1015cd750:     	stp	w8, w9, [x23]
1015cd754:     	str	x10, [x23, #0x8]
1015cd758:     	b	0x1015cd7a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3644>
1015cd75c:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015cd760:     	add	x2, x2, #0x920
1015cd764:     	mov	x0, x8
1015cd768:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd76c:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd770:     	add	x2, x2, #0x8d0
1015cd774:     	mov	x0, x19
1015cd778:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd77c:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd780:     	add	x2, x2, #0x540
1015cd784:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd788:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cd78c:     	ldr	q0, [x8, #0xdc0]
1015cd790:     	stur	q0, [x23, #0x8]
1015cd794:     	mov	w8, #0x6                ; =6
1015cd798:     	str	w8, [x23]
1015cd79c:     	add	x0, sp, #0x440
1015cd7a0:     	bl	0x1015ac168 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
1015cd7a4:     	add	x0, sp, #0x680
1015cd7a8:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015cd7ac:     	ldr	x8, [sp, #0x668]
1015cd7b0:     	mov	x9, #-0x1               ; =-1
1015cd7b4:     	ldaddl	x9, x8, [x8]
1015cd7b8:     	cmp	x8, #0x1
1015cd7bc:     	b.ne	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd7c0:     	dmb	ishld
1015cd7c4:     	add	x0, sp, #0x668
1015cd7c8:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015cd7cc:     	b	0x1015ca434 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015cd7d0:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd7d4:     	add	x2, x2, #0x5e8
1015cd7d8:     	mov	x0, x19
1015cd7dc:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd7e0:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015cd7e4:     	add	x2, x2, #0x740
1015cd7e8:     	ldr	x0, [sp, #0x50]
1015cd7ec:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd7f0:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015cd7f4:     	add	x2, x2, #0x758
1015cd7f8:     	ldr	x0, [sp, #0x50]
1015cd7fc:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd800:     	ldr	w5, [x25, #0x130]
1015cd804:     	mov	x0, x19
1015cd808:     	ldr	x1, [sp, #0x58]
1015cd80c:     	mov	x2, x20
1015cd810:     	mov	x3, x23
1015cd814:     	mov	x4, x22
1015cd818:     	mov	x6, x21
1015cd81c:     	mov	x7, x22
1015cd820:     	add	sp, sp, #0x810
1015cd824:     	ldp	x29, x30, [sp, #0x50]
1015cd828:     	ldp	x20, x19, [sp, #0x40]
1015cd82c:     	ldp	x22, x21, [sp, #0x30]
1015cd830:     	ldp	x24, x23, [sp, #0x20]
1015cd834:     	ldp	x26, x25, [sp, #0x10]
1015cd838:     	ldp	x28, x27, [sp], #0x60
1015cd83c:     	b	0x1015b8fa4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call>
1015cd840:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd844:     	add	x2, x2, #0x600
1015cd848:     	mov	x0, x1
1015cd84c:     	mov	x1, x8
1015cd850:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd854:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cd858:     	add	x2, x2, #0x5b8
1015cd85c:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd860:     	add	x0, sp, #0x550
1015cd864:     	mov	x1, #0x0                ; =0
1015cd868:     	mov	w2, #0x8                ; =8
1015cd86c:     	ldr	x3, [sp, #0x50]
1015cd870:     	mov	w4, #0x8                ; =8
1015cd874:     	mov	w5, #0x68               ; =104
1015cd878:     	bl	0x1039e1800 <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
1015cd87c:     	ldr	w8, [sp, #0x550]
1015cd880:     	tbz	w8, #0x0, 0x1015cd8b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3754>
1015cd884:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cd888:     	add	x8, x8, #0x1c2
1015cd88c:     	mov	w9, #0xc                ; =12
1015cd890:     	stp	x9, x8, [x23, #0x8]
1015cd894:     	mov	w8, #0x1a               ; =26
1015cd898:     	str	x8, [x23, #0x18]
1015cd89c:     	str	wzr, [x23]
1015cd8a0:     	b	0x1015cd52c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33cc>
1015cd8a4:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015cd8a8:     	add	x2, x2, #0x770
1015cd8ac:     	ldr	x1, [sp, #0x28]
1015cd8b0:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cd8b4:     	str	xzr, [sp]
1015cd8b8:     	str	xzr, [sp, #0x18]
1015cd8bc:     	ldr	x8, [sp, #0x558]
1015cd8c0:     	ldr	x9, [sp, #0x50]
1015cd8c4:     	str	x9, [sp, #0x6c0]
1015cd8c8:     	str	x8, [sp, #0x6c8]
1015cd8cc:     	str	xzr, [sp, #0x6d0]
1015cd8d0:     	ldr	x8, [sp, #0x48]
1015cd8d4:     	ldr	w9, [x8], #0x4
1015cd8d8:     	str	x8, [sp, #0x48]
1015cd8dc:     	ldr	x8, [sp, #0x660]
1015cd8e0:     	ldr	x1, [x8, #0x5a0]
1015cd8e4:     	str	x9, [sp, #0x38]
1015cd8e8:     	cmp	x1, x9
1015cd8ec:     	b.ls	0x1015ce3a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4248>
1015cd8f0:     	ldr	x8, [x8, #0x598]
1015cd8f4:     	mov	w9, #0x58               ; =88
1015cd8f8:     	ldr	x10, [sp, #0x38]
1015cd8fc:     	umaddl	x8, w10, w9, x8
1015cd900:     	str	x8, [sp, #0x30]
1015cd904:     	ldr	w1, [x8, #0x50]
1015cd908:     	add	x8, sp, #0x550
1015cd90c:     	ldr	x9, [sp, #0x20]
1015cd910:     	add	x0, x9, #0xf0
1015cd914:     	add	x2, x9, #0x2f8
1015cd918:     	bl	0x1015d0bac <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015cd91c:     	ldr	x8, [sp, #0x550]
1015cd920:     	add	x9, sp, #0x550
1015cd924:     	ldur	q0, [x9, #0x8]
1015cd928:     	ldur	q1, [x9, #0x18]
1015cd92c:     	stp	q0, q1, [sp, #0x3f0]
1015cd930:     	ldur	q0, [x9, #0x28]
1015cd934:     	str	q0, [sp, #0x410]
1015cd938:     	ldur	x9, [x9, #0x38]
1015cd93c:     	str	x9, [sp, #0x420]
1015cd940:     	cbz	x8, 0x1015cdbd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a78>
1015cd944:     	ldr	x9, [sp, #0x420]
1015cd948:     	add	x10, sp, #0x220
1015cd94c:     	stur	x9, [x10, #0x38]
1015cd950:     	ldr	q0, [sp, #0x410]
1015cd954:     	stur	q0, [x10, #0x28]
1015cd958:     	ldp	q1, q0, [sp, #0x3f0]
1015cd95c:     	stur	q0, [x10, #0x18]
1015cd960:     	stur	q1, [x10, #0x8]
1015cd964:     	str	x8, [sp, #0x220]
1015cd968:     	ldr	x8, [sp, #0x228]
1015cd96c:     	ldr	x8, [x8, #0x10]
1015cd970:     	ldrb	w8, [x8, #0x10]
1015cd974:     	orr	w8, w8, #0x2
1015cd978:     	cmp	w8, #0x1b
1015cd97c:     	b.ne	0x1015cde74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d14>
1015cd980:     	add	x8, sp, #0x550
1015cd984:     	add	x0, sp, #0x220
1015cd988:     	bl	0x10152e71c <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections12source_count>
1015cd98c:     	ldr	w8, [sp, #0x550]
1015cd990:     	cmp	w8, #0x6
1015cd994:     	b.ne	0x1015cdc20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ac0>
1015cd998:     	ldr	x8, [sp, #0x558]
1015cd99c:     	str	x8, [sp, #0x50]
1015cd9a0:     	ldr	x8, [sp, #0x38]
1015cd9a4:     	cmp	x19, x8
1015cd9a8:     	b.ne	0x1015cd9b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3858>
1015cd9ac:     	ldr	x8, [sp, #0x50]
1015cd9b0:     	cmp	x8, x28
1015cd9b4:     	b.ne	0x1015cdc4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3aec>
1015cd9b8:     	ldr	x8, [sp, #0x18]
1015cd9bc:     	ldr	x9, [sp, #0x50]
1015cd9c0:     	adds	x8, x9, x8
1015cd9c4:     	str	x8, [sp, #0x18]
1015cd9c8:     	b.hs	0x1015cdfdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e7c>
1015cd9cc:     	ldr	x8, [sp, #0x50]
1015cd9d0:     	cbz	x8, 0x1015cdc68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b08>
1015cd9d4:     	ldr	x8, [sp, #0x18]
1015cd9d8:     	cmp	x8, x20
1015cd9dc:     	b.hi	0x1015cdc68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b08>
1015cd9e0:     	ldr	x8, [sp, #0x30]
1015cd9e4:     	ldr	x8, [x8, #0x8]
1015cd9e8:     	str	x8, [sp, #0x8]
1015cd9ec:     	cbnz	x8, 0x1015cda60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3900>
1015cd9f0:     	str	xzr, [sp]
1015cd9f4:     	ldr	x9, [sp, #0x8]
1015cd9f8:     	mov	w8, #0x8                ; =8
1015cd9fc:     	stp	x9, x8, [sp, #0x110]
1015cda00:     	str	xzr, [sp, #0x120]
1015cda04:     	ldp	q0, q1, [sp, #0x220]
1015cda08:     	add	x8, sp, #0x550
1015cda0c:     	stur	q0, [x8, #0x18]
1015cda10:     	stur	q1, [x8, #0x28]
1015cda14:     	ldp	q0, q1, [sp, #0x240]
1015cda18:     	stur	q0, [x8, #0x38]
1015cda1c:     	stur	q1, [x8, #0x48]
1015cda20:     	ldr	q0, [sp, #0x110]
1015cda24:     	str	q0, [sp, #0x550]
1015cda28:     	ldr	x8, [sp, #0x120]
1015cda2c:     	str	x8, [sp, #0x560]
1015cda30:     	ldr	x8, [sp, #0x38]
1015cda34:     	str	x8, [sp, #0x5a8]
1015cda38:     	ldr	x8, [sp, #0x50]
1015cda3c:     	str	x8, [sp, #0x5b0]
1015cda40:     	add	x0, sp, #0x6c0
1015cda44:     	add	x1, sp, #0x550
1015cda48:     	bl	0x1015d36e0 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionE8push_mutBR_>
1015cda4c:     	ldr	x8, [sp, #0x48]
1015cda50:     	ldr	x9, [sp, #0x28]
1015cda54:     	cmp	x8, x9
1015cda58:     	b.ne	0x1015cd8d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3770>
1015cda5c:     	b	0x1015cdc80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b20>
1015cda60:     	ldr	x8, [sp, #0x30]
1015cda64:     	ldr	x8, [x8]
1015cda68:     	str	x8, [sp, #0x10]
1015cda6c:     	add	x0, sp, #0x550
1015cda70:     	mov	x1, #0x0                ; =0
1015cda74:     	mov	w2, #0x8                ; =8
1015cda78:     	ldr	x3, [sp, #0x8]
1015cda7c:     	mov	w4, #0x8                ; =8
1015cda80:     	mov	w5, #0x48               ; =72
1015cda84:     	bl	0x1039e1800 <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
1015cda88:     	ldr	x8, [sp, #0x550]
1015cda8c:     	cmp	x8, #0x1
1015cda90:     	b.eq	0x1015cdf3c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ddc>
1015cda94:     	ldr	x8, [sp, #0x558]
1015cda98:     	ldr	x10, [sp, #0x8]
1015cda9c:     	and	x9, x10, #0x7fffffffffffff00
1015cdaa0:     	stp	x10, x8, [sp, #0x110]
1015cdaa4:     	str	xzr, [sp, #0x120]
1015cdaa8:     	lsl	x8, x10, #2
1015cdaac:     	stp	x9, x8, [sp]
1015cdab0:     	b	0x1015cdae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3988>
1015cdab4:     	ldr	x8, [x21, #0x28]
1015cdab8:     	ldr	x9, [sp, #0x30]
1015cdabc:     	ldr	x8, [x8, x9, lsl #3]
1015cdac0:     	str	x8, [sp, #0x558]
1015cdac4:     	str	w9, [sp, #0x554]
1015cdac8:     	str	wzr, [sp, #0x550]
1015cdacc:     	add	x0, sp, #0x110
1015cdad0:     	add	x1, sp, #0x550
1015cdad4:     	bl	0x1015d3774 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
1015cdad8:     	ldr	x8, [sp, #0x8]
1015cdadc:     	subs	x8, x8, #0x4
1015cdae0:     	str	x8, [sp, #0x8]
1015cdae4:     	b.eq	0x1015cda04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38a4>
1015cdae8:     	ldr	x8, [sp, #0x10]
1015cdaec:     	ldr	w9, [x8], #0x4
1015cdaf0:     	str	x8, [sp, #0x10]
1015cdaf4:     	ldr	x8, [sp, #0x660]
1015cdaf8:     	ldr	x1, [x8, #0x360]
1015cdafc:     	str	x9, [sp, #0x30]
1015cdb00:     	cmp	x1, x9
1015cdb04:     	b.ls	0x1015ce3bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x425c>
1015cdb08:     	ldr	x8, [x8, #0x358]
1015cdb0c:     	mov	w9, #0x140              ; =320
1015cdb10:     	ldr	x10, [sp, #0x30]
1015cdb14:     	umaddl	x8, w10, w9, x8
1015cdb18:     	ldrb	w8, [x8, #0x124]
1015cdb1c:     	cmp	w8, #0x7
1015cdb20:     	b.ne	0x1015cdab4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3954>
1015cdb24:     	add	x8, sp, #0x440
1015cdb28:     	ldr	x9, [sp, #0x20]
1015cdb2c:     	add	x0, x9, #0xf0
1015cdb30:     	add	x2, x9, #0x2f8
1015cdb34:     	ldr	x1, [sp, #0x30]
1015cdb38:     	bl	0x1015d0bac <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
1015cdb3c:     	ldr	x8, [sp, #0x440]
1015cdb40:     	add	x9, sp, #0x440
1015cdb44:     	ldur	q0, [x9, #0x8]
1015cdb48:     	ldur	q1, [x9, #0x18]
1015cdb4c:     	stp	q0, q1, [sp, #0xa0]
1015cdb50:     	ldur	q0, [x9, #0x28]
1015cdb54:     	str	q0, [sp, #0xc0]
1015cdb58:     	ldur	x9, [x9, #0x38]
1015cdb5c:     	str	x9, [sp, #0xd0]
1015cdb60:     	cbz	x8, 0x1015cde20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cc0>
1015cdb64:     	ldp	q0, q1, [sp, #0xa0]
1015cdb68:     	add	x10, sp, #0x550
1015cdb6c:     	stp	q0, q1, [x10, #0x10]
1015cdb70:     	ldr	q0, [sp, #0xc0]
1015cdb74:     	stur	q0, [x10, #0x30]
1015cdb78:     	ldr	x9, [sp, #0xd0]
1015cdb7c:     	stur	x9, [x10, #0x40]
1015cdb80:     	str	x8, [sp, #0x558]
1015cdb84:     	ldr	x8, [sp, #0x30]
1015cdb88:     	str	w8, [sp, #0x554]
1015cdb8c:     	mov	w8, #0x1                ; =1
1015cdb90:     	str	w8, [sp, #0x550]
1015cdb94:     	add	x0, sp, #0x110
1015cdb98:     	add	x1, sp, #0x550
1015cdb9c:     	bl	0x1015d3774 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
1015cdba0:     	b	0x1015cdad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3978>
1015cdba4:     	str	wzr, [x23]
1015cdba8:     	mov	w8, #0xc                ; =12
1015cdbac:     	adrp	x9, 0x107555000 <_anon.8298275ee38f8eff3e6cd6ae5f4faa65.78+0xf0>
1015cdbb0:     	add	x9, x9, #0x620
1015cdbb4:     	b	0x1015cdbc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a68>
1015cdbb8:     	str	wzr, [x23]
1015cdbbc:     	mov	w8, #0xc                ; =12
1015cdbc0:     	adrp	x9, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cdbc4:     	add	x9, x9, #0x7ce
1015cdbc8:     	stp	x8, x9, [x23, #0x8]
1015cdbcc:     	mov	w8, #0x1a               ; =26
1015cdbd0:     	str	x8, [x23, #0x18]
1015cdbd4:     	b	0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015cdbd8:     	ldp	q0, q1, [sp, #0x3f0]
1015cdbdc:     	stur	q0, [x27, #0x4]
1015cdbe0:     	stur	q1, [x27, #0x14]
1015cdbe4:     	ldr	q0, [sp, #0x410]
1015cdbe8:     	stur	q0, [x27, #0x24]
1015cdbec:     	ldr	x8, [sp, #0x420]
1015cdbf0:     	stur	x8, [x27, #0x34]
1015cdbf4:     	ldr	q0, [sp, #0x550]
1015cdbf8:     	ldr	q1, [sp, #0x560]
1015cdbfc:     	stur	q0, [x23, #0x4]
1015cdc00:     	mov	w8, #0x2                ; =2
1015cdc04:     	str	w8, [x23]
1015cdc08:     	stur	q1, [x23, #0x14]
1015cdc0c:     	ldr	q0, [sp, #0x570]
1015cdc10:     	stur	q0, [x23, #0x24]
1015cdc14:     	ldur	q0, [x27, #0x2c]
1015cdc18:     	str	q0, [x23, #0x30]
1015cdc1c:     	b	0x1015cd524 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c4>
1015cdc20:     	ldr	w9, [sp, #0x554]
1015cdc24:     	ldr	x10, [sp, #0x558]
1015cdc28:     	ldr	q0, [sp, #0x560]
1015cdc2c:     	ldr	q1, [sp, #0x570]
1015cdc30:     	stp	q0, q1, [x23, #0x10]
1015cdc34:     	ldr	q0, [sp, #0x580]
1015cdc38:     	ldr	q1, [sp, #0x590]
1015cdc3c:     	stp	q0, q1, [x23, #0x30]
1015cdc40:     	stp	w8, w9, [x23]
1015cdc44:     	str	x10, [x23, #0x8]
1015cdc48:     	b	0x1015cde90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d30>
1015cdc4c:     	str	wzr, [x23]
1015cdc50:     	mov	w8, #0xc                ; =12
1015cdc54:     	strb	w8, [x23, #0x8]
1015cdc58:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cdc5c:     	add	x8, x8, #0x1f7
1015cdc60:     	mov	w9, #0x24               ; =36
1015cdc64:     	b	0x1015cde8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d2c>
1015cdc68:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cdc6c:     	ldr	q0, [x8, #0xdc0]
1015cdc70:     	stur	q0, [x23, #0x8]
1015cdc74:     	mov	w8, #0x6                ; =6
1015cdc78:     	str	w8, [x23]
1015cdc7c:     	b	0x1015cde90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d30>
1015cdc80:     	ldr	x8, [sp, #0x18]
1015cdc84:     	cmp	x8, #0x2
1015cdc88:     	b.lo	0x1015cd510 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33b0>
1015cdc8c:     	ldr	x8, [sp, #0x18]
1015cdc90:     	str	x8, [sp, #0x6d8]
1015cdc94:     	add	x8, x8, x8, lsl #5
1015cdc98:     	lsl	x1, x8, #16
1015cdc9c:     	add	x8, sp, #0x550
1015cdca0:     	add	x0, sp, #0x668
1015cdca4:     	bl	0x102d54f5c <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1015cdca8:     	ldr	w8, [sp, #0x550]
1015cdcac:     	cmp	w8, #0x1a
1015cdcb0:     	b.ne	0x1015cdec8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d68>
1015cdcb4:     	ldur	q0, [x27, #0x8]
1015cdcb8:     	ldur	q1, [x27, #0x18]
1015cdcbc:     	str	q0, [sp, #0x6e0]
1015cdcc0:     	str	q1, [sp, #0x6f0]
1015cdcc4:     	ldr	x20, [sp, #0x6d0]
1015cdcc8:     	cbnz	x20, 0x1015cdffc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e9c>
1015cdccc:     	mov	x8, #0x0                ; =0
1015cdcd0:     	mov	w9, #0x8                ; =8
1015cdcd4:     	str	x20, [sp, #0x708]
1015cdcd8:     	str	x9, [sp, #0x710]
1015cdcdc:     	str	xzr, [sp, #0x718]
1015cdce0:     	ldr	x1, [sp, #0x6c8]
1015cdce4:     	mov	w9, #0x68               ; =104
1015cdce8:     	madd	x2, x8, x9, x1
1015cdcec:     	mov	w19, #0x1               ; =1
1015cdcf0:     	add	x0, sp, #0x708
1015cdcf4:     	mov	w28, #0x1               ; =1
1015cdcf8:     	bl	0x1014987d0 <__RINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENCNvMs0_B2f_NtB2h_10Invocation12run_parallels9_0EEB2p_>
1015cdcfc:     	ldr	x2, [sp, #0x710]
1015cdd00:     	ldr	x3, [sp, #0x718]
1015cdd04:     	add	x0, sp, #0x550
1015cdd08:     	ldr	x1, [sp, #0x58]
1015cdd0c:     	bl	0x1015c3308 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel9admissionNtB6_10Invocation18parallel_admission>
1015cdd10:     	ldr	w8, [sp, #0x550]
1015cdd14:     	cmp	w8, #0x6
1015cdd18:     	b.ne	0x1015cdee8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d88>
1015cdd1c:     	ldr	x8, [sp, #0x558]
1015cdd20:     	ldr	q0, [sp, #0x560]
1015cdd24:     	str	q0, [sp, #0x740]
1015cdd28:     	ldr	x9, [sp, #0x570]
1015cdd2c:     	str	x9, [sp, #0x750]
1015cdd30:     	cbz	x8, 0x1015cdf60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e00>
1015cdd34:     	ldr	q0, [sp, #0x740]
1015cdd38:     	stur	q0, [x24, #0x8]
1015cdd3c:     	ldr	x9, [sp, #0x750]
1015cdd40:     	str	x8, [sp, #0x720]
1015cdd44:     	str	x9, [sp, #0x738]
1015cdd48:     	ldr	x0, [sp, #0x660]
1015cdd4c:     	add	x8, sp, #0x550
1015cdd50:     	add	x1, sp, #0x668
1015cdd54:     	ldr	x2, [sp, #0x18]
1015cdd58:     	bl	0x1015e3eb8 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel17worker_setup_fits>
1015cdd5c:     	ldr	w9, [sp, #0x550]
1015cdd60:     	ldrb	w8, [sp, #0x554]
1015cdd64:     	cmp	w9, #0x6
1015cdd68:     	b.ne	0x1015cdf90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e30>
1015cdd6c:     	tbz	w8, #0x0, 0x1015cdfc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e64>
1015cdd70:     	ldr	x8, [sp, #0x660]
1015cdd74:     	ldr	x1, [x8, #0x3a0]
1015cdd78:     	ldr	w0, [x22, #0x30]
1015cdd7c:     	cmp	x1, x0
1015cdd80:     	b.ls	0x1015ce3d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4270>
1015cdd84:     	ldr	x8, [x8, #0x398]
1015cdd88:     	mov	w9, #0x540              ; =1344
1015cdd8c:     	umaddl	x8, w0, w9, x8
1015cdd90:     	ldr	w9, [x8, #0x520]
1015cdd94:     	ldr	q0, [x8, #0x510]
1015cdd98:     	stur	q0, [x29, #-0x100]
1015cdd9c:     	stur	w9, [x29, #-0xf0]
1015cdda0:     	add	x8, sp, #0x550
1015cdda4:     	ldr	x9, [sp, #0x20]
1015cdda8:     	add	x0, x9, #0x3b8
1015cddac:     	bl	0x102363bdc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015cddb0:     	ldr	x8, [sp, #0x550]
1015cddb4:     	cmp	x8, #0x1
1015cddb8:     	b.ne	0x1015ce050 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ef0>
1015cddbc:     	ldr	x1, [sp, #0x558]
1015cddc0:     	ldr	x2, [sp, #0x560]
1015cddc4:     	add	x19, sp, #0x550
1015cddc8:     	add	x8, sp, #0x550
1015cddcc:     	ldr	x9, [sp, #0x20]
1015cddd0:     	add	x0, x9, #0x3b8
1015cddd4:     	add	x3, sp, #0x668
1015cddd8:     	bl	0x102365ae0 <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget32reserve_worker_group_with_memory>
1015cdddc:     	ldrb	w8, [sp, #0x588]
1015cdde0:     	cmp	w8, #0x2
1015cdde4:     	b.ne	0x1015ce090 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f30>
1015cdde8:     	ldr	w8, [sp, #0x550]
1015cddec:     	cmp	w8, #0x1a
1015cddf0:     	b.ne	0x1015ce23c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40dc>
1015cddf4:     	ldur	w9, [x29, #-0x100]
1015cddf8:     	ldurb	w8, [x29, #-0xfc]
1015cddfc:     	add	x12, sp, #0x720
1015cde00:     	ldur	w10, [x12, #0x45]
1015cde04:     	str	w10, [sp, #0x110]
1015cde08:     	ldur	w11, [x29, #-0xf8]
1015cde0c:     	add	x10, sp, #0x110
1015cde10:     	stur	w11, [x10, #0x3]
1015cde14:     	mov	w10, #0x4               ; =4
1015cde18:     	ldur	d0, [x12, #0x4c]
1015cde1c:     	b	0x1015ce248 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40e8>
1015cde20:     	ldp	q0, q1, [sp, #0xa0]
1015cde24:     	add	x8, sp, #0x440
1015cde28:     	stur	q0, [x8, #0x4]
1015cde2c:     	stur	q1, [x8, #0x14]
1015cde30:     	ldr	q0, [sp, #0xc0]
1015cde34:     	stur	q0, [x8, #0x24]
1015cde38:     	ldr	x9, [sp, #0xd0]
1015cde3c:     	stur	x9, [x8, #0x34]
1015cde40:     	ldr	q0, [sp, #0x440]
1015cde44:     	ldr	q1, [sp, #0x450]
1015cde48:     	stur	q0, [x23, #0x4]
1015cde4c:     	mov	w9, #0x2                ; =2
1015cde50:     	str	w9, [x23]
1015cde54:     	stur	q1, [x23, #0x14]
1015cde58:     	ldr	q0, [sp, #0x460]
1015cde5c:     	stur	q0, [x23, #0x24]
1015cde60:     	ldur	q0, [x8, #0x2c]
1015cde64:     	str	q0, [x23, #0x30]
1015cde68:     	add	x0, sp, #0x110
1015cde6c:     	bl	0x1015aca9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015cde70:     	b	0x1015cde90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d30>
1015cde74:     	str	wzr, [x23]
1015cde78:     	mov	w8, #0xc                ; =12
1015cde7c:     	strb	w8, [x23, #0x8]
1015cde80:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cde84:     	add	x8, x8, #0x21b
1015cde88:     	mov	w9, #0x30               ; =48
1015cde8c:     	stp	x8, x9, [x23, #0x10]
1015cde90:     	add	x0, sp, #0x220
1015cde94:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cde98:     	b	0x1015cd524 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c4>
1015cde9c:     	mov	w24, #0x1               ; =1
1015cdea0:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cdea4:     	add	x2, x2, #0x5d0
1015cdea8:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cdeac:     	b	0x1015ce3dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x427c>
1015cdeb0:     	adrp	x2, 0x107f0f000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.66+0x208>
1015cdeb4:     	add	x2, x2, #0x788
1015cdeb8:     	mov	x0, x1
1015cdebc:     	ldr	x1, [sp, #0x28]
1015cdec0:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cdec4:     	b	0x1015ce3dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x427c>
1015cdec8:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cdecc:     	ldr	q0, [x8, #0xdc0]
1015cded0:     	stur	q0, [x23, #0x8]
1015cded4:     	mov	w8, #0x6                ; =6
1015cded8:     	str	w8, [x23]
1015cdedc:     	add	x0, sp, #0x550
1015cdee0:     	bl	0x1015ac240 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
1015cdee4:     	b	0x1015cd524 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c4>
1015cdee8:     	ldr	w9, [sp, #0x554]
1015cdeec:     	ldr	x10, [sp, #0x558]
1015cdef0:     	ldr	q0, [sp, #0x560]
1015cdef4:     	str	q0, [sp, #0x740]
1015cdef8:     	ldur	q1, [x27, #0x28]
1015cdefc:     	stur	q1, [x23, #0x28]
1015cdf00:     	ldur	q1, [x27, #0x38]
1015cdf04:     	ldr	x11, [sp, #0x570]
1015cdf08:     	ldr	x12, [sp, #0x598]
1015cdf0c:     	str	x11, [sp, #0x750]
1015cdf10:     	stur	q1, [x23, #0x38]
1015cdf14:     	str	x12, [x23, #0x48]
1015cdf18:     	str	q0, [x23, #0x10]
1015cdf1c:     	str	x11, [x23, #0x20]
1015cdf20:     	stp	w8, w9, [x23]
1015cdf24:     	str	x10, [x23, #0x8]
1015cdf28:     	b	0x1015cdf74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e14>
1015cdf2c:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015cdf30:     	add	x2, x2, #0x510
1015cdf34:     	mov	x0, x20
1015cdf38:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015cdf3c:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015cdf40:     	add	x8, x8, #0x1dc
1015cdf44:     	ldr	x9, [sp]
1015cdf48:     	orr	x9, x9, #0xc
1015cdf4c:     	stp	x9, x8, [x23, #0x8]
1015cdf50:     	mov	w8, #0x1b               ; =27
1015cdf54:     	str	x8, [x23, #0x18]
1015cdf58:     	str	wzr, [x23]
1015cdf5c:     	b	0x1015cde90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d30>
1015cdf60:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cdf64:     	ldr	q0, [x8, #0xdc0]
1015cdf68:     	stur	q0, [x23, #0x8]
1015cdf6c:     	mov	w8, #0x6                ; =6
1015cdf70:     	str	w8, [x23]
1015cdf74:     	ldr	x8, [sp, #0x708]
1015cdf78:     	cbz	x8, 0x1015ce2e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
1015cdf7c:     	ldr	x0, [sp, #0x710]
1015cdf80:     	lsl	x1, x8, #3
1015cdf84:     	mov	w2, #0x8                ; =8
1015cdf88:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015cdf8c:     	b	0x1015ce2e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
1015cdf90:     	ldur	q0, [x27, #0x15]
1015cdf94:     	stur	q0, [x23, #0x15]
1015cdf98:     	ldur	q0, [x27, #0x25]
1015cdf9c:     	stur	q0, [x23, #0x25]
1015cdfa0:     	ldur	q0, [x27, #0x35]
1015cdfa4:     	stur	q0, [x23, #0x35]
1015cdfa8:     	ldr	q0, [sp, #0x590]
1015cdfac:     	str	q0, [x23, #0x40]
1015cdfb0:     	ldur	q0, [x27, #0x5]
1015cdfb4:     	stur	q0, [x23, #0x5]
1015cdfb8:     	str	w9, [x23]
1015cdfbc:     	strb	w8, [x23, #0x4]
1015cdfc0:     	b	0x1015ce2c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4160>
1015cdfc4:     	adrp	x8, 0x10751d000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2872>
1015cdfc8:     	ldr	q0, [x8, #0xdc0]
1015cdfcc:     	stur	q0, [x23, #0x8]
1015cdfd0:     	mov	w8, #0x6                ; =6
1015cdfd4:     	str	w8, [x23]
1015cdfd8:     	b	0x1015ce2c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4160>
1015cdfdc:     	str	wzr, [x23]
1015cdfe0:     	mov	w8, #0xc                ; =12
1015cdfe4:     	adrp	x9, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015cdfe8:     	add	x9, x9, #0x7ff
1015cdfec:     	stp	x8, x9, [x23, #0x8]
1015cdff0:     	mov	w8, #0x1c               ; =28
1015cdff4:     	str	x8, [x23, #0x18]
1015cdff8:     	b	0x1015cde90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d30>
1015cdffc:     	add	x0, sp, #0x550
1015ce000:     	mov	x1, #0x0                ; =0
1015ce004:     	mov	w2, #0x8                ; =8
1015ce008:     	mov	x3, x20
1015ce00c:     	mov	w4, #0x8                ; =8
1015ce010:     	mov	w5, #0x8                ; =8
1015ce014:     	bl	0x1039e1800 <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
1015ce018:     	ldr	w8, [sp, #0x550]
1015ce01c:     	tbz	w8, #0x0, 0x1015ce070 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f10>
1015ce020:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ce024:     	add	x8, x8, #0x24b
1015ce028:     	mov	w9, #0xc                ; =12
1015ce02c:     	stp	x9, x8, [x23, #0x8]
1015ce030:     	mov	w8, #0x27               ; =39
1015ce034:     	str	x8, [x23, #0x18]
1015ce038:     	str	wzr, [x23]
1015ce03c:     	b	0x1015ce2e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4188>
1015ce040:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ce044:     	add	x2, x2, #0x4e0
1015ce048:     	mov	x0, x20
1015ce04c:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ce050:     	str	wzr, [x23]
1015ce054:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce058:     	add	x8, x8, #0x85e
1015ce05c:     	mov	w9, #0xc                ; =12
1015ce060:     	stp	x9, x8, [x23, #0x8]
1015ce064:     	mov	w8, #0x27               ; =39
1015ce068:     	str	x8, [x23, #0x18]
1015ce06c:     	b	0x1015ce2c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4160>
1015ce070:     	ldr	x9, [sp, #0x558]
1015ce074:     	ldr	x8, [sp, #0x6d0]
1015ce078:     	b	0x1015cdcd4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3b74>
1015ce07c:     	adrp	x8, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ce080:     	add	x8, x8, #0x4f8
1015ce084:     	mov	x0, x2
1015ce088:     	mov	x2, x8
1015ce08c:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ce090:     	ldrb	w8, [sp, #0x550]
1015ce094:     	ldr	w9, [sp, #0x554]
1015ce098:     	add	x12, sp, #0x720
1015ce09c:     	stur	w9, [x12, #0xb3]
1015ce0a0:     	ldur	w9, [x27, #0x1]
1015ce0a4:     	stur	w9, [x29, #-0x90]
1015ce0a8:     	ldr	q0, [sp, #0x560]
1015ce0ac:     	ldr	q1, [sp, #0x570]
1015ce0b0:     	str	q0, [sp, #0x440]
1015ce0b4:     	str	q1, [sp, #0x450]
1015ce0b8:     	ldr	x10, [sp, #0x580]
1015ce0bc:     	ldr	x9, [sp, #0x588]
1015ce0c0:     	sub	x11, x29, #0xe0
1015ce0c4:     	str	x10, [sp, #0x460]
1015ce0c8:     	ldr	d0, [sp, #0x558]
1015ce0cc:     	ldur	w10, [x12, #0xb3]
1015ce0d0:     	stur	w10, [x12, #0x93]
1015ce0d4:     	ldur	w10, [x29, #-0x90]
1015ce0d8:     	stur	w10, [x29, #-0xb0]
1015ce0dc:     	ldr	q1, [sp, #0x440]
1015ce0e0:     	ldr	q2, [sp, #0x450]
1015ce0e4:     	ldr	x10, [sp, #0x460]
1015ce0e8:     	str	x10, [sp, #0x240]
1015ce0ec:     	stp	q1, q2, [sp, #0x220]
1015ce0f0:     	add	x20, sp, #0x720
1015ce0f4:     	ldur	w10, [x12, #0x93]
1015ce0f8:     	str	w10, [sp, #0x334]
1015ce0fc:     	ldur	w10, [x29, #-0xb0]
1015ce100:     	stur	w10, [x26, #0x1]
1015ce104:     	ldp	q1, q2, [sp, #0x220]
1015ce108:     	ldr	x10, [sp, #0x240]
1015ce10c:     	stp	q1, q2, [sp, #0x340]
1015ce110:     	strb	w8, [sp, #0x330]
1015ce114:     	str	d0, [sp, #0x338]
1015ce118:     	str	x10, [sp, #0x360]
1015ce11c:     	str	x9, [sp, #0x368]
1015ce120:     	ldr	x8, [sp, #0x58]
1015ce124:     	ldr	q0, [x8, #0x4e0]
1015ce128:     	stur	q0, [x27, #0xa8]
1015ce12c:     	ldr	x9, [x8, #0x4f0]
1015ce130:     	ldp	q0, q1, [x8, #0x80]
1015ce134:     	str	q0, [sp, #0x5d0]
1015ce138:     	str	q1, [sp, #0x5e0]
1015ce13c:     	ldr	x10, [x8, #0xa0]
1015ce140:     	str	x9, [sp, #0x608]
1015ce144:     	str	x10, [sp, #0x5f0]
1015ce148:     	ldp	q0, q1, [x8, #0x40]
1015ce14c:     	str	q0, [sp, #0x590]
1015ce150:     	str	q1, [sp, #0x5a0]
1015ce154:     	ldp	q1, q0, [x8, #0x60]
1015ce158:     	str	q0, [sp, #0x5c0]
1015ce15c:     	str	q1, [sp, #0x5b0]
1015ce160:     	ldp	q0, q1, [x8]
1015ce164:     	str	q0, [sp, #0x550]
1015ce168:     	str	q1, [sp, #0x560]
1015ce16c:     	ldp	q1, q0, [x8, #0x20]
1015ce170:     	str	q0, [sp, #0x580]
1015ce174:     	str	q1, [sp, #0x570]
1015ce178:     	ldr	x8, [sp, #0x40]
1015ce17c:     	stp	x8, xzr, [x29, #-0xe8]
1015ce180:     	stur	xzr, [x29, #-0xd8]
1015ce184:     	add	x8, sp, #0x6d8
1015ce188:     	add	x9, sp, #0x6c0
1015ce18c:     	str	x8, [sp, #0x440]
1015ce190:     	str	x9, [sp, #0x448]
1015ce194:     	add	x8, sp, #0x330
1015ce198:     	add	x9, sp, #0x668
1015ce19c:     	str	x8, [sp, #0x450]
1015ce1a0:     	str	x9, [sp, #0x458]
1015ce1a4:     	sub	x8, x29, #0x100
1015ce1a8:     	str	x11, [sp, #0x468]
1015ce1ac:     	add	x9, sp, #0x660
1015ce1b0:     	str	x8, [sp, #0x460]
1015ce1b4:     	str	x9, [sp, #0x470]
1015ce1b8:     	sub	x8, x29, #0xe8
1015ce1bc:     	add	x9, sp, #0x550
1015ce1c0:     	str	x8, [sp, #0x478]
1015ce1c4:     	str	x9, [sp, #0x480]
1015ce1c8:     	adrp	x1, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ce1cc:     	add	x1, x1, #0x5a0
1015ce1d0:     	add	x8, sp, #0x110
1015ce1d4:     	add	x0, sp, #0x440
1015ce1d8:     	bl	0x1014c57f8 <__RINvNtNtCsgirOGyZpP7g_3std6thread6scoped5scopeNCNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallelNtBS_10Invocation12run_parallelsc_0INtNtCsgDHHaSskbIF_4core6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIB2P_NtBQ_7ReceiptNtBU_27NativeProgramExecutionErrorEEB4f_EEB10_>
1015ce1dc:     	ldp	q0, q1, [sp, #0x330]
1015ce1e0:     	str	q0, [sp, #0x440]
1015ce1e4:     	str	q1, [sp, #0x450]
1015ce1e8:     	ldp	q0, q1, [sp, #0x350]
1015ce1ec:     	str	q0, [sp, #0x460]
1015ce1f0:     	str	q1, [sp, #0x470]
1015ce1f4:     	mov	w19, #0x1               ; =1
1015ce1f8:     	add	x8, sp, #0x220
1015ce1fc:     	add	x0, sp, #0x440
1015ce200:     	bl	0x10291c90c <__RNvMs4_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_15NativeWorkGroup29finish_with_credit_statistics>
1015ce204:     	ldr	w8, [sp, #0x220]
1015ce208:     	tbz	w8, #0x0, 0x1015ce2f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4194>
1015ce20c:     	ldr	x8, [sp, #0x238]
1015ce210:     	ldr	q0, [sp, #0x240]
1015ce214:     	str	q0, [x23, #0x30]
1015ce218:     	ldur	w10, [x29, #-0x100]
1015ce21c:     	ldur	q0, [x25, #0x8]
1015ce220:     	mov	w11, #0x4               ; =4
1015ce224:     	stp	w11, w10, [x23]
1015ce228:     	ldur	q1, [x20, #0x44]
1015ce22c:     	stur	q1, [x23, #0x8]
1015ce230:     	stur	q0, [x23, #0x18]
1015ce234:     	mov	w9, #0x28               ; =40
1015ce238:     	b	0x1015ce42c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42cc>
1015ce23c:     	mov	w10, #0x0               ; =0
1015ce240:     	ldr	d0, [sp, #0x550]
1015ce244:     	mov	w8, #0xd                ; =13
1015ce248:     	add	x11, sp, #0x110
1015ce24c:     	ldur	w11, [x11, #0x3]
1015ce250:     	add	x13, sp, #0x720
1015ce254:     	stur	w11, [x13, #0xb3]
1015ce258:     	ldr	w11, [sp, #0x110]
1015ce25c:     	stur	w11, [x29, #-0x90]
1015ce260:     	ldur	q1, [x19, #0x8]
1015ce264:     	ldur	q2, [x19, #0x18]
1015ce268:     	str	q1, [sp, #0x440]
1015ce26c:     	str	q2, [sp, #0x450]
1015ce270:     	ldur	x11, [x19, #0x28]
1015ce274:     	str	x11, [sp, #0x460]
1015ce278:     	ldur	w12, [x13, #0xb3]
1015ce27c:     	stur	w12, [x13, #0x93]
1015ce280:     	ldur	w12, [x29, #-0x90]
1015ce284:     	stur	w12, [x29, #-0xb0]
1015ce288:     	str	x11, [sp, #0x240]
1015ce28c:     	stp	q1, q2, [sp, #0x220]
1015ce290:     	stur	w12, [x23, #0x9]
1015ce294:     	ldur	w11, [x13, #0x93]
1015ce298:     	str	w11, [x23, #0xc]
1015ce29c:     	ldp	q1, q2, [sp, #0x220]
1015ce2a0:     	stur	q1, [x23, #0x18]
1015ce2a4:     	stur	q2, [x23, #0x28]
1015ce2a8:     	ldr	x11, [sp, #0x240]
1015ce2ac:     	str	x11, [x23, #0x38]
1015ce2b0:     	stp	w10, w9, [x23]
1015ce2b4:     	strb	w8, [x23, #0x8]
1015ce2b8:     	mov	w19, #0x1               ; =1
1015ce2bc:     	str	d0, [x23, #0x10]
1015ce2c0:     	mov	w28, #0x1               ; =1
1015ce2c4:     	add	x0, sp, #0x720
1015ce2c8:     	bl	0x1015ada9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015ce2cc:     	ldr	x8, [sp, #0x708]
1015ce2d0:     	cbz	x8, 0x1015ce2e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4184>
1015ce2d4:     	ldr	x0, [sp, #0x710]
1015ce2d8:     	lsl	x1, x8, #3
1015ce2dc:     	mov	w2, #0x8                ; =8
1015ce2e0:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015ce2e4:     	tbz	w19, #0x0, 0x1015cd524 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c4>
1015ce2e8:     	add	x0, sp, #0x6e0
1015ce2ec:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015ce2f0:     	b	0x1015cd524 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33c4>
1015ce2f4:     	ldr	x8, [sp, #0x238]
1015ce2f8:     	ldr	x9, [sp, #0x20]
1015ce2fc:     	ldr	x9, [x9, #0x418]
1015ce300:     	adds	x9, x9, x8
1015ce304:     	b.hs	0x1015ce3e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4280>
1015ce308:     	ldr	x10, [sp, #0x240]
1015ce30c:     	ldr	x8, [sp, #0x248]
1015ce310:     	ldr	x11, [sp, #0x20]
1015ce314:     	str	x9, [x11, #0x418]
1015ce318:     	ldr	x9, [x11, #0x420]
1015ce31c:     	adds	x9, x9, x10
1015ce320:     	b.hs	0x1015ce3f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4294>
1015ce324:     	ldr	x10, [sp, #0x20]
1015ce328:     	str	x9, [x10, #0x420]
1015ce32c:     	ldr	x9, [x10, #0x428]
1015ce330:     	adds	x8, x9, x8
1015ce334:     	b.hs	0x1015ce410 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42b0>
1015ce338:     	ldr	x9, [sp, #0x20]
1015ce33c:     	str	x8, [x9, #0x428]
1015ce340:     	ldr	q0, [sp, #0x6e0]
1015ce344:     	ldr	q1, [sp, #0x6f0]
1015ce348:     	str	q0, [sp, #0x440]
1015ce34c:     	str	q1, [sp, #0x450]
1015ce350:     	mov	w19, #0x0               ; =0
1015ce354:     	add	x0, sp, #0x440
1015ce358:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015ce35c:     	ldr	w8, [sp, #0x110]
1015ce360:     	cmp	w8, #0x6
1015ce364:     	b.ne	0x1015ce43c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42dc>
1015ce368:     	mov	x9, #0x0                ; =0
1015ce36c:     	add	x8, sp, #0x110
1015ce370:     	ldur	q0, [x8, #0x8]
1015ce374:     	stur	q0, [x29, #-0xd0]
1015ce378:     	ldr	x8, [sp, #0x128]
1015ce37c:     	stur	x8, [x29, #-0xc0]
1015ce380:     	ldur	x20, [x29, #-0xc8]
1015ce384:     	mov	w10, #0xc8              ; =200
1015ce388:     	mul	x10, x8, x10
1015ce38c:     	add	x21, x20, x10
1015ce390:     	cmp	x10, x9
1015ce394:     	b.eq	0x1015ce464 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4304>
1015ce398:     	ldr	x11, [x20, x9]
1015ce39c:     	add	x9, x9, #0xc8
1015ce3a0:     	cbz	x11, 0x1015ce390 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4230>
1015ce3a4:     	b	0x1015ce4c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4360>
1015ce3a8:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ce3ac:     	add	x2, x2, #0x558
1015ce3b0:     	ldr	x0, [sp, #0x38]
1015ce3b4:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ce3b8:     	b	0x1015ce3dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x427c>
1015ce3bc:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ce3c0:     	add	x2, x2, #0x570
1015ce3c4:     	ldr	x0, [sp, #0x30]
1015ce3c8:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ce3cc:     	b	0x1015ce3dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x427c>
1015ce3d0:     	adrp	x2, 0x107f10000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.234+0xeb0>
1015ce3d4:     	add	x2, x2, #0x588
1015ce3d8:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015ce3dc:     	brk	#0x1
1015ce3e0:     	str	wzr, [x23]
1015ce3e4:     	mov	w9, #0xc                ; =12
1015ce3e8:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce3ec:     	add	x10, x10, #0x885
1015ce3f0:     	b	0x1015ce404 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42a4>
1015ce3f4:     	str	wzr, [x23]
1015ce3f8:     	mov	w9, #0xc                ; =12
1015ce3fc:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce400:     	add	x10, x10, #0x8ae
1015ce404:     	stp	x9, x10, [x23, #0x8]
1015ce408:     	mov	w8, #0x29               ; =41
1015ce40c:     	b	0x1015ce428 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42c8>
1015ce410:     	str	wzr, [x23]
1015ce414:     	mov	w9, #0xc                ; =12
1015ce418:     	adrp	x10, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce41c:     	add	x10, x10, #0x8d7
1015ce420:     	stp	x9, x10, [x23, #0x8]
1015ce424:     	mov	w8, #0x2b               ; =43
1015ce428:     	mov	w9, #0x18               ; =24
1015ce42c:     	str	x8, [x23, x9]
1015ce430:     	add	x0, sp, #0x110
1015ce434:     	bl	0x1015abfa8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
1015ce438:     	b	0x1015ce2c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4160>
1015ce43c:     	ldp	q0, q1, [sp, #0x140]
1015ce440:     	stp	q0, q1, [x23, #0x30]
1015ce444:     	add	x9, sp, #0x110
1015ce448:     	ldur	q0, [x9, #0x4]
1015ce44c:     	stur	q0, [x23, #0x4]
1015ce450:     	ldp	q1, q0, [sp, #0x120]
1015ce454:     	stp	q1, q0, [x23, #0x10]
1015ce458:     	str	w8, [x23]
1015ce45c:     	mov	w19, #0x0               ; =0
1015ce460:     	b	0x1015ce2c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4160>
1015ce464:     	ldr	x9, [sp, #0x20]
1015ce468:     	ldr	x9, [x9, #0x440]
1015ce46c:     	cmn	x9, #0x1
1015ce470:     	b.eq	0x1015ce6c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4564>
1015ce474:     	add	x9, x9, #0x1
1015ce478:     	ldr	x10, [sp, #0x20]
1015ce47c:     	str	x9, [x10, #0x440]
1015ce480:     	ldr	x9, [x10, #0x438]
1015ce484:     	ldr	x10, [sp, #0x6d0]
1015ce488:     	adds	x9, x10, x9
1015ce48c:     	b.hs	0x1015ce6c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4564>
1015ce490:     	ldp	x10, x11, [sp, #0x18]
1015ce494:     	str	x9, [x11, #0x438]
1015ce498:     	ldr	x9, [x11, #0x448]
1015ce49c:     	adds	x9, x9, x10
1015ce4a0:     	b.hs	0x1015ce6d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4574>
1015ce4a4:     	ldr	x11, [sp, #0x20]
1015ce4a8:     	str	x9, [x11, #0x448]
1015ce4ac:     	ldr	x9, [x11, #0x450]
1015ce4b0:     	ldur	x10, [x29, #-0xd8]
1015ce4b4:     	cmp	x10, x9
1015ce4b8:     	csel	x9, x10, x9, hi
1015ce4bc:     	str	x9, [x11, #0x450]
1015ce4c0:     	mov	w9, #0xc8               ; =200
1015ce4c4:     	mul	x10, x8, x9
1015ce4c8:     	add	x11, x20, #0x60
1015ce4cc:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce4d0:     	add	x8, x8, #0x91f
1015ce4d4:     	mov	w9, #0x17               ; =23
1015ce4d8:     	adrp	x12, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce4dc:     	add	x12, x12, #0x936
1015ce4e0:     	adrp	x13, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce4e4:     	add	x13, x13, #0x94e
1015ce4e8:     	adrp	x14, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce4ec:     	add	x14, x14, #0x966
1015ce4f0:     	adrp	x15, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce4f4:     	add	x15, x15, #0x985
1015ce4f8:     	adrp	x16, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce4fc:     	add	x16, x16, #0x9ab
1015ce500:     	adrp	x17, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce504:     	add	x17, x17, #0x9ca
1015ce508:     	adrp	x1, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce50c:     	add	x1, x1, #0x9e6
1015ce510:     	adrp	x2, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce514:     	add	x2, x2, #0xa0a
1015ce518:     	adrp	x3, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce51c:     	add	x3, x3, #0xa2e
1015ce520:     	adrp	x4, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce524:     	add	x4, x4, #0xa4d
1015ce528:     	adrp	x0, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce52c:     	add	x0, x0, #0xa6a
1015ce530:     	adrp	x5, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce534:     	add	x5, x5, #0xa92
1015ce538:     	b	0x1015ce544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43e4>
1015ce53c:     	sub	x10, x10, #0xc8
1015ce540:     	add	x11, x11, #0xc8
1015ce544:     	cbz	x10, 0x1015ce6e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4584>
1015ce548:     	ldur	x6, [x11, #-0x60]
1015ce54c:     	cmp	x6, #0x1
1015ce550:     	b.eq	0x1015ce53c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43dc>
1015ce554:     	ldr	x6, [sp, #0x20]
1015ce558:     	ldr	x6, [x6, #0x330]
1015ce55c:     	ldur	x7, [x11, #-0x18]
1015ce560:     	adds	x6, x7, x6
1015ce564:     	b.hs	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce568:     	ldr	x7, [sp, #0x20]
1015ce56c:     	str	x6, [x7, #0x330]
1015ce570:     	ldr	x6, [x7, #0x3c8]
1015ce574:     	ldur	x7, [x11, #-0x10]
1015ce578:     	adds	x6, x7, x6
1015ce57c:     	b.hs	0x1015ce8a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4740>
1015ce580:     	ldr	x7, [sp, #0x20]
1015ce584:     	str	x6, [x7, #0x3c8]
1015ce588:     	ldr	x6, [x7, #0x3d0]
1015ce58c:     	ldur	x7, [x11, #-0x8]
1015ce590:     	adds	x6, x7, x6
1015ce594:     	b.hs	0x1015ce8ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x474c>
1015ce598:     	ldr	x7, [sp, #0x20]
1015ce59c:     	str	x6, [x7, #0x3d0]
1015ce5a0:     	ldr	x6, [x7, #0x3d8]
1015ce5a4:     	ldr	x7, [x11]
1015ce5a8:     	adds	x6, x7, x6
1015ce5ac:     	b.hs	0x1015ce8b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4758>
1015ce5b0:     	ldr	x7, [sp, #0x20]
1015ce5b4:     	str	x6, [x7, #0x3d8]
1015ce5b8:     	ldr	x6, [x7, #0x3e0]
1015ce5bc:     	ldr	x7, [x11, #0x8]
1015ce5c0:     	adds	x6, x7, x6
1015ce5c4:     	b.hs	0x1015ce8c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4764>
1015ce5c8:     	ldr	x7, [sp, #0x20]
1015ce5cc:     	str	x6, [x7, #0x3e0]
1015ce5d0:     	ldr	x6, [x7, #0x3e8]
1015ce5d4:     	ldr	x7, [x11, #0x10]
1015ce5d8:     	adds	x6, x7, x6
1015ce5dc:     	b.hs	0x1015ce8d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4770>
1015ce5e0:     	ldr	x7, [sp, #0x20]
1015ce5e4:     	str	x6, [x7, #0x3e8]
1015ce5e8:     	ldr	x6, [x7, #0x3f0]
1015ce5ec:     	ldr	x7, [x11, #0x18]
1015ce5f0:     	adds	x6, x7, x6
1015ce5f4:     	b.hs	0x1015ce8dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x477c>
1015ce5f8:     	ldr	x7, [sp, #0x20]
1015ce5fc:     	str	x6, [x7, #0x3f0]
1015ce600:     	ldr	x6, [x7, #0x3f8]
1015ce604:     	ldr	x7, [x11, #0x20]
1015ce608:     	adds	x6, x7, x6
1015ce60c:     	b.hs	0x1015ce8e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4788>
1015ce610:     	ldr	x7, [sp, #0x20]
1015ce614:     	str	x6, [x7, #0x3f8]
1015ce618:     	ldr	x6, [x7, #0x400]
1015ce61c:     	ldr	x7, [x11, #0x28]
1015ce620:     	adds	x6, x7, x6
1015ce624:     	b.hs	0x1015ce8f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4794>
1015ce628:     	ldr	x7, [sp, #0x20]
1015ce62c:     	str	x6, [x7, #0x400]
1015ce630:     	ldr	x6, [x7, #0x408]
1015ce634:     	ldr	x7, [x11, #0x30]
1015ce638:     	adds	x6, x7, x6
1015ce63c:     	b.hs	0x1015ce900 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47a0>
1015ce640:     	ldr	x7, [sp, #0x20]
1015ce644:     	str	x6, [x7, #0x408]
1015ce648:     	ldr	x6, [x7, #0x410]
1015ce64c:     	ldr	x7, [x11, #0x38]
1015ce650:     	adds	x6, x7, x6
1015ce654:     	b.hs	0x1015ce90c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47ac>
1015ce658:     	ldr	x7, [sp, #0x20]
1015ce65c:     	str	x6, [x7, #0x410]
1015ce660:     	ldr	x6, [x7, #0x418]
1015ce664:     	ldr	x7, [x11, #0x40]
1015ce668:     	adds	x6, x7, x6
1015ce66c:     	b.hs	0x1015ce918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47b8>
1015ce670:     	ldr	x7, [sp, #0x20]
1015ce674:     	str	x6, [x7, #0x418]
1015ce678:     	ldr	x6, [x7, #0x420]
1015ce67c:     	ldr	x7, [x11, #0x48]
1015ce680:     	adds	x6, x7, x6
1015ce684:     	b.hs	0x1015ce918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47b8>
1015ce688:     	ldr	x7, [sp, #0x20]
1015ce68c:     	str	x6, [x7, #0x420]
1015ce690:     	ldr	x6, [x7, #0x428]
1015ce694:     	ldr	x7, [x11, #0x50]
1015ce698:     	adds	x6, x7, x6
1015ce69c:     	b.hs	0x1015ce918 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47b8>
1015ce6a0:     	ldr	x7, [sp, #0x20]
1015ce6a4:     	str	x6, [x7, #0x428]
1015ce6a8:     	ldr	x6, [x7, #0x430]
1015ce6ac:     	ldr	x7, [x11, #0x58]
1015ce6b0:     	adds	x6, x7, x6
1015ce6b4:     	b.hs	0x1015ce924 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47c4>
1015ce6b8:     	ldr	x7, [sp, #0x20]
1015ce6bc:     	str	x6, [x7, #0x430]
1015ce6c0:     	b	0x1015ce53c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x43dc>
1015ce6c4:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce6c8:     	add	x8, x8, #0x902
1015ce6cc:     	mov	w9, #0x1d               ; =29
1015ce6d0:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce6d4:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce6d8:     	add	x8, x8, #0x7ff
1015ce6dc:     	mov	w9, #0x1c               ; =28
1015ce6e0:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce6e4:     	stp	xzr, xzr, [x29, #-0xa0]
1015ce6e8:     	mov	w8, #0x8                ; =8
1015ce6ec:     	stp	xzr, x8, [x29, #-0xb0]
1015ce6f0:     	mov	w28, #0x1               ; =1
1015ce6f4:     	ldr	x1, [sp, #0x6d0]
1015ce6f8:     	sub	x0, x29, #0xb0
1015ce6fc:     	bl	0x1014b7850 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE17try_reserve_exactB1h_>
1015ce700:     	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1015ce704:     	cmp	x0, x8
1015ce708:     	b.ne	0x1015ce940 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47e0>
1015ce70c:     	ldur	x8, [x29, #-0xb0]
1015ce710:     	ldr	x9, [sp, #0x6d0]
1015ce714:     	cmp	x8, x9
1015ce718:     	b.ne	0x1015ce950 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47f0>
1015ce71c:     	ldr	x9, [sp, #0x6c8]
1015ce720:     	ldr	x10, [sp, #0x6c0]
1015ce724:     	mov	w11, #0x68              ; =104
1015ce728:     	madd	x22, x8, x11, x9
1015ce72c:     	stp	x9, x9, [x29, #-0x90]
1015ce730:     	stp	x10, x22, [x29, #-0x80]
1015ce734:     	cbz	x8, 0x1015ce7e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4688>
1015ce738:     	add	x24, sp, #0x440
1015ce73c:     	add	x19, x9, #0x68
1015ce740:     	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
1015ce744:     	mov	x26, x19
1015ce748:     	ldr	x8, [x26, #-0x68]!
1015ce74c:     	cmp	x8, x25
1015ce750:     	b.eq	0x1015ce7e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4684>
1015ce754:     	str	x8, [sp, #0x440]
1015ce758:     	ldur	q0, [x26, #0x58]
1015ce75c:     	stur	q0, [x24, #0x58]
1015ce760:     	ldur	q0, [x26, #0x28]
1015ce764:     	stur	q0, [x24, #0x28]
1015ce768:     	ldur	q0, [x26, #0x38]
1015ce76c:     	stur	q0, [x24, #0x38]
1015ce770:     	ldur	q0, [x26, #0x48]
1015ce774:     	stur	q0, [x24, #0x48]
1015ce778:     	ldur	q0, [x26, #0x8]
1015ce77c:     	stur	q0, [x24, #0x8]
1015ce780:     	ldur	q0, [x26, #0x18]
1015ce784:     	stur	q0, [x24, #0x18]
1015ce788:     	ldr	x8, [sp, #0x498]
1015ce78c:     	ldr	x9, [sp, #0x4a0]
1015ce790:     	ldur	q0, [x26, #0x18]
1015ce794:     	str	q0, [sp, #0x220]
1015ce798:     	ldur	q0, [x26, #0x28]
1015ce79c:     	str	q0, [sp, #0x230]
1015ce7a0:     	ldur	q0, [x26, #0x38]
1015ce7a4:     	str	q0, [sp, #0x240]
1015ce7a8:     	ldur	q0, [x26, #0x48]
1015ce7ac:     	str	q0, [sp, #0x250]
1015ce7b0:     	str	x8, [sp, #0x260]
1015ce7b4:     	str	xzr, [sp, #0x268]
1015ce7b8:     	str	x9, [sp, #0x270]
1015ce7bc:     	sub	x0, x29, #0xb0
1015ce7c0:     	add	x1, sp, #0x220
1015ce7c4:     	bl	0x1014b77b4 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE13push_back_mutB1h_>
1015ce7c8:     	add	x0, sp, #0x440
1015ce7cc:     	bl	0x1015aca9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015ce7d0:     	add	x19, x26, #0xd0
1015ce7d4:     	add	x8, x26, #0x68
1015ce7d8:     	cmp	x8, x22
1015ce7dc:     	b.ne	0x1015ce744 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x45e4>
1015ce7e0:     	mov	x19, x22
1015ce7e4:     	stur	x19, [x29, #-0x88]
1015ce7e8:     	mov	w28, #0x0               ; =0
1015ce7ec:     	sub	x0, x29, #0x90
1015ce7f0:     	bl	0x1015e63f4 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
1015ce7f4:     	ldp	q0, q1, [x29, #-0xb0]
1015ce7f8:     	str	q0, [sp, #0x440]
1015ce7fc:     	str	q1, [sp, #0x450]
1015ce800:     	ldur	x24, [x29, #-0xd0]
1015ce804:     	ldr	q0, [sp, #0x680]
1015ce808:     	ldr	q1, [sp, #0x690]
1015ce80c:     	stp	q0, q1, [sp, #0x220]
1015ce810:     	ldr	q0, [sp, #0x6a0]
1015ce814:     	ldr	q1, [sp, #0x6b0]
1015ce818:     	stp	q0, q1, [x29, #-0x90]
1015ce81c:     	ldr	x8, [sp, #0x58]
1015ce820:     	add	x0, x8, #0x3c0
1015ce824:     	bl	0x1015abcb4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
1015ce828:     	ldr	q0, [sp, #0x440]
1015ce82c:     	ldr	q1, [sp, #0x450]
1015ce830:     	ldr	x8, [sp, #0x58]
1015ce834:     	stp	q0, q1, [x8, #0x3c0]
1015ce838:     	ldp	q0, q1, [sp, #0x220]
1015ce83c:     	str	q0, [x8, #0x400]
1015ce840:     	str	q1, [x8, #0x410]
1015ce844:     	ldp	q0, q1, [x29, #-0x90]
1015ce848:     	str	q0, [x8, #0x420]
1015ce84c:     	str	x20, [x8, #0x3e0]
1015ce850:     	str	x20, [x8, #0x3e8]
1015ce854:     	str	x24, [x8, #0x3f0]
1015ce858:     	str	x21, [x8, #0x3f8]
1015ce85c:     	str	q1, [x8, #0x430]
1015ce860:     	mov	w8, #0x1                ; =1
1015ce864:     	dup.2d	v0, x8
1015ce868:     	stur	q0, [x23, #0x8]
1015ce86c:     	mov	w8, #0x6                ; =6
1015ce870:     	str	w8, [x23]
1015ce874:     	mov	w19, #0x0               ; =0
1015ce878:     	mov	w28, #0x0               ; =0
1015ce87c:     	add	x0, sp, #0x720
1015ce880:     	bl	0x1015ada9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015ce884:     	ldr	x8, [sp, #0x708]
1015ce888:     	cbz	x8, 0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015ce88c:     	ldr	x0, [sp, #0x710]
1015ce890:     	lsl	x1, x8, #3
1015ce894:     	mov	w2, #0x8                ; =8
1015ce898:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015ce89c:     	b	0x1015cd7ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x364c>
1015ce8a0:     	mov	x8, x12
1015ce8a4:     	mov	w9, #0x18               ; =24
1015ce8a8:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce8ac:     	mov	x8, x13
1015ce8b0:     	mov	w9, #0x18               ; =24
1015ce8b4:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce8b8:     	mov	x8, x14
1015ce8bc:     	mov	w9, #0x1f               ; =31
1015ce8c0:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce8c4:     	mov	x8, x15
1015ce8c8:     	mov	w9, #0x26               ; =38
1015ce8cc:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce8d0:     	mov	x8, x16
1015ce8d4:     	mov	w9, #0x1f               ; =31
1015ce8d8:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce8dc:     	mov	x8, x17
1015ce8e0:     	mov	w9, #0x1c               ; =28
1015ce8e4:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce8e8:     	mov	x8, x1
1015ce8ec:     	mov	w9, #0x24               ; =36
1015ce8f0:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce8f4:     	mov	x8, x2
1015ce8f8:     	mov	w9, #0x24               ; =36
1015ce8fc:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce900:     	mov	x8, x3
1015ce904:     	mov	w9, #0x1f               ; =31
1015ce908:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce90c:     	mov	x8, x4
1015ce910:     	mov	w9, #0x1d               ; =29
1015ce914:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce918:     	mov	x8, x0
1015ce91c:     	mov	w9, #0x28               ; =40
1015ce920:     	b	0x1015ce92c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47cc>
1015ce924:     	mov	x8, x5
1015ce928:     	mov	w9, #0x21               ; =33
1015ce92c:     	str	wzr, [x23]
1015ce930:     	mov	w10, #0xc               ; =12
1015ce934:     	stp	x10, x8, [x23, #0x8]
1015ce938:     	str	x9, [x23, #0x18]
1015ce93c:     	b	0x1015ce974 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4814>
1015ce940:     	adrp	x8, 0x107556000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.65+0x876>
1015ce944:     	add	x8, x8, #0x81b
1015ce948:     	mov	w9, #0x21               ; =33
1015ce94c:     	b	0x1015ce95c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x47fc>
1015ce950:     	adrp	x8, 0x107559000 <_anon.cbfb9d46cffbe2e2878b0e313e2fedf6.377+0x1b98>
1015ce954:     	add	x8, x8, #0x272
1015ce958:     	mov	w9, #0x30               ; =48
1015ce95c:     	str	wzr, [x23]
1015ce960:     	mov	w10, #0xc               ; =12
1015ce964:     	strb	w10, [x23, #0x8]
1015ce968:     	stp	x8, x9, [x23, #0x10]
1015ce96c:     	sub	x0, x29, #0xb0
1015ce970:     	bl	0x1015ad324 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
1015ce974:     	sub	x0, x29, #0xd0
1015ce978:     	bl	0x1015ac820 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
1015ce97c:     	mov	w19, #0x0               ; =0
1015ce980:     	b	0x1015ce2c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4160>
1015ce984:     	mov	x22, x0
1015ce988:     	mov	w19, #0x0               ; =0
1015ce98c:     	b	0x1015cea74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4914>
1015ce990:     	mov	x22, x0
1015ce994:     	mov	w28, #0x1               ; =1
1015ce998:     	b	0x1015cea2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48cc>
1015ce99c:     	mov	x22, x0
1015ce9a0:     	mov	x23, x28
1015ce9a4:     	b	0x1015cea84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4924>
1015ce9a8:     	mov	x22, x0
1015ce9ac:     	mov	w19, #0x0               ; =0
1015ce9b0:     	mov	w28, #0x0               ; =0
1015ce9b4:     	mov	w23, #0x0               ; =0
1015ce9b8:     	ldr	q0, [sp, #0x440]
1015ce9bc:     	ldr	q1, [sp, #0x450]
1015ce9c0:     	ldr	x8, [sp, #0x58]
1015ce9c4:     	stp	q0, q1, [x8, #0x3c0]
1015ce9c8:     	ldp	q0, q1, [sp, #0x220]
1015ce9cc:     	str	q0, [x8, #0x400]
1015ce9d0:     	str	q1, [x8, #0x410]
1015ce9d4:     	ldp	q0, q1, [x29, #-0x90]
1015ce9d8:     	str	q0, [x8, #0x420]
1015ce9dc:     	str	x20, [x8, #0x3e0]
1015ce9e0:     	str	x20, [x8, #0x3e8]
1015ce9e4:     	str	x24, [x8, #0x3f0]
1015ce9e8:     	str	x21, [x8, #0x3f8]
1015ce9ec:     	str	q1, [x8, #0x430]
1015ce9f0:     	b	0x1015cea7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x491c>
1015ce9f4:     	mov	x22, x0
1015ce9f8:     	b	0x1015cea24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48c4>
1015ce9fc:     	mov	x22, x0
1015cea00:     	stur	x19, [x29, #-0x88]
1015cea04:     	b	0x1015cea18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48b8>
1015cea08:     	mov	x22, x0
1015cea0c:     	stur	x19, [x29, #-0x88]
1015cea10:     	add	x0, sp, #0x440
1015cea14:     	bl	0x1015aca9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015cea18:     	sub	x0, x29, #0x90
1015cea1c:     	bl	0x1015e63f4 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
1015cea20:     	mov	w28, #0x0               ; =0
1015cea24:     	sub	x0, x29, #0xb0
1015cea28:     	bl	0x1015ad324 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
1015cea2c:     	sub	x0, x29, #0xd0
1015cea30:     	bl	0x1015ac820 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
1015cea34:     	mov	w19, #0x0               ; =0
1015cea38:     	b	0x1015cea78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4918>
1015cea3c:     	mov	x22, x0
1015cea40:     	b	0x1015cea70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4910>
1015cea44:     	mov	x22, x0
1015cea48:     	b	0x1015cea70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4910>
1015cea4c:     	b	0x1015ceab4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4954>
1015cea50:     	b	0x1015cead8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4978>
1015cea54:     	mov	x22, x0
1015cea58:     	add	x0, sp, #0x110
1015cea5c:     	bl	0x1015abfa8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
1015cea60:     	b	0x1015cea74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4914>
1015cea64:     	mov	x22, x0
1015cea68:     	add	x0, sp, #0x330
1015cea6c:     	bl	0x1015ae540 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers15NativeWorkGroupECs7fdMCt8k5K6_8mech_gpu>
1015cea70:     	mov	w19, #0x1               ; =1
1015cea74:     	mov	w28, #0x1               ; =1
1015cea78:     	mov	w23, #0x1               ; =1
1015cea7c:     	add	x0, sp, #0x720
1015cea80:     	bl	0x1015ada9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015cea84:     	ldr	x8, [sp, #0x708]
1015cea88:     	cbz	x8, 0x1015cea9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x493c>
1015cea8c:     	ldr	x0, [sp, #0x710]
1015cea90:     	lsl	x1, x8, #3
1015cea94:     	mov	w2, #0x8                ; =8
1015cea98:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1015cea9c:     	tbz	w19, #0x0, 0x1015ceaa8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4948>
1015ceaa0:     	add	x0, sp, #0x6e0
1015ceaa4:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015ceaa8:     	tbnz	w28, #0x0, 0x1015ceae0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4980>
1015ceaac:     	b	0x1015ceae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4988>
1015ceab0:     	b	0x1015ceac8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4968>
1015ceab4:     	mov	x22, x0
1015ceab8:     	add	x0, sp, #0x110
1015ceabc:     	bl	0x1015aca9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
1015ceac0:     	b	0x1015ceacc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x496c>
1015ceac4:     	b	0x1015cead8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4978>
1015ceac8:     	mov	x22, x0
1015ceacc:     	add	x0, sp, #0x220
1015cead0:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cead4:     	b	0x1015ceadc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x497c>
1015cead8:     	mov	x22, x0
1015ceadc:     	mov	w23, #0x1               ; =1
1015ceae0:     	add	x0, sp, #0x6c0
1015ceae4:     	bl	0x1015ac9b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
1015ceae8:     	tbnz	w23, #0x0, 0x1015ceaf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4994>
1015ceaec:     	b	0x1015ceb30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49d0>
1015ceaf0:     	mov	x22, x0
1015ceaf4:     	add	x0, sp, #0x6a0
1015ceaf8:     	bl	0x1015ada9c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
1015ceafc:     	b	0x1015ceb04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49a4>
1015ceb00:     	mov	x22, x0
1015ceb04:     	add	x0, sp, #0x680
1015ceb08:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015ceb0c:     	b	0x1015ceb30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49d0>
1015ceb10:     	mov	x22, x0
1015ceb14:     	add	x1, sp, #0x550
1015ceb18:     	mov	x0, x20
1015ceb1c:     	mov	w2, #0x108              ; =264
1015ceb20:     	bl	0x103a072f8 <dyld_stub_binder+0x103a072f8>
1015ceb24:     	mov	w19, #0x0               ; =0
1015ceb28:     	b	0x1015cebb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a50>
1015ceb2c:     	mov	x22, x0
1015ceb30:     	ldr	x8, [sp, #0x668]
1015ceb34:     	mov	x9, #-0x1               ; =-1
1015ceb38:     	ldaddl	x9, x8, [x8]
1015ceb3c:     	cmp	x8, #0x1
1015ceb40:     	b.ne	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015ceb44:     	dmb	ishld
1015ceb48:     	add	x0, sp, #0x668
1015ceb4c:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ceb50:     	b	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015ceb54:     	mov	x22, x0
1015ceb58:     	ldr	x8, [sp, #0x550]
1015ceb5c:     	mov	x9, #-0x1               ; =-1
1015ceb60:     	ldaddl	x9, x8, [x8]
1015ceb64:     	cmp	x8, #0x1
1015ceb68:     	b.ne	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015ceb6c:     	dmb	ishld
1015ceb70:     	add	x0, sp, #0x550
1015ceb74:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015ceb78:     	b	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015ceb7c:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015ceb80:     	mov	x22, x0
1015ceb84:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1015ceb88:     	str	x8, [x20]
1015ceb8c:     	b	0x1015cebc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a64>
1015ceb90:     	mov	x22, x0
1015ceb94:     	add	x0, sp, #0x440
1015ceb98:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015ceb9c:     	b	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015ceba0:     	mov	x22, x0
1015ceba4:     	tbnz	w19, #0x0, 0x1015cec10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ab0>
1015ceba8:     	b	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015cebac:     	mov	x22, x0
1015cebb0:     	sub	x0, x29, #0x90
1015cebb4:     	bl	0x1015adb14 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015cebb8:     	b	0x1015cebec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a8c>
1015cebbc:     	mov	x22, x0
1015cebc0:     	mov	x23, x24
1015cebc4:     	cbz	w23, 0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015cebc8:     	ldr	x8, [sp, #0x550]
1015cebcc:     	cbz	x8, 0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015cebd0:     	add	x0, sp, #0x550
1015cebd4:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cebd8:     	b	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015cebdc:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015cebe0:     	mov	x22, x0
1015cebe4:     	b	0x1015cec10 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4ab0>
1015cebe8:     	mov	x22, x0
1015cebec:     	ldur	x8, [x29, #-0xb0]
1015cebf0:     	mov	x9, #-0x1               ; =-1
1015cebf4:     	ldaddl	x9, x8, [x8]
1015cebf8:     	cmp	x8, #0x1
1015cebfc:     	b.ne	0x1015cec0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4aac>
1015cec00:     	dmb	ishld
1015cec04:     	sub	x0, x29, #0xb0
1015cec08:     	bl	0x102e1abb4 <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015cec0c:     	tbz	w19, #0x0, 0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015cec10:     	add	x0, sp, #0x220
1015cec14:     	bl	0x1015ae760 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
1015cec18:     	b	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015cec1c:     	mov	x22, x0
1015cec20:     	add	x0, sp, #0x60
1015cec24:     	bl	0x1015add3c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015cec28:     	b	0x1015cec58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4af8>
1015cec2c:     	bl	0x103a05d28 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
1015cec30:     	mov	w8, #0x2                ; =2
1015cec34:     	str	x8, [x20, #0x220]
1015cec38:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
1015cec3c:     	mov	w8, #0x2                ; =2
1015cec40:     	str	x8, [x20, #0x220]
1015cec44:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
1015cec48:     	mov	x22, x0
1015cec4c:     	ldr	w8, [sp, #0x550]
1015cec50:     	cmp	w8, #0x6
1015cec54:     	b.ne	0x1015cec60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4b00>
1015cec58:     	mov	x0, x22
1015cec5c:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
1015cec60:     	add	x0, sp, #0x550
1015cec64:     	bl	0x1015ae63c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
1015cec68:     	mov	x0, x22
1015cec6c:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
