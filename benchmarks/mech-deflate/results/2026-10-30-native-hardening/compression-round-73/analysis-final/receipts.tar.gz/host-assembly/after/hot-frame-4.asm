
/private/tmp/mech-budget-cross-crate-round73-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152e9ec <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>:
10152e9ec:     	ldp	x9, x8, [x0]
10152e9f0:     	cmp	x9, x8
10152e9f4:     	b.eq	0x10152ea6c <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x80>
10152e9f8:     	ldp	x12, x11, [x1]
10152e9fc:     	mov	w13, #0x18              ; =24
10152ea00:     	ldr	x14, [x1, #0x28]
10152ea04:     	b	0x10152ea10 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x24>
10152ea08:     	cmp	x9, x8
10152ea0c:     	b.eq	0x10152ea58 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x6c>
10152ea10:     	mov	x10, x9
10152ea14:     	ldr	w15, [x9], #0x4
10152ea18:     	cmp	x11, x15
10152ea1c:     	b.ls	0x10152ea08 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
10152ea20:     	umaddl	x15, w15, w13, x12
10152ea24:     	ldr	x16, [x15]
10152ea28:     	cmp	x16, #0x1
10152ea2c:     	b.ne	0x10152ea08 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
10152ea30:     	ldp	x16, x15, [x15, #0x8]
10152ea34:     	add	x15, x15, x16
10152ea38:     	cmp	x15, x16
10152ea3c:     	ccmp	x15, x14, #0x2, hs
10152ea40:     	b.hi	0x10152ea08 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
10152ea44:     	mov	w8, #0x1                ; =1
10152ea48:     	add	x9, x10, #0x4
10152ea4c:     	str	x9, [x0]
10152ea50:     	mov	x0, x8
10152ea54:     	ret
10152ea58:     	mov	w8, #0x0                ; =0
10152ea5c:     	add	x9, x10, #0x4
10152ea60:     	str	x9, [x0]
10152ea64:     	mov	x0, x8
10152ea68:     	ret
10152ea6c:     	mov	w0, #0x0                ; =0
10152ea70:     	ret
