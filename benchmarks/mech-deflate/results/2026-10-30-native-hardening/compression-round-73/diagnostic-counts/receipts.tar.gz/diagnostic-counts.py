"""Bounded nonallocating mechanism census; never a performance/allocator cohort.
Only an isolated GPU source copy is instrumented. The accepted Engine/Core and
unchanged same-build compressor Object/image are used. No production file edit.
"""
from pathlib import Path
import difflib,hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=r;p=r/'diagnostic-counts';p.mkdir();stage=p/'source/hosts/gpu';stage.parent.mkdir(parents=True);shutil.copytree(w/'hosts/gpu/src',stage/'src');shutil.copy2(w/'hosts/gpu/Cargo.toml',stage/'Cargo.toml')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
patches=[]
def update(relative,edit):
 f=stage/'src'/relative;s=f.read_text();t=edit(s);assert s!=t,relative;f.write_text(t);patches.extend(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile=relative,tofile=relative));return t
module='''
// ISOLATED DIAGNOSTIC ONLY. Fixed counters, no allocation or permission cache.
pub(in crate::native_artifact) mod diagnostic_counters {
    use core::sync::atomic::{AtomicU64, Ordering};
    static COUNTS: [AtomicU64; 64] = [const { AtomicU64::new(0) }; 64];
    #[inline(always)]
    pub(in crate::native_artifact) fn hit(index: usize) {
        COUNTS[index].fetch_add(1, Ordering::Relaxed);
    }
    pub(in crate::native_artifact) fn helper(operation: u64) {
        let bucket = if operation < 3 { 3 + operation as usize }
            else if operation >= u64::MAX - 28 && operation < u64::MAX {
                7 + (u64::MAX - operation - 1) as usize
            } else { 6 };
        hit(bucket);
    }
    #[unsafe(no_mangle)]
    pub extern "C" fn mech_diagnostic_counts_take(index: usize) -> u64 {
        COUNTS.get(index).map_or(0, |counter| counter.swap(0, Ordering::Relaxed))
    }
}
'''
def work_edit(s):
 needle='''        if let Some(budget) = &self.library {
            return budget
                .charge_compute_with_limit(amount, self.limit)''';assert s.count(needle)==1
 return s.replace(needle,needle.replace('            return budget','            diagnostic_counters::hit(0);\n            return budget'))+module
update('native_artifact/work/mod.rs',work_edit)
path='crate::native_artifact::work::diagnostic_counters'
def hook_edit(s):
 needle='''    let outcome = context
        .visit(site)''';assert s.count(needle)==1;s=s.replace(needle,'    '+path+'::hit(1);\n'+needle)
 needle='''    let outcome = if result.is_null() || result != context.result {''';assert s.count(needle)==1;return s.replace(needle,'    '+path+'::hit(2);\n    '+path+'::helper(operation);\n'+needle)
update('native_artifact/program/runtime/hooks.rs',hook_edit)
def frame_edit(s):
 needles=[('''            Operation::Pack { output } if tag == GlobalHelper::Library => {
''',40),('''            Operation::Copy { source, output } if tag == GlobalHelper::Move && words.is_empty() => {
''',41),('''                let action = descriptor.metadata().plan.blocks()[site].action();
''',42),('''                if layout.children(*field).is_some() {
''',43)]
 for needle,index in needles:
  assert s.count(needle)==1,(index,s.count(needle));s=s.replace(needle,needle+'                '+path+f'::hit({index});\n')
 needle='''                        match &value {
                            super::super::buffer_frames::Field::Managed(value) => call''';assert s.count(needle)==1
 s=s.replace(needle,'''                        match &value {
                            super::super::buffer_frames::Field::Managed(_) => '''+path+'''::hit(45),
                            super::super::buffer_frames::Field::Scalar { .. } => '''+path+'''::hit(44),
                        }
'''+needle)
 return s
update('native_artifact/program/runtime/invocation/buffer_frames.rs',frame_edit)
(p/'diagnostic.patch').write_text(''.join(patches));libs=json.loads((old/'final-libraries.json').read_text());base=json.loads((old/'final-release.json').read_text());cmd=base['command'].copy();cmd[-3]=str(stage/'src/lib.rs');cmd[-1]=str(p/'libmech_gpu.rlib')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':
  name,file=a.split('=',1);target=Path(libs[name]['path']) if name in libs else old/'variants/after/dependency'/Path(file).name;assert target.exists(),target;cmd[i]=name+'='+str(target)
for i in range(len(cmd)-1,0,-1):
 if cmd[i].startswith('dependency=') and cmd[i-1]=='-L':del cmd[i-1:i+1]
cmd[1:1]=['-L','dependency='+str(old/'variants/after/dependency')]
def run(name,command,env=None):
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**(env or {})},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={'command':command,'environment':env or {},'exit':q.returncode,'seconds':time.monotonic()-at,'scope':'Isolated diagnostic only. Instrumented code/timing/instructions/allocator observations are never used for optimization acceptance. Fixed atomic counters count attempts/selected routes; no counter read per loop iteration.'};(p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 if q.returncode:print(q.stdout[-2000:]+q.stderr[-6500:],flush=True)
 q.check_returncode();return q
run('gpu-build',cmd,base['environment'])
# Reuse the exact accepted linked worker and Object, substituting only the
# diagnostic GPU and adding out-of-timer counter reset/read/export.
source_root=r;base=json.loads((source_root/'counters/after/cpu-build.json').read_text());source=(source_root/'counters/after/cpu.rs').read_text();s='''unsafe extern "C" { fn mech_diagnostic_counts_take(index:usize)->u64; }
fn take_mechanism_counts()->[u64;64] { core::array::from_fn(|i| unsafe {mech_diagnostic_counts_take(i)}) }
'''+source
needle='eprintln!("MEASURING {sample}");let cpu_before';assert s.count(needle)==1;s=s.replace(needle,'let _=take_mechanism_counts();'+needle)
needle='let cpu_after=cpu_usage::read();';assert s.count(needle)==1;s=s.replace(needle,needle+'let mechanism_counts=take_mechanism_counts().to_vec();')
needle='serde_json::json!({"instructions":cpu_after.instructions-cpu_before.instructions';assert s.count(needle)==1;s=s.replace(needle,'serde_json::json!({"mechanism_counts":mechanism_counts,"instructions":cpu_after.instructions-cpu_before.instructions')
(p/'worker.rs').write_text(s);cmd=base['command'].copy();cmd[-3]=str(p/'worker.rs');cmd[-1]=str(p/'worker')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern' and a.startswith('mech_gpu='):cmd[i]='mech_gpu='+str(p/'libmech_gpu.rlib')
run('worker-build',cmd)
# Drivers serialize this run after every compiler/control/primary cohort.
assert (r/'DIAGNOSTIC_RUN_ALLOWED').exists(), 'Run this diagnostic only after primary and control cohorts finish'
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [x for x in active if Path(x.strip()).name in {'rustc','cargo','gpu-unit-tests','tests'}]
q=run('run',[str(p/'worker'),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','4'])
all_rows=[json.loads(x) for x in q.stdout.splitlines() if x.startswith('{')];rows=[x for x in all_rows if not x['warmup'] and not x['profile']];assert len(rows)==4
assert all(x['exact_reference'] and x['independent_inflation'] and x['work']==60260219686 and x['capacity']==13 and len(x['mechanism_counts'])==64 for x in rows);assert q.stderr.endswith('CLEANUP bytes=0 nodes=0\n')
counts=rows[0]['mechanism_counts'];assert all(x['mechanism_counts']==counts for x in rows),[x['mechanism_counts'] for x in rows]
labels={0:'shared_compute_debit_attempts',1:'admit_callback_attempts',2:'helper_callback_attempts',3:'helper_Library',4:'helper_Move',5:'helper_Collection',6:'helper_Output',40:'frame_Pack_selected',41:'frame_Copy_selected',42:'frame_Project_selected',43:'frame_Project_composite_child',44:'frame_Project_selected_scalar_word',45:'frame_Project_selected_managed_child'}
high=['WindowPrepare','WindowFinish','StringMapPrepare','StringMapFinish','BorrowedStringsPrepare','BorrowedStringFailure','ClosedTailBegin','ClosedTailEnd','PrefixPause','PrefixBorrowedResume','PrefixTailResume','PrefixScanned','JoinMapPrepare','JoinMapFinish','StructuralObservation','MapOwnerBegin','MapOwnerCall','MapOwnerEnd','MapOwnerSpan','ParallelRun','ParallelTake','ParallelYield','ParallelEnter','FrozenMapCopy','FrozenMapRead','NumericWritePrepare','NumericSegmentBegin','NumericSegmentEnd'];labels.update({7+i:'helper_'+name for i,name in enumerate(high)})
assert sum(counts[3:35])==counts[2]
result={'status':'passed','observations':4,'consistent_per_call_counts':{labels.get(i,str(i)):v for i,v in enumerate(counts) if v},'compiler_source':json.loads((old/'final-release.json').read_text())['source_head'],'instrumented_gpu_sha256':sha(p/'libmech_gpu.rlib'),'worker_sha256':sha(p/'worker'),'patch_sha256':sha(p/'diagnostic.patch'),'production_source_note':'Only a staged copy of current GPU production source is instrumented; the current R73 candidate Engine and frozen Core are linked, with the unchanged compressor Object/image. The current ordinary cross-crate inline edit is included in this diagnostic, which is excluded from performance acceptance.','scope':'Dynamic mechanism counts only. Shared compute-debit attempts count the sole production call site of NativeLibraryWorkBudget::charge_compute_with_limit. Selected frame counts are subsets of helpers, not additive independent work. No retired-instruction attribution or timing gain follows from these counts. All instrumentation excluded from primary/counter/allocator acceptance.'};(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
files=[x for x in p.iterdir() if x.is_file() and x.suffix in {'.json','.rs','.patch','.stdout','.stderr'}]
subprocess.run(['python3',str(r/'archive.py'),'diagnostic-counts',*map(str,files),str(r/'diagnostic-counts.py')],check=True);print(json.dumps(result,indent=2),flush=True)
(p/'worker').unlink();(p/'libmech_gpu.rlib').unlink()
