from pathlib import Path
import hashlib,json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'restore-checks';p.mkdir();rows=[];base=json.loads((r/'engine-parent/build.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
for label,cmd,count in [('budget',[str(r/'engine-parent/engine-tests'),'resident::budget::','--nocapture','--test-threads=1'],108),('planner',[str(r/'engine-parent/engine-tests'),'memory_planner::','--nocapture','--test-threads=1'],22),('memory-runtime',['python3','scripts/check-memory-runtime.py'],None),('format',['cargo','+nightly-2026-03-03','fmt','--all','--','--check'],None),('whitespace',['git','diff','--check'],None)]:
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**base['environment']},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 d={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'restored_head':head,'scope':'Exact restored Budget/test source is byte-identical to the R71 parent unit staging commit7edff4a; reused actual parent Engine executable, not rebuilt or relabeled as candidate code.'}
 if count is not None:
  m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);d['executed_tests']=int(m[1]) if m else None;d['expected_tests']=count;d['binary_sha256']=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
 (p/(label+'.json')).write_text(json.dumps(d,indent=2)+'\n');rows.append(d);print(label,q.returncode,d.get('executed_tests'),flush=True)
 subprocess.run(['python3',str(r/'archive.py'),'restored-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'restore-checks.py'),str(r/'restore.json'),str(r/'decision.json')],check=True)
 q.check_returncode()
 if count is not None:assert d['executed_tests']==count
(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
