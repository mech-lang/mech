from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');d=r/'diagnostics';p=r/'linked';p.mkdir(exist_ok=True);(p/'bin').mkdir(exist_ok=True)
obj=r/'generated-object/object.o';image=r/'generated-object/descriptor.json';meta=json.loads((r/'generated-object/metadata.json').read_text());comparison=json.loads((r/'generated-object/comparison.json').read_text())
for name in ['object.o','descriptor.json','metadata.json']:
 f=r/'generated-object'/name;assert hashlib.sha256(f.read_bytes()).hexdigest()==comparison[name]['sha256']
identity=meta['identity_symbol'];entry=meta['entry_symbol']
external='unsafe extern "C" {\n #[link_name = "'+identity+'"] static LINKED_IDENTITY:[u8; mech_gpu::native_artifact::NATIVE_PROGRAM_LINK_IDENTITY_BYTES];\n #[link_name = "'+entry+'"] fn linked_entry(frame:*mut std::ffi::c_void)->u64;\n}\n'
needle='let jit=JitProgramArtifact::compile_with_limits(&artifact,&catalog,mode.compilation()).unwrap();'
replacement='// SAFETY: the build verifies the SAME unchanged emitted Object, descriptor, bytecode,\n // compiler libraries and allocator before link; symbols live for this entire program.\n let jit=unsafe {mech_gpu::native_artifact::LinkedProgramArtifact::from_build_owned_image(\n include_bytes!("'+str(image)+'"),&catalog,&LINKED_IDENTITY,linked_entry)}.unwrap();'
pins={'object':comparison,'source':{},'scope':'Diagnostic only. Full compressor is linked same-build machine code; two tiny seed/clear helpers retain their original JIT preparation outside the compression boundary. Not runtime-only minimal binary size and not a new primary elapsed comparison.'}
for f in [Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mec'),Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc'),Path('/private/tmp/roc-deflate-repro-20261024/roc-deflate/benchmark/echo-clock/targets/arm64mac/mimalloc.o')]:pins['source'][str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
assert pins['source'][str(Path('/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc'))]=='a2a551911949f8c5fdc64273a43662c2a9c4953b853136c19d196692fdac45a7'
(p/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
def command(name,cmd):
 at=time.monotonic()
 with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'source':'dc77024f29f373f0938695531ab2b7c975bb1e7e','scope':pins['scope']},indent=2)+'\n');q.check_returncode()
 print(name,'COMPLETE',flush=True)
for label in ['cpu','memory']:
 source=(d/(label+'.rs')).read_text();assert source.count(needle)==1
 source=external+source.replace(needle,replacement).replace('"phase":"compiled"','"phase":"linked-compressor-image-restored"')
 f=p/(label+'.rs');f.write_text(source)
 cmd=json.loads((d/(label+'-build.json')).read_text())['command'];cmd[-3]=str(f);cmd[-1]=str(p/'bin'/label);cmd[-3:-3]=['-C','link-arg='+str(obj)]
 command(label+'-build',cmd)
for label,samples in [('cpu',32),('memory',8)]:
 command(label,[str(p/'bin'/label),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc',str(samples)])
 output=(p/(label+'.stdout')).read_text();error=(p/(label+'.stderr')).read_text();rows=[json.loads(line) for line in output.splitlines() if line.startswith('{')]
 assert len(rows)==samples+2 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==44443824446 for x in rows)
 assert error.endswith('CLEANUP bytes=0 nodes=0\n')
 if label=='memory':assert len([line for line in error.splitlines() if line.startswith('ALLOC_PROBE ')])==samples+2
 (p/(label+'-binary.json')).write_text(json.dumps({'sha256':hashlib.sha256((p/'bin'/label).read_bytes()).hexdigest(),'bytes':(p/'bin'/label).stat().st_size},indent=2)+'\n')
 files=[r/'linked.py',p/'pins.json']+[p/(label+suffix) for suffix in ['.rs','.json','.stdout','.stderr','-build.json','-build.stdout','-build.stderr','-binary.json']]
 subprocess.run(['python3',str(r/'archive.py'),'linked-'+label,*map(str,files)],cwd=w,check=True)
