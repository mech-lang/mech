from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');old=Path('/private/tmp/mech-deep-profile-20261030');d=r/'diagnostics';d.mkdir(exist_ok=True);(d/'bin').mkdir(exist_ok=True)
for name in ['usage.c','usage.h','cpu_usage.rs','allocation_profile.c','allocation_profile.h','allocation_profile.rs','usage.o','memory_profile.o']:
 shutil.copy2(old/name,d/name)
for original,target in [('mech_cpu.rs','cpu.rs'),('mech_memory.rs','memory.rs')]:
 s=(old/original).read_text().replace(str(old),str(d))
 if target=='memory.rs':s=s.replace('pinned mimalloc2.1.7; no allocation probe','pinned mimalloc2.1.7; allocation census')
 (d/target).write_text(s)
base=json.loads((r/'primary/current-build.json').read_text());libs=base['libraries']
def command(name,cmd):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 (d/(name+'.stdout')).write_text(q.stdout);(d/(name+'.stderr')).write_text(q.stderr);(d/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at},indent=2)+'\n');q.check_returncode()
for label,source in [('cpu',d/'cpu.rs'),('memory',d/'memory.rs')]:
 cmd=base['command'].copy();cmd[-3]=str(source);cmd[-1]=str(d/'bin'/label);extra=['-C','link-arg='+str(d/'usage.o')]
 if label=='memory':extra+=['-C','link-arg='+str(d/'memory_profile.o')]
 cmd[-3:-3]=extra;command(label+'-build',cmd)
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [x for x in active if Path(x.strip()).name in {'rustc','cargo','tests','gpu-unit-tests','before','after','current','roc-profile'}]
artifact='/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc'
jobs=[('reference-cpu',old/'reference-cpu',['12'],True,32),('cpu-before',old/'mech-cpu-round37',[artifact,'32'],False,34),('cpu-after',d/'bin/cpu',[artifact,'32'],False,34),('reference-memory',old/'reference-memory',['12'],True,32),('memory-before',old/'mech-memory-round37',[artifact,'8'],False,10),('memory-after',d/'bin/memory',[artifact,'8'],False,10)]
for label,binary,args,reference,count in jobs:
 p=d/label;p.mkdir(exist_ok=True);cmd=[str(binary),*args];at=time.monotonic()
 with (p/'run.stdout').open('w') as out,(p/'run.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (p/'run.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'scope':'Diagnostic only; CPU runs use plain pinned allocator, memory runs are separately instrumented. Every elapsed observation excluded from primary comparison.','before_source':'3a54f1a1d64db9eee01db97763a3f95a138db93a','after_source':'dc77024f29f373f0938695531ab2b7c975bb1e7e','libraries_after':libs},indent=2)+'\n')
 stdout=(p/'run.stdout').read_text();stderr=(p/'run.stderr').read_text();q.check_returncode()
 if reference:
  rows=[json.loads(x[12:]) for x in stderr.splitlines() if x.startswith('ALLOC_PROBE ')];assert len(rows)==count and stdout.count('rep\troc-deflate\t')==20000
 else:
  rows=[json.loads(x) for x in stdout.splitlines() if x.startswith('{')];assert len(rows)==count and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 and x['work']==(44443887150 if label.endswith('before') else 44443824446) for x in rows);assert stderr.endswith('CLEANUP bytes=0 nodes=0\n')
 files=[p,r/'diagnostics.py',d/'cpu.rs',d/'memory.rs',d/'cpu_usage.rs',d/'allocation_profile.rs',d/'allocation_profile.c',d/'allocation_profile.h',d/'usage.c',d/'usage.h',d/'cpu-build.json',d/'cpu-build.stdout',d/'cpu-build.stderr',d/'memory-build.json',d/'memory-build.stdout',d/'memory-build.stderr']
 subprocess.run(['python3',str(r/'archive.py'),'diagnostics-'+label,*map(str,files)],cwd=w,check=True)
 print(label,'COMPLETE',len(rows),flush=True)
