#[repr(C)]
#[derive(Clone, Copy, Default)]
pub struct Usage { pub instructions:u64, pub cycles:u64, pub user_ns:u64, pub system_ns:u64, pub rss:u64, pub footprint:u64, pub lifetime_peak:u64, pub pageins:u64 }
unsafe extern "C" { fn bench_read_usage(out:*mut Usage)->i32; }
pub fn read()->Usage { let mut out=Usage::default(); assert_eq!(unsafe { bench_read_usage(&mut out) },0); out }
