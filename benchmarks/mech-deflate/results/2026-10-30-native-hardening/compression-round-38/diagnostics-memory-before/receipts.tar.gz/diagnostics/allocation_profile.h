#ifndef ALLOCATION_PROFILE_H
#define ALLOCATION_PROFILE_H
#include <stddef.h>
#include <stdint.h>
void probe_alloc(void *ptr, size_t requested);
size_t probe_usable(void *ptr);
void probe_realloc(uintptr_t old_address, size_t old_usable, void *ptr, size_t requested);
void probe_free(void *ptr);
void probe_begin(void);
void probe_end(void);
void probe_print(uint64_t sample);
#endif
