#include "usage.h"
#include <libproc.h>
#include <sys/resource.h>
#include <unistd.h>
int bench_read_usage(struct bench_usage *out) {
 struct rusage_info_v4 r={0};
 int code=proc_pid_rusage(getpid(),RUSAGE_INFO_V4,(rusage_info_t *)&r);
 if(code) return code;
 *out=(struct bench_usage){r.ri_instructions,r.ri_cycles,r.ri_user_time,r.ri_system_time,r.ri_resident_size,r.ri_phys_footprint,r.ri_lifetime_max_phys_footprint,r.ri_pageins};
 return 0;
}
