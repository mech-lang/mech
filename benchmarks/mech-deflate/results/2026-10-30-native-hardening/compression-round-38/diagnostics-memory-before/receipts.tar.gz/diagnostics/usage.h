#ifndef BENCH_USAGE_H
#define BENCH_USAGE_H
#include <stdint.h>
struct bench_usage { uint64_t instructions, cycles, user_ns, system_ns, rss, footprint, lifetime_peak, pageins; };
int bench_read_usage(struct bench_usage *out);
#endif
