use std::alloc::{GlobalAlloc, Layout};
#[path = "/private/tmp/mech-linear-restack-20261026/complete-focused/src/pinned_allocator.rs"]
mod pinned;
pub struct TracedMimalloc;
unsafe extern "C" {
    fn probe_alloc(ptr:*mut u8, requested:usize);
    fn probe_usable(ptr:*mut u8)->usize;
    fn probe_realloc(old:usize, old_size:usize, ptr:*mut u8, requested:usize);
    fn probe_free(ptr:*mut u8);
    fn probe_begin();
    fn probe_end();
    fn probe_print(sample:u64);
}
unsafe impl GlobalAlloc for TracedMimalloc {
    unsafe fn alloc(&self, layout:Layout)->*mut u8 { unsafe { let p=pinned::PinnedMimalloc.alloc(layout);probe_alloc(p,layout.size());p } }
    unsafe fn alloc_zeroed(&self, layout:Layout)->*mut u8 { unsafe { let p=pinned::PinnedMimalloc.alloc_zeroed(layout);probe_alloc(p,layout.size());p } }
    unsafe fn realloc(&self, ptr:*mut u8, layout:Layout, size:usize)->*mut u8 { unsafe { let prior=probe_usable(ptr);let p=pinned::PinnedMimalloc.realloc(ptr,layout,size);probe_realloc(ptr as usize,prior,p,size);p } }
    unsafe fn dealloc(&self, ptr:*mut u8, layout:Layout) { unsafe { probe_free(ptr);pinned::PinnedMimalloc.dealloc(ptr,layout); } }
}
pub fn begin() { unsafe { probe_begin() } }
pub fn end() { unsafe { probe_end() } }
pub fn print(sample:u64) { unsafe { probe_print(sample) } }
