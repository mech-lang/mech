from pathlib import Path
import hashlib,json,subprocess,time,statistics
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'preflight';p.mkdir(exist_ok=True)
source=Path('/private/tmp/mech-timing-round.rs');libs=json.loads((r/'libraries.json').read_text());b=json.loads(Path('/private/tmp/mech-action-retirement-round37-20261030/primary/current-build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'after')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern':key=a.split('=')[0];cmd[i]=key+'='+libs[key]['path']
at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True);(p/'build.stdout').write_text(q.stdout);(p/'build.stderr').write_text(q.stderr);(p/'build.json').write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'libraries':libs,'compiler_source':'f64c9e65f26e6fc47cd16c0ea419643712196fbd','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n');q.check_returncode()
active=subprocess.check_output(['ps','-Ao','comm='],text=True).splitlines();assert not [v for v in active if Path(v.strip()).name in {'rustc','cargo','tests','gpu-unit-tests','current','before','after','roc-profile'}]
summary={'scope':'One preliminary pair of complete eight-byte calls; not a confirmed gain. Frozen ownership source f64c9e65f; separate feature repair is not yet rebuilt. No other builds/tests/profiles overlap.','fixed_reference_seconds':.000300,'observations':{}}
for label,binary in [('before',Path('/private/tmp/mech-action-retirement-round37-20261030/primary/current')),('after',p/'after')]:
 cmd=[str(binary),'/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mbc','32'];at=time.monotonic()
 with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,stdout=out,stderr=err)
 (p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'compiler_source':'3a54f1a1d64db9eee01db97763a3f95a138db93a' if label=='before' else 'f64c9e65f26e6fc47cd16c0ea419643712196fbd'},indent=2)+'\n')
 rows=[json.loads(x) for x in (p/(label+'.stdout')).read_text().splitlines() if x.startswith('{')];q.check_returncode();assert len(rows)==34 and all(x['exact_reference'] and x['independent_inflation'] and x['capacity']==13 for x in rows)
 assert (p/(label+'.stderr')).read_text().endswith('CLEANUP bytes=0 nodes=0\n');steady=[x for x in rows if not x['warmup'] and not x['profile']];med=statistics.median(x['seconds'] for x in steady)
 summary['observations'][label]={'median_seconds':med,'multiple_of_fixed_reference':med/.000300,'work':sorted({x['work'] for x in rows}),'steady_calls':len(steady)}
 (p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(label,summary['observations'][label],flush=True)
 subprocess.run(['python3',str(r/'archive.py'),'preflight-'+label,str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(p/(label+'.json')),str(p/'summary.json'),str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(r/'preflight.py')],cwd=w,check=True)
summary['after_over_before']=summary['observations']['after']['median_seconds']/summary['observations']['before']['median_seconds'];(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PRELIMINARY',summary['after_over_before'],flush=True)
