from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'unit';p.mkdir(exist_ok=True)
b=json.loads(Path('/private/tmp/mech-retirement-round36-20261030/final-unit/build.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'gpu-unit-tests')
def command(name,cmd,expected=None):
 at=time.monotonic()
 with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**b.get('environment',{})},stdout=out,stderr=err)
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':b.get('environment',{}),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'compiler_source':'f64c9e65f26e6fc47cd16c0ea419643712196fbd'},indent=2)+'\n')
 print(name,q.returncode,time.monotonic()-at,flush=True)
 if q.returncode:print((p/(name+'.stdout')).read_text()[-5000:]);print((p/(name+'.stderr')).read_text()[-5000:])
 q.check_returncode()
 if expected is not None:assert f'{expected} passed; 0 failed' in (p/(name+'.stdout')).read_text()
command('build',cmd)
for name,args,count in [('runtime',['native_artifact::program::runtime::','--skip','complete_unchanged_knucleotide_body_uses_the_owned_emitted_map'],311),('work-values',['native_artifact::work::','native_artifact::memory::','native_artifact::values::'],31)]:
 command(name,[str(p/'gpu-unit-tests'),*args,'--nocapture','--test-threads=1'],count)
subprocess.run(['python3',str(r/'archive.py'),'unit-qualification',*[str(f) for f in p.iterdir() if f.name!='gpu-unit-tests'],str(r/'unit.py')],cwd=w,check=True)
