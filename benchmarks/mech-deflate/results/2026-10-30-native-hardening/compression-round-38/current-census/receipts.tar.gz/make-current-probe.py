from pathlib import Path
import hashlib,json,os,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');gpu=w/'hosts/gpu/src';p=r/'probe-current';p.mkdir(exist_ok=True)
chosen=['lib.rs','native_artifact/mod.rs','native_artifact/values/mod.rs','native_artifact/program/mod.rs','native_artifact/program/runtime/mod.rs','native_artifact/program/runtime/invocation/mod.rs','native_artifact/program/runtime/buffer_frames.rs']
overrides={gpu/name:p/(name.replace('/','_')) for name in chosen}
records=[]
def adapted(src):
 lines=src.read_text().splitlines(keepends=True);out=[]
 for line in lines:
  match=re.match(r'^(\s*)(?:pub(?:\([^)]*\))?\s+)?mod\s+(\w+)\s*;\s*$',line)
  if not match:out.append(line);continue
  name=match[2];at=None;explicit=None
  for i in range(len(out)-1,max(-1,len(out)-6),-1):
   m=re.match(r'\s*#\[path = "([^"]+)"\]\s*$',out[i])
   if m:at=i;explicit=m[1];break
   if out[i].strip() and not out[i].lstrip().startswith('#'):break
  if explicit:target=(src.parent/explicit).resolve()
  else:
   parent=src.parent if src.name in ['mod.rs','lib.rs'] else src.parent/src.stem
   candidates=[parent/(name+'.rs'),parent/name/'mod.rs'];target=next((x for x in candidates if x.is_file()),None)
   assert target is not None,(src,name,candidates)
  target=overrides.get(target,target);attribute=match[1]+'#[path = "'+str(target)+'"]\n'
  if at is None:out.append(attribute)
  else:out[at]=attribute
  out.append(line)
 text=''.join(out)
 text=re.sub(r'include_(str|bytes)!\("([^"]+)"\)',lambda m:'include_'+m[1]+'!("'+str((src.parent/m[2]).resolve())+'")',text)
 return text

for src,dst in overrides.items():
 text=adapted(src);dst.write_text(text);records.append({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'adapted':str(dst)})

def append(original,text):
 path=overrides[gpu/original];path.write_text(path.read_text()+text)

append('native_artifact/values/mod.rs',r'''
#[cfg(test)]
impl NativeValueArena<'_> {
    pub(in crate::native_artifact) fn probe_current(&self, slot:u32)->Option<&mech_core::Value> {
        self.values.values().get(slot as usize).and_then(Option::as_ref)
    }
    pub(in crate::native_artifact) fn probe_aliases(&self, id:&mech_core::snapshot::FrozenSnapshotIdentity)->Vec<usize> {
        self.values.values().iter().enumerate().filter_map(|(slot,value)|value.as_ref().filter(|v|id.matches(v)).map(|_|slot)).collect()
    }
}
''')
append('native_artifact/program/runtime/buffer_frames.rs',r'''
#[cfg(test)]
impl BufferFrames {
    pub(super) fn probe_aliases(&self,id:&mech_core::snapshot::FrozenSnapshotIdentity)->Vec<usize> {
        self.inner.as_ref().map_or_else(Vec::new,|inner|inner.owners.values().iter().enumerate().filter_map(|(slot,value)|value.as_ref().filter(|v|id.matches(v)).map(|_|slot)).collect())
    }
}
''')
append('native_artifact/program/runtime/invocation/mod.rs',r'''
#[cfg(test)]
impl Invocation<'_, '_, '_> {
    pub(in crate::native_artifact::program::runtime) fn probe_buffer(&self,site:usize)->Option<(mech_core::snapshot::FrozenSnapshotIdentity,usize,serde_json::Value)> {
        let proof=self.descriptor.metadata().unsigned_buffer_calls.get(site)?.as_ref()?;
        let source=proof.source()?;
        let value=self.state.arena.probe_current(source.get())?;
        let ValueData::Matrix(matrix)=value.data() else {return None};
        let (width,len,pointer)=match matrix.elements() {
            mech_core::snapshot::SequenceView::U8(v)=>(1,v.len(),v.as_ptr() as usize),
            mech_core::snapshot::SequenceView::U16(v)=>(2,v.len(),v.as_ptr() as usize),
            mech_core::snapshot::SequenceView::U32(v)=>(4,v.len(),v.as_ptr() as usize),
            mech_core::snapshot::SequenceView::U64(v)=>(8,v.len(),v.as_ptr() as usize),
            _=>return None,
        };
        let capacity=matrix.unsigned_buffer_capacity()?;
        if ![524288,2442056,6002052].contains(&(capacity*width)) {return None;}
        let id=value.frozen_storage_identity();
        let aliases=self.state.buffer_frames.probe_aliases(&id);
        let layout=&self.descriptor.metadata().buffer_frames;
        let frames=(0..self.descriptor.plan().values().len()).filter_map(|v| {
            let fields=layout.fields_at(v)?;
            let matching=fields.iter().enumerate().filter_map(|(ordinal,field)|match field.lane() {
                mech_engine::native_artifact::NativeBufferFrameLane::Managed{at} if aliases.contains(&at)=>Some(ordinal),
                _=>None,
            }).collect::<Vec<_>>();
            (!matching.is_empty()).then_some(serde_json::json!({"value":v,"ordinals":matching}))
        }).collect::<Vec<_>>();
        let action=self.descriptor.plan().blocks()[site].action();
        let metadata=serde_json::json!({"site":site,"source":source.get(),"source_schema":value.schema(),"action":format!("{action:?}"),"origin":self.descriptor.plan().blocks()[site].origin(),"capacity":capacity,"width":width,"length":len,"owned_source_slots":proof.owned_source_slots().iter().map(|v|v.get()).collect::<Vec<_>>(),"arena_aliases_before":self.state.arena.probe_aliases(&id),"frame_aliases_before":aliases,"frames":frames});
        Some((id,pointer,metadata))
    }
    pub(in crate::native_artifact::program::runtime) fn probe_after(&self,site:usize,id:&mech_core::snapshot::FrozenSnapshotIdentity,old_pointer:usize)->serde_json::Value {
        let output=match self.descriptor.plan().blocks()[site].action() {
            NativeIterationAction::LibraryCall{output,..}=>self.state.arena.probe_current(output.get()),
            _=>None,
        };
        let pointer=output.and_then(|v|match v.data() {
            ValueData::Matrix(m)=>match m.elements() {
                mech_core::snapshot::SequenceView::U8(v)=>Some(v.as_ptr() as usize),
                mech_core::snapshot::SequenceView::U16(v)=>Some(v.as_ptr() as usize),
                mech_core::snapshot::SequenceView::U32(v)=>Some(v.as_ptr() as usize),
                mech_core::snapshot::SequenceView::U64(v)=>Some(v.as_ptr() as usize),
                _=>None,
            },_=>None,
        });
        serde_json::json!({"arena_aliases_after":self.state.arena.probe_aliases(id),"frame_aliases_after":self.state.buffer_frames.probe_aliases(id),"output_reuses_backing":pointer==Some(old_pointer),"output_keeps_old_frozen_identity":output.is_some_and(|v|id.matches(v))})
    }
}
''')
append('native_artifact/program/runtime/mod.rs','\n#[cfg(test)]\n#[path = "'+str(p/'probe.rs')+'"]\nmod ownership_probe;\n')

probe=Path('/private/tmp/mech-numeric-composition-round33-20261030/census/probe.rs').read_text()
probe=probe.replace('ready:BTreeMap<(u64,u64,u64),u64>','ready:BTreeMap<(u64,u64,u64),u64>,ownership:Vec<serde_json::Value>')
needle=' let status=match SAVED_HELPER.with(Cell::get) {'
probe=probe.replace(needle,''' // SAFETY: same synchronous invocation context as the original helper; read-only census, no strong owner retained.
 let capture=if operation==crate::native_artifact::program::protocol::GlobalHelper::Library.raw() { unsafe {(&*(raw.cast::<runtime::invocation::Invocation<'_, '_, '_>>())).probe_buffer(site as usize)} } else {None};
'''+needle)
probe=probe.replace(' if status==crate::native_artifact::abi::STATUS_OK', ''' if let Some((identity,pointer,before))=capture {
  // SAFETY: the original synchronous helper has returned; context still lives.
  let after=unsafe {(&*(raw.cast::<runtime::invocation::Invocation<'_, '_, '_>>())).probe_after(site as usize,&identity,pointer)};
  OBS.with(|v|v.borrow_mut().ownership.push(serde_json::json!({"before":before,"after":after,"helper_status":status})));
 }
 if status==crate::native_artifact::abi::STATUS_OK''')
probe=probe.replace('"rows":rows,','"rows":rows,"ownership":obs.ownership,')
probe=probe.replace('/private/tmp/mech-numeric-composition-round33-20261030/census/counts.json',str(p/'counts.json')).replace('fn complete_compressor_private_helper_census','fn complete_compressor_buffer_ownership_census')
probe=probe.replace('48341cf70e20ddd5c2b676d27256b144ea0b99ea','dc77024f29f373f0938695531ab2b7c975bb1e7e').replace('Native parent pieces with single-use child continuation; actual current source hashes are in build receipt','Read-only buffer ownership census; actual current source hashes are in build receipt')
(p/'probe.rs').write_text(probe)
for entry in records:entry['adapted_sha256']=hashlib.sha256(Path(entry['adapted']).read_bytes()).hexdigest()
(p/'adaptation.json').write_text(json.dumps({'method':'Absolute module paths plus test-only read-only weak-identity/slot/backing census; all original maintained function bodies untouched. No strong buffer owner crosses the actual helper. Diagnostic only.','files':records},indent=2)+'\n')
b=json.loads(Path('/private/tmp/mech-action-retirement-round37-20261030/unit/build.json').read_text());b['environment']=json.loads(Path('/private/tmp/mech-retirement-round36-20261030/final-unit/build.json').read_text())['environment'];cmd=b['command'].copy();cmd[-3]=str(overrides[gpu/'lib.rs']);cmd[-1]=str(p/'gpu-unit-tests')
def command(name,cmd,env=None):
 at=time.monotonic()
 with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:q=subprocess.run(cmd,cwd=w,env=env,stdout=out,stderr=err)
 (p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':b.get('environment',{}),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2)+'\n')
 print(name,q.returncode,time.monotonic()-at,flush=True)
 if q.returncode:print((p/(name+'.stderr')).read_text()[-8000:],flush=True)
 q.check_returncode()
command('build',cmd,{**os.environ,**b.get('environment',{})})
command('run',[str(p/'gpu-unit-tests'),'native_artifact::program::runtime::ownership_probe::complete_compressor_buffer_ownership_census','--exact','--nocapture','--test-threads=1'])
assert '1 passed; 0 failed' in (p/'run.stdout').read_text()
assert 'CLEANUP bytes=0 nodes=0' in (p/'run.stderr').read_text()
counts=json.loads((p/'counts.json').read_text());assert counts['ownership']
print('Reached ownership observations',len(counts['ownership']),flush=True)
