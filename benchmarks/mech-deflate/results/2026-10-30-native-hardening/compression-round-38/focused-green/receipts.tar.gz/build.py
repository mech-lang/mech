from pathlib import Path
import json,subprocess,os,time,hashlib,shutil
w=Path('/private/tmp/mech-deflate-linear-stack');r=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-action-retirement-round37-20261030')
b=json.loads((old/'final-release.json').read_text());previous=json.loads((old/'libraries.json').read_text());cmd=b['command'];env=b['environment'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
start=time.monotonic()
with (r/'release.log').open('w') as out,(r/'release.stderr').open('w') as err:q=subprocess.run(cmd,cwd=w,env={**os.environ,**env},stdout=out,stderr=err)
(r/'release.json').write_text(json.dumps({'command':cmd,'environment':env,'head':head,'exit':q.returncode,'seconds':time.monotonic()-start},indent=2)+'\n');print('RELEASE',q.returncode,time.monotonic()-start,flush=True)
if q.returncode:print((r/'release.stderr').read_text()[-6000:],flush=True)
q.check_returncode();rows=[json.loads(x) for x in (r/'release.log').read_text().splitlines() if x.startswith('{')];assert rows[-1]=={'reason':'build-finished','success':True}
libs={};(r/'library').mkdir(exist_ok=True)
for row in rows:
 if row.get('reason')=='compiler-artifact' and row['target']['name'] in previous:
  name=row['target']['name'];files=[Path(x) for x in row['filenames'] if x.endswith('.rlib')];assert len(files)==1
  target=r/'library'/files[0].name;shutil.copy2(files[0],target)
  libs[name]={'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'features':row['features'],'profile':row['profile']}
  assert libs[name]['features']==previous[name]['features'] and libs[name]['profile']==previous[name]['profile'],name
  if name not in {'mech_engine','mech_gpu','mech_stdlib'}:assert libs[name]['sha256']==previous[name]['sha256'],name
assert len(libs)==8
(r/'libraries.json').write_text(json.dumps(libs,indent=2)+'\n');print('FROZEN',{n:libs[n]['sha256'] for n in ['mech_engine','mech_gpu','mech_stdlib']},flush=True)
