from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'static';p.mkdir(exist_ok=True)
files={}
for label,binary in [('reference',Path('/private/tmp/mech-deflate-profiling-20261028/roc-profile')),('linked',r/'linked/bin/cpu')]:
 command=['xcrun','size','-m',str(binary)];at=time.monotonic();q=subprocess.run(command,capture_output=True,text=True);(p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr);q.check_returncode();files[label]={'command':command,'exit':q.returncode,'seconds':time.monotonic()-at,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'file_bytes':binary.stat().st_size}
(p/'commands.json').write_text(json.dumps(files,indent=2)+'\n')
subprocess.run(['python3',str(r/'archive.py'),'static',str(p),str(r/'static.py')],cwd=w,check=True)
