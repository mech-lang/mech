from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'final-components';p.mkdir(exist_ok=True);old=Path('/private/tmp/mech-retirement-round36-20261030/components');b=json.loads((old/'build.json').read_text());libs=json.loads((r/'final-libraries.json').read_text());cmd=b['command'].copy();cmd[-1]=str(p/'tests')
for i,a in enumerate(cmd):
 if i and cmd[i-1]=='--extern' and a.split('=')[0] in libs:cmd[i]=a.split('=')[0]+'='+libs[a.split('=')[0]]['path']
def command(name,cmd,expected):
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,env={**os.environ,**b.get('environment',{})},capture_output=True,text=True)
 (p/(name+'.stdout')).write_text(q.stdout);(p/(name+'.stderr')).write_text(q.stderr);(p/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'environment':b.get('environment',{}),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'libraries':libs},indent=2)+'\n')
 print(name,q.returncode,time.monotonic()-at,flush=True)
 if q.returncode:print(q.stdout[-5000:]);print(q.stderr[-5000:])
 q.check_returncode()
 if expected is not None:assert f'{expected} passed; 0 failed' in q.stdout,q.stdout[-1500:]
command('build',cmd,None)
command('focused',[str(p/'tests'),'sequence_capacity_qualification::reserved_append_recurrence_selects_the_unchanged_path_guard_builder','sequence_capacity_qualification::completed_call_handoff_keeps_future_seed_reads_and_failure_recovery','--nocapture','--test-threads=1'],2)
subprocess.run(['python3',str(r/'archive.py'),'final-focused-green',str(p/'build.json'),str(p/'build.stdout'),str(p/'build.stderr'),str(p/'focused.json'),str(p/'focused.stdout'),str(p/'focused.stderr'),str(r/'final-release.json'),str(r/'final-libraries.json'),str(r/'build-final.py'),str(r/'components-final.py')],cwd=w,check=True)
for name,expected in [('existing',234),('connected',8)]:
 cmd=json.loads((old/(name+'.json')).read_text())['command'].copy();cmd[0]=str(p/'tests');command(name,cmd,expected)
 subprocess.run(['python3',str(r/'archive.py'),'final-components-'+name,str(p/(name+'.json')),str(p/(name+'.stdout')),str(p/(name+'.stderr'))],cwd=w,check=True)
