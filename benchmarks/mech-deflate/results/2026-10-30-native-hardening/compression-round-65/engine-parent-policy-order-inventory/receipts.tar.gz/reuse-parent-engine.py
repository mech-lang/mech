"""Fresh parent Engine test execution; preserve actual historical compilation provenance."""
from pathlib import Path
import hashlib,json,re,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');c=json.loads((r/'configuration.json').read_text());assert c['initialized']
pin=json.loads((r/'baseline/engine-test-binary.json').read_text());binary=Path(pin['path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==pin['sha256'] and binary.stat().st_size==pin['bytes']
assert subprocess.check_output(['git','diff',c['baseline_checkpoint'],'--','src/engine'],cwd=w)==b'','Run unchanged parent witnesses before applying the candidate'
assert subprocess.check_output(['git','rev-parse','HEAD:src/engine'],cwd=w,text=True)==(r/'baseline/engine-source-tree.txt').read_text()
build=json.loads((r/'baseline/engine-test-build.json').read_text());assert build['exit']==0
p=r/'engine-parent';p.mkdir()
reuse={'exit':0,'binary':pin,'baseline_checkpoint':c['baseline_checkpoint'],'current_source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'retained_build_receipt':'baseline/engine-test-build.json','source_tree':(r/'baseline/engine-source-tree.txt').read_text().strip(),'scope':'Pinned unchanged R64 Engine test binary, source tree and successful build receipt verified. No R65 parent compilation occurred. The following inventories and executions are fresh R65 observations.'};(p/'reuse.json').write_text(json.dumps(reuse,indent=2)+'\n')
selections=[('projection',c['engine_projection_filter'],c['engine_projection_expected']),('policy-order','native_projection_meter_keeps_policy_order_after_enclosing_funding',1),('overflow-retry','native_projection_meter_preview_and_charge_keep_compute_node_overflow_atomic',1),('shape','frame_shape::tests::',c['engine_shape_expected'])]
for name,selection,count in selections:
 for inventory in [True,False]:
  stage=name+('-inventory' if inventory else '');cmd=[str(binary),selection,*(['--list'] if inventory else ['--nocapture','--test-threads=1'])];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(stage+'.'+stream)).write_text(getattr(q,stream))
  row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'expected_tests':count,'binary_sha256':pin['sha256'],'retained_build_receipt':'baseline/engine-test-build.json','phase':'parent','baseline_checkpoint':c['baseline_checkpoint'],'scope':'Fresh R65 parent execution of verified unchanged Engine binary; compilation is explicitly attributed to the retained R64 build.'}
  if inventory:row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;observed=row['executed_tests']
  (p/(stage+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  subprocess.run(['python3',str(r/'archive.py'),'engine-parent-'+stage,str(p/(stage+'.json')),str(p/(stage+'.stdout')),str(p/(stage+'.stderr')),str(p/'reuse.json'),str(r/'baseline/engine-test-binary.json'),str(r/'baseline/engine-test-build.json'),str(r/'baseline/engine-source-tree.txt'),str(r/'reuse-parent-engine.py')],cwd=w,check=True)
  print(stage,q.returncode,observed,flush=True)
  if q.returncode:print(q.stdout[-3000:]+q.stderr[-3000:],flush=True)
  q.check_returncode();assert observed==count,row
