"""Root runs only after R64 finishes; capture accepted baseline without old timings."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
r=Path(__file__).resolve().parent;old=Path('/private/tmp/mech-projection-budget-round64-20261031');w=Path('/private/tmp/mech-deflate-linear-stack');c=json.loads((r/'configuration.json').read_text())
assert not c['initialized'],'Never relabel an initialized baseline'
assert len(sys.argv)==2,'Supply the accepted complete R64 checkpoint SHA'
checkpoint=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=w,text=True).strip()
assert json.loads((old/'decision.json').read_text())['status']=='retained','R64 acceptance is pending or rejected'
assert json.loads((old/'validation.json').read_text())['all_required_checks_pass'],'R64 qualification is incomplete'
release=json.loads((old/'final-release.json').read_text());binding=json.loads((old/'linked-primary/after/binding.json').read_text())
assert release['source_head']==binding['compiler_source']
assert subprocess.check_output(['git','diff',release['source_head'],checkpoint,'--','src','hosts/gpu/src'],cwd=w)==b'','Accepted baseline source differs from measured production'
for relative in ['core-focused/core-unit-tests','core-focused/build.json','units-after/gpu-unit-tests','units-after/build.json','engine-after/engine-tests','engine-after/build.json']:
 assert (old/relative).exists(),relative
for name,pin in binding['pins'].items():
 p=old/'linked-primary/after'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256'] and p.stat().st_size==pin['bytes']
assert hashlib.sha256((old/'linked-primary/after/worker').read_bytes()).hexdigest()==binding['worker_sha256']
(r/'variants/before').symlink_to(old/'variants/after',target_is_directory=True);before=r/'linked-primary/before';before.mkdir()
for p in (old/'linked-primary/after').iterdir():
 q=before/p.name
 if p.name in {'object.o','descriptor.json','metadata.json','worker'}:q.symlink_to(p)
 else:shutil.copy2(p,q)
for target,source in [('binding.json','linked-primary/after/binding.json'),('metadata.json','linked-primary/after/metadata.json'),('final-libraries.json','final-libraries.json'),('final-release.json','final-release.json'),('auxiliary-dependencies.json','auxiliary-dependencies.json'),('binary-audit.json','binary-audit.json')]:shutil.copy2(old/source,r/'baseline'/target)
for label in ['before','after']:
 (r/('sites-'+label)).mkdir(exist_ok=True)
 for name in ['allocation_sites.c','allocation_profile.rs','allocation_profile.h','usage.c','usage.h','sites.o','probe-pin.json']:shutil.copy2(old/'sites-after'/name,r/('sites-'+label)/name)
# Only a small census counter is read after the cohort boundary; no measurements run.
counter=json.loads((old/'allocation-observed.json').read_text());target=json.loads((r/'allocation-target.json').read_text())
target.update(baseline_requests=counter['allocation_requests'],baseline_requested_bytes=counter['requested_bytes'],baseline_reallocations=counter['reallocations'])
(r/'allocation-target.json').write_text(json.dumps(target,indent=2)+'\n')
c.update(initialized=True,baseline_checkpoint=checkpoint,baseline_build_source=release['source_head'])
provenance={'round':64,'accepted_checkpoint':checkpoint,'measured_build_source':release['source_head'],'source_note':'Baseline is the completed retained R64 graph and its actual build source, including the completed first-only central projection-budget change. Historical build identity is not replaced with a later report/checkpoint SHA.','binary_note':'R64 fresh emission matched its retained baseline Object/image/metadata byte-for-byte. R65 separately checks fresh emitted-image identity and audits the linked host caller/callee assembly; these are distinct code layers.','receipt_scope':'Historical baseline pins only. No R64 timing or test execution is relabeled as a fresh R65 observation.'}
(r/'baseline/provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
for label,relative in [('core','core-focused/core-unit-tests'),('gpu','units-after/gpu-unit-tests'),('engine','engine-after/engine-tests')]:
 binary=old/relative;assert binary.exists(),binary
 pin={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'bytes':binary.stat().st_size,'source_receipt':str(old/({'core':'core-focused/build.json','gpu':'units-after/build.json','engine':'engine-after/build.json'}[label])),'scope':'R64 test binary reused for fresh R65 baseline test execution only; not a production library rebuild or relabeled historical run.'}
 (r/'baseline'/(label+'-test-binary.json')).write_text(json.dumps(pin,indent=2)+'\n')
 shutil.copy2(pin['source_receipt'],r/'baseline'/(label+'-test-build.json'))
(r/'baseline/engine-source-tree.txt').write_text(subprocess.check_output(['git','rev-parse',checkpoint+':src/engine'],cwd=w,text=True))
(r/'baseline/core-source-tree.txt').write_text(subprocess.check_output(['git','rev-parse',checkpoint+':src/core'],cwd=w,text=True))
(r/'configuration.json').write_text(json.dumps(c,indent=2)+'\n')
print(json.dumps({'accepted_checkpoint':checkpoint,'baseline_build_source':release['source_head'],'baseline_allocation_counter':target},indent=2))
