
/private/tmp/mech-projection-budget-round64-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027080b4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>:
1027080b4:     	sub	sp, sp, #0x70
1027080b8:     	stp	x24, x23, [sp, #0x30]
1027080bc:     	stp	x22, x21, [sp, #0x40]
1027080c0:     	stp	x20, x19, [sp, #0x50]
1027080c4:     	stp	x29, x30, [sp, #0x60]
1027080c8:     	add	x29, sp, #0x60
1027080cc:     	mov	x20, x2
1027080d0:     	mov	x21, x1
1027080d4:     	mov	x22, x0
1027080d8:     	mov	x19, x8
1027080dc:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
1027080e0:     	add	x0, x0, #0x568
1027080e4:     	ldr	x8, [x0]
1027080e8:     	blr	x8
1027080ec:     	mov	x23, x0
1027080f0:     	ldrb	w8, [x0, #0x48]
1027080f4:     	cmp	w8, #0x1
1027080f8:     	b.eq	0x102708128 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x74>
1027080fc:     	cmp	w8, #0x2
102708100:     	b.ne	0x102708110 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x5c>
102708104:     	adrp	x0, 0x10803d000 <_anon.27279621258a66ea37a651666c84bd55.41+0x10>
102708108:     	add	x0, x0, #0xe78
10270810c:     	bl	0x103a01c24 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102708110:     	adrp	x1, 0x102a19000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x410>
102708114:     	add	x1, x1, #0x470
102708118:     	mov	x0, x23
10270811c:     	bl	0x102e6e9ac <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102708120:     	mov	w8, #0x1                ; =1
102708124:     	strb	w8, [x23, #0x48]
102708128:     	ldr	x1, [x22]
10270812c:     	add	x0, sp, #0x8
102708130:     	mov	x2, x23
102708134:     	mov	x3, x21
102708138:     	mov	x4, x20
10270813c:     	bl	0x102707670 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context>
102708140:     	ldrb	w8, [sp, #0x8]
102708144:     	cmp	w8, #0x9
102708148:     	b.eq	0x102708104 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x50>
10270814c:     	ldur	q0, [sp, #0x8]
102708150:     	ldur	q1, [sp, #0x18]
102708154:     	stp	q0, q1, [x19]
102708158:     	ldr	x8, [sp, #0x28]
10270815c:     	str	x8, [x19, #0x20]
102708160:     	ldp	x29, x30, [sp, #0x60]
102708164:     	ldp	x20, x19, [sp, #0x50]
102708168:     	ldp	x22, x21, [sp, #0x40]
10270816c:     	ldp	x24, x23, [sp, #0x30]
102708170:     	add	sp, sp, #0x70
102708174:     	ret
