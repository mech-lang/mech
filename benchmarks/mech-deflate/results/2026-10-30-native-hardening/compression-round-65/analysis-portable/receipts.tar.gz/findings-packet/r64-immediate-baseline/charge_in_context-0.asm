
/private/tmp/mech-projection-budget-round64-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102707670 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context>:
102707670:     	sub	sp, sp, #0x60
102707674:     	stp	x22, x21, [sp, #0x30]
102707678:     	stp	x20, x19, [sp, #0x40]
10270767c:     	stp	x29, x30, [sp, #0x50]
102707680:     	add	x29, sp, #0x50
102707684:     	ldr	x8, [x2, #0x20]
102707688:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10270768c:     	cmp	x8, x9
102707690:     	b.hs	0x1027077d4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x164>
102707694:     	mov	x19, x1
102707698:     	mov	x20, x0
10270769c:     	ldr	x8, [x2, #0x28]
1027076a0:     	cmp	x8, #0x0
1027076a4:     	ccmp	x8, x1, #0x4, ne
1027076a8:     	b.ne	0x102707728 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0xb8>
1027076ac:     	ldr	x8, [x19, #0x10]
1027076b0:     	cbnz	x8, 0x1027077e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x170>
1027076b4:     	mov	x8, #-0x1               ; =-1
1027076b8:     	str	x8, [x19, #0x10]
1027076bc:     	ldr	w8, [x2, #0x30]
1027076c0:     	ldp	x9, x10, [x2, #0x38]
1027076c4:     	ldp	x11, x12, [x19, #0x60]
1027076c8:     	cmp	x9, x11
1027076cc:     	csel	x9, x9, x11, lo
1027076d0:     	cmp	x10, x12
1027076d4:     	csel	x10, x10, x12, lo
1027076d8:     	tst	w8, #0x1
1027076dc:     	csel	x8, x9, x11, ne
1027076e0:     	csel	x12, x10, x12, ne
1027076e4:     	ldr	x9, [x19, #0x38]
1027076e8:     	adds	x21, x9, x3
1027076ec:     	b.hs	0x1027077cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x15c>
1027076f0:     	ldr	x9, [x19, #0x40]
1027076f4:     	adds	x22, x9, x4
1027076f8:     	b.hs	0x1027077cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x15c>
1027076fc:     	ldr	x9, [x19, #0x48]
102707700:     	adds	x9, x9, x21
102707704:     	b.hs	0x1027077cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x15c>
102707708:     	ldr	x10, [x19, #0x50]
10270770c:     	adds	x13, x10, x22
102707710:     	b.hs	0x1027077cc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x15c>
102707714:     	cmp	x9, x8
102707718:     	b.ls	0x102707730 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0xc0>
10270771c:     	mov	w11, #0x6               ; =6
102707720:     	mov	w10, #0x6               ; =6
102707724:     	b	0x102707748 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0xd8>
102707728:     	strb	wzr, [x20]
10270772c:     	b	0x102707768 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0xf8>
102707730:     	cmp	x13, x12
102707734:     	b.ls	0x10270777c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x10c>
102707738:     	mov	w10, #0x6               ; =6
10270773c:     	mov	w11, #0x5               ; =5
102707740:     	mov	x9, x13
102707744:     	mov	x8, x12
102707748:     	strb	w10, [x20]
10270774c:     	strb	w11, [x20, #0x1]
102707750:     	mov	w10, #0x1               ; =1
102707754:     	strb	w10, [x20, #0x2]
102707758:     	stp	x9, x8, [x20, #0x8]
10270775c:     	ldr	x8, [x19, #0x10]
102707760:     	add	x8, x8, #0x1
102707764:     	str	x8, [x19, #0x10]
102707768:     	ldp	x29, x30, [sp, #0x50]
10270776c:     	ldp	x20, x19, [sp, #0x40]
102707770:     	ldp	x22, x21, [sp, #0x30]
102707774:     	add	sp, sp, #0x60
102707778:     	ret
10270777c:     	mov	x0, x19
102707780:     	ldr	x8, [x0, #0x70]!
102707784:     	cbz	x8, 0x1027077a4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x134>
102707788:     	add	x8, sp, #0x8
10270778c:     	mov	x1, x3
102707790:     	mov	x2, x4
102707794:     	bl	0x102453e98 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102707798:     	ldrb	w8, [sp, #0x8]
10270779c:     	cmp	w8, #0x8
1027077a0:     	b.ne	0x1027077b4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0x144>
1027077a4:     	stp	x21, x22, [x19, #0x38]
1027077a8:     	mov	w8, #0x8                ; =8
1027077ac:     	strb	w8, [x20]
1027077b0:     	b	0x10270775c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0xec>
1027077b4:     	ldur	q0, [sp, #0x8]
1027077b8:     	ldur	q1, [sp, #0x18]
1027077bc:     	stp	q0, q1, [x20]
1027077c0:     	ldr	x8, [sp, #0x28]
1027077c4:     	str	x8, [x20, #0x20]
1027077c8:     	b	0x10270775c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0xec>
1027077cc:     	mov	w10, #0x2               ; =2
1027077d0:     	b	0x102707748 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context+0xd8>
1027077d4:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
1027077d8:     	add	x0, x0, #0x4f0
1027077dc:     	bl	0x103a022d8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1027077e0:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
1027077e4:     	add	x0, x0, #0x508
1027077e8:     	bl	0x103a022a8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1027077ec:     	ldr	x8, [x19, #0x10]
1027077f0:     	add	x8, x8, #0x1
1027077f4:     	str	x8, [x19, #0x10]
1027077f8:     	bl	0x103a037a0 <dyld_stub_binder+0x103a037a0>
