# Large-buffer initialization audit

Source-only audit, 2026-10-31. No production changes, builds, compressor runs, census parsing or binary disassembly were performed. This does not establish a new timing win.

## Result

No source-level initialization mismatch: both implementations fully zero the matchfinder tree and match cache; both reserve an empty path buffer and initialize path elements only as appended. The previously known Mech extra buffer requests must not be described as zeroing their entire reserved capacity.

| Buffer | Capacity in elements | Initial logical length | Initial payload initialized by both programs | Reserved payload bytes |
| --- | ---: | ---: | ---: | ---: |
| U16 matchfinder tree | 262144 | 262144 | 524288 bytes, all zero | 524288 |
| U32 match cache | 1500513 | 1500513 | 6002052 bytes, all zero | 6002052 |
| U64 path nodes | 305257 | 0 | 0 bytes | 2442056 |

The two zero-filled payloads total 6,526,340 bytes. For an eight-byte block, a path pass appends 257 guard words (0x80000000), one end word (0), and eight computed path words: length 266 / 2,128 initialized bytes at completion. Clear resets the logical length while preserving requested capacity; it does not semantically initialize 305257 words. Repeat passes overwrite only the appended words.

## Exact source provenance

The cleaned reference directory no longer contains the original tracked source or a usable Git repository. The 57 KiB archived `benchmarks/mech-deflate/results/2026-10-29-native-hardening/compression-round-14/qualification/recovered-reference-source.tar.gz` contains all fourteen pinned files. Every file hash was independently compared to `benchmarks/mech-deflate/results/2026-10-28-compressor-comparison/build.json` and matched revision `671077457ff7ef3a3d44caf715a3fc595addf379`. See source-pins.json. Four relevant files were copied to this scratch packet for review; no reference working tree was modified.

The actual measured Mech program is `/private/tmp/mech-linear-restack-20261026/complete-compressor-borrowed-caller.mec`, SHA-256 `331e659e92181d803b3d87218effe88f711c2e8ecad9f31838fc50991de1c5c9` (verified). It is the maintained caller-buffer variant, not the fixture entry that reserves 6,633,832 output bytes. The measured harness seeds capacity 13 and clears/reuses it outside evaluate_into.

Pinned reference locations:
- Matchfinder.roc:34–36: init_nodes is List.repeat(0.U16, num_entries).
- BtMatchfinder.roc:24–51: 65536 children + 65536 hash4 heads + 131072 hash3 heads = 262144.
- CompressOptimal.roc:52–64: match cache is 1500000 + (258-3+1) + 258 - 1 = 1500513.
- CompressOptimal.roc:72–76: optimum node capacity = soft block limit + minimum block length - 1 + 258 = 305257 (the value used by the pinned Mech source and retained qualification).
- CompressOptimal.roc:714–720: actual compress initialization is init_nodes, List.repeat U32, then List.with_capacity U64.
- CompressOptimal.roc:429–439 and 503: clear, guard append, end append, one computed append per block position.

Measured Mech locations:
- complete-compressor-borrowed-caller.mec:74–75: initial-nodes emits count U16 zeroes.
- :1902–1904: real tree, zero cache, capacity-only path creation.
- :732–742: path clear, guard append, zero end word, scan.

## Maintained native execution path

`hosts/gpu/src/native_artifact/program/runtime/collections/uniform_words.rs` checks the exact same-plan pure unsigned collection, current fresh range/builder, current word width, finite work/space eligibility and reservations. It performs one `builder.values.reserve(host_count)` followed by one `fill_unsigned(host_count, kind, word)`; it does not execute the ordinary interpreted per-element CFG when this proved path is selected. Allocation failure is not swallowed. A failed eligibility probe retains the ordinary path and first-error behavior.

`hosts/gpu/src/native_artifact/program/runtime/collections/data.rs:110–134` checks empty length and exact admitted capacity, then uses the concrete packed Vec<U16>/Vec<U32>/Vec<U64>::resize. Thus zero tree/cache creation writes the full intended typed payload once through this constructor; it does not construct ValueDataDraft per element. The R62 retained CPU samples include 36 exclusive weights in CollectedValues::fill_unsigned, confirming the host fill path executes. Sampling weights are not retired instruction counts and do not prove how LLVM lowered the fill loop.

`src/engine/src/intrinsics/sequence_buffers.rs:273` gives WithCapacity length 0. Its copy_buffer_with_sublist at :392 starts Vec::new plus try_reserve_exact; with no source and no append, it performs no element initialization. The same routine skips copying source elements for Clear. In the consuming path, native_collection_unsigned_buffers.rs mutate uses Vec::clear. Fallback appends use extend_from_slice of the source initialized slice, never the spare capacity. Capacity reservation and payload initialization therefore have distinct costs.

The known R56 path histogram of 35 reservations (one initial, 32 fallback appends, two clears) totals 85,471,960 requested bytes, but the 32 append source lengths 258–265, each four times, copy only 66,944 initialized bytes; clears copy no elements. Those are retained earlier mechanism counts, not a new R64 observation. Four extra full U16 copies account for another 2,097,152 copied bytes. Their alias/ownership limitation remains real but is an already-identified target.

## What remains unproved

No retained host disassembly for CollectedValues::fill_unsigned was located. It is a linked Rust host function, so the generated Mech Object alone cannot show its actual SIMD/memset/bzero lowering. Vec::resize is the verified source mechanism. A later bounded audit of that single linked-worker function can determine whether U16/U32 zero fills use a vector loop or a library fill; do not claim a missing memset or a new optimization before that evidence. R64 cohorts were left undisturbed.

No recommendation to omit zero initialization is justified: both pinned programs explicitly request it. No source/algorithm/allocation-site change is proposed.
