# Immediate R64 baseline confirmation

Worker: `/private/tmp/mech-projection-budget-round64-20261031/linked-primary/after/worker`.

SHA-256: `343d1ccefa8e9735616b62ce48f8e0c99d34baf6ecc75a6a098b59b907afec3e`.

Actual bounded disassembly confirms the R65 target remains after R64. Function starts/counts are unchanged: compute-ceiling wrapper `0x102707ce0` / 73 instructions, outlined `charge_in_context` `0x102707670` / 99, generic charge wrapper `0x1027080b4` / 49. Both wrapper and helper still reserve 96-byte frames.

The duplicated current compute load/add, generic checked comparison addition despite caller delta zero, outlined helper call, and 40-byte post-call Result transport remain at the exact R63 addresses. `success-path.json` re-extracts the current R64 instructions and verifies the same explicitly qualified ordinary successful path: 40 wrapper + 60 callee instructions, excluding TLS function execution. This remains a static specified-path count, not an observed dynamic average.

Full functions are not byte-identical: cold panic targets and TLS destructor initialization addresses relocated. `versus-r63.json` retains every changed decoded instruction. An initial whole-function identity assertion rejected those relocated differences; the corrected comparison checks the actual successful path while retaining the full differences. No compiler, tests, benchmark or compressor was run by this audit.

Exact symbol, disassembly and size commands plus static opcode counts are in `audit.json`; original tool outputs are the `.asm` and size files. This is the immediate host baseline for the separate attribute-only R65 experiment, not R63 reused as a substitute.
