# R65 candidate: inline the existing checked-debit helper

Production scope: `force-inline-debit.patch` changes one attribute in `src/engine/src/resident/budget.rs`. No accounting or TLS source changes. This is separate from R64's two first-violation API substitutions.

## Provenance and machine checks

1. After R64 cohorts finish, run `audit-current-debit.py` on the retained R64 `linked-primary/after/worker`, recording SHA and commands. Check whether the outlined helper, caller's zero comparison delta, duplicate current compute load/add, two stack frames and Result copy remain. R63 evidence is in `r63-debit-object/`, but R64 must be the immediate baseline.
2. Apply the attribute-only patch, rebuild with exactly R64's compiler/profile/dependencies, and run the same audit on the candidate host. Retain both raw disassemblies. Count host text with the same Mach-O size tool for both workers. Record generated Object/descriptor/bytecode hashes separately; expect them unchanged.
3. Materialized checks: does the compute-ceiling wrapper still call `charge_in_context`? Does it still have the independent checked comparison add for delta zero? Is the 40-byte stack-result transport removed? How many stack-frame bytes and static success-path instructions remain? Are both used.compute loads/adds still present across TLS? Report each observed outcome independently rather than requiring all predictions to succeed. A missing named callee alone does not prove its cost disappeared.
4. Count changes in both direct source callers (`NativeLibraryWorkBudget::charge`, `charge_compute_with_limit`). The generic charge caller may grow because it must retain comparison handling. Keep whole host text/worker bytes and generated text/stack distinct.

## Semantic qualification

Run existing `native_artifact::work::tests::` (12 source tests; establish actual inventory) at parent and candidate. The exact error-order acceptance is `native_ceiling_and_overflow_precede_foreign_account_and_library_caps`: caller overflow/ceiling before foreign-account rejection, tightened library cap afterward, unchanged work on failure and successful retry.

Run Engine native-library-work and worker-budget controls for nested scopes, unwind restoration, account identity, shared-worker atomic funding, reserved credits, retained spent prefixes and zero final memory. Reuse the R64 12-test projection module because it exercises the same maintained meter alongside the wrapper; keep R63's six shape regressions. Existing original/decoded, linked complete compression, finite-budget error-prefix, publication/recovery and architecture checks remain unchanged.

An attribute-only change does not need a second implementation of its checks in a new test. If a later follow-up changes how precomputed totals are supplied, add a targeted test through this public compute-ceiling entry under worker/shared-credit denial before proceeding.

## Measurement and decision

Keep the full eight-byte compression and reference cohort, exact output, allocations, source/bytecode pins, logical work 60,260,219,686, comparison work 47,612, allocator and evaluate_into boundaries. Run isolated matched elapsed and independent instruction/cycle/allocation cohorts. A host-only optimization may leave allocation totals and generated Object unchanged; those are controls, not failures. Retain contrary pairs or code-size growth. Report timing as multiples of the pinned reference and change versus the immediately preceding baseline.

Do not count the R62 23 TLS samples as removable by this change: TLS source is unchanged. The 40+60 ordinary-path static instructions are a concrete baseline path, not a prediction of the dynamic savings. Accept or reject based on actual machine changes and measurements, not the inline directive itself.
