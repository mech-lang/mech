# Residual immutable schema encoding after R59

Read-only source/census finding. No implementation, build or timing performed.

R62 still contains 148 schema-encoding allocation requests / 4,893 requested bytes. This is what remains after R59 eliminated the separate 600-request frame-composition family. Current mutually exclusive first-Engine-ancestor partition:

| Caller | Requests | Mechanism |
| --- | ---: | --- |
| native_collection_calls::layout | 66 | Re-encode Schema::key while constructing current input/output layouts. |
| live::footprint_impl | 66 | Re-encode descriptor.schema().canonical_bytes merely to read its length. |
| unsigned_buffer_with_sublist no-op closure | 16 | Re-encode the exact selected output key despite NativePreparedLibraryCall.output_key already retaining it. |

These counts are requests, not function-call counts. They overlap the broader existing generic-binding family and must not be added to that family as independent totals.

## Immediate one-line patch: 16 requests

`residual-output-key.patch` substitutes self.output_key at the existing zero-count AppendLeBytes/AppendSublist identity check. Preparation derives that key from precisely self.template.output().key(); the build-owned image loader independently checks the serialized key against the selected template. Both fields are private immutable metadata. The check still compares the current source key and exact output schema ID at the same position, and all validation, accounting, ownership, geometry and output admission remain unchanged. No new cache or authority is introduced.

Existing acceptance tests: `sequence_buffer_contract::native_bulk_byte_append_current_counts_and_real_capacity_identity` covers current count 0, invalid 9, recovery and backing identity; `native_sublist_append_cached_ranges_rebind_and_recover` covers original/decoded artifacts and sublist behavior. Preserve strict image key validation. Verify this exact 16-request family disappears in the complete-call census; elapsed/instructions remain independent acceptance decisions. This is a small allocation cleanup, not a predicted large speedup.

## Larger residuals need an explicit immutable certificate

`layout` already receives an exact schema and its table ID indirectly through bind_current. Passing the existing SchemaEntry key is safe only once its schema body is known to be the same selected template body; do not use an arbitrary same-ID entry from a foreign table. One semantics-preserving fallback is cached entry key only if entry.schema() == schema, otherwise retain schema.key(). This adds no new error or validation order. Prefer passing prepared immutable keys when the same-template relationship is already guaranteed.

`live::footprint_impl` currently accepts a ResolvedValueDescriptor without an ID and must retain exact descriptor schema bytes even for an empty prior output. The input data memo already has immutable header bytes on cached paths, but these census calls are the uncached fallback. Do not take the first current value's schema bytes before validating its contract, and do not scan the whole table for a body match. The bounded change should pass the current bound port's already-established immutable schema byte count through the existing measurement boundary, separately from per-visit payload measurement. No actual payload summary, admission permission or old account may be reused. Preserve compute charges based on the current retained arena and the original first-failing prefix.
