# Move the sole bound-call owner on the unsealed path

Source audit only; scratch patch not applied or compiled. Production file: `src/engine/src/resident/native_semantics.rs`, `bind_call`.

## Mechanism and prediction

After evaluating all candidate checks, the current code always performs `bound_call.clone()`. A second owner is needed only when a private scalar `SealedWitness` is attached. On the uncertified path the original owner is dropped immediately; the deep clone remains in the kernel. Move that original into the kernel instead.

R62 complete-call census contains exactly 72 requests / 5,404 requested bytes under `native_semantics::bind_call +780`, all from this BoundCall clone. Generated return offsets split 24 requests at +80624 and 48 at +80836. The saved `attribution.json` retains every matching stack and the census SHA-256. These calls construct the seed record and singleton matrix, neither of which is a scalar candidate. The prediction is disappearance of this entire 72-request family, with no change to allocation sites in the source program, work, geometry, published outputs or managed ownership.

This is separate from the previously prepared 149-request owned turn-plan refinement fix. Do not add overlapping metadata-family totals to either count. No elapsed improvement is established yet; this is a small exact construction removal.

## Patch invariants

- Candidate type lookup, exact request/parameter comparison, `scalar_request`, and `bound_call_matches` remain byte-for-byte in the same order.
- Only after those checks, retain the Copy `NativeScalarSemantics` rather than cloning CandidateWitness's contract/layout/parameter metadata.
- Certified path still retains two exact BoundCall owners, clears the old lowering witness with `with_bound_call`, restores the original work-accounting classification, and installs the same private SealedWitness containing the original call.
- Uncertified path still calls `with_bound_call`, clearing any old candidate/public attachment, and restores the same work-accounting classification. It simply transfers the single owned call.
- CandidateWitness contains immutable metadata only. Dropping its cloned copy is not a debit/refund or admission transition; no managed account reservation, live owner, mutable cache or execution permit lives there. The original witness is still cleared by `with_bound_call` at the same semantic point.
- Public APIs, struct layouts, metadata admission envelopes, finite-limit checks, current arguments, bound factory, execution and canonical artifact/image bytes are unchanged.

## Focused acceptance

1. Inventory and run the existing `resident::native_semantics::tests` with the exact full retained Engine unit feature profile and warnings-as-errors. Source currently contains nine tests with feature gates; report observed count, do not assume the gates.
2. Preserve existing positive scalar seal coverage, exact-request mismatch rejection, changed semantic/cost metadata rejection, custom same-name replacement rejection, and uncertified operation behavior.
3. Add or extend a narrow assertion if needed: after both successful sealing and no-candidate binding, `kernel.bound_call()` equals the input call and `kernel.work_accounting()` equals the pre-attachment classification. Existing selected-call component qualification exercises actual canonical seed construction.
4. Replay original/decoded artifact qualification and finite/error/recovery controls unchanged. No new allowances and no test-value changes.
5. Build/link using frozen dependencies as for R63. Run the same eight-byte complete compression, four elapsed pairs, separate instructions/cycles, and full allocation census.
6. Verify disappearance of exactly the bind_call+780 subtree; other sites unchanged except known compiler layout effects. Compare successful bytes and inflate, work/comparison pins, final managed bytes/nodes zero, source and bytecode hashes. A candidate validation miss must still follow the uncertified branch and never preserve an old seal.
7. Record allocator/instruction effects independently of elapsed. Keep contrary pairs and do not claim a timing win from the 72-request prediction.
