"""Bounded actual host disassembly, only after all timed/diagnostic cohorts finish."""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;p=r/'host-assembly';p.mkdir()
for label in ['before','after']:
 binding=json.loads((r/'linked-primary'/label/'binding.json').read_text());worker=r/'linked-primary'/label/'worker'
 assert hashlib.sha256(worker.read_bytes()).hexdigest()==binding['worker_sha256']
 cmd=[sys.executable,str(r/'findings-packet/audit-current-debit.py'),str(worker),str(p/label)];q=subprocess.run(cmd,capture_output=True,text=True)
 (p/(label+'.stdout')).write_text(q.stdout);(p/(label+'.stderr')).write_text(q.stderr);(p/(label+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'compiler_source':binding['compiler_source'],'worker_sha256':binding['worker_sha256'],'scope':'Post-cohort bounded static host audit, not execution or dynamic instruction attribution.'},indent=2)+'\n')
 subprocess.run([sys.executable,str(r/'archive.py'),'host-assembly-'+label,str(p),str(r/'host-assembly.py'),str(r/'findings-packet/audit-current-debit.py')],check=True)
 q.check_returncode();audit=json.loads((p/label/'audit.json').read_text());assert audit['worker_sha256']==binding['worker_sha256'] and audit['size_exit']==0 and all(x['exit']==0 and x['static_instruction_count']>0 for x in audit['regions'])
 assert any(x['needle']=='charge_compute_with_limit' for x in audit['regions']),'Need actual caller assembly; missing helper alone proves nothing'
subprocess.run([sys.executable,str(r/'host_analysis.py'),str(r),str(r/'host-assembly-comparison.json')],check=True)
subprocess.run([sys.executable,str(r/'archive.py'),'host-assembly-summary',str(r/'host-assembly-comparison.json'),str(r/'host_analysis.py')],check=True)
