
/private/tmp/mech-inline-debit-round65-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102706e08 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>:
102706e08:     	sub	sp, sp, #0x80
102706e0c:     	stp	x22, x21, [sp, #0x50]
102706e10:     	stp	x20, x19, [sp, #0x60]
102706e14:     	stp	x29, x30, [sp, #0x70]
102706e18:     	add	x29, sp, #0x70
102706e1c:     	mov	x20, x0
102706e20:     	mov	x19, x8
102706e24:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
102706e28:     	add	x0, x0, #0x568
102706e2c:     	ldr	x8, [x0]
102706e30:     	blr	x8
102706e34:     	ldrb	w8, [x0, #0x48]
102706e38:     	cmp	w8, #0x1
102706e3c:     	b.eq	0x102706e84 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x7c>
102706e40:     	cmp	w8, #0x2
102706e44:     	b.ne	0x102706e54 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x4c>
102706e48:     	adrp	x0, 0x10803d000 <_anon.27279621258a66ea37a651666c84bd55.41+0x10>
102706e4c:     	add	x0, x0, #0xe78
102706e50:     	bl	0x103a005a4 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102706e54:     	adrp	x8, 0x102a17000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy5_EB8_+0x4f0>
102706e58:     	add	x8, x8, #0xed0
102706e5c:     	str	x0, [sp, #0x8]
102706e60:     	mov	x21, x1
102706e64:     	mov	x1, x8
102706e68:     	mov	x22, x2
102706e6c:     	bl	0x102e6d354 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102706e70:     	ldr	x0, [sp, #0x8]
102706e74:     	mov	x1, x21
102706e78:     	mov	x2, x22
102706e7c:     	mov	w8, #0x1                ; =1
102706e80:     	strb	w8, [x0, #0x48]
102706e84:     	ldr	x8, [x0, #0x20]
102706e88:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102706e8c:     	cmp	x8, x9
102706e90:     	b.hs	0x102706ff4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x1ec>
102706e94:     	ldr	x8, [x0, #0x28]
102706e98:     	ldr	x20, [x20]
102706e9c:     	cmp	x8, #0x0
102706ea0:     	ccmp	x8, x20, #0x4, ne
102706ea4:     	b.ne	0x102706f28 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x120>
102706ea8:     	ldr	x8, [x20, #0x10]
102706eac:     	cbnz	x8, 0x102707000 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x1f8>
102706eb0:     	mov	x8, #-0x1               ; =-1
102706eb4:     	str	x8, [x20, #0x10]
102706eb8:     	ldr	w8, [x0, #0x30]
102706ebc:     	ldp	x9, x10, [x0, #0x38]
102706ec0:     	ldp	x11, x12, [x20, #0x60]
102706ec4:     	cmp	x9, x11
102706ec8:     	csel	x9, x9, x11, lo
102706ecc:     	cmp	x10, x12
102706ed0:     	csel	x10, x10, x12, lo
102706ed4:     	tst	w8, #0x1
102706ed8:     	csel	x9, x9, x11, ne
102706edc:     	csel	x13, x10, x12, ne
102706ee0:     	ldr	x8, [x20, #0x38]
102706ee4:     	adds	x21, x8, x1
102706ee8:     	b.hs	0x102706fe8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x1e0>
102706eec:     	ldr	x8, [x20, #0x40]
102706ef0:     	adds	x22, x8, x2
102706ef4:     	b.hs	0x102706fe8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x1e0>
102706ef8:     	ldr	x8, [x20, #0x48]
102706efc:     	adds	x10, x8, x21
102706f00:     	b.hs	0x102706fe8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x1e0>
102706f04:     	ldr	x8, [x20, #0x50]
102706f08:     	adds	x14, x8, x22
102706f0c:     	b.hs	0x102706fe8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x1e0>
102706f10:     	cmp	x10, x9
102706f14:     	b.ls	0x102706f30 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x128>
102706f18:     	mov	w12, #0x6               ; =6
102706f1c:     	mov	w11, #0x1               ; =1
102706f20:     	mov	w8, #0x6                ; =6
102706f24:     	b	0x102706fa0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x198>
102706f28:     	mov	w8, #0x0                ; =0
102706f2c:     	b	0x102706fac <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x1a4>
102706f30:     	cmp	x14, x13
102706f34:     	b.ls	0x102706f50 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x148>
102706f38:     	mov	w8, #0x6                ; =6
102706f3c:     	mov	w12, #0x5               ; =5
102706f40:     	mov	w11, #0x1               ; =1
102706f44:     	mov	x9, x13
102706f48:     	mov	x10, x14
102706f4c:     	b	0x102706fa0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x198>
102706f50:     	mov	x0, x20
102706f54:     	ldr	x8, [x0, #0x70]!
102706f58:     	cbz	x8, 0x102706f70 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x168>
102706f5c:     	add	x8, sp, #0x28
102706f60:     	bl	0x102453c90 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102706f64:     	ldrb	w8, [sp, #0x28]
102706f68:     	cmp	w8, #0x8
102706f6c:     	b.ne	0x102706f7c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x174>
102706f70:     	stp	x21, x22, [x20, #0x38]
102706f74:     	mov	w8, #0x8                ; =8
102706f78:     	b	0x102706fa0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x198>
102706f7c:     	ldrb	w12, [sp, #0x29]
102706f80:     	ldrb	w11, [sp, #0x2a]
102706f84:     	ldur	w9, [sp, #0x2b]
102706f88:     	str	w9, [sp, #0x20]
102706f8c:     	ldrb	w9, [sp, #0x2f]
102706f90:     	strb	w9, [sp, #0x24]
102706f94:     	ldp	x10, x9, [sp, #0x30]
102706f98:     	ldur	q0, [sp, #0x40]
102706f9c:     	str	q0, [sp, #0x10]
102706fa0:     	ldr	x13, [x20, #0x10]
102706fa4:     	add	x13, x13, #0x1
102706fa8:     	str	x13, [x20, #0x10]
102706fac:     	strb	w8, [x19]
102706fb0:     	strb	w12, [x19, #0x1]
102706fb4:     	strb	w11, [x19, #0x2]
102706fb8:     	ldr	w8, [sp, #0x20]
102706fbc:     	stur	w8, [x19, #0x3]
102706fc0:     	ldrb	w8, [sp, #0x24]
102706fc4:     	strb	w8, [x19, #0x7]
102706fc8:     	stp	x10, x9, [x19, #0x8]
102706fcc:     	ldr	q0, [sp, #0x10]
102706fd0:     	stur	q0, [x19, #0x18]
102706fd4:     	ldp	x29, x30, [sp, #0x70]
102706fd8:     	ldp	x20, x19, [sp, #0x60]
102706fdc:     	ldp	x22, x21, [sp, #0x50]
102706fe0:     	add	sp, sp, #0x80
102706fe4:     	ret
102706fe8:     	mov	w8, #0x2                ; =2
102706fec:     	mov	w11, #0x1               ; =1
102706ff0:     	b	0x102706f78 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge+0x170>
102706ff4:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
102706ff8:     	add	x0, x0, #0x4f0
102706ffc:     	bl	0x103a00c58 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102707000:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
102707004:     	add	x0, x0, #0x508
102707008:     	bl	0x103a00c28 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10270700c:     	ldr	x8, [x20, #0x10]
102707010:     	add	x8, x8, #0x1
102707014:     	str	x8, [x20, #0x10]
102707018:     	bl	0x103a02120 <dyld_stub_binder+0x103a02120>
