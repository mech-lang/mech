
/private/tmp/mech-inline-debit-round65-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000102707ce0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
102707ce0:     	sub	sp, sp, #0x60
102707ce4:     	stp	x20, x19, [sp, #0x40]
102707ce8:     	stp	x29, x30, [sp, #0x50]
102707cec:     	add	x29, sp, #0x50
102707cf0:     	ldr	x19, [x0]
102707cf4:     	ldr	x10, [x19, #0x10]
102707cf8:     	mov	x11, #0x7fffffffffffffff ; =9223372036854775807
102707cfc:     	cmp	x10, x11
102707d00:     	b.hs	0x102707d68 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x88>
102707d04:     	ldr	x10, [x19, #0x38]
102707d08:     	adds	x10, x10, x1
102707d0c:     	b.hs	0x102707d74 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
102707d10:     	cmp	x10, x2
102707d14:     	b.ls	0x102707d34 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x54>
102707d18:     	mov	w9, #0x606              ; =1542
102707d1c:     	strh	w9, [x8]
102707d20:     	mov	w9, #0x1                ; =1
102707d24:     	strb	w9, [x8, #0x2]
102707d28:     	str	x10, [x8, #0x8]
102707d2c:     	str	x2, [x8, #0x10]
102707d30:     	b	0x102707df4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x114>
102707d34:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
102707d38:     	add	x0, x0, #0x568
102707d3c:     	ldr	x10, [x0]
102707d40:     	blr	x10
102707d44:     	mov	x2, x0
102707d48:     	ldrb	w10, [x0, #0x48]
102707d4c:     	cmp	w10, #0x1
102707d50:     	b.eq	0x102707dbc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xdc>
102707d54:     	cmp	w10, #0x2
102707d58:     	b.ne	0x102707d90 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xb0>
102707d5c:     	adrp	x0, 0x10803d000 <_anon.27279621258a66ea37a651666c84bd55.41+0x10>
102707d60:     	add	x0, x0, #0xe78
102707d64:     	bl	0x103a01c24 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102707d68:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
102707d6c:     	add	x0, x0, #0x538
102707d70:     	bl	0x103a022d8 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102707d74:     	mov	w9, #0x606              ; =1542
102707d78:     	strh	w9, [x8]
102707d7c:     	mov	w9, #0x1                ; =1
102707d80:     	strb	w9, [x8, #0x2]
102707d84:     	mov	x9, #-0x1               ; =-1
102707d88:     	str	x9, [x8, #0x8]
102707d8c:     	b	0x102707d2c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x4c>
102707d90:     	adrp	x10, 0x102a19000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x410>
102707d94:     	add	x10, x10, #0x470
102707d98:     	mov	x0, x2
102707d9c:     	stp	x8, x1, [sp, #0x8]
102707da0:     	mov	x1, x10
102707da4:     	str	x2, [sp]
102707da8:     	bl	0x102e6e9ac <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102707dac:     	ldp	x2, x8, [sp]
102707db0:     	ldr	x1, [sp, #0x10]
102707db4:     	mov	w10, #0x1               ; =1
102707db8:     	strb	w10, [x2, #0x48]
102707dbc:     	add	x0, sp, #0x18
102707dc0:     	mov	x3, x1
102707dc4:     	mov	x1, x19
102707dc8:     	mov	x4, #0x0                ; =0
102707dcc:     	mov	x19, x8
102707dd0:     	bl	0x102707670 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget17charge_in_context>
102707dd4:     	ldrb	w9, [sp, #0x18]
102707dd8:     	cmp	w9, #0x9
102707ddc:     	b.eq	0x102707d5c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x7c>
102707de0:     	ldur	q0, [sp, #0x18]
102707de4:     	ldur	q1, [sp, #0x28]
102707de8:     	stp	q0, q1, [x19]
102707dec:     	ldr	x9, [sp, #0x38]
102707df0:     	str	x9, [x19, #0x20]
102707df4:     	ldp	x29, x30, [sp, #0x50]
102707df8:     	ldp	x20, x19, [sp, #0x40]
102707dfc:     	add	sp, sp, #0x60
102707e00:     	ret
