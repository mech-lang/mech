
/private/tmp/mech-inline-debit-round65-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001027068e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
1027068e0:     	sub	sp, sp, #0x80
1027068e4:     	stp	x22, x21, [sp, #0x50]
1027068e8:     	stp	x20, x19, [sp, #0x60]
1027068ec:     	stp	x29, x30, [sp, #0x70]
1027068f0:     	add	x29, sp, #0x70
1027068f4:     	mov	x19, x8
1027068f8:     	ldr	x20, [x0]
1027068fc:     	ldr	x8, [x20, #0x10]
102706900:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
102706904:     	cmp	x8, x9
102706908:     	b.hs	0x102706974 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
10270690c:     	add	x9, x8, #0x1
102706910:     	str	x9, [x20, #0x10]
102706914:     	ldr	x9, [x20, #0x38]
102706918:     	adds	x9, x9, x1
10270691c:     	b.hs	0x102706980 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xa0>
102706920:     	str	x8, [x20, #0x10]
102706924:     	cmp	x9, x2
102706928:     	b.ls	0x102706944 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x64>
10270692c:     	mov	w8, #0x606              ; =1542
102706930:     	strh	w8, [x19]
102706934:     	mov	w8, #0x1                ; =1
102706938:     	strb	w8, [x19, #0x2]
10270693c:     	stp	x9, x2, [x19, #0x8]
102706940:     	b	0x102706b10 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
102706944:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
102706948:     	add	x0, x0, #0x568
10270694c:     	ldr	x8, [x0]
102706950:     	blr	x8
102706954:     	ldrb	w8, [x0, #0x48]
102706958:     	cmp	w8, #0x1
10270695c:     	b.eq	0x1027069c8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe8>
102706960:     	cmp	w8, #0x2
102706964:     	b.ne	0x1027069a0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xc0>
102706968:     	adrp	x0, 0x10803d000 <_anon.27279621258a66ea37a651666c84bd55.41+0x10>
10270696c:     	add	x0, x0, #0xe78
102706970:     	bl	0x103a005a4 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102706974:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
102706978:     	add	x0, x0, #0x538
10270697c:     	bl	0x103a00c58 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102706980:     	mov	w9, #0x606              ; =1542
102706984:     	strh	w9, [x19]
102706988:     	mov	w9, #0x1                ; =1
10270698c:     	strb	w9, [x19, #0x2]
102706990:     	mov	x9, #-0x1               ; =-1
102706994:     	stp	x9, x2, [x19, #0x8]
102706998:     	str	x8, [x20, #0x10]
10270699c:     	b	0x102706b10 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
1027069a0:     	adrp	x8, 0x102a17000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy5_EB8_+0x4f0>
1027069a4:     	add	x8, x8, #0xed0
1027069a8:     	str	x0, [sp, #0x8]
1027069ac:     	mov	x21, x1
1027069b0:     	mov	x1, x8
1027069b4:     	bl	0x102e6d354 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
1027069b8:     	ldr	x0, [sp, #0x8]
1027069bc:     	mov	x1, x21
1027069c0:     	mov	w8, #0x1                ; =1
1027069c4:     	strb	w8, [x0, #0x48]
1027069c8:     	ldr	x8, [x0, #0x20]
1027069cc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1027069d0:     	cmp	x8, x9
1027069d4:     	b.hs	0x102706b30 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x250>
1027069d8:     	ldr	x8, [x0, #0x28]
1027069dc:     	cmp	x8, #0x0
1027069e0:     	ccmp	x8, x20, #0x4, ne
1027069e4:     	b.ne	0x102706a60 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x180>
1027069e8:     	ldr	x8, [x20, #0x10]
1027069ec:     	cbnz	x8, 0x102706b3c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x25c>
1027069f0:     	mov	x8, #-0x1               ; =-1
1027069f4:     	str	x8, [x20, #0x10]
1027069f8:     	ldr	w8, [x0, #0x30]
1027069fc:     	ldp	x9, x10, [x0, #0x38]
102706a00:     	ldp	x11, x12, [x20, #0x60]
102706a04:     	cmp	x9, x11
102706a08:     	csel	x9, x9, x11, lo
102706a0c:     	cmp	x10, x12
102706a10:     	csel	x10, x10, x12, lo
102706a14:     	tst	w8, #0x1
102706a18:     	csel	x9, x9, x11, ne
102706a1c:     	csel	x13, x10, x12, ne
102706a20:     	ldr	x8, [x20, #0x38]
102706a24:     	adds	x21, x8, x1
102706a28:     	b.hs	0x102706b24 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102706a2c:     	ldr	x8, [x20, #0x48]
102706a30:     	adds	x10, x8, x21
102706a34:     	b.hs	0x102706b24 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102706a38:     	ldr	x22, [x20, #0x40]
102706a3c:     	ldr	x8, [x20, #0x50]
102706a40:     	adds	x14, x8, x22
102706a44:     	b.hs	0x102706b24 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102706a48:     	cmp	x10, x9
102706a4c:     	b.ls	0x102706a68 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x188>
102706a50:     	mov	w12, #0x6               ; =6
102706a54:     	mov	w11, #0x1               ; =1
102706a58:     	mov	w8, #0x6                ; =6
102706a5c:     	b	0x102706adc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102706a60:     	mov	w8, #0x0                ; =0
102706a64:     	b	0x102706ae8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x208>
102706a68:     	cmp	x14, x13
102706a6c:     	b.ls	0x102706a88 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
102706a70:     	mov	w8, #0x6                ; =6
102706a74:     	mov	w12, #0x5               ; =5
102706a78:     	mov	w11, #0x1               ; =1
102706a7c:     	mov	x9, x13
102706a80:     	mov	x10, x14
102706a84:     	b	0x102706adc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102706a88:     	mov	x0, x20
102706a8c:     	ldr	x8, [x0, #0x70]!
102706a90:     	cbz	x8, 0x102706aac <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1cc>
102706a94:     	add	x8, sp, #0x28
102706a98:     	mov	x2, #0x0                ; =0
102706a9c:     	bl	0x102453c90 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102706aa0:     	ldrb	w8, [sp, #0x28]
102706aa4:     	cmp	w8, #0x8
102706aa8:     	b.ne	0x102706ab8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d8>
102706aac:     	stp	x21, x22, [x20, #0x38]
102706ab0:     	mov	w8, #0x8                ; =8
102706ab4:     	b	0x102706adc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102706ab8:     	ldrb	w12, [sp, #0x29]
102706abc:     	ldrb	w11, [sp, #0x2a]
102706ac0:     	ldur	w9, [sp, #0x2b]
102706ac4:     	str	w9, [sp, #0x20]
102706ac8:     	ldrb	w9, [sp, #0x2f]
102706acc:     	strb	w9, [sp, #0x24]
102706ad0:     	ldp	x10, x9, [sp, #0x30]
102706ad4:     	ldur	q0, [sp, #0x40]
102706ad8:     	str	q0, [sp, #0x10]
102706adc:     	ldr	x13, [x20, #0x10]
102706ae0:     	add	x13, x13, #0x1
102706ae4:     	str	x13, [x20, #0x10]
102706ae8:     	strb	w8, [x19]
102706aec:     	strb	w12, [x19, #0x1]
102706af0:     	strb	w11, [x19, #0x2]
102706af4:     	ldr	w8, [sp, #0x20]
102706af8:     	stur	w8, [x19, #0x3]
102706afc:     	ldrb	w8, [sp, #0x24]
102706b00:     	strb	w8, [x19, #0x7]
102706b04:     	stp	x10, x9, [x19, #0x8]
102706b08:     	ldr	q0, [sp, #0x10]
102706b0c:     	stur	q0, [x19, #0x18]
102706b10:     	ldp	x29, x30, [sp, #0x70]
102706b14:     	ldp	x20, x19, [sp, #0x60]
102706b18:     	ldp	x22, x21, [sp, #0x50]
102706b1c:     	add	sp, sp, #0x80
102706b20:     	ret
102706b24:     	mov	w8, #0x2                ; =2
102706b28:     	mov	w11, #0x1               ; =1
102706b2c:     	b	0x102706ab4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d4>
102706b30:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
102706b34:     	add	x0, x0, #0x4f0
102706b38:     	bl	0x103a00c58 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102706b3c:     	adrp	x0, 0x10803f000 <_anon.beb89ec6cfcf836d4c17d891cfcecc03.311+0xa0>
102706b40:     	add	x0, x0, #0x508
102706b44:     	bl	0x103a00c28 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102706b48:     	ldr	x8, [x20, #0x10]
102706b4c:     	add	x8, x8, #0x1
102706b50:     	str	x8, [x20, #0x10]
102706b54:     	bl	0x103a02120 <dyld_stub_binder+0x103a02120>
