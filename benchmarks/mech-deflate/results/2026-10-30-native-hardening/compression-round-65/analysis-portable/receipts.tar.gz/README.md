# R65: inline the maintained checked-debit helper

Scratch harness prepared for parent execution. No R65 build, test, compression, disassembly or performance run has occurred. The baseline remains pending until R64 is complete and retained. The sole production change is `#[inline]` → `#[inline(always)]` on `NativeLibraryWorkBudget::charge_in_context` in Engine `resident/budget.rs`. `freeze-source.py` verifies the entire file differs only in that attribute. No accounting/TLS implementation, allowance, allocation site, compressor source or new test is introduced.

This is separate from R64's completed first-only projection-policy experiment. The immediate R64 worker must be re-examined; older outlined helper evidence is a lead, not proof the same code survived. The candidate may expose the compute-only caller's constant comparison delta and eliminate call/return or Result transport. Inspect the actual machine code; do not assume the attribute succeeds or that TLS work disappears. Allocation totals are expected unchanged, and neither instructions nor elapsed are forced to improve.

## Parent execution order

All commands are serial. `archive.py` publishes and commits the raw receipts and uses `dereference=True` so copied baseline symlinks become actual archived files. No concurrent build, test, disassembly or other profiling may overlap timed cohorts.

1. Complete and retain R64; finalize validation. Initialize R65 with its accepted checkpoint, preserving its distinct actual build SHA:

   `python3 /private/tmp/mech-inline-debit-round65-20261031/initialize-baseline.py <accepted-R64-checkpoint-SHA>`

   The initializer pins R64 libraries, auxiliary dependencies, Object/descriptor/metadata, linked worker, probe sources and diagnostic object. It copies no old timing, census or executed-test result as an R65 observation. It pins the existing R64 Engine, GPU and Core test binaries and their historical build receipts explicitly. Baseline allocation expectations come from R64's actual completed allocation counter.

2. Before applying production, run the inherited Engine witnesses and execute the pinned existing Core and GPU test binaries afresh:

   `python3 /private/tmp/mech-inline-debit-round65-20261031/reuse-parent-engine.py`

   `python3 /private/tmp/mech-inline-debit-round65-20261031/reuse-tests.py core`

   `python3 /private/tmp/mech-inline-debit-round65-20261031/reuse-tests.py gpu`

   Parent Engine freshly executes the pinned R64 `engine-after/engine-tests` binary with its actual historical build provenance; there is no parent rebuild and no historical execution relabeling. Candidate Engine is newly compiled from scratch-staged source against the candidate dependency graph. Both variants must pass projection 12, shape 6 and the policy-order/overflow-retry single-test subsets. Core's two existing first-violation tests execute freshly from the pinned unchanged R64 binary; no Core test or production rebuild is needed. The GPU parent executes `native_artifact::work::tests::` (12 tests), plus exact `native_ceiling_and_overflow_precede_foreign_account_and_library_caps` (1). Inventory counts and run counts must both match. These tests preserve overflow/ceiling before foreign-account rejection, tighter library caps, unchanged work on denial, and successful retry. No expected-red control is inherited.

3. Apply and commit `findings-packet/force-inline-debit.patch`. Freeze the exact attribute-only source and build the coherent changed host graph:

   `python3 /private/tmp/mech-inline-debit-round65-20261031/freeze-source.py`

   `python3 /private/tmp/mech-inline-debit-round65-20261031/build-changed.py`

   The build uses retained exact release commands/features. It rebuilds Engine → Compute → Stdlib → Runtime → GPU in a fresh consistent dependency overlay, retaining Core/math/syntax/external artifacts by SHA. It does not run Cargo-wide compilation or rebuild math. All build time is outside timing.

4. Run candidate tests, fresh cohorts, bounded host-code audit, then qualification:

   `python3 /private/tmp/mech-inline-debit-round65-20261031/run-remaining.py`

   Preconditions are the passing parent Engine projection/shape, fresh Core 2 and GPU work 12/error-order 1 receipts. Candidate GPU tests additionally execute work 12/error-order 1. `run-cohorts.py` runs fresh candidate emission and smoke/byte-identity checks, primary elapsed, hardware/heap counters, full before census, full after census, Mech samples, reference samples, and **then** bounded host assembly. Host disassembly never overlaps measurements. Baseline primary uses the retained R64 worker and coherent libraries; all observed executions are fresh R65 cohorts.

   `qualify-all.py` inventories and actually executes runtime 329, preparation 2, work/memory/value 32, components 236, connected 8, path mechanism 1, linked 12, scalar controls 12, frame-allocation controls 8, workflow Python 132, GPU CI 35, Engine CI projection 12/shape 6 and architecture 10. Counts overlap; do not add them as unique tests. The existing complete-knucleotide exclusion remains documented. Minimal-profile and remote CI completion are not claimed.

5. Preserve every failed attempt in `prior-failures.json` with its actual raw receipt/disposition; do not overwrite failures. Fill `decision.json` from the template only after observed results. Then:

   `python3 /private/tmp/mech-inline-debit-round65-20261031/finalize-analysis.py`

   The finalizer only analyzes completed receipts and requires all qualification checks to pass. Add `--archive` only when ready for publication. Publish report, scorecard JSON/CSV, allocation comparison, profile numbers, validation, binary identity, host assembly comparison and replay scripts. Numerical `reconstruct.py /new/empty/output/path` verifies every archived version and reproduces six public outputs without compilation or compressor execution.

## Assembly acceptance

`host-assembly.py` uses the native agent's bounded `audit-current-debit.py`: symbol discovery then at most 64 KiB per named host function. It retains raw assembly, exact commands, actual worker SHA and whole linked `__text` size. Both direct callers (`charge_compute_with_limit` and `NativeLibraryWorkBudget::charge`) and the helper are included when materialized. `host_analysis.py` re-parses raw assembly and verifies each retained instruction/opcode ledger. Missing symbols alone are not a gain.

Review these separately: whether the compute-only caller still calls an outlined helper; whether zero comparison overflow work survives; whether stack Result transport survives; actual caller and helper stack adjustments; compute reload/add sequences across TLS; other caller growth; whole host text/file size. Static full-function counts include failure/panic paths. Do not equate them with successful-path or dynamic counts, sum unrelated stack frames, or assign sampled CPU percentages to retired instructions. The generated compressor Object/image/metadata must be byte-identical and its text/entry-stack counts remain a separate layer.

## Measurement controls

Four independently prepared pairs × 16 alternating blocks × 31 calls × 2 variants produce 3,968 primary observations, 3,984 including warmup/profile rows. A fresh 20,000-call reference defines elapsed multiples. Report before/after multiples and matched ratio; keep all adverse pairs and independent diagnostic directions. CPU counters have 32 observations per variant, Mech heap counters eight measured calls. Full before and after allocation traces are fresh and individually reconciled to their own heap cohorts. Requested capacity is not initialized bytes copied; post-call OS footprint is not peak RSS. No previous-round gains are multiplied.

Complete eight-byte `abcdefgh`, exact raw output `[75,76,74,78,73,77,75,207,0,0]`, independent inflate, output capacity 13 clear/reuse, input aliases, tree 262,144 U16, cache 1,500,513 U32, depth 300, nice 258, source/bytecode/allocator pins and `evaluate_into` timing stay unchanged. Logical work 60,260,219,686 and comparison work 47,612 are not hardware instruction counts. Final managed bytes/nodes must be zero. No full-scale timing or larger-input performance claim.
