from pathlib import Path
import subprocess,shutil,json
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');packet=w/'benchmarks/mech-deflate/results/2026-10-30-native-hardening/compression-round-65';p=r/'replay-initial';p.mkdir()
for name in ['stdout','stderr']:shutil.copy2(r/('reconstruction.'+name),p/name)
row={'command':['python3',str(packet/'reconstruct.py'),str(r/'replay-final')],'exit':1,'classification':'introduced replay packet input omission','disposition':'New host-assembly replay consumes linked-primary/before/binding.json; baseline binding was archived at baseline/binding.json only. Add the exact same verified baseline binding at the required replay path. No measurement, test, source or pin change.'};(p/'receipt.json').write_text(json.dumps(row,indent=2)+'\n')
f=r/'prior-failures.json';rows=json.loads(f.read_text());rows.append({'receipt':'replay-initial/receipt.json','classification':row['classification'],'disposition':row['disposition']});f.write_text(json.dumps(rows,indent=2)+'\n')
assert (r/'linked-primary/before/binding.json').read_bytes()==(r/'baseline/binding.json').read_bytes()
subprocess.run(['python3',str(r/'archive.py'),'replay-prerequisites',str(p),str(r/'linked-primary/before/binding.json'),str(r/'finish-replay.py')],check=True)
q=subprocess.run(['python3',str(r/'finalize-analysis.py')],capture_output=True,text=True);(r/'finalization-portable.stdout').write_text(q.stdout);(r/'finalization-portable.stderr').write_text(q.stderr)
if q.returncode:print(q.stdout[-2000:]+q.stderr[-4000:],flush=True)
q.check_returncode()
paths=[str(r/item['path']) for item in json.loads((packet/'analysis-final/manifest.json').read_text())['files']]
subprocess.run(['python3',str(r/'archive.py'),'analysis-portable',*paths],check=True)
for name in ['analyze.py','allocation_analysis.py','binary_identity.py','validation.py','render-report.py','reconstruct.py','profile_analysis.py','finalize-analysis.py','host_analysis.py','allocation-comparison.json','profile-numbers.json','validation.json','binary-audit.json','host-assembly-comparison.json']:
 shutil.copy2(r/name,packet/name)
for name in ['scorecard.json','scorecard.csv']:shutil.copy2(r/'analysis'/name,packet/name)
for src,dst in [('report.md','REPORT.md'),('findings-packet/binary-review.md','binary-review.md'),('findings-packet/missed-costs.md','missed-costs.md')]:shutil.copy2(r/src,packet/dst)
cmd=['python3',str(packet/'reconstruct.py'),str(r/'replay-portable')];q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
(r/'reconstruction-portable.stdout').write_text(q.stdout);(r/'reconstruction-portable.stderr').write_text(q.stderr);print(q.stdout[-1800:]+q.stderr[-4000:],flush=True);q.check_returncode()
d=json.loads(q.stdout);d.update(command=cmd,exit=q.returncode);(packet/'reconstruction.json').write_text(json.dumps(d,indent=2)+'\n')
subprocess.run(['git','add',str(packet)],cwd=w,check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Publish checked-debit gains with complete standalone host-code replay'],cwd=w,check=True)
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),flush=True)
