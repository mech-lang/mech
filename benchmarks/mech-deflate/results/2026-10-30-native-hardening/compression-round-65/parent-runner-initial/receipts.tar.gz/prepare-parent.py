from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
jobs=[('initialize-baseline.py',['78614f175a932b37a73e9b8a12be1fd4e390c9f3']),('reuse-parent-engine.py',[]),('reuse-tests.py',['core']),('reuse-tests.py',['gpu'])]
for name,args in jobs:
 print('START',name,*args,flush=True)
 subprocess.run(['python3',str(r/name),*args],check=True)
 print('DONE',name,flush=True)
print('PARENTS_PASSED',flush=True)
