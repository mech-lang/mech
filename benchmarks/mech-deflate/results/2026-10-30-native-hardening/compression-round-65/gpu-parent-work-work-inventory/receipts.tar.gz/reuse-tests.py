"""Execute pinned unchanged R64 Core or baseline GPU test binaries afresh for R65."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');label=sys.argv[1];assert label in ['core','gpu']
c=json.loads((r/'configuration.json').read_text());assert c['initialized'];pin=json.loads((r/'baseline'/(label+'-test-binary.json')).read_text());binary=Path(pin['path'])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==pin['sha256'] and binary.stat().st_size==pin['bytes']
source_scope='src/core' if label=='core' else 'hosts/gpu/src'
assert subprocess.check_output(['git','diff',c['baseline_checkpoint'],'--',source_scope],cwd=w)==b''
if label=='core':assert subprocess.check_output(['git','rev-parse','HEAD:src/core'],cwd=w,text=True)==(r/'baseline/core-source-tree.txt').read_text()
p=r/('core-focused' if label=='core' else 'gpu-parent-work');p.mkdir()
reuse={'exit':0,'binary':pin,'baseline_checkpoint':c['baseline_checkpoint'],'current_source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'retained_build_receipt':'baseline/'+label+'-test-build.json','scope':'Binary pin and unchanged source verified now. No test compilation occurred in R65. All inventory and selected-run receipts below are fresh R65 executions.'};(p/'reuse.json').write_text(json.dumps(reuse,indent=2)+'\n')
selections=[('selected','first_call_rejection',2)] if label=='core' else [('work',c['gpu_work_filter'],c['gpu_work_expected']),('ceiling-order','native_artifact::work::tests::native_ceiling_and_overflow_precede_foreign_account_and_library_caps',1)]
for name,selection,count in selections:
 for inventory in [True,False]:
  stage=('inventory' if inventory else 'selected') if label=='core' else name+('-inventory' if inventory else '')
  cmd=[str(binary),selection,*(['--list'] if inventory else ['--nocapture','--test-threads=1'])];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/(stage+'.'+stream)).write_text(getattr(q,stream))
  row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'binary_sha256':pin['sha256'],'expected_tests':count,'retained_build_receipt':reuse['retained_build_receipt'],'scope':'Fresh R65 execution of verified unchanged baseline binary; compilation provenance is historical and explicitly separate.'}
  if inventory:row['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=row['listed_tests']
  else:
   m=re.search(r'test result: ok. (\d+) passed; 0 failed;',q.stdout);row['executed_tests']=int(m[1]) if m else None;observed=row['executed_tests']
  (p/(stage+'.json')).write_text(json.dumps(row,indent=2)+'\n')
  subprocess.run(['python3',str(r/'archive.py'),p.name+'-'+stage,str(p/(stage+'.json')),str(p/(stage+'.stdout')),str(p/(stage+'.stderr')),str(p/'reuse.json'),str(r/'baseline'/(label+'-test-binary.json')),str(r/'baseline'/(label+'-test-build.json')),str(r/'reuse-tests.py')],cwd=w,check=True)
  print(label,stage,q.returncode,observed,flush=True)
  if q.returncode:print(q.stdout[-3000:]+q.stderr[-3000:],flush=True)
  q.check_returncode();assert observed==count,row
