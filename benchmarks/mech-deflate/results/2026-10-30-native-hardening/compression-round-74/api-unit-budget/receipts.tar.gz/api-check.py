"""Compile just the current Engine unit root against frozen dependencies."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'api-unit';p.mkdir();old=Path('/private/tmp/mech-observed-plan-transfer-round70-20261031');base=json.loads((old/'engine-after/build.json').read_text());libs=json.loads((old/'final-libraries.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True).strip()
root=p/'source';stage=root/'src/engine';stage.parent.mkdir(parents=True);shutil.copytree(w/'src/engine',stage,ignore=shutil.ignore_patterns('target','.git'));(root/'tests').symlink_to(w/'tests',target_is_directory=True)
cmd=base['command'].copy();assert cmd[-2]=='-o';cmd[-3]=str(stage/'src/lib.rs');cmd[-1]=str(p/'engine-tests');env=base['environment'];source_pins={str(f.relative_to(stage)):hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in sorted(stage.rglob('*')) if f.is_file()}
def run(label,command,count=None,inventory=False):
 at=time.monotonic();q=subprocess.run(command,cwd=w,env={**os.environ,**env},capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(label+'.'+stream)).write_text(getattr(q,stream))
 d={'command':command,'environment':env,'exit':q.returncode,'seconds':time.monotonic()-at,'source_head':head,'source_files':source_pins,'libraries':libs,'scope':'API semantic witness before GPU integration; current Engine test code,frozen unchanged Core/syntax/external dependencies,warnings-as-errors retained. Not a release or compressor timing claim.'}
 if count is not None:
  if inventory:d['listed_tests']=len(re.findall(r': test$',q.stdout,re.M));observed=d['listed_tests']
  else:
   m=re.search(r'test result: (?:ok|FAILED). (\d+) passed; (\d+) failed;',q.stdout);d['executed_tests']=int(m[1])+int(m[2]) if m else None;d['passed_tests']=int(m[1]) if m else None;d['failed_tests']=int(m[2]) if m else None;observed=d['executed_tests']
 (p/(label+'.json')).write_text(json.dumps(d,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'api-unit-'+label,str(p/(label+'.json')),str(p/(label+'.stdout')),str(p/(label+'.stderr')),str(r/'api-check.py'),*[str(stage/'src/resident'/name) for name in ['budget.rs','native_work_context.rs','native_work_context_tests.rs']]],check=True)
 print(label,q.returncode,d.get('executed_tests',d.get('listed_tests')),flush=True)
 if q.returncode:print(q.stdout[-3000:]+q.stderr[-6000:],flush=True)
 q.check_returncode()
 if count is not None:assert observed==count,(label,d)
run('build',cmd)
for name,selection,count in [('scoped','native_work_context::tests::',5),('budget','resident::budget::',113),('planner','memory_planner::',22)]:
 run(name+'-inventory',[cmd[-1],selection,'--list'],count,True);run(name,[cmd[-1],selection,'--nocapture','--test-threads=1'],count)
print('API_CHECK_COMPLETE',flush=True)
