use mech_engine::native_artifact::with_native_work_context;
fn main(){with_native_work_context(|context|std::thread::scope(|scope|{
 scope.spawn(move||context.has_active_scope()).join().unwrap();
}));}
