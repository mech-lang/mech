use mech_engine::native_artifact::{NativeLibraryWorkBudget,with_native_work_context};
use mech_core::ManagedMemoryBudget;
fn main() {
 let memory=ManagedMemoryBudget::new(8192);
 { let b=NativeLibraryWorkBudget::new(10,10,&memory).unwrap();
 with_native_work_context(|context| {
  assert!(!context.has_active_scope());
  b.with_call_limits(2,0,|| {
   assert!(context.has_active_scope());
   b.charge_compute_with_limit_scoped(context,1,10).unwrap();
   b.charge_compute_with_limit(1,10).unwrap();
   assert!(b.charge_compute_with_limit_scoped(context,1,10).is_err());
  }).unwrap();
  assert!(!context.has_active_scope());
  b.charge_compute_with_limit_scoped(context,1,10).unwrap();
  assert_eq!(b.used(),(3,0));
 }); }
 assert_eq!(memory.used_bytes(),0);
 println!("SCOPED_CONTEXT_OK used=3 final_bytes=0");
}
