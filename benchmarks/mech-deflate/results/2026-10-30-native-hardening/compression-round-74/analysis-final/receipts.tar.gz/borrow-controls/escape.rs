use mech_engine::native_artifact::with_native_work_context;
fn main(){let _escaped=with_native_work_context(|context|context);}
