
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010154fe64 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge>:
10154fe64:     	sub	sp, sp, #0xa0
10154fe68:     	stp	x26, x25, [sp, #0x50]
10154fe6c:     	stp	x24, x23, [sp, #0x60]
10154fe70:     	stp	x22, x21, [sp, #0x70]
10154fe74:     	stp	x20, x19, [sp, #0x80]
10154fe78:     	stp	x29, x30, [sp, #0x90]
10154fe7c:     	add	x29, sp, #0x90
10154fe80:     	mov	x20, x3
10154fe84:     	mov	x19, x0
10154fe88:     	ldr	w22, [x3]
10154fe8c:     	cmp	w22, #0x2
10154fe90:     	cset	w21, ne
10154fe94:     	ldr	w23, [x3, #0x10]
10154fe98:     	cbz	x4, 0x10154fedc <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x78>
10154fe9c:     	ldur	x8, [x1, #0x18]
10154fea0:     	cbz	x8, 0x10154ff38 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xd4>
10154fea4:     	ldr	x3, [x1, #0x10]
10154fea8:     	add	x8, sp, #0x28
10154feac:     	add	x0, x1, #0x18
10154feb0:     	mov	x1, x4
10154feb4:     	bl	0x1023728b0 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped>
10154feb8:     	ldrb	w8, [sp, #0x28]
10154febc:     	cmp	w8, #0x8
10154fec0:     	b.ne	0x10154ff08 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xa4>
10154fec4:     	mov	w10, #0xe               ; =14
10154fec8:     	mov	x13, x23
10154fecc:     	mov	x23, x0
10154fed0:     	cmp	w10, #0xe
10154fed4:     	b.eq	0x10154ffc8 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x164>
10154fed8:     	b	0x10154ffe4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x180>
10154fedc:     	ldur	x8, [x1, #0x18]
10154fee0:     	cbz	x8, 0x10154ff38 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xd4>
10154fee4:     	ldr	x9, [x1, #0x10]
10154fee8:     	add	x8, sp, #0x28
10154feec:     	add	x0, x1, #0x18
10154fef0:     	mov	x1, x2
10154fef4:     	mov	x2, x9
10154fef8:     	bl	0x10236d190 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
10154fefc:     	ldrb	w8, [sp, #0x28]
10154ff00:     	cmp	w8, #0x8
10154ff04:     	b.eq	0x10154fec4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x60>
10154ff08:     	ldp	x13, x8, [sp, #0x28]
10154ff0c:     	ldr	x9, [sp, #0x38]
10154ff10:     	and	x10, x13, #0xffff
10154ff14:     	cmp	x10, #0x606
10154ff18:     	b.ne	0x10154ff8c <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x128>
10154ff1c:     	mov	w10, #0x6               ; =6
10154ff20:     	mov	x12, x21
10154ff24:     	mov	x13, x23
10154ff28:     	mov	x23, x0
10154ff2c:     	cmp	w10, #0xe
10154ff30:     	b.eq	0x10154ffc8 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x164>
10154ff34:     	b	0x10154ffe4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x180>
10154ff38:     	mov	x24, x2
10154ff3c:     	mov	x25, x1
10154ff40:     	bl	0x10236c9ac <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
10154ff44:     	tbz	w0, #0x0, 0x10154ff60 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0xfc>
10154ff48:     	mov	w13, #0x0               ; =0
10154ff4c:     	mov	x8, #0x0                ; =0
10154ff50:     	mov	w10, #0x7               ; =7
10154ff54:     	cmp	w10, #0xe
10154ff58:     	b.eq	0x10154ffc8 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x164>
10154ff5c:     	b	0x10154ffe4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x180>
10154ff60:     	ldp	x8, x9, [x25, #0x8]
10154ff64:     	adds	x8, x8, x24
10154ff68:     	b.hs	0x101550040 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x1dc>
10154ff6c:     	cmp	x8, x9
10154ff70:     	b.ls	0x10154ffd4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x170>
10154ff74:     	mov	w10, #0x6               ; =6
10154ff78:     	mov	x13, x23
10154ff7c:     	mov	x12, x21
10154ff80:     	cmp	w10, #0xe
10154ff84:     	b.eq	0x10154ffc8 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x164>
10154ff88:     	b	0x10154ffe4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x180>
10154ff8c:     	mov	x0, x23
10154ff90:     	lsr	x12, x9, #32
10154ff94:     	ldr	x10, [sp, #0x40]
10154ff98:     	str	x10, [sp, #0x8]
10154ff9c:     	mov	w10, #0x7               ; =7
10154ffa0:     	ldp	w14, w11, [sp, #0x48]
10154ffa4:     	str	w14, [sp, #0x10]
10154ffa8:     	mov	x23, x12
10154ffac:     	mov	x12, x9
10154ffb0:     	mov	x9, x8
10154ffb4:     	mov	x8, x13
10154ffb8:     	mov	x13, x23
10154ffbc:     	mov	x23, x0
10154ffc0:     	cmp	w10, #0xe
10154ffc4:     	b.ne	0x10154ffe4 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x180>
10154ffc8:     	mov	w8, #0x13               ; =19
10154ffcc:     	strb	w8, [x19]
10154ffd0:     	b	0x101550024 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x1c0>
10154ffd4:     	str	x8, [x25, #0x8]
10154ffd8:     	mov	w10, #0xe               ; =14
10154ffdc:     	cmp	w10, #0xe
10154ffe0:     	b.eq	0x10154ffc8 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x164>
10154ffe4:     	cmp	w10, #0x6
10154ffe8:     	b.ne	0x101550000 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x19c>
10154ffec:     	ldr	w13, [x20, #0x4]
10154fff0:     	add	x14, x20, #0x8
10154fff4:     	mov	w10, #0xe               ; =14
10154fff8:     	mov	x12, x22
10154fffc:     	b	0x101550004 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x1a0>
101550000:     	add	x14, sp, #0x8
101550004:     	ldr	w15, [x14, #0x8]
101550008:     	ldr	x14, [x14]
10155000c:     	strb	w10, [x19]
101550010:     	stp	x8, x9, [x19, #0x8]
101550014:     	stp	w12, w13, [x19, #0x18]
101550018:     	str	x14, [x19, #0x20]
10155001c:     	stp	w15, w11, [x19, #0x28]
101550020:     	stp	w21, w23, [x19, #0x30]
101550024:     	ldp	x29, x30, [sp, #0x90]
101550028:     	ldp	x20, x19, [sp, #0x80]
10155002c:     	ldp	x22, x21, [sp, #0x70]
101550030:     	ldp	x24, x23, [sp, #0x60]
101550034:     	ldp	x26, x25, [sp, #0x50]
101550038:     	add	sp, sp, #0xa0
10155003c:     	ret
101550040:     	mov	w10, #0x6               ; =6
101550044:     	mov	x8, #-0x1               ; =-1
101550048:     	b	0x10154ff78 <__RNvNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime6charge+0x114>
