"""Actual cross-crate Rust lifetime/thread-boundary controls, outside timing."""
from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;w=Path('/private/tmp/mech-deflate-linear-stack');p=r/'borrow-controls';p.mkdir();libs=json.loads((r/'final-libraries.json').read_text());release=json.loads((r/'final-release.json').read_text());rustc=release['command'][0]
cases={
'valid':('use mech_engine::native_artifact::{NativeLibraryWorkBudget,with_native_work_context};\nuse mech_core::ManagedMemoryBudget;\nfn main() {\n let memory=ManagedMemoryBudget::new(8192);\n { let b=NativeLibraryWorkBudget::new(10,10,&memory).unwrap();\n with_native_work_context(|context| {\n  assert!(!context.has_active_scope());\n  b.with_call_limits(2,0,|| {\n   assert!(context.has_active_scope());\n   b.charge_compute_with_limit_scoped(context,1,10).unwrap();\n   b.charge_compute_with_limit(1,10).unwrap();\n   assert!(b.charge_compute_with_limit_scoped(context,1,10).is_err());\n  }).unwrap();\n  assert!(!context.has_active_scope());\n  b.charge_compute_with_limit_scoped(context,1,10).unwrap();\n  assert_eq!(b.used(),(3,0));\n }); }\n assert_eq!(memory.used_bytes(),0);\n println!("SCOPED_CONTEXT_OK used=3 final_bytes=0");\n}\n',0,None),
'escape':('use mech_engine::native_artifact::with_native_work_context;\nfn main(){let _escaped=with_native_work_context(|context|context);}\n',1,'lifetime may not live long enough'),
'send':('use mech_engine::native_artifact::with_native_work_context;\nfn main(){with_native_work_context(|context|std::thread::scope(|scope|{\n scope.spawn(move||context.has_active_scope()).join().unwrap();\n}));}\n',1,'cannot be shared between threads safely')}
for name,(source,expected,reason) in cases.items():
 f=p/(name+'.rs');f.write_text(source);cmd=[rustc,'--edition=2024','--crate-name','context_'+name,'-D','warnings','-C','opt-level=3','-L','dependency='+str(r/'variants/after/dependency'),'--extern','mech_engine='+libs['mech_engine']['path'],'--extern','mech_core='+libs['mech_core']['path'],str(f),'-o',str(p/name)]
 if name!='valid':cmd.insert(1,'--emit=metadata')
 at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
 for stream in ['stdout','stderr']:(p/(name+'.'+stream)).write_text(getattr(q,stream))
 row={'command':cmd,'exit':q.returncode,'expected_exit':expected,'expected_error':reason,'seconds':time.monotonic()-at,'compiler_source':release['source_head'],'libraries':libs,'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'scope':'Real Rust consumer. Rejections prove lifetime escape and cross-thread use are blocked for the actual candidate API; neither is a runtime/performance claim.'};(p/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 subprocess.run(['python3',str(r/'archive.py'),'borrow-control-'+name,str(f),str(p/(name+'.json')),str(p/(name+'.stdout')),str(p/(name+'.stderr')),str(r/'borrow-controls.py')],check=True)
 if q.returncode!=expected or (reason and reason not in q.stderr):print(q.stderr[-7000:],flush=True)
 assert q.returncode==expected and (reason is None or reason in q.stderr),name
 if name=='valid':
  cmd=[str(p/name)];at=time.monotonic();q=subprocess.run(cmd,cwd=w,capture_output=True,text=True)
  for stream in ['stdout','stderr']:(p/('valid-run.'+stream)).write_text(getattr(q,stream))
  row={'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-at,'expected_stdout':'SCOPED_CONTEXT_OK used=3 final_bytes=0\n','compiler_source':release['source_head']};(p/'valid-run.json').write_text(json.dumps(row,indent=2)+'\n')
  subprocess.run(['python3',str(r/'archive.py'),'borrow-control-valid-run',str(p/'valid-run.json'),str(p/'valid-run.stdout'),str(p/'valid-run.stderr'),str(r/'borrow-controls.py')],check=True)
  assert q.returncode==0 and q.stdout==row['expected_stdout']
print('BORROW_CONTROLS_PASSED',flush=True)
