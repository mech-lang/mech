from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent
for name in ['units.py','qualify-all.py','type-architecture.py']:
 print('START',name,flush=True);subprocess.run(['python3',str(r/name)],check=True)
