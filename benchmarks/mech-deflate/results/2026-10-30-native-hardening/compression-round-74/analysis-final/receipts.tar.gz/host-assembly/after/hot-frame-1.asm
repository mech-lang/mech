
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010150dc8c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>:
10150dc8c:     	sub	sp, sp, #0x1d0
10150dc90:     	stp	x28, x27, [sp, #0x170]
10150dc94:     	stp	x26, x25, [sp, #0x180]
10150dc98:     	stp	x24, x23, [sp, #0x190]
10150dc9c:     	stp	x22, x21, [sp, #0x1a0]
10150dca0:     	stp	x20, x19, [sp, #0x1b0]
10150dca4:     	stp	x29, x30, [sp, #0x1c0]
10150dca8:     	add	x29, sp, #0x1c0
10150dcac:     	mov	x25, x6
10150dcb0:     	mov	x26, x4
10150dcb4:     	mov	x23, x3
10150dcb8:     	mov	x22, x2
10150dcbc:     	mov	x24, x1
10150dcc0:     	mov	x20, x0
10150dcc4:     	mov	x19, x8
10150dcc8:     	ldr	x21, [x29, #0x10]
10150dccc:     	stp	x5, x6, [sp]
10150dcd0:     	str	x7, [sp, #0x10]
10150dcd4:     	add	x27, sp, #0x80
10150dcd8:     	ldr	w0, [x0, #0x110]
10150dcdc:     	add	x8, sp, #0xc8
10150dce0:     	mov	x1, x21
10150dce4:     	bl	0x10254e3d0 <__RNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls13finite_limits>
10150dce8:     	ldrb	w8, [sp, #0xc8]
10150dcec:     	cmp	w8, #0x29
10150dcf0:     	b.ne	0x10150dd44 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb8>
10150dcf4:     	ldr	x28, [x20, #0x1d8]
10150dcf8:     	cbz	x28, 0x10150dd64 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xd8>
10150dcfc:     	mov	w27, #0x2c              ; =44
10150dd00:     	strb	w27, [sp, #0xc8]
10150dd04:     	add	x0, sp, #0xc8
10150dd08:     	bl	0x10150e600 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10150dd0c:     	cmp	x22, x26
10150dd10:     	b.ne	0x10150dd3c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb0>
10150dd14:     	ldr	x8, [x20, #0x78]
10150dd18:     	cmp	x22, x8
10150dd1c:     	b.ne	0x10150dd3c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xb0>
10150dd20:     	cmp	x25, #0x0
10150dd24:     	cset	w8, ne
10150dd28:     	ldr	x9, [x20, #0x10]
10150dd2c:     	cmp	x9, #0xb
10150dd30:     	cset	w9, eq
10150dd34:     	eor	w8, w8, w9
10150dd38:     	tbz	w8, #0x0, 0x10150dd8c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x100>
10150dd3c:     	strb	w27, [x19]
10150dd40:     	b	0x10150dd6c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10150dd44:     	ldur	q0, [x27, #0x48]
10150dd48:     	ldur	q1, [x27, #0x58]
10150dd4c:     	stp	q0, q1, [x19]
10150dd50:     	ldur	q0, [x27, #0x68]
10150dd54:     	str	q0, [x19, #0x20]
10150dd58:     	ldr	x8, [sp, #0xf8]
10150dd5c:     	str	x8, [x19, #0x30]
10150dd60:     	b	0x10150dd6c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10150dd64:     	mov	w8, #0x2c               ; =44
10150dd68:     	strb	w8, [x19]
10150dd6c:     	ldp	x29, x30, [sp, #0x1c0]
10150dd70:     	ldp	x20, x19, [sp, #0x1b0]
10150dd74:     	ldp	x22, x21, [sp, #0x1a0]
10150dd78:     	ldp	x24, x23, [sp, #0x190]
10150dd7c:     	ldp	x26, x25, [sp, #0x180]
10150dd80:     	ldp	x28, x27, [sp, #0x170]
10150dd84:     	add	sp, sp, #0x1d0
10150dd88:     	ret
10150dd8c:     	ldp	x8, x9, [x28, #0x10]
10150dd90:     	stp	x8, x9, [sp, #0x18]
10150dd94:     	stp	x24, x22, [sp, #0x28]
10150dd98:     	stp	x23, x22, [sp, #0x38]
10150dd9c:     	mov	x10, sp
10150dda0:     	str	x10, [sp, #0x48]
10150dda4:     	ldr	x10, [x21, #0x60]
10150dda8:     	cmp	x10, #0x1
10150ddac:     	b.ne	0x10150debc <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x230>
10150ddb0:     	ldr	w10, [x21, #0x50]
10150ddb4:     	add	x22, sp, #0x80
10150ddb8:     	tbz	w10, #0x0, 0x10150dec8 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x23c>
10150ddbc:     	ldp	x11, x10, [x29, #0x18]
10150ddc0:     	ldr	x12, [x21, #0x68]
10150ddc4:     	ldr	x13, [x21, #0x58]
10150ddc8:     	ldp	x14, x15, [x28, #0x20]
10150ddcc:     	add	x16, x28, #0x50
10150ddd0:     	add	x17, x28, #0x30
10150ddd4:     	add	x0, x28, #0x38
10150ddd8:     	add	x1, x28, #0x40
10150dddc:     	add	x2, x28, #0x48
10150dde0:     	stp	x12, x13, [sp, #0xb8]
10150dde4:     	add	x12, sp, #0xb8
10150dde8:     	stp	x11, x12, [sp, #0xc8]
10150ddec:     	add	x12, sp, #0xc0
10150ddf0:     	stp	x12, x11, [sp, #0xd8]
10150ddf4:     	stp	x21, x10, [sp, #0xe8]
10150ddf8:     	stp	x8, x9, [sp, #0xf8]
10150ddfc:     	stp	x14, x15, [sp, #0x108]
10150de00:     	stp	x16, x28, [sp, #0x118]
10150de04:     	stp	x17, x0, [sp, #0x128]
10150de08:     	stp	x1, x2, [sp, #0x138]
10150de0c:     	add	x8, sp, #0x8
10150de10:     	stp	x8, x20, [sp, #0x148]
10150de14:     	add	x8, sp, #0x18
10150de18:     	str	x8, [sp, #0x158]
10150de1c:     	adrp	x0, 0x107f0d000 <_anon.7cbaf8f659a3b31eba05fca1d81c56df.677+0x10>
10150de20:     	add	x0, x0, #0xfb8
10150de24:     	add	x8, sp, #0x80
10150de28:     	add	x1, sp, #0xc8
10150de2c:     	bl	0x10162726c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>
10150de30:     	ldrb	w8, [sp, #0x80]
10150de34:     	cmp	w8, #0x2f
10150de38:     	b.ne	0x10150de84 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0x1f8>
10150de3c:     	ldur	q0, [x22, #0x8]
10150de40:     	stur	q0, [sp, #0x57]
10150de44:     	ldur	q1, [x22, #0x18]
10150de48:     	stur	q1, [sp, #0x67]
10150de4c:     	ldr	x8, [sp, #0xa8]
10150de50:     	stur	x8, [sp, #0x77]
10150de54:     	stur	q0, [x22, #0x4f]
10150de58:     	stur	q1, [x22, #0x5f]
10150de5c:     	stur	x8, [x22, #0x6f]
10150de60:     	mov	w8, #0x29               ; =41
10150de64:     	strb	w8, [x19]
10150de68:     	ldur	q0, [x22, #0x48]
10150de6c:     	stur	q0, [x19, #0x1]
10150de70:     	ldur	q0, [x22, #0x58]
10150de74:     	stur	q0, [x19, #0x11]
10150de78:     	ldur	q0, [x22, #0x67]
10150de7c:     	str	q0, [x19, #0x20]
10150de80:     	b	0x10150dd6c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10150de84:     	ldr	q0, [sp, #0xa0]
10150de88:     	stur	q0, [sp, #0x6f]
10150de8c:     	ldur	q0, [x22, #0x11]
10150de90:     	ldur	q1, [x22, #0x1]
10150de94:     	stp	q1, q0, [sp, #0x50]
10150de98:     	ldr	x9, [sp, #0xb0]
10150de9c:     	strb	w8, [x19]
10150dea0:     	stur	q1, [x19, #0x1]
10150dea4:     	ldr	q0, [sp, #0x60]
10150dea8:     	stur	q0, [x19, #0x11]
10150deac:     	ldur	q0, [sp, #0x6f]
10150deb0:     	str	q0, [x19, #0x20]
10150deb4:     	str	x9, [x19, #0x30]
10150deb8:     	b	0x10150dd6c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_+0xe0>
10150debc:     	adrp	x0, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
10150dec0:     	add	x0, x0, #0x1c0
10150dec4:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10150dec8:     	adrp	x0, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
10150decc:     	add	x0, x0, #0x1d8
10150ded0:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
