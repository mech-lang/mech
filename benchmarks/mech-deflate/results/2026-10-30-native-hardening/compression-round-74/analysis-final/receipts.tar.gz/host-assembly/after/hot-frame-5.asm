
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010152bb88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>:
10152bb88:     	stp	x28, x27, [sp, #-0x60]!
10152bb8c:     	stp	x26, x25, [sp, #0x10]
10152bb90:     	stp	x24, x23, [sp, #0x20]
10152bb94:     	stp	x22, x21, [sp, #0x30]
10152bb98:     	stp	x20, x19, [sp, #0x40]
10152bb9c:     	stp	x29, x30, [sp, #0x50]
10152bba0:     	add	x29, sp, #0x50
10152bba4:     	sub	sp, sp, #0x4c0
10152bba8:     	str	xzr, [sp]
10152bbac:     	ldr	x27, [x1, #0x4a0]
10152bbb0:     	ldr	x8, [x27, #0x4a0]
10152bbb4:     	cmp	x2, x8
10152bbb8:     	b.hs	0x10152bc84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
10152bbbc:     	mov	x22, x5
10152bbc0:     	mov	x23, x4
10152bbc4:     	mov	x20, x2
10152bbc8:     	mov	x21, x1
10152bbcc:     	add	x26, sp, #0x400
10152bbd0:     	ldr	x8, [x27, #0x498]
10152bbd4:     	mov	w9, #0x28               ; =40
10152bbd8:     	madd	x24, x2, x9, x8
10152bbdc:     	ldr	w8, [x24]
10152bbe0:     	cmp	w8, #0x1
10152bbe4:     	b.gt	0x10152bc68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe0>
10152bbe8:     	cbnz	w8, 0x10152bc98 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x110>
10152bbec:     	cbnz	x3, 0x10152beec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bbf0:     	ldr	x1, [x27, #0x380]
10152bbf4:     	cmp	x20, x1
10152bbf8:     	b.hs	0x10152cf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1380>
10152bbfc:     	ldr	x8, [x27, #0x378]
10152bc00:     	mov	w9, #0x170              ; =368
10152bc04:     	madd	x8, x20, x9, x8
10152bc08:     	ldp	x10, x9, [x8]
10152bc0c:     	cmp	x10, #0x2
10152bc10:     	sbcs	xzr, x9, xzr
10152bc14:     	b.hs	0x10152c0c0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x538>
10152bc18:     	ldr	w9, [x8, #0x130]
10152bc1c:     	ldr	w10, [x24, #0x4]
10152bc20:     	cmp	w9, w10
10152bc24:     	b.ne	0x10152c0dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
10152bc28:     	ldr	x9, [x8, #0x128]
10152bc2c:     	cmp	x22, x9
10152bc30:     	b.ne	0x10152c0dc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x554>
10152bc34:     	stp	x24, x0, [sp, #0x38]
10152bc38:     	add	x9, x27, #0x488
10152bc3c:     	ldr	x8, [x8, #0x120]
10152bc40:     	str	x8, [sp, #0x30]
10152bc44:     	lsl	x8, x22, #2
10152bc48:     	stp	x8, x9, [sp, #0x18]
10152bc4c:     	cbz	x22, 0x10152c2b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
10152bc50:     	mov	x10, #0x0               ; =0
10152bc54:     	mov	x25, #0x0               ; =0
10152bc58:     	ldr	x24, [x21, #0x490]
10152bc5c:     	ldr	x26, [sp, #0x18]
10152bc60:     	str	x24, [sp, #0x28]
10152bc64:     	b	0x10152bd24 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x19c>
10152bc68:     	cmp	w8, #0x2
10152bc6c:     	b.ne	0x10152bc84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfc>
10152bc70:     	cbz	x3, 0x10152bed8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x350>
10152bc74:     	cmp	x3, #0x12
10152bc78:     	b.ne	0x10152beec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bc7c:     	cbnz	x22, 0x10152beec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bc80:     	b	0x10152bf48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
10152bc84:     	mov	w8, #0x2                ; =2
10152bc88:     	str	x8, [x0, #0x8]
10152bc8c:     	mov	w8, #0x6                ; =6
10152bc90:     	str	w8, [x0]
10152bc94:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152bc98:     	cmp	x3, #0x1
10152bc9c:     	b.ne	0x10152beec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bca0:     	cbnz	x22, 0x10152beec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bca4:     	mov	x19, x0
10152bca8:     	add	x0, sp, #0x400
10152bcac:     	mov	x1, x21
10152bcb0:     	mov	x2, x20
10152bcb4:     	bl	0x10153eae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
10152bcb8:     	ldr	w8, [sp, #0x400]
10152bcbc:     	cmp	w8, #0x1
10152bcc0:     	b.ne	0x10152bf28 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3a0>
10152bcc4:     	ldr	w3, [sp, #0x404]
10152bcc8:     	ldr	w4, [sp, #0x408]
10152bccc:     	ldp	w8, w9, [x24, #0x4]
10152bcd0:     	cmp	w3, w8
10152bcd4:     	ccmp	w4, w9, #0x0, eq
10152bcd8:     	mov	x11, x19
10152bcdc:     	b.eq	0x10152c0f8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x570>
10152bce0:     	str	wzr, [x11]
10152bce4:     	mov	w8, #0xc                ; =12
10152bce8:     	strb	w8, [x11, #0x8]
10152bcec:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152bcf0:     	add	x8, x8, #0xc6b
10152bcf4:     	mov	w9, #0x2e               ; =46
10152bcf8:     	stp	x8, x9, [x11, #0x10]
10152bcfc:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152bd00:     	ldp	q0, q1, [sp, #0x2f0]
10152bd04:     	ldp	q2, q3, [sp, #0x310]
10152bd08:     	stp	q2, q3, [x24, #0x20]
10152bd0c:     	stp	q0, q1, [x24]
10152bd10:     	add	x10, x19, #0x40
10152bd14:     	add	x25, x25, #0x1
10152bd18:     	subs	x26, x26, #0x4
10152bd1c:     	ldr	x24, [sp, #0x28]
10152bd20:     	b.eq	0x10152c2b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x72c>
10152bd24:     	str	x26, [sp, #0x48]
10152bd28:     	ldr	x8, [x27, #0x360]
10152bd2c:     	ldr	x9, [sp, #0x30]
10152bd30:     	ldr	w1, [x9, x25, lsl #2]
10152bd34:     	cmp	x8, x1
10152bd38:     	b.ls	0x10152cef4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x136c>
10152bd3c:     	ldr	x8, [x27, #0x358]
10152bd40:     	mov	w9, #0x140              ; =320
10152bd44:     	umaddl	x8, w1, w9, x8
10152bd48:     	ldrb	w9, [x8, #0x124]
10152bd4c:     	cmp	w9, #0x7
10152bd50:     	b.ne	0x10152be1c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x294>
10152bd54:     	cmp	x25, x22
10152bd58:     	b.hs	0x10152cf18 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1390>
10152bd5c:     	ldr	x8, [x23, x25, lsl #3]
10152bd60:     	cbnz	x8, 0x10152c470 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x8e8>
10152bd64:     	ldr	x8, [x27, #0x490]
10152bd68:     	cmp	x8, x1
10152bd6c:     	b.ls	0x10152bda4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
10152bd70:     	ldr	x8, [sp, #0x20]
10152bd74:     	ldr	x8, [x8]
10152bd78:     	mov	w9, #0x18               ; =24
10152bd7c:     	umaddl	x8, w1, w9, x8
10152bd80:     	ldr	x9, [x8]
10152bd84:     	cmp	x9, #0x1
10152bd88:     	b.ne	0x10152bda4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
10152bd8c:     	ldp	x8, x9, [x8, #0x8]
10152bd90:     	adds	x8, x8, x9
10152bd94:     	b.hs	0x10152bda4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x21c>
10152bd98:     	ldr	x9, [x27, #0x4b0]
10152bd9c:     	cmp	x8, x9
10152bda0:     	b.ls	0x10152be6c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152bda4:     	mov	x26, x10
10152bda8:     	add	x8, sp, #0x400
10152bdac:     	add	x0, x24, #0xf0
10152bdb0:     	add	x2, x24, #0x2f8
10152bdb4:     	bl	0x1016370b0 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152bdb8:     	ldr	x8, [sp, #0x400]
10152bdbc:     	add	x9, sp, #0x400
10152bdc0:     	ldur	q0, [x9, #0x8]
10152bdc4:     	ldur	q1, [x9, #0x18]
10152bdc8:     	stp	q0, q1, [sp, #0x50]
10152bdcc:     	ldur	q0, [x9, #0x28]
10152bdd0:     	str	q0, [sp, #0x70]
10152bdd4:     	ldur	x9, [x9, #0x38]
10152bdd8:     	str	x9, [sp, #0x80]
10152bddc:     	cbz	x8, 0x10152c4b0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x928>
10152bde0:     	mov	w19, #0x0               ; =0
10152bde4:     	ldp	q0, q1, [sp, #0x50]
10152bde8:     	add	x10, sp, #0x2f0
10152bdec:     	stur	q0, [x10, #0x8]
10152bdf0:     	stur	q1, [x10, #0x18]
10152bdf4:     	ldr	q0, [sp, #0x70]
10152bdf8:     	stur	q0, [x10, #0x28]
10152bdfc:     	ldr	x9, [sp, #0x80]
10152be00:     	stur	x9, [x10, #0x38]
10152be04:     	mov	x10, x26
10152be08:     	str	x8, [sp, #0x2f0]
10152be0c:     	ldr	x1, [x24, #0xd8]
10152be10:     	cmp	x25, x1
10152be14:     	b.lo	0x10152be84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
10152be18:     	b	0x10152bec4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
10152be1c:     	cmp	x25, x22
10152be20:     	b.hs	0x10152cf2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13a4>
10152be24:     	ldr	x8, [x23, x25, lsl #3]
10152be28:     	cmp	w9, #0x3
10152be2c:     	b.gt	0x10152be48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2c0>
10152be30:     	sub	w9, w9, #0x1
10152be34:     	cmp	w9, #0x3
10152be38:     	b.lo	0x10152be6c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152be3c:     	cmp	x8, #0x2
10152be40:     	b.lo	0x10152be6c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152be44:     	b	0x10152c500 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152be48:     	cmp	w9, #0x4
10152be4c:     	b.eq	0x10152be64 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2dc>
10152be50:     	cmp	w9, #0x5
10152be54:     	b.ne	0x10152bea8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x320>
10152be58:     	cmp	x8, #0x10, lsl #12      ; =0x10000
10152be5c:     	b.lo	0x10152be6c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2e4>
10152be60:     	b	0x10152c500 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152be64:     	cmp	x8, #0x100
10152be68:     	b.hs	0x10152c500 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152be6c:     	mov	x8, #0x0                ; =0
10152be70:     	mov	w19, #0x1               ; =1
10152be74:     	str	x8, [sp, #0x2f0]
10152be78:     	ldr	x1, [x24, #0xd8]
10152be7c:     	cmp	x25, x1
10152be80:     	b.hs	0x10152bec4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x33c>
10152be84:     	ldr	x28, [x24, #0xd0]
10152be88:     	add	x24, x28, x10
10152be8c:     	ldr	x8, [x24]
10152be90:     	mov	x19, x10
10152be94:     	ldr	x26, [sp, #0x48]
10152be98:     	cbz	x8, 0x10152bd00 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
10152be9c:     	add	x0, x28, x19
10152bea0:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152bea4:     	b	0x10152bd00 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x178>
10152bea8:     	lsr	x8, x8, #32
10152beac:     	cbnz	x8, 0x10152c500 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x978>
10152beb0:     	mov	w19, #0x1               ; =1
10152beb4:     	str	x8, [sp, #0x2f0]
10152beb8:     	ldr	x1, [x24, #0xd8]
10152bebc:     	cmp	x25, x1
10152bec0:     	b.lo	0x10152be84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x2fc>
10152bec4:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152bec8:     	add	x2, x2, #0x888
10152becc:     	mov	x0, x25
10152bed0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152bed4:     	b	0x10152cfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152bed8:     	cmp	x22, #0x2
10152bedc:     	b.ne	0x10152beec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x364>
10152bee0:     	ldp	x9, x8, [x23]
10152bee4:     	orr	x8, x9, x8
10152bee8:     	cbz	x8, 0x10152bf48 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x3c0>
10152beec:     	str	wzr, [x0]
10152bef0:     	mov	w8, #0xc                ; =12
10152bef4:     	strb	w8, [x0, #0x8]
10152bef8:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152befc:     	add	x8, x8, #0xd9e
10152bf00:     	mov	w9, #0x34               ; =52
10152bf04:     	stp	x8, x9, [x0, #0x10]
10152bf08:     	add	sp, sp, #0x4c0
10152bf0c:     	ldp	x29, x30, [sp, #0x50]
10152bf10:     	ldp	x20, x19, [sp, #0x40]
10152bf14:     	ldp	x22, x21, [sp, #0x30]
10152bf18:     	ldp	x24, x23, [sp, #0x20]
10152bf1c:     	ldp	x26, x25, [sp, #0x10]
10152bf20:     	ldp	x28, x27, [sp], #0x60
10152bf24:     	ret
10152bf28:     	str	wzr, [x19]
10152bf2c:     	mov	w8, #0xc                ; =12
10152bf30:     	str	w8, [x19, #0x8]
10152bf34:     	adrp	x8, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
10152bf38:     	add	x8, x8, #0xcf9
10152bf3c:     	mov	w9, #0x27               ; =39
10152bf40:     	stp	x8, x9, [x19, #0x10]
10152bf44:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152bf48:     	ldr	x1, [x27, #0x380]
10152bf4c:     	cmp	x20, x1
10152bf50:     	b.hs	0x10152cf40 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13b8>
10152bf54:     	stp	x24, x0, [sp, #0x38]
10152bf58:     	ldr	x8, [x27, #0x378]
10152bf5c:     	mov	w9, #0x170              ; =368
10152bf60:     	madd	x26, x20, x9, x8
10152bf64:     	cbz	x3, 0x10152c228 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6a0>
10152bf68:     	cmp	x3, #0x12
10152bf6c:     	b.ne	0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152bf70:     	ldp	x9, x8, [x26]
10152bf74:     	eor	x9, x9, #0x3
10152bf78:     	orr	x8, x9, x8
10152bf7c:     	cbnz	x8, 0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152bf80:     	ldr	w22, [x26, #0x28]
10152bf84:     	ldr	x8, [sp, #0x38]
10152bf88:     	ldr	w8, [x8, #0x4]
10152bf8c:     	cmp	w22, w8
10152bf90:     	b.ne	0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152bf94:     	ldr	w24, [x26, #0x2c]
10152bf98:     	ldr	x8, [sp, #0x38]
10152bf9c:     	ldr	w8, [x8, #0x8]
10152bfa0:     	cmp	w24, w8
10152bfa4:     	b.ne	0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152bfa8:     	mov	x25, #0x0               ; =0
10152bfac:     	mov	w28, #0x3               ; =3
10152bfb0:     	add	x0, x27, #0x488
10152bfb4:     	mov	x1, x22
10152bfb8:     	bl	0x10153ea34 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine15native_artifact13buffer_framesNtB5_18NativeBufferFrames6fields>
10152bfbc:     	cbz	x0, 0x10152c48c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
10152bfc0:     	ldr	x8, [sp, #0x38]
10152bfc4:     	ldr	x23, [x8, #0x10]
10152bfc8:     	cmp	x23, x1
10152bfcc:     	b.hs	0x10152c48c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x904>
10152bfd0:     	add	x8, x0, x23, lsl #5
10152bfd4:     	ldrb	w9, [x8]
10152bfd8:     	cmp	w9, #0x2
10152bfdc:     	b.ne	0x10152c6b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
10152bfe0:     	ldp	x8, x9, [x8, #0x8]
10152bfe4:     	adds	x8, x8, x9
10152bfe8:     	b.hs	0x10152c6b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
10152bfec:     	ldr	x9, [x27, #0x4b0]
10152bff0:     	cmp	x8, x9
10152bff4:     	b.hi	0x10152c6b4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xb2c>
10152bff8:     	cmp	x28, #0x2
10152bffc:     	sbcs	xzr, x25, xzr
10152c000:     	b.hs	0x10152c81c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc94>
10152c004:     	ldr	x1, [x26, #0x128]
10152c008:     	cmp	x1, #0x1
10152c00c:     	b.ls	0x10152cfb8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1430>
10152c010:     	ldr	x8, [x26, #0x120]
10152c014:     	ldr	x25, [x21, #0x490]
10152c018:     	ldr	w1, [x8, #0x4]
10152c01c:     	add	x8, sp, #0x400
10152c020:     	add	x0, x25, #0xf0
10152c024:     	add	x2, x25, #0x2f8
10152c028:     	bl	0x1016370b0 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152c02c:     	add	x8, sp, #0x400
10152c030:     	ldur	q0, [x8, #0x8]
10152c034:     	ldur	q1, [x8, #0x18]
10152c038:     	stp	q0, q1, [sp, #0x150]
10152c03c:     	ldur	q0, [x8, #0x28]
10152c040:     	str	q0, [sp, #0x170]
10152c044:     	ldr	x8, [sp, #0x400]
10152c048:     	ldr	x9, [sp, #0x438]
10152c04c:     	str	x9, [sp, #0x180]
10152c050:     	cbz	x8, 0x10152c924 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd9c>
10152c054:     	ldp	q0, q1, [sp, #0x150]
10152c058:     	add	x9, sp, #0x230
10152c05c:     	stur	q0, [x9, #0x48]
10152c060:     	stur	q1, [x9, #0x58]
10152c064:     	ldr	q0, [sp, #0x170]
10152c068:     	stur	q0, [x9, #0x68]
10152c06c:     	ldr	x9, [sp, #0x180]
10152c070:     	str	x9, [sp, #0x2a8]
10152c074:     	str	x8, [sp, #0x270]
10152c078:     	ldr	x1, [x27, #0x408]
10152c07c:     	cmp	x20, x1
10152c080:     	b.hs	0x10152cfdc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1454>
10152c084:     	ldr	x8, [x27, #0x400]
10152c088:     	add	x23, x8, x20, lsl #9
10152c08c:     	ldp	x9, x8, [x23]
10152c090:     	eor	x9, x9, #0x2
10152c094:     	orr	x8, x9, x8
10152c098:     	cbnz	x8, 0x10152c944 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xdbc>
10152c09c:     	ldr	x10, [sp, #0x40]
10152c0a0:     	str	wzr, [x10]
10152c0a4:     	mov	w8, #0xc                ; =12
10152c0a8:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
10152c0ac:     	add	x9, x9, #0xd40
10152c0b0:     	stp	x8, x9, [x10, #0x8]
10152c0b4:     	mov	w8, #0x23               ; =35
10152c0b8:     	str	x8, [x10, #0x18]
10152c0bc:     	b	0x10152cdcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
10152c0c0:     	str	wzr, [x0]
10152c0c4:     	mov	w8, #0xc                ; =12
10152c0c8:     	strb	w8, [x0, #0x8]
10152c0cc:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152c0d0:     	add	x8, x8, #0xc43
10152c0d4:     	mov	w9, #0x28               ; =40
10152c0d8:     	b	0x10152bf04 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
10152c0dc:     	str	wzr, [x0]
10152c0e0:     	mov	w8, #0xc                ; =12
10152c0e4:     	strb	w8, [x0, #0x8]
10152c0e8:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152c0ec:     	add	x8, x8, #0xc21
10152c0f0:     	mov	w9, #0x22               ; =34
10152c0f4:     	b	0x10152bf04 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x37c>
10152c0f8:     	ldp	x8, x9, [x24, #0x18]
10152c0fc:     	lsl	x9, x9, #2
10152c100:     	stp	x24, x11, [sp, #0x38]
10152c104:     	cbz	x9, 0x10152c134 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ac>
10152c108:     	ldr	w10, [x8], #0x4
10152c10c:     	sub	x9, x9, #0x4
10152c110:     	cmp	w10, w3
10152c114:     	b.ne	0x10152c104 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x57c>
10152c118:     	ldr	x25, [x21, #0x490]
10152c11c:     	add	x0, sp, #0x400
10152c120:     	add	x1, x25, #0x3c0
10152c124:     	add	x2, x27, #0x488
10152c128:     	add	x5, x25, #0x2f8
10152c12c:     	bl	0x101522878 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb1_EBb_>
10152c130:     	b	0x10152c14c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5c4>
10152c134:     	ldr	x25, [x21, #0x490]
10152c138:     	add	x0, sp, #0x400
10152c13c:     	add	x1, x25, #0x3c0
10152c140:     	add	x2, x27, #0x488
10152c144:     	add	x5, x25, #0x2f8
10152c148:     	bl	0x101522554 <__RINvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB3_12BufferFrames4copyKb0_EBb_>
10152c14c:     	ldr	w8, [sp, #0x400]
10152c150:     	cmp	w8, #0x6
10152c154:     	b.ne	0x10152c858 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
10152c158:     	mov	x22, #0x0               ; =0
10152c15c:     	ldr	x9, [sp, #0x38]
10152c160:     	ldr	x8, [x9, #0x20]
10152c164:     	cbz	x8, 0x10152c2a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
10152c168:     	ldr	x23, [x9, #0x18]
10152c16c:     	lsl	x24, x8, #2
10152c170:     	b	0x10152c17c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5f4>
10152c174:     	subs	x24, x24, #0x4
10152c178:     	b.eq	0x10152c2a0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x718>
10152c17c:     	ldr	w20, [x23], #0x4
10152c180:     	add	x8, sp, #0x400
10152c184:     	add	x0, x25, #0x3c0
10152c188:     	add	x1, x27, #0x4d0
10152c18c:     	add	x3, x25, #0x2f8
10152c190:     	mov	x2, x20
10152c194:     	bl	0x10152b5d8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames6retire>
10152c198:     	ldr	w9, [sp, #0x400]
10152c19c:     	ldrb	w8, [sp, #0x404]
10152c1a0:     	cmp	w9, #0x6
10152c1a4:     	b.ne	0x10152c2fc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x774>
10152c1a8:     	tbnz	w8, #0x0, 0x10152c174 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
10152c1ac:     	add	x8, sp, #0x400
10152c1b0:     	add	x0, x25, #0xf0
10152c1b4:     	add	x2, x25, #0x2f8
10152c1b8:     	mov	x1, x20
10152c1bc:     	bl	0x1016376bc <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena14retire_current>
10152c1c0:     	ldrb	w8, [sp, #0x400]
10152c1c4:     	cmp	w8, #0x14
10152c1c8:     	b.eq	0x10152c174 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5ec>
10152c1cc:     	ldr	q0, [sp, #0x400]
10152c1d0:     	ldr	q1, [sp, #0x410]
10152c1d4:     	stp	q0, q1, [sp, #0x2f0]
10152c1d8:     	ldr	q2, [sp, #0x420]
10152c1dc:     	str	q2, [sp, #0x310]
10152c1e0:     	ldr	x8, [sp, #0x430]
10152c1e4:     	str	x8, [sp, #0x320]
10152c1e8:     	stur	q0, [x26, #0x4]
10152c1ec:     	stur	q1, [x26, #0x14]
10152c1f0:     	stur	q2, [x26, #0x24]
10152c1f4:     	stur	x8, [x26, #0x34]
10152c1f8:     	mov	w8, #0x2                ; =2
10152c1fc:     	ldr	x9, [sp, #0x40]
10152c200:     	str	w8, [x9]
10152c204:     	ldr	q0, [sp, #0x400]
10152c208:     	ldr	q1, [sp, #0x410]
10152c20c:     	stur	q0, [x9, #0x4]
10152c210:     	stur	q1, [x9, #0x14]
10152c214:     	ldr	q0, [sp, #0x420]
10152c218:     	stur	q0, [x9, #0x24]
10152c21c:     	ldur	q0, [x26, #0x2c]
10152c220:     	str	q0, [x9, #0x30]
10152c224:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c228:     	ldp	x28, x25, [x26]
10152c22c:     	cmp	x28, #0x2
10152c230:     	sbcs	xzr, x25, xzr
10152c234:     	b.hs	0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c238:     	ldr	x8, [x26, #0x128]
10152c23c:     	cmp	x8, #0x2
10152c240:     	b.ne	0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c244:     	ldr	x8, [x26, #0x120]
10152c248:     	ldr	w22, [x8]
10152c24c:     	ldr	x8, [sp, #0x38]
10152c250:     	ldr	w8, [x8, #0x4]
10152c254:     	cmp	w22, w8
10152c258:     	b.ne	0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c25c:     	ldr	w24, [x26, #0x130]
10152c260:     	ldr	x8, [sp, #0x38]
10152c264:     	ldr	w8, [x8, #0x8]
10152c268:     	cmp	w24, w8
10152c26c:     	b.ne	0x10152c27c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x6f4>
10152c270:     	ldr	x8, [x26, #0x10]
10152c274:     	cmp	x8, #0xb
10152c278:     	b.eq	0x10152bfb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x428>
10152c27c:     	ldr	x10, [sp, #0x40]
10152c280:     	str	wzr, [x10]
10152c284:     	mov	w8, #0xc                ; =12
10152c288:     	strb	w8, [x10, #0x8]
10152c28c:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152c290:     	add	x8, x8, #0xd73
10152c294:     	mov	w9, #0x2b               ; =43
10152c298:     	stp	x8, x9, [x10, #0x10]
10152c29c:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c2a0:     	ldr	x9, [sp, #0x40]
10152c2a4:     	stp	x22, x21, [x9, #0x8]
10152c2a8:     	mov	w8, #0x6                ; =6
10152c2ac:     	str	w8, [x9]
10152c2b0:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c2b4:     	ldr	x1, [x27, #0x408]
10152c2b8:     	cmp	x20, x1
10152c2bc:     	b.hs	0x10152cf50 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13c8>
10152c2c0:     	ldr	x8, [x27, #0x400]
10152c2c4:     	add	x28, x8, x20, lsl #9
10152c2c8:     	ldp	x9, x8, [x28]
10152c2cc:     	eor	x9, x9, #0x2
10152c2d0:     	orr	x8, x9, x8
10152c2d4:     	ldr	x19, [sp, #0x40]
10152c2d8:     	cbnz	x8, 0x10152c334 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7ac>
10152c2dc:     	str	wzr, [x19]
10152c2e0:     	mov	w8, #0xc                ; =12
10152c2e4:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
10152c2e8:     	add	x9, x9, #0xcd6
10152c2ec:     	stp	x8, x9, [x19, #0x8]
10152c2f0:     	mov	w8, #0x23               ; =35
10152c2f4:     	str	x8, [x19, #0x18]
10152c2f8:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c2fc:     	ldur	q0, [x26, #0x15]
10152c300:     	ldr	x10, [sp, #0x40]
10152c304:     	stur	q0, [x10, #0x15]
10152c308:     	ldur	q0, [x26, #0x25]
10152c30c:     	stur	q0, [x10, #0x25]
10152c310:     	ldur	q0, [x26, #0x35]
10152c314:     	stur	q0, [x10, #0x35]
10152c318:     	ldr	q0, [sp, #0x440]
10152c31c:     	str	q0, [x10, #0x40]
10152c320:     	ldur	q0, [x26, #0x5]
10152c324:     	stur	q0, [x10, #0x5]
10152c328:     	str	w9, [x10]
10152c32c:     	strb	w8, [x10, #0x4]
10152c330:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c334:     	add	x24, sp, #0x400
10152c338:     	add	x8, sp, #0x400
10152c33c:     	mov	x0, x21
10152c340:     	mov	w1, #0x0                ; =0
10152c344:     	bl	0x10154aca8 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10152c348:     	ldr	w8, [sp, #0x400]
10152c34c:     	tbz	w8, #0x0, 0x10152c380 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x7f8>
10152c350:     	ldur	q0, [x24, #0x18]
10152c354:     	ldur	q1, [x24, #0x28]
10152c358:     	ldur	q2, [x24, #0x38]
10152c35c:     	stp	q1, q2, [sp, #0x310]
10152c360:     	ldur	q3, [x24, #0x48]
10152c364:     	str	q3, [sp, #0x330]
10152c368:     	ldur	q4, [x24, #0x8]
10152c36c:     	stp	q4, q0, [sp, #0x2f0]
10152c370:     	stp	q1, q2, [x19, #0x20]
10152c374:     	str	q3, [x19, #0x40]
10152c378:     	stp	q4, q0, [x19]
10152c37c:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c380:     	ldr	x10, [sp, #0x30]
10152c384:     	ldr	x8, [sp, #0x18]
10152c388:     	add	x8, x10, x8
10152c38c:     	ldur	q0, [x24, #0x48]
10152c390:     	ldur	q1, [x24, #0x58]
10152c394:     	stp	q0, q1, [sp, #0x330]
10152c398:     	ldur	x9, [x24, #0x68]
10152c39c:     	str	x9, [sp, #0x350]
10152c3a0:     	ldur	q2, [x24, #0x8]
10152c3a4:     	str	q2, [sp, #0x2f0]
10152c3a8:     	ldur	q3, [x24, #0x38]
10152c3ac:     	ldur	q4, [x24, #0x18]
10152c3b0:     	ldur	q5, [x24, #0x28]
10152c3b4:     	stp	q2, q4, [sp, #0x90]
10152c3b8:     	stp	q5, q3, [sp, #0xb0]
10152c3bc:     	str	x9, [sp, #0xf0]
10152c3c0:     	stp	q0, q1, [sp, #0xd0]
10152c3c4:     	str	x10, [sp, #0x400]
10152c3c8:     	str	x8, [sp, #0x408]
10152c3cc:     	add	x0, sp, #0x400
10152c3d0:     	add	x1, x27, #0x488
10152c3d4:     	bl	0x101527cd0 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>
10152c3d8:     	ldr	x25, [x21, #0x490]
10152c3dc:     	ldr	x2, [x25, #0xd8]
10152c3e0:     	cmp	x22, x2
10152c3e4:     	add	x26, sp, #0x400
10152c3e8:     	tbz	w0, #0x0, 0x10152c520 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x998>
10152c3ec:     	b.hi	0x10152ce88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1300>
10152c3f0:     	ldr	x1, [x25, #0xd0]
10152c3f4:     	ldp	q0, q1, [x21, #0x80]
10152c3f8:     	str	q0, [sp, #0x480]
10152c3fc:     	str	q1, [sp, #0x490]
10152c400:     	ldr	x8, [x21, #0xa0]
10152c404:     	str	x8, [sp, #0x4a0]
10152c408:     	ldp	q0, q1, [x21, #0x40]
10152c40c:     	str	q0, [sp, #0x440]
10152c410:     	str	q1, [sp, #0x450]
10152c414:     	ldp	q1, q0, [x21, #0x60]
10152c418:     	str	q0, [sp, #0x470]
10152c41c:     	str	q1, [sp, #0x460]
10152c420:     	ldp	q0, q1, [x21]
10152c424:     	str	q0, [sp, #0x400]
10152c428:     	str	q1, [sp, #0x410]
10152c42c:     	ldp	q1, q0, [x21, #0x20]
10152c430:     	add	x8, x25, #0x3b8
10152c434:     	str	q0, [sp, #0x430]
10152c438:     	str	q1, [sp, #0x420]
10152c43c:     	add	x9, sp, #0x90
10152c440:     	stp	x8, x9, [sp, #0x8]
10152c444:     	add	x9, sp, #0x400
10152c448:     	str	x9, [sp]
10152c44c:     	add	x8, sp, #0xf8
10152c450:     	add	x5, x25, #0x3c0
10152c454:     	mov	x0, x28
10152c458:     	mov	x2, x22
10152c45c:     	mov	x3, x23
10152c460:     	mov	x4, x22
10152c464:     	mov	x6, #0x0                ; =0
10152c468:     	bl	0x10150da44 <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions0_0EB35_>
10152c46c:     	b	0x10152c590 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xa08>
10152c470:     	ldr	x10, [sp, #0x40]
10152c474:     	str	wzr, [x10]
10152c478:     	mov	w8, #0xc                ; =12
10152c47c:     	strb	w8, [x10, #0x8]
10152c480:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152c484:     	add	x8, x8, #0xbcc
10152c488:     	b	0x10152c294 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x70c>
10152c48c:     	ldr	x10, [sp, #0x40]
10152c490:     	str	wzr, [x10]
10152c494:     	mov	w8, #0xc                ; =12
10152c498:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
10152c49c:     	add	x9, x9, #0xd20
10152c4a0:     	stp	x8, x9, [x10, #0x8]
10152c4a4:     	mov	w8, #0x20               ; =32
10152c4a8:     	str	x8, [x10, #0x18]
10152c4ac:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c4b0:     	ldp	q0, q1, [sp, #0x50]
10152c4b4:     	add	x9, sp, #0x400
10152c4b8:     	stur	q0, [x9, #0x4]
10152c4bc:     	stur	q1, [x9, #0x14]
10152c4c0:     	ldr	q0, [sp, #0x70]
10152c4c4:     	stur	q0, [x9, #0x24]
10152c4c8:     	ldr	x8, [sp, #0x80]
10152c4cc:     	stur	x8, [x9, #0x34]
10152c4d0:     	ldr	q0, [sp, #0x400]
10152c4d4:     	ldr	q1, [sp, #0x410]
10152c4d8:     	ldr	x10, [sp, #0x40]
10152c4dc:     	stur	q0, [x10, #0x4]
10152c4e0:     	mov	w8, #0x2                ; =2
10152c4e4:     	str	w8, [x10]
10152c4e8:     	stur	q1, [x10, #0x14]
10152c4ec:     	ldr	q0, [sp, #0x420]
10152c4f0:     	stur	q0, [x10, #0x24]
10152c4f4:     	ldur	q0, [x9, #0x2c]
10152c4f8:     	str	q0, [x10, #0x30]
10152c4fc:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c500:     	ldr	x10, [sp, #0x40]
10152c504:     	str	wzr, [x10]
10152c508:     	mov	w8, #0xc                ; =12
10152c50c:     	strb	w8, [x10, #0x8]
10152c510:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152c514:     	add	x8, x8, #0xbf7
10152c518:     	mov	w9, #0x2a               ; =42
10152c51c:     	b	0x10152c298 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
10152c520:     	b.hi	0x10152ce9c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1314>
10152c524:     	ldr	x1, [x25, #0xd0]
10152c528:     	ldp	q0, q1, [x21, #0x80]
10152c52c:     	str	q0, [sp, #0x480]
10152c530:     	str	q1, [sp, #0x490]
10152c534:     	ldr	x8, [x21, #0xa0]
10152c538:     	str	x8, [sp, #0x4a0]
10152c53c:     	ldp	q0, q1, [x21, #0x40]
10152c540:     	str	q0, [sp, #0x440]
10152c544:     	str	q1, [sp, #0x450]
10152c548:     	ldp	q1, q0, [x21, #0x60]
10152c54c:     	str	q0, [sp, #0x470]
10152c550:     	str	q1, [sp, #0x460]
10152c554:     	ldp	q0, q1, [x21]
10152c558:     	str	q0, [sp, #0x400]
10152c55c:     	str	q1, [sp, #0x410]
10152c560:     	ldp	q1, q0, [x21, #0x20]
10152c564:     	str	q0, [sp, #0x430]
10152c568:     	str	q1, [sp, #0x420]
10152c56c:     	add	x8, sp, #0xf8
10152c570:     	add	x5, sp, #0x400
10152c574:     	add	x6, x25, #0x3b8
10152c578:     	add	x7, sp, #0x90
10152c57c:     	mov	x0, x28
10152c580:     	mov	x2, x22
10152c584:     	mov	x3, x23
10152c588:     	mov	x4, x22
10152c58c:     	bl	0x10253bd08 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_frame_words>
10152c590:     	ldrb	w8, [sp, #0xf8]
10152c594:     	cmp	w8, #0x2e
10152c598:     	b.ne	0x10152c638 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xab0>
10152c59c:     	ldr	x2, [x25, #0xd8]
10152c5a0:     	cmp	x22, x2
10152c5a4:     	b.hi	0x10152ceb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1328>
10152c5a8:     	ldr	x6, [x25, #0xd0]
10152c5ac:     	ldp	x4, x8, [sp, #0x30]
10152c5b0:     	ldr	w3, [x8, #0x4]
10152c5b4:     	add	x8, x25, #0x2f8
10152c5b8:     	stp	x22, x8, [sp, #0x8]
10152c5bc:     	add	x0, sp, #0x400
10152c5c0:     	add	x1, x25, #0x3c0
10152c5c4:     	add	x2, x27, #0x488
10152c5c8:     	str	x23, [sp]
10152c5cc:     	mov	x5, x22
10152c5d0:     	mov	x7, x22
10152c5d4:     	bl	0x10152aed8 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames4pack>
10152c5d8:     	ldr	x2, [x25, #0xd8]
10152c5dc:     	cmp	x22, x2
10152c5e0:     	b.hi	0x10152cedc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1354>
10152c5e4:     	ldr	x0, [x25, #0xd0]
10152c5e8:     	str	xzr, [sp, #0x2f0]
10152c5ec:     	add	x2, sp, #0x2f0
10152c5f0:     	mov	x1, x22
10152c5f4:     	bl	0x1016132bc <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
10152c5f8:     	ldr	w8, [sp, #0x400]
10152c5fc:     	cmp	w8, #0x6
10152c600:     	b.eq	0x10152c158 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d0>
10152c604:     	ldur	q0, [x26, #0x14]
10152c608:     	ldr	x9, [sp, #0x40]
10152c60c:     	stur	q0, [x9, #0x14]
10152c610:     	ldur	q0, [x26, #0x24]
10152c614:     	stur	q0, [x9, #0x24]
10152c618:     	ldur	q0, [x26, #0x34]
10152c61c:     	stur	q0, [x9, #0x34]
10152c620:     	ldr	q0, [sp, #0x440]
10152c624:     	str	q0, [x9, #0x40]
10152c628:     	ldur	q0, [x26, #0x4]
10152c62c:     	stur	q0, [x9, #0x4]
10152c630:     	str	w8, [x9]
10152c634:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c638:     	ldr	x2, [x25, #0xd8]
10152c63c:     	cmp	x22, x2
10152c640:     	b.hi	0x10152cec4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x133c>
10152c644:     	ldr	x0, [x25, #0xd0]
10152c648:     	str	xzr, [sp, #0x400]
10152c64c:     	add	x2, sp, #0x400
10152c650:     	mov	x1, x22
10152c654:     	bl	0x1016132bc <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
10152c658:     	ldr	x1, [x27, #0x380]
10152c65c:     	cmp	x20, x1
10152c660:     	b.hs	0x10152cf60 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13d8>
10152c664:     	ldr	x8, [x27, #0x378]
10152c668:     	mov	w9, #0x170              ; =368
10152c66c:     	madd	x8, x20, x9, x8
10152c670:     	ldr	w9, [x8, #0x158]
10152c674:     	add	x10, sp, #0xf8
10152c678:     	add	x8, x8, #0x148
10152c67c:     	ldr	q0, [x8]
10152c680:     	ldp	q1, q2, [x10]
10152c684:     	ldr	x11, [sp, #0x40]
10152c688:     	stur	q1, [x11, #0x18]
10152c68c:     	stur	q2, [x11, #0x28]
10152c690:     	ldr	q1, [x10, #0x20]
10152c694:     	stur	q1, [x11, #0x38]
10152c698:     	ldr	x8, [sp, #0x128]
10152c69c:     	str	x8, [x11, #0x48]
10152c6a0:     	mov	w8, #0x3                ; =3
10152c6a4:     	str	w8, [x11]
10152c6a8:     	stur	q0, [x11, #0x4]
10152c6ac:     	str	w9, [x11, #0x14]
10152c6b0:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c6b4:     	ldr	x25, [x21, #0x490]
10152c6b8:     	ldr	x1, [x25, #0x3c0]
10152c6bc:     	add	x0, sp, #0x400
10152c6c0:     	add	x2, x27, #0x488
10152c6c4:     	add	x5, x25, #0x2f8
10152c6c8:     	mov	x3, x22
10152c6cc:     	mov	x4, x23
10152c6d0:     	bl	0x10152b840 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames7project>
10152c6d4:     	ldr	w8, [sp, #0x400]
10152c6d8:     	cmp	w8, #0x6
10152c6dc:     	b.ne	0x10152c7d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc48>
10152c6e0:     	add	x8, sp, #0x400
10152c6e4:     	ldur	q0, [x8, #0x38]
10152c6e8:     	ldur	q1, [x8, #0x28]
10152c6ec:     	ldur	q2, [x8, #0x18]
10152c6f0:     	ldur	q3, [x8, #0x8]
10152c6f4:     	stp	q3, q2, [sp, #0x230]
10152c6f8:     	stp	q1, q0, [sp, #0x250]
10152c6fc:     	ldp	x9, x8, [x26]
10152c700:     	mov	w10, #0x1               ; =1
10152c704:     	cmp	x10, x9
10152c708:     	ngcs	xzr, x8
10152c70c:     	b.lo	0x10152cbb8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1030>
10152c710:     	ldr	x8, [x26, #0x128]
10152c714:     	cmp	x8, #0x2
10152c718:     	b.lo	0x10152cf80 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13f8>
10152c71c:     	ldr	x8, [x26, #0x120]
10152c720:     	ldr	w1, [x8, #0x4]
10152c724:     	mov	w22, #0x1               ; =1
10152c728:     	add	x8, sp, #0x400
10152c72c:     	add	x0, x25, #0xf0
10152c730:     	add	x2, x25, #0x2f8
10152c734:     	bl	0x1016370b0 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10152c738:     	add	x8, sp, #0x400
10152c73c:     	ldur	q0, [x8, #0x8]
10152c740:     	ldur	q1, [x8, #0x18]
10152c744:     	stp	q0, q1, [sp, #0x2b0]
10152c748:     	ldur	q0, [x8, #0x28]
10152c74c:     	str	q0, [sp, #0x2d0]
10152c750:     	ldr	x8, [sp, #0x400]
10152c754:     	ldr	x9, [sp, #0x438]
10152c758:     	str	x9, [sp, #0x2e0]
10152c75c:     	cbz	x8, 0x10152c880 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcf8>
10152c760:     	ldp	q0, q1, [sp, #0x2b0]
10152c764:     	add	x9, sp, #0x230
10152c768:     	stur	q0, [x9, #0x48]
10152c76c:     	stur	q1, [x9, #0x58]
10152c770:     	ldr	q0, [sp, #0x2d0]
10152c774:     	add	x26, sp, #0x230
10152c778:     	stur	q0, [x9, #0x68]
10152c77c:     	ldr	x9, [sp, #0x2e0]
10152c780:     	str	x9, [sp, #0x2a8]
10152c784:     	str	x8, [sp, #0x270]
10152c788:     	ldr	x1, [x27, #0x408]
10152c78c:     	cmp	x20, x1
10152c790:     	b.hs	0x10152cfc8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1440>
10152c794:     	ldr	x8, [x27, #0x400]
10152c798:     	add	x22, x8, x20, lsl #9
10152c79c:     	ldp	x9, x8, [x22]
10152c7a0:     	eor	x9, x9, #0x2
10152c7a4:     	orr	x8, x9, x8
10152c7a8:     	cbnz	x8, 0x10152c8d0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xd48>
10152c7ac:     	ldr	x10, [sp, #0x40]
10152c7b0:     	str	wzr, [x10]
10152c7b4:     	mov	w8, #0xc                ; =12
10152c7b8:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
10152c7bc:     	add	x9, x9, #0xd63
10152c7c0:     	stp	x8, x9, [x10, #0x8]
10152c7c4:     	mov	w8, #0x2a               ; =42
10152c7c8:     	str	x8, [x10, #0x18]
10152c7cc:     	b	0x10152cd58 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
10152c7d0:     	add	x10, sp, #0x400
10152c7d4:     	ldur	q0, [x10, #0x14]
10152c7d8:     	ldur	q1, [x10, #0x24]
10152c7dc:     	ldur	q2, [x10, #0x34]
10152c7e0:     	stp	q1, q2, [sp, #0x310]
10152c7e4:     	ldr	w9, [sp, #0x444]
10152c7e8:     	str	w9, [sp, #0x330]
10152c7ec:     	ldur	q3, [x10, #0x4]
10152c7f0:     	stp	q3, q0, [sp, #0x2f0]
10152c7f4:     	ldr	x10, [sp, #0x448]
10152c7f8:     	ldr	x11, [sp, #0x40]
10152c7fc:     	stur	q0, [x11, #0x14]
10152c800:     	stur	q1, [x11, #0x24]
10152c804:     	stur	q2, [x11, #0x34]
10152c808:     	str	w9, [x11, #0x44]
10152c80c:     	stur	q3, [x11, #0x4]
10152c810:     	str	w8, [x11]
10152c814:     	str	x10, [x11, #0x48]
10152c818:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c81c:     	ldr	x25, [x21, #0x490]
10152c820:     	add	x0, sp, #0x400
10152c824:     	add	x1, x25, #0x3c0
10152c828:     	add	x2, x27, #0x488
10152c82c:     	add	x6, x25, #0x2f8
10152c830:     	mov	x3, x22
10152c834:     	mov	x4, x23
10152c838:     	mov	x5, x24
10152c83c:     	bl	0x10152a26c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames17project_composite>
10152c840:     	ldr	w8, [sp, #0x400]
10152c844:     	cmp	w8, #0x6
10152c848:     	b.ne	0x10152c858 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcd0>
10152c84c:     	mov	x22, #0x0               ; =0
10152c850:     	add	x26, sp, #0x400
10152c854:     	b	0x10152c15c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10152c858:     	ldr	q0, [sp, #0x420]
10152c85c:     	ldr	q1, [sp, #0x430]
10152c860:     	ldr	x8, [sp, #0x40]
10152c864:     	stp	q0, q1, [x8, #0x20]
10152c868:     	ldr	q0, [sp, #0x440]
10152c86c:     	str	q0, [x8, #0x40]
10152c870:     	ldr	q0, [sp, #0x410]
10152c874:     	ldr	q1, [sp, #0x400]
10152c878:     	stp	q1, q0, [x8]
10152c87c:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152c880:     	ldp	q0, q1, [sp, #0x2b0]
10152c884:     	add	x9, sp, #0x400
10152c888:     	stur	q0, [x9, #0x4]
10152c88c:     	stur	q1, [x9, #0x14]
10152c890:     	ldr	q0, [sp, #0x2d0]
10152c894:     	stur	q0, [x9, #0x24]
10152c898:     	ldr	x8, [sp, #0x2e0]
10152c89c:     	stur	x8, [x9, #0x34]
10152c8a0:     	ldr	q0, [sp, #0x400]
10152c8a4:     	ldr	q1, [sp, #0x410]
10152c8a8:     	ldr	x10, [sp, #0x40]
10152c8ac:     	stur	q0, [x10, #0x4]
10152c8b0:     	mov	w8, #0x2                ; =2
10152c8b4:     	str	w8, [x10]
10152c8b8:     	stur	q1, [x10, #0x14]
10152c8bc:     	ldr	q0, [sp, #0x420]
10152c8c0:     	stur	q0, [x10, #0x24]
10152c8c4:     	ldur	q0, [x9, #0x2c]
10152c8c8:     	str	q0, [x10, #0x30]
10152c8cc:     	b	0x10152cd64 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11dc>
10152c8d0:     	add	x24, sp, #0x400
10152c8d4:     	add	x8, sp, #0x400
10152c8d8:     	mov	x0, x21
10152c8dc:     	mov	w1, #0x0                ; =0
10152c8e0:     	bl	0x10154aca8 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10152c8e4:     	ldr	x8, [sp, #0x400]
10152c8e8:     	cmp	x8, #0x1
10152c8ec:     	b.ne	0x10152c998 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xe10>
10152c8f0:     	ldur	q0, [x24, #0x18]
10152c8f4:     	ldur	q1, [x24, #0x28]
10152c8f8:     	ldur	q2, [x24, #0x38]
10152c8fc:     	stp	q1, q2, [sp, #0x310]
10152c900:     	ldur	q3, [x24, #0x48]
10152c904:     	str	q3, [sp, #0x330]
10152c908:     	ldur	q4, [x24, #0x8]
10152c90c:     	stp	q4, q0, [sp, #0x2f0]
10152c910:     	ldr	x8, [sp, #0x40]
10152c914:     	stp	q1, q2, [x8, #0x20]
10152c918:     	str	q3, [x8, #0x40]
10152c91c:     	stp	q4, q0, [x8]
10152c920:     	b	0x10152cd58 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11d0>
10152c924:     	ldp	q0, q1, [sp, #0x150]
10152c928:     	add	x9, sp, #0x400
10152c92c:     	stur	q0, [x9, #0x4]
10152c930:     	stur	q1, [x9, #0x14]
10152c934:     	ldr	q0, [sp, #0x170]
10152c938:     	stur	q0, [x9, #0x24]
10152c93c:     	ldr	x8, [sp, #0x180]
10152c940:     	b	0x10152c4cc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x944>
10152c944:     	add	x24, sp, #0x400
10152c948:     	add	x8, sp, #0x400
10152c94c:     	mov	x0, x21
10152c950:     	mov	w1, #0x0                ; =0
10152c954:     	bl	0x10154aca8 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
10152c958:     	ldr	x8, [sp, #0x400]
10152c95c:     	cmp	x8, #0x1
10152c960:     	b.ne	0x10152ca44 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xebc>
10152c964:     	ldur	q0, [x24, #0x18]
10152c968:     	ldur	q1, [x24, #0x28]
10152c96c:     	ldur	q2, [x24, #0x38]
10152c970:     	stp	q1, q2, [sp, #0x310]
10152c974:     	ldur	q3, [x24, #0x48]
10152c978:     	str	q3, [sp, #0x330]
10152c97c:     	ldur	q4, [x24, #0x8]
10152c980:     	stp	q4, q0, [sp, #0x2f0]
10152c984:     	ldr	x8, [sp, #0x40]
10152c988:     	stp	q1, q2, [x8, #0x20]
10152c98c:     	str	q3, [x8, #0x40]
10152c990:     	stp	q4, q0, [x8]
10152c994:     	b	0x10152cdcc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1244>
10152c998:     	ldur	q0, [x24, #0x48]
10152c99c:     	ldur	q1, [x24, #0x58]
10152c9a0:     	stp	q0, q1, [sp, #0x330]
10152c9a4:     	ldur	x8, [x24, #0x68]
10152c9a8:     	str	x8, [sp, #0x350]
10152c9ac:     	ldur	q2, [x24, #0x8]
10152c9b0:     	ldur	q3, [x24, #0x18]
10152c9b4:     	stp	q2, q3, [sp, #0x2f0]
10152c9b8:     	ldur	q4, [x24, #0x38]
10152c9bc:     	ldur	q5, [x24, #0x28]
10152c9c0:     	stp	q2, q3, [sp, #0x360]
10152c9c4:     	stp	q5, q4, [sp, #0x380]
10152c9c8:     	str	x8, [sp, #0x3c0]
10152c9cc:     	stp	q0, q1, [sp, #0x3a0]
10152c9d0:     	ldr	x8, [sp, #0x230]
10152c9d4:     	cbz	x8, 0x10152cb2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xfa4>
10152c9d8:     	ldp	q0, q1, [x21, #0x80]
10152c9dc:     	str	q0, [sp, #0x480]
10152c9e0:     	str	q1, [sp, #0x490]
10152c9e4:     	ldr	x8, [x21, #0xa0]
10152c9e8:     	str	x8, [sp, #0x4a0]
10152c9ec:     	ldp	q0, q1, [x21, #0x40]
10152c9f0:     	str	q0, [sp, #0x440]
10152c9f4:     	str	q1, [sp, #0x450]
10152c9f8:     	ldp	q1, q0, [x21, #0x60]
10152c9fc:     	str	q0, [sp, #0x470]
10152ca00:     	str	q1, [sp, #0x460]
10152ca04:     	ldp	q0, q1, [x21]
10152ca08:     	str	q0, [sp, #0x400]
10152ca0c:     	str	q1, [sp, #0x410]
10152ca10:     	ldp	q1, q0, [x21, #0x20]
10152ca14:     	str	q0, [sp, #0x430]
10152ca18:     	str	q1, [sp, #0x420]
10152ca1c:     	add	x8, sp, #0x3c8
10152ca20:     	add	x1, sp, #0x270
10152ca24:     	add	x3, sp, #0x230
10152ca28:     	add	x4, sp, #0x400
10152ca2c:     	add	x5, x25, #0x3b8
10152ca30:     	add	x6, sp, #0x360
10152ca34:     	mov	x0, x22
10152ca38:     	mov	x2, x23
10152ca3c:     	bl	0x10253c0ac <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall25admit_buffer_record_field>
10152ca40:     	b	0x10152cba0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1018>
10152ca44:     	ldur	q0, [x24, #0x48]
10152ca48:     	ldur	q1, [x24, #0x58]
10152ca4c:     	stp	q0, q1, [sp, #0x330]
10152ca50:     	ldur	x8, [x24, #0x68]
10152ca54:     	str	x8, [sp, #0x350]
10152ca58:     	ldur	q2, [x24, #0x8]
10152ca5c:     	ldur	q3, [x24, #0x18]
10152ca60:     	stp	q2, q3, [sp, #0x2f0]
10152ca64:     	ldur	q4, [x24, #0x38]
10152ca68:     	ldur	q5, [x24, #0x28]
10152ca6c:     	stp	q2, q3, [sp, #0x190]
10152ca70:     	stp	q5, q4, [sp, #0x1b0]
10152ca74:     	str	x8, [sp, #0x1f0]
10152ca78:     	stp	q0, q1, [sp, #0x1d0]
10152ca7c:     	ldr	x8, [sp, #0x38]
10152ca80:     	ldr	x7, [x8, #0x10]
10152ca84:     	ldp	q0, q1, [x21, #0x80]
10152ca88:     	str	q0, [sp, #0x480]
10152ca8c:     	str	q1, [sp, #0x490]
10152ca90:     	ldr	x8, [x21, #0xa0]
10152ca94:     	str	x8, [sp, #0x4a0]
10152ca98:     	ldp	q0, q1, [x21, #0x40]
10152ca9c:     	str	q0, [sp, #0x440]
10152caa0:     	str	q1, [sp, #0x450]
10152caa4:     	ldp	q1, q0, [x21, #0x60]
10152caa8:     	str	q0, [sp, #0x470]
10152caac:     	str	q1, [sp, #0x460]
10152cab0:     	ldp	q0, q1, [x21]
10152cab4:     	str	q0, [sp, #0x400]
10152cab8:     	str	q1, [sp, #0x410]
10152cabc:     	ldp	q1, q0, [x21, #0x20]
10152cac0:     	add	x8, x25, #0x3b8
10152cac4:     	str	q0, [sp, #0x430]
10152cac8:     	str	q1, [sp, #0x420]
10152cacc:     	add	x9, sp, #0x190
10152cad0:     	stp	x8, x9, [sp, #0x8]
10152cad4:     	add	x9, sp, #0x400
10152cad8:     	adrp	x1, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152cadc:     	add	x1, x1, #0xca0
10152cae0:     	str	x9, [sp]
10152cae4:     	add	x8, sp, #0x1f8
10152cae8:     	add	x5, x25, #0x3c0
10152caec:     	add	x6, sp, #0x270
10152caf0:     	adrp	x3, 0x107552000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.1057+0x37c>
10152caf4:     	add	x3, x3, #0x110
10152caf8:     	mov	x0, x23
10152cafc:     	mov	w2, #0x2                ; =2
10152cb00:     	mov	w4, #0x2                ; =2
10152cb04:     	bl	0x10150dc8c <__RINvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB7_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2X_10Invocation19buffer_frame_actions5_0EB35_>
10152cb08:     	ldrb	w8, [sp, #0x1f8]
10152cb0c:     	cmp	w8, #0x2e
10152cb10:     	b.ne	0x10152cd90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1208>
10152cb14:     	add	x0, sp, #0x270
10152cb18:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cb1c:     	ldr	x8, [sp, #0x38]
10152cb20:     	ldr	x23, [x8, #0x10]
10152cb24:     	ldr	w24, [x8, #0x8]
10152cb28:     	b	0x10152c820 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xc98>
10152cb2c:     	ldr	w3, [sp, #0x248]
10152cb30:     	ldur	q0, [x26, #0x8]
10152cb34:     	str	q0, [sp, #0x2f0]
10152cb38:     	ldp	q0, q1, [x21, #0x80]
10152cb3c:     	str	q0, [sp, #0x480]
10152cb40:     	str	q1, [sp, #0x490]
10152cb44:     	ldr	x8, [x21, #0xa0]
10152cb48:     	str	x8, [sp, #0x4a0]
10152cb4c:     	ldp	q0, q1, [x21, #0x40]
10152cb50:     	str	q0, [sp, #0x440]
10152cb54:     	str	q1, [sp, #0x450]
10152cb58:     	ldp	q1, q0, [x21, #0x60]
10152cb5c:     	str	q0, [sp, #0x470]
10152cb60:     	str	q1, [sp, #0x460]
10152cb64:     	ldp	q0, q1, [x21]
10152cb68:     	str	q0, [sp, #0x400]
10152cb6c:     	str	q1, [sp, #0x410]
10152cb70:     	ldp	q1, q0, [x21, #0x20]
10152cb74:     	str	q0, [sp, #0x430]
10152cb78:     	str	q1, [sp, #0x420]
10152cb7c:     	add	x8, sp, #0x3c8
10152cb80:     	add	x1, sp, #0x270
10152cb84:     	add	x4, sp, #0x2f0
10152cb88:     	add	x5, sp, #0x400
10152cb8c:     	add	x6, x25, #0x3b8
10152cb90:     	add	x7, sp, #0x360
10152cb94:     	mov	x0, x22
10152cb98:     	mov	x2, x23
10152cb9c:     	bl	0x10253bd64 <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared13buffer_framesNtB6_25NativePreparedLibraryCall24admit_buffer_record_word>
10152cba0:     	ldrb	w8, [sp, #0x3c8]
10152cba4:     	cmp	w8, #0x2e
10152cba8:     	b.ne	0x10152cd1c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1194>
10152cbac:     	mov	w22, #0x1               ; =1
10152cbb0:     	add	x0, sp, #0x270
10152cbb4:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cbb8:     	ldr	x8, [x27, #0x360]
10152cbbc:     	ldr	x9, [sp, #0x38]
10152cbc0:     	ldr	w1, [x9, #0x8]
10152cbc4:     	cmp	x8, x1
10152cbc8:     	b.ls	0x10152cf74 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x13ec>
10152cbcc:     	ldr	x8, [x27, #0x358]
10152cbd0:     	mov	w9, #0x140              ; =320
10152cbd4:     	umaddl	x9, w1, w9, x8
10152cbd8:     	ldr	x8, [sp, #0x230]
10152cbdc:     	cbz	x8, 0x10152ccc0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1138>
10152cbe0:     	ldp	q0, q1, [sp, #0x230]
10152cbe4:     	str	q0, [sp, #0x400]
10152cbe8:     	str	q1, [sp, #0x410]
10152cbec:     	ldp	q0, q1, [sp, #0x250]
10152cbf0:     	str	q0, [sp, #0x420]
10152cbf4:     	str	q1, [sp, #0x430]
10152cbf8:     	ldr	x8, [x27, #0x448]
10152cbfc:     	cmp	x8, x1
10152cc00:     	b.ls	0x10152cfa0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1418>
10152cc04:     	ldr	x8, [x27, #0x440]
10152cc08:     	mov	w10, #0x24              ; =36
10152cc0c:     	umaddl	x8, w1, w10, x8
10152cc10:     	ldr	w10, [sp, #0x438]
10152cc14:     	ldr	w11, [x8, #0x20]
10152cc18:     	cmp	w10, w11
10152cc1c:     	b.ne	0x10152cc90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
10152cc20:     	ldp	q0, q1, [sp, #0x240]
10152cc24:     	stp	q0, q1, [sp, #0x2f0]
10152cc28:     	ldr	x10, [sp, #0x2f0]
10152cc2c:     	ldr	x11, [sp, #0x2f8]
10152cc30:     	ldp	x12, x13, [x8]
10152cc34:     	ldr	x14, [sp, #0x300]
10152cc38:     	ldr	x15, [sp, #0x308]
10152cc3c:     	ldp	x16, x8, [x8, #0x10]
10152cc40:     	cmp	x10, x12
10152cc44:     	ccmp	x11, x13, #0x0, eq
10152cc48:     	ccmp	x14, x16, #0x0, eq
10152cc4c:     	ccmp	x15, x8, #0x0, eq
10152cc50:     	b.ne	0x10152cc90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
10152cc54:     	ldrb	w8, [x9, #0x124]
10152cc58:     	cmp	w8, #0x7
10152cc5c:     	b.ne	0x10152cc90 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1108>
10152cc60:     	add	x8, sp, #0x2f0
10152cc64:     	add	x0, x25, #0xf0
10152cc68:     	add	x2, sp, #0x400
10152cc6c:     	add	x3, x25, #0x2f8
10152cc70:     	bl	0x101638a6c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
10152cc74:     	ldrb	w8, [sp, #0x2f0]
10152cc78:     	cmp	w8, #0x14
10152cc7c:     	b.ne	0x10152cdd8 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1250>
10152cc80:     	mov	w22, #0x0               ; =0
10152cc84:     	add	x0, sp, #0x400
10152cc88:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cc8c:     	b	0x10152c84c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0xcc4>
10152cc90:     	ldr	x10, [sp, #0x40]
10152cc94:     	str	wzr, [x10]
10152cc98:     	mov	w8, #0xc                ; =12
10152cc9c:     	strb	w8, [x10, #0x8]
10152cca0:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152cca4:     	add	x8, x8, #0xd49
10152cca8:     	mov	w9, #0x2a               ; =42
10152ccac:     	stp	x8, x9, [x10, #0x10]
10152ccb0:     	mov	w22, #0x0               ; =0
10152ccb4:     	add	x0, sp, #0x400
10152ccb8:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152ccbc:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152ccc0:     	ldr	w8, [sp, #0x248]
10152ccc4:     	ldr	w10, [x9, #0x130]
10152ccc8:     	cmp	w8, w10
10152cccc:     	b.ne	0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152ccd0:     	ldrb	w8, [sp, #0x239]
10152ccd4:     	ldr	x21, [sp, #0x240]
10152ccd8:     	ldrb	w10, [sp, #0x238]
10152ccdc:     	ldrb	w9, [x9, #0x124]
10152cce0:     	cmp	w10, #0x2
10152cce4:     	b.le	0x10152cd04 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x117c>
10152cce8:     	cmp	w10, #0x4
10152ccec:     	b.gt	0x10152cd78 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x11f0>
10152ccf0:     	cmp	w10, #0x3
10152ccf4:     	b.ne	0x10152ce38 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12b0>
10152ccf8:     	cmp	w9, #0x3
10152ccfc:     	b.eq	0x10152ce5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152cd00:     	b	0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cd04:     	cbz	w10, 0x10152ce20 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1298>
10152cd08:     	cmp	w10, #0x1
10152cd0c:     	b.ne	0x10152ce2c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12a4>
10152cd10:     	cmp	w9, #0x1
10152cd14:     	b.eq	0x10152ce5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152cd18:     	b	0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cd1c:     	ldr	x1, [x27, #0x378]
10152cd20:     	ldr	x2, [x27, #0x380]
10152cd24:     	add	x0, sp, #0x400
10152cd28:     	add	x4, sp, #0x3c8
10152cd2c:     	mov	x3, x20
10152cd30:     	bl	0x1015283f8 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>
10152cd34:     	ldr	q0, [sp, #0x420]
10152cd38:     	ldr	q1, [sp, #0x430]
10152cd3c:     	ldr	x8, [sp, #0x40]
10152cd40:     	stp	q0, q1, [x8, #0x20]
10152cd44:     	ldr	q0, [sp, #0x440]
10152cd48:     	str	q0, [x8, #0x40]
10152cd4c:     	ldr	q0, [sp, #0x410]
10152cd50:     	ldr	q1, [sp, #0x400]
10152cd54:     	stp	q1, q0, [x8]
10152cd58:     	mov	w22, #0x1               ; =1
10152cd5c:     	add	x0, sp, #0x270
10152cd60:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cd64:     	ldr	x8, [sp, #0x230]
10152cd68:     	cbz	x8, 0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152cd6c:     	add	x0, sp, #0x230
10152cd70:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cd74:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152cd78:     	cmp	w10, #0x5
10152cd7c:     	b.ne	0x10152ce50 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12c8>
10152cd80:     	cmp	w9, #0x5
10152cd84:     	b.ne	0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152cd88:     	ldrh	w21, [sp, #0x23a]
10152cd8c:     	b	0x10152ce5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152cd90:     	ldr	x1, [x27, #0x378]
10152cd94:     	ldr	x2, [x27, #0x380]
10152cd98:     	add	x0, sp, #0x400
10152cd9c:     	add	x4, sp, #0x1f8
10152cda0:     	mov	x3, x20
10152cda4:     	bl	0x101528364 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>
10152cda8:     	ldr	q0, [sp, #0x420]
10152cdac:     	ldr	q1, [sp, #0x430]
10152cdb0:     	ldr	x8, [sp, #0x40]
10152cdb4:     	stp	q0, q1, [x8, #0x20]
10152cdb8:     	ldr	q0, [sp, #0x440]
10152cdbc:     	str	q0, [x8, #0x40]
10152cdc0:     	ldr	q0, [sp, #0x410]
10152cdc4:     	ldr	q1, [sp, #0x400]
10152cdc8:     	stp	q1, q0, [x8]
10152cdcc:     	add	x0, sp, #0x270
10152cdd0:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cdd4:     	b	0x10152bf08 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x380>
10152cdd8:     	add	x10, sp, #0x230
10152cddc:     	ldur	w9, [x10, #0xc1]
10152cde0:     	ldr	x11, [sp, #0x40]
10152cde4:     	stur	w9, [x11, #0x9]
10152cde8:     	ldr	w9, [sp, #0x2f4]
10152cdec:     	str	w9, [x11, #0xc]
10152cdf0:     	ldr	q0, [sp, #0x310]
10152cdf4:     	stur	q0, [x11, #0x28]
10152cdf8:     	ldr	x9, [sp, #0x320]
10152cdfc:     	str	x9, [x11, #0x38]
10152ce00:     	ldr	d0, [sp, #0x308]
10152ce04:     	ldur	q1, [x10, #0xc8]
10152ce08:     	mov	w9, #0x2                ; =2
10152ce0c:     	str	w9, [x11]
10152ce10:     	strb	w8, [x11, #0x8]
10152ce14:     	str	q1, [x11, #0x10]
10152ce18:     	str	d0, [x11, #0x20]
10152ce1c:     	b	0x10152ccb0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1128>
10152ce20:     	cbnz	w9, 0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152ce24:     	and	x21, x8, #0x1
10152ce28:     	b	0x10152ce5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152ce2c:     	cmp	w9, #0x2
10152ce30:     	b.eq	0x10152ce5c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12d4>
10152ce34:     	b	0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152ce38:     	cmp	w9, #0x4
10152ce3c:     	b.ne	0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152ce40:     	mov	w22, #0x1               ; =1
10152ce44:     	mov	x21, x8
10152ce48:     	add	x26, sp, #0x400
10152ce4c:     	b	0x10152c15c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10152ce50:     	cmp	w9, #0x6
10152ce54:     	b.ne	0x10152ce68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x12e0>
10152ce58:     	ldr	w21, [sp, #0x23c]
10152ce5c:     	mov	w22, #0x1               ; =1
10152ce60:     	add	x26, sp, #0x400
10152ce64:     	b	0x10152c15c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x5d4>
10152ce68:     	ldr	x10, [sp, #0x40]
10152ce6c:     	str	wzr, [x10]
10152ce70:     	mov	w8, #0xc                ; =12
10152ce74:     	strb	w8, [x10, #0x8]
10152ce78:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10152ce7c:     	add	x8, x8, #0xd20
10152ce80:     	mov	w9, #0x29               ; =41
10152ce84:     	b	0x10152c298 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x710>
10152ce88:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152ce8c:     	add	x3, x3, #0x828
10152ce90:     	mov	x0, #0x0                ; =0
10152ce94:     	mov	x1, x22
10152ce98:     	bl	0x103a021d8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152ce9c:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cea0:     	add	x3, x3, #0x7b0
10152cea4:     	mov	x0, #0x0                ; =0
10152cea8:     	mov	x1, x22
10152ceac:     	bl	0x103a021d8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152ceb0:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152ceb4:     	add	x3, x3, #0x810
10152ceb8:     	mov	x0, #0x0                ; =0
10152cebc:     	mov	x1, x22
10152cec0:     	bl	0x103a021d8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152cec4:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cec8:     	add	x3, x3, #0x7e0
10152cecc:     	mov	x0, #0x0                ; =0
10152ced0:     	mov	x1, x22
10152ced4:     	bl	0x103a021d8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152ced8:     	b	0x10152cfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cedc:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cee0:     	add	x3, x3, #0x7f8
10152cee4:     	mov	x0, #0x0                ; =0
10152cee8:     	mov	x1, x22
10152ceec:     	bl	0x103a021d8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
10152cef0:     	b	0x10152cfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cef4:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cef8:     	add	x2, x2, #0x840
10152cefc:     	mov	x0, x1
10152cf00:     	mov	x1, x8
10152cf04:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf08:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf0c:     	add	x2, x2, #0x780
10152cf10:     	mov	x0, x20
10152cf14:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf18:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf1c:     	add	x2, x2, #0x858
10152cf20:     	mov	x0, x25
10152cf24:     	mov	x1, x22
10152cf28:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf2c:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf30:     	add	x2, x2, #0x870
10152cf34:     	mov	x0, x25
10152cf38:     	mov	x1, x22
10152cf3c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf40:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf44:     	add	x2, x2, #0x8a0
10152cf48:     	mov	x0, x20
10152cf4c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf50:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf54:     	add	x2, x2, #0x798
10152cf58:     	mov	x0, x20
10152cf5c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf60:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf64:     	add	x2, x2, #0x7c8
10152cf68:     	mov	x0, x20
10152cf6c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf70:     	b	0x10152cfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cf74:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf78:     	add	x2, x2, #0x918
10152cf7c:     	b	0x10152cf8c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1404>
10152cf80:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cf84:     	add	x2, x2, #0x8e8
10152cf88:     	mov	w1, #0x1                ; =1
10152cf8c:     	mov	w22, #0x1               ; =1
10152cf90:     	mov	x0, x1
10152cf94:     	mov	x1, x8
10152cf98:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cf9c:     	b	0x10152cfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cfa0:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfa4:     	add	x2, x2, #0x930
10152cfa8:     	mov	x0, x1
10152cfac:     	mov	x1, x8
10152cfb0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cfb4:     	b	0x10152cfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cfb8:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfbc:     	add	x2, x2, #0x8b8
10152cfc0:     	mov	w0, #0x1                ; =1
10152cfc4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cfc8:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfcc:     	add	x2, x2, #0x900
10152cfd0:     	mov	x0, x20
10152cfd4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cfd8:     	b	0x10152cfec <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1464>
10152cfdc:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
10152cfe0:     	add	x2, x2, #0x8d0
10152cfe4:     	mov	x0, x20
10152cfe8:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10152cfec:     	brk	#0x1
10152cff0:     	mov	x20, x0
10152cff4:     	add	x0, sp, #0x400
10152cff8:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152cffc:     	b	0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d000:     	mov	x20, x0
10152d004:     	add	x0, sp, #0x270
10152d008:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d00c:     	b	0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d010:     	mov	x20, x0
10152d014:     	add	x0, sp, #0x270
10152d018:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d01c:     	mov	w22, #0x1               ; =1
10152d020:     	b	0x10152d028 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x14a0>
10152d024:     	mov	x20, x0
10152d028:     	cbz	w22, 0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d02c:     	ldr	x8, [sp, #0x230]
10152d030:     	cbz	x8, 0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d034:     	add	x0, sp, #0x230
10152d038:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d03c:     	b	0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d040:     	add	x8, x28, x19
10152d044:     	ldp	q0, q1, [sp, #0x2f0]
10152d048:     	ldp	q2, q3, [sp, #0x310]
10152d04c:     	stp	q2, q3, [x8, #0x20]
10152d050:     	stp	q0, q1, [x8]
10152d054:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
10152d058:     	mov	x20, x0
10152d05c:     	tbnz	w19, #0x0, 0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d060:     	add	x0, sp, #0x2f0
10152d064:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
10152d068:     	b	0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d06c:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
10152d070:     	mov	x20, x0
10152d074:     	ldr	w8, [sp, #0x400]
10152d078:     	cmp	w8, #0x6
10152d07c:     	b.eq	0x10152d09c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action+0x1514>
10152d080:     	add	x0, sp, #0x400
10152d084:     	bl	0x101525658 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10152d088:     	mov	x0, x20
10152d08c:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
10152d090:     	mov	x20, x0
10152d094:     	add	x0, sp, #0xf8
10152d098:     	bl	0x1015257ec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10152d09c:     	mov	x0, x20
10152d0a0:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
