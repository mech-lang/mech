
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023737a4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work>:
1023737a4:     	stp	x28, x27, [sp, #-0x60]!
1023737a8:     	stp	x26, x25, [sp, #0x10]
1023737ac:     	stp	x24, x23, [sp, #0x20]
1023737b0:     	stp	x22, x21, [sp, #0x30]
1023737b4:     	stp	x20, x19, [sp, #0x40]
1023737b8:     	stp	x29, x30, [sp, #0x50]
1023737bc:     	add	x29, sp, #0x50
1023737c0:     	sub	sp, sp, #0x1a0
1023737c4:     	ldr	x9, [x0, #0xd0]
1023737c8:     	adds	x13, x9, x1
1023737cc:     	b.hs	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023737d0:     	ldr	x21, [x0, #0xc8]
1023737d4:     	ldr	x26, [x0, #0xe8]
1023737d8:     	ldr	x28, [x0, #0xf8]
1023737dc:     	ldr	x25, [x0, #0x108]
1023737e0:     	ldp	x22, x23, [x0, #0x118]
1023737e4:     	ldr	x9, [x0]
1023737e8:     	cmp	x9, #0x1
1023737ec:     	b.ne	0x102373858 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xb4>
1023737f0:     	cmp	x23, #0x10, lsl #12     ; =0x10000
1023737f4:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
1023737f8:     	mov	w9, #0x1000000          ; =16777216
1023737fc:     	cmp	x26, x9
102373800:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373804:     	mov	w9, #0x1000000          ; =16777216
102373808:     	cmp	x13, x9
10237380c:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373810:     	mov	w9, #0x1000000          ; =16777216
102373814:     	cmp	x28, x9
102373818:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
10237381c:     	mov	w9, #0x1000000          ; =16777216
102373820:     	cmp	x25, x9
102373824:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373828:     	cmp	x22, #0x10, lsl #12     ; =0x10000
10237382c:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373830:     	cmp	x21, #0x10, lsl #12     ; =0x10000
102373834:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373838:     	ldr	x9, [x0, #0x8]
10237383c:     	cmp	x13, x9
102373840:     	b.hi	0x102373850 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0xac>
102373844:     	ldr	x9, [x0, #0x10]
102373848:     	cmp	x21, x9
10237384c:     	b.ls	0x102373990 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102373850:     	mov	w9, #0x2                ; =2
102373854:     	b	0x102373998 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f4>
102373858:     	ldp	x24, x2, [x0, #0xd8]
10237385c:     	ldr	x20, [x0, #0xf0]
102373860:     	ldr	x9, [x0, #0x100]
102373864:     	ldr	x1, [x0, #0x110]
102373868:     	ldr	x15, [x0, #0x128]
10237386c:     	ldr	x27, [x0, #0x18]
102373870:     	cmp	x27, #0x2
102373874:     	b.ne	0x1023738e8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x144>
102373878:     	mov	x19, x0
10237387c:     	mov	x27, x8
102373880:     	stp	x21, x13, [x29, #-0xf0]
102373884:     	mov	x21, x13
102373888:     	stp	x24, x2, [x29, #-0xe0]
10237388c:     	stp	x26, x20, [x29, #-0xd0]
102373890:     	stp	x28, x9, [x29, #-0xc0]
102373894:     	stp	x25, x1, [x29, #-0xb0]
102373898:     	stp	x22, x23, [x29, #-0xa0]
10237389c:     	stur	x15, [x29, #-0x90]
1023738a0:     	sub	x8, x29, #0x88
1023738a4:     	sub	x0, x29, #0xf0
1023738a8:     	bl	0x102380ab0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
1023738ac:     	ldurb	w8, [x29, #-0x88]
1023738b0:     	cmp	w8, #0x8
1023738b4:     	b.ne	0x102373964 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1c0>
1023738b8:     	add	x0, sp, #0xd0
1023738bc:     	sub	x1, x29, #0xf0
1023738c0:     	bl	0x10236ef64 <__RNvMs4_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_18KernelCostEstimate21check_planning_limits>
1023738c4:     	mov	x8, x27
1023738c8:     	ldrb	w9, [sp, #0xd0]
1023738cc:     	cmp	w9, #0x8
1023738d0:     	b.eq	0x102373988 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1e4>
1023738d4:     	ldp	q0, q1, [sp, #0xd0]
1023738d8:     	stp	q0, q1, [x8]
1023738dc:     	ldr	x9, [sp, #0xf0]
1023738e0:     	str	x9, [x8, #0x20]
1023738e4:     	b	0x10237399c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
1023738e8:     	str	x9, [sp, #0xc0]
1023738ec:     	ldr	x10, [x0, #0x20]
1023738f0:     	ldp	x11, x9, [x0, #0x38]
1023738f4:     	stp	x9, x10, [sp, #0xb0]
1023738f8:     	ldp	x10, x9, [x0, #0x48]
1023738fc:     	stp	x9, x11, [sp, #0xa0]
102373900:     	ldr	x9, [x0, #0x58]
102373904:     	stp	x9, x10, [sp, #0x90]
102373908:     	ldp	x10, x9, [x0, #0x60]
10237390c:     	str	x9, [sp, #0x88]
102373910:     	ldp	x11, x9, [x0, #0x70]
102373914:     	stp	x0, x9, [sp, #0x78]
102373918:     	ldp	x6, x12, [x0, #0x80]
10237391c:     	ldp	x4, x7, [x0, #0x90]
102373920:     	ldr	x3, [x0, #0xa0]
102373924:     	ldp	w5, w14, [x0, #0xb8]
102373928:     	ldr	x9, [x0, #0xc0]
10237392c:     	str	x9, [sp, #0xc8]
102373930:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
102373934:     	add	x0, x0, #0x550
102373938:     	ldr	x9, [x0]
10237393c:     	blr	x9
102373940:     	mov	x19, x0
102373944:     	ldrb	w9, [x0, #0x48]
102373948:     	cmp	w9, #0x1
10237394c:     	b.eq	0x102373a18 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x274>
102373950:     	cmp	w9, #0x2
102373954:     	b.ne	0x1023739bc <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x218>
102373958:     	adrp	x0, 0x108032000 <_anon.b751fc49bcc701379c8af7be5d8e914b.25>
10237395c:     	add	x0, x0, #0x610
102373960:     	bl	0x103a01874 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102373964:     	sub	x8, x29, #0x88
102373968:     	ldp	q0, q1, [x8]
10237396c:     	stp	q0, q1, [sp, #0xd0]
102373970:     	ldur	x8, [x29, #-0x68]
102373974:     	str	x8, [sp, #0xf0]
102373978:     	mov	x8, x27
10237397c:     	ldrb	w9, [sp, #0xd0]
102373980:     	cmp	w9, #0x8
102373984:     	b.ne	0x1023738d4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x130>
102373988:     	mov	x0, x19
10237398c:     	mov	x13, x21
102373990:     	str	x13, [x0, #0xd0]
102373994:     	mov	w9, #0x8                ; =8
102373998:     	strb	w9, [x8]
10237399c:     	add	sp, sp, #0x1a0
1023739a0:     	ldp	x29, x30, [sp, #0x50]
1023739a4:     	ldp	x20, x19, [sp, #0x40]
1023739a8:     	ldp	x22, x21, [sp, #0x30]
1023739ac:     	ldp	x24, x23, [sp, #0x20]
1023739b0:     	ldp	x26, x25, [sp, #0x10]
1023739b4:     	ldp	x28, x27, [sp], #0x60
1023739b8:     	ret
1023739bc:     	stp	x1, x15, [sp, #0x10]
1023739c0:     	adrp	x1, 0x102362000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTmmENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1h_11collections5btree3mapINtB24_8BTreeMapmmEINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtB31_8adapters12GenericShuntINtNtB3W_3map3MapINtNtB3W_9enumerate9EnumerateINtNtB3W_6filter6FilterIB4H_INtNtB8_4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine16source_semantics8frontend11PendingNodeEENCNvMs0_NtB5V_11applicationNtB5V_15SemanticBuilder19counted_applications7_0EENCB78_s8_0EINtNtBa_6result6ResultNtNtBa_7convert10InfallibleNtB5V_19SourceSemanticErrorEEE0E0EB5Z_+0x30c>
1023739c4:     	add	x1, x1, #0xb7c
1023739c8:     	mov	x0, x19
1023739cc:     	str	x8, [sp, #0x20]
1023739d0:     	stp	x6, x13, [sp, #0x50]
1023739d4:     	stp	x14, x7, [sp, #0x30]
1023739d8:     	str	x2, [sp, #0x8]
1023739dc:     	stp	x3, x4, [sp, #0x40]
1023739e0:     	str	w5, [sp, #0x2c]
1023739e4:     	stp	x12, x11, [sp, #0x60]
1023739e8:     	str	x10, [sp, #0x70]
1023739ec:     	bl	0x102e6e274 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
1023739f0:     	ldp	x11, x10, [sp, #0x68]
1023739f4:     	ldp	x13, x12, [sp, #0x58]
1023739f8:     	ldp	x7, x3, [sp, #0x38]
1023739fc:     	ldp	x4, x6, [sp, #0x48]
102373a00:     	ldr	w5, [sp, #0x2c]
102373a04:     	ldp	x2, x1, [sp, #0x8]
102373a08:     	ldp	x15, x8, [sp, #0x18]
102373a0c:     	ldr	x14, [sp, #0x30]
102373a10:     	mov	w9, #0x1                ; =1
102373a14:     	strb	w9, [x19, #0x48]
102373a18:     	str	x10, [sp, #0x70]
102373a1c:     	ldr	x9, [x19]
102373a20:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
102373a24:     	cmp	x9, x10
102373a28:     	b.hs	0x102373c38 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x494>
102373a2c:     	add	x10, x9, #0x1
102373a30:     	str	x10, [x19]
102373a34:     	ldr	x10, [x19, #0x8]
102373a38:     	cbz	x10, 0x102373ae0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x33c>
102373a3c:     	stp	x12, x11, [sp, #0x60]
102373a40:     	ldr	x11, [x10, #0x10]
102373a44:     	mov	x12, #0x7fffffffffffffff ; =9223372036854775807
102373a48:     	cmp	x11, x12
102373a4c:     	b.hs	0x102373c44 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x4a0>
102373a50:     	ldr	x10, [x10, #0x58]
102373a54:     	str	x9, [x19]
102373a58:     	ldr	x9, [sp, #0xc8]
102373a5c:     	cmp	x10, x9
102373a60:     	b.ne	0x102373ae4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x340>
102373a64:     	stp	x7, x3, [sp, #0x38]
102373a68:     	stp	x4, x6, [sp, #0x48]
102373a6c:     	str	w5, [sp, #0x2c]
102373a70:     	str	x14, [sp, #0x30]
102373a74:     	mov	x19, x8
102373a78:     	stp	x21, x13, [x29, #-0xf0]
102373a7c:     	str	x13, [sp, #0x58]
102373a80:     	stp	x24, x2, [x29, #-0xe0]
102373a84:     	mov	x24, x2
102373a88:     	stp	x26, x20, [x29, #-0xd0]
102373a8c:     	ldr	x8, [sp, #0xc0]
102373a90:     	stp	x28, x8, [x29, #-0xc0]
102373a94:     	stp	x25, x1, [x29, #-0xb0]
102373a98:     	mov	x26, x1
102373a9c:     	stp	x22, x23, [x29, #-0xa0]
102373aa0:     	mov	x20, x15
102373aa4:     	stur	x15, [x29, #-0x90]
102373aa8:     	sub	x8, x29, #0x88
102373aac:     	sub	x0, x29, #0xf0
102373ab0:     	bl	0x102380ab0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget20observe_control_work>
102373ab4:     	ldurb	w8, [x29, #-0x88]
102373ab8:     	cmp	w8, #0x8
102373abc:     	b.ne	0x102373aec <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x348>
102373ac0:     	cmp	x27, #0x1
102373ac4:     	mov	x8, x19
102373ac8:     	ldr	x11, [sp, #0xb8]
102373acc:     	b.ne	0x102373b04 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102373ad0:     	cmp	x23, x11
102373ad4:     	b.ls	0x102373b04 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x360>
102373ad8:     	mov	w9, #0x0                ; =0
102373adc:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373ae0:     	str	x9, [x19]
102373ae4:     	strb	wzr, [x8]
102373ae8:     	b	0x10237399c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102373aec:     	sub	x8, x29, #0x88
102373af0:     	ldp	q0, q1, [x8]
102373af4:     	stp	q0, q1, [x19]
102373af8:     	ldur	x8, [x29, #-0x68]
102373afc:     	str	x8, [x19, #0x20]
102373b00:     	b	0x10237399c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102373b04:     	ldp	x9, x11, [sp, #0xa8]
102373b08:     	cmp	x9, #0x1
102373b0c:     	b.ne	0x102373b24 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102373b10:     	cmp	x28, x11
102373b14:     	b.ls	0x102373b24 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x380>
102373b18:     	mov	w9, #0x2                ; =2
102373b1c:     	mov	x23, x28
102373b20:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373b24:     	ldp	x9, x11, [sp, #0x98]
102373b28:     	cmp	x9, #0x1
102373b2c:     	b.ne	0x102373b44 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
102373b30:     	cmp	x25, x11
102373b34:     	b.ls	0x102373b44 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3a0>
102373b38:     	mov	w9, #0x3                ; =3
102373b3c:     	mov	x23, x25
102373b40:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373b44:     	ldr	x9, [sp, #0x90]
102373b48:     	cmp	x9, #0x1
102373b4c:     	ldr	x11, [sp, #0x70]
102373b50:     	b.ne	0x102373b68 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
102373b54:     	cmp	x22, x11
102373b58:     	b.ls	0x102373b68 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3c4>
102373b5c:     	mov	w9, #0x4                ; =4
102373b60:     	mov	x23, x22
102373b64:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373b68:     	ldr	x9, [sp, #0x88]
102373b6c:     	cmp	x9, #0x1
102373b70:     	ldr	x11, [sp, #0x68]
102373b74:     	b.ne	0x102373b8c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
102373b78:     	cmp	x21, x11
102373b7c:     	b.ls	0x102373b8c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x3e8>
102373b80:     	mov	w9, #0x5                ; =5
102373b84:     	mov	x23, x21
102373b88:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373b8c:     	ldr	x9, [sp, #0x80]
102373b90:     	cmp	x9, #0x1
102373b94:     	ldp	x11, x13, [sp, #0x50]
102373b98:     	b.ne	0x102373bb0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
102373b9c:     	cmp	x13, x11
102373ba0:     	b.ls	0x102373bb0 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x40c>
102373ba4:     	mov	w9, #0x6                ; =6
102373ba8:     	mov	x23, x13
102373bac:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373bb0:     	ldr	x9, [sp, #0x60]
102373bb4:     	cmp	x9, #0x1
102373bb8:     	ldr	x11, [sp, #0x48]
102373bbc:     	b.ne	0x102373bd4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102373bc0:     	cmp	x24, x11
102373bc4:     	b.ls	0x102373bd4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x430>
102373bc8:     	mov	w9, #0x7                ; =7
102373bcc:     	mov	x23, x24
102373bd0:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373bd4:     	ldp	x9, x11, [sp, #0x38]
102373bd8:     	cmp	x9, #0x1
102373bdc:     	b.ne	0x102373bf8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102373be0:     	mov	x24, x26
102373be4:     	cmp	x26, x11
102373be8:     	b.ls	0x102373bf8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x454>
102373bec:     	mov	w9, #0x8                ; =8
102373bf0:     	mov	x23, x24
102373bf4:     	b	0x102373c1c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x478>
102373bf8:     	ldr	w9, [sp, #0x2c]
102373bfc:     	cmp	w9, #0x1
102373c00:     	ldr	x0, [sp, #0x78]
102373c04:     	ldr	x11, [sp, #0x30]
102373c08:     	b.ne	0x102373990 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102373c0c:     	cmp	w11, w20
102373c10:     	b.hs	0x102373990 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1ec>
102373c14:     	mov	w23, w20
102373c18:     	mov	w9, #0xa                ; =10
102373c1c:     	mov	w10, #0x6               ; =6
102373c20:     	strb	w10, [x8]
102373c24:     	strb	w9, [x8, #0x1]
102373c28:     	mov	w9, #0x1                ; =1
102373c2c:     	strb	w9, [x8, #0x2]
102373c30:     	stp	x23, x11, [x8, #0x8]
102373c34:     	b	0x10237399c <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter19charge_compute_work+0x1f8>
102373c38:     	adrp	x0, 0x108033000 <_anon.b751fc49bcc701379c8af7be5d8e914b.242+0x8>
102373c3c:     	add	x0, x0, #0xac0
102373c40:     	bl	0x103a01f28 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102373c44:     	adrp	x0, 0x108033000 <_anon.b751fc49bcc701379c8af7be5d8e914b.242+0x8>
102373c48:     	add	x0, x0, #0xad8
102373c4c:     	bl	0x103a01f28 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102373c50:     	brk	#0x1
102373c54:     	ldr	x8, [x19]
102373c58:     	sub	x8, x8, #0x1
102373c5c:     	str	x8, [x19]
102373c60:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
