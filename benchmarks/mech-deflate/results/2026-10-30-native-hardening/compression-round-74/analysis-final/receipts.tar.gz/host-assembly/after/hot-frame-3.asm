
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101528364 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_>:
101528364:     	stp	x20, x19, [sp, #-0x20]!
101528368:     	stp	x29, x30, [sp, #0x10]
10152836c:     	add	x29, sp, #0x10
101528370:     	mov	x19, x4
101528374:     	cmp	x3, x2
101528378:     	b.hs	0x1015283c8 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions6_0Be_+0x64>
10152837c:     	mov	w8, #0x170              ; =368
101528380:     	madd	x8, x3, x8, x1
101528384:     	add	x9, x8, #0x148
101528388:     	ldr	q0, [x9]
10152838c:     	stur	q0, [x0, #0x4]
101528390:     	ldp	q0, q1, [x19]
101528394:     	stur	q0, [x0, #0x18]
101528398:     	ldr	w8, [x8, #0x158]
10152839c:     	str	w8, [x0, #0x14]
1015283a0:     	stur	q1, [x0, #0x28]
1015283a4:     	ldr	q0, [x19, #0x20]
1015283a8:     	stur	q0, [x0, #0x38]
1015283ac:     	ldr	x8, [x19, #0x30]
1015283b0:     	str	x8, [x0, #0x48]
1015283b4:     	mov	w8, #0x3                ; =3
1015283b8:     	str	w8, [x0]
1015283bc:     	ldp	x29, x30, [sp, #0x10]
1015283c0:     	ldp	x20, x19, [sp], #0x20
1015283c4:     	ret
1015283c8:     	adrp	x8, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
1015283cc:     	add	x8, x8, #0xfd8
1015283d0:     	mov	x0, x3
1015283d4:     	mov	x1, x2
1015283d8:     	mov	x2, x8
1015283dc:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015283e0:     	brk	#0x1
1015283e4:     	mov	x20, x0
1015283e8:     	mov	x0, x19
1015283ec:     	bl	0x1015257ec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1015283f0:     	mov	x0, x20
1015283f4:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
