
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010162726c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_>:
10162726c:     	stp	x28, x27, [sp, #-0x60]!
101627270:     	stp	x26, x25, [sp, #0x10]
101627274:     	stp	x24, x23, [sp, #0x20]
101627278:     	stp	x22, x21, [sp, #0x30]
10162727c:     	stp	x20, x19, [sp, #0x40]
101627280:     	stp	x29, x30, [sp, #0x50]
101627284:     	add	x29, sp, #0x50
101627288:     	sub	sp, sp, #0x610
10162728c:     	str	xzr, [sp]
101627290:     	mov	x23, x1
101627294:     	mov	x20, x8
101627298:     	ldr	x8, [x0]
10162729c:     	mov	x0, #0x0                ; =0
1016272a0:     	blr	x8
1016272a4:     	cbz	x0, 0x101627d4c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xae0>
1016272a8:     	mov	x19, x0
1016272ac:     	mov	x8, x0
1016272b0:     	ldr	x9, [x8, #0x20]!
1016272b4:     	cbnz	x9, 0x101627cd8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa6c>
1016272b8:     	ldp	x0, x22, [x23]
1016272bc:     	ldp	x28, x24, [x23, #0x10]
1016272c0:     	ldp	x26, x21, [x23, #0x20]
1016272c4:     	ldp	x27, x16, [x23, #0x38]
1016272c8:     	ldp	x17, x14, [x23, #0x48]
1016272cc:     	ldp	x9, x25, [x23, #0x58]
1016272d0:     	str	x9, [sp, #0x70]
1016272d4:     	ldp	x9, x11, [x23, #0x68]
1016272d8:     	str	x9, [sp, #0x60]
1016272dc:     	ldp	x12, x1, [x23, #0x78]
1016272e0:     	ldp	x13, x15, [x23, #0x88]
1016272e4:     	mov	x9, #-0x1               ; =-1
1016272e8:     	str	x9, [x19, #0x20]
1016272ec:     	ldr	x10, [x19, #0x28]
1016272f0:     	ldr	x9, [x0]
1016272f4:     	cbz	x10, 0x101627310 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
1016272f8:     	cmp	x10, x9
1016272fc:     	b.eq	0x101627310 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4>
101627300:     	mov	x9, #0x0                ; =0
101627304:     	str	xzr, [x8]
101627308:     	mov	w26, #0x2f              ; =47
10162730c:     	b	0x101627734 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4c8>
101627310:     	ldr	x10, [x9]
101627314:     	adds	x10, x10, #0x1
101627318:     	str	x10, [x9]
10162731c:     	b.hs	0x101627d84 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb18>
101627320:     	str	x11, [sp, #0x10]
101627324:     	ldp	x11, x10, [x19, #0x20]
101627328:     	add	x11, x11, #0x1
10162732c:     	stp	x11, x9, [x19, #0x20]
101627330:     	stp	x8, x10, [sp, #0x88]
101627334:     	ldr	x23, [x0]
101627338:     	ldr	x8, [x23]
10162733c:     	adds	x8, x8, #0x1
101627340:     	str	x8, [x23]
101627344:     	b.hs	0x101627d84 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb18>
101627348:     	stp	xzr, xzr, [sp, #0xd8]
10162734c:     	str	x23, [sp, #0xd0]
101627350:     	ldr	x8, [x19]
101627354:     	cbnz	x8, 0x101627d1c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xab0>
101627358:     	stp	x13, x1, [sp, #0x38]
10162735c:     	stp	x17, x14, [sp, #0x18]
101627360:     	stp	x16, x15, [sp, #0x28]
101627364:     	str	x12, [sp, #0x8]
101627368:     	ldur	q0, [x19, #0x8]
10162736c:     	ldr	x8, [x19, #0x18]
101627370:     	str	x8, [sp, #0xb0]
101627374:     	stur	q0, [sp, #0xa0]
101627378:     	ldr	q0, [sp, #0xd0]
10162737c:     	ldr	x8, [sp, #0xe0]
101627380:     	str	x8, [x19, #0x18]
101627384:     	stur	q0, [x19, #0x8]
101627388:     	str	x19, [sp, #0x98]
10162738c:     	bl	0x10236d5b4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101627390:     	ldp	x12, x9, [x19, #0x30]
101627394:     	ldr	x11, [x19, #0x40]
101627398:     	ldr	x8, [x22]
10162739c:     	adds	x8, x0, x8
1016273a0:     	csinv	x8, x8, xzr, lo
1016273a4:     	cmp	x9, x8
1016273a8:     	stp	x11, x9, [sp, #0x48]
1016273ac:     	csel	x9, x9, x8, lo
1016273b0:     	ldr	x10, [x28]
1016273b4:     	adds	x10, x1, x10
1016273b8:     	csinv	x10, x10, xzr, lo
1016273bc:     	cmp	x11, x10
1016273c0:     	csel	x11, x11, x10, lo
1016273c4:     	str	x12, [sp, #0x58]
1016273c8:     	tst	w12, #0x1
1016273cc:     	csel	x8, x9, x8, ne
1016273d0:     	csel	x9, x11, x10, ne
1016273d4:     	mov	w10, #0x1               ; =1
1016273d8:     	stp	x10, x8, [x19, #0x30]
1016273dc:     	str	x9, [x19, #0x40]
1016273e0:     	add	x8, sp, #0xb8
1016273e4:     	mov	x0, x24
1016273e8:     	bl	0x10236c914 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
1016273ec:     	add	x23, sp, #0x320
1016273f0:     	add	x28, sp, #0x230
1016273f4:     	ldp	q0, q1, [x26, #0x80]
1016273f8:     	stp	q0, q1, [x28, #0x80]
1016273fc:     	ldr	x8, [x26, #0xa0]
101627400:     	str	x8, [sp, #0x2d0]
101627404:     	ldp	q0, q1, [x26, #0x40]
101627408:     	stp	q0, q1, [x28, #0x40]
10162740c:     	ldp	q1, q0, [x26, #0x60]
101627410:     	stp	q1, q0, [x28, #0x60]
101627414:     	ldp	q0, q1, [x26]
101627418:     	stp	q0, q1, [x28]
10162741c:     	ldp	q1, q0, [x26, #0x20]
101627420:     	stp	q1, q0, [x28, #0x20]
101627424:     	ldr	q0, [x21, #0x30]
101627428:     	str	q0, [x28, #0x120]
10162742c:     	ldr	q0, [x21, #0x40]
101627430:     	str	q0, [x28, #0x130]
101627434:     	ldr	q0, [x21, #0x50]
101627438:     	str	q0, [x28, #0x140]
10162743c:     	ldr	x8, [x21, #0x60]
101627440:     	str	x8, [sp, #0x380]
101627444:     	ldr	q0, [x21]
101627448:     	str	q0, [x28, #0xf0]
10162744c:     	ldr	q0, [x21, #0x10]
101627450:     	str	q0, [x28, #0x100]
101627454:     	ldr	q0, [x21, #0x20]
101627458:     	str	q0, [x28, #0x110]
10162745c:     	ldr	q0, [x26, #0x70]
101627460:     	str	q0, [x23, #0x1a0]
101627464:     	ldr	q0, [x26, #0x80]
101627468:     	str	q0, [x23, #0x1b0]
10162746c:     	ldr	q0, [x26, #0x90]
101627470:     	str	q0, [x23, #0x1c0]
101627474:     	ldr	x8, [x26, #0xa0]
101627478:     	str	x8, [sp, #0x4f0]
10162747c:     	ldr	q0, [x26, #0x30]
101627480:     	str	q0, [x23, #0x160]
101627484:     	ldr	q0, [x26, #0x40]
101627488:     	str	q0, [x23, #0x170]
10162748c:     	ldr	q0, [x26, #0x50]
101627490:     	str	q0, [x23, #0x180]
101627494:     	ldr	q0, [x26, #0x60]
101627498:     	str	q0, [x23, #0x190]
10162749c:     	ldr	q0, [x26]
1016274a0:     	str	q0, [x23, #0x130]
1016274a4:     	ldr	q0, [x26, #0x10]
1016274a8:     	str	q0, [x23, #0x140]
1016274ac:     	ldr	q0, [x26, #0x20]
1016274b0:     	str	q0, [x23, #0x150]
1016274b4:     	add	x8, sp, #0xd0
1016274b8:     	add	x1, sp, #0x450
1016274bc:     	add	x2, sp, #0x320
1016274c0:     	mov	x0, x24
1016274c4:     	bl	0x10236aaa0 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext3new>
1016274c8:     	ldr	x25, [x25]
1016274cc:     	lsr	x8, x25, #61
1016274d0:     	cbnz	x8, 0x101627d2c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xac0>
1016274d4:     	lsl	x26, x25, #3
1016274d8:     	mov	w8, #0x2c               ; =44
1016274dc:     	strb	w8, [sp, #0x450]
1016274e0:     	add	x0, sp, #0x450
1016274e4:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
1016274e8:     	add	x8, sp, #0x320
1016274ec:     	add	x0, sp, #0xd0
1016274f0:     	mov	x1, x26
1016274f4:     	mov	x2, #0x0                ; =0
1016274f8:     	bl	0x10236ad6c <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
1016274fc:     	ldrb	w8, [sp, #0x320]
101627500:     	cmp	w8, #0x8
101627504:     	b.ne	0x1016275e8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x37c>
101627508:     	add	x8, sp, #0x450
10162750c:     	add	x0, sp, #0xd0
101627510:     	add	x2, x27, #0x8
101627514:     	mov	x1, x25
101627518:     	bl	0x10236a838 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext14check_capacity>
10162751c:     	add	x21, sp, #0x450
101627520:     	ldrb	w8, [sp, #0x450]
101627524:     	cmp	w8, #0x8
101627528:     	b.ne	0x101627600 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x394>
10162752c:     	add	x8, sp, #0x450
101627530:     	add	x0, sp, #0xb8
101627534:     	mov	x1, x25
101627538:     	bl	0x102d509a4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
10162753c:     	ldr	w25, [sp, #0x450]
101627540:     	cmp	w25, #0x1a
101627544:     	b.ne	0x101627778 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x50c>
101627548:     	ldur	q0, [x21, #0x8]
10162754c:     	ldur	q1, [x21, #0x18]
101627550:     	stp	q0, q1, [x28, #0xb0]
101627554:     	add	x8, sp, #0x450
101627558:     	add	x0, sp, #0xb8
10162755c:     	add	x1, x27, #0x8
101627560:     	bl	0x102d50878 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
101627564:     	ldr	w25, [sp, #0x450]
101627568:     	cmp	w25, #0x1a
10162756c:     	ldr	x8, [sp, #0x40]
101627570:     	b.ne	0x10162779c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x530>
101627574:     	ldur	q0, [x21, #0x8]
101627578:     	ldur	q1, [x21, #0x18]
10162757c:     	stp	q0, q1, [x28, #0xd0]
101627580:     	ldr	x1, [x8]
101627584:     	cbz	x1, 0x1016275ac <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x340>
101627588:     	ldr	x2, [x8, #0x8]
10162758c:     	add	x8, sp, #0x450
101627590:     	add	x3, sp, #0xb8
101627594:     	add	x4, sp, #0xd0
101627598:     	ldr	x0, [sp, #0x38]
10162759c:     	bl	0x10253c9ec <__RNvMs_NtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared17frame_compositionNtB6_25NativePreparedLibraryCall23admit_composed_selector>
1016275a0:     	ldrb	w26, [sp, #0x450]
1016275a4:     	cmp	w26, #0x2e
1016275a8:     	b.ne	0x101627b94 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x928>
1016275ac:     	add	x8, sp, #0x450
1016275b0:     	add	x1, sp, #0x230
1016275b4:     	mov	x0, x24
1016275b8:     	bl	0x1023745d8 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter21for_native_projection>
1016275bc:     	ldr	x9, [sp, #0x450]
1016275c0:     	ldr	x8, [sp, #0x458]
1016275c4:     	ldp	q2, q3, [x21, #0x10]
1016275c8:     	cmp	x9, #0x2
1016275cc:     	b.ne	0x1016277c0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x554>
1016275d0:     	stp	q3, q2, [sp, #0x60]
1016275d4:     	and	w25, w8, #0xff
1016275d8:     	lsr	w21, w8, #8
1016275dc:     	lsr	x22, x8, #32
1016275e0:     	mov	w26, #0x29              ; =41
1016275e4:     	b	0x101627bdc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
1016275e8:     	ldr	w22, [sp, #0x324]
1016275ec:     	ldr	w8, [sp, #0x320]
1016275f0:     	ldur	q0, [x23, #0x18]
1016275f4:     	str	q0, [sp, #0x60]
1016275f8:     	ldur	q0, [x23, #0x8]
1016275fc:     	b	0x101627614 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3a8>
101627600:     	ldr	w22, [sp, #0x454]
101627604:     	ldr	w8, [sp, #0x450]
101627608:     	ldur	q0, [x21, #0x18]
10162760c:     	str	q0, [sp, #0x60]
101627610:     	ldur	q0, [x21, #0x8]
101627614:     	str	q0, [sp, #0x70]
101627618:     	and	w25, w8, #0xff
10162761c:     	lsr	w21, w8, #8
101627620:     	mov	w26, #0x29              ; =41
101627624:     	ldr	w8, [sp, #0x200]
101627628:     	cmp	w8, #0x1a
10162762c:     	b.eq	0x101627680 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101627630:     	cmp	w8, #0xa
101627634:     	b.eq	0x101627650 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3e4>
101627638:     	cmp	w8, #0x13
10162763c:     	b.ne	0x101627680 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101627640:     	ldr	x1, [sp, #0x210]
101627644:     	mov	w8, #0x10               ; =16
101627648:     	cbnz	x1, 0x101627668 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3fc>
10162764c:     	b	0x101627680 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101627650:     	ldr	x1, [sp, #0x218]
101627654:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101627658:     	cmp	x1, x8
10162765c:     	b.eq	0x101627680 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101627660:     	mov	w8, #0x18               ; =24
101627664:     	cbz	x1, 0x101627680 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x414>
101627668:     	add	x9, sp, #0xd0
10162766c:     	add	x9, x9, #0x130
101627670:     	add	x8, x9, x8
101627674:     	ldr	x0, [x8, #0x8]
101627678:     	mov	w2, #0x1                ; =1
10162767c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101627680:     	ldr	x8, [sp, #0xb8]
101627684:     	mov	x9, #-0x1               ; =-1
101627688:     	ldaddl	x9, x8, [x8]
10162768c:     	cmp	x8, #0x1
101627690:     	b.ne	0x1016276a0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
101627694:     	dmb	ishld
101627698:     	add	x0, sp, #0xb8
10162769c:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1016276a0:     	add	x27, sp, #0x98
1016276a4:     	ldur	w8, [x29, #-0xe0]
1016276a8:     	str	w8, [sp, #0xd0]
1016276ac:     	ldurh	w8, [x29, #-0xdc]
1016276b0:     	strh	w8, [sp, #0xd4]
1016276b4:     	ldp	x8, x9, [sp, #0x50]
1016276b8:     	stp	x9, x8, [x19, #0x30]
1016276bc:     	ldr	x8, [sp, #0x48]
1016276c0:     	str	x8, [x19, #0x40]
1016276c4:     	add	x0, sp, #0x98
1016276c8:     	bl	0x1023b42f4 <__RNvXs_NvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBa_23NativeLibraryWorkBudget16with_call_limitsNtB4_10ScopeGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
1016276cc:     	ldr	x8, [sp, #0xa0]
1016276d0:     	cbz	x8, 0x1016276ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
1016276d4:     	ldr	x9, [x8]
1016276d8:     	subs	x9, x9, #0x1
1016276dc:     	str	x9, [x8]
1016276e0:     	b.ne	0x1016276ec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x480>
1016276e4:     	add	x0, x27, #0x8
1016276e8:     	bl	0x102370b00 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
1016276ec:     	add	x19, sp, #0x88
1016276f0:     	add	x0, sp, #0x88
1016276f4:     	bl	0x102397690 <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
1016276f8:     	and	x27, x21, #0xffffff
1016276fc:     	mov	w21, w22
101627700:     	ldr	x8, [sp, #0x90]
101627704:     	cbz	x8, 0x101627720 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
101627708:     	ldr	x9, [x8]
10162770c:     	subs	x9, x9, #0x1
101627710:     	str	x9, [x8]
101627714:     	b.ne	0x101627720 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x4b4>
101627718:     	add	x0, x19, #0x8
10162771c:     	bl	0x102370b00 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101627720:     	lsl	x8, x27, #8
101627724:     	orr	x8, x8, x21, lsl #32
101627728:     	mov	w9, w25
10162772c:     	orr	x9, x8, x9
101627730:     	ldp	q1, q0, [sp, #0x60]
101627734:     	ldr	w8, [sp, #0xd0]
101627738:     	stur	w8, [x20, #0x2]
10162773c:     	ldrh	w8, [sp, #0xd4]
101627740:     	strh	w8, [x20, #0x6]
101627744:     	strb	w26, [x20]
101627748:     	strb	w23, [x20, #0x1]
10162774c:     	str	x9, [x20, #0x8]
101627750:     	stp	q0, q1, [x20, #0x10]
101627754:     	str	x24, [x20, #0x30]
101627758:     	add	sp, sp, #0x610
10162775c:     	ldp	x29, x30, [sp, #0x50]
101627760:     	ldp	x20, x19, [sp, #0x40]
101627764:     	ldp	x22, x21, [sp, #0x30]
101627768:     	ldp	x24, x23, [sp, #0x20]
10162776c:     	ldp	x26, x25, [sp, #0x10]
101627770:     	ldp	x28, x27, [sp], #0x60
101627774:     	ret
101627778:     	add	x8, sp, #0x450
10162777c:     	mov	w21, #0x0               ; =0
101627780:     	ldr	w22, [sp, #0x454]
101627784:     	ldur	q1, [x8, #0x18]
101627788:     	ldur	q0, [x8, #0x8]
10162778c:     	stp	q1, q0, [sp, #0x60]
101627790:     	mov	w26, #0x2b              ; =43
101627794:     	ldr	x24, [sp, #0x478]
101627798:     	b	0x101627624 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
10162779c:     	add	x8, sp, #0x450
1016277a0:     	mov	w21, #0x0               ; =0
1016277a4:     	ldr	w22, [sp, #0x454]
1016277a8:     	ldur	q1, [x8, #0x18]
1016277ac:     	ldur	q0, [x8, #0x8]
1016277b0:     	stp	q1, q0, [sp, #0x60]
1016277b4:     	mov	w26, #0x2b              ; =43
1016277b8:     	ldr	x24, [sp, #0x478]
1016277bc:     	b	0x101627c04 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x998>
1016277c0:     	ldp	q0, q1, [x21, #0xf0]
1016277c4:     	stp	q0, q1, [x28, #0x1e0]
1016277c8:     	ldp	q0, q1, [x21, #0x110]
1016277cc:     	stp	q0, q1, [x28, #0x200]
1016277d0:     	ldp	q0, q1, [x21, #0xb0]
1016277d4:     	stp	q0, q1, [x28, #0x1a0]
1016277d8:     	ldp	q0, q1, [x21, #0xd0]
1016277dc:     	stp	q0, q1, [x28, #0x1c0]
1016277e0:     	ldp	q0, q1, [x21, #0x70]
1016277e4:     	stp	q0, q1, [x28, #0x160]
1016277e8:     	ldp	q0, q1, [x21, #0x90]
1016277ec:     	stp	q0, q1, [x28, #0x180]
1016277f0:     	ldp	q0, q1, [x21, #0x30]
1016277f4:     	stp	q0, q1, [x28, #0x120]
1016277f8:     	ldp	q0, q1, [x21, #0x50]
1016277fc:     	stp	q0, q1, [x28, #0x140]
101627800:     	stp	q2, q3, [x28, #0x100]
101627804:     	str	x8, [sp, #0x328]
101627808:     	str	x9, [sp, #0x320]
10162780c:     	ldr	x10, [sp, #0x70]
101627810:     	ldr	x1, [x10]
101627814:     	cbz	x1, 0x10162787c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
101627818:     	ldp	x9, x8, [sp, #0x30]
10162781c:     	ldr	x8, [x8, #0x190]
101627820:     	ldr	q0, [x9]
101627824:     	str	q0, [x21]
101627828:     	ldr	q0, [x9, #0x10]
10162782c:     	str	q0, [x21, #0x10]
101627830:     	ldr	q0, [x9, #0x20]
101627834:     	str	q0, [x21, #0x20]
101627838:     	ldr	x9, [x9, #0x30]
10162783c:     	str	x9, [sp, #0x480]
101627840:     	ldr	x2, [x10, #0x8]
101627844:     	sub	x0, x29, #0xe0
101627848:     	add	x3, x8, #0x10
10162784c:     	add	x4, sp, #0x450
101627850:     	add	x5, sp, #0xb8
101627854:     	add	x6, sp, #0x320
101627858:     	bl	0x101621484 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>
10162785c:     	ldurb	w25, [x29, #-0xe0]
101627860:     	cmp	w25, #0x8
101627864:     	b.ne	0x101627ae0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x874>
101627868:     	ldur	x8, [x29, #-0xd8]
10162786c:     	cbz	x8, 0x10162787c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x610>
101627870:     	ldur	x23, [x29, #-0xd0]
101627874:     	ldr	x11, [sp, #0x30]
101627878:     	b	0x101627b10 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
10162787c:     	ldr	x11, [sp, #0x30]
101627880:     	ldr	x8, [sp, #0x18]
101627884:     	cbz	x8, 0x101627b0c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a0>
101627888:     	mov	x22, #0x0               ; =0
10162788c:     	mov	x23, #0x0               ; =0
101627890:     	mov	x24, #0x0               ; =0
101627894:     	adrp	x9, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101627898:     	add	x9, x9, #0xc0
10162789c:     	str	x9, [sp, #0x40]
1016278a0:     	lsl	x28, x8, #2
1016278a4:     	mov	w27, #0x2c              ; =44
1016278a8:     	ldr	x1, [x11, #0x8]
1016278ac:     	cmp	x24, x1
1016278b0:     	b.hs	0x101627d78 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb0c>
1016278b4:     	ldr	x8, [x11]
1016278b8:     	add	x8, x8, x22
1016278bc:     	ldrb	w9, [x8]
1016278c0:     	cmp	w9, #0x3
1016278c4:     	str	x23, [sp, #0x70]
1016278c8:     	b.ne	0x10162790c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6a0>
1016278cc:     	ldr	x8, [x8, #0x8]
1016278d0:     	ldr	x1, [x11, #0x18]
1016278d4:     	cmp	x8, x1
1016278d8:     	b.hs	0x101627d58 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xaec>
1016278dc:     	ldr	x1, [x11, #0x28]
1016278e0:     	cmp	x8, x1
1016278e4:     	b.hs	0x101627d68 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xafc>
1016278e8:     	ldr	x9, [x11, #0x10]
1016278ec:     	add	x9, x9, x8, lsl #6
1016278f0:     	ldr	x10, [x9]
1016278f4:     	cmp	x10, #0x0
1016278f8:     	csel	x26, xzr, x9, eq
1016278fc:     	ldr	x9, [x11, #0x20]
101627900:     	ldr	x25, [x9, x8, lsl #3]
101627904:     	strb	w27, [sp, #0x450]
101627908:     	b	0x101627948 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x6dc>
10162790c:     	ldr	q0, [x8]
101627910:     	str	q0, [x21]
101627914:     	ldr	q0, [x8, #0x10]
101627918:     	str	q0, [x21, #0x10]
10162791c:     	ldr	x8, [x11, #0x30]
101627920:     	ldr	x8, [x8]
101627924:     	ldr	x1, [x8]
101627928:     	sub	x0, x29, #0xe0
10162792c:     	add	x2, sp, #0x450
101627930:     	bl	0x101635f6c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101627934:     	ldur	x8, [x29, #-0xe0]
101627938:     	strb	w27, [sp, #0x450]
10162793c:     	cmp	x8, #0x1
101627940:     	b.ne	0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
101627944:     	ldp	x26, x25, [x29, #-0xd8]
101627948:     	add	x0, sp, #0x450
10162794c:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101627950:     	ldr	x8, [sp, #0x38]
101627954:     	ldr	x23, [x8, #0x190]
101627958:     	ldr	x8, [sp, #0x28]
10162795c:     	ldr	w21, [x8, x24, lsl #2]
101627960:     	ldr	x8, [x23, #0x28]
101627964:     	cmp	x8, x21
101627968:     	b.ls	0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
10162796c:     	ldr	x8, [x23, #0x20]
101627970:     	mov	w9, #0x2c               ; =44
101627974:     	add	x27, x8, x21, lsl #7
101627978:     	strb	w9, [sp, #0x450]
10162797c:     	add	x0, sp, #0x450
101627980:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101627984:     	cbz	x26, 0x101627a2c <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x7c0>
101627988:     	cbnz	x25, 0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
10162798c:     	ldr	w8, [x26, #0x38]
101627990:     	cmp	w8, w21
101627994:     	b.ne	0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
101627998:     	ldp	q1, q0, [x26, #0x10]
10162799c:     	add	x21, sp, #0x450
1016279a0:     	stp	q1, q0, [x21, #0x130]
1016279a4:     	ldur	q0, [x27, #0x70]
1016279a8:     	str	q0, [x21]
1016279ac:     	ldur	q0, [x27, #0x80]
1016279b0:     	str	q0, [x21, #0x10]
1016279b4:     	ldp	x8, x9, [x29, #-0xe0]
1016279b8:     	ldr	x10, [sp, #0x450]
1016279bc:     	ldr	x11, [sp, #0x458]
1016279c0:     	ldp	x12, x13, [x29, #-0xd0]
1016279c4:     	ldr	x14, [sp, #0x460]
1016279c8:     	ldr	x15, [sp, #0x468]
1016279cc:     	cmp	x8, x10
1016279d0:     	ccmp	x9, x11, #0x0, eq
1016279d4:     	ccmp	x12, x14, #0x0, eq
1016279d8:     	ccmp	x13, x15, #0x0, eq
1016279dc:     	b.ne	0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
1016279e0:     	add	x1, sp, #0xb8
1016279e4:     	mov	x0, x26
1016279e8:     	bl	0x102e10a94 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
1016279ec:     	mov	w27, #0x2c              ; =44
1016279f0:     	cmp	x0, #0x1
1016279f4:     	b.ne	0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
1016279f8:     	sub	x8, x29, #0xb8
1016279fc:     	add	x1, x23, #0x10
101627a00:     	mov	x0, x26
101627a04:     	bl	0x102e0eb78 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
101627a08:     	ldurb	w8, [x29, #-0xb8]
101627a0c:     	cmp	w8, #0x16
101627a10:     	b.ne	0x101627d38 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xacc>
101627a14:     	add	x8, sp, #0x450
101627a18:     	add	x0, sp, #0x320
101627a1c:     	add	x2, x23, #0x10
101627a20:     	mov	x1, x26
101627a24:     	bl	0x102383980 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget42measure_borrowed_canonical_value_footprint>
101627a28:     	b	0x101627aa0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x834>
101627a2c:     	ldur	x8, [x27, #0x58]
101627a30:     	cbnz	x8, 0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
101627a34:     	ldurh	w1, [x27, #0x12]
101627a38:     	ldurb	w0, [x27, #0x10]
101627a3c:     	bl	0x101635cb4 <__RNvMNtCs1qJAwyMG1lC_11mech_engine13native_scalarNtB2_16NativeScalarKind16from_schema_body>
101627a40:     	and	w26, w0, #0xff
101627a44:     	mov	w21, #0x2c              ; =44
101627a48:     	strb	w21, [sp, #0x450]
101627a4c:     	cmp	w26, #0x7
101627a50:     	b.eq	0x101627d40 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad4>
101627a54:     	add	x0, sp, #0x450
101627a58:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101627a5c:     	sub	x0, x29, #0x70
101627a60:     	mov	x1, x26
101627a64:     	mov	x2, x25
101627a68:     	bl	0x101635d24 <__RNvMNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact2irNtB2_17NativeScalarValue9from_bits>
101627a6c:     	strb	w21, [sp, #0x450]
101627a70:     	ldurb	w8, [x29, #-0x70]
101627a74:     	cmp	w8, #0x7
101627a78:     	b.eq	0x101627d40 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xad4>
101627a7c:     	add	x0, sp, #0x450
101627a80:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101627a84:     	add	x8, sp, #0x450
101627a88:     	add	x0, sp, #0x320
101627a8c:     	add	x1, x27, #0x10
101627a90:     	sub	x2, x29, #0x70
101627a94:     	bl	0x102382cd0 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget37measure_native_scalar_frame_footprint>
101627a98:     	add	x21, sp, #0x450
101627a9c:     	mov	w27, #0x2c              ; =44
101627aa0:     	ldrb	w25, [sp, #0x450]
101627aa4:     	cmp	w25, #0x8
101627aa8:     	b.ne	0x101627cf8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa8c>
101627aac:     	ldr	x8, [sp, #0x460]
101627ab0:     	ldr	x23, [sp, #0x70]
101627ab4:     	adds	x23, x8, x23
101627ab8:     	b.hs	0x101627bcc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x960>
101627abc:     	strb	w27, [sp, #0x450]
101627ac0:     	add	x0, sp, #0x450
101627ac4:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101627ac8:     	add	x22, x22, #0x20
101627acc:     	add	x24, x24, #0x1
101627ad0:     	subs	x28, x28, #0x4
101627ad4:     	ldr	x11, [sp, #0x30]
101627ad8:     	b.ne	0x1016278a8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x63c>
101627adc:     	b	0x101627b10 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8a4>
101627ae0:     	sub	x8, x29, #0xe0
101627ae4:     	ldurb	w9, [x29, #-0xdd]
101627ae8:     	ldurh	w10, [x8, #0x1]
101627aec:     	orr	w21, w10, w9, lsl #16
101627af0:     	ldur	w22, [x29, #-0xdc]
101627af4:     	ldur	q0, [x8, #0x18]
101627af8:     	str	q0, [sp, #0x60]
101627afc:     	ldur	q0, [x8, #0x8]
101627b00:     	str	q0, [sp, #0x70]
101627b04:     	mov	w26, #0x29              ; =41
101627b08:     	b	0x101627bdc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
101627b0c:     	mov	x23, #0x0               ; =0
101627b10:     	ldr	x0, [sp, #0x20]
101627b14:     	mov	x1, x11
101627b18:     	bl	0x101620b4c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_>
101627b1c:     	tbnz	w0, #0x0, 0x101627b44 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x8d8>
101627b20:     	ldp	x4, x8, [sp, #0x30]
101627b24:     	ldr	x8, [x8, #0x190]
101627b28:     	ldp	x2, x3, [x8, #0x20]
101627b2c:     	add	x0, sp, #0x450
101627b30:     	ldr	x1, [sp, #0x20]
101627b34:     	bl	0x101620de8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_>
101627b38:     	ldrb	w26, [sp, #0x450]
101627b3c:     	cmp	w26, #0x2e
101627b40:     	b.ne	0x101627b94 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x928>
101627b44:     	ldr	x8, [sp, #0x60]
101627b48:     	ldr	x8, [x8]
101627b4c:     	subs	x8, x23, x8
101627b50:     	ldr	x11, [sp, #0x38]
101627b54:     	add	x12, sp, #0x450
101627b58:     	b.lo	0x101627b74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x908>
101627b5c:     	ldr	x9, [sp, #0x10]
101627b60:     	ldr	x9, [x9]
101627b64:     	mov	w10, #0x2c              ; =44
101627b68:     	strb	w10, [sp, #0x450]
101627b6c:     	adds	x22, x9, x8
101627b70:     	b.lo	0x101627c30 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x9c4>
101627b74:     	mov	w21, #0x0               ; =0
101627b78:     	mov	w25, #0x0               ; =0
101627b7c:     	mov	w22, #0x0               ; =0
101627b80:     	ldur	w8, [x12, #0x2]
101627b84:     	stur	w8, [x29, #-0xe0]
101627b88:     	ldrh	w8, [sp, #0x456]
101627b8c:     	sturh	w8, [x29, #-0xdc]
101627b90:     	b	0x101627bd8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x96c>
101627b94:     	ldrb	w23, [sp, #0x451]
101627b98:     	ldur	w8, [x21, #0x2]
101627b9c:     	stur	w8, [x29, #-0xe0]
101627ba0:     	ldrh	w8, [sp, #0x456]
101627ba4:     	sturh	w8, [x29, #-0xdc]
101627ba8:     	ldr	w22, [sp, #0x45c]
101627bac:     	ldr	w8, [sp, #0x458]
101627bb0:     	and	w25, w8, #0xff
101627bb4:     	add	x9, sp, #0x450
101627bb8:     	lsr	w21, w8, #8
101627bbc:     	ldp	q0, q1, [x9, #0x10]
101627bc0:     	stp	q1, q0, [sp, #0x60]
101627bc4:     	ldr	x24, [sp, #0x480]
101627bc8:     	b	0x101627bdc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
101627bcc:     	mov	w21, #0x0               ; =0
101627bd0:     	mov	w25, #0x0               ; =0
101627bd4:     	mov	w22, #0x0               ; =0
101627bd8:     	mov	w26, #0x2c              ; =44
101627bdc:     	add	x0, sp, #0x300
101627be0:     	bl	0x102d55e30 <__RNvXs4_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_22ManagedNodeReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101627be4:     	ldr	x8, [sp, #0x300]
101627be8:     	mov	x9, #-0x1               ; =-1
101627bec:     	ldaddl	x9, x8, [x8]
101627bf0:     	cmp	x8, #0x1
101627bf4:     	b.ne	0x101627c04 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x998>
101627bf8:     	dmb	ishld
101627bfc:     	add	x0, sp, #0x300
101627c00:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101627c04:     	add	x0, sp, #0x2e0
101627c08:     	bl	0x102d56100 <__RNvXs6_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservationNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
101627c0c:     	ldr	x8, [sp, #0x2e0]
101627c10:     	mov	x9, #-0x1               ; =-1
101627c14:     	ldaddl	x9, x8, [x8]
101627c18:     	cmp	x8, #0x1
101627c1c:     	b.ne	0x101627624 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101627c20:     	dmb	ishld
101627c24:     	add	x0, sp, #0x2e0
101627c28:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101627c2c:     	b	0x101627624 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101627c30:     	add	x0, sp, #0x450
101627c34:     	mov	x21, x11
101627c38:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101627c3c:     	ldr	w8, [x21, #0x110]
101627c40:     	ldr	x9, [sp, #0x8]
101627c44:     	ldr	x9, [x9]
101627c48:     	movi.2d	v0, #0000000000000000
101627c4c:     	add	x21, sp, #0x450
101627c50:     	stp	q0, q0, [x21, #0x20]
101627c54:     	str	q0, [x21, #0x40]
101627c58:     	str	xzr, [sp, #0x4a0]
101627c5c:     	str	x9, [sp, #0x4a8]
101627c60:     	str	wzr, [sp, #0x4b0]
101627c64:     	stp	q0, q0, [x21]
101627c68:     	mov	w9, #0x3                ; =3
101627c6c:     	orr	x1, x9, x8, lsl #32
101627c70:     	sub	x0, x29, #0xe0
101627c74:     	add	x2, sp, #0x450
101627c78:     	add	x4, sp, #0x230
101627c7c:     	mov	x3, x22
101627c80:     	bl	0x101634c6c <__RINvNtNtCskIfnrfrMWVM_9mech_core11memory_plan6budget30visit_memory_budget_violationsNtB2_21MemoryBudgetViolationNcNtINtNtNtCsgDHHaSskbIF_4core3ops12control_flow11ControlFlowB1k_E5Break0ECs7fdMCt8k5K6_8mech_gpu>
101627c84:     	ldurb	w8, [x29, #-0xe0]
101627c88:     	cmp	w8, #0x8
101627c8c:     	b.ne	0x101627ce4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa78>
101627c90:     	add	x0, sp, #0x300
101627c94:     	bl	0x1016318f8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101627c98:     	add	x0, sp, #0x2e0
101627c9c:     	bl	0x101631970 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101627ca0:     	ldr	w8, [sp, #0x200]
101627ca4:     	cmp	w8, #0x1a
101627ca8:     	b.eq	0x101627cb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xa4c>
101627cac:     	add	x8, sp, #0xd0
101627cb0:     	add	x0, x8, #0x130
101627cb4:     	bl	0x1016318a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
101627cb8:     	mov	w25, #0x0               ; =0
101627cbc:     	ldr	x8, [sp, #0xb8]
101627cc0:     	mov	x9, #-0x1               ; =-1
101627cc4:     	ldaddl	x9, x8, [x8]
101627cc8:     	mov	w26, #0x2e              ; =46
101627ccc:     	cmp	x8, #0x1
101627cd0:     	b.eq	0x101627694 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x428>
101627cd4:     	b	0x1016276a0 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x434>
101627cd8:     	adrp	x0, 0x107f0f000 <_anon.797b2294c71d6bb404c294e7e4131068.123+0x2a0>
101627cdc:     	add	x0, x0, #0xfa0
101627ce0:     	bl	0x103a01ef8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
101627ce4:     	ldp	q0, q1, [x21, #0x130]
101627ce8:     	stp	q1, q0, [sp, #0x60]
101627cec:     	mov	w26, #0x2a              ; =42
101627cf0:     	mov	w25, #0x12              ; =18
101627cf4:     	b	0x101627bdc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
101627cf8:     	ldrb	w8, [sp, #0x453]
101627cfc:     	ldurh	w9, [x21, #0x1]
101627d00:     	add	x10, sp, #0x450
101627d04:     	orr	w21, w9, w8, lsl #16
101627d08:     	ldr	w22, [sp, #0x454]
101627d0c:     	ldur	q0, [x10, #0x18]
101627d10:     	str	q0, [sp, #0x60]
101627d14:     	ldur	q0, [x10, #0x8]
101627d18:     	b	0x101627b00 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x894>
101627d1c:     	adrp	x0, 0x107f0f000 <_anon.797b2294c71d6bb404c294e7e4131068.123+0x2a0>
101627d20:     	add	x0, x0, #0xf88
101627d24:     	bl	0x103a01ef8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
101627d28:     	b	0x101627d84 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb18>
101627d2c:     	mov	w25, #0x0               ; =0
101627d30:     	mov	w26, #0x2c              ; =44
101627d34:     	b	0x101627624 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x3b8>
101627d38:     	sub	x0, x29, #0xb8
101627d3c:     	bl	0x101632b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
101627d40:     	mov	w25, #0x0               ; =0
101627d44:     	mov	w26, #0x2c              ; =44
101627d48:     	b	0x101627bdc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0x970>
101627d4c:     	adrp	x0, 0x107f0f000 <_anon.797b2294c71d6bb404c294e7e4131068.123+0x2a0>
101627d50:     	add	x0, x0, #0xf28
101627d54:     	bl	0x103a01874 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
101627d58:     	mov	x24, x8
101627d5c:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101627d60:     	add	x8, x8, #0xd8
101627d64:     	b	0x101627d74 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb08>
101627d68:     	mov	x24, x8
101627d6c:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101627d70:     	add	x8, x8, #0xf0
101627d74:     	str	x8, [sp, #0x40]
101627d78:     	mov	x0, x24
101627d7c:     	ldr	x2, [sp, #0x40]
101627d80:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101627d84:     	brk	#0x1
101627d88:     	mov	x20, x0
101627d8c:     	ldr	x8, [sp, #0x300]
101627d90:     	mov	x9, #-0x1               ; =-1
101627d94:     	ldaddl	x9, x8, [x8]
101627d98:     	cmp	x8, #0x1
101627d9c:     	b.ne	0x101627df8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb8c>
101627da0:     	dmb	ishld
101627da4:     	add	x0, sp, #0x300
101627da8:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101627dac:     	b	0x101627df8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb8c>
101627db0:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101627db4:     	b	0x101627dec <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb80>
101627db8:     	mov	x20, x0
101627dbc:     	ldr	x8, [sp, #0x2e0]
101627dc0:     	mov	x9, #-0x1               ; =-1
101627dc4:     	ldaddl	x9, x8, [x8]
101627dc8:     	cmp	x8, #0x1
101627dcc:     	b.ne	0x101627e80 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc14>
101627dd0:     	dmb	ishld
101627dd4:     	add	x0, sp, #0x2e0
101627dd8:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101627ddc:     	b	0x101627e80 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc14>
101627de0:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101627de4:     	mov	x20, x0
101627de8:     	b	0x101627df8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xb8c>
101627dec:     	mov	x20, x0
101627df0:     	add	x0, sp, #0x300
101627df4:     	bl	0x1016318f8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101627df8:     	add	x0, sp, #0x2e0
101627dfc:     	bl	0x101631970 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101627e00:     	b	0x101627e80 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc14>
101627e04:     	mov	x20, x0
101627e08:     	b	0x101627ef4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc88>
101627e0c:     	mov	x20, x0
101627e10:     	ldr	x8, [sp, #0x90]
101627e14:     	cbz	x8, 0x101627efc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc90>
101627e18:     	ldr	x9, [x8]
101627e1c:     	subs	x9, x9, #0x1
101627e20:     	str	x9, [x8]
101627e24:     	b.ne	0x101627efc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc90>
101627e28:     	add	x0, x19, #0x8
101627e2c:     	bl	0x102370b00 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101627e30:     	b	0x101627efc <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc90>
101627e34:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101627e38:     	mov	x20, x0
101627e3c:     	ldr	x8, [sp, #0xa0]
101627e40:     	cbz	x8, 0x101627ef4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc88>
101627e44:     	ldr	x9, [x8]
101627e48:     	subs	x9, x9, #0x1
101627e4c:     	str	x9, [x8]
101627e50:     	b.ne	0x101627ef4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc88>
101627e54:     	add	x0, x27, #0x8
101627e58:     	bl	0x102370b00 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101627e5c:     	b	0x101627ef4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc88>
101627e60:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101627e64:     	mov	x20, x0
101627e68:     	b	0x101627e98 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc2c>
101627e6c:     	mov	x20, x0
101627e70:     	b	0x101627ec8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc5c>
101627e74:     	mov	x20, x0
101627e78:     	b	0x101627eb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc4c>
101627e7c:     	mov	x20, x0
101627e80:     	ldr	w8, [sp, #0x200]
101627e84:     	cmp	w8, #0x1a
101627e88:     	b.eq	0x101627e98 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc2c>
101627e8c:     	add	x8, sp, #0xd0
101627e90:     	add	x0, x8, #0x130
101627e94:     	bl	0x1016318a8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime5error18MemoryRuntimeErrorECs7fdMCt8k5K6_8mech_gpu>
101627e98:     	ldr	x8, [sp, #0xb8]
101627e9c:     	mov	x9, #-0x1               ; =-1
101627ea0:     	ldaddl	x9, x8, [x8]
101627ea4:     	cmp	x8, #0x1
101627ea8:     	b.ne	0x101627eb8 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc4c>
101627eac:     	dmb	ishld
101627eb0:     	add	x0, sp, #0xb8
101627eb4:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101627eb8:     	ldp	x8, x9, [sp, #0x50]
101627ebc:     	stp	x9, x8, [x19, #0x30]
101627ec0:     	ldr	x8, [sp, #0x48]
101627ec4:     	str	x8, [x19, #0x40]
101627ec8:     	add	x0, sp, #0x98
101627ecc:     	bl	0x101634b7c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits10ScopeGuardECs7fdMCt8k5K6_8mech_gpu>
101627ed0:     	b	0x101627ef4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc88>
101627ed4:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101627ed8:     	mov	x20, x0
101627edc:     	ldr	x8, [x23]
101627ee0:     	subs	x8, x8, #0x1
101627ee4:     	str	x8, [x23]
101627ee8:     	b.ne	0x101627ef4 <__RINvMs2_NtNtCsgirOGyZpP7g_3std6thread5localINtB6_8LocalKeyNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkContextE4withNCINvMs0_BW_NtBW_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultuNtNtNtNtBY_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCINvMs_NtNtB3M_8prepared17frame_compositionNtB5k_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB72_10Invocation19buffer_frame_actions5_0Es_0E0IB36_B35_NtNtNtCskIfnrfrMWVM_9mech_core8function8resident19ResidentKernelErrorEEB7a_+0xc88>
101627eec:     	add	x0, sp, #0xd0
101627ef0:     	bl	0x102370b00 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
101627ef4:     	add	x0, sp, #0x88
101627ef8:     	bl	0x101634bf4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits12AccountGuardECs7fdMCt8k5K6_8mech_gpu>
101627efc:     	mov	x0, x20
101627f00:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
101627f04:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101627f08:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
