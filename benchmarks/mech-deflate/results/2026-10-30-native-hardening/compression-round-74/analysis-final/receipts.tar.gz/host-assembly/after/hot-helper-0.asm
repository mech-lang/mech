
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015402d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper>:
1015402d4:     	stp	x28, x27, [sp, #-0x60]!
1015402d8:     	stp	x26, x25, [sp, #0x10]
1015402dc:     	stp	x24, x23, [sp, #0x20]
1015402e0:     	stp	x22, x21, [sp, #0x30]
1015402e4:     	stp	x20, x19, [sp, #0x40]
1015402e8:     	stp	x29, x30, [sp, #0x50]
1015402ec:     	add	x29, sp, #0x50
1015402f0:     	sub	sp, sp, #0x810
1015402f4:     	str	xzr, [sp]
1015402f8:     	add	x9, x2, #0x1d
1015402fc:     	cmp	x9, #0x1f
101540300:     	b.hi	0x10154032c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101540304:     	mov	w10, #-0x10000001       ; =-268435457
101540308:     	lsr	w10, w10, w9
10154030c:     	tbz	w10, #0x0, 0x10154032c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58>
101540310:     	adrp	x10, 0x107551000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.887+0x1b7>
101540314:     	add	x10, x10, #0xfa0
101540318:     	ldr	x22, [x10, x9, lsl #3]
10154031c:     	ldr	x9, [x0, #0x238]
101540320:     	cmp	x9, #0x3
101540324:     	b.ne	0x101540340 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6c>
101540328:     	b	0x101540368 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
10154032c:     	sub	x21, x2, #0x3
101540330:     	mov	w22, #0x3               ; =3
101540334:     	ldr	x9, [x0, #0x238]
101540338:     	cmp	x9, #0x3
10154033c:     	b.eq	0x101540368 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101540340:     	ldr	w9, [x0, #0x268]
101540344:     	cbz	w9, 0x101540368 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x94>
101540348:     	str	wzr, [x8]
10154034c:     	mov	w9, #0xc                ; =12
101540350:     	strb	w9, [x8, #0x8]
101540354:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540358:     	add	x9, x9, #0x646
10154035c:     	mov	w10, #0x25              ; =37
101540360:     	stp	x9, x10, [x8, #0x10]
101540364:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540368:     	cmp	x22, #0xb
10154036c:     	b.eq	0x101540444 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x170>
101540370:     	add	x27, sp, #0x550
101540374:     	add	x24, sp, #0x440
101540378:     	add	x26, sp, #0x330
10154037c:     	add	x25, sp, #0x220
101540380:     	cmp	x22, #0x1d
101540384:     	b.eq	0x1015403d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104>
101540388:     	cmp	x22, #0x1f
10154038c:     	b.ne	0x101540474 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a0>
101540390:     	ldp	x20, x28, [x3]
101540394:     	ldr	x10, [x3, #0x10]
101540398:     	ldp	x12, x11, [x0, #0xc0]
10154039c:     	ldp	x26, x19, [x0, #0xd0]
1015403a0:     	ldp	x22, x25, [x0, #0xe0]
1015403a4:     	ldr	w9, [x0, #0xf0]
1015403a8:     	mov	w13, #0x2               ; =2
1015403ac:     	str	x13, [x0, #0xc0]
1015403b0:     	cbz	x12, 0x1015404f0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x21c>
1015403b4:     	cmp	x12, #0x2
1015403b8:     	b.ne	0x10154050c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x238>
1015403bc:     	str	wzr, [x8]
1015403c0:     	mov	w9, #0xc                ; =12
1015403c4:     	adrp	x10, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
1015403c8:     	add	x10, x10, #0xef9
1015403cc:     	stp	x9, x10, [x8, #0x8]
1015403d0:     	mov	w9, #0x20               ; =32
1015403d4:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015403d8:     	ldr	x19, [x0, #0x4a0]
1015403dc:     	ldr	x9, [x19, #0x270]
1015403e0:     	cmp	x1, x9
1015403e4:     	b.hs	0x1015404b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
1015403e8:     	ldr	x9, [x19, #0x268]
1015403ec:     	add	x9, x9, x1, lsl #4
1015403f0:     	ldr	w10, [x9]
1015403f4:     	tbz	w10, #0x0, 0x1015404b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e4>
1015403f8:     	ldr	x9, [x9, #0x8]
1015403fc:     	ldr	x10, [x19, #0x258]
101540400:     	cmp	x9, x10
101540404:     	b.hs	0x101542b54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2880>
101540408:     	ldr	x10, [x19, #0x250]
10154040c:     	mov	w11, #0x160             ; =352
101540410:     	madd	x21, x9, x11, x10
101540414:     	mov	x20, x21
101540418:     	ldr	x10, [x20, #0x30]!
10154041c:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
101540420:     	cmp	x10, x11
101540424:     	b.ne	0x10154060c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x338>
101540428:     	str	wzr, [x8]
10154042c:     	mov	w9, #0xc                ; =12
101540430:     	adrp	x10, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101540434:     	add	x10, x10, #0xe81
101540438:     	stp	x9, x10, [x8, #0x8]
10154043c:     	mov	w9, #0x23               ; =35
101540440:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540444:     	mov	x9, x0
101540448:     	mov	x0, x8
10154044c:     	mov	x2, x1
101540450:     	mov	x1, x9
101540454:     	add	sp, sp, #0x810
101540458:     	ldp	x29, x30, [sp, #0x50]
10154045c:     	ldp	x20, x19, [sp, #0x40]
101540460:     	ldp	x22, x21, [sp, #0x30]
101540464:     	ldp	x24, x23, [sp, #0x20]
101540468:     	ldp	x26, x25, [sp, #0x10]
10154046c:     	ldp	x28, x27, [sp], #0x60
101540470:     	b	0x1015339bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
101540474:     	ldr	x9, [x0, #0xc0]
101540478:     	cmp	x9, #0x2
10154047c:     	b.ne	0x1015404d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x200>
101540480:     	cmp	x22, #0x15
101540484:     	b.gt	0x1015405c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4>
101540488:     	sub	x9, x22, #0xc
10154048c:     	cmp	x9, #0x4
101540490:     	b.hs	0x101540890 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5bc>
101540494:     	lsr	x9, x1, #32
101540498:     	cbz	x9, 0x10154064c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x378>
10154049c:     	str	wzr, [x8]
1015404a0:     	mov	w9, #0xc                ; =12
1015404a4:     	strb	w9, [x8, #0x8]
1015404a8:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
1015404ac:     	add	x9, x9, #0x26f
1015404b0:     	mov	w10, #0x15              ; =21
1015404b4:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015404b8:     	str	wzr, [x8]
1015404bc:     	mov	w9, #0xc                ; =12
1015404c0:     	adrp	x10, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
1015404c4:     	add	x10, x10, #0xd8d
1015404c8:     	stp	x9, x10, [x8, #0x8]
1015404cc:     	mov	w9, #0x2d               ; =45
1015404d0:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015404d4:     	str	wzr, [x8]
1015404d8:     	mov	w9, #0xc                ; =12
1015404dc:     	strb	w9, [x8, #0x8]
1015404e0:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015404e4:     	add	x9, x9, #0x486
1015404e8:     	mov	w10, #0x35              ; =53
1015404ec:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015404f0:     	str	wzr, [x8]
1015404f4:     	mov	w9, #0xc                ; =12
1015404f8:     	strb	w9, [x8, #0x8]
1015404fc:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101540500:     	add	x9, x9, #0x114
101540504:     	mov	w10, #0x27              ; =39
101540508:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154050c:     	ldr	x21, [x0, #0x4a0]
101540510:     	ldr	x12, [x21, #0x178]
101540514:     	cmp	x11, x12
101540518:     	b.hs	0x10154058c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
10154051c:     	ldr	x12, [x21, #0x170]
101540520:     	add	x12, x12, x11, lsl #4
101540524:     	ldr	x11, [x12]
101540528:     	ldr	x13, [x21, #0x160]
10154052c:     	cmp	x11, x13
101540530:     	b.hs	0x10154058c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101540534:     	ldr	x12, [x12, #0x8]
101540538:     	ldr	x13, [x21, #0x158]
10154053c:     	mov	w14, #0x48              ; =72
101540540:     	madd	x11, x11, x14, x13
101540544:     	ldr	x13, [x11, #0x28]
101540548:     	cmp	x12, x13
10154054c:     	b.hs	0x10154058c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b8>
101540550:     	ldr	x13, [x11, #0x20]
101540554:     	mov	w14, #0x110             ; =272
101540558:     	madd	x23, x12, x14, x13
10154055c:     	mov	x24, x23
101540560:     	ldr	x13, [x24, #0x30]!
101540564:     	mov	x12, #-0x8000000000000000 ; =-9223372036854775808
101540568:     	cmp	x13, x12
10154056c:     	b.ne	0x101540b08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x834>
101540570:     	str	wzr, [x8]
101540574:     	mov	w9, #0xc                ; =12
101540578:     	adrp	x10, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
10154057c:     	add	x10, x10, #0xf19
101540580:     	stp	x9, x10, [x8, #0x8]
101540584:     	mov	w9, #0x1f               ; =31
101540588:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
10154058c:     	str	wzr, [x8]
101540590:     	mov	w9, #0xc                ; =12
101540594:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101540598:     	add	x10, x10, #0x76
10154059c:     	stp	x9, x10, [x8, #0x8]
1015405a0:     	mov	w9, #0x29               ; =41
1015405a4:     	str	x9, [x8, #0x18]
1015405a8:     	add	sp, sp, #0x810
1015405ac:     	ldp	x29, x30, [sp, #0x50]
1015405b0:     	ldp	x20, x19, [sp, #0x40]
1015405b4:     	ldp	x22, x21, [sp, #0x30]
1015405b8:     	ldp	x24, x23, [sp, #0x20]
1015405bc:     	ldp	x26, x25, [sp, #0x10]
1015405c0:     	ldp	x28, x27, [sp], #0x60
1015405c4:     	ret
1015405c8:     	sub	x9, x22, #0x17
1015405cc:     	cmp	x9, #0x4
1015405d0:     	b.hs	0x1015408c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5f4>
1015405d4:     	cmn	x2, #0x17
1015405d8:     	b.gt	0x1015406c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3f0>
1015405dc:     	cmn	x2, #0x18
1015405e0:     	b.eq	0x1015409e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x710>
1015405e4:     	cmn	x2, #0x17
1015405e8:     	b.ne	0x1015409c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f4>
1015405ec:     	ldr	x9, [x0, #0xf8]
1015405f0:     	cmp	x9, #0x2
1015405f4:     	b.ne	0x101540b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x884>
1015405f8:     	str	wzr, [x8]
1015405fc:     	mov	w9, #0xc                ; =12
101540600:     	adrp	x10, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540604:     	add	x10, x10, #0x994
101540608:     	b	0x101540b28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x854>
10154060c:     	ldp	x10, x11, [x21, #0x68]
101540610:     	sub	x23, x10, #0x18
101540614:     	lsl	x10, x11, #5
101540618:     	cbz	x10, 0x101540878 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a4>
10154061c:     	ldr	x11, [x23, #0x18]
101540620:     	add	x23, x23, #0x20
101540624:     	sub	x10, x10, #0x20
101540628:     	cmp	x11, x1
10154062c:     	b.ne	0x101540618 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344>
101540630:     	ldr	w10, [x23]
101540634:     	cmp	w10, #0x5
101540638:     	b.eq	0x101540b34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x860>
10154063c:     	cmp	w10, #0x6
101540640:     	b.ne	0x101540878 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x5a4>
101540644:     	mov	w22, #0x8               ; =8
101540648:     	b	0x101540b38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x864>
10154064c:     	ldr	x9, [x0, #0x4c0]
101540650:     	lsr	x10, x9, #59
101540654:     	cbnz	x10, 0x101541888 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15b4>
101540658:     	mov	x10, #-0x21             ; =-33
10154065c:     	movk	x10, #0x7ff, lsl #48
101540660:     	cmp	x9, x10
101540664:     	b.hi	0x101541888 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15b4>
101540668:     	mov	x25, x2
10154066c:     	mov	x21, x3
101540670:     	mov	x19, x1
101540674:     	mov	x23, x8
101540678:     	mov	x20, x0
10154067c:     	ldr	x26, [x0, #0x490]
101540680:     	lsl	x8, x9, #5
101540684:     	and	x8, x8, #0xffffffffffffffc0
101540688:     	add	x22, x8, #0x400
10154068c:     	ldr	x8, [x26, #0x310]
101540690:     	cbz	x8, 0x101540a98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7c4>
101540694:     	ldr	x2, [x26, #0x308]
101540698:     	add	x8, sp, #0x550
10154069c:     	add	x0, x26, #0x310
1015406a0:     	mov	x1, x22
1015406a4:     	bl	0x10236d190 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>
1015406a8:     	ldrb	w8, [sp, #0x550]
1015406ac:     	cmp	w8, #0x8
1015406b0:     	b.ne	0x101540ab8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7e4>
1015406b4:     	mov	x0, x20
1015406b8:     	mov	x1, x19
1015406bc:     	mov	x10, x25
1015406c0:     	b	0x1015410dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe08>
1015406c4:     	cmn	x2, #0x16
1015406c8:     	b.eq	0x101540a0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x738>
1015406cc:     	cmn	x2, #0x15
1015406d0:     	b.ne	0x1015409c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6f4>
1015406d4:     	ldr	x9, [x0, #0x4a0]
1015406d8:     	str	x9, [sp, #0x660]
1015406dc:     	ldr	x19, [x3, #0x10]
1015406e0:     	ldr	x10, [x9, #0x5a0]
1015406e4:     	cmp	x19, x10
1015406e8:     	b.hs	0x101540c84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9b0>
1015406ec:     	ldr	x9, [x9, #0x598]
1015406f0:     	mov	w10, #0x58              ; =88
1015406f4:     	madd	x22, x19, x10, x9
1015406f8:     	ldr	w9, [x22, #0x3c]
1015406fc:     	cmp	x1, x9
101540700:     	b.ne	0x101540d54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540704:     	ldr	x24, [x0, #0x490]
101540708:     	ldr	w9, [x24, #0x2f0]
10154070c:     	cmp	w9, #0x1
101540710:     	b.ne	0x101540d54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540714:     	ldr	w9, [x24, #0x2f4]
101540718:     	cmp	w9, w1
10154071c:     	b.ne	0x101540d54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540720:     	ldr	w9, [x24, #0x2e8]
101540724:     	cmp	w9, #0x1
101540728:     	b.ne	0x101540d54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
10154072c:     	ldr	w9, [x22, #0x34]
101540730:     	ldr	w10, [x24, #0x2ec]
101540734:     	cmp	w10, w9
101540738:     	b.ne	0x101540d54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
10154073c:     	ldrb	w10, [x24, #0x460]
101540740:     	cmp	w10, #0x1
101540744:     	b.ne	0x101540d54 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa80>
101540748:     	mov	x23, x8
10154074c:     	str	x0, [sp, #0x58]
101540750:     	ldr	x8, [x0, #0xf8]
101540754:     	cmp	x8, #0x2
101540758:     	b.ne	0x101541734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1460>
10154075c:     	ldr	x8, [sp, #0x58]
101540760:     	ldrb	w8, [x8, #0x510]
101540764:     	tbnz	w8, #0x0, 0x101541734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1460>
101540768:     	lsl	x0, x9, #1
10154076c:     	ldr	x8, [sp, #0x58]
101540770:     	ldr	x1, [x8, #0x4c0]
101540774:     	cmp	x0, x1
101540778:     	b.hs	0x101543874 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35a0>
10154077c:     	ldr	x8, [sp, #0x58]
101540780:     	ldr	x9, [x8, #0x4b8]
101540784:     	ldr	x28, [x9, x0, lsl #3]
101540788:     	ldr	x8, [x8, #0x3c0]
10154078c:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101540790:     	cmp	x8, x9
101540794:     	b.ne	0x10154191c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1648>
101540798:     	mov	x21, x3
10154079c:     	bl	0x102e6b284 <__RNvNtNtCsgirOGyZpP7g_3std6thread9functions21available_parallelism>
1015407a0:     	cmp	x0, #0x1
1015407a4:     	b.ne	0x1015407b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4e0>
1015407a8:     	mov	x0, x1
1015407ac:     	bl	0x10152323c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtNtB4_3num7nonzero7NonZerojENtNtNtCsgirOGyZpP7g_3std2io5error5ErrorEECs7fdMCt8k5K6_8mech_gpu>
1015407b0:     	mov	w1, #0x1                ; =1
1015407b4:     	mov	w8, #0x20               ; =32
1015407b8:     	cmp	x1, #0x20
1015407bc:     	csel	x20, x1, x8, lo
1015407c0:     	sub	x8, x28, #0x1
1015407c4:     	cmp	x8, x20
1015407c8:     	b.hs	0x101541734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1460>
1015407cc:     	ldr	x8, [x22, #0x28]
1015407d0:     	str	x8, [sp, #0x50]
1015407d4:     	cmp	x8, x20
1015407d8:     	b.hi	0x101541734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1460>
1015407dc:     	ldr	x8, [x22, #0x20]
1015407e0:     	str	x8, [sp, #0x48]
1015407e4:     	add	x8, sp, #0x550
1015407e8:     	add	x0, x24, #0x3b8
1015407ec:     	bl	0x10236ca38 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
1015407f0:     	ldr	x8, [sp, #0x550]
1015407f4:     	cmp	x8, #0x1
1015407f8:     	b.ne	0x101541734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1460>
1015407fc:     	ldr	x8, [sp, #0x558]
101540800:     	cbz	x8, 0x101541734 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1460>
101540804:     	ldr	x8, [x21]
101540808:     	str	x8, [sp, #0x40]
10154080c:     	cbz	x8, 0x101541f74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ca0>
101540810:     	ldr	x8, [x21, #0x8]
101540814:     	cbz	x8, 0x101541f74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ca0>
101540818:     	mov	x21, x8
10154081c:     	ldr	x9, [x8, #0x38]
101540820:     	ldr	x8, [sp, #0x58]
101540824:     	cmp	x9, x8
101540828:     	b.ne	0x101540860 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
10154082c:     	ldr	x8, [x21]
101540830:     	cmp	x8, #0x25
101540834:     	b.ne	0x101540860 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
101540838:     	ldr	x8, [x21, #0x10]
10154083c:     	ldr	x9, [sp, #0x660]
101540840:     	ldr	x9, [x9, #0x360]
101540844:     	cmp	x8, x9
101540848:     	b.lo	0x101540860 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
10154084c:     	ldr	x8, [x21, #0x28]
101540850:     	cbz	x8, 0x101540860 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x58c>
101540854:     	ldr	x8, [x21, #0x70]
101540858:     	cmp	x8, #0x4
10154085c:     	b.ne	0x101542e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b9c>
101540860:     	str	wzr, [x23]
101540864:     	mov	w8, #0xc                ; =12
101540868:     	strb	w8, [x23, #0x8]
10154086c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540870:     	add	x8, x8, #0x826
101540874:     	b	0x101541a94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c0>
101540878:     	str	wzr, [x8]
10154087c:     	mov	w9, #0xc                ; =12
101540880:     	strb	w9, [x8, #0x8]
101540884:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
101540888:     	add	x9, x9, #0xe23
10154088c:     	b	0x101540d30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa5c>
101540890:     	mov	x19, x2
101540894:     	mov	x23, x3
101540898:     	cmp	x22, #0x14
10154089c:     	b.ne	0x10154093c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x668>
1015408a0:     	ldr	x9, [x0, #0x490]
1015408a4:     	ldr	x10, [x0, #0x4a0]
1015408a8:     	mov	x24, x0
1015408ac:     	mov	x0, x9
1015408b0:     	mov	x20, x1
1015408b4:     	mov	x1, x10
1015408b8:     	mov	x2, x20
1015408bc:     	mov	x25, x8
1015408c0:     	bl	0x10154fcf0 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015408c4:     	b	0x1015408fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x628>
1015408c8:     	mov	x19, x2
1015408cc:     	mov	x23, x3
1015408d0:     	cmp	x22, #0x16
1015408d4:     	b.ne	0x10154093c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x668>
1015408d8:     	ldr	x9, [x0, #0x490]
1015408dc:     	ldr	x10, [x0, #0x4a0]
1015408e0:     	mov	x24, x0
1015408e4:     	mov	x0, x9
1015408e8:     	mov	x20, x1
1015408ec:     	mov	x1, x10
1015408f0:     	mov	x2, x20
1015408f4:     	mov	x25, x8
1015408f8:     	bl	0x10153c178 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
1015408fc:     	mov	x1, x20
101540900:     	mov	x8, x25
101540904:     	mov	x9, x0
101540908:     	mov	x0, x24
10154090c:     	tbz	w9, #0x0, 0x10154093c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x668>
101540910:     	mov	x20, x8
101540914:     	add	x8, sp, #0x550
101540918:     	mov	x24, x0
10154091c:     	mov	x25, x1
101540920:     	bl	0x10153f4b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>
101540924:     	ldr	w8, [sp, #0x550]
101540928:     	cmp	w8, #0x6
10154092c:     	b.ne	0x101540ae4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x810>
101540930:     	mov	x8, x20
101540934:     	mov	x0, x24
101540938:     	mov	x1, x25
10154093c:     	ldr	x9, [x0, #0x490]
101540940:     	ldr	w10, [x9, #0x2f0]
101540944:     	tbz	w10, #0x0, 0x1015409ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6d8>
101540948:     	ldr	w10, [x9, #0x2f4]
10154094c:     	cmp	x1, x10
101540950:     	b.ne	0x1015409ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x6d8>
101540954:     	mov	x3, x23
101540958:     	ldr	x23, [x0, #0x4a0]
10154095c:     	mov	x20, x1
101540960:     	mov	x25, x0
101540964:     	cmp	x22, #0x1a
101540968:     	b.gt	0x101540f44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc70>
10154096c:     	sub	x10, x22, #0x13
101540970:     	cmp	x10, #0x4
101540974:     	b.hs	0x101541220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf4c>
101540978:     	mov	x0, x8
10154097c:     	mov	x1, x25
101540980:     	mov	x2, x20
101540984:     	mov	x4, x3
101540988:     	mov	x3, x19
10154098c:     	add	sp, sp, #0x810
101540990:     	ldp	x29, x30, [sp, #0x50]
101540994:     	ldp	x20, x19, [sp, #0x40]
101540998:     	ldp	x22, x21, [sp, #0x30]
10154099c:     	ldp	x24, x23, [sp, #0x20]
1015409a0:     	ldp	x26, x25, [sp, #0x10]
1015409a4:     	ldp	x28, x27, [sp], #0x60
1015409a8:     	b	0x10154e288 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation19retained_map_helper>
1015409ac:     	str	wzr, [x8]
1015409b0:     	mov	w9, #0xc                ; =12
1015409b4:     	strb	w9, [x8, #0x8]
1015409b8:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015409bc:     	add	x9, x9, #0x623
1015409c0:     	mov	w10, #0x23              ; =35
1015409c4:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015409c8:     	str	wzr, [x8]
1015409cc:     	mov	w9, #0xc                ; =12
1015409d0:     	strb	w9, [x8, #0x8]
1015409d4:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015409d8:     	add	x9, x9, #0xa5e
1015409dc:     	mov	w10, #0x20              ; =32
1015409e0:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015409e4:     	ldr	x9, [x0, #0xf8]
1015409e8:     	cmp	x9, #0x2
1015409ec:     	b.ne	0x101540ca0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x9cc>
1015409f0:     	str	wzr, [x8]
1015409f4:     	mov	w9, #0xc                ; =12
1015409f8:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015409fc:     	add	x10, x10, #0xff3
101540a00:     	stp	x9, x10, [x8, #0x8]
101540a04:     	mov	w9, #0x26               ; =38
101540a08:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540a0c:     	ldr	x9, [x3]
101540a10:     	ldr	x23, [x0, #0x4a0]
101540a14:     	ldr	x10, [x23, #0x5a0]
101540a18:     	cmp	x9, x10
101540a1c:     	b.hs	0x101540d38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa64>
101540a20:     	ldp	x11, x10, [x3, #0x8]
101540a24:     	orr	x10, x11, x10
101540a28:     	cbnz	x10, 0x101540d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540a2c:     	ldr	x10, [x23, #0x598]
101540a30:     	mov	w11, #0x58              ; =88
101540a34:     	madd	x19, x9, x11, x10
101540a38:     	ldr	w10, [x19, #0x44]
101540a3c:     	cmp	x1, x10
101540a40:     	b.ne	0x101540d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540a44:     	ldr	x10, [x0, #0x490]
101540a48:     	ldr	w11, [x10, #0x2f0]
101540a4c:     	cmp	w11, #0x1
101540a50:     	b.ne	0x101540d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540a54:     	ldr	w11, [x10, #0x2f4]
101540a58:     	cmp	w11, w1
101540a5c:     	b.ne	0x101540d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540a60:     	ldrb	w11, [x10, #0x460]
101540a64:     	cmp	w11, #0x1
101540a68:     	b.ne	0x101540d70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa9c>
101540a6c:     	mov	x21, x8
101540a70:     	ldr	x8, [x0, #0x3c0]
101540a74:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
101540a78:     	cmp	x8, x11
101540a7c:     	b.ne	0x101541664 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1390>
101540a80:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
101540a84:     	ldr	q0, [x8, #0xc00]
101540a88:     	stur	q0, [x21, #0x8]
101540a8c:     	mov	w8, #0x6                ; =6
101540a90:     	str	w8, [x21]
101540a94:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540a98:     	bl	0x10236c9ac <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget16has_active_scope>
101540a9c:     	tbz	w0, #0x0, 0x101540d8c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xab8>
101540aa0:     	mov	w11, #0x0               ; =0
101540aa4:     	mov	w10, #0x0               ; =0
101540aa8:     	mov	x8, #0x0                ; =0
101540aac:     	mov	w13, #0x7               ; =7
101540ab0:     	mov	x12, x23
101540ab4:     	b	0x101540f08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101540ab8:     	ldr	x8, [sp, #0x550]
101540abc:     	ldr	x14, [sp, #0x558]
101540ac0:     	ldr	x9, [sp, #0x560]
101540ac4:     	and	x10, x8, #0xffff
101540ac8:     	cmp	x10, #0x606
101540acc:     	mov	x12, x23
101540ad0:     	b.ne	0x101540ef0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc1c>
101540ad4:     	mov	w10, #0x0               ; =0
101540ad8:     	mov	w13, #0x6               ; =6
101540adc:     	mov	x8, x14
101540ae0:     	b	0x101540f08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101540ae4:     	ldr	q0, [sp, #0x570]
101540ae8:     	ldr	q1, [sp, #0x580]
101540aec:     	stp	q0, q1, [x20, #0x20]
101540af0:     	ldr	q0, [sp, #0x590]
101540af4:     	str	q0, [x20, #0x40]
101540af8:     	ldr	q0, [sp, #0x560]
101540afc:     	ldr	q1, [sp, #0x550]
101540b00:     	stp	q1, q0, [x20]
101540b04:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540b08:     	mov	x14, x23
101540b0c:     	ldr	x13, [x14, #0xb0]!
101540b10:     	cmp	x13, x12
101540b14:     	b.ne	0x101540f88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xcb4>
101540b18:     	str	wzr, [x8]
101540b1c:     	mov	w9, #0xc                ; =12
101540b20:     	adrp	x10, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101540b24:     	add	x10, x10, #0xf38
101540b28:     	stp	x9, x10, [x8, #0x8]
101540b2c:     	mov	w9, #0x21               ; =33
101540b30:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540b34:     	mov	w22, #0x10              ; =16
101540b38:     	ldr	x10, [x3, #0x10]
101540b3c:     	cbz	x10, 0x101540db8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xae4>
101540b40:     	str	wzr, [x8]
101540b44:     	mov	w9, #0xc                ; =12
101540b48:     	strb	w9, [x8, #0x8]
101540b4c:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
101540b50:     	add	x9, x9, #0xdf5
101540b54:     	b	0x101540d30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa5c>
101540b58:     	ldr	x24, [x0, #0x4a0]
101540b5c:     	ldr	x11, [x24, #0x5a0]
101540b60:     	ldr	x10, [x0, #0x1c0]
101540b64:     	cmp	x10, x11
101540b68:     	b.hs	0x101541094 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdc0>
101540b6c:     	ldr	x22, [x0, #0x490]
101540b70:     	ldr	w11, [x22, #0x2f0]
101540b74:     	cmp	w11, #0x1
101540b78:     	b.ne	0x101541288 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfb4>
101540b7c:     	ldr	x11, [x3, #0x8]
101540b80:     	cmp	x11, x10
101540b84:     	b.ne	0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540b88:     	ldr	x11, [x3, #0x10]
101540b8c:     	cbnz	x11, 0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540b90:     	cbnz	x9, 0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540b94:     	ldr	x9, [x24, #0x598]
101540b98:     	mov	w11, #0x58              ; =88
101540b9c:     	madd	x21, x10, x11, x9
101540ba0:     	ldr	w26, [x21, #0x48]
101540ba4:     	cmp	x1, x26
101540ba8:     	b.ne	0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540bac:     	ldr	w9, [x22, #0x2e8]
101540bb0:     	tbz	w9, #0x0, 0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540bb4:     	ldr	w9, [x21, #0x34]
101540bb8:     	ldr	w10, [x22, #0x2ec]
101540bbc:     	cmp	w10, w9
101540bc0:     	b.ne	0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540bc4:     	ldr	w19, [x22, #0x2f4]
101540bc8:     	mov	x20, x0
101540bcc:     	mov	x0, x21
101540bd0:     	mov	x1, x19
101540bd4:     	mov	x23, x8
101540bd8:     	mov	x25, x3
101540bdc:     	bl	0x1015182c4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare8parallelNtB2_6Region8contains>
101540be0:     	mov	x8, x23
101540be4:     	cbz	w0, 0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540be8:     	ldr	x1, [x24, #0x380]
101540bec:     	cmp	x1, x19
101540bf0:     	b.ls	0x101543880 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35ac>
101540bf4:     	ldr	x8, [x24, #0x378]
101540bf8:     	mov	w9, #0x170              ; =368
101540bfc:     	umaddl	x8, w19, w9, x8
101540c00:     	add	x9, x8, #0x15c
101540c04:     	ldr	w8, [x8, #0x16c]
101540c08:     	str	w8, [sp, #0x560]
101540c0c:     	ldr	q0, [x9]
101540c10:     	str	q0, [sp, #0x550]
101540c14:     	add	x8, sp, #0x440
101540c18:     	add	x0, sp, #0x550
101540c1c:     	bl	0x102a3387c <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
101540c20:     	ldr	w8, [sp, #0x440]
101540c24:     	cmp	w8, #0x1
101540c28:     	b.ne	0x101540c38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x964>
101540c2c:     	ldr	w8, [sp, #0x444]
101540c30:     	cmp	w8, w26
101540c34:     	b.eq	0x101540c50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x97c>
101540c38:     	ldr	w8, [sp, #0x448]
101540c3c:     	cmp	w8, #0x1
101540c40:     	b.ne	0x101541ad4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1800>
101540c44:     	ldr	w8, [sp, #0x44c]
101540c48:     	cmp	w8, w26
101540c4c:     	b.ne	0x101541ad4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1800>
101540c50:     	mov	x0, x20
101540c54:     	mov	x1, x19
101540c58:     	bl	0x10153ef2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
101540c5c:     	cbz	w0, 0x101541a30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x175c>
101540c60:     	ldrb	w8, [x22, #0x460]
101540c64:     	cmp	w8, #0x1
101540c68:     	mov	x8, x23
101540c6c:     	b.ne	0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540c70:     	mov	x9, x20
101540c74:     	ldr	x10, [x20, #0xc0]
101540c78:     	cmp	x10, #0x2
101540c7c:     	b.eq	0x101541a44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1770>
101540c80:     	b	0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101540c84:     	str	wzr, [x8]
101540c88:     	mov	w9, #0xc                ; =12
101540c8c:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101540c90:     	add	x10, x10, #0xd7c
101540c94:     	stp	x9, x10, [x8, #0x8]
101540c98:     	mov	w9, #0x22               ; =34
101540c9c:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540ca0:     	ldr	x11, [x0, #0x4a0]
101540ca4:     	ldr	x12, [x11, #0x5a0]
101540ca8:     	ldr	x10, [x0, #0x1c0]
101540cac:     	cmp	x10, x12
101540cb0:     	b.hs	0x1015410b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xddc>
101540cb4:     	ldr	x11, [x11, #0x598]
101540cb8:     	mov	w12, #0x58              ; =88
101540cbc:     	madd	x11, x10, x12, x11
101540cc0:     	ldr	w11, [x11, #0x38]
101540cc4:     	cmp	x1, x11
101540cc8:     	b.ne	0x101540d1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540ccc:     	add	x11, x0, #0x1c8
101540cd0:     	ldr	q0, [x11]
101540cd4:     	stur	q0, [x27, #0x8]
101540cd8:     	ldp	x11, x12, [x3]
101540cdc:     	ldr	x13, [x3, #0x10]
101540ce0:     	ldr	x14, [sp, #0x558]
101540ce4:     	ldr	x15, [sp, #0x560]
101540ce8:     	cmp	x11, x10
101540cec:     	ccmp	x12, x14, #0x0, eq
101540cf0:     	ccmp	x13, x15, #0x0, eq
101540cf4:     	cset	w10, ne
101540cf8:     	cbnz	x9, 0x101540d1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540cfc:     	cbnz	w10, 0x101540d1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540d00:     	ldr	x9, [x0, #0x490]
101540d04:     	ldr	w10, [x9, #0x2f0]
101540d08:     	cbnz	w10, 0x101540d1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540d0c:     	ldr	w10, [x9, #0x2e8]
101540d10:     	cbnz	w10, 0x101540d1c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa48>
101540d14:     	ldrb	w10, [x9, #0x338]
101540d18:     	tbz	w10, #0x0, 0x1015417d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1504>
101540d1c:     	str	wzr, [x8]
101540d20:     	mov	w9, #0xc                ; =12
101540d24:     	strb	w9, [x8, #0x8]
101540d28:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540d2c:     	add	x9, x9, #0xa30
101540d30:     	mov	w10, #0x2e              ; =46
101540d34:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540d38:     	str	wzr, [x8]
101540d3c:     	mov	w9, #0xc                ; =12
101540d40:     	adrp	x10, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540d44:     	add	x10, x10, #0x884
101540d48:     	stp	x9, x10, [x8, #0x8]
101540d4c:     	mov	w9, #0x14               ; =20
101540d50:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540d54:     	str	wzr, [x8]
101540d58:     	mov	w9, #0xc                ; =12
101540d5c:     	strb	w9, [x8, #0x8]
101540d60:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540d64:     	add	x9, x9, #0x84e
101540d68:     	mov	w10, #0x36              ; =54
101540d6c:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540d70:     	str	wzr, [x8]
101540d74:     	mov	w9, #0xc                ; =12
101540d78:     	strb	w9, [x8, #0x8]
101540d7c:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540d80:     	add	x9, x9, #0x96e
101540d84:     	mov	w10, #0x26              ; =38
101540d88:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101540d8c:     	ldr	x8, [x26, #0x300]
101540d90:     	ldr	x9, [x26, #0x308]
101540d94:     	adds	x8, x8, x22
101540d98:     	b.hs	0x101541d48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a74>
101540d9c:     	cmp	x8, x9
101540da0:     	b.ls	0x1015410cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xdf8>
101540da4:     	mov	x12, x23
101540da8:     	mov	w11, #0x0               ; =0
101540dac:     	mov	w10, #0x0               ; =0
101540db0:     	mov	w13, #0x6               ; =6
101540db4:     	b	0x101540f08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101540db8:     	ldr	x10, [x0, #0x490]
101540dbc:     	ldr	x10, [x10, #0x3c0]
101540dc0:     	cbz	x10, 0x101540f28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540dc4:     	ldr	x11, [x10, #0x40]
101540dc8:     	cmp	x11, #0x2
101540dcc:     	b.eq	0x101540f28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540dd0:     	ldr	x11, [x10, #0xd8]
101540dd4:     	cmp	x11, x9
101540dd8:     	b.ne	0x101540f28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540ddc:     	ldr	x11, [x23, x22]
101540de0:     	ldr	x12, [x10, #0x78]
101540de4:     	cmp	x11, x12
101540de8:     	b.hs	0x101540f28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc54>
101540dec:     	ldr	x10, [x10, #0x70]
101540df0:     	mov	w12, #0x108             ; =264
101540df4:     	mul	x11, x11, x12
101540df8:     	ldr	x10, [x10, x11]
101540dfc:     	cbnz	x10, 0x101540b40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x86c>
101540e00:     	add	x24, sp, #0x440
101540e04:     	stp	x9, x1, [sp, #0x48]
101540e08:     	mov	x28, x8
101540e0c:     	ldr	x8, [x0, #0x4d8]
101540e10:     	cbz	x8, 0x1015415cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12f8>
101540e14:     	ldr	x10, [x21, #0xb8]
101540e18:     	add	x9, x10, #0x2
101540e1c:     	ldr	x11, [x0, #0x4e0]
101540e20:     	cmp	x9, x11
101540e24:     	b.hs	0x1015415cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12f8>
101540e28:     	str	x0, [sp, #0x58]
101540e2c:     	add	x10, x10, #0x3
101540e30:     	cmp	x10, x11
101540e34:     	b.hs	0x1015415cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12f8>
101540e38:     	ldr	x9, [x8, x9, lsl #3]
101540e3c:     	ldr	x8, [x8, x10, lsl #3]
101540e40:     	stp	x9, x8, [sp, #0x38]
101540e44:     	ldr	q0, [x3]
101540e48:     	str	q0, [sp, #0x440]
101540e4c:     	mov	w8, #0x5                ; =5
101540e50:     	str	x8, [sp, #0x450]
101540e54:     	add	x0, sp, #0x550
101540e58:     	add	x3, sp, #0x440
101540e5c:     	ldp	x2, x1, [sp, #0x50]
101540e60:     	bl	0x1015339bc <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation15end_closed_tail>
101540e64:     	ldr	w8, [sp, #0x550]
101540e68:     	cmp	w8, #0x6
101540e6c:     	b.ne	0x1015419fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1728>
101540e70:     	ldr	x1, [x19, #0x380]
101540e74:     	ldr	x8, [sp, #0x50]
101540e78:     	cmp	x8, x1
101540e7c:     	b.hs	0x1015438d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3604>
101540e80:     	ldr	x9, [x19, #0x378]
101540e84:     	mov	w10, #0x170             ; =368
101540e88:     	ldr	x8, [sp, #0x50]
101540e8c:     	madd	x8, x8, x10, x9
101540e90:     	ldp	x8, x9, [x8]
101540e94:     	cmp	x8, #0x2
101540e98:     	sbcs	xzr, x9, xzr
101540e9c:     	b.hs	0x101541b50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x187c>
101540ea0:     	ldr	x1, [x19, #0x408]
101540ea4:     	ldr	x8, [sp, #0x50]
101540ea8:     	cmp	x8, x1
101540eac:     	b.hs	0x1015438e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3614>
101540eb0:     	ldr	x9, [x19, #0x400]
101540eb4:     	ldr	x8, [sp, #0x50]
101540eb8:     	add	x9, x9, x8, lsl #9
101540ebc:     	str	x9, [sp, #0x30]
101540ec0:     	ldp	x9, x8, [x9]
101540ec4:     	eor	x9, x9, #0x2
101540ec8:     	orr	x8, x9, x8
101540ecc:     	cbnz	x8, 0x101541b90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x18bc>
101540ed0:     	str	wzr, [x28]
101540ed4:     	mov	w8, #0xc                ; =12
101540ed8:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101540edc:     	add	x9, x9, #0xdba
101540ee0:     	stp	x8, x9, [x28, #0x8]
101540ee4:     	mov	w8, #0x23               ; =35
101540ee8:     	str	x8, [x28, #0x18]
101540eec:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540ef0:     	mov	x10, x9
101540ef4:     	lsr	x11, x9, #32
101540ef8:     	ldur	q0, [x27, #0x18]
101540efc:     	stur	q0, [x29, #-0x70]
101540f00:     	mov	w13, #0x7               ; =7
101540f04:     	mov	x9, x14
101540f08:     	str	wzr, [x12]
101540f0c:     	strb	w13, [x12, #0x8]
101540f10:     	stp	x8, x9, [x12, #0x10]
101540f14:     	stp	w10, w11, [x12, #0x20]
101540f18:     	ldur	q0, [x29, #-0x70]
101540f1c:     	stur	q0, [x12, #0x28]
101540f20:     	str	wzr, [x12, #0x38]
101540f24:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101540f28:     	str	wzr, [x8]
101540f2c:     	mov	w9, #0xc                ; =12
101540f30:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
101540f34:     	add	x10, x10, #0x5f0
101540f38:     	stp	x9, x10, [x8, #0x8]
101540f3c:     	mov	w9, #0x2b               ; =43
101540f40:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101540f44:     	sub	x10, x22, #0x1b
101540f48:     	cmp	x10, #0x2
101540f4c:     	b.hs	0x101541254 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf80>
101540f50:     	ldp	x5, x6, [x3, #0x8]
101540f54:     	ldr	x4, [x3]
101540f58:     	mov	x0, x8
101540f5c:     	mov	x1, x25
101540f60:     	mov	x2, x20
101540f64:     	mov	x3, x19
101540f68:     	add	sp, sp, #0x810
101540f6c:     	ldp	x29, x30, [sp, #0x50]
101540f70:     	ldp	x20, x19, [sp, #0x40]
101540f74:     	ldp	x22, x21, [sp, #0x30]
101540f78:     	ldp	x24, x23, [sp, #0x20]
101540f7c:     	ldp	x26, x25, [sp, #0x10]
101540f80:     	ldp	x28, x27, [sp], #0x60
101540f84:     	b	0x10153e720 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation17frozen_map_helper>
101540f88:     	cbnz	x10, 0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101540f8c:     	ldr	x12, [x0, #0x490]
101540f90:     	ldr	w10, [x12, #0x2f0]
101540f94:     	cmp	w10, #0x1
101540f98:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101540f9c:     	ldr	w10, [x12, #0x2f4]
101540fa0:     	cmp	w10, w9
101540fa4:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101540fa8:     	ldr	w9, [x12, #0x2e8]
101540fac:     	cmp	w9, #0x1
101540fb0:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101540fb4:     	ldr	w9, [x11, #0x30]
101540fb8:     	ldr	w10, [x12, #0x2ec]
101540fbc:     	cmp	w10, w9
101540fc0:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101540fc4:     	stp	x14, x12, [sp, #0x38]
101540fc8:     	stp	x8, x1, [sp, #0x48]
101540fcc:     	mov	w8, #0x1                ; =1
101540fd0:     	orr	x8, x8, x9, lsl #1
101540fd4:     	str	x0, [sp, #0x58]
101540fd8:     	ldr	x1, [x0, #0x4c0]
101540fdc:     	cmp	x8, x1
101540fe0:     	b.hs	0x101543854 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3580>
101540fe4:     	ldr	x9, [sp, #0x58]
101540fe8:     	ldr	x9, [x9, #0x4b8]
101540fec:     	ldr	x8, [x9, x8, lsl #3]
101540ff0:     	cmp	x8, #0x1
101540ff4:     	ldp	x9, x8, [sp, #0x40]
101540ff8:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101540ffc:     	add	x0, x9, #0x3b8
101541000:     	bl	0x10236d5b4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101541004:     	ldp	x9, x8, [sp, #0x40]
101541008:     	cmp	x0, x26
10154100c:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541010:     	cmp	x1, x19
101541014:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541018:     	add	x8, sp, #0x550
10154101c:     	add	x0, x9, #0x3b8
101541020:     	bl	0x10236ca38 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101541024:     	ldr	x8, [sp, #0x48]
101541028:     	ldr	x9, [sp, #0x550]
10154102c:     	cmp	x9, #0x1
101541030:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541034:     	ldr	x9, [sp, #0x558]
101541038:     	cmp	x9, x22
10154103c:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
101541040:     	ldr	x9, [sp, #0x560]
101541044:     	cmp	x9, x25
101541048:     	b.ne	0x101541078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xda4>
10154104c:     	cbz	x20, 0x101541d9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ac8>
101541050:     	cmp	x20, #0x2
101541054:     	b.eq	0x101541d60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a8c>
101541058:     	cmp	x20, #0x3
10154105c:     	b.ne	0x101541d7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aa8>
101541060:     	cbnz	x28, 0x101541d7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aa8>
101541064:     	ldp	x1, x2, [x23, #0x8]
101541068:     	ldr	x0, [sp, #0x50]
10154106c:     	bl	0x101557618 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
101541070:     	tbnz	w0, #0x0, 0x101541d74 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aa0>
101541074:     	b	0x101541d7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aa8>
101541078:     	str	wzr, [x8]
10154107c:     	mov	w9, #0xc                ; =12
101541080:     	strb	w9, [x8, #0x8]
101541084:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101541088:     	add	x9, x9, #0xd6
10154108c:     	mov	w10, #0x3e              ; =62
101541090:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541094:     	str	wzr, [x8]
101541098:     	mov	w9, #0xc                ; =12
10154109c:     	adrp	x10, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015410a0:     	add	x10, x10, #0x9b5
1015410a4:     	stp	x9, x10, [x8, #0x8]
1015410a8:     	mov	w9, #0x13               ; =19
1015410ac:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015410b0:     	str	wzr, [x8]
1015410b4:     	mov	w9, #0xc                ; =12
1015410b8:     	adrp	x10, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
1015410bc:     	add	x10, x10, #0x19
1015410c0:     	stp	x9, x10, [x8, #0x8]
1015410c4:     	mov	w9, #0x19               ; =25
1015410c8:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015410cc:     	mov	x0, x20
1015410d0:     	mov	x1, x19
1015410d4:     	mov	x10, x25
1015410d8:     	str	x8, [x26, #0x300]
1015410dc:     	add	x8, sp, #0x550
1015410e0:     	cmn	x10, #0xd
1015410e4:     	b.ne	0x101541104 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe30>
1015410e8:     	bl	0x101546a04 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation17check_prefix_exit>
1015410ec:     	ldr	w8, [sp, #0x550]
1015410f0:     	cmp	w8, #0x6
1015410f4:     	b.ne	0x101541138 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe64>
1015410f8:     	mov	x8, x23
1015410fc:     	mov	x9, x25
101541100:     	b	0x10154115c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe88>
101541104:     	bl	0x101546b68 <__RNvMs1_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB7_10Invocation19check_prefix_header>
101541108:     	ldr	w8, [sp, #0x550]
10154110c:     	cmp	w8, #0x6
101541110:     	b.ne	0x101541138 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe64>
101541114:     	mov	x9, x25
101541118:     	cmn	x25, #0xa
10154111c:     	mov	x8, x23
101541120:     	b.ne	0x10154115c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xe88>
101541124:     	mov	x1, x20
101541128:     	ldr	x10, [x20, #0xa8]
10154112c:     	mov	x3, x21
101541130:     	cbnz	x10, 0x101541204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf30>
101541134:     	b	0x101541180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xeac>
101541138:     	ldr	q0, [sp, #0x570]
10154113c:     	ldr	q1, [sp, #0x580]
101541140:     	stp	q0, q1, [x23, #0x20]
101541144:     	ldr	q0, [sp, #0x590]
101541148:     	str	q0, [x23, #0x40]
10154114c:     	ldr	q0, [sp, #0x560]
101541150:     	ldr	q1, [sp, #0x550]
101541154:     	stp	q1, q0, [x23]
101541158:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154115c:     	mov	x3, x21
101541160:     	ldp	x10, x11, [x21]
101541164:     	ldr	x12, [x21, #0x10]
101541168:     	orr	x10, x10, x11
10154116c:     	mov	x1, x20
101541170:     	ldr	x11, [x20, #0xa8]
101541174:     	orr	x11, x12, x11
101541178:     	orr	x10, x10, x11
10154117c:     	cbnz	x10, 0x101541204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf30>
101541180:     	ldr	x10, [x1, #0x290]
101541184:     	cmp	x10, #0x6
101541188:     	b.ne	0x101541204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf30>
10154118c:     	ldr	x10, [x1, #0x4a0]
101541190:     	ldr	x11, [x10]
101541194:     	cmp	x11, #0x2
101541198:     	b.eq	0x10154204c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d78>
10154119c:     	add	x25, x1, #0x238
1015411a0:     	ldr	x11, [x25]
1015411a4:     	cmp	x11, #0x3
1015411a8:     	b.eq	0x101542058 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d84>
1015411ac:     	ldr	x22, [x10, #0x138]
1015411b0:     	ldr	w11, [x1, #0x280]
1015411b4:     	cmn	x9, #0xc
1015411b8:     	b.gt	0x101541340 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x106c>
1015411bc:     	cmn	x9, #0xd
1015411c0:     	b.eq	0x101541468 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1194>
1015411c4:     	cmn	x9, #0xc
1015411c8:     	b.ne	0x10154144c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1178>
1015411cc:     	mov	x9, x19
1015411d0:     	cmp	w11, w9
1015411d4:     	b.ne	0x1015411e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf14>
1015411d8:     	ldrb	w11, [x1, #0x288]
1015411dc:     	tbz	w11, #0x0, 0x1015411e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xf14>
1015411e0:     	ldrb	w11, [x1, #0x289]
1015411e4:     	tbz	w11, #0x0, 0x10154160c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1338>
1015411e8:     	str	wzr, [x8]
1015411ec:     	mov	w9, #0xc                ; =12
1015411f0:     	strb	w9, [x8, #0x8]
1015411f4:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015411f8:     	add	x9, x9, #0xd3a
1015411fc:     	mov	w10, #0x29              ; =41
101541200:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541204:     	str	wzr, [x8]
101541208:     	mov	w9, #0xc                ; =12
10154120c:     	strb	w9, [x8, #0x8]
101541210:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541214:     	add	x9, x9, #0xd7f
101541218:     	mov	w10, #0x24              ; =36
10154121c:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541220:     	cmp	x22, #0xa
101541224:     	b.ne	0x1015412a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd0>
101541228:     	mov	x0, x8
10154122c:     	mov	x1, x25
101541230:     	mov	x2, x20
101541234:     	add	sp, sp, #0x810
101541238:     	ldp	x29, x30, [sp, #0x50]
10154123c:     	ldp	x20, x19, [sp, #0x40]
101541240:     	ldp	x22, x21, [sp, #0x30]
101541244:     	ldp	x24, x23, [sp, #0x20]
101541248:     	ldp	x26, x25, [sp, #0x10]
10154124c:     	ldp	x28, x27, [sp], #0x60
101541250:     	b	0x101534000 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation17begin_closed_tail>
101541254:     	cmp	x22, #0x1e
101541258:     	b.ne	0x1015412a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xfd0>
10154125c:     	mov	x0, x8
101541260:     	mov	x1, x25
101541264:     	mov	x2, x20
101541268:     	add	sp, sp, #0x810
10154126c:     	ldp	x29, x30, [sp, #0x50]
101541270:     	ldp	x20, x19, [sp, #0x40]
101541274:     	ldp	x22, x21, [sp, #0x30]
101541278:     	ldp	x24, x23, [sp, #0x20]
10154127c:     	ldp	x26, x25, [sp, #0x10]
101541280:     	ldp	x28, x27, [sp], #0x60
101541284:     	b	0x101530d78 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB4_10Invocation21begin_numeric_segment>
101541288:     	str	wzr, [x8]
10154128c:     	mov	w9, #0xc                ; =12
101541290:     	strb	w9, [x8, #0x8]
101541294:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541298:     	add	x9, x9, #0x9c8
10154129c:     	mov	w10, #0x18              ; =24
1015412a0:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
1015412a4:     	mov	x24, x3
1015412a8:     	mov	x19, x8
1015412ac:     	mov	x0, x9
1015412b0:     	mov	x1, x23
1015412b4:     	mov	x2, x20
1015412b8:     	bl	0x10153e974 <__RNvMNtNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner6frozen16frozen_map_callsNtNtBa_10invocation10Invocation20frozen_native_action>
1015412bc:     	tbnz	w0, #0x0, 0x101541320 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
1015412c0:     	mov	x8, x25
1015412c4:     	ldr	x25, [x25, #0x490]
1015412c8:     	str	x8, [sp, #0x58]
1015412cc:     	ldr	x26, [x8, #0x4a0]
1015412d0:     	mov	x0, x25
1015412d4:     	mov	x1, x26
1015412d8:     	mov	x2, x20
1015412dc:     	bl	0x10154fdc0 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
1015412e0:     	tbnz	w0, #0x0, 0x101541320 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
1015412e4:     	mov	x0, x25
1015412e8:     	mov	x1, x26
1015412ec:     	mov	x2, x20
1015412f0:     	bl	0x10154fcf0 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_call>
1015412f4:     	tbnz	w0, #0x0, 0x101541320 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
1015412f8:     	mov	x0, x25
1015412fc:     	mov	x1, x26
101541300:     	mov	x2, x20
101541304:     	bl	0x10154fd58 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation20retained_native_exit>
101541308:     	tbnz	w0, #0x0, 0x101541320 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x104c>
10154130c:     	mov	x0, x25
101541310:     	mov	x1, x26
101541314:     	mov	x2, x20
101541318:     	bl	0x10153c178 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtB8_10invocation10Invocation20retained_native_span>
10154131c:     	tbz	w0, #0x0, 0x101541848 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1574>
101541320:     	str	wzr, [x19]
101541324:     	mov	w8, #0xc                ; =12
101541328:     	strb	w8, [x19, #0x8]
10154132c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541330:     	add	x8, x8, #0x5f8
101541334:     	mov	w9, #0x2b               ; =43
101541338:     	stp	x8, x9, [x19, #0x10]
10154133c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541340:     	cmn	x9, #0xb
101541344:     	b.eq	0x101541510 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x123c>
101541348:     	cmn	x9, #0xa
10154134c:     	b.ne	0x10154144c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1178>
101541350:     	ldrb	w21, [x1, #0x284]
101541354:     	ldr	x2, [x1, #0x278]
101541358:     	mov	x8, x1
10154135c:     	add	x0, sp, #0x550
101541360:     	mov	x1, x3
101541364:     	add	x3, x8, #0x250
101541368:     	bl	0x10154b0a8 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6prefixNtB4_9Retention7checked>
10154136c:     	ldr	w8, [sp, #0x550]
101541370:     	cmp	w8, #0x6
101541374:     	b.ne	0x101541594 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12c0>
101541378:     	ldr	x8, [sp, #0x568]
10154137c:     	ldur	q0, [x27, #0x8]
101541380:     	str	q0, [sp, #0x220]
101541384:     	str	x8, [sp, #0x230]
101541388:     	tbnz	w21, #0x0, 0x1015415ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1318>
10154138c:     	mov	x8, x20
101541390:     	ldr	x9, [x20, #0xc0]
101541394:     	cmp	x9, #0x2
101541398:     	b.ne	0x1015415ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1318>
10154139c:     	ldr	x9, [x8, #0x220]
1015413a0:     	cmp	x9, #0x2
1015413a4:     	b.eq	0x1015415ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1318>
1015413a8:     	ldr	x9, [x8, #0x1d8]
1015413ac:     	cmp	x9, x22
1015413b0:     	b.ne	0x1015415ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1318>
1015413b4:     	ldr	x21, [x8, #0x4e0]
1015413b8:     	mov	x8, #-0x41              ; =-65
1015413bc:     	movk	x8, #0xfff, lsl #48
1015413c0:     	cmp	x21, x8
1015413c4:     	b.hi	0x101542a84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27b0>
1015413c8:     	ldr	x8, [x20, #0x490]
1015413cc:     	lsl	x9, x21, #4
1015413d0:     	add	x0, sp, #0x550
1015413d4:     	add	x1, x8, #0x2f8
1015413d8:     	add	x2, x9, #0x400
1015413dc:     	bl	0x101529328 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015413e0:     	ldrb	w8, [sp, #0x550]
1015413e4:     	cmp	w8, #0xe
1015413e8:     	b.ne	0x101541780 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015413ec:     	cbz	x21, 0x101541400 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x112c>
1015413f0:     	ldr	x0, [x20, #0x4d8]
1015413f4:     	cbz	x0, 0x101541ab8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17e4>
1015413f8:     	lsl	x1, x21, #3
1015413fc:     	bl	0x103a03498 <dyld_stub_binder+0x103a03498>
101541400:     	add	x0, x20, #0x1d8
101541404:     	bl	0x101526afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
101541408:     	mov	w8, #0x2                ; =2
10154140c:     	str	x8, [x20, #0x220]
101541410:     	ldr	x8, [x20, #0x238]
101541414:     	cmp	x8, #0x3
101541418:     	b.eq	0x101543280 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fac>
10154141c:     	ldr	q0, [sp, #0x220]
101541420:     	str	q0, [x25]
101541424:     	ldr	x8, [sp, #0x230]
101541428:     	str	x8, [x25, #0x10]
10154142c:     	ldr	x8, [x25]
101541430:     	cmp	x8, #0x3
101541434:     	b.eq	0x10154328c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fb8>
101541438:     	mov	w8, #0x1                ; =1
10154143c:     	str	w8, [x20, #0x268]
101541440:     	str	w19, [x20, #0x26c]
101541444:     	str	xzr, [x23, #0x8]
101541448:     	b	0x101541740 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x146c>
10154144c:     	str	wzr, [x8]
101541450:     	mov	w9, #0xc                ; =12
101541454:     	strb	w9, [x8, #0x8]
101541458:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10154145c:     	add	x9, x9, #0xd63
101541460:     	mov	w10, #0x1c              ; =28
101541464:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541468:     	ldr	w9, [x1, #0x270]
10154146c:     	cbnz	w9, 0x101541560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x128c>
101541470:     	ldr	x9, [x1, #0xc0]
101541474:     	cmp	x9, #0x2
101541478:     	b.ne	0x101541560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x128c>
10154147c:     	ldr	x9, [x1, #0x220]
101541480:     	cmp	x9, #0x2
101541484:     	b.eq	0x101541560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x128c>
101541488:     	ldr	x9, [x1, #0x1d8]
10154148c:     	cmp	x9, x22
101541490:     	b.ne	0x101541560 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x128c>
101541494:     	ldr	x21, [x1, #0x4e0]
101541498:     	mov	x8, #-0x41              ; =-65
10154149c:     	movk	x8, #0xfff, lsl #48
1015414a0:     	cmp	x21, x8
1015414a4:     	b.hi	0x101542a84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27b0>
1015414a8:     	ldr	x8, [x20, #0x490]
1015414ac:     	lsl	x9, x21, #4
1015414b0:     	add	x0, sp, #0x550
1015414b4:     	add	x1, x8, #0x2f8
1015414b8:     	add	x2, x9, #0x400
1015414bc:     	bl	0x101529328 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015414c0:     	ldrb	w8, [sp, #0x550]
1015414c4:     	cmp	w8, #0xe
1015414c8:     	b.ne	0x101541780 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ac>
1015414cc:     	cbz	x21, 0x1015414e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x120c>
1015414d0:     	ldr	x0, [x20, #0x4d8]
1015414d4:     	cbz	x0, 0x101541ab8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17e4>
1015414d8:     	lsl	x1, x21, #3
1015414dc:     	bl	0x103a03498 <dyld_stub_binder+0x103a03498>
1015414e0:     	add	x0, x20, #0x1d8
1015414e4:     	bl	0x101526afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
1015414e8:     	mov	w8, #0x2                ; =2
1015414ec:     	str	x8, [x20, #0x220]
1015414f0:     	ldr	x8, [x20, #0x238]
1015414f4:     	cmp	x8, #0x3
1015414f8:     	b.eq	0x1015431b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ee0>
1015414fc:     	mov	w8, #0x1                ; =1
101541500:     	str	w8, [x20, #0x270]
101541504:     	str	w19, [x20, #0x274]
101541508:     	str	xzr, [x23, #0x8]
10154150c:     	b	0x101541740 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x146c>
101541510:     	cmp	w11, w19
101541514:     	b.ne	0x10154157c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12a8>
101541518:     	ldrb	w9, [x1, #0x288]
10154151c:     	tbnz	w9, #0x0, 0x10154157c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12a8>
101541520:     	ldrb	w9, [x1, #0x289]
101541524:     	tbnz	w9, #0x0, 0x10154157c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x12a8>
101541528:     	add	x0, sp, #0x550
10154152c:     	mov	x2, x19
101541530:     	mov	x4, x22
101541534:     	bl	0x101536964 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23prepare_borrowed_region>
101541538:     	ldr	w8, [sp, #0x550]
10154153c:     	cmp	w8, #0x6
101541540:     	b.ne	0x10154174c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1478>
101541544:     	ldr	x8, [x25]
101541548:     	cmp	x8, #0x3
10154154c:     	b.eq	0x101542f14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c40>
101541550:     	ldur	q0, [x27, #0x8]
101541554:     	mov	w8, #0x1                ; =1
101541558:     	strb	w8, [x20, #0x288]
10154155c:     	b	0x10154173c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
101541560:     	str	wzr, [x8]
101541564:     	mov	w9, #0xc                ; =12
101541568:     	strb	w9, [x8, #0x8]
10154156c:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541570:     	add	x9, x9, #0xcab
101541574:     	mov	w10, #0x2f              ; =47
101541578:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
10154157c:     	str	wzr, [x8]
101541580:     	mov	w9, #0xc                ; =12
101541584:     	strb	w9, [x8, #0x8]
101541588:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10154158c:     	add	x9, x9, #0xd0c
101541590:     	b	0x101540d30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xa5c>
101541594:     	ldr	q0, [sp, #0x560]
101541598:     	ldr	q1, [sp, #0x570]
10154159c:     	stur	q0, [x24, #0xc]
1015415a0:     	ldur	q0, [x27, #0x4]
1015415a4:     	str	q0, [sp, #0x440]
1015415a8:     	ldr	q0, [sp, #0x580]
1015415ac:     	ldr	q2, [sp, #0x590]
1015415b0:     	stp	q0, q2, [x23, #0x30]
1015415b4:     	ldr	q0, [sp, #0x440]
1015415b8:     	stur	q0, [x23, #0x4]
1015415bc:     	ldur	q0, [x24, #0xc]
1015415c0:     	stp	q0, q1, [x23, #0x10]
1015415c4:     	str	w8, [x23]
1015415c8:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015415cc:     	str	wzr, [x28]
1015415d0:     	mov	w8, #0xc                ; =12
1015415d4:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
1015415d8:     	add	x9, x9, #0xfd4
1015415dc:     	stp	x8, x9, [x28, #0x8]
1015415e0:     	mov	w8, #0x30               ; =48
1015415e4:     	str	x8, [x28, #0x18]
1015415e8:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015415ec:     	str	wzr, [x23]
1015415f0:     	mov	w8, #0xc                ; =12
1015415f4:     	strb	w8, [x23, #0x8]
1015415f8:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015415fc:     	add	x8, x8, #0xcda
101541600:     	mov	w9, #0x32               ; =50
101541604:     	stp	x8, x9, [x23, #0x10]
101541608:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154160c:     	ldr	x1, [x10, #0x270]
101541610:     	cmp	x9, x1
101541614:     	b.hs	0x101543864 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3590>
101541618:     	ldr	x8, [x10, #0x268]
10154161c:     	add	x8, x8, x19, lsl #4
101541620:     	ldr	w9, [x8]
101541624:     	tbz	w9, #0x0, 0x101541828 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1554>
101541628:     	ldr	x3, [x8, #0x8]
10154162c:     	add	x0, sp, #0x550
101541630:     	mov	x1, x20
101541634:     	mov	x2, x21
101541638:     	bl	0x101534050 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation19begin_closed_region>
10154163c:     	ldr	w8, [sp, #0x550]
101541640:     	cmp	w8, #0x6
101541644:     	b.ne	0x10154174c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1478>
101541648:     	ldr	x8, [x25]
10154164c:     	cmp	x8, #0x3
101541650:     	b.eq	0x101543240 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f6c>
101541654:     	ldur	q0, [x27, #0x8]
101541658:     	mov	w8, #0x1                ; =1
10154165c:     	strb	w8, [x20, #0x289]
101541660:     	b	0x10154173c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
101541664:     	mov	x22, x0
101541668:     	ldr	x11, [x0, #0x3d8]
10154166c:     	cbz	x11, 0x1015418a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15d0>
101541670:     	ldr	x12, [x22, #0x3d0]
101541674:     	cmp	x12, x8
101541678:     	csel	x8, xzr, x8, lo
10154167c:     	sub	x8, x12, x8
101541680:     	ldr	x11, [x22, #0x3c8]
101541684:     	mov	w12, #0x58              ; =88
101541688:     	madd	x8, x8, x12, x11
10154168c:     	ldr	x11, [x8, #0x40]
101541690:     	cmp	x11, x9
101541694:     	b.ne	0x101541808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1534>
101541698:     	ldr	w9, [x10, #0x2e8]
10154169c:     	cmp	w9, #0x1
1015416a0:     	b.ne	0x101541808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1534>
1015416a4:     	ldr	w9, [x19, #0x34]
1015416a8:     	ldr	w10, [x10, #0x2ec]
1015416ac:     	cmp	w10, w9
1015416b0:     	b.ne	0x101541808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1534>
1015416b4:     	lsl	x0, x9, #1
1015416b8:     	ldr	x1, [x22, #0x4c0]
1015416bc:     	cmp	x0, x1
1015416c0:     	b.hs	0x10154394c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3678>
1015416c4:     	ldr	x9, [x8, #0x50]
1015416c8:     	ldr	x10, [x22, #0x4b8]
1015416cc:     	ldr	x10, [x10, x0, lsl #3]
1015416d0:     	subs	x9, x9, x10
1015416d4:     	b.lo	0x101541808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1534>
1015416d8:     	ldr	x10, [x8, #0x48]
1015416dc:     	cmp	x9, x10
1015416e0:     	b.ne	0x101541808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1534>
1015416e4:     	ldr	x10, [x22, #0x3f8]
1015416e8:     	ldr	x9, [x22, #0x3e8]
1015416ec:     	cmp	x9, x10
1015416f0:     	b.eq	0x101541718 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1444>
1015416f4:     	add	x10, x9, #0xc8
1015416f8:     	str	x10, [x22, #0x3e8]
1015416fc:     	ldr	x15, [x9]
101541700:     	ldp	w14, w13, [x9, #0x8]
101541704:     	ldrb	w12, [x9, #0x10]
101541708:     	ldp	x11, x10, [x9, #0x18]
10154170c:     	cbz	x15, 0x101542738 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2464>
101541710:     	cmp	x15, #0x2
101541714:     	b.ne	0x10154292c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2658>
101541718:     	str	wzr, [x21]
10154171c:     	mov	w8, #0xc                ; =12
101541720:     	strb	w8, [x21, #0x8]
101541724:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541728:     	add	x8, x8, #0x8b5
10154172c:     	mov	w9, #0x16               ; =22
101541730:     	b	0x101541820 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x154c>
101541734:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
101541738:     	ldr	q0, [x8, #0xc00]
10154173c:     	stur	q0, [x23, #0x8]
101541740:     	mov	w8, #0x6                ; =6
101541744:     	str	w8, [x23]
101541748:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154174c:     	ldr	w9, [sp, #0x554]
101541750:     	ldur	q0, [x27, #0x18]
101541754:     	stur	q0, [x23, #0x18]
101541758:     	ldur	q0, [x27, #0x28]
10154175c:     	stur	q0, [x23, #0x28]
101541760:     	ldur	q0, [x27, #0x38]
101541764:     	stur	q0, [x23, #0x38]
101541768:     	ldr	x10, [sp, #0x598]
10154176c:     	str	x10, [x23, #0x48]
101541770:     	ldur	q0, [x27, #0x8]
101541774:     	stp	w8, w9, [x23]
101541778:     	stur	q0, [x23, #0x8]
10154177c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541780:     	ldr	q0, [sp, #0x550]
101541784:     	ldr	q1, [sp, #0x560]
101541788:     	str	q0, [sp, #0x440]
10154178c:     	str	q1, [sp, #0x450]
101541790:     	ldr	q2, [sp, #0x570]
101541794:     	str	q2, [sp, #0x460]
101541798:     	ldr	x8, [sp, #0x580]
10154179c:     	str	x8, [sp, #0x470]
1015417a0:     	stur	q0, [x27, #0x4]
1015417a4:     	stur	q1, [x27, #0x14]
1015417a8:     	stur	q2, [x27, #0x24]
1015417ac:     	stur	x8, [x27, #0x34]
1015417b0:     	str	wzr, [x23]
1015417b4:     	ldr	q0, [sp, #0x550]
1015417b8:     	ldr	q1, [sp, #0x560]
1015417bc:     	stur	q0, [x23, #0x4]
1015417c0:     	stur	q1, [x23, #0x14]
1015417c4:     	ldr	q0, [sp, #0x570]
1015417c8:     	stur	q0, [x23, #0x24]
1015417cc:     	ldur	q0, [x27, #0x2c]
1015417d0:     	str	q0, [x23, #0x30]
1015417d4:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015417d8:     	mov	x19, x8
1015417dc:     	add	x0, sp, #0x550
1015417e0:     	add	x1, x9, #0x2f8
1015417e4:     	mov	w2, #0x100              ; =256
1015417e8:     	bl	0x101529328 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
1015417ec:     	ldrb	w8, [sp, #0x550]
1015417f0:     	cmp	w8, #0xe
1015417f4:     	b.ne	0x1015418c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x15f0>
1015417f8:     	str	xzr, [x19, #0x8]
1015417fc:     	mov	w8, #0x6                ; =6
101541800:     	str	w8, [x19]
101541804:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541808:     	str	wzr, [x21]
10154180c:     	mov	w8, #0xc                ; =12
101541810:     	strb	w8, [x21, #0x8]
101541814:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541818:     	add	x8, x8, #0x93b
10154181c:     	mov	w9, #0x33               ; =51
101541820:     	stp	x8, x9, [x21, #0x10]
101541824:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541828:     	str	wzr, [x23]
10154182c:     	mov	w8, #0xc                ; =12
101541830:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
101541834:     	add	x9, x9, #0x284
101541838:     	stp	x8, x9, [x23, #0x8]
10154183c:     	mov	w8, #0x26               ; =38
101541840:     	str	x8, [x23, #0x18]
101541844:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541848:     	cmp	x22, #0x9
10154184c:     	b.eq	0x101541af4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1820>
101541850:     	cmp	x22, #0x8
101541854:     	b.ne	0x101541b24 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1850>
101541858:     	mov	x0, x19
10154185c:     	ldr	x1, [sp, #0x58]
101541860:     	mov	x2, x20
101541864:     	mov	x3, x24
101541868:     	add	sp, sp, #0x810
10154186c:     	ldp	x29, x30, [sp, #0x50]
101541870:     	ldp	x20, x19, [sp, #0x40]
101541874:     	ldp	x22, x21, [sp, #0x30]
101541878:     	ldp	x24, x23, [sp, #0x20]
10154187c:     	ldp	x26, x25, [sp, #0x10]
101541880:     	ldp	x28, x27, [sp], #0x60
101541884:     	b	0x101537af0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation24prepare_borrowed_strings>
101541888:     	str	wzr, [x8]
10154188c:     	mov	w9, #0xc                ; =12
101541890:     	adrp	x10, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101541894:     	add	x10, x10, #0xbfd
101541898:     	stp	x9, x10, [x8, #0x8]
10154189c:     	mov	w9, #0x1a               ; =26
1015418a0:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
1015418a4:     	str	wzr, [x21]
1015418a8:     	mov	w8, #0xc                ; =12
1015418ac:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015418b0:     	add	x9, x9, #0x898
1015418b4:     	stp	x8, x9, [x21, #0x8]
1015418b8:     	mov	w8, #0x1d               ; =29
1015418bc:     	str	x8, [x21, #0x18]
1015418c0:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015418c4:     	ldr	q0, [sp, #0x550]
1015418c8:     	ldr	q1, [sp, #0x560]
1015418cc:     	str	q0, [sp, #0x440]
1015418d0:     	str	q1, [sp, #0x450]
1015418d4:     	ldr	q2, [sp, #0x570]
1015418d8:     	str	q2, [sp, #0x460]
1015418dc:     	ldr	x8, [sp, #0x580]
1015418e0:     	str	x8, [sp, #0x470]
1015418e4:     	stur	q0, [x27, #0x4]
1015418e8:     	stur	q1, [x27, #0x14]
1015418ec:     	stur	q2, [x27, #0x24]
1015418f0:     	stur	x8, [x27, #0x34]
1015418f4:     	str	wzr, [x19]
1015418f8:     	ldr	q0, [sp, #0x550]
1015418fc:     	ldr	q1, [sp, #0x560]
101541900:     	stur	q0, [x19, #0x4]
101541904:     	stur	q1, [x19, #0x14]
101541908:     	ldr	q0, [sp, #0x570]
10154190c:     	stur	q0, [x19, #0x24]
101541910:     	ldur	q0, [x27, #0x2c]
101541914:     	str	q0, [x19, #0x30]
101541918:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154191c:     	ldr	x9, [sp, #0x58]
101541920:     	ldr	x9, [x9, #0x3d8]
101541924:     	cbz	x9, 0x101541b70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x189c>
101541928:     	ldr	x9, [sp, #0x58]
10154192c:     	ldr	x10, [x9, #0x3d0]
101541930:     	cmp	x10, x8
101541934:     	csel	x8, xzr, x8, lo
101541938:     	sub	x8, x10, x8
10154193c:     	ldr	x9, [x9, #0x3c8]
101541940:     	mov	w10, #0x58              ; =88
101541944:     	madd	x20, x8, x10, x9
101541948:     	ldr	x8, [x20, #0x40]
10154194c:     	cmp	x8, x19
101541950:     	b.ne	0x101541a9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c8>
101541954:     	ldr	x8, [x20, #0x48]
101541958:     	cbnz	x8, 0x101541a9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c8>
10154195c:     	ldr	x8, [x20, #0x50]
101541960:     	cmp	x8, x28
101541964:     	b.ne	0x101541a9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x17c8>
101541968:     	ldr	w1, [x22, #0x50]
10154196c:     	add	x8, sp, #0x550
101541970:     	add	x0, x24, #0xf0
101541974:     	add	x2, x24, #0x2f8
101541978:     	bl	0x1016370b0 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
10154197c:     	ldur	q0, [x27, #0x8]
101541980:     	ldur	q1, [x27, #0x18]
101541984:     	stp	q0, q1, [sp, #0x3a0]
101541988:     	ldur	q0, [x27, #0x28]
10154198c:     	str	q0, [sp, #0x3c0]
101541990:     	ldr	x8, [sp, #0x550]
101541994:     	ldr	x9, [sp, #0x588]
101541998:     	str	x9, [sp, #0x3d0]
10154199c:     	cbz	x8, 0x101542160 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1e8c>
1015419a0:     	ldp	q0, q1, [sp, #0x3a0]
1015419a4:     	add	x9, sp, #0x440
1015419a8:     	stur	q0, [x9, #0x8]
1015419ac:     	ldr	x10, [sp, #0x3d0]
1015419b0:     	ldr	q0, [sp, #0x3c0]
1015419b4:     	stur	q0, [x9, #0x28]
1015419b8:     	stur	q1, [x9, #0x18]
1015419bc:     	str	x10, [sp, #0x478]
1015419c0:     	str	x8, [sp, #0x440]
1015419c4:     	ldr	x8, [sp, #0x448]
1015419c8:     	ldr	x9, [x20, #0x8]
1015419cc:     	ldr	x8, [x8, #0x10]
1015419d0:     	ldr	x9, [x9, #0x10]
1015419d4:     	cmp	x8, x9
1015419d8:     	b.eq	0x1015422b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fdc>
1015419dc:     	mov	w8, #0x0                ; =0
1015419e0:     	mov	w9, #0xc                ; =12
1015419e4:     	strb	w9, [x23, #0x8]
1015419e8:     	mov	w9, #0x27               ; =39
1015419ec:     	str	x9, [x23, #0x18]
1015419f0:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015419f4:     	add	x9, x9, #0x6c5
1015419f8:     	b	0x1015422c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fec>
1015419fc:     	ldr	w9, [sp, #0x554]
101541a00:     	ldur	q0, [x27, #0x18]
101541a04:     	stur	q0, [x28, #0x18]
101541a08:     	ldur	q0, [x27, #0x28]
101541a0c:     	stur	q0, [x28, #0x28]
101541a10:     	ldur	q0, [x27, #0x38]
101541a14:     	stur	q0, [x28, #0x38]
101541a18:     	ldr	x10, [sp, #0x598]
101541a1c:     	str	x10, [x28, #0x48]
101541a20:     	ldur	q0, [x27, #0x8]
101541a24:     	stp	w8, w9, [x28]
101541a28:     	stur	q0, [x28, #0x8]
101541a2c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541a30:     	mov	x9, x20
101541a34:     	ldr	x8, [x20, #0xc0]
101541a38:     	cmp	x8, #0x2
101541a3c:     	mov	x8, x23
101541a40:     	b.ne	0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101541a44:     	ldr	x9, [x9, #0x220]
101541a48:     	cmp	x9, #0x2
101541a4c:     	b.ne	0x101541ad8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1804>
101541a50:     	ldr	x8, [x24, #0x360]
101541a54:     	ldr	w1, [x21, #0x4c]
101541a58:     	cmp	x8, x1
101541a5c:     	b.ls	0x1015438f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3624>
101541a60:     	ldr	x8, [x24, #0x358]
101541a64:     	mov	w9, #0x140              ; =320
101541a68:     	umaddl	x8, w1, w9, x8
101541a6c:     	ldrb	w9, [x8, #0x124]
101541a70:     	ldr	x8, [x25]
101541a74:     	cmp	w9, #0x7
101541a78:     	b.ne	0x101541c80 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19ac>
101541a7c:     	cbz	x8, 0x101541e90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1bbc>
101541a80:     	str	wzr, [x23]
101541a84:     	mov	w8, #0xc                ; =12
101541a88:     	strb	w8, [x23, #0x8]
101541a8c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541a90:     	add	x8, x8, #0x9e0
101541a94:     	mov	w9, #0x28               ; =40
101541a98:     	b	0x101541604 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1330>
101541a9c:     	str	wzr, [x23]
101541aa0:     	mov	w8, #0xc                ; =12
101541aa4:     	strb	w8, [x23, #0x8]
101541aa8:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541aac:     	add	x8, x8, #0x6ec
101541ab0:     	mov	w9, #0x36               ; =54
101541ab4:     	b	0x101541604 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1330>
101541ab8:     	str	wzr, [x23]
101541abc:     	mov	w8, #0xc                ; =12
101541ac0:     	strb	w8, [x23, #0x8]
101541ac4:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101541ac8:     	add	x8, x8, #0x1fe
101541acc:     	mov	w9, #0x29               ; =41
101541ad0:     	b	0x101541604 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1330>
101541ad4:     	mov	x8, x23
101541ad8:     	str	wzr, [x8]
101541adc:     	mov	w9, #0xc                ; =12
101541ae0:     	strb	w9, [x8, #0x8]
101541ae4:     	adrp	x9, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541ae8:     	add	x9, x9, #0xa08
101541aec:     	mov	w10, #0x28              ; =40
101541af0:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541af4:     	mov	x0, x19
101541af8:     	ldr	x1, [sp, #0x58]
101541afc:     	mov	x2, x20
101541b00:     	mov	x3, x24
101541b04:     	add	sp, sp, #0x810
101541b08:     	ldp	x29, x30, [sp, #0x50]
101541b0c:     	ldp	x20, x19, [sp, #0x40]
101541b10:     	ldp	x22, x21, [sp, #0x30]
101541b14:     	ldp	x24, x23, [sp, #0x20]
101541b18:     	ldp	x26, x25, [sp, #0x10]
101541b1c:     	ldp	x28, x27, [sp], #0x60
101541b20:     	b	0x10153555c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation23borrowed_string_failure>
101541b24:     	ldr	x0, [sp, #0x58]
101541b28:     	mov	x1, x20
101541b2c:     	bl	0x10153549c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
101541b30:     	cbz	x0, 0x101541cdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a08>
101541b34:     	str	wzr, [x19]
101541b38:     	mov	w8, #0xc                ; =12
101541b3c:     	strb	w8, [x19, #0x8]
101541b40:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541b44:     	add	x8, x8, #0x4bb
101541b48:     	mov	w9, #0x2e               ; =46
101541b4c:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101541b50:     	str	wzr, [x28]
101541b54:     	mov	w8, #0xc                ; =12
101541b58:     	strb	w8, [x28, #0x8]
101541b5c:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
101541b60:     	add	x8, x8, #0xdd2
101541b64:     	mov	w9, #0x23               ; =35
101541b68:     	stp	x8, x9, [x28, #0x10]
101541b6c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541b70:     	str	wzr, [x23]
101541b74:     	mov	w8, #0xc                ; =12
101541b78:     	adrp	x9, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101541b7c:     	add	x9, x9, #0xc76
101541b80:     	stp	x8, x9, [x23, #0x8]
101541b84:     	mov	w8, #0x14               ; =20
101541b88:     	str	x8, [x23, #0x18]
101541b8c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541b90:     	ldr	x8, [sp, #0x58]
101541b94:     	ldr	x8, [x8, #0x490]
101541b98:     	add	x0, sp, #0x550
101541b9c:     	add	x1, x8, #0x2f8
101541ba0:     	mov	w2, #0x40               ; =64
101541ba4:     	bl	0x101529328 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101541ba8:     	ldrb	w8, [sp, #0x550]
101541bac:     	cmp	w8, #0xe
101541bb0:     	b.ne	0x101541e18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b44>
101541bb4:     	ldr	x0, [x23, x22]
101541bb8:     	ldr	x8, [x21, #0x40]
101541bbc:     	str	x8, [sp, #0x28]
101541bc0:     	cmp	x0, x8
101541bc4:     	b.hs	0x10154399c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36c8>
101541bc8:     	ldr	x10, [x21, #0x38]
101541bcc:     	ldr	w3, [x21, #0xe0]
101541bd0:     	ldr	x8, [sp, #0x58]
101541bd4:     	ldr	x8, [x8, #0x490]
101541bd8:     	mov	w9, #0x18               ; =24
101541bdc:     	mul	x9, x0, x9
101541be0:     	str	x10, [sp, #0x20]
101541be4:     	ldr	x4, [x10, x9]
101541be8:     	ldr	x1, [x8, #0x3c0]
101541bec:     	add	x0, sp, #0x550
101541bf0:     	add	x2, x19, #0x488
101541bf4:     	bl	0x10152a740 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames18take_managed_owner>
101541bf8:     	ldr	w8, [sp, #0x550]
101541bfc:     	cmp	w8, #0x6
101541c00:     	b.ne	0x101541f28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c54>
101541c04:     	ldur	q0, [x27, #0x28]
101541c08:     	stur	q0, [x24, #0x24]
101541c0c:     	ldur	q1, [x27, #0x38]
101541c10:     	ldur	q2, [x27, #0x18]
101541c14:     	ldur	q3, [x27, #0x8]
101541c18:     	stp	q3, q2, [sp, #0x60]
101541c1c:     	stp	q0, q1, [sp, #0x80]
101541c20:     	add	x24, sp, #0x550
101541c24:     	add	x8, sp, #0x550
101541c28:     	ldr	x0, [sp, #0x58]
101541c2c:     	mov	w1, #0x0                ; =0
101541c30:     	bl	0x10154aca8 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation25selected_join_coexistence>
101541c34:     	ldr	x8, [sp, #0x550]
101541c38:     	cmp	x8, #0x1
101541c3c:     	b.ne	0x101542088 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1db4>
101541c40:     	ldur	q0, [x24, #0x18]
101541c44:     	ldur	q1, [x24, #0x28]
101541c48:     	ldur	q2, [x24, #0x38]
101541c4c:     	str	q1, [sp, #0x460]
101541c50:     	str	q2, [sp, #0x470]
101541c54:     	ldur	q3, [x24, #0x48]
101541c58:     	str	q3, [sp, #0x480]
101541c5c:     	ldur	q4, [x24, #0x8]
101541c60:     	str	q0, [sp, #0x450]
101541c64:     	str	q4, [sp, #0x440]
101541c68:     	stp	q1, q2, [x28, #0x20]
101541c6c:     	str	q3, [x28, #0x40]
101541c70:     	stp	q4, q0, [x28]
101541c74:     	add	x0, sp, #0x60
101541c78:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101541c7c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541c80:     	mov	x9, #0x0                ; =0
101541c84:     	ldr	x10, [x22, #0x330]
101541c88:     	ldr	x11, [x22, #0x3c8]
101541c8c:     	ldr	x12, [x22, #0x430]
101541c90:     	ldp	q0, q1, [x22, #0x3d0]
101541c94:     	ldp	q2, q3, [x22, #0x3f0]
101541c98:     	ldr	q4, [x22, #0x410]
101541c9c:     	ldr	q5, [x22, #0x420]
101541ca0:     	mov	w13, #0x1               ; =1
101541ca4:     	stp	x13, x9, [x20, #0xf8]
101541ca8:     	str	x8, [x20, #0x108]
101541cac:     	ldp	q6, q7, [sp, #0x60]
101541cb0:     	stp	q6, q7, [x20, #0x110]
101541cb4:     	ldr	q6, [sp, #0x80]
101541cb8:     	str	q6, [x20, #0x130]
101541cbc:     	stp	x10, x11, [x20, #0x140]
101541cc0:     	stp	q0, q1, [x20, #0x150]
101541cc4:     	stp	q2, q3, [x20, #0x170]
101541cc8:     	stp	q4, q5, [x20, #0x190]
101541ccc:     	str	x12, [x20, #0x1b0]
101541cd0:     	str	w19, [x20, #0x1b8]
101541cd4:     	dup.2d	v0, x13
101541cd8:     	b	0x10154173c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1468>
101541cdc:     	ldr	x8, [x23, #0x558]
101541ce0:     	cmp	x20, x8
101541ce4:     	b.hs	0x101541d00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1a2c>
101541ce8:     	ldr	x8, [x23, #0x550]
101541cec:     	mov	w9, #0x28               ; =40
101541cf0:     	mul	x9, x20, x9
101541cf4:     	ldr	w8, [x8, x9]
101541cf8:     	cmp	w8, #0x5
101541cfc:     	b.ne	0x101541f90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cbc>
101541d00:     	cmp	x22, #0x6
101541d04:     	b.gt	0x101541edc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1c08>
101541d08:     	cmp	x22, #0x4
101541d0c:     	b.eq	0x101542194 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ec0>
101541d10:     	cmp	x22, #0x5
101541d14:     	b.eq	0x10154221c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f48>
101541d18:     	cmp	x22, #0x6
101541d1c:     	b.ne	0x1015421f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f20>
101541d20:     	ldr	q0, [x24]
101541d24:     	str	q0, [sp, #0x550]
101541d28:     	ldr	x8, [x24, #0x10]
101541d2c:     	str	x8, [sp, #0x560]
101541d30:     	add	x3, sp, #0x550
101541d34:     	mov	x0, x19
101541d38:     	ldr	x1, [sp, #0x58]
101541d3c:     	mov	x2, x20
101541d40:     	bl	0x10153977c <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation25prepare_string_map_region>
101541d44:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541d48:     	mov	w11, #0x0               ; =0
101541d4c:     	mov	w10, #0x0               ; =0
101541d50:     	mov	w13, #0x6               ; =6
101541d54:     	mov	x8, #-0x1               ; =-1
101541d58:     	mov	x12, x23
101541d5c:     	b	0x101540f08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0xc34>
101541d60:     	cbnz	x28, 0x101541d7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aa8>
101541d64:     	ldp	x1, x2, [x23, #0x8]
101541d68:     	ldr	x0, [sp, #0x50]
101541d6c:     	bl	0x101557618 <__RNvXsC_NtNtCsgDHHaSskbIF_4core5slice3cmpmNtB5_13SliceContains14slice_contains>
101541d70:     	tbz	w0, #0x0, 0x101541d7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1aa8>
101541d74:     	mov	x8, #0x0                ; =0
101541d78:     	b	0x101541dd8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b04>
101541d7c:     	ldr	x8, [sp, #0x48]
101541d80:     	str	wzr, [x8]
101541d84:     	mov	w9, #0xc                ; =12
101541d88:     	strb	w9, [x8, #0x8]
101541d8c:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101541d90:     	add	x9, x9, #0x9e
101541d94:     	mov	w10, #0x38              ; =56
101541d98:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541d9c:     	ldr	x9, [x23, #0xa0]
101541da0:     	cbz	x9, 0x101541e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b9c>
101541da4:     	ldr	x8, [x23, #0x98]
101541da8:     	lsl	x9, x9, #5
101541dac:     	b	0x101541dbc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ae8>
101541db0:     	add	x8, x8, #0x20
101541db4:     	subs	x9, x9, #0x20
101541db8:     	b.eq	0x101541e70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b9c>
101541dbc:     	ldr	w11, [x8, #0x18]
101541dc0:     	ldr	x10, [sp, #0x50]
101541dc4:     	cmp	x10, x11
101541dc8:     	b.ne	0x101541db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1adc>
101541dcc:     	ldr	w10, [x8, #0x1c]
101541dd0:     	cmp	x28, x10
101541dd4:     	b.ne	0x101541db0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1adc>
101541dd8:     	str	x8, [sp, #0x220]
101541ddc:     	ldr	x9, [sp, #0x40]
101541de0:     	ldp	x8, x9, [x9, #0xd0]
101541de4:     	lsl	x9, x9, #6
101541de8:     	cbz	x9, 0x101541fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cd8>
101541dec:     	ldr	x10, [x8], #0x40
101541df0:     	sub	x9, x9, #0x40
101541df4:     	cbz	x10, 0x101541de8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1b14>
101541df8:     	ldr	x8, [sp, #0x48]
101541dfc:     	str	wzr, [x8]
101541e00:     	mov	w9, #0xc                ; =12
101541e04:     	strb	w9, [x8, #0x8]
101541e08:     	adrp	x9, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101541e0c:     	add	x9, x9, #0x6c
101541e10:     	mov	w10, #0x32              ; =50
101541e14:     	b	0x101540360 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x8c>
101541e18:     	ldr	q0, [sp, #0x550]
101541e1c:     	ldr	q1, [sp, #0x560]
101541e20:     	str	q0, [sp, #0x440]
101541e24:     	str	q1, [sp, #0x450]
101541e28:     	ldr	q2, [sp, #0x570]
101541e2c:     	str	q2, [sp, #0x460]
101541e30:     	ldr	x8, [sp, #0x580]
101541e34:     	str	x8, [sp, #0x470]
101541e38:     	stur	q0, [x27, #0x4]
101541e3c:     	stur	q1, [x27, #0x14]
101541e40:     	stur	q2, [x27, #0x24]
101541e44:     	stur	x8, [x27, #0x34]
101541e48:     	str	wzr, [x28]
101541e4c:     	ldr	q0, [sp, #0x550]
101541e50:     	ldr	q1, [sp, #0x560]
101541e54:     	stur	q0, [x28, #0x4]
101541e58:     	stur	q1, [x28, #0x14]
101541e5c:     	ldr	q0, [sp, #0x570]
101541e60:     	stur	q0, [x28, #0x24]
101541e64:     	ldur	q0, [x27, #0x2c]
101541e68:     	str	q0, [x28, #0x30]
101541e6c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541e70:     	ldr	x8, [sp, #0x48]
101541e74:     	str	wzr, [x8]
101541e78:     	mov	w9, #0xc                ; =12
101541e7c:     	adrp	x10, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101541e80:     	add	x10, x10, #0xf59
101541e84:     	stp	x9, x10, [x8, #0x8]
101541e88:     	mov	w9, #0x31               ; =49
101541e8c:     	b	0x1015405a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d0>
101541e90:     	add	x8, sp, #0x550
101541e94:     	add	x0, x22, #0xf0
101541e98:     	add	x2, x22, #0x2f8
101541e9c:     	bl	0x1016370b0 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101541ea0:     	ldr	x9, [sp, #0x550]
101541ea4:     	ldr	x8, [sp, #0x558]
101541ea8:     	ldr	q0, [sp, #0x560]
101541eac:     	ldr	q1, [sp, #0x570]
101541eb0:     	str	q0, [sp, #0x440]
101541eb4:     	str	q1, [sp, #0x450]
101541eb8:     	ldr	q0, [sp, #0x580]
101541ebc:     	str	q0, [sp, #0x460]
101541ec0:     	cbz	x9, 0x101542064 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1d90>
101541ec4:     	ldr	q0, [sp, #0x440]
101541ec8:     	ldr	q1, [sp, #0x450]
101541ecc:     	stp	q0, q1, [sp, #0x60]
101541ed0:     	ldr	q0, [sp, #0x460]
101541ed4:     	str	q0, [sp, #0x80]
101541ed8:     	b	0x101541c84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x19b0>
101541edc:     	cmp	x22, #0x7
101541ee0:     	b.eq	0x1015421c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1ef0>
101541ee4:     	cmp	x22, #0x10
101541ee8:     	b.eq	0x10154224c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f78>
101541eec:     	cmp	x22, #0x11
101541ef0:     	b.ne	0x1015421f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1f20>
101541ef4:     	ldp	x4, x5, [x24, #0x8]
101541ef8:     	ldr	x3, [x24]
101541efc:     	mov	x0, x19
101541f00:     	ldr	x1, [sp, #0x58]
101541f04:     	mov	x2, x20
101541f08:     	add	sp, sp, #0x810
101541f0c:     	ldp	x29, x30, [sp, #0x50]
101541f10:     	ldp	x20, x19, [sp, #0x40]
101541f14:     	ldp	x22, x21, [sp, #0x30]
101541f18:     	ldp	x24, x23, [sp, #0x20]
101541f1c:     	ldp	x26, x25, [sp, #0x10]
101541f20:     	ldp	x28, x27, [sp], #0x60
101541f24:     	b	0x10154da1c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation21finish_join_map_chunk>
101541f28:     	ldur	q0, [x27, #0x14]
101541f2c:     	ldur	q1, [x27, #0x24]
101541f30:     	ldur	q2, [x27, #0x34]
101541f34:     	str	q1, [sp, #0x460]
101541f38:     	str	q2, [sp, #0x470]
101541f3c:     	ldr	w9, [sp, #0x594]
101541f40:     	str	w9, [sp, #0x480]
101541f44:     	ldur	q3, [x27, #0x4]
101541f48:     	str	q0, [sp, #0x450]
101541f4c:     	str	q3, [sp, #0x440]
101541f50:     	ldr	x10, [sp, #0x598]
101541f54:     	stur	q0, [x28, #0x14]
101541f58:     	stur	q1, [x28, #0x24]
101541f5c:     	stur	q2, [x28, #0x34]
101541f60:     	str	w9, [x28, #0x44]
101541f64:     	stur	q3, [x28, #0x4]
101541f68:     	str	w8, [x28]
101541f6c:     	str	x10, [x28, #0x48]
101541f70:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101541f74:     	str	wzr, [x23]
101541f78:     	mov	w8, #0xc                ; =12
101541f7c:     	strb	w8, [x23, #0x8]
101541f80:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541f84:     	add	x8, x8, #0x722
101541f88:     	mov	w9, #0x24               ; =36
101541f8c:     	b	0x101541604 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1330>
101541f90:     	str	wzr, [x19]
101541f94:     	mov	w8, #0xc                ; =12
101541f98:     	strb	w8, [x19, #0x8]
101541f9c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101541fa0:     	add	x8, x8, #0x5d4
101541fa4:     	mov	w9, #0x24               ; =36
101541fa8:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101541fac:     	add	x8, sp, #0x220
101541fb0:     	str	x8, [sp, #0x440]
101541fb4:     	str	x24, [sp, #0x448]
101541fb8:     	ldr	x19, [sp, #0x58]
101541fbc:     	str	x19, [sp, #0x450]
101541fc0:     	ldr	x8, [sp, #0x38]
101541fc4:     	str	x8, [sp, #0x458]
101541fc8:     	str	x21, [sp, #0x460]
101541fcc:     	add	x0, sp, #0x550
101541fd0:     	add	x1, sp, #0x440
101541fd4:     	bl	0x101528640 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16numeric_segmentsNtB6_10Invocation19end_numeric_segments4_0Be_>
101541fd8:     	ldr	x8, [x19, #0x490]
101541fdc:     	ldr	x2, [x8, #0xd8]
101541fe0:     	ldr	x1, [x23, #0x40]
101541fe4:     	cmp	x1, x2
101541fe8:     	b.hi	0x101543514 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3240>
101541fec:     	ldr	x0, [x8, #0xd0]
101541ff0:     	str	xzr, [sp, #0x440]
101541ff4:     	add	x2, sp, #0x440
101541ff8:     	bl	0x1016132bc <__RNvXNtNtCsgDHHaSskbIF_4core5slice10specializeSINtNtB6_6option6OptionNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueEINtB2_8SpecFillBI_E9spec_fillCs7fdMCt8k5K6_8mech_gpu>
101541ffc:     	ldr	w8, [sp, #0x550]
101542000:     	cmp	w8, #0x6
101542004:     	b.ne	0x10154227c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1fa8>
101542008:     	ldr	x9, [sp, #0x58]
10154200c:     	ldr	x8, [x9, #0x490]
101542010:     	str	wzr, [x8, #0x340]
101542014:     	ldr	x10, [x9, #0x490]
101542018:     	mov	w8, #0x1                ; =1
10154201c:     	str	w8, [x10, #0x2f0]
101542020:     	ldr	x8, [sp, #0x50]
101542024:     	str	w8, [x10, #0x2f4]
101542028:     	ldr	x8, [x9, #0x490]
10154202c:     	cmp	x20, #0x2
101542030:     	cset	w9, ne
101542034:     	strb	w9, [x8, #0x460]
101542038:     	ldr	x8, [sp, #0x48]
10154203c:     	str	xzr, [x8, #0x8]
101542040:     	mov	w9, #0x6                ; =6
101542044:     	str	w9, [x8]
101542048:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154204c:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101542050:     	add	x0, x0, #0x910
101542054:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101542058:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154205c:     	add	x0, x0, #0x928
101542060:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101542064:     	ldr	q0, [sp, #0x440]
101542068:     	ldr	q1, [sp, #0x450]
10154206c:     	stp	q0, q1, [x23, #0x10]
101542070:     	ldr	q0, [sp, #0x460]
101542074:     	str	q0, [x23, #0x30]
101542078:     	mov	w9, #0x2                ; =2
10154207c:     	str	w9, [x23]
101542080:     	str	x8, [x23, #0x8]
101542084:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542088:     	ldur	q0, [x24, #0x48]
10154208c:     	ldur	q1, [x24, #0x58]
101542090:     	str	q0, [sp, #0x480]
101542094:     	str	q1, [sp, #0x490]
101542098:     	ldur	x8, [x24, #0x68]
10154209c:     	str	x8, [sp, #0x4a0]
1015420a0:     	ldur	q2, [x24, #0x8]
1015420a4:     	ldur	q3, [x24, #0x18]
1015420a8:     	str	q2, [sp, #0x440]
1015420ac:     	str	q3, [sp, #0x450]
1015420b0:     	ldur	q4, [x24, #0x38]
1015420b4:     	ldur	q5, [x24, #0x28]
1015420b8:     	stp	q2, q3, [sp, #0xa0]
1015420bc:     	stp	q5, q4, [sp, #0xc0]
1015420c0:     	str	x8, [sp, #0x100]
1015420c4:     	stp	q0, q1, [sp, #0xe0]
1015420c8:     	ldr	w8, [x23]
1015420cc:     	cmp	w8, #0x6
1015420d0:     	b.ne	0x1015422d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2000>
1015420d4:     	ldp	q0, q1, [sp, #0x60]
1015420d8:     	str	q0, [sp, #0x440]
1015420dc:     	str	q1, [sp, #0x450]
1015420e0:     	ldp	q0, q1, [sp, #0x80]
1015420e4:     	str	q0, [sp, #0x460]
1015420e8:     	str	q1, [sp, #0x470]
1015420ec:     	ldr	x8, [sp, #0x58]
1015420f0:     	ldp	q0, q1, [x8, #0x80]
1015420f4:     	str	q0, [sp, #0x5d0]
1015420f8:     	str	q1, [sp, #0x5e0]
1015420fc:     	ldr	x9, [x8, #0xa0]
101542100:     	str	x9, [sp, #0x5f0]
101542104:     	ldp	q0, q1, [x8, #0x40]
101542108:     	str	q0, [sp, #0x590]
10154210c:     	str	q1, [sp, #0x5a0]
101542110:     	ldp	q1, q0, [x8, #0x60]
101542114:     	str	q0, [sp, #0x5c0]
101542118:     	str	q1, [sp, #0x5b0]
10154211c:     	ldp	q0, q1, [x8]
101542120:     	str	q0, [sp, #0x550]
101542124:     	str	q1, [sp, #0x560]
101542128:     	ldp	q1, q0, [x8, #0x20]
10154212c:     	str	q0, [sp, #0x580]
101542130:     	str	q1, [sp, #0x570]
101542134:     	ldr	x9, [x8, #0x490]
101542138:     	add	x8, sp, #0x110
10154213c:     	add	x1, sp, #0x440
101542140:     	add	x4, sp, #0x550
101542144:     	add	x5, x9, #0x3b8
101542148:     	add	x6, sp, #0xa0
10154214c:     	ldr	x0, [sp, #0x30]
101542150:     	ldr	x2, [sp, #0x40]
101542154:     	mov	w3, #0x1                ; =1
101542158:     	bl	0x10253200c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared16unsigned_buffersNtB4_25NativePreparedLibraryCall30unsigned_matrix_append_private>
10154215c:     	b	0x10154235c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2088>
101542160:     	ldp	q0, q1, [sp, #0x3a0]
101542164:     	stur	q0, [x27, #0x4]
101542168:     	stur	q1, [x27, #0x14]
10154216c:     	ldr	q0, [sp, #0x3c0]
101542170:     	stur	q0, [x27, #0x24]
101542174:     	ldr	x8, [sp, #0x3d0]
101542178:     	stur	x8, [x27, #0x34]
10154217c:     	ldr	q0, [sp, #0x550]
101542180:     	ldr	q1, [sp, #0x560]
101542184:     	stur	q0, [x23, #0x4]
101542188:     	mov	w8, #0x2                ; =2
10154218c:     	str	w8, [x23]
101542190:     	b	0x1015417c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x14ec>
101542194:     	mov	x0, x19
101542198:     	ldr	x1, [sp, #0x58]
10154219c:     	mov	x2, x20
1015421a0:     	mov	x3, x24
1015421a4:     	add	sp, sp, #0x810
1015421a8:     	ldp	x29, x30, [sp, #0x50]
1015421ac:     	ldp	x20, x19, [sp, #0x40]
1015421b0:     	ldp	x22, x21, [sp, #0x30]
1015421b4:     	ldp	x24, x23, [sp, #0x20]
1015421b8:     	ldp	x26, x25, [sp, #0x10]
1015421bc:     	ldp	x28, x27, [sp], #0x60
1015421c0:     	b	0x101534c84 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation21prepare_window_region>
1015421c4:     	mov	x0, x19
1015421c8:     	ldr	x1, [sp, #0x58]
1015421cc:     	mov	x2, x20
1015421d0:     	mov	x3, x24
1015421d4:     	add	sp, sp, #0x810
1015421d8:     	ldp	x29, x30, [sp, #0x50]
1015421dc:     	ldp	x20, x19, [sp, #0x40]
1015421e0:     	ldp	x22, x21, [sp, #0x30]
1015421e4:     	ldp	x24, x23, [sp, #0x20]
1015421e8:     	ldp	x26, x25, [sp, #0x10]
1015421ec:     	ldp	x28, x27, [sp], #0x60
1015421f0:     	b	0x1015393d4 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6window10string_mapNtB6_10Invocation24finish_string_map_region>
1015421f4:     	ldr	x8, [sp, #0x58]
1015421f8:     	ldr	x8, [x8, #0xa8]
1015421fc:     	cbz	x8, 0x101542a44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2770>
101542200:     	str	wzr, [x19]
101542204:     	mov	w8, #0xc                ; =12
101542208:     	strb	w8, [x19, #0x8]
10154220c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101542210:     	add	x8, x8, #0x4e9
101542214:     	mov	w9, #0x2d               ; =45
101542218:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
10154221c:     	mov	x0, x19
101542220:     	ldr	x1, [sp, #0x58]
101542224:     	mov	x2, x20
101542228:     	mov	x3, x24
10154222c:     	add	sp, sp, #0x810
101542230:     	ldp	x29, x30, [sp, #0x50]
101542234:     	ldp	x20, x19, [sp, #0x40]
101542238:     	ldp	x22, x21, [sp, #0x30]
10154223c:     	ldp	x24, x23, [sp, #0x20]
101542240:     	ldp	x26, x25, [sp, #0x10]
101542244:     	ldp	x28, x27, [sp], #0x60
101542248:     	b	0x101534688 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation6windowNtB4_10Invocation20finish_window_region>
10154224c:     	mov	x0, x19
101542250:     	ldr	x1, [sp, #0x58]
101542254:     	mov	x2, x20
101542258:     	mov	x3, x24
10154225c:     	add	sp, sp, #0x810
101542260:     	ldp	x29, x30, [sp, #0x50]
101542264:     	ldp	x20, x19, [sp, #0x40]
101542268:     	ldp	x22, x21, [sp, #0x30]
10154226c:     	ldp	x24, x23, [sp, #0x20]
101542270:     	ldp	x26, x25, [sp, #0x10]
101542274:     	ldp	x28, x27, [sp], #0x60
101542278:     	b	0x10154dd7c <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation22prepare_join_map_chunk>
10154227c:     	ldur	q0, [x27, #0x14]
101542280:     	ldr	x9, [sp, #0x48]
101542284:     	stur	q0, [x9, #0x14]
101542288:     	ldur	q0, [x27, #0x24]
10154228c:     	stur	q0, [x9, #0x24]
101542290:     	ldur	q0, [x27, #0x34]
101542294:     	stur	q0, [x9, #0x34]
101542298:     	ldr	q0, [sp, #0x590]
10154229c:     	str	q0, [x9, #0x40]
1015422a0:     	ldur	q0, [x27, #0x4]
1015422a4:     	stur	q0, [x9, #0x4]
1015422a8:     	str	w8, [x9]
1015422ac:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015422b0:     	mov	w8, #0x1                ; =1
1015422b4:     	str	x8, [x23, #0x8]
1015422b8:     	mov	w8, #0x6                ; =6
1015422bc:     	mov	w9, #0x2                ; =2
1015422c0:     	str	x9, [x23, #0x10]
1015422c4:     	str	w8, [x23]
1015422c8:     	add	x0, sp, #0x440
1015422cc:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
1015422d0:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015422d4:     	ldp	q0, q1, [sp, #0x60]
1015422d8:     	str	q0, [sp, #0x440]
1015422dc:     	str	q1, [sp, #0x450]
1015422e0:     	ldp	q0, q1, [sp, #0x80]
1015422e4:     	str	q0, [sp, #0x460]
1015422e8:     	str	q1, [sp, #0x470]
1015422ec:     	ldr	x8, [sp, #0x58]
1015422f0:     	ldp	q0, q1, [x8, #0x80]
1015422f4:     	str	q0, [sp, #0x5d0]
1015422f8:     	str	q1, [sp, #0x5e0]
1015422fc:     	ldr	x9, [x8, #0xa0]
101542300:     	str	x9, [sp, #0x5f0]
101542304:     	ldp	q0, q1, [x8, #0x40]
101542308:     	str	q0, [sp, #0x590]
10154230c:     	str	q1, [sp, #0x5a0]
101542310:     	ldp	q1, q0, [x8, #0x60]
101542314:     	str	q0, [sp, #0x5c0]
101542318:     	str	q1, [sp, #0x5b0]
10154231c:     	ldp	q0, q1, [x8]
101542320:     	str	q0, [sp, #0x550]
101542324:     	str	q1, [sp, #0x560]
101542328:     	ldp	q1, q0, [x8, #0x20]
10154232c:     	str	q0, [sp, #0x580]
101542330:     	str	q1, [sp, #0x570]
101542334:     	ldr	x9, [x8, #0x490]
101542338:     	add	x8, sp, #0x110
10154233c:     	add	x1, sp, #0x440
101542340:     	add	x5, sp, #0x550
101542344:     	add	x6, x9, #0x3b8
101542348:     	add	x7, sp, #0xa0
10154234c:     	ldp	x0, x2, [sp, #0x30]
101542350:     	ldr	x3, [sp, #0x40]
101542354:     	mov	w4, #0x1                ; =1
101542358:     	bl	0x102531a24 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall31unsigned_matrix_replace_private>
10154235c:     	ldr	x9, [sp, #0x110]
101542360:     	add	x8, sp, #0x110
101542364:     	cbz	x9, 0x101542980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26ac>
101542368:     	add	x10, sp, #0x110
10154236c:     	ldur	q0, [x10, #0xc8]
101542370:     	stur	q0, [x25, #0xc8]
101542374:     	ldur	q0, [x10, #0xd8]
101542378:     	stur	q0, [x25, #0xd8]
10154237c:     	ldur	q0, [x10, #0xe8]
101542380:     	stur	q0, [x25, #0xe8]
101542384:     	ldur	q0, [x10, #0xf8]
101542388:     	stur	q0, [x25, #0xf8]
10154238c:     	ldur	q0, [x10, #0x88]
101542390:     	stur	q0, [x25, #0x88]
101542394:     	ldur	q0, [x10, #0x98]
101542398:     	stur	q0, [x25, #0x98]
10154239c:     	ldur	q0, [x10, #0xa8]
1015423a0:     	stur	q0, [x25, #0xa8]
1015423a4:     	ldur	q0, [x10, #0xb8]
1015423a8:     	stur	q0, [x25, #0xb8]
1015423ac:     	ldur	q0, [x10, #0x58]
1015423b0:     	stur	q0, [x25, #0x58]
1015423b4:     	ldur	q0, [x10, #0x68]
1015423b8:     	stur	q0, [x25, #0x68]
1015423bc:     	ldur	q0, [x10, #0x78]
1015423c0:     	stur	q0, [x25, #0x78]
1015423c4:     	ldur	q0, [x8, #0x18]
1015423c8:     	stur	q0, [x25, #0x18]
1015423cc:     	ldur	q0, [x8, #0x28]
1015423d0:     	stur	q0, [x25, #0x28]
1015423d4:     	ldur	q0, [x8, #0x38]
1015423d8:     	stur	q0, [x25, #0x38]
1015423dc:     	ldur	q0, [x8, #0x48]
1015423e0:     	stur	q0, [x25, #0x48]
1015423e4:     	ldur	q0, [x8, #0x8]
1015423e8:     	stur	q0, [x25, #0x8]
1015423ec:     	str	x9, [sp, #0x220]
1015423f0:     	ldr	x8, [sp, #0x58]
1015423f4:     	ldr	x9, [x8, #0x490]
1015423f8:     	add	x8, sp, #0x720
1015423fc:     	add	x0, x9, #0x3b8
101542400:     	bl	0x10236c914 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
101542404:     	ldr	x8, [x19, #0x5e8]
101542408:     	cmn	x8, #0x1, lsl #12       ; =0x1000
10154240c:     	b.hs	0x1015437ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34d8>
101542410:     	add	x24, x8, #0x1, lsl #12  ; =0x1000
101542414:     	lsr	x8, x24, #60
101542418:     	cbnz	x8, 0x1015437cc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34f8>
10154241c:     	ldr	x8, [sp, #0x58]
101542420:     	ldr	x8, [x8, #0x490]
101542424:     	lsl	x2, x24, #4
101542428:     	mov	w19, #0x1               ; =1
10154242c:     	add	x0, sp, #0x550
101542430:     	add	x1, x8, #0x2f8
101542434:     	bl	0x101529328 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101542438:     	ldrb	w8, [sp, #0x550]
10154243c:     	cmp	w8, #0xe
101542440:     	b.ne	0x1015429bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x26e8>
101542444:     	add	x8, sp, #0x550
101542448:     	add	x0, sp, #0x720
10154244c:     	mov	x1, x24
101542450:     	bl	0x102d509a4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101542454:     	ldr	w8, [sp, #0x550]
101542458:     	cmp	w8, #0x1a
10154245c:     	b.ne	0x101542aa4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x27d0>
101542460:     	ldur	q0, [x27, #0x18]
101542464:     	ldur	q1, [x27, #0x8]
101542468:     	stp	q1, q0, [x29, #-0x90]
10154246c:     	ldr	x1, [x23, x22]
101542470:     	ldr	x8, [sp, #0x28]
101542474:     	cmp	x1, x8
101542478:     	b.hs	0x101543fac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cd8>
10154247c:     	mov	w8, #0x18               ; =24
101542480:     	ldr	x9, [sp, #0x20]
101542484:     	madd	x8, x1, x8, x9
101542488:     	ldrb	w8, [x8, #0x12]
10154248c:     	tbz	w8, #0x0, 0x101542644 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2370>
101542490:     	ldr	x8, [sp, #0x58]
101542494:     	ldr	x8, [x8, #0x490]
101542498:     	ldr	x8, [x8, #0x3c0]
10154249c:     	cbz	x8, 0x101542b68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2894>
1015424a0:     	ldr	x9, [x8, #0x40]
1015424a4:     	cmp	x9, #0x2
1015424a8:     	b.eq	0x101542b68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2894>
1015424ac:     	ldr	x10, [x8, #0xd8]
1015424b0:     	ldr	x9, [sp, #0x48]
1015424b4:     	cmp	x10, x9
1015424b8:     	b.ne	0x101542b68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2894>
1015424bc:     	ldr	x9, [x8, #0x80]
1015424c0:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
1015424c4:     	cmp	x9, x10
1015424c8:     	b.eq	0x101542b68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2894>
1015424cc:     	ldr	x9, [x8, #0x90]
1015424d0:     	cmp	x1, x9
1015424d4:     	b.hs	0x101542b68 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2894>
1015424d8:     	ldr	x8, [x8, #0x88]
1015424dc:     	mov	w9, #0x70               ; =112
1015424e0:     	madd	x8, x1, x9, x8
1015424e4:     	ldr	x11, [x8]
1015424e8:     	ldr	d0, [x8, #0x8]
1015424ec:     	ldrb	w12, [x8, #0x10]
1015424f0:     	ldp	x9, x10, [x8, #0x18]
1015424f4:     	str	xzr, [x8]
1015424f8:     	cbz	x11, 0x101543528 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3254>
1015424fc:     	ldur	q1, [x8, #0x58]
101542500:     	stur	q1, [x26, #0x58]
101542504:     	ldr	x13, [x8, #0x68]
101542508:     	str	x13, [sp, #0x398]
10154250c:     	str	x11, [sp, #0x330]
101542510:     	str	d0, [sp, #0x338]
101542514:     	strb	w12, [sp, #0x340]
101542518:     	ldur	w11, [x8, #0x11]
10154251c:     	stur	w11, [x26, #0x11]
101542520:     	ldr	w11, [x8, #0x14]
101542524:     	str	w11, [sp, #0x344]
101542528:     	str	x9, [sp, #0x348]
10154252c:     	str	x10, [sp, #0x350]
101542530:     	ldur	q0, [x8, #0x28]
101542534:     	stur	q0, [x26, #0x28]
101542538:     	ldur	q0, [x8, #0x38]
10154253c:     	stur	q0, [x26, #0x38]
101542540:     	ldur	q0, [x8, #0x48]
101542544:     	stur	q0, [x26, #0x48]
101542548:     	add	x0, sp, #0x550
10154254c:     	add	x1, sp, #0x220
101542550:     	mov	w2, #0x108              ; =264
101542554:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101542558:     	mov	w19, #0x0               ; =0
10154255c:     	add	x24, sp, #0x440
101542560:     	add	x8, sp, #0x440
101542564:     	add	x0, sp, #0x550
101542568:     	add	x1, sp, #0x330
10154256c:     	bl	0x102e0e1a0 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix23with_append_preparation>
101542570:     	ldr	x8, [sp, #0x440]
101542574:     	cbz	x8, 0x101543630 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x335c>
101542578:     	add	x9, sp, #0x220
10154257c:     	ldr	w10, [sp, #0x448]
101542580:     	add	x11, sp, #0x440
101542584:     	ldur	q0, [x11, #0x1c]
101542588:     	ldur	q1, [x11, #0x2c]
10154258c:     	ldur	q2, [x11, #0x3c]
101542590:     	str	q1, [sp, #0x410]
101542594:     	str	q2, [sp, #0x420]
101542598:     	ldur	q1, [x11, #0x48]
10154259c:     	stur	q1, [x26, #0xfc]
1015425a0:     	ldur	q1, [x11, #0xc]
1015425a4:     	stp	q1, q0, [sp, #0x3f0]
1015425a8:     	ldur	q0, [x11, #0xc8]
1015425ac:     	stur	q0, [x9, #0xc8]
1015425b0:     	ldur	q0, [x11, #0xd8]
1015425b4:     	stur	q0, [x9, #0xd8]
1015425b8:     	ldur	q0, [x11, #0xe8]
1015425bc:     	stur	q0, [x9, #0xe8]
1015425c0:     	ldur	q0, [x11, #0xf8]
1015425c4:     	stur	q0, [x9, #0xf8]
1015425c8:     	ldur	q0, [x11, #0x88]
1015425cc:     	stur	q0, [x9, #0x88]
1015425d0:     	ldur	q0, [x11, #0x98]
1015425d4:     	stur	q0, [x9, #0x98]
1015425d8:     	ldur	q0, [x11, #0xa8]
1015425dc:     	stur	q0, [x9, #0xa8]
1015425e0:     	ldur	q0, [x11, #0xb8]
1015425e4:     	stur	q0, [x9, #0xb8]
1015425e8:     	ldur	q0, [x11, #0x58]
1015425ec:     	stur	q0, [x9, #0x58]
1015425f0:     	ldur	q0, [x11, #0x68]
1015425f4:     	stur	q0, [x9, #0x68]
1015425f8:     	ldur	q0, [x11, #0x78]
1015425fc:     	stur	q0, [x9, #0x78]
101542600:     	ldur	q0, [x26, #0xfc]
101542604:     	stur	q0, [x26, #0xac]
101542608:     	ldr	q0, [sp, #0x420]
10154260c:     	ldr	q1, [sp, #0x410]
101542610:     	stp	q1, q0, [sp, #0x3c0]
101542614:     	ldp	q2, q0, [sp, #0x3f0]
101542618:     	stp	q2, q0, [sp, #0x3a0]
10154261c:     	stur	q0, [x25, #0x1c]
101542620:     	stur	q1, [x25, #0x2c]
101542624:     	stur	q2, [x25, #0xc]
101542628:     	ldr	q0, [sp, #0x3d0]
10154262c:     	stur	q0, [x25, #0x3c]
101542630:     	ldur	q0, [x26, #0xac]
101542634:     	stur	q0, [x25, #0x48]
101542638:     	str	x8, [sp, #0x220]
10154263c:     	str	w10, [sp, #0x228]
101542640:     	ldr	x1, [x23, x22]
101542644:     	mov	w19, #0x1               ; =1
101542648:     	mov	x0, x20
10154264c:     	bl	0x101586ecc <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare16readonly_numericNtB2_5Proof8capacity>
101542650:     	cmp	x0, #0x1
101542654:     	b.ne	0x101542cfc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a28>
101542658:     	mov	x20, x1
10154265c:     	add	x8, sp, #0x550
101542660:     	add	x0, sp, #0x220
101542664:     	bl	0x102e0e088 <__RNvMs0_NtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix7appendsNtB7_21PrivateUnsignedMatrix20reserved_native_view>
101542668:     	ldr	w8, [sp, #0x550]
10154266c:     	tbz	w8, #0x0, 0x1015431c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2eec>
101542670:     	ldr	x8, [sp, #0x58]
101542674:     	ldr	x10, [x8, #0x4d8]
101542678:     	cbz	x10, 0x101543450 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x317c>
10154267c:     	ldr	x8, [x23, x22]
101542680:     	ldr	x9, [x21, #0xb0]
101542684:     	add	x8, x9, x8, lsl #2
101542688:     	add	x11, x8, #0x3
10154268c:     	ldr	x8, [sp, #0x58]
101542690:     	ldr	x8, [x8, #0x4e0]
101542694:     	cmp	x11, x8
101542698:     	b.hs	0x101543450 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x317c>
10154269c:     	ldr	x19, [sp, #0x558]
1015426a0:     	ldr	x9, [sp, #0x560]
1015426a4:     	ldr	x8, [sp, #0x568]
1015426a8:     	str	x9, [x10, x11, lsl #3]
1015426ac:     	ldr	x10, [sp, #0x58]
1015426b0:     	ldr	x10, [x10, #0x4d8]
1015426b4:     	cbz	x10, 0x101543384 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b0>
1015426b8:     	ldr	x11, [x23, x22]
1015426bc:     	ldr	x12, [x21, #0xb0]
1015426c0:     	add	x11, x12, x11, lsl #2
1015426c4:     	add	x11, x11, #0x4
1015426c8:     	ldr	x12, [sp, #0x58]
1015426cc:     	ldr	x12, [x12, #0x4e0]
1015426d0:     	cmp	x11, x12
1015426d4:     	b.hs	0x101543384 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b0>
1015426d8:     	mov	w12, #0x1               ; =1
1015426dc:     	str	x12, [x10, x11, lsl #3]
1015426e0:     	ldr	x10, [sp, #0x58]
1015426e4:     	ldr	x10, [x10, #0x4d8]
1015426e8:     	cbz	x10, 0x101543384 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b0>
1015426ec:     	ldr	x11, [x23, x22]
1015426f0:     	ldr	x12, [x21, #0xb0]
1015426f4:     	add	x11, x12, x11, lsl #2
1015426f8:     	add	x11, x11, #0x5
1015426fc:     	ldr	x12, [sp, #0x58]
101542700:     	ldr	x12, [x12, #0x4e0]
101542704:     	cmp	x11, x12
101542708:     	b.hs	0x101543384 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b0>
10154270c:     	str	x9, [x10, x11, lsl #3]
101542710:     	ldr	x9, [sp, #0x58]
101542714:     	ldr	x9, [x9, #0x4d8]
101542718:     	cbz	x9, 0x101543384 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b0>
10154271c:     	add	x10, x20, #0x2
101542720:     	ldr	x11, [sp, #0x58]
101542724:     	ldr	x11, [x11, #0x4e0]
101542728:     	cmp	x10, x11
10154272c:     	b.hs	0x101543384 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30b0>
101542730:     	str	x8, [x9, x10, lsl #3]
101542734:     	b	0x101542d0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2a38>
101542738:     	ldur	w15, [x9, #0x11]
10154273c:     	stur	w15, [x27, #0x9]
101542740:     	ldur	w15, [x9, #0x14]
101542744:     	str	w15, [sp, #0x55c]
101542748:     	str	w14, [sp, #0x550]
10154274c:     	str	w13, [sp, #0x554]
101542750:     	strb	w12, [sp, #0x558]
101542754:     	str	x11, [sp, #0x560]
101542758:     	str	x10, [sp, #0x568]
10154275c:     	ldur	q0, [x9, #0x28]
101542760:     	ldur	q1, [x9, #0x38]
101542764:     	str	q1, [sp, #0x580]
101542768:     	str	q0, [sp, #0x570]
10154276c:     	ldur	q0, [x9, #0x48]
101542770:     	ldur	q1, [x9, #0x58]
101542774:     	ldur	q2, [x9, #0x68]
101542778:     	ldur	q3, [x9, #0x78]
10154277c:     	ldur	q4, [x9, #0x88]
101542780:     	ldur	q5, [x9, #0x98]
101542784:     	ldur	q6, [x9, #0xa8]
101542788:     	ldur	q7, [x9, #0xb8]
10154278c:     	str	q7, [sp, #0x600]
101542790:     	str	q6, [sp, #0x5f0]
101542794:     	str	q5, [sp, #0x5e0]
101542798:     	str	q4, [sp, #0x5d0]
10154279c:     	str	q3, [sp, #0x5c0]
1015427a0:     	str	q2, [sp, #0x5b0]
1015427a4:     	str	q0, [sp, #0x590]
1015427a8:     	str	q1, [sp, #0x5a0]
1015427ac:     	ldr	x9, [x8, #0x48]
1015427b0:     	cmn	x9, #0x1
1015427b4:     	b.eq	0x10154380c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3538>
1015427b8:     	add	x9, x9, #0x1
1015427bc:     	str	x9, [x8, #0x48]
1015427c0:     	ldr	x8, [x8, #0x50]
1015427c4:     	cmp	x9, x8
1015427c8:     	b.ne	0x101542840 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x256c>
1015427cc:     	ldr	x8, [x22, #0x3d8]
1015427d0:     	cbz	x8, 0x101542840 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x256c>
1015427d4:     	ldr	x10, [x22, #0x3d0]
1015427d8:     	add	x11, x10, #0x1
1015427dc:     	ldr	x12, [x22, #0x3c0]
1015427e0:     	cmp	x11, x12
1015427e4:     	csel	x12, xzr, x12, lo
1015427e8:     	sub	x11, x11, x12
1015427ec:     	str	x11, [x22, #0x3d0]
1015427f0:     	sub	x8, x8, #0x1
1015427f4:     	str	x8, [x22, #0x3d8]
1015427f8:     	ldr	x8, [x22, #0x3c8]
1015427fc:     	mov	w9, #0x58               ; =88
101542800:     	madd	x8, x10, x9, x8
101542804:     	ldp	q1, q0, [x8]
101542808:     	str	q1, [sp, #0x440]
10154280c:     	str	q0, [sp, #0x450]
101542810:     	ldp	q1, q0, [x8, #0x30]
101542814:     	ldr	x9, [x8, #0x50]
101542818:     	ldr	q2, [x8, #0x20]
10154281c:     	str	x9, [sp, #0x490]
101542820:     	str	q0, [sp, #0x480]
101542824:     	str	q2, [sp, #0x460]
101542828:     	str	q1, [sp, #0x470]
10154282c:     	ldr	x8, [sp, #0x440]
101542830:     	cbz	x8, 0x101542840 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x256c>
101542834:     	mov	w24, #0x1               ; =1
101542838:     	add	x0, sp, #0x440
10154283c:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542840:     	ldr	w20, [sp, #0x608]
101542844:     	mov	x0, x19
101542848:     	mov	x1, x20
10154284c:     	bl	0x1015182c4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare8parallelNtB2_6Region8contains>
101542850:     	tbz	w0, #0x0, 0x101542a14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2740>
101542854:     	ldr	x1, [x23, #0x380]
101542858:     	cmp	x1, x20
10154285c:     	b.ls	0x101543f18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c44>
101542860:     	ldr	x8, [x23, #0x378]
101542864:     	mov	w9, #0x170              ; =368
101542868:     	umaddl	x8, w20, w9, x8
10154286c:     	add	x9, x8, #0x15c
101542870:     	ldr	w8, [x8, #0x16c]
101542874:     	str	w8, [sp, #0x450]
101542878:     	ldr	q0, [x9]
10154287c:     	str	q0, [sp, #0x440]
101542880:     	mov	w24, #0x1               ; =1
101542884:     	add	x8, sp, #0x220
101542888:     	add	x0, sp, #0x440
10154288c:     	bl	0x102a3387c <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact16fusion_semantics5factsNtB5_18NativeProgramFacts18control_successors>
101542890:     	ldr	w8, [x19, #0x48]
101542894:     	ldr	w9, [sp, #0x220]
101542898:     	cmp	w9, #0x1
10154289c:     	b.ne	0x1015428ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25d8>
1015428a0:     	ldr	w9, [sp, #0x224]
1015428a4:     	cmp	w9, w8
1015428a8:     	b.eq	0x1015428c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x25f0>
1015428ac:     	ldr	w9, [sp, #0x228]
1015428b0:     	cmp	w9, #0x1
1015428b4:     	b.ne	0x101542a14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2740>
1015428b8:     	ldr	w9, [sp, #0x22c]
1015428bc:     	cmp	w9, w8
1015428c0:     	b.ne	0x101542a14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2740>
1015428c4:     	ldr	x20, [sp, #0x550]
1015428c8:     	cmp	x20, #0x0
1015428cc:     	cset	w23, eq
1015428d0:     	cbz	x20, 0x101542b84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28b0>
1015428d4:     	ldr	q0, [sp, #0x550]
1015428d8:     	ldr	q1, [sp, #0x560]
1015428dc:     	str	q0, [sp, #0x440]
1015428e0:     	str	q1, [sp, #0x450]
1015428e4:     	ldr	q0, [sp, #0x570]
1015428e8:     	ldr	q1, [sp, #0x580]
1015428ec:     	str	q0, [sp, #0x460]
1015428f0:     	str	q1, [sp, #0x470]
1015428f4:     	ldr	x9, [x22, #0x490]
1015428f8:     	ldr	w1, [x19, #0x4c]
1015428fc:     	add	x8, sp, #0x220
101542900:     	add	x0, x9, #0xf0
101542904:     	add	x2, sp, #0x440
101542908:     	add	x3, x9, #0x2f8
10154290c:     	bl	0x101638a6c <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena3put>
101542910:     	ldrb	w8, [sp, #0x220]
101542914:     	cmp	w8, #0x14
101542918:     	b.ne	0x101542c04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2930>
10154291c:     	mov	w24, #0x0               ; =0
101542920:     	add	x0, sp, #0x440
101542924:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542928:     	b	0x101542b9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x28c8>
10154292c:     	ldur	w8, [x9, #0x11]
101542930:     	str	w8, [sp, #0xa0]
101542934:     	ldur	w8, [x9, #0x14]
101542938:     	stur	w8, [sp, #0xa3]
10154293c:     	ldur	q0, [x9, #0x28]
101542940:     	ldur	q1, [x9, #0x38]
101542944:     	stp	q0, q1, [sp, #0x110]
101542948:     	ldur	q0, [x9, #0x48]
10154294c:     	str	q0, [sp, #0x330]
101542950:     	stp	w14, w13, [x21]
101542954:     	strb	w12, [x21, #0x8]
101542958:     	mov	w8, w8
10154295c:     	str	w8, [x21, #0xc]
101542960:     	ldr	w8, [sp, #0xa0]
101542964:     	stur	w8, [x21, #0x9]
101542968:     	stp	x11, x10, [x21, #0x10]
10154296c:     	ldp	q1, q0, [sp, #0x110]
101542970:     	stp	q1, q0, [x21, #0x20]
101542974:     	ldr	q0, [sp, #0x330]
101542978:     	str	q0, [x21, #0x40]
10154297c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542980:     	ldr	x1, [x19, #0x378]
101542984:     	ldr	x2, [x19, #0x380]
101542988:     	add	x0, sp, #0x550
10154298c:     	add	x4, x8, #0x8
101542990:     	ldr	x3, [sp, #0x50]
101542994:     	bl	0x10152848c <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14numeric_writesNtB6_10Invocation21prepare_numeric_writes1_0Be_>
101542998:     	ldr	q0, [sp, #0x570]
10154299c:     	ldr	q1, [sp, #0x580]
1015429a0:     	stp	q0, q1, [x28, #0x20]
1015429a4:     	ldr	q0, [sp, #0x590]
1015429a8:     	str	q0, [x28, #0x40]
1015429ac:     	ldr	q0, [sp, #0x560]
1015429b0:     	ldr	q1, [sp, #0x550]
1015429b4:     	stp	q1, q0, [x28]
1015429b8:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015429bc:     	ldr	q0, [sp, #0x550]
1015429c0:     	ldr	q1, [sp, #0x560]
1015429c4:     	str	q0, [sp, #0x440]
1015429c8:     	str	q1, [sp, #0x450]
1015429cc:     	ldr	q2, [sp, #0x570]
1015429d0:     	str	q2, [sp, #0x460]
1015429d4:     	ldr	x8, [sp, #0x580]
1015429d8:     	str	x8, [sp, #0x470]
1015429dc:     	stur	q0, [x27, #0x4]
1015429e0:     	stur	q1, [x27, #0x14]
1015429e4:     	stur	q2, [x27, #0x24]
1015429e8:     	stur	x8, [x27, #0x34]
1015429ec:     	str	wzr, [x28]
1015429f0:     	ldr	q0, [sp, #0x550]
1015429f4:     	ldr	q1, [sp, #0x560]
1015429f8:     	stur	q0, [x28, #0x4]
1015429fc:     	stur	q1, [x28, #0x14]
101542a00:     	ldr	q0, [sp, #0x570]
101542a04:     	stur	q0, [x28, #0x24]
101542a08:     	ldur	q0, [x27, #0x2c]
101542a0c:     	str	q0, [x28, #0x30]
101542a10:     	b	0x101542ae0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x280c>
101542a14:     	str	wzr, [x21]
101542a18:     	mov	w9, #0xc                ; =12
101542a1c:     	strb	w9, [x21, #0x8]
101542a20:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101542a24:     	add	x8, x8, #0x8cb
101542a28:     	mov	w9, #0x2d               ; =45
101542a2c:     	stp	x8, x9, [x21, #0x10]
101542a30:     	ldr	x8, [sp, #0x550]
101542a34:     	cbz	x8, 0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542a38:     	add	x0, sp, #0x550
101542a3c:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542a40:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542a44:     	cmp	x22, #0x1
101542a48:     	b.gt	0x101542b04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2830>
101542a4c:     	cbz	x22, 0x101542c50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x297c>
101542a50:     	cmp	x22, #0x1
101542a54:     	b.ne	0x101542cc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29f0>
101542a58:     	ldr	x8, [sp, #0x58]
101542a5c:     	ldr	x8, [x8, #0x490]
101542a60:     	ldrb	w8, [x8, #0x460]
101542a64:     	tbz	w8, #0x0, 0x101542f20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c4c>
101542a68:     	str	wzr, [x19]
101542a6c:     	mov	w8, #0xc                ; =12
101542a70:     	strb	w8, [x19, #0x8]
101542a74:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101542a78:     	add	x8, x8, #0x531
101542a7c:     	mov	w9, #0x16               ; =22
101542a80:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101542a84:     	str	wzr, [x23]
101542a88:     	mov	w8, #0xc                ; =12
101542a8c:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101542a90:     	add	x9, x9, #0xbfd
101542a94:     	stp	x8, x9, [x23, #0x8]
101542a98:     	mov	w8, #0x1a               ; =26
101542a9c:     	str	x8, [x23, #0x18]
101542aa0:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542aa4:     	ldur	q0, [x27, #0x4]
101542aa8:     	ldur	q1, [x27, #0x14]
101542aac:     	str	q0, [sp, #0x440]
101542ab0:     	str	q1, [sp, #0x450]
101542ab4:     	ldr	w9, [sp, #0x574]
101542ab8:     	str	w9, [sp, #0x460]
101542abc:     	ldr	x10, [sp, #0x578]
101542ac0:     	stur	q0, [x28, #0x14]
101542ac4:     	stur	q1, [x28, #0x24]
101542ac8:     	str	w9, [x28, #0x34]
101542acc:     	str	wzr, [x28]
101542ad0:     	mov	w9, #0xd                ; =13
101542ad4:     	strb	w9, [x28, #0x8]
101542ad8:     	str	w8, [x28, #0x10]
101542adc:     	str	x10, [x28, #0x38]
101542ae0:     	ldr	x8, [sp, #0x720]
101542ae4:     	mov	x9, #-0x1               ; =-1
101542ae8:     	ldaddl	x9, x8, [x8]
101542aec:     	cmp	x8, #0x1
101542af0:     	b.ne	0x101543208 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f34>
101542af4:     	dmb	ishld
101542af8:     	add	x0, sp, #0x720
101542afc:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101542b00:     	b	0x101543208 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f34>
101542b04:     	cmp	x22, #0x2
101542b08:     	b.eq	0x101542c7c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29a8>
101542b0c:     	cmp	x22, #0x12
101542b10:     	b.ne	0x101542cc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x29f0>
101542b14:     	ldr	x8, [sp, #0x58]
101542b18:     	ldr	x8, [x8, #0x490]
101542b1c:     	ldrb	w8, [x8, #0x460]
101542b20:     	tbnz	w8, #0x0, 0x101542b38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2864>
101542b24:     	ldp	x8, x9, [x24]
101542b28:     	ldr	x10, [x24, #0x10]
101542b2c:     	orr	x8, x8, x9
101542b30:     	orr	x8, x8, x10
101542b34:     	cbz	x8, 0x101543298 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2fc4>
101542b38:     	str	wzr, [x19]
101542b3c:     	mov	w8, #0xc                ; =12
101542b40:     	strb	w8, [x19, #0x8]
101542b44:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101542b48:     	add	x8, x8, #0x5a7
101542b4c:     	mov	w9, #0x2d               ; =45
101542b50:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101542b54:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101542b58:     	add	x2, x2, #0x948
101542b5c:     	mov	x0, x9
101542b60:     	mov	x1, x10
101542b64:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101542b68:     	str	wzr, [x28]
101542b6c:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
101542b70:     	add	x8, x8, #0x807
101542b74:     	mov	w9, #0xc                ; =12
101542b78:     	stp	x9, x8, [x28, #0x8]
101542b7c:     	mov	w8, #0x30               ; =48
101542b80:     	b	0x1015431d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f04>
101542b84:     	ldr	x8, [x22, #0x4d8]
101542b88:     	cbz	x8, 0x101542ef8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c24>
101542b8c:     	ldr	x9, [x22, #0x4e0]
101542b90:     	cbz	x9, 0x101542ef8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2c24>
101542b94:     	ldr	x9, [sp, #0x558]
101542b98:     	str	x9, [x8]
101542b9c:     	ldr	w8, [sp, #0x608]
101542ba0:     	ldr	x10, [x22, #0x490]
101542ba4:     	mov	w11, #0x1               ; =1
101542ba8:     	str	w11, [x10, #0x2f0]
101542bac:     	str	w8, [x10, #0x2f4]
101542bb0:     	ldr	x8, [x22, #0x490]
101542bb4:     	strb	w11, [x8, #0x460]
101542bb8:     	ldr	x8, [x22, #0x3c0]
101542bbc:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
101542bc0:     	cmp	x8, x9
101542bc4:     	b.eq	0x101543234 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f60>
101542bc8:     	ldr	x8, [x22, #0x3d8]
101542bcc:     	cbnz	x8, 0x101543234 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f60>
101542bd0:     	ldr	x9, [x22, #0x3e8]
101542bd4:     	ldr	x8, [x22, #0x3f8]
101542bd8:     	cmp	x8, x9
101542bdc:     	b.eq	0x101543220 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f4c>
101542be0:     	str	wzr, [x21]
101542be4:     	mov	w8, #0xc                ; =12
101542be8:     	strb	w8, [x21, #0x8]
101542bec:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101542bf0:     	add	x8, x8, #0x8f8
101542bf4:     	mov	w9, #0x25               ; =37
101542bf8:     	stp	x8, x9, [x21, #0x10]
101542bfc:     	cbz	x20, 0x101542a30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x275c>
101542c00:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542c04:     	ldur	w9, [x25, #0x1]
101542c08:     	stur	w9, [x21, #0x9]
101542c0c:     	ldr	w9, [sp, #0x224]
101542c10:     	str	w9, [x21, #0xc]
101542c14:     	ldr	q0, [sp, #0x240]
101542c18:     	stur	q0, [x21, #0x28]
101542c1c:     	ldr	x9, [sp, #0x250]
101542c20:     	str	x9, [x21, #0x38]
101542c24:     	ldr	d0, [sp, #0x238]
101542c28:     	ldur	q1, [x25, #0x8]
101542c2c:     	mov	w9, #0x2                ; =2
101542c30:     	str	w9, [x21]
101542c34:     	strb	w8, [x21, #0x8]
101542c38:     	str	q1, [x21, #0x10]
101542c3c:     	str	d0, [x21, #0x20]
101542c40:     	mov	w24, #0x0               ; =0
101542c44:     	add	x0, sp, #0x440
101542c48:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101542c4c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542c50:     	ldr	x8, [sp, #0x58]
101542c54:     	ldr	x8, [x8, #0x490]
101542c58:     	ldrb	w8, [x8, #0x460]
101542c5c:     	tbz	w8, #0x0, 0x101543054 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d80>
101542c60:     	str	wzr, [x19]
101542c64:     	mov	w8, #0xc                ; =12
101542c68:     	strb	w8, [x19, #0x8]
101542c6c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101542c70:     	add	x8, x8, #0x58f
101542c74:     	mov	w9, #0x18               ; =24
101542c78:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101542c7c:     	ldr	x8, [sp, #0x58]
101542c80:     	ldr	x8, [x8, #0x490]
101542c84:     	ldrb	w8, [x8, #0x460]
101542c88:     	tbnz	w8, #0x0, 0x101543198 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ec4>
101542c8c:     	ldr	x8, [x24, #0x10]
101542c90:     	cbnz	x8, 0x101543198 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2ec4>
101542c94:     	ldp	x3, x4, [x24]
101542c98:     	mov	x0, x19
101542c9c:     	ldr	x1, [sp, #0x58]
101542ca0:     	mov	x2, x20
101542ca4:     	add	sp, sp, #0x810
101542ca8:     	ldp	x29, x30, [sp, #0x50]
101542cac:     	ldp	x20, x19, [sp, #0x40]
101542cb0:     	ldp	x22, x21, [sp, #0x30]
101542cb4:     	ldp	x24, x23, [sp, #0x20]
101542cb8:     	ldp	x26, x25, [sp, #0x10]
101542cbc:     	ldp	x28, x27, [sp], #0x60
101542cc0:     	b	0x10152f5f0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation17collection_helper>
101542cc4:     	ldr	x5, [x24]
101542cc8:     	mov	x0, x19
101542ccc:     	ldr	x1, [sp, #0x58]
101542cd0:     	mov	x2, x20
101542cd4:     	mov	x3, x22
101542cd8:     	mov	x4, x21
101542cdc:     	add	sp, sp, #0x810
101542ce0:     	ldp	x29, x30, [sp, #0x50]
101542ce4:     	ldp	x20, x19, [sp, #0x40]
101542ce8:     	ldp	x22, x21, [sp, #0x30]
101542cec:     	ldp	x24, x23, [sp, #0x20]
101542cf0:     	ldp	x26, x25, [sp, #0x10]
101542cf4:     	ldp	x28, x27, [sp], #0x60
101542cf8:     	b	0x10152f8e0 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation19typed_output_helper>
101542cfc:     	add	x8, sp, #0x550
101542d00:     	add	x0, sp, #0x220
101542d04:     	bl	0x102e0921c <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrixNtB2_21PrivateUnsignedMatrix12elements_mut>
101542d08:     	ldr	x19, [sp, #0x558]
101542d0c:     	add	x0, sp, #0x550
101542d10:     	add	x1, sp, #0x220
101542d14:     	mov	w2, #0x108              ; =264
101542d18:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101542d1c:     	ldr	x8, [sp, #0x58]
101542d20:     	ldr	x8, [x8, #0x490]
101542d24:     	ldr	x8, [x8, #0x3c0]
101542d28:     	cbz	x8, 0x101542e40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b6c>
101542d2c:     	ldr	x9, [x8, #0x40]
101542d30:     	cmp	x9, #0x2
101542d34:     	b.eq	0x101542e40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b6c>
101542d38:     	ldr	x10, [x8, #0xd8]
101542d3c:     	ldr	x9, [sp, #0x48]
101542d40:     	cmp	x10, x9
101542d44:     	b.ne	0x101542e40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b6c>
101542d48:     	ldr	x9, [x23, x22]
101542d4c:     	ldr	x10, [x8, #0x78]
101542d50:     	cmp	x9, x10
101542d54:     	b.hs	0x101542e40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2b6c>
101542d58:     	ldr	x8, [x8, #0x70]
101542d5c:     	mov	w10, #0x108             ; =264
101542d60:     	madd	x20, x9, x10, x8
101542d64:     	mov	x0, x20
101542d68:     	bl	0x101522dc8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
101542d6c:     	add	x1, sp, #0x550
101542d70:     	mov	x0, x20
101542d74:     	mov	w2, #0x108              ; =264
101542d78:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101542d7c:     	ldr	x8, [sp, #0x58]
101542d80:     	ldr	x8, [x8, #0x4d8]
101542d84:     	cbz	x8, 0x10154344c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3178>
101542d88:     	ldr	x9, [x23, x22]
101542d8c:     	ldr	x10, [x21, #0xb0]
101542d90:     	add	x9, x10, x9, lsl #2
101542d94:     	add	x9, x9, #0x2
101542d98:     	ldr	x10, [sp, #0x58]
101542d9c:     	ldr	x10, [x10, #0x4e0]
101542da0:     	cmp	x9, x10
101542da4:     	b.hs	0x10154344c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3178>
101542da8:     	str	x19, [x8, x9, lsl #3]
101542dac:     	ldr	x8, [sp, #0x58]
101542db0:     	ldr	x8, [x8, #0x4d8]
101542db4:     	cbz	x8, 0x10154344c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3178>
101542db8:     	ldr	x9, [x23, x22]
101542dbc:     	ldr	x10, [x21, #0x40]
101542dc0:     	ldr	x11, [x21, #0xb0]
101542dc4:     	add	x9, x9, x10, lsl #2
101542dc8:     	add	x9, x9, x11
101542dcc:     	add	x9, x9, #0x2
101542dd0:     	ldr	x10, [sp, #0x58]
101542dd4:     	ldr	x10, [x10, #0x4e0]
101542dd8:     	cmp	x9, x10
101542ddc:     	b.hs	0x10154344c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3178>
101542de0:     	mov	w10, #0x1               ; =1
101542de4:     	str	x10, [x8, x9, lsl #3]
101542de8:     	mov	w19, #0x0               ; =0
101542dec:     	add	x0, sp, #0x550
101542df0:     	ldp	x3, x1, [sp, #0x50]
101542df4:     	ldr	x2, [sp, #0x48]
101542df8:     	bl	0x101534550 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation4tailNtB4_10Invocation26resume_numeric_after_write>
101542dfc:     	ldr	w8, [sp, #0x550]
101542e00:     	cmp	w8, #0x6
101542e04:     	b.ne	0x101543784 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x34b0>
101542e08:     	str	xzr, [x28, #0x8]
101542e0c:     	str	w8, [x28]
101542e10:     	mov	w19, #0x0               ; =0
101542e14:     	sub	x0, x29, #0x90
101542e18:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101542e1c:     	ldr	x8, [sp, #0x720]
101542e20:     	mov	x9, #-0x1               ; =-1
101542e24:     	ldaddl	x9, x8, [x8]
101542e28:     	cmp	x8, #0x1
101542e2c:     	b.ne	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542e30:     	dmb	ishld
101542e34:     	add	x0, sp, #0x720
101542e38:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101542e3c:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101542e40:     	str	wzr, [x28]
101542e44:     	mov	w8, #0xc                ; =12
101542e48:     	adrp	x9, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
101542e4c:     	add	x9, x9, #0x5f0
101542e50:     	stp	x8, x9, [x28, #0x8]
101542e54:     	mov	w8, #0x2b               ; =43
101542e58:     	str	x8, [x28, #0x18]
101542e5c:     	mov	w19, #0x0               ; =0
101542e60:     	add	x0, sp, #0x550
101542e64:     	bl	0x101522dc8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixEECs7fdMCt8k5K6_8mech_gpu>
101542e68:     	mov	w19, #0x0               ; =0
101542e6c:     	b	0x1015431dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f08>
101542e70:     	add	x8, sp, #0x550
101542e74:     	add	x0, x24, #0x3b8
101542e78:     	bl	0x10236c914 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget13memory_budget>
101542e7c:     	ldr	x8, [sp, #0x58]
101542e80:     	ldr	x8, [x8, #0x20]
101542e84:     	cmp	x8, #0x1
101542e88:     	b.ne	0x101543214 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f40>
101542e8c:     	ldr	x8, [sp, #0x58]
101542e90:     	ldr	w8, [x8, #0x40]
101542e94:     	tbz	w8, #0x0, 0x101543344 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3070>
101542e98:     	ldr	x8, [sp, #0x58]
101542e9c:     	ldr	x1, [x8, #0x28]
101542ea0:     	ldr	x2, [x8, #0x48]
101542ea4:     	add	x8, sp, #0x668
101542ea8:     	add	x0, sp, #0x550
101542eac:     	bl	0x102d50838 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget11with_limits>
101542eb0:     	ldr	x8, [sp, #0x550]
101542eb4:     	mov	x9, #-0x1               ; =-1
101542eb8:     	ldaddl	x9, x8, [x8]
101542ebc:     	cmp	x8, #0x1
101542ec0:     	b.ne	0x101542ed0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2bfc>
101542ec4:     	dmb	ishld
101542ec8:     	add	x0, sp, #0x550
101542ecc:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101542ed0:     	ldr	x8, [sp, #0x660]
101542ed4:     	ldr	x9, [x8, #0x6c0]
101542ed8:     	cmp	x9, #0x100, lsl #12     ; =0x100000
101542edc:     	b.ls	0x1015433a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x30d4>
101542ee0:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
101542ee4:     	ldr	q0, [x8, #0xc00]
101542ee8:     	stur	q0, [x23, #0x8]
101542eec:     	mov	w8, #0x6                ; =6
101542ef0:     	str	w8, [x23]
101542ef4:     	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
101542ef8:     	str	wzr, [x21]
101542efc:     	mov	w9, #0xc                ; =12
101542f00:     	strb	w9, [x21, #0x8]
101542f04:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101542f08:     	add	x8, x8, #0x1fe
101542f0c:     	mov	w9, #0x29               ; =41
101542f10:     	b	0x101542a2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2758>
101542f14:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101542f18:     	add	x0, x0, #0x988
101542f1c:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101542f20:     	add	x0, sp, #0x550
101542f24:     	ldr	x1, [sp, #0x58]
101542f28:     	mov	x2, x20
101542f2c:     	bl	0x10153eae8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation10needs_move>
101542f30:     	ldr	w8, [sp, #0x550]
101542f34:     	tbz	w8, #0x0, 0x10154324c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f78>
101542f38:     	ldr	w21, [sp, #0x554]
101542f3c:     	ldr	w22, [sp, #0x558]
101542f40:     	add	x0, sp, #0x550
101542f44:     	ldr	x1, [sp, #0x58]
101542f48:     	mov	x2, x20
101542f4c:     	mov	w3, #0x1                ; =1
101542f50:     	mov	w4, #0x8                ; =8
101542f54:     	mov	x5, #0x0                ; =0
101542f58:     	bl	0x10152bb88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
101542f5c:     	ldr	w8, [sp, #0x550]
101542f60:     	cmp	w8, #0x6
101542f64:     	b.ne	0x1015432f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3024>
101542f68:     	ldr	x8, [sp, #0x558]
101542f6c:     	cmp	x8, #0x2
101542f70:     	b.ne	0x101542fc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2cf4>
101542f74:     	add	x0, sp, #0x550
101542f78:     	ldr	x1, [sp, #0x58]
101542f7c:     	mov	x2, x21
101542f80:     	mov	x3, x22
101542f84:     	bl	0x10154bf84 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joins6mappedNtB8_10Invocation15move_joined_map>
101542f88:     	ldr	w9, [sp, #0x550]
101542f8c:     	ldrb	w8, [sp, #0x554]
101542f90:     	cmp	w9, #0x6
101542f94:     	b.ne	0x1015434e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x320c>
101542f98:     	tbnz	w8, #0x0, 0x101543040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d6c>
101542f9c:     	ldr	x8, [sp, #0x58]
101542fa0:     	ldr	x9, [x8, #0x490]
101542fa4:     	add	x8, sp, #0x550
101542fa8:     	add	x0, x9, #0xf0
101542fac:     	add	x3, x9, #0x2f8
101542fb0:     	mov	x1, x21
101542fb4:     	mov	x2, x22
101542fb8:     	bl	0x1016378b4 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena15copy_current_to>
101542fbc:     	ldrb	w8, [sp, #0x550]
101542fc0:     	cmp	w8, #0x14
101542fc4:     	b.ne	0x101543744 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3470>
101542fc8:     	ldr	x1, [x23, #0x380]
101542fcc:     	cmp	x20, x1
101542fd0:     	b.hs	0x10154413c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e68>
101542fd4:     	ldr	x8, [x23, #0x378]
101542fd8:     	mov	w9, #0x170              ; =368
101542fdc:     	madd	x8, x20, x9, x8
101542fe0:     	ldp	x10, x9, [x8]
101542fe4:     	mov	w11, #0x11              ; =17
101542fe8:     	eor	x10, x10, x11
101542fec:     	orr	x9, x10, x9
101542ff0:     	cbnz	x9, 0x101543040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d6c>
101542ff4:     	ldr	x1, [x23, #0x390]
101542ff8:     	ldr	w2, [x8, #0x10]
101542ffc:     	cmp	x1, x2
101543000:     	b.ls	0x101544178 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ea4>
101543004:     	ldr	x8, [x23, #0x388]
101543008:     	mov	w9, #0x180              ; =384
10154300c:     	umaddl	x8, w2, w9, x8
101543010:     	ldp	x8, x9, [x8]
101543014:     	mov	w10, #0x5               ; =5
101543018:     	eor	x8, x8, x10
10154301c:     	orr	x8, x8, x9
101543020:     	cbnz	x8, 0x101543040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d6c>
101543024:     	add	x0, sp, #0x550
101543028:     	ldr	x1, [sp, #0x58]
10154302c:     	mov	w3, #0x1                ; =1
101543030:     	bl	0x10153f120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
101543034:     	ldr	w8, [sp, #0x550]
101543038:     	cmp	w8, #0x6
10154303c:     	b.ne	0x101543720 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x344c>
101543040:     	ldr	x8, [sp, #0x58]
101543044:     	ldr	x8, [x8, #0x490]
101543048:     	mov	w9, #0x1                ; =1
10154304c:     	strb	w9, [x8, #0x460]
101543050:     	b	0x1015417f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1524>
101543054:     	ldr	x1, [x23, #0x380]
101543058:     	cmp	x20, x1
10154305c:     	b.hs	0x101544028 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d54>
101543060:     	ldr	x8, [x23, #0x378]
101543064:     	mov	w9, #0x170              ; =368
101543068:     	madd	x25, x20, x9, x8
10154306c:     	ldp	x9, x8, [x25]
101543070:     	cmp	x9, #0x2
101543074:     	sbcs	xzr, x8, xzr
101543078:     	b.hs	0x101543268 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f94>
10154307c:     	ldr	x9, [x24]
101543080:     	ldr	x8, [sp, #0x58]
101543084:     	ldr	x21, [x8, #0x4d8]
101543088:     	cmp	x9, x21
10154308c:     	b.ne	0x10154332c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3058>
101543090:     	ldr	x22, [x24, #0x8]
101543094:     	ldr	x8, [x25, #0x128]
101543098:     	cmp	x22, x8
10154309c:     	b.ne	0x10154332c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3058>
1015430a0:     	ldr	x9, [x24, #0x10]
1015430a4:     	cbnz	x9, 0x10154332c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3058>
1015430a8:     	ldr	x9, [sp, #0x58]
1015430ac:     	ldr	x9, [x9, #0x4e0]
1015430b0:     	cmp	x8, x9
1015430b4:     	b.hi	0x10154332c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3058>
1015430b8:     	ldr	x23, [x25, #0x120]
1015430bc:     	add	x0, sp, #0x550
1015430c0:     	ldr	x1, [sp, #0x58]
1015430c4:     	mov	x2, x20
1015430c8:     	mov	x3, x21
1015430cc:     	mov	x4, x22
1015430d0:     	bl	0x10152d0a4 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation14selected_callsNtB4_10Invocation21prepared_library_call>
1015430d4:     	ldr	w8, [sp, #0x550]
1015430d8:     	cmp	w8, #0x6
1015430dc:     	b.ne	0x1015432f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3024>
1015430e0:     	ldr	x8, [sp, #0x558]
1015430e4:     	cmp	x8, #0x2
1015430e8:     	b.ne	0x101543430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x315c>
1015430ec:     	add	x0, sp, #0x550
1015430f0:     	ldr	x1, [sp, #0x58]
1015430f4:     	mov	x2, x20
1015430f8:     	mov	x3, x21
1015430fc:     	mov	x4, x22
101543100:     	bl	0x101538210 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime5lines10line_callsNtNtB6_10invocation10Invocation16line_matrix_call>
101543104:     	ldr	w8, [sp, #0x550]
101543108:     	cmp	w8, #0x6
10154310c:     	b.ne	0x1015432f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3024>
101543110:     	ldr	x8, [sp, #0x558]
101543114:     	cmp	x8, #0x2
101543118:     	b.ne	0x101543430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x315c>
10154311c:     	add	x0, sp, #0x550
101543120:     	ldr	x1, [sp, #0x58]
101543124:     	mov	x2, x20
101543128:     	mov	x3, x21
10154312c:     	mov	x4, x22
101543130:     	bl	0x10153c284 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime7session7capture14captured_callsNtNtB8_10invocation10Invocation26captured_line_element_call>
101543134:     	ldr	w9, [sp, #0x550]
101543138:     	ldrb	w8, [sp, #0x554]
10154313c:     	cmp	w9, #0x6
101543140:     	b.ne	0x1015434e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x320c>
101543144:     	tbnz	w8, #0x0, 0x101543040 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d6c>
101543148:     	add	x0, sp, #0x550
10154314c:     	ldr	x1, [sp, #0x58]
101543150:     	mov	x2, x20
101543154:     	mov	x3, x21
101543158:     	mov	x4, x22
10154315c:     	bl	0x101548b20 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation18selected_join_call>
101543160:     	ldr	w9, [sp, #0x550]
101543164:     	ldrb	w8, [sp, #0x554]
101543168:     	cmp	w9, #0x6
10154316c:     	b.ne	0x1015434e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x320c>
101543170:     	tbz	w8, #0x0, 0x10154390c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3638>
101543174:     	ldr	x8, [sp, #0x58]
101543178:     	ldr	x9, [x8, #0x490]
10154317c:     	mov	w10, #0x1               ; =1
101543180:     	strb	w10, [x9, #0x460]
101543184:     	ldr	x8, [x8, #0x290]
101543188:     	cmp	x8, #0x4
10154318c:     	cset	w8, eq
101543190:     	stp	x8, x10, [x19, #0x8]
101543194:     	b	0x1015417fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1528>
101543198:     	str	wzr, [x19]
10154319c:     	mov	w8, #0xc                ; =12
1015431a0:     	strb	w8, [x19, #0x8]
1015431a4:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015431a8:     	add	x8, x8, #0x516
1015431ac:     	mov	w9, #0x1b               ; =27
1015431b0:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
1015431b4:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015431b8:     	add	x0, x0, #0x940
1015431bc:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
1015431c0:     	str	wzr, [x28]
1015431c4:     	adrp	x8, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
1015431c8:     	add	x8, x8, #0xe59
1015431cc:     	mov	w9, #0xc                ; =12
1015431d0:     	stp	x9, x8, [x28, #0x8]
1015431d4:     	mov	w8, #0x28               ; =40
1015431d8:     	str	x8, [x28, #0x18]
1015431dc:     	sub	x0, x29, #0x90
1015431e0:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015431e4:     	ldr	x8, [sp, #0x720]
1015431e8:     	mov	x9, #-0x1               ; =-1
1015431ec:     	ldaddl	x9, x8, [x8]
1015431f0:     	cmp	x8, #0x1
1015431f4:     	b.ne	0x101543204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f30>
1015431f8:     	dmb	ishld
1015431fc:     	add	x0, sp, #0x720
101543200:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101543204:     	tbz	w19, #0x0, 0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543208:     	add	x0, sp, #0x220
10154320c:     	bl	0x10152577c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
101543210:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543214:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101543218:     	add	x8, x8, #0xc8a
10154321c:     	b	0x10154334c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3078>
101543220:     	add	x20, x22, #0x3c0
101543224:     	mov	x0, x20
101543228:     	bl	0x101522e40 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
10154322c:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101543230:     	str	x8, [x20]
101543234:     	mov	w8, #0x1                ; =1
101543238:     	dup.2d	v0, x8
10154323c:     	b	0x101540a88 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x7b4>
101543240:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543244:     	add	x0, x0, #0x9b8
101543248:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154324c:     	str	wzr, [x19]
101543250:     	mov	w8, #0xc                ; =12
101543254:     	str	w8, [x19, #0x8]
101543258:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
10154325c:     	add	x8, x8, #0xc55
101543260:     	mov	w9, #0x21               ; =33
101543264:     	b	0x101541338 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1064>
101543268:     	str	wzr, [x19]
10154326c:     	mov	w8, #0xc                ; =12
101543270:     	strb	w8, [x19, #0x8]
101543274:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101543278:     	add	x8, x8, #0x56b
10154327c:     	b	0x101541fa4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cd0>
101543280:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543284:     	add	x0, x0, #0x958
101543288:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
10154328c:     	adrp	x0, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543290:     	add	x0, x0, #0x970
101543294:     	bl	0x103a01f88 <__RNvNtCsgDHHaSskbIF_4core6option13unwrap_failed>
101543298:     	add	x0, sp, #0x550
10154329c:     	ldr	x1, [sp, #0x58]
1015432a0:     	mov	x2, x20
1015432a4:     	mov	w3, #0x12               ; =18
1015432a8:     	mov	w4, #0x8                ; =8
1015432ac:     	mov	x5, #0x0                ; =0
1015432b0:     	bl	0x10152bb88 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB4_10Invocation19buffer_frame_action>
1015432b4:     	ldr	w8, [sp, #0x550]
1015432b8:     	cmp	w8, #0x6
1015432bc:     	b.ne	0x1015432f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3024>
1015432c0:     	ldr	x8, [sp, #0x558]
1015432c4:     	cmp	x8, #0x2
1015432c8:     	b.ne	0x101543430 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x315c>
1015432cc:     	mov	x0, x19
1015432d0:     	ldr	x1, [sp, #0x58]
1015432d4:     	mov	x2, x20
1015432d8:     	add	sp, sp, #0x810
1015432dc:     	ldp	x29, x30, [sp, #0x50]
1015432e0:     	ldp	x20, x19, [sp, #0x40]
1015432e4:     	ldp	x22, x21, [sp, #0x30]
1015432e8:     	ldp	x24, x23, [sp, #0x20]
1015432ec:     	ldp	x26, x25, [sp, #0x10]
1015432f0:     	ldp	x28, x27, [sp], #0x60
1015432f4:     	b	0x101530380 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation32canonical_structural_observation>
1015432f8:     	ldr	w9, [sp, #0x554]
1015432fc:     	ldur	q0, [x27, #0x18]
101543300:     	stur	q0, [x19, #0x18]
101543304:     	ldur	q0, [x27, #0x28]
101543308:     	stur	q0, [x19, #0x28]
10154330c:     	ldur	q0, [x27, #0x38]
101543310:     	stur	q0, [x19, #0x38]
101543314:     	ldr	x10, [sp, #0x598]
101543318:     	str	x10, [x19, #0x48]
10154331c:     	ldur	q0, [x27, #0x8]
101543320:     	stp	w8, w9, [x19]
101543324:     	stur	q0, [x19, #0x8]
101543328:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
10154332c:     	str	wzr, [x19]
101543330:     	mov	w8, #0xc                ; =12
101543334:     	strb	w8, [x19, #0x8]
101543338:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10154333c:     	add	x8, x8, #0x547
101543340:     	b	0x101541fa4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1cd0>
101543344:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101543348:     	add	x8, x8, #0xca8
10154334c:     	str	wzr, [x23]
101543350:     	mov	w9, #0xc                ; =12
101543354:     	stp	x9, x8, [x23, #0x8]
101543358:     	mov	w8, #0x1e               ; =30
10154335c:     	str	x8, [x23, #0x18]
101543360:     	ldr	x8, [sp, #0x550]
101543364:     	mov	x9, #-0x1               ; =-1
101543368:     	ldaddl	x9, x8, [x8]
10154336c:     	cmp	x8, #0x1
101543370:     	b.ne	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543374:     	dmb	ishld
101543378:     	add	x0, sp, #0x550
10154337c:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101543380:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543384:     	str	wzr, [x28]
101543388:     	mov	w8, #0xc                ; =12
10154338c:     	strb	w8, [x28, #0x8]
101543390:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101543394:     	add	x8, x8, #0x1fe
101543398:     	mov	w9, #0x29               ; =41
10154339c:     	stp	x8, x9, [x28, #0x10]
1015433a0:     	mov	w19, #0x1               ; =1
1015433a4:     	b	0x1015431dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f08>
1015433a8:     	str	xzr, [sp, #0x38]
1015433ac:     	add	x24, sp, #0x720
1015433b0:     	ldp	x15, x9, [sp, #0x48]
1015433b4:     	lsl	x11, x9, #2
1015433b8:     	add	x9, x15, x11
1015433bc:     	str	x9, [sp, #0x28]
1015433c0:     	ldr	x12, [x8, #0x5a0]
1015433c4:     	ldr	x13, [x8, #0x598]
1015433c8:     	mov	w8, #0xc                ; =12
1015433cc:     	mov	w9, #0x29               ; =41
1015433d0:     	mov	w14, #0x58              ; =88
1015433d4:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015433d8:     	add	x10, x10, #0xcc6
1015433dc:     	ldr	x16, [sp, #0x38]
1015433e0:     	cbz	x11, 0x101543470 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x319c>
1015433e4:     	ldr	w17, [x15], #0x4
1015433e8:     	cmp	x12, x17
1015433ec:     	b.ls	0x101543420 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x314c>
1015433f0:     	umaddl	x17, w17, w14, x13
1015433f4:     	ldr	x17, [x17, #0x8]
1015433f8:     	sub	x11, x11, #0x4
1015433fc:     	ldr	x0, [sp, #0x38]
101543400:     	adds	x0, x17, x0
101543404:     	str	x0, [sp, #0x38]
101543408:     	b.lo	0x1015433dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3108>
10154340c:     	and	x8, x16, #0xffffffffffffff00
101543410:     	orr	x8, x8, #0xc
101543414:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101543418:     	add	x10, x10, #0xcef
10154341c:     	mov	w9, #0x1f               ; =31
101543420:     	str	wzr, [x23]
101543424:     	stp	x8, x10, [x23, #0x8]
101543428:     	str	x9, [x23, #0x18]
10154342c:     	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
101543430:     	ldur	q0, [x27, #0x8]
101543434:     	ldr	x8, [sp, #0x58]
101543438:     	ldr	x8, [x8, #0x490]
10154343c:     	mov	w9, #0x1                ; =1
101543440:     	strb	w9, [x8, #0x460]
101543444:     	stur	q0, [x19, #0x8]
101543448:     	b	0x1015417fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x1528>
10154344c:     	mov	w19, #0x0               ; =0
101543450:     	str	wzr, [x28]
101543454:     	mov	w8, #0xc                ; =12
101543458:     	strb	w8, [x28, #0x8]
10154345c:     	adrp	x8, 0x10754e000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x5f0>
101543460:     	add	x8, x8, #0x1fe
101543464:     	mov	w9, #0x29               ; =41
101543468:     	stp	x8, x9, [x28, #0x10]
10154346c:     	b	0x1015431dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f08>
101543470:     	mov	w8, #0x48               ; =72
101543474:     	mov	x9, #0x48               ; =72
101543478:     	madd	x8, x20, x8, x9
10154347c:     	ldr	x9, [sp, #0x38]
101543480:     	umulh	x9, x9, x8
101543484:     	cmp	xzr, x9
101543488:     	b.ne	0x101543c9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39c8>
10154348c:     	ldr	x9, [sp, #0x38]
101543490:     	mul	x8, x9, x8
101543494:     	mov	w9, #0x580              ; =1408
101543498:     	mov	x10, #0x400             ; =1024
10154349c:     	madd	x9, x20, x9, x10
1015434a0:     	adds	x8, x8, x9
1015434a4:     	str	x8, [sp, #0x30]
1015434a8:     	b.hs	0x101543cb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39dc>
1015434ac:     	mov	x8, #-0x201             ; =-513
1015434b0:     	movk	x8, #0x1fff, lsl #48
1015434b4:     	ldr	x9, [sp, #0x30]
1015434b8:     	cmp	x9, x8
1015434bc:     	b.ls	0x101543544 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3270>
1015434c0:     	str	wzr, [x23]
1015434c4:     	mov	w8, #0xc                ; =12
1015434c8:     	adrp	x9, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015434cc:     	add	x9, x9, #0xd28
1015434d0:     	stp	x8, x9, [x23, #0x8]
1015434d4:     	mov	w8, #0x17               ; =23
1015434d8:     	str	x8, [x23, #0x18]
1015434dc:     	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
1015434e0:     	ldur	q0, [x27, #0x15]
1015434e4:     	stur	q0, [x19, #0x15]
1015434e8:     	ldur	q0, [x27, #0x25]
1015434ec:     	stur	q0, [x19, #0x25]
1015434f0:     	ldur	q0, [x27, #0x35]
1015434f4:     	stur	q0, [x19, #0x35]
1015434f8:     	ldr	q0, [sp, #0x590]
1015434fc:     	str	q0, [x19, #0x40]
101543500:     	ldur	q0, [x27, #0x5]
101543504:     	stur	q0, [x19, #0x5]
101543508:     	str	w9, [x19]
10154350c:     	strb	w8, [x19, #0x4]
101543510:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543514:     	adrp	x3, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101543518:     	add	x3, x3, #0xb58
10154351c:     	mov	x0, #0x0                ; =0
101543520:     	bl	0x103a021d8 <__RNvNtNtCsgDHHaSskbIF_4core5slice5index16slice_index_fail>
101543524:     	b	0x1015444ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d8>
101543528:     	str	wzr, [x28]
10154352c:     	mov	w8, #0xc                ; =12
101543530:     	strb	w8, [x28, #0x8]
101543534:     	adrp	x8, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101543538:     	add	x8, x8, #0xe2d
10154353c:     	mov	w9, #0x2c               ; =44
101543540:     	b	0x101543468 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3194>
101543544:     	ldr	x8, [sp, #0x58]
101543548:     	ldr	x9, [x8, #0x490]
10154354c:     	ldr	x8, [sp, #0x30]
101543550:     	lsl	x8, x8, #3
101543554:     	add	x0, sp, #0x550
101543558:     	str	x9, [sp, #0x20]
10154355c:     	add	x1, x9, #0x2f8
101543560:     	add	x2, x8, #0x1, lsl #12   ; =0x1000
101543564:     	bl	0x101529328 <__RNvMNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact4workNtB2_15NativeWorkMeter6charge>
101543568:     	ldrb	w8, [sp, #0x550]
10154356c:     	cmp	w8, #0xe
101543570:     	b.ne	0x1015436c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x33f4>
101543574:     	add	x8, sp, #0x550
101543578:     	add	x0, sp, #0x668
10154357c:     	ldr	x1, [sp, #0x30]
101543580:     	bl	0x102d509a4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101543584:     	ldr	w8, [sp, #0x550]
101543588:     	cmp	w8, #0x1a
10154358c:     	b.ne	0x1015437ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3518>
101543590:     	ldur	q0, [x27, #0x8]
101543594:     	ldur	q1, [x27, #0x18]
101543598:     	str	q0, [sp, #0x680]
10154359c:     	str	q1, [sp, #0x690]
1015435a0:     	add	x8, sp, #0x550
1015435a4:     	mov	x0, x20
1015435a8:     	ldr	x1, [sp, #0x50]
1015435ac:     	ldr	x2, [sp, #0x38]
1015435b0:     	bl	0x1015d92b0 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel15scheduler_nodes>
1015435b4:     	ldr	w8, [sp, #0x550]
1015435b8:     	cmp	w8, #0x6
1015435bc:     	b.ne	0x101543828 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3554>
1015435c0:     	ldr	x1, [sp, #0x558]
1015435c4:     	add	x8, sp, #0x440
1015435c8:     	add	x0, sp, #0x668
1015435cc:     	bl	0x102d50878 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget13reserve_nodes>
1015435d0:     	ldr	w8, [sp, #0x440]
1015435d4:     	cmp	w8, #0x1a
1015435d8:     	b.ne	0x101543890 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35bc>
1015435dc:     	add	x8, sp, #0x440
1015435e0:     	ldur	q0, [x8, #0x8]
1015435e4:     	ldur	q1, [x8, #0x18]
1015435e8:     	str	q0, [sp, #0x6a0]
1015435ec:     	str	q1, [sp, #0x6b0]
1015435f0:     	ldr	x8, [sp, #0x50]
1015435f4:     	cbnz	x8, 0x101543958 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3684>
1015435f8:     	mov	w8, #0x8                ; =8
1015435fc:     	str	xzr, [sp, #0x6c0]
101543600:     	str	x8, [sp, #0x6c8]
101543604:     	str	xzr, [sp, #0x6d0]
101543608:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
10154360c:     	ldr	q0, [x8, #0xc00]
101543610:     	stur	q0, [x23, #0x8]
101543614:     	mov	w8, #0x6                ; =6
101543618:     	str	w8, [x23]
10154361c:     	add	x0, sp, #0x6c0
101543620:     	bl	0x101523b4c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
101543624:     	add	x0, sp, #0x6a0
101543628:     	bl	0x101524ab8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10154362c:     	b	0x1015438ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35d8>
101543630:     	mov	w19, #0x0               ; =0
101543634:     	ldur	q0, [x24, #0x8]
101543638:     	ldur	q1, [x24, #0x18]
10154363c:     	ldur	q2, [x24, #0x28]
101543640:     	ldur	q3, [x24, #0x38]
101543644:     	ldur	x8, [x24, #0x48]
101543648:     	stur	x8, [x27, #0x44]
10154364c:     	stur	q0, [x27, #0x4]
101543650:     	stur	q1, [x27, #0x14]
101543654:     	stur	q2, [x27, #0x24]
101543658:     	stur	q3, [x27, #0x34]
10154365c:     	ldr	q0, [sp, #0x570]
101543660:     	ldr	q1, [sp, #0x580]
101543664:     	str	q0, [sp, #0x410]
101543668:     	str	q1, [sp, #0x420]
10154366c:     	ldur	q0, [x27, #0x3c]
101543670:     	stur	q0, [x26, #0xfc]
101543674:     	ldr	q0, [sp, #0x560]
101543678:     	ldr	q1, [sp, #0x550]
10154367c:     	stp	q1, q0, [sp, #0x3f0]
101543680:     	ldp	q0, q1, [sp, #0x3f0]
101543684:     	ldur	q2, [x26, #0xfc]
101543688:     	stur	q2, [x26, #0xac]
10154368c:     	ldr	q2, [sp, #0x410]
101543690:     	ldr	q3, [sp, #0x420]
101543694:     	stp	q2, q3, [sp, #0x3c0]
101543698:     	stp	q0, q1, [sp, #0x3a0]
10154369c:     	ldp	q1, q0, [sp, #0x3a0]
1015436a0:     	stur	q0, [x28, #0x14]
1015436a4:     	ldp	q0, q2, [sp, #0x3c0]
1015436a8:     	stur	q0, [x28, #0x24]
1015436ac:     	stur	q2, [x28, #0x34]
1015436b0:     	ldur	q0, [x26, #0xac]
1015436b4:     	str	q0, [x28, #0x40]
1015436b8:     	stur	q1, [x28, #0x4]
1015436bc:     	mov	w8, #0x5                ; =5
1015436c0:     	str	w8, [x28]
1015436c4:     	b	0x1015431dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f08>
1015436c8:     	ldr	q0, [sp, #0x550]
1015436cc:     	ldr	q1, [sp, #0x560]
1015436d0:     	str	q0, [sp, #0x440]
1015436d4:     	str	q1, [sp, #0x450]
1015436d8:     	ldr	q2, [sp, #0x570]
1015436dc:     	str	q2, [sp, #0x460]
1015436e0:     	ldr	x8, [sp, #0x580]
1015436e4:     	str	x8, [sp, #0x470]
1015436e8:     	stur	q0, [x27, #0x4]
1015436ec:     	stur	q1, [x27, #0x14]
1015436f0:     	stur	q2, [x27, #0x24]
1015436f4:     	stur	x8, [x27, #0x34]
1015436f8:     	str	wzr, [x23]
1015436fc:     	ldr	q0, [sp, #0x550]
101543700:     	ldr	q1, [sp, #0x560]
101543704:     	stur	q0, [x23, #0x4]
101543708:     	stur	q1, [x23, #0x14]
10154370c:     	ldr	q0, [sp, #0x570]
101543710:     	stur	q0, [x23, #0x24]
101543714:     	ldur	q0, [x27, #0x2c]
101543718:     	str	q0, [x23, #0x30]
10154371c:     	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
101543720:     	ldr	q0, [sp, #0x570]
101543724:     	ldr	q1, [sp, #0x580]
101543728:     	stp	q0, q1, [x19, #0x20]
10154372c:     	ldr	q0, [sp, #0x590]
101543730:     	str	q0, [x19, #0x40]
101543734:     	ldr	q0, [sp, #0x560]
101543738:     	ldr	q1, [sp, #0x550]
10154373c:     	stp	q1, q0, [x19]
101543740:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543744:     	ldur	w9, [x27, #0x1]
101543748:     	stur	w9, [x19, #0x9]
10154374c:     	ldr	w9, [sp, #0x554]
101543750:     	str	w9, [x19, #0xc]
101543754:     	ldr	q0, [sp, #0x570]
101543758:     	stur	q0, [x19, #0x28]
10154375c:     	ldr	x9, [sp, #0x580]
101543760:     	str	x9, [x19, #0x38]
101543764:     	ldr	d0, [sp, #0x568]
101543768:     	ldur	q1, [x27, #0x8]
10154376c:     	mov	w9, #0x2                ; =2
101543770:     	str	w9, [x19]
101543774:     	strb	w8, [x19, #0x8]
101543778:     	str	q1, [x19, #0x10]
10154377c:     	str	d0, [x19, #0x20]
101543780:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
101543784:     	mov	w19, #0x0               ; =0
101543788:     	ldr	q0, [sp, #0x570]
10154378c:     	ldr	q1, [sp, #0x580]
101543790:     	stp	q0, q1, [x28, #0x20]
101543794:     	ldr	q0, [sp, #0x590]
101543798:     	str	q0, [x28, #0x40]
10154379c:     	ldr	q0, [sp, #0x560]
1015437a0:     	ldr	q1, [sp, #0x550]
1015437a4:     	stp	q1, q0, [x28]
1015437a8:     	b	0x1015431dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2f08>
1015437ac:     	str	wzr, [x28]
1015437b0:     	mov	w8, #0xc                ; =12
1015437b4:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
1015437b8:     	add	x9, x9, #0xddd
1015437bc:     	stp	x8, x9, [x28, #0x8]
1015437c0:     	mov	w8, #0x2a               ; =42
1015437c4:     	str	x8, [x28, #0x18]
1015437c8:     	b	0x101542ae0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x280c>
1015437cc:     	str	wzr, [x28]
1015437d0:     	mov	w8, #0xc                ; =12
1015437d4:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
1015437d8:     	add	x9, x9, #0xe07
1015437dc:     	stp	x8, x9, [x28, #0x8]
1015437e0:     	mov	w8, #0x26               ; =38
1015437e4:     	str	x8, [x28, #0x18]
1015437e8:     	b	0x101542ae0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x280c>
1015437ec:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
1015437f0:     	ldr	q0, [x8, #0xc00]
1015437f4:     	stur	q0, [x23, #0x8]
1015437f8:     	mov	w8, #0x6                ; =6
1015437fc:     	str	w8, [x23]
101543800:     	add	x0, sp, #0x550
101543804:     	bl	0x1015233cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
101543808:     	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
10154380c:     	str	wzr, [x21]
101543810:     	mov	w9, #0xc                ; =12
101543814:     	str	x9, [x21, #0x8]
101543818:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10154381c:     	add	x8, x8, #0x91d
101543820:     	mov	w9, #0x1e               ; =30
101543824:     	b	0x101542a2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2758>
101543828:     	ldr	w9, [sp, #0x554]
10154382c:     	ldr	x10, [sp, #0x558]
101543830:     	ldr	q0, [sp, #0x560]
101543834:     	ldr	q1, [sp, #0x570]
101543838:     	stp	q0, q1, [x23, #0x10]
10154383c:     	ldr	q0, [sp, #0x580]
101543840:     	ldr	q1, [sp, #0x590]
101543844:     	stp	q0, q1, [x23, #0x30]
101543848:     	stp	w8, w9, [x23]
10154384c:     	str	x10, [x23, #0x8]
101543850:     	b	0x1015438ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35d8>
101543854:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101543858:     	add	x2, x2, #0xb40
10154385c:     	mov	x0, x8
101543860:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543864:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543868:     	add	x2, x2, #0x9a0
10154386c:     	mov	x0, x19
101543870:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543874:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543878:     	add	x2, x2, #0x760
10154387c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543880:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543884:     	add	x2, x2, #0x808
101543888:     	mov	x0, x19
10154388c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543890:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
101543894:     	ldr	q0, [x8, #0xc00]
101543898:     	stur	q0, [x23, #0x8]
10154389c:     	mov	w8, #0x6                ; =6
1015438a0:     	str	w8, [x23]
1015438a4:     	add	x0, sp, #0x440
1015438a8:     	bl	0x1015232f4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
1015438ac:     	add	x0, sp, #0x680
1015438b0:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
1015438b4:     	ldr	x8, [sp, #0x668]
1015438b8:     	mov	x9, #-0x1               ; =-1
1015438bc:     	ldaddl	x9, x8, [x8]
1015438c0:     	cmp	x8, #0x1
1015438c4:     	b.ne	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015438c8:     	dmb	ishld
1015438cc:     	add	x0, sp, #0x668
1015438d0:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
1015438d4:     	b	0x1015405a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x2d4>
1015438d8:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
1015438dc:     	add	x2, x2, #0x960
1015438e0:     	ldr	x0, [sp, #0x50]
1015438e4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015438e8:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
1015438ec:     	add	x2, x2, #0x978
1015438f0:     	ldr	x0, [sp, #0x50]
1015438f4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015438f8:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015438fc:     	add	x2, x2, #0x820
101543900:     	mov	x0, x1
101543904:     	mov	x1, x8
101543908:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154390c:     	ldr	w5, [x25, #0x130]
101543910:     	mov	x0, x19
101543914:     	ldr	x1, [sp, #0x58]
101543918:     	mov	x2, x20
10154391c:     	mov	x3, x23
101543920:     	mov	x4, x22
101543924:     	mov	x6, x21
101543928:     	mov	x7, x22
10154392c:     	add	sp, sp, #0x810
101543930:     	ldp	x29, x30, [sp, #0x50]
101543934:     	ldp	x20, x19, [sp, #0x40]
101543938:     	ldp	x22, x21, [sp, #0x30]
10154393c:     	ldp	x24, x23, [sp, #0x20]
101543940:     	ldp	x26, x25, [sp, #0x10]
101543944:     	ldp	x28, x27, [sp], #0x60
101543948:     	b	0x10152fc68 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation16helper_fallbacksNtB4_10Invocation22canonical_library_call>
10154394c:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543950:     	add	x2, x2, #0x7d8
101543954:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543958:     	add	x0, sp, #0x550
10154395c:     	mov	x1, #0x0                ; =0
101543960:     	mov	w2, #0x8                ; =8
101543964:     	ldr	x3, [sp, #0x50]
101543968:     	mov	w4, #0x8                ; =8
10154396c:     	mov	w5, #0x68               ; =104
101543970:     	bl	0x1039dc58c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
101543974:     	ldr	w8, [sp, #0x550]
101543978:     	tbz	w8, #0x0, 0x1015439ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36d8>
10154397c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101543980:     	add	x8, x8, #0x746
101543984:     	mov	w9, #0xc                ; =12
101543988:     	stp	x9, x8, [x23, #0x8]
10154398c:     	mov	w8, #0x1a               ; =26
101543990:     	str	x8, [x23, #0x18]
101543994:     	str	wzr, [x23]
101543998:     	b	0x101543624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3350>
10154399c:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
1015439a0:     	add	x2, x2, #0x990
1015439a4:     	ldr	x1, [sp, #0x28]
1015439a8:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015439ac:     	str	xzr, [sp]
1015439b0:     	str	xzr, [sp, #0x18]
1015439b4:     	ldr	x8, [sp, #0x558]
1015439b8:     	ldr	x9, [sp, #0x50]
1015439bc:     	str	x9, [sp, #0x6c0]
1015439c0:     	str	x8, [sp, #0x6c8]
1015439c4:     	str	xzr, [sp, #0x6d0]
1015439c8:     	ldr	x8, [sp, #0x48]
1015439cc:     	ldr	w9, [x8], #0x4
1015439d0:     	str	x8, [sp, #0x48]
1015439d4:     	ldr	x8, [sp, #0x660]
1015439d8:     	ldr	x1, [x8, #0x5a0]
1015439dc:     	str	x9, [sp, #0x38]
1015439e0:     	cmp	x1, x9
1015439e4:     	b.ls	0x101544478 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41a4>
1015439e8:     	ldr	x8, [x8, #0x598]
1015439ec:     	mov	w9, #0x58               ; =88
1015439f0:     	ldr	x10, [sp, #0x38]
1015439f4:     	umaddl	x8, w10, w9, x8
1015439f8:     	str	x8, [sp, #0x30]
1015439fc:     	ldr	w1, [x8, #0x50]
101543a00:     	add	x8, sp, #0x550
101543a04:     	ldr	x9, [sp, #0x20]
101543a08:     	add	x0, x9, #0xf0
101543a0c:     	add	x2, x9, #0x2f8
101543a10:     	bl	0x1016370b0 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101543a14:     	ldr	x8, [sp, #0x550]
101543a18:     	add	x9, sp, #0x550
101543a1c:     	ldur	q0, [x9, #0x8]
101543a20:     	ldur	q1, [x9, #0x18]
101543a24:     	stp	q0, q1, [sp, #0x3f0]
101543a28:     	ldur	q0, [x9, #0x28]
101543a2c:     	str	q0, [sp, #0x410]
101543a30:     	ldur	x9, [x9, #0x38]
101543a34:     	str	x9, [sp, #0x420]
101543a38:     	cbz	x8, 0x101543cd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39fc>
101543a3c:     	ldr	x9, [sp, #0x420]
101543a40:     	add	x10, sp, #0x220
101543a44:     	stur	x9, [x10, #0x38]
101543a48:     	ldr	q0, [sp, #0x410]
101543a4c:     	stur	q0, [x10, #0x28]
101543a50:     	ldp	q1, q0, [sp, #0x3f0]
101543a54:     	stur	q0, [x10, #0x18]
101543a58:     	stur	q1, [x10, #0x8]
101543a5c:     	str	x8, [sp, #0x220]
101543a60:     	ldr	x8, [sp, #0x228]
101543a64:     	ldr	x8, [x8, #0x10]
101543a68:     	ldrb	w8, [x8, #0x10]
101543a6c:     	orr	w8, w8, #0x2
101543a70:     	cmp	w8, #0x1b
101543a74:     	b.ne	0x101543f84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cb0>
101543a78:     	add	x8, sp, #0x550
101543a7c:     	add	x0, sp, #0x220
101543a80:     	bl	0x1015a4510 <__RNvNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections12source_count>
101543a84:     	ldr	w8, [sp, #0x550]
101543a88:     	cmp	w8, #0x6
101543a8c:     	b.ne	0x101543d18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a44>
101543a90:     	ldr	x8, [sp, #0x558]
101543a94:     	str	x8, [sp, #0x50]
101543a98:     	ldr	x8, [sp, #0x38]
101543a9c:     	cmp	x19, x8
101543aa0:     	b.ne	0x101543ab0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x37dc>
101543aa4:     	ldr	x8, [sp, #0x50]
101543aa8:     	cmp	x8, x28
101543aac:     	b.ne	0x101543d44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a70>
101543ab0:     	ldr	x8, [sp, #0x18]
101543ab4:     	ldr	x9, [sp, #0x50]
101543ab8:     	adds	x8, x9, x8
101543abc:     	str	x8, [sp, #0x18]
101543ac0:     	b.hs	0x1015440d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e04>
101543ac4:     	ldr	x8, [sp, #0x50]
101543ac8:     	cbz	x8, 0x101543d60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8c>
101543acc:     	ldr	x8, [sp, #0x18]
101543ad0:     	cmp	x8, x20
101543ad4:     	b.hi	0x101543d60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3a8c>
101543ad8:     	ldr	x8, [sp, #0x30]
101543adc:     	ldr	x8, [x8, #0x8]
101543ae0:     	str	x8, [sp, #0x8]
101543ae4:     	cbnz	x8, 0x101543b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3884>
101543ae8:     	str	xzr, [sp]
101543aec:     	ldr	x9, [sp, #0x8]
101543af0:     	mov	w8, #0x8                ; =8
101543af4:     	stp	x9, x8, [sp, #0x110]
101543af8:     	str	xzr, [sp, #0x120]
101543afc:     	ldp	q0, q1, [sp, #0x220]
101543b00:     	add	x8, sp, #0x550
101543b04:     	stur	q0, [x8, #0x18]
101543b08:     	stur	q1, [x8, #0x28]
101543b0c:     	ldp	q0, q1, [sp, #0x240]
101543b10:     	stur	q0, [x8, #0x38]
101543b14:     	stur	q1, [x8, #0x48]
101543b18:     	ldr	q0, [sp, #0x110]
101543b1c:     	str	q0, [sp, #0x550]
101543b20:     	ldr	x8, [sp, #0x120]
101543b24:     	str	x8, [sp, #0x560]
101543b28:     	ldr	x8, [sp, #0x38]
101543b2c:     	str	x8, [sp, #0x5a8]
101543b30:     	ldr	x8, [sp, #0x50]
101543b34:     	str	x8, [sp, #0x5b0]
101543b38:     	add	x0, sp, #0x6c0
101543b3c:     	add	x1, sp, #0x550
101543b40:     	bl	0x101547c28 <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionE8push_mutBR_>
101543b44:     	ldr	x8, [sp, #0x48]
101543b48:     	ldr	x9, [sp, #0x28]
101543b4c:     	cmp	x8, x9
101543b50:     	b.ne	0x1015439c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x36f4>
101543b54:     	b	0x101543d78 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3aa4>
101543b58:     	ldr	x8, [sp, #0x30]
101543b5c:     	ldr	x8, [x8]
101543b60:     	str	x8, [sp, #0x10]
101543b64:     	add	x0, sp, #0x550
101543b68:     	mov	x1, #0x0                ; =0
101543b6c:     	mov	w2, #0x8                ; =8
101543b70:     	ldr	x3, [sp, #0x8]
101543b74:     	mov	w4, #0x8                ; =8
101543b78:     	mov	w5, #0x48               ; =72
101543b7c:     	bl	0x1039dc58c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
101543b80:     	ldr	x8, [sp, #0x550]
101543b84:     	cmp	x8, #0x1
101543b88:     	b.eq	0x101544038 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d64>
101543b8c:     	ldr	x8, [sp, #0x558]
101543b90:     	ldr	x10, [sp, #0x8]
101543b94:     	and	x9, x10, #0x7fffffffffffff00
101543b98:     	stp	x10, x8, [sp, #0x110]
101543b9c:     	str	xzr, [sp, #0x120]
101543ba0:     	lsl	x8, x10, #2
101543ba4:     	stp	x9, x8, [sp]
101543ba8:     	b	0x101543be0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x390c>
101543bac:     	ldr	x8, [x21, #0x28]
101543bb0:     	ldr	x9, [sp, #0x30]
101543bb4:     	ldr	x8, [x8, x9, lsl #3]
101543bb8:     	str	x8, [sp, #0x558]
101543bbc:     	str	w9, [sp, #0x554]
101543bc0:     	str	wzr, [sp, #0x550]
101543bc4:     	add	x0, sp, #0x110
101543bc8:     	add	x1, sp, #0x550
101543bcc:     	bl	0x101547cbc <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
101543bd0:     	ldr	x8, [sp, #0x8]
101543bd4:     	subs	x8, x8, #0x4
101543bd8:     	str	x8, [sp, #0x8]
101543bdc:     	b.eq	0x101543afc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3828>
101543be0:     	ldr	x8, [sp, #0x10]
101543be4:     	ldr	w9, [x8], #0x4
101543be8:     	str	x8, [sp, #0x10]
101543bec:     	ldr	x8, [sp, #0x660]
101543bf0:     	ldr	x1, [x8, #0x360]
101543bf4:     	str	x9, [sp, #0x30]
101543bf8:     	cmp	x1, x9
101543bfc:     	b.ls	0x10154448c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41b8>
101543c00:     	ldr	x8, [x8, #0x358]
101543c04:     	mov	w9, #0x140              ; =320
101543c08:     	ldr	x10, [sp, #0x30]
101543c0c:     	umaddl	x8, w10, w9, x8
101543c10:     	ldrb	w8, [x8, #0x124]
101543c14:     	cmp	w8, #0x7
101543c18:     	b.ne	0x101543bac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38d8>
101543c1c:     	add	x8, sp, #0x440
101543c20:     	ldr	x9, [sp, #0x20]
101543c24:     	add	x0, x9, #0xf0
101543c28:     	add	x2, x9, #0x2f8
101543c2c:     	ldr	x1, [sp, #0x30]
101543c30:     	bl	0x1016370b0 <__RNvMs1_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact6valuesNtB5_16NativeValueArena12copy_current>
101543c34:     	ldr	x8, [sp, #0x440]
101543c38:     	add	x9, sp, #0x440
101543c3c:     	ldur	q0, [x9, #0x8]
101543c40:     	ldur	q1, [x9, #0x18]
101543c44:     	stp	q0, q1, [sp, #0xa0]
101543c48:     	ldur	q0, [x9, #0x28]
101543c4c:     	str	q0, [sp, #0xc0]
101543c50:     	ldur	x9, [x9, #0x38]
101543c54:     	str	x9, [sp, #0xd0]
101543c58:     	cbz	x8, 0x101543f30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3c5c>
101543c5c:     	ldp	q0, q1, [sp, #0xa0]
101543c60:     	add	x10, sp, #0x550
101543c64:     	stp	q0, q1, [x10, #0x10]
101543c68:     	ldr	q0, [sp, #0xc0]
101543c6c:     	stur	q0, [x10, #0x30]
101543c70:     	ldr	x9, [sp, #0xd0]
101543c74:     	stur	x9, [x10, #0x40]
101543c78:     	str	x8, [sp, #0x558]
101543c7c:     	ldr	x8, [sp, #0x30]
101543c80:     	str	w8, [sp, #0x554]
101543c84:     	mov	w8, #0x1                ; =1
101543c88:     	str	w8, [sp, #0x550]
101543c8c:     	add	x0, sp, #0x110
101543c90:     	add	x1, sp, #0x550
101543c94:     	bl	0x101547cbc <__RNvMsF_NtCsgKscDXrlV49_5alloc3vecINtB5_3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureE8push_mutBR_>
101543c98:     	b	0x101543bd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x38fc>
101543c9c:     	str	wzr, [x23]
101543ca0:     	mov	w8, #0xc                ; =12
101543ca4:     	adrp	x9, 0x10754b000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.34+0x2>
101543ca8:     	add	x9, x9, #0xbfd
101543cac:     	b	0x101543cc0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x39ec>
101543cb0:     	str	wzr, [x23]
101543cb4:     	mov	w8, #0xc                ; =12
101543cb8:     	adrp	x9, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101543cbc:     	add	x9, x9, #0xd0e
101543cc0:     	stp	x8, x9, [x23, #0x8]
101543cc4:     	mov	w8, #0x1a               ; =26
101543cc8:     	str	x8, [x23, #0x18]
101543ccc:     	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
101543cd0:     	ldp	q0, q1, [sp, #0x3f0]
101543cd4:     	stur	q0, [x27, #0x4]
101543cd8:     	stur	q1, [x27, #0x14]
101543cdc:     	ldr	q0, [sp, #0x410]
101543ce0:     	stur	q0, [x27, #0x24]
101543ce4:     	ldr	x8, [sp, #0x420]
101543ce8:     	stur	x8, [x27, #0x34]
101543cec:     	ldr	q0, [sp, #0x550]
101543cf0:     	ldr	q1, [sp, #0x560]
101543cf4:     	stur	q0, [x23, #0x4]
101543cf8:     	mov	w8, #0x2                ; =2
101543cfc:     	str	w8, [x23]
101543d00:     	stur	q1, [x23, #0x14]
101543d04:     	ldr	q0, [sp, #0x570]
101543d08:     	stur	q0, [x23, #0x24]
101543d0c:     	ldur	q0, [x27, #0x2c]
101543d10:     	str	q0, [x23, #0x30]
101543d14:     	b	0x10154361c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3348>
101543d18:     	ldr	w9, [sp, #0x554]
101543d1c:     	ldr	x10, [sp, #0x558]
101543d20:     	ldr	q0, [sp, #0x560]
101543d24:     	ldr	q1, [sp, #0x570]
101543d28:     	stp	q0, q1, [x23, #0x10]
101543d2c:     	ldr	q0, [sp, #0x580]
101543d30:     	ldr	q1, [sp, #0x590]
101543d34:     	stp	q0, q1, [x23, #0x30]
101543d38:     	stp	w8, w9, [x23]
101543d3c:     	str	x10, [x23, #0x8]
101543d40:     	b	0x101543fa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ccc>
101543d44:     	str	wzr, [x23]
101543d48:     	mov	w8, #0xc                ; =12
101543d4c:     	strb	w8, [x23, #0x8]
101543d50:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101543d54:     	add	x8, x8, #0x77b
101543d58:     	mov	w9, #0x24               ; =36
101543d5c:     	b	0x101543f9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cc8>
101543d60:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
101543d64:     	ldr	q0, [x8, #0xc00]
101543d68:     	stur	q0, [x23, #0x8]
101543d6c:     	mov	w8, #0x6                ; =6
101543d70:     	str	w8, [x23]
101543d74:     	b	0x101543fa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ccc>
101543d78:     	ldr	x8, [sp, #0x18]
101543d7c:     	cmp	x8, #0x2
101543d80:     	b.lo	0x101543608 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3334>
101543d84:     	ldr	x8, [sp, #0x18]
101543d88:     	str	x8, [sp, #0x6d8]
101543d8c:     	add	x8, x8, x8, lsl #5
101543d90:     	lsl	x1, x8, #16
101543d94:     	add	x8, sp, #0x550
101543d98:     	add	x0, sp, #0x668
101543d9c:     	bl	0x102d509a4 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
101543da0:     	ldr	w8, [sp, #0x550]
101543da4:     	cmp	w8, #0x1a
101543da8:     	b.ne	0x101543fc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3cf0>
101543dac:     	ldur	q0, [x27, #0x8]
101543db0:     	ldur	q1, [x27, #0x18]
101543db4:     	str	q0, [sp, #0x6e0]
101543db8:     	str	q1, [sp, #0x6f0]
101543dbc:     	ldr	x20, [sp, #0x6d0]
101543dc0:     	cbnz	x20, 0x1015440f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e24>
101543dc4:     	mov	x8, #0x0                ; =0
101543dc8:     	mov	w9, #0x8                ; =8
101543dcc:     	str	x20, [sp, #0x708]
101543dd0:     	str	x9, [sp, #0x710]
101543dd4:     	str	xzr, [sp, #0x718]
101543dd8:     	ldr	x1, [sp, #0x6c8]
101543ddc:     	mov	w9, #0x68               ; =104
101543de0:     	madd	x2, x8, x9, x1
101543de4:     	mov	w19, #0x1               ; =1
101543de8:     	add	x0, sp, #0x708
101543dec:     	mov	w28, #0x1               ; =1
101543df0:     	bl	0x101498ab4 <__RINvMsj_NtCsgKscDXrlV49_5alloc3vecINtB6_3VecjE14extend_trustedINtNtNtNtCsgDHHaSskbIF_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENCNvMs0_B2f_NtB2h_10Invocation12run_parallels9_0EEB2p_>
101543df4:     	ldr	x2, [sp, #0x710]
101543df8:     	ldr	x3, [sp, #0x718]
101543dfc:     	add	x0, sp, #0x550
101543e00:     	ldr	x1, [sp, #0x58]
101543e04:     	bl	0x101539cf0 <__RNvMNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel9admissionNtB6_10Invocation18parallel_admission>
101543e08:     	ldr	w8, [sp, #0x550]
101543e0c:     	cmp	w8, #0x6
101543e10:     	b.ne	0x101543fe4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d10>
101543e14:     	ldr	x8, [sp, #0x558]
101543e18:     	ldr	q0, [sp, #0x560]
101543e1c:     	str	q0, [sp, #0x740]
101543e20:     	ldr	x9, [sp, #0x570]
101543e24:     	str	x9, [sp, #0x750]
101543e28:     	cbz	x8, 0x10154405c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d88>
101543e2c:     	ldr	q0, [sp, #0x740]
101543e30:     	stur	q0, [x24, #0x8]
101543e34:     	ldr	x9, [sp, #0x750]
101543e38:     	str	x8, [sp, #0x720]
101543e3c:     	str	x9, [sp, #0x738]
101543e40:     	ldr	x0, [sp, #0x660]
101543e44:     	add	x8, sp, #0x550
101543e48:     	add	x1, sp, #0x668
101543e4c:     	ldr	x2, [sp, #0x18]
101543e50:     	bl	0x1015d9390 <__RNvNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel17worker_setup_fits>
101543e54:     	ldr	w9, [sp, #0x550]
101543e58:     	ldrb	w8, [sp, #0x554]
101543e5c:     	cmp	w9, #0x6
101543e60:     	b.ne	0x10154408c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3db8>
101543e64:     	tbz	w8, #0x0, 0x1015440c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3dec>
101543e68:     	ldr	x8, [sp, #0x660]
101543e6c:     	ldr	x1, [x8, #0x3a0]
101543e70:     	ldr	w0, [x22, #0x30]
101543e74:     	cmp	x1, x0
101543e78:     	b.ls	0x1015444a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41cc>
101543e7c:     	ldr	x8, [x8, #0x398]
101543e80:     	mov	w9, #0x540              ; =1344
101543e84:     	umaddl	x8, w0, w9, x8
101543e88:     	ldr	w9, [x8, #0x520]
101543e8c:     	ldr	q0, [x8, #0x510]
101543e90:     	stur	q0, [x29, #-0x100]
101543e94:     	stur	w9, [x29, #-0xf0]
101543e98:     	add	x8, sp, #0x550
101543e9c:     	ldr	x9, [sp, #0x20]
101543ea0:     	add	x0, x9, #0x3b8
101543ea4:     	bl	0x10236ca38 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101543ea8:     	ldr	x8, [sp, #0x550]
101543eac:     	cmp	x8, #0x1
101543eb0:     	b.ne	0x10154414c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e78>
101543eb4:     	ldr	x1, [sp, #0x558]
101543eb8:     	ldr	x2, [sp, #0x560]
101543ebc:     	add	x19, sp, #0x550
101543ec0:     	add	x8, sp, #0x550
101543ec4:     	ldr	x9, [sp, #0x20]
101543ec8:     	add	x0, x9, #0x3b8
101543ecc:     	add	x3, sp, #0x668
101543ed0:     	bl	0x10236ea9c <__RNvMs3_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB7_23NativeLibraryWorkBudget32reserve_worker_group_with_memory>
101543ed4:     	ldrb	w8, [sp, #0x588]
101543ed8:     	cmp	w8, #0x2
101543edc:     	b.ne	0x10154418c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3eb8>
101543ee0:     	ldr	w8, [sp, #0x550]
101543ee4:     	cmp	w8, #0x1a
101543ee8:     	b.ne	0x10154433c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4068>
101543eec:     	ldur	w9, [x29, #-0x100]
101543ef0:     	ldurb	w8, [x29, #-0xfc]
101543ef4:     	add	x12, sp, #0x720
101543ef8:     	ldur	w10, [x12, #0x45]
101543efc:     	str	w10, [sp, #0x110]
101543f00:     	ldur	w11, [x29, #-0xf8]
101543f04:     	add	x10, sp, #0x110
101543f08:     	stur	w11, [x10, #0x3]
101543f0c:     	mov	w10, #0x4               ; =4
101543f10:     	ldur	d0, [x12, #0x4c]
101543f14:     	b	0x101544348 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4074>
101543f18:     	mov	w24, #0x1               ; =1
101543f1c:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101543f20:     	add	x2, x2, #0x7f0
101543f24:     	mov	x0, x20
101543f28:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543f2c:     	b	0x1015444ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d8>
101543f30:     	ldp	q0, q1, [sp, #0xa0]
101543f34:     	add	x8, sp, #0x440
101543f38:     	stur	q0, [x8, #0x4]
101543f3c:     	stur	q1, [x8, #0x14]
101543f40:     	ldr	q0, [sp, #0xc0]
101543f44:     	stur	q0, [x8, #0x24]
101543f48:     	ldr	x9, [sp, #0xd0]
101543f4c:     	stur	x9, [x8, #0x34]
101543f50:     	ldr	q0, [sp, #0x440]
101543f54:     	ldr	q1, [sp, #0x450]
101543f58:     	stur	q0, [x23, #0x4]
101543f5c:     	mov	w9, #0x2                ; =2
101543f60:     	str	w9, [x23]
101543f64:     	stur	q1, [x23, #0x14]
101543f68:     	ldr	q0, [sp, #0x460]
101543f6c:     	stur	q0, [x23, #0x24]
101543f70:     	ldur	q0, [x8, #0x2c]
101543f74:     	str	q0, [x23, #0x30]
101543f78:     	add	x0, sp, #0x110
101543f7c:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101543f80:     	b	0x101543fa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ccc>
101543f84:     	str	wzr, [x23]
101543f88:     	mov	w8, #0xc                ; =12
101543f8c:     	strb	w8, [x23, #0x8]
101543f90:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101543f94:     	add	x8, x8, #0x79f
101543f98:     	mov	w9, #0x30               ; =48
101543f9c:     	stp	x8, x9, [x23, #0x10]
101543fa0:     	add	x0, sp, #0x220
101543fa4:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101543fa8:     	b	0x10154361c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3348>
101543fac:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101543fb0:     	add	x2, x2, #0x9a8
101543fb4:     	mov	x0, x1
101543fb8:     	ldr	x1, [sp, #0x28]
101543fbc:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101543fc0:     	b	0x1015444ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d8>
101543fc4:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
101543fc8:     	ldr	q0, [x8, #0xc00]
101543fcc:     	stur	q0, [x23, #0x8]
101543fd0:     	mov	w8, #0x6                ; =6
101543fd4:     	str	w8, [x23]
101543fd8:     	add	x0, sp, #0x550
101543fdc:     	bl	0x1015233cc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationNtNtB16_5error18MemoryRuntimeErrorEECs7fdMCt8k5K6_8mech_gpu>
101543fe0:     	b	0x10154361c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3348>
101543fe4:     	ldr	w9, [sp, #0x554]
101543fe8:     	ldr	x10, [sp, #0x558]
101543fec:     	ldr	q0, [sp, #0x560]
101543ff0:     	str	q0, [sp, #0x740]
101543ff4:     	ldur	q1, [x27, #0x28]
101543ff8:     	stur	q1, [x23, #0x28]
101543ffc:     	ldur	q1, [x27, #0x38]
101544000:     	ldr	x11, [sp, #0x570]
101544004:     	ldr	x12, [sp, #0x598]
101544008:     	str	x11, [sp, #0x750]
10154400c:     	stur	q1, [x23, #0x38]
101544010:     	str	x12, [x23, #0x48]
101544014:     	str	q0, [x23, #0x10]
101544018:     	str	x11, [x23, #0x20]
10154401c:     	stp	w8, w9, [x23]
101544020:     	str	x10, [x23, #0x8]
101544024:     	b	0x101544070 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3d9c>
101544028:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154402c:     	add	x2, x2, #0x730
101544030:     	mov	x0, x20
101544034:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101544038:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10154403c:     	add	x8, x8, #0x760
101544040:     	ldr	x9, [sp]
101544044:     	orr	x9, x9, #0xc
101544048:     	stp	x9, x8, [x23, #0x8]
10154404c:     	mov	w8, #0x1b               ; =27
101544050:     	str	x8, [x23, #0x18]
101544054:     	str	wzr, [x23]
101544058:     	b	0x101543fa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ccc>
10154405c:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
101544060:     	ldr	q0, [x8, #0xc00]
101544064:     	stur	q0, [x23, #0x8]
101544068:     	mov	w8, #0x6                ; =6
10154406c:     	str	w8, [x23]
101544070:     	ldr	x8, [sp, #0x708]
101544074:     	cbz	x8, 0x101544a60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x478c>
101544078:     	ldr	x0, [sp, #0x710]
10154407c:     	lsl	x1, x8, #3
101544080:     	mov	w2, #0x8                ; =8
101544084:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101544088:     	b	0x101544a60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x478c>
10154408c:     	ldur	q0, [x27, #0x15]
101544090:     	stur	q0, [x23, #0x15]
101544094:     	ldur	q0, [x27, #0x25]
101544098:     	stur	q0, [x23, #0x25]
10154409c:     	ldur	q0, [x27, #0x35]
1015440a0:     	stur	q0, [x23, #0x35]
1015440a4:     	ldr	q0, [sp, #0x590]
1015440a8:     	str	q0, [x23, #0x40]
1015440ac:     	ldur	q0, [x27, #0x5]
1015440b0:     	stur	q0, [x23, #0x5]
1015440b4:     	str	w9, [x23]
1015440b8:     	strb	w8, [x23, #0x4]
1015440bc:     	b	0x101544a38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4764>
1015440c0:     	adrp	x8, 0x107519000 <_anon.cb4d3dab6ababcfe648a6925c4590ada.10+0x2a32>
1015440c4:     	ldr	q0, [x8, #0xc00]
1015440c8:     	stur	q0, [x23, #0x8]
1015440cc:     	mov	w8, #0x6                ; =6
1015440d0:     	str	w8, [x23]
1015440d4:     	b	0x101544a38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4764>
1015440d8:     	str	wzr, [x23]
1015440dc:     	mov	w8, #0xc                ; =12
1015440e0:     	adrp	x9, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015440e4:     	add	x9, x9, #0xd3f
1015440e8:     	stp	x8, x9, [x23, #0x8]
1015440ec:     	mov	w8, #0x1c               ; =28
1015440f0:     	str	x8, [x23, #0x18]
1015440f4:     	b	0x101543fa0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3ccc>
1015440f8:     	add	x0, sp, #0x550
1015440fc:     	mov	x1, #0x0                ; =0
101544100:     	mov	w2, #0x8                ; =8
101544104:     	mov	x3, x20
101544108:     	mov	w4, #0x8                ; =8
10154410c:     	mov	w5, #0x8                ; =8
101544110:     	bl	0x1039dc58c <__RNvMs4_NtCsgKscDXrlV49_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7fdMCt8k5K6_8mech_gpu>
101544114:     	ldr	w8, [sp, #0x550]
101544118:     	tbz	w8, #0x0, 0x10154416c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3e98>
10154411c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101544120:     	add	x8, x8, #0x7cf
101544124:     	mov	w9, #0xc                ; =12
101544128:     	stp	x9, x8, [x23, #0x8]
10154412c:     	mov	w8, #0x27               ; =39
101544130:     	str	x8, [x23, #0x18]
101544134:     	str	wzr, [x23]
101544138:     	b	0x101544a60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x478c>
10154413c:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101544140:     	add	x2, x2, #0x700
101544144:     	mov	x0, x20
101544148:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154414c:     	str	wzr, [x23]
101544150:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101544154:     	add	x8, x8, #0xd9e
101544158:     	mov	w9, #0xc                ; =12
10154415c:     	stp	x9, x8, [x23, #0x8]
101544160:     	mov	w8, #0x27               ; =39
101544164:     	str	x8, [x23, #0x18]
101544168:     	b	0x101544a38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4764>
10154416c:     	ldr	x9, [sp, #0x558]
101544170:     	ldr	x8, [sp, #0x6d0]
101544174:     	b	0x101543dcc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3af8>
101544178:     	adrp	x8, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154417c:     	add	x8, x8, #0x718
101544180:     	mov	x0, x2
101544184:     	mov	x2, x8
101544188:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154418c:     	ldrb	w8, [sp, #0x550]
101544190:     	ldr	w9, [sp, #0x554]
101544194:     	add	x12, sp, #0x720
101544198:     	stur	w9, [x12, #0xb3]
10154419c:     	ldur	w9, [x27, #0x1]
1015441a0:     	stur	w9, [x29, #-0x90]
1015441a4:     	ldr	q0, [sp, #0x560]
1015441a8:     	ldr	q1, [sp, #0x570]
1015441ac:     	str	q0, [sp, #0x440]
1015441b0:     	str	q1, [sp, #0x450]
1015441b4:     	ldr	x10, [sp, #0x580]
1015441b8:     	ldr	x9, [sp, #0x588]
1015441bc:     	sub	x11, x29, #0xe0
1015441c0:     	str	x10, [sp, #0x460]
1015441c4:     	ldr	d0, [sp, #0x558]
1015441c8:     	ldur	w10, [x12, #0xb3]
1015441cc:     	stur	w10, [x12, #0x73]
1015441d0:     	ldur	w10, [x29, #-0x90]
1015441d4:     	stur	w10, [x29, #-0xd0]
1015441d8:     	ldr	q1, [sp, #0x440]
1015441dc:     	ldr	q2, [sp, #0x450]
1015441e0:     	ldr	x10, [sp, #0x460]
1015441e4:     	str	x10, [sp, #0x240]
1015441e8:     	stp	q1, q2, [sp, #0x220]
1015441ec:     	add	x20, sp, #0x720
1015441f0:     	ldur	w10, [x12, #0x73]
1015441f4:     	str	w10, [sp, #0x334]
1015441f8:     	ldur	w10, [x29, #-0xd0]
1015441fc:     	stur	w10, [x26, #0x1]
101544200:     	ldp	q1, q2, [sp, #0x220]
101544204:     	ldr	x10, [sp, #0x240]
101544208:     	stp	q1, q2, [sp, #0x340]
10154420c:     	strb	w8, [sp, #0x330]
101544210:     	str	d0, [sp, #0x338]
101544214:     	str	x10, [sp, #0x360]
101544218:     	str	x9, [sp, #0x368]
10154421c:     	ldr	x8, [sp, #0x58]
101544220:     	add	x9, x8, #0x4e8
101544224:     	ldr	q0, [x9]
101544228:     	stur	q0, [x27, #0xa8]
10154422c:     	ldr	x9, [x8, #0x4f8]
101544230:     	ldp	q0, q1, [x8, #0x80]
101544234:     	str	q0, [sp, #0x5d0]
101544238:     	str	q1, [sp, #0x5e0]
10154423c:     	ldr	x10, [x8, #0xa0]
101544240:     	str	x9, [sp, #0x608]
101544244:     	str	x10, [sp, #0x5f0]
101544248:     	ldp	q0, q1, [x8, #0x40]
10154424c:     	str	q0, [sp, #0x590]
101544250:     	str	q1, [sp, #0x5a0]
101544254:     	ldp	q1, q0, [x8, #0x60]
101544258:     	str	q0, [sp, #0x5c0]
10154425c:     	str	q1, [sp, #0x5b0]
101544260:     	ldp	q0, q1, [x8]
101544264:     	str	q0, [sp, #0x550]
101544268:     	str	q1, [sp, #0x560]
10154426c:     	ldp	q1, q0, [x8, #0x20]
101544270:     	str	q0, [sp, #0x580]
101544274:     	str	q1, [sp, #0x570]
101544278:     	ldr	x8, [sp, #0x40]
10154427c:     	stp	x8, xzr, [x29, #-0xe8]
101544280:     	stur	xzr, [x29, #-0xd8]
101544284:     	add	x8, sp, #0x6d8
101544288:     	add	x9, sp, #0x6c0
10154428c:     	str	x8, [sp, #0x440]
101544290:     	str	x9, [sp, #0x448]
101544294:     	add	x8, sp, #0x330
101544298:     	add	x9, sp, #0x668
10154429c:     	str	x8, [sp, #0x450]
1015442a0:     	str	x9, [sp, #0x458]
1015442a4:     	sub	x8, x29, #0x100
1015442a8:     	str	x11, [sp, #0x468]
1015442ac:     	add	x9, sp, #0x660
1015442b0:     	str	x8, [sp, #0x460]
1015442b4:     	str	x9, [sp, #0x470]
1015442b8:     	sub	x8, x29, #0xe8
1015442bc:     	add	x9, sp, #0x550
1015442c0:     	str	x8, [sp, #0x478]
1015442c4:     	str	x9, [sp, #0x480]
1015442c8:     	adrp	x1, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015442cc:     	add	x1, x1, #0x7c0
1015442d0:     	add	x8, sp, #0x110
1015442d4:     	add	x0, sp, #0x440
1015442d8:     	bl	0x1015feac8 <__RINvNtNtCsgirOGyZpP7g_3std6thread6scoped5scopeNCNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallelNtBS_10Invocation12run_parallelsc_0INtNtCsgDHHaSskbIF_4core6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIB2P_NtBQ_7ReceiptNtBU_27NativeProgramExecutionErrorEEB4f_EEB10_>
1015442dc:     	ldp	q0, q1, [sp, #0x330]
1015442e0:     	str	q0, [sp, #0x440]
1015442e4:     	str	q1, [sp, #0x450]
1015442e8:     	ldp	q0, q1, [sp, #0x350]
1015442ec:     	str	q0, [sp, #0x460]
1015442f0:     	str	q1, [sp, #0x470]
1015442f4:     	mov	w19, #0x1               ; =1
1015442f8:     	add	x8, sp, #0x220
1015442fc:     	add	x0, sp, #0x440
101544300:     	bl	0x102370190 <__RNvMs4_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_15NativeWorkGroup29finish_with_credit_statistics>
101544304:     	ldr	w8, [sp, #0x220]
101544308:     	tbz	w8, #0x0, 0x1015443c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x40f0>
10154430c:     	ldr	x8, [sp, #0x238]
101544310:     	ldr	q0, [sp, #0x240]
101544314:     	str	q0, [x23, #0x30]
101544318:     	ldur	w10, [x29, #-0x100]
10154431c:     	ldur	q0, [x25, #0x8]
101544320:     	mov	w11, #0x4               ; =4
101544324:     	stp	w11, w10, [x23]
101544328:     	ldur	q1, [x20, #0x44]
10154432c:     	stur	q1, [x23, #0x8]
101544330:     	stur	q0, [x23, #0x18]
101544334:     	mov	w9, #0x28               ; =40
101544338:     	b	0x1015444fc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4228>
10154433c:     	mov	w10, #0x0               ; =0
101544340:     	ldr	d0, [sp, #0x550]
101544344:     	mov	w8, #0xd                ; =13
101544348:     	add	x11, sp, #0x110
10154434c:     	ldur	w11, [x11, #0x3]
101544350:     	add	x13, sp, #0x720
101544354:     	stur	w11, [x13, #0xb3]
101544358:     	ldr	w11, [sp, #0x110]
10154435c:     	stur	w11, [x29, #-0x90]
101544360:     	ldur	q1, [x19, #0x8]
101544364:     	ldur	q2, [x19, #0x18]
101544368:     	str	q1, [sp, #0x440]
10154436c:     	str	q2, [sp, #0x450]
101544370:     	ldur	x11, [x19, #0x28]
101544374:     	str	x11, [sp, #0x460]
101544378:     	ldur	w12, [x13, #0xb3]
10154437c:     	stur	w12, [x13, #0x73]
101544380:     	ldur	w12, [x29, #-0x90]
101544384:     	stur	w12, [x29, #-0xd0]
101544388:     	str	x11, [sp, #0x240]
10154438c:     	stp	q1, q2, [sp, #0x220]
101544390:     	stur	w12, [x23, #0x9]
101544394:     	ldur	w11, [x13, #0x73]
101544398:     	str	w11, [x23, #0xc]
10154439c:     	ldp	q1, q2, [sp, #0x220]
1015443a0:     	stur	q1, [x23, #0x18]
1015443a4:     	stur	q2, [x23, #0x28]
1015443a8:     	ldr	x11, [sp, #0x240]
1015443ac:     	str	x11, [x23, #0x38]
1015443b0:     	stp	w10, w9, [x23]
1015443b4:     	strb	w8, [x23, #0x8]
1015443b8:     	mov	w19, #0x1               ; =1
1015443bc:     	str	d0, [x23, #0x10]
1015443c0:     	b	0x101544a38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4764>
1015443c4:     	ldr	x8, [sp, #0x238]
1015443c8:     	ldr	x9, [sp, #0x20]
1015443cc:     	ldr	x9, [x9, #0x418]
1015443d0:     	adds	x9, x9, x8
1015443d4:     	b.hs	0x1015444b0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41dc>
1015443d8:     	ldr	x10, [sp, #0x240]
1015443dc:     	ldr	x8, [sp, #0x248]
1015443e0:     	ldr	x11, [sp, #0x20]
1015443e4:     	str	x9, [x11, #0x418]
1015443e8:     	ldr	x9, [x11, #0x420]
1015443ec:     	adds	x9, x9, x10
1015443f0:     	b.hs	0x1015444c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41f0>
1015443f4:     	ldr	x10, [sp, #0x20]
1015443f8:     	str	x9, [x10, #0x420]
1015443fc:     	ldr	x9, [x10, #0x428]
101544400:     	adds	x8, x9, x8
101544404:     	b.hs	0x1015444e0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x420c>
101544408:     	ldr	x9, [sp, #0x20]
10154440c:     	str	x8, [x9, #0x428]
101544410:     	ldr	q0, [sp, #0x6e0]
101544414:     	ldr	q1, [sp, #0x6f0]
101544418:     	str	q0, [sp, #0x440]
10154441c:     	str	q1, [sp, #0x450]
101544420:     	mov	w19, #0x0               ; =0
101544424:     	add	x0, sp, #0x440
101544428:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
10154442c:     	ldr	w8, [sp, #0x110]
101544430:     	cmp	w8, #0x6
101544434:     	b.ne	0x10154450c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4238>
101544438:     	mov	x9, #0x0                ; =0
10154443c:     	add	x8, sp, #0x110
101544440:     	ldur	q0, [x8, #0x8]
101544444:     	stur	q0, [x29, #-0xd0]
101544448:     	ldr	x8, [sp, #0x128]
10154444c:     	stur	x8, [x29, #-0xc0]
101544450:     	ldur	x20, [x29, #-0xc8]
101544454:     	mov	w10, #0xc8              ; =200
101544458:     	mul	x10, x8, x10
10154445c:     	add	x21, x20, x10
101544460:     	cmp	x10, x9
101544464:     	b.eq	0x101544530 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x425c>
101544468:     	ldr	x11, [x20, x9]
10154446c:     	add	x9, x9, #0xc8
101544470:     	cbz	x11, 0x101544460 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x418c>
101544474:     	b	0x10154458c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x42b8>
101544478:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
10154447c:     	add	x2, x2, #0x778
101544480:     	ldr	x0, [sp, #0x38]
101544484:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101544488:     	b	0x1015444ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d8>
10154448c:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101544490:     	add	x2, x2, #0x790
101544494:     	ldr	x0, [sp, #0x30]
101544498:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154449c:     	b	0x1015444ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x41d8>
1015444a0:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015444a4:     	add	x2, x2, #0x7a8
1015444a8:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015444ac:     	brk	#0x1
1015444b0:     	str	wzr, [x23]
1015444b4:     	mov	w9, #0xc                ; =12
1015444b8:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015444bc:     	add	x10, x10, #0xdc5
1015444c0:     	b	0x1015444d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4200>
1015444c4:     	str	wzr, [x23]
1015444c8:     	mov	w9, #0xc                ; =12
1015444cc:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015444d0:     	add	x10, x10, #0xdee
1015444d4:     	stp	x9, x10, [x23, #0x8]
1015444d8:     	mov	w8, #0x29               ; =41
1015444dc:     	b	0x1015444f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4224>
1015444e0:     	str	wzr, [x23]
1015444e4:     	mov	w9, #0xc                ; =12
1015444e8:     	adrp	x10, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015444ec:     	add	x10, x10, #0xe17
1015444f0:     	stp	x9, x10, [x23, #0x8]
1015444f4:     	mov	w8, #0x2b               ; =43
1015444f8:     	mov	w9, #0x18               ; =24
1015444fc:     	str	x8, [x23, x9]
101544500:     	add	x0, sp, #0x110
101544504:     	bl	0x101523134 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
101544508:     	b	0x101544a38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4764>
10154450c:     	ldp	q0, q1, [sp, #0x140]
101544510:     	stp	q0, q1, [x23, #0x30]
101544514:     	add	x9, sp, #0x110
101544518:     	ldur	q0, [x9, #0x4]
10154451c:     	stur	q0, [x23, #0x4]
101544520:     	ldp	q1, q0, [sp, #0x120]
101544524:     	stp	q1, q0, [x23, #0x10]
101544528:     	str	w8, [x23]
10154452c:     	b	0x101544a34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4760>
101544530:     	ldr	x9, [sp, #0x20]
101544534:     	ldr	x9, [x9, #0x440]
101544538:     	cmn	x9, #0x1
10154453c:     	b.eq	0x101544790 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44bc>
101544540:     	add	x9, x9, #0x1
101544544:     	ldr	x10, [sp, #0x20]
101544548:     	str	x9, [x10, #0x440]
10154454c:     	ldr	x9, [x10, #0x438]
101544550:     	ldr	x10, [sp, #0x6d0]
101544554:     	adds	x9, x10, x9
101544558:     	b.hs	0x101544790 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44bc>
10154455c:     	ldp	x10, x11, [sp, #0x18]
101544560:     	str	x9, [x11, #0x438]
101544564:     	ldr	x9, [x11, #0x448]
101544568:     	adds	x9, x9, x10
10154456c:     	b.hs	0x10154479c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44c8>
101544570:     	ldr	x11, [sp, #0x20]
101544574:     	str	x9, [x11, #0x448]
101544578:     	ldr	x9, [x11, #0x450]
10154457c:     	ldur	x10, [x29, #-0xd8]
101544580:     	cmp	x10, x9
101544584:     	csel	x9, x10, x9, hi
101544588:     	str	x9, [x11, #0x450]
10154458c:     	mov	w9, #0xc8               ; =200
101544590:     	mul	x10, x8, x9
101544594:     	add	x11, x20, #0x60
101544598:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
10154459c:     	add	x8, x8, #0xe5f
1015445a0:     	mov	w9, #0x17               ; =23
1015445a4:     	adrp	x12, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445a8:     	add	x12, x12, #0xe76
1015445ac:     	adrp	x13, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445b0:     	add	x13, x13, #0xe8e
1015445b4:     	adrp	x14, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445b8:     	add	x14, x14, #0xea6
1015445bc:     	adrp	x15, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445c0:     	add	x15, x15, #0xec5
1015445c4:     	adrp	x16, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445c8:     	add	x16, x16, #0xeeb
1015445cc:     	adrp	x17, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445d0:     	add	x17, x17, #0xf0a
1015445d4:     	adrp	x1, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445d8:     	add	x1, x1, #0xf26
1015445dc:     	adrp	x2, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445e0:     	add	x2, x2, #0xf4a
1015445e4:     	adrp	x3, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445e8:     	add	x3, x3, #0xf6e
1015445ec:     	adrp	x4, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445f0:     	add	x4, x4, #0xf8d
1015445f4:     	adrp	x0, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015445f8:     	add	x0, x0, #0xfaa
1015445fc:     	adrp	x5, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101544600:     	add	x5, x5, #0xfd2
101544604:     	b	0x101544610 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x433c>
101544608:     	sub	x10, x10, #0xc8
10154460c:     	add	x11, x11, #0xc8
101544610:     	cbz	x10, 0x1015447ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x44d8>
101544614:     	ldur	x6, [x11, #-0x60]
101544618:     	cmp	x6, #0x1
10154461c:     	b.eq	0x101544608 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4334>
101544620:     	ldr	x6, [sp, #0x20]
101544624:     	ldr	x6, [x6, #0x330]
101544628:     	ldur	x7, [x11, #-0x18]
10154462c:     	adds	x6, x7, x6
101544630:     	b.hs	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
101544634:     	ldr	x7, [sp, #0x20]
101544638:     	str	x6, [x7, #0x330]
10154463c:     	ldr	x6, [x7, #0x3c8]
101544640:     	ldur	x7, [x11, #-0x10]
101544644:     	adds	x6, x7, x6
101544648:     	b.hs	0x101544958 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4684>
10154464c:     	ldr	x7, [sp, #0x20]
101544650:     	str	x6, [x7, #0x3c8]
101544654:     	ldr	x6, [x7, #0x3d0]
101544658:     	ldur	x7, [x11, #-0x8]
10154465c:     	adds	x6, x7, x6
101544660:     	b.hs	0x101544964 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4690>
101544664:     	ldr	x7, [sp, #0x20]
101544668:     	str	x6, [x7, #0x3d0]
10154466c:     	ldr	x6, [x7, #0x3d8]
101544670:     	ldr	x7, [x11]
101544674:     	adds	x6, x7, x6
101544678:     	b.hs	0x101544970 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x469c>
10154467c:     	ldr	x7, [sp, #0x20]
101544680:     	str	x6, [x7, #0x3d8]
101544684:     	ldr	x6, [x7, #0x3e0]
101544688:     	ldr	x7, [x11, #0x8]
10154468c:     	adds	x6, x7, x6
101544690:     	b.hs	0x10154497c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46a8>
101544694:     	ldr	x7, [sp, #0x20]
101544698:     	str	x6, [x7, #0x3e0]
10154469c:     	ldr	x6, [x7, #0x3e8]
1015446a0:     	ldr	x7, [x11, #0x10]
1015446a4:     	adds	x6, x7, x6
1015446a8:     	b.hs	0x101544988 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46b4>
1015446ac:     	ldr	x7, [sp, #0x20]
1015446b0:     	str	x6, [x7, #0x3e8]
1015446b4:     	ldr	x6, [x7, #0x3f0]
1015446b8:     	ldr	x7, [x11, #0x18]
1015446bc:     	adds	x6, x7, x6
1015446c0:     	b.hs	0x101544994 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46c0>
1015446c4:     	ldr	x7, [sp, #0x20]
1015446c8:     	str	x6, [x7, #0x3f0]
1015446cc:     	ldr	x6, [x7, #0x3f8]
1015446d0:     	ldr	x7, [x11, #0x20]
1015446d4:     	adds	x6, x7, x6
1015446d8:     	b.hs	0x1015449a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46cc>
1015446dc:     	ldr	x7, [sp, #0x20]
1015446e0:     	str	x6, [x7, #0x3f8]
1015446e4:     	ldr	x6, [x7, #0x400]
1015446e8:     	ldr	x7, [x11, #0x28]
1015446ec:     	adds	x6, x7, x6
1015446f0:     	b.hs	0x1015449ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46d8>
1015446f4:     	ldr	x7, [sp, #0x20]
1015446f8:     	str	x6, [x7, #0x400]
1015446fc:     	ldr	x6, [x7, #0x408]
101544700:     	ldr	x7, [x11, #0x30]
101544704:     	adds	x6, x7, x6
101544708:     	b.hs	0x1015449b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46e4>
10154470c:     	ldr	x7, [sp, #0x20]
101544710:     	str	x6, [x7, #0x408]
101544714:     	ldr	x6, [x7, #0x410]
101544718:     	ldr	x7, [x11, #0x38]
10154471c:     	adds	x6, x7, x6
101544720:     	b.hs	0x1015449c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46f0>
101544724:     	ldr	x7, [sp, #0x20]
101544728:     	str	x6, [x7, #0x410]
10154472c:     	ldr	x6, [x7, #0x418]
101544730:     	ldr	x7, [x11, #0x40]
101544734:     	adds	x6, x7, x6
101544738:     	b.hs	0x1015449d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46fc>
10154473c:     	ldr	x7, [sp, #0x20]
101544740:     	str	x6, [x7, #0x418]
101544744:     	ldr	x6, [x7, #0x420]
101544748:     	ldr	x7, [x11, #0x48]
10154474c:     	adds	x6, x7, x6
101544750:     	b.hs	0x1015449d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46fc>
101544754:     	ldr	x7, [sp, #0x20]
101544758:     	str	x6, [x7, #0x420]
10154475c:     	ldr	x6, [x7, #0x428]
101544760:     	ldr	x7, [x11, #0x50]
101544764:     	adds	x6, x7, x6
101544768:     	b.hs	0x1015449d0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46fc>
10154476c:     	ldr	x7, [sp, #0x20]
101544770:     	str	x6, [x7, #0x428]
101544774:     	ldr	x6, [x7, #0x430]
101544778:     	ldr	x7, [x11, #0x58]
10154477c:     	adds	x6, x7, x6
101544780:     	b.hs	0x1015449dc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4708>
101544784:     	ldr	x7, [sp, #0x20]
101544788:     	str	x6, [x7, #0x430]
10154478c:     	b	0x101544608 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4334>
101544790:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
101544794:     	add	x8, x8, #0xe42
101544798:     	b	0x1015449c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x46f4>
10154479c:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015447a0:     	add	x8, x8, #0xd3f
1015447a4:     	mov	w9, #0x1c               ; =28
1015447a8:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
1015447ac:     	stp	xzr, xzr, [x29, #-0xa0]
1015447b0:     	mov	w8, #0x8                ; =8
1015447b4:     	stp	xzr, x8, [x29, #-0xb0]
1015447b8:     	ldr	x1, [sp, #0x6d0]
1015447bc:     	sub	x0, x29, #0xb0
1015447c0:     	bl	0x1014debc0 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE17try_reserve_exactB1h_>
1015447c4:     	mov	x8, #-0x7fffffffffffffff ; =-9223372036854775807
1015447c8:     	cmp	x0, x8
1015447cc:     	b.ne	0x1015449f8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4724>
1015447d0:     	ldur	x8, [x29, #-0xb0]
1015447d4:     	ldr	x9, [sp, #0x6d0]
1015447d8:     	cmp	x8, x9
1015447dc:     	b.ne	0x101544a08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4734>
1015447e0:     	ldr	x9, [sp, #0x6c8]
1015447e4:     	ldr	x10, [sp, #0x6c0]
1015447e8:     	mov	w11, #0x68              ; =104
1015447ec:     	madd	x22, x8, x11, x9
1015447f0:     	stp	x9, x9, [x29, #-0x90]
1015447f4:     	stp	x10, x22, [x29, #-0x80]
1015447f8:     	cbz	x8, 0x1015448ac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x45d8>
1015447fc:     	add	x24, sp, #0x440
101544800:     	add	x19, x9, #0x68
101544804:     	mov	x25, #-0x8000000000000000 ; =-9223372036854775808
101544808:     	mov	x26, x19
10154480c:     	ldr	x8, [x26, #-0x68]!
101544810:     	cmp	x8, x25
101544814:     	b.eq	0x1015448a8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x45d4>
101544818:     	str	x8, [sp, #0x440]
10154481c:     	ldur	q0, [x26, #0x58]
101544820:     	stur	q0, [x24, #0x58]
101544824:     	ldur	q0, [x26, #0x28]
101544828:     	stur	q0, [x24, #0x28]
10154482c:     	ldur	q0, [x26, #0x38]
101544830:     	stur	q0, [x24, #0x38]
101544834:     	ldur	q0, [x26, #0x48]
101544838:     	stur	q0, [x24, #0x48]
10154483c:     	ldur	q0, [x26, #0x8]
101544840:     	stur	q0, [x24, #0x8]
101544844:     	ldur	q0, [x26, #0x18]
101544848:     	stur	q0, [x24, #0x18]
10154484c:     	ldr	x8, [sp, #0x498]
101544850:     	ldr	x9, [sp, #0x4a0]
101544854:     	ldur	q0, [x26, #0x18]
101544858:     	str	q0, [sp, #0x220]
10154485c:     	ldur	q0, [x26, #0x28]
101544860:     	str	q0, [sp, #0x230]
101544864:     	ldur	q0, [x26, #0x38]
101544868:     	str	q0, [sp, #0x240]
10154486c:     	ldur	q0, [x26, #0x48]
101544870:     	str	q0, [sp, #0x250]
101544874:     	str	x8, [sp, #0x260]
101544878:     	str	xzr, [sp, #0x268]
10154487c:     	str	x9, [sp, #0x270]
101544880:     	sub	x0, x29, #0xb0
101544884:     	add	x1, sp, #0x220
101544888:     	bl	0x1014deb24 <__RNvMs3_NtNtCsgKscDXrlV49_5alloc11collections9vec_dequeINtB5_8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionE13push_back_mutB1h_>
10154488c:     	add	x0, sp, #0x440
101544890:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101544894:     	add	x19, x26, #0xd0
101544898:     	add	x8, x26, #0x68
10154489c:     	cmp	x8, x22
1015448a0:     	b.ne	0x101544808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4534>
1015448a4:     	mov	x19, x22
1015448a8:     	stur	x19, [x29, #-0x88]
1015448ac:     	sub	x0, x29, #0x90
1015448b0:     	bl	0x1015d9fd8 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
1015448b4:     	ldur	x24, [x29, #-0xd0]
1015448b8:     	ldr	q0, [sp, #0x680]
1015448bc:     	ldr	q1, [sp, #0x690]
1015448c0:     	str	q0, [sp, #0x440]
1015448c4:     	str	q1, [sp, #0x450]
1015448c8:     	ldr	q0, [sp, #0x6a0]
1015448cc:     	ldr	q1, [sp, #0x6b0]
1015448d0:     	stp	q0, q1, [sp, #0x220]
1015448d4:     	ldr	x8, [sp, #0x58]
1015448d8:     	add	x0, x8, #0x3c0
1015448dc:     	bl	0x101522e40 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6option6OptionNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel5BatchEEB1e_>
1015448e0:     	ldp	q0, q1, [x29, #-0xb0]
1015448e4:     	ldr	x8, [sp, #0x58]
1015448e8:     	stp	q0, q1, [x8, #0x3c0]
1015448ec:     	ldr	q0, [sp, #0x440]
1015448f0:     	ldr	q1, [sp, #0x450]
1015448f4:     	str	q0, [x8, #0x400]
1015448f8:     	str	q1, [x8, #0x410]
1015448fc:     	ldp	q0, q1, [sp, #0x220]
101544900:     	str	q0, [x8, #0x420]
101544904:     	str	x20, [x8, #0x3e0]
101544908:     	str	x20, [x8, #0x3e8]
10154490c:     	str	x24, [x8, #0x3f0]
101544910:     	str	x21, [x8, #0x3f8]
101544914:     	str	q1, [x8, #0x430]
101544918:     	mov	w8, #0x1                ; =1
10154491c:     	dup.2d	v0, x8
101544920:     	stur	q0, [x23, #0x8]
101544924:     	mov	w8, #0x6                ; =6
101544928:     	str	w8, [x23]
10154492c:     	mov	w19, #0x0               ; =0
101544930:     	mov	w28, #0x0               ; =0
101544934:     	add	x0, sp, #0x720
101544938:     	bl	0x101524ab8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
10154493c:     	ldr	x8, [sp, #0x708]
101544940:     	cbz	x8, 0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
101544944:     	ldr	x0, [sp, #0x710]
101544948:     	lsl	x1, x8, #3
10154494c:     	mov	w2, #0x8                ; =8
101544950:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101544954:     	b	0x1015438b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x35e0>
101544958:     	mov	x8, x12
10154495c:     	mov	w9, #0x18               ; =24
101544960:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
101544964:     	mov	x8, x13
101544968:     	mov	w9, #0x18               ; =24
10154496c:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
101544970:     	mov	x8, x14
101544974:     	mov	w9, #0x1f               ; =31
101544978:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
10154497c:     	mov	x8, x15
101544980:     	mov	w9, #0x26               ; =38
101544984:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
101544988:     	mov	x8, x16
10154498c:     	mov	w9, #0x1f               ; =31
101544990:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
101544994:     	mov	x8, x17
101544998:     	mov	w9, #0x1c               ; =28
10154499c:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
1015449a0:     	mov	x8, x1
1015449a4:     	mov	w9, #0x24               ; =36
1015449a8:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
1015449ac:     	mov	x8, x2
1015449b0:     	mov	w9, #0x24               ; =36
1015449b4:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
1015449b8:     	mov	x8, x3
1015449bc:     	mov	w9, #0x1f               ; =31
1015449c0:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
1015449c4:     	mov	x8, x4
1015449c8:     	mov	w9, #0x1d               ; =29
1015449cc:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
1015449d0:     	mov	x8, x0
1015449d4:     	mov	w9, #0x28               ; =40
1015449d8:     	b	0x1015449e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4710>
1015449dc:     	mov	x8, x5
1015449e0:     	mov	w9, #0x21               ; =33
1015449e4:     	str	wzr, [x23]
1015449e8:     	mov	w10, #0xc               ; =12
1015449ec:     	stp	x10, x8, [x23, #0x8]
1015449f0:     	str	x9, [x23, #0x18]
1015449f4:     	b	0x101544a2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4758>
1015449f8:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
1015449fc:     	add	x8, x8, #0xd5b
101544a00:     	mov	w9, #0x21               ; =33
101544a04:     	b	0x101544a14 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4740>
101544a08:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101544a0c:     	add	x8, x8, #0x7f6
101544a10:     	mov	w9, #0x30               ; =48
101544a14:     	str	wzr, [x23]
101544a18:     	mov	w10, #0xc               ; =12
101544a1c:     	strb	w10, [x23, #0x8]
101544a20:     	stp	x8, x9, [x23, #0x10]
101544a24:     	sub	x0, x29, #0xb0
101544a28:     	bl	0x1015244b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
101544a2c:     	sub	x0, x29, #0xd0
101544a30:     	bl	0x1015239ac <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
101544a34:     	mov	w19, #0x0               ; =0
101544a38:     	mov	w28, #0x1               ; =1
101544a3c:     	add	x0, sp, #0x720
101544a40:     	bl	0x101524ab8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101544a44:     	ldr	x8, [sp, #0x708]
101544a48:     	cbz	x8, 0x101544a5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4788>
101544a4c:     	ldr	x0, [sp, #0x710]
101544a50:     	lsl	x1, x8, #3
101544a54:     	mov	w2, #0x8                ; =8
101544a58:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101544a5c:     	tbz	w19, #0x0, 0x10154361c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3348>
101544a60:     	add	x0, sp, #0x6e0
101544a64:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544a68:     	b	0x10154361c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x3348>
101544a6c:     	b	0x101544bc0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48ec>
101544a70:     	mov	x22, x0
101544a74:     	mov	x23, x28
101544a78:     	b	0x101544b6c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4898>
101544a7c:     	mov	x22, x0
101544a80:     	mov	w19, #0x0               ; =0
101544a84:     	b	0x101544b5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4888>
101544a88:     	mov	x22, x0
101544a8c:     	mov	w28, #0x1               ; =1
101544a90:     	b	0x101544b18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4844>
101544a94:     	mov	x22, x0
101544a98:     	mov	w19, #0x0               ; =0
101544a9c:     	mov	w28, #0x0               ; =0
101544aa0:     	mov	w23, #0x0               ; =0
101544aa4:     	ldp	q0, q1, [x29, #-0xb0]
101544aa8:     	ldr	x8, [sp, #0x58]
101544aac:     	stp	q0, q1, [x8, #0x3c0]
101544ab0:     	ldr	q0, [sp, #0x440]
101544ab4:     	ldr	q1, [sp, #0x450]
101544ab8:     	str	q0, [x8, #0x400]
101544abc:     	str	q1, [x8, #0x410]
101544ac0:     	ldp	q0, q1, [sp, #0x220]
101544ac4:     	str	q0, [x8, #0x420]
101544ac8:     	str	x20, [x8, #0x3e0]
101544acc:     	str	x20, [x8, #0x3e8]
101544ad0:     	str	x24, [x8, #0x3f0]
101544ad4:     	str	x21, [x8, #0x3f8]
101544ad8:     	str	q1, [x8, #0x430]
101544adc:     	b	0x101544b64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4890>
101544ae0:     	mov	x22, x0
101544ae4:     	b	0x101544b0c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4838>
101544ae8:     	mov	x22, x0
101544aec:     	stur	x19, [x29, #-0x88]
101544af0:     	b	0x101544b04 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4830>
101544af4:     	mov	x22, x0
101544af8:     	stur	x19, [x29, #-0x88]
101544afc:     	add	x0, sp, #0x440
101544b00:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101544b04:     	sub	x0, x29, #0x90
101544b08:     	bl	0x1015d9fd8 <__RNvXse_NtNtCsgKscDXrlV49_5alloc3vec9into_iterINtB5_8IntoIterNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionENtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4dropB18_>
101544b0c:     	sub	x0, x29, #0xb0
101544b10:     	bl	0x1015244b8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCsgKscDXrlV49_5alloc11collections9vec_deque8VecDequeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel13PendingRegionEEB1P_>
101544b14:     	mov	w28, #0x0               ; =0
101544b18:     	sub	x0, x29, #0xd0
101544b1c:     	bl	0x1015239ac <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecINtNtB4_6result6ResultNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1F_27NativeProgramExecutionErrorEEEB1L_>
101544b20:     	mov	w19, #0x0               ; =0
101544b24:     	b	0x101544b60 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x488c>
101544b28:     	mov	x22, x0
101544b2c:     	b	0x101544b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4884>
101544b30:     	mov	x22, x0
101544b34:     	b	0x101544b58 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4884>
101544b38:     	b	0x101544b9c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48c8>
101544b3c:     	mov	x22, x0
101544b40:     	add	x0, sp, #0x110
101544b44:     	bl	0x101523134 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtB4_6result6ResultINtNtCsgKscDXrlV49_5alloc3vec3VecIBH_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7ReceiptNtB1J_27NativeProgramExecutionErrorEEB3c_EEB1P_>
101544b48:     	b	0x101544b5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4888>
101544b4c:     	mov	x22, x0
101544b50:     	add	x0, sp, #0x330
101544b54:     	bl	0x10152555c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workers15NativeWorkGroupECs7fdMCt8k5K6_8mech_gpu>
101544b58:     	mov	w19, #0x1               ; =1
101544b5c:     	mov	w28, #0x1               ; =1
101544b60:     	mov	w23, #0x1               ; =1
101544b64:     	add	x0, sp, #0x720
101544b68:     	bl	0x101524ab8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101544b6c:     	ldr	x8, [sp, #0x708]
101544b70:     	cbz	x8, 0x101544b84 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48b0>
101544b74:     	ldr	x0, [sp, #0x710]
101544b78:     	lsl	x1, x8, #3
101544b7c:     	mov	w2, #0x8                ; =8
101544b80:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101544b84:     	tbz	w19, #0x0, 0x101544b90 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48bc>
101544b88:     	add	x0, sp, #0x6e0
101544b8c:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544b90:     	tbnz	w28, #0x0, 0x101544bc8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48f4>
101544b94:     	b	0x101544bd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48fc>
101544b98:     	b	0x101544bb0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48dc>
101544b9c:     	mov	x22, x0
101544ba0:     	add	x0, sp, #0x110
101544ba4:     	bl	0x101523c30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel7CaptureEEB1p_>
101544ba8:     	b	0x101544bb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48e0>
101544bac:     	b	0x101544bc0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48ec>
101544bb0:     	mov	x22, x0
101544bb4:     	add	x0, sp, #0x220
101544bb8:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544bbc:     	b	0x101544bc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x48f0>
101544bc0:     	mov	x22, x0
101544bc4:     	mov	w23, #0x1               ; =1
101544bc8:     	add	x0, sp, #0x6c0
101544bcc:     	bl	0x101523b4c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtCsgKscDXrlV49_5alloc3vec3VecNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8parallel11ReadyRegionEEB1p_>
101544bd0:     	tbnz	w23, #0x0, 0x101544bdc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4908>
101544bd4:     	b	0x101544c18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4944>
101544bd8:     	mov	x22, x0
101544bdc:     	add	x0, sp, #0x6a0
101544be0:     	bl	0x101524ab8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget22ManagedNodeReservationECs7fdMCt8k5K6_8mech_gpu>
101544be4:     	b	0x101544bec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4918>
101544be8:     	mov	x22, x0
101544bec:     	add	x0, sp, #0x680
101544bf0:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544bf4:     	b	0x101544c18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4944>
101544bf8:     	mov	x22, x0
101544bfc:     	add	x1, sp, #0x550
101544c00:     	mov	x0, x20
101544c04:     	mov	w2, #0x108              ; =264
101544c08:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101544c0c:     	mov	w19, #0x0               ; =0
101544c10:     	b	0x101544c98 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49c4>
101544c14:     	mov	x22, x0
101544c18:     	ldr	x8, [sp, #0x668]
101544c1c:     	mov	x9, #-0x1               ; =-1
101544c20:     	ldaddl	x9, x8, [x8]
101544c24:     	cmp	x8, #0x1
101544c28:     	b.ne	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544c2c:     	dmb	ishld
101544c30:     	add	x0, sp, #0x668
101544c34:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101544c38:     	b	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544c3c:     	mov	x22, x0
101544c40:     	ldr	x8, [sp, #0x550]
101544c44:     	mov	x9, #-0x1               ; =-1
101544c48:     	ldaddl	x9, x8, [x8]
101544c4c:     	cmp	x8, #0x1
101544c50:     	b.ne	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544c54:     	dmb	ishld
101544c58:     	add	x0, sp, #0x550
101544c5c:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101544c60:     	b	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544c64:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101544c68:     	mov	x22, x0
101544c6c:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
101544c70:     	str	x8, [x20]
101544c74:     	b	0x101544cac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x49d8>
101544c78:     	mov	x22, x0
101544c7c:     	tbnz	w19, #0x0, 0x101544cf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a24>
101544c80:     	b	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544c84:     	mov	x22, x0
101544c88:     	add	x0, sp, #0x440
101544c8c:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544c90:     	b	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544c94:     	mov	x22, x0
101544c98:     	sub	x0, x29, #0x90
101544c9c:     	bl	0x101524b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs7fdMCt8k5K6_8mech_gpu>
101544ca0:     	b	0x101544cd4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a00>
101544ca4:     	mov	x22, x0
101544ca8:     	mov	x23, x24
101544cac:     	cbz	w23, 0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544cb0:     	ldr	x8, [sp, #0x550]
101544cb4:     	cbz	x8, 0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544cb8:     	add	x0, sp, #0x550
101544cbc:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544cc0:     	b	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544cc4:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101544cc8:     	mov	x22, x0
101544ccc:     	b	0x101544cf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a24>
101544cd0:     	mov	x22, x0
101544cd4:     	ldr	x8, [sp, #0x720]
101544cd8:     	mov	x9, #-0x1               ; =-1
101544cdc:     	ldaddl	x9, x8, [x8]
101544ce0:     	cmp	x8, #0x1
101544ce4:     	b.ne	0x101544cf4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a20>
101544ce8:     	dmb	ishld
101544cec:     	add	x0, sp, #0x720
101544cf0:     	bl	0x102e165fc <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
101544cf4:     	tbz	w19, #0x0, 0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544cf8:     	add	x0, sp, #0x220
101544cfc:     	bl	0x10152577c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation23private_unsigned_matrix21PrivateUnsignedMatrixECs7fdMCt8k5K6_8mech_gpu>
101544d00:     	b	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544d04:     	mov	x22, x0
101544d08:     	add	x0, sp, #0x60
101544d0c:     	bl	0x101524d58 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs7fdMCt8k5K6_8mech_gpu>
101544d10:     	b	0x101544d40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a6c>
101544d14:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101544d18:     	mov	w8, #0x2                ; =2
101544d1c:     	str	x8, [x20, #0x220]
101544d20:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
101544d24:     	mov	w8, #0x2                ; =2
101544d28:     	str	x8, [x20, #0x220]
101544d2c:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
101544d30:     	mov	x22, x0
101544d34:     	ldr	w8, [sp, #0x550]
101544d38:     	cmp	w8, #0x6
101544d3c:     	b.ne	0x101544d48 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation6helper+0x4a74>
101544d40:     	mov	x0, x22
101544d44:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
101544d48:     	add	x0, sp, #0x550
101544d4c:     	bl	0x101525658 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
101544d50:     	mov	x0, x22
101544d54:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
