
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010236d190 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
10236d190:     	sub	sp, sp, #0x80
10236d194:     	stp	x20, x19, [sp, #0x60]
10236d198:     	stp	x29, x30, [sp, #0x70]
10236d19c:     	add	x29, sp, #0x70
10236d1a0:     	ldr	x19, [x0]
10236d1a4:     	ldr	x9, [x19, #0x10]
10236d1a8:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10236d1ac:     	cmp	x9, x10
10236d1b0:     	b.hs	0x10236d210 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x80>
10236d1b4:     	ldr	x9, [x19, #0x38]
10236d1b8:     	adds	x9, x9, x1
10236d1bc:     	b.hs	0x10236d21c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x8c>
10236d1c0:     	cmp	x9, x2
10236d1c4:     	b.ls	0x10236d1e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x50>
10236d1c8:     	mov	w10, #0x606             ; =1542
10236d1cc:     	strh	w10, [x8]
10236d1d0:     	mov	w10, #0x1               ; =1
10236d1d4:     	strb	w10, [x8, #0x2]
10236d1d8:     	stp	x9, x2, [x8, #0x8]
10236d1dc:     	b	0x10236d2f8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x168>
10236d1e0:     	adrp	x0, 0x10806f000 <__mi_heap_main+0xb28>
10236d1e4:     	add	x0, x0, #0x550
10236d1e8:     	ldr	x9, [x0]
10236d1ec:     	blr	x9
10236d1f0:     	ldrb	w9, [x0, #0x48]
10236d1f4:     	cmp	w9, #0x1
10236d1f8:     	b.eq	0x10236d24c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xbc>
10236d1fc:     	cmp	w9, #0x2
10236d200:     	b.ne	0x10236d224 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
10236d204:     	adrp	x0, 0x108032000 <_anon.b751fc49bcc701379c8af7be5d8e914b.25>
10236d208:     	add	x0, x0, #0x610
10236d20c:     	bl	0x103a01874 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
10236d210:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
10236d214:     	add	x0, x0, #0x130
10236d218:     	bl	0x103a01f28 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236d21c:     	mov	x9, #-0x1               ; =-1
10236d220:     	b	0x10236d1c8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x38>
10236d224:     	adrp	x9, 0x102362000 <__RINvNtNtNtNtCsgDHHaSskbIF_4core5slice4sort6stable9quicksort9quicksortTmmENCINvMNtCsgKscDXrlV49_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1h_11collections5btree3mapINtB24_8BTreeMapmmEINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtB31_8adapters12GenericShuntINtNtB3W_3map3MapINtNtB3W_9enumerate9EnumerateINtNtB3W_6filter6FilterIB4H_INtNtB8_4iter4IterNtNtNtCs1qJAwyMG1lC_11mech_engine16source_semantics8frontend11PendingNodeEENCNvMs0_NtB5V_11applicationNtB5V_15SemanticBuilder19counted_applications7_0EENCB78_s8_0EINtNtBa_6result6ResultNtNtBa_7convert10InfallibleNtB5V_19SourceSemanticErrorEEE0E0EB5Z_+0x30c>
10236d228:     	add	x9, x9, #0xb7c
10236d22c:     	stp	x1, x0, [sp]
10236d230:     	mov	x1, x9
10236d234:     	mov	x20, x8
10236d238:     	bl	0x102e6e274 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
10236d23c:     	ldp	x1, x0, [sp]
10236d240:     	mov	x8, x20
10236d244:     	mov	w9, #0x1                ; =1
10236d248:     	strb	w9, [x0, #0x48]
10236d24c:     	ldr	x9, [x0, #0x20]
10236d250:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10236d254:     	cmp	x9, x10
10236d258:     	b.hs	0x10236d308 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x178>
10236d25c:     	ldr	x9, [x0, #0x28]
10236d260:     	cmp	x9, #0x0
10236d264:     	ccmp	x9, x19, #0x4, ne
10236d268:     	b.ne	0x10236d2dc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x14c>
10236d26c:     	mov	x20, x8
10236d270:     	ldr	x8, [x19, #0x10]
10236d274:     	cbnz	x8, 0x10236d314 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x184>
10236d278:     	mov	x2, x1
10236d27c:     	mov	x8, #-0x1               ; =-1
10236d280:     	str	x8, [x19, #0x10]
10236d284:     	ldr	q0, [x0, #0x30]
10236d288:     	str	q0, [sp, #0x10]
10236d28c:     	ldr	x8, [x0, #0x40]
10236d290:     	str	x8, [sp, #0x20]
10236d294:     	add	x0, sp, #0x38
10236d298:     	add	x1, x19, #0x18
10236d29c:     	add	x4, sp, #0x10
10236d2a0:     	mov	x3, #0x0                ; =0
10236d2a4:     	bl	0x102381918 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits>
10236d2a8:     	ldr	x8, [x19, #0x10]
10236d2ac:     	add	x8, x8, #0x1
10236d2b0:     	str	x8, [x19, #0x10]
10236d2b4:     	ldrb	w9, [sp, #0x38]
10236d2b8:     	ldur	q0, [sp, #0x39]
10236d2bc:     	ldur	q1, [sp, #0x49]
10236d2c0:     	stp	q0, q1, [sp, #0x10]
10236d2c4:     	ldr	x8, [sp, #0x58]
10236d2c8:     	stur	x8, [sp, #0x2f]
10236d2cc:     	cmp	w9, #0x9
10236d2d0:     	mov	x8, x20
10236d2d4:     	b.ne	0x10236d2e0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x150>
10236d2d8:     	b	0x10236d204 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x74>
10236d2dc:     	mov	w9, #0x0                ; =0
10236d2e0:     	strb	w9, [x8]
10236d2e4:     	ldp	q0, q1, [sp, #0x10]
10236d2e8:     	stur	q0, [x8, #0x1]
10236d2ec:     	stur	q1, [x8, #0x11]
10236d2f0:     	ldur	x9, [sp, #0x2f]
10236d2f4:     	str	x9, [x8, #0x20]
10236d2f8:     	ldp	x29, x30, [sp, #0x70]
10236d2fc:     	ldp	x20, x19, [sp, #0x60]
10236d300:     	add	sp, sp, #0x80
10236d304:     	ret
10236d308:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
10236d30c:     	add	x0, x0, #0xe8
10236d310:     	bl	0x103a01f28 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236d314:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
10236d318:     	add	x0, x0, #0x100
10236d31c:     	bl	0x103a01ef8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
10236d320:     	ldr	x8, [x19, #0x10]
10236d324:     	add	x8, x8, #0x1
10236d328:     	str	x8, [x19, #0x10]
10236d32c:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
