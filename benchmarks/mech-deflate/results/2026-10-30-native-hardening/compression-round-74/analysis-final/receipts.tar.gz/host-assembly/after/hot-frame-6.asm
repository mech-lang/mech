
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101620b4c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_>:
101620b4c:     	sub	sp, sp, #0xd0
101620b50:     	stp	x28, x27, [sp, #0x70]
101620b54:     	stp	x26, x25, [sp, #0x80]
101620b58:     	stp	x24, x23, [sp, #0x90]
101620b5c:     	stp	x22, x21, [sp, #0xa0]
101620b60:     	stp	x20, x19, [sp, #0xb0]
101620b64:     	stp	x29, x30, [sp, #0xc0]
101620b68:     	add	x29, sp, #0xc0
101620b6c:     	ldrb	w8, [x0, #0x3c]
101620b70:     	cmp	w8, #0x1
101620b74:     	b.ne	0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620b78:     	ldp	x21, x24, [x0, #0x10]
101620b7c:     	ldp	x9, x8, [x0, #0x20]
101620b80:     	stp	x9, x8, [sp]
101620b84:     	ldp	x27, x19, [x1]
101620b88:     	ldp	x8, x9, [x1, #0x28]
101620b8c:     	stp	x9, x8, [sp, #0x18]
101620b90:     	ldp	x8, x9, [x1, #0x10]
101620b94:     	str	x9, [sp, #0x28]
101620b98:     	str	x8, [sp, #0x10]
101620b9c:     	add	x26, x21, #0x8
101620ba0:     	lsl	x8, x24, #6
101620ba4:     	sub	x20, x8, x24, lsl #3
101620ba8:     	mov	x23, x21
101620bac:     	b	0x101620be4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x98>
101620bb0:     	add	x8, sp, #0x30
101620bb4:     	add	x0, x9, #0x10
101620bb8:     	add	x1, x25, #0x18
101620bbc:     	bl	0x102e2c800 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
101620bc0:     	ldr	x8, [sp, #0x30]
101620bc4:     	cmp	x8, #0x1e
101620bc8:     	b.ne	0x101620d70 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x224>
101620bcc:     	ldr	x8, [sp, #0x38]
101620bd0:     	add	x23, x23, #0x38
101620bd4:     	add	x26, x26, #0x38
101620bd8:     	sub	x20, x20, #0x38
101620bdc:     	cmp	x8, x28
101620be0:     	b.ne	0x101620d94 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620be4:     	cmp	x20, #0x0
101620be8:     	cset	w22, eq
101620bec:     	cbz	x20, 0x101620d94 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620bf0:     	ldr	x0, [x23, #0x30]
101620bf4:     	cmp	x0, x19
101620bf8:     	b.hs	0x101620db8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x26c>
101620bfc:     	add	x8, x27, x0, lsl #5
101620c00:     	ldrb	w9, [x8]
101620c04:     	cmp	w9, #0x3
101620c08:     	b.ne	0x101620c3c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0xf0>
101620c0c:     	ldr	x0, [x8, #0x8]
101620c10:     	ldr	x8, [sp, #0x28]
101620c14:     	cmp	x0, x8
101620c18:     	b.hs	0x101620dc8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x27c>
101620c1c:     	ldr	x8, [sp, #0x20]
101620c20:     	cmp	x0, x8
101620c24:     	b.hs	0x101620dd8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x28c>
101620c28:     	lsl	x8, x0, #6
101620c2c:     	ldr	x9, [sp, #0x10]
101620c30:     	ldr	x9, [x9, x8]
101620c34:     	cbnz	x9, 0x101620c74 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x128>
101620c38:     	b	0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620c3c:     	ldp	q0, q1, [x8]
101620c40:     	stp	q0, q1, [sp, #0x30]
101620c44:     	ldr	x8, [sp, #0x18]
101620c48:     	ldr	x8, [x8]
101620c4c:     	ldr	x1, [x8]
101620c50:     	add	x0, sp, #0x58
101620c54:     	add	x2, sp, #0x30
101620c58:     	bl	0x101635f6c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101620c5c:     	ldr	x8, [sp, #0x58]
101620c60:     	cmp	x8, #0x1
101620c64:     	b.ne	0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620c68:     	ldr	x8, [sp, #0x60]
101620c6c:     	cbz	x8, 0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620c70:     	ldr	x9, [x8]
101620c74:     	add	x8, sp, #0x30
101620c78:     	add	x0, x9, #0x10
101620c7c:     	add	x1, x23, #0x18
101620c80:     	bl	0x102e2c800 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
101620c84:     	ldr	x8, [sp, #0x30]
101620c88:     	cmp	x8, #0x1e
101620c8c:     	b.ne	0x101620d70 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x224>
101620c90:     	ldr	x28, [sp, #0x38]
101620c94:     	ldr	w8, [x23]
101620c98:     	cmp	w8, #0x2
101620c9c:     	b.eq	0x101620cc0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x174>
101620ca0:     	cmp	w8, #0x1
101620ca4:     	b.ne	0x101620d94 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620ca8:     	ldr	x8, [x26], #0x38
101620cac:     	add	x23, x23, #0x38
101620cb0:     	sub	x20, x20, #0x38
101620cb4:     	cmp	x8, x28
101620cb8:     	b.eq	0x101620be4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x98>
101620cbc:     	b	0x101620d94 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620cc0:     	ldur	w8, [x26, #-0x4]
101620cc4:     	ldr	x9, [sp, #0x8]
101620cc8:     	cmp	x9, x8
101620ccc:     	b.ls	0x101620d94 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620cd0:     	ldr	x9, [sp]
101620cd4:     	ldr	x8, [x9, x8, lsl #3]
101620cd8:     	cmp	x8, x24
101620cdc:     	b.hs	0x101620d94 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x248>
101620ce0:     	mov	w9, #0x38               ; =56
101620ce4:     	madd	x25, x8, x9, x21
101620ce8:     	ldr	x0, [x25, #0x30]
101620cec:     	cmp	x0, x19
101620cf0:     	b.hs	0x101620db8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x26c>
101620cf4:     	add	x8, x27, x0, lsl #5
101620cf8:     	ldrb	w9, [x8]
101620cfc:     	cmp	w9, #0x3
101620d00:     	b.ne	0x101620d34 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x1e8>
101620d04:     	ldr	x0, [x8, #0x8]
101620d08:     	ldr	x8, [sp, #0x28]
101620d0c:     	cmp	x0, x8
101620d10:     	b.hs	0x101620dc8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x27c>
101620d14:     	ldr	x8, [sp, #0x20]
101620d18:     	cmp	x0, x8
101620d1c:     	b.hs	0x101620dd8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x28c>
101620d20:     	lsl	x8, x0, #6
101620d24:     	ldr	x9, [sp, #0x10]
101620d28:     	ldr	x9, [x9, x8]
101620d2c:     	cbnz	x9, 0x101620bb0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x64>
101620d30:     	b	0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620d34:     	ldp	q0, q1, [x8]
101620d38:     	stp	q0, q1, [sp, #0x30]
101620d3c:     	ldr	x8, [sp, #0x18]
101620d40:     	ldr	x8, [x8]
101620d44:     	ldr	x1, [x8]
101620d48:     	add	x0, sp, #0x58
101620d4c:     	add	x2, sp, #0x30
101620d50:     	bl	0x101635f6c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101620d54:     	ldr	x8, [sp, #0x58]
101620d58:     	cmp	x8, #0x1
101620d5c:     	b.ne	0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620d60:     	ldr	x8, [sp, #0x60]
101620d64:     	cbz	x8, 0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620d68:     	ldr	x9, [x8]
101620d6c:     	b	0x101620bb0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x64>
101620d70:     	and	x8, x8, #0x1e
101620d74:     	cmp	x8, #0x14
101620d78:     	b.ne	0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620d7c:     	ldr	x1, [sp, #0x38]
101620d80:     	cbz	x1, 0x101620d90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions0_0Es_0s_0EB49_+0x244>
101620d84:     	ldr	x0, [sp, #0x40]
101620d88:     	mov	w2, #0x1                ; =1
101620d8c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101620d90:     	mov	w22, #0x0               ; =0
101620d94:     	mov	x0, x22
101620d98:     	ldp	x29, x30, [sp, #0xc0]
101620d9c:     	ldp	x20, x19, [sp, #0xb0]
101620da0:     	ldp	x22, x21, [sp, #0xa0]
101620da4:     	ldp	x24, x23, [sp, #0x90]
101620da8:     	ldp	x26, x25, [sp, #0x80]
101620dac:     	ldp	x28, x27, [sp, #0x70]
101620db0:     	add	sp, sp, #0xd0
101620db4:     	ret
101620db8:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101620dbc:     	add	x2, x2, #0xc0
101620dc0:     	mov	x1, x19
101620dc4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101620dc8:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101620dcc:     	add	x2, x2, #0xd8
101620dd0:     	ldr	x1, [sp, #0x28]
101620dd4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101620dd8:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101620ddc:     	add	x2, x2, #0xf0
101620de0:     	ldr	x1, [sp, #0x20]
101620de4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
