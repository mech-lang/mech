
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101527cd0 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_>:
101527cd0:     	ldp	x9, x8, [x0]
101527cd4:     	cmp	x9, x8
101527cd8:     	b.eq	0x101527d50 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x80>
101527cdc:     	ldp	x12, x11, [x1]
101527ce0:     	mov	w13, #0x18              ; =24
101527ce4:     	ldr	x14, [x1, #0x28]
101527ce8:     	b	0x101527cf4 <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x24>
101527cec:     	cmp	x9, x8
101527cf0:     	b.eq	0x101527d3c <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x6c>
101527cf4:     	mov	x10, x9
101527cf8:     	ldr	w15, [x9], #0x4
101527cfc:     	cmp	x11, x15
101527d00:     	b.ls	0x101527cec <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
101527d04:     	umaddl	x15, w15, w13, x12
101527d08:     	ldr	x16, [x15]
101527d0c:     	cmp	x16, #0x1
101527d10:     	b.ne	0x101527cec <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
101527d14:     	ldp	x16, x15, [x15, #0x8]
101527d18:     	add	x15, x15, x16
101527d1c:     	cmp	x15, x16
101527d20:     	ccmp	x15, x14, #0x2, hs
101527d24:     	b.hi	0x101527cec <__RINvXs2J_NtNtCsgDHHaSskbIF_4core5slice4iterINtB7_4IterNtNtNtCs1qJAwyMG1lC_11mech_engine15native_artifact7control16NativeMatchValueENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB2V_10Invocation19buffer_frame_actions_0EB33_+0x1c>
101527d28:     	mov	w8, #0x1                ; =1
101527d2c:     	add	x9, x10, #0x4
101527d30:     	str	x9, [x0]
101527d34:     	mov	x0, x8
101527d38:     	ret
101527d3c:     	mov	w8, #0x0                ; =0
101527d40:     	add	x9, x10, #0x4
101527d44:     	str	x9, [x0]
101527d48:     	mov	x0, x8
101527d4c:     	ret
101527d50:     	mov	w0, #0x0                ; =0
101527d54:     	ret
