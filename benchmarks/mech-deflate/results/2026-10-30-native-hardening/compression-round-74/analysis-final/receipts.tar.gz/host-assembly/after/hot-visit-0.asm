
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101521c2c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>:
101521c2c:     	sub	sp, sp, #0x50
101521c30:     	stp	x22, x21, [sp, #0x20]
101521c34:     	stp	x20, x19, [sp, #0x30]
101521c38:     	stp	x29, x30, [sp, #0x40]
101521c3c:     	add	x29, sp, #0x40
101521c40:     	cbz	x0, 0x101521cf4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101521c44:     	ldr	x8, [x0]
101521c48:     	cmp	x8, #0x1
101521c4c:     	b.ne	0x101521c8c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x60>
101521c50:     	ldr	x8, [x1]
101521c54:     	ldr	x9, [x8, #0x10]
101521c58:     	cmp	x9, #0x2
101521c5c:     	b.eq	0x101521cf4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101521c60:     	ldr	x9, [x0, #0x8]
101521c64:     	ldr	x10, [x8, #0x40]
101521c68:     	cmp	x9, x10
101521c6c:     	b.hs	0x101521cf4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101521c70:     	ldr	x8, [x8, #0x38]
101521c74:     	mov	w10, #0x3c8             ; =968
101521c78:     	madd	x8, x9, x10, x8
101521c7c:     	ldr	x8, [x8, #0x290]
101521c80:     	cbz	x8, 0x101521cf4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101521c84:     	mov	x1, x0
101521c88:     	b	0x101521cf8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
101521c8c:     	ldr	x8, [x0, #0x18]
101521c90:     	cbz	x8, 0x101521d50 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x124>
101521c94:     	ldr	x8, [x0, #0x10]
101521c98:     	ldr	w8, [x8]
101521c9c:     	ldr	x9, [x1, #0x20]
101521ca0:     	ldr	x9, [x9]
101521ca4:     	cmp	x9, x8
101521ca8:     	b.ne	0x101521cf4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101521cac:     	ldr	x8, [x1, #0x18]
101521cb0:     	ldr	x8, [x8]
101521cb4:     	cmp	x8, #0x2
101521cb8:     	b.ne	0x101521cf4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101521cbc:     	mov	x21, x1
101521cc0:     	ldr	x9, [x1, #0x8]
101521cc4:     	add	x8, sp, #0x8
101521cc8:     	mov	x20, x0
101521ccc:     	mov	x0, x9
101521cd0:     	bl	0x10236ca38 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget18unscoped_remaining>
101521cd4:     	ldr	x8, [sp, #0x8]
101521cd8:     	cmp	x8, #0x1
101521cdc:     	b.ne	0x101521cf4 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xc8>
101521ce0:     	mov	x0, x20
101521ce4:     	ldr	x8, [sp, #0x10]
101521ce8:     	ldr	x19, [x20, #0x30]
101521cec:     	cmp	x8, x19
101521cf0:     	b.hs	0x101521d10 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xe4>
101521cf4:     	mov	x1, #0x0                ; =0
101521cf8:     	mov	x0, x1
101521cfc:     	ldp	x29, x30, [sp, #0x40]
101521d00:     	ldp	x20, x19, [sp, #0x30]
101521d04:     	ldp	x22, x21, [sp, #0x20]
101521d08:     	add	sp, sp, #0x50
101521d0c:     	ret
101521d10:     	ldr	x8, [x21, #0x10]
101521d14:     	ldr	x9, [x8, #0x18]!
101521d18:     	ldur	x21, [x8, #-0x8]
101521d1c:     	cbz	x9, 0x101521d34 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x108>
101521d20:     	mov	x0, x8
101521d24:     	bl	0x10236d5b4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget4used>
101521d28:     	mov	x8, x0
101521d2c:     	mov	x0, x20
101521d30:     	b	0x101521d38 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x10c>
101521d34:     	ldur	x8, [x8, #-0x10]
101521d38:     	mov	x1, #0x0                ; =0
101521d3c:     	subs	x8, x21, x8
101521d40:     	b.lo	0x101521cf8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
101521d44:     	cmp	x8, x19
101521d48:     	b.hs	0x101521c84 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0x58>
101521d4c:     	b	0x101521cf8 <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_+0xcc>
101521d50:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101521d54:     	add	x2, x2, #0x260
101521d58:     	mov	x0, #0x0                ; =0
101521d5c:     	mov	x1, #0x0                ; =0
101521d60:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
