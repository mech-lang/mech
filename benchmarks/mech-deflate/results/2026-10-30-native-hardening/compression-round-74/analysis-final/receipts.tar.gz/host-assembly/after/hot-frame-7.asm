
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101620de8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_>:
101620de8:     	sub	sp, sp, #0x150
101620dec:     	stp	x28, x27, [sp, #0xf0]
101620df0:     	stp	x26, x25, [sp, #0x100]
101620df4:     	stp	x24, x23, [sp, #0x110]
101620df8:     	stp	x22, x21, [sp, #0x120]
101620dfc:     	stp	x20, x19, [sp, #0x130]
101620e00:     	stp	x29, x30, [sp, #0x140]
101620e04:     	add	x29, sp, #0x140
101620e08:     	mov	x21, x4
101620e0c:     	mov	x25, x2
101620e10:     	mov	x24, x1
101620e14:     	str	x0, [sp, #0x38]
101620e18:     	ldr	x8, [x1, #0x8]
101620e1c:     	stp	x1, x3, [sp, #0x48]
101620e20:     	cbz	x8, 0x101620fb4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1cc>
101620e24:     	ldr	x23, [x24]
101620e28:     	lsl	x20, x8, #2
101620e2c:     	add	x10, x25, #0x10
101620e30:     	ldp	x26, x8, [x21]
101620e34:     	ldp	x9, x11, [x21, #0x28]
101620e38:     	stp	x11, x9, [sp, #0x20]
101620e3c:     	ldp	x9, x11, [x21, #0x10]
101620e40:     	str	x11, [sp, #0x30]
101620e44:     	stp	x10, x9, [sp, #0x10]
101620e48:     	str	x8, [sp, #0x8]
101620e4c:     	add	x27, x8, #0x1
101620e50:     	mov	w8, #0x2c               ; =44
101620e54:     	ldr	w24, [x23], #0x4
101620e58:     	cmp	x3, x24
101620e5c:     	b.ls	0x101621310 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
101620e60:     	strb	w8, [sp, #0x90]
101620e64:     	add	x0, sp, #0x90
101620e68:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101620e6c:     	sub	x27, x27, #0x1
101620e70:     	cbz	x27, 0x101621394 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5ac>
101620e74:     	ldrb	w8, [x26]
101620e78:     	cmp	w8, #0x3
101620e7c:     	b.ne	0x101620eb0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0xc8>
101620e80:     	ldr	x0, [x26, #0x8]
101620e84:     	ldr	x8, [sp, #0x30]
101620e88:     	cmp	x0, x8
101620e8c:     	b.hs	0x1016213d8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5f0>
101620e90:     	ldr	x8, [sp, #0x28]
101620e94:     	cmp	x0, x8
101620e98:     	b.hs	0x1016213e8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x600>
101620e9c:     	lsl	x8, x0, #6
101620ea0:     	ldr	x9, [sp, #0x18]
101620ea4:     	ldr	x8, [x9, x8]
101620ea8:     	cbnz	x8, 0x101620ee8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x100>
101620eac:     	b	0x101620ef0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x108>
101620eb0:     	ldp	q0, q1, [x26]
101620eb4:     	stp	q0, q1, [sp, #0x90]
101620eb8:     	ldr	x8, [sp, #0x20]
101620ebc:     	ldr	x8, [x8]
101620ec0:     	ldr	x1, [x8]
101620ec4:     	add	x0, sp, #0x68
101620ec8:     	add	x2, sp, #0x90
101620ecc:     	bl	0x101635f6c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101620ed0:     	ldr	x8, [sp, #0x68]
101620ed4:     	cmp	x8, #0x1
101620ed8:     	b.ne	0x101620ef0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x108>
101620edc:     	ldr	x8, [sp, #0x70]
101620ee0:     	cbz	x8, 0x101620ef0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x108>
101620ee4:     	ldr	x8, [x8]
101620ee8:     	ldp	x22, x19, [x8, #0x10]
101620eec:     	b	0x101620ef8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x110>
101620ef0:     	mov	x19, #0x0               ; =0
101620ef4:     	mov	w22, #0x8               ; =8
101620ef8:     	mov	x1, x28
101620efc:     	lsl	x28, x19, #3
101620f00:     	lsr	x8, x19, #61
101620f04:     	cmp	x8, #0x0
101620f08:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
101620f0c:     	ccmp	x28, x8, #0x2, eq
101620f10:     	b.hi	0x101620fe0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1f8>
101620f14:     	str	x25, [sp, #0x40]
101620f18:     	cbz	x28, 0x101620f50 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x168>
101620f1c:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101620f20:     	mov	x0, x28
101620f24:     	mov	w1, #0x8                ; =8
101620f28:     	bl	0x100009684 <__RNvCsfBzVIH1HIC6_7___rustc12___rust_alloc>
101620f2c:     	cbz	x0, 0x1016213f8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x610>
101620f30:     	mov	x25, x0
101620f34:     	cbz	x19, 0x101620f48 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x160>
101620f38:     	mov	x0, x25
101620f3c:     	mov	x1, x22
101620f40:     	mov	x2, x28
101620f44:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101620f48:     	mov	x28, x25
101620f4c:     	b	0x101620f58 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x170>
101620f50:     	mov	w28, #0x8               ; =8
101620f54:     	mov	w25, #0x8               ; =8
101620f58:     	ldr	x8, [sp, #0x10]
101620f5c:     	add	x0, x8, x24, lsl #7
101620f60:     	add	x8, sp, #0x90
101620f64:     	mov	x1, x25
101620f68:     	mov	x2, x19
101620f6c:     	bl	0x102da83a0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
101620f70:     	ldr	x8, [sp, #0x90]
101620f74:     	cmp	x8, #0x1e
101620f78:     	ldp	x24, x3, [sp, #0x48]
101620f7c:     	b.ne	0x1016212f0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x508>
101620f80:     	ldr	x8, [sp, #0xa0]
101620f84:     	cbz	x8, 0x101620fa0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1b8>
101620f88:     	ldr	x0, [sp, #0x98]
101620f8c:     	lsl	x1, x8, #3
101620f90:     	mov	w2, #0x8                ; =8
101620f94:     	mov	x19, x3
101620f98:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101620f9c:     	mov	x3, x19
101620fa0:     	add	x26, x26, #0x20
101620fa4:     	sub	x20, x20, #0x4
101620fa8:     	ldr	x25, [sp, #0x40]
101620fac:     	mov	w8, #0x2c               ; =44
101620fb0:     	cbnz	x20, 0x101620e54 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x6c>
101620fb4:     	ldr	x26, [x24, #0x30]
101620fb8:     	lsl	x19, x26, #3
101620fbc:     	lsr	x8, x26, #61
101620fc0:     	cmp	x8, #0x0
101620fc4:     	mov	x8, #0x7ffffffffffffff8 ; =9223372036854775800
101620fc8:     	ccmp	x19, x8, #0x2, eq
101620fcc:     	b.ls	0x101620fe8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x200>
101620fd0:     	mov	x22, #0x0               ; =0
101620fd4:     	mov	x0, x22
101620fd8:     	mov	x1, x19
101620fdc:     	bl	0x103a01dd4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
101620fe0:     	mov	x0, #0x0                ; =0
101620fe4:     	bl	0x103a01dd4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
101620fe8:     	str	x25, [sp, #0x40]
101620fec:     	cbz	x19, 0x101621024 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x23c>
101620ff0:     	bl	0x100023c78 <__RNvCsfBzVIH1HIC6_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
101620ff4:     	mov	w22, #0x8               ; =8
101620ff8:     	mov	x0, x19
101620ffc:     	mov	w1, #0x8                ; =8
101621000:     	bl	0x1000096b8 <__RNvCsfBzVIH1HIC6_7___rustc19___rust_alloc_zeroed>
101621004:     	str	x0, [sp, #0x30]
101621008:     	cbz	x0, 0x101620fd4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x1ec>
10162100c:     	ldp	x25, x8, [x24, #0x10]
101621010:     	lsl	x9, x8, #6
101621014:     	sub	x9, x9, x8, lsl #3
101621018:     	stp	x26, x9, [sp, #0x10]
10162101c:     	cbnz	x8, 0x101621040 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x258>
101621020:     	b	0x10162114c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x364>
101621024:     	mov	w8, #0x8                ; =8
101621028:     	str	x8, [sp, #0x30]
10162102c:     	ldp	x25, x8, [x24, #0x10]
101621030:     	lsl	x9, x8, #6
101621034:     	sub	x9, x9, x8, lsl #3
101621038:     	stp	xzr, x9, [sp, #0x10]
10162103c:     	cbz	x8, 0x10162114c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x364>
101621040:     	ldp	x19, x27, [x21]
101621044:     	add	x28, x25, #0x18
101621048:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
10162104c:     	add	x8, x8, #0xc0
101621050:     	str	x8, [sp, #0x8]
101621054:     	ldp	x8, x9, [x21, #0x28]
101621058:     	stp	x9, x8, [sp, #0x20]
10162105c:     	ldr	x20, [sp, #0x18]
101621060:     	ldp	x23, x22, [x21, #0x10]
101621064:     	b	0x10162107c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x294>
101621068:     	ldr	x8, [sp, #0x30]
10162106c:     	str	x1, [x8, x0, lsl #3]
101621070:     	add	x28, x28, #0x38
101621074:     	subs	x20, x20, #0x38
101621078:     	b.eq	0x10162114c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x364>
10162107c:     	ldr	x0, [x28, #0x18]
101621080:     	cmp	x0, x27
101621084:     	b.hs	0x1016213c8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5e0>
101621088:     	add	x8, x19, x0, lsl #5
10162108c:     	ldrb	w9, [x8]
101621090:     	cmp	w9, #0x3
101621094:     	b.ne	0x1016210c0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x2d8>
101621098:     	ldr	x0, [x8, #0x8]
10162109c:     	cmp	x0, x22
1016210a0:     	b.hs	0x1016213a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5c0>
1016210a4:     	ldr	x8, [sp, #0x28]
1016210a8:     	cmp	x0, x8
1016210ac:     	b.hs	0x1016213b8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5d0>
1016210b0:     	lsl	x8, x0, #6
1016210b4:     	ldr	x24, [x23, x8]
1016210b8:     	cbnz	x24, 0x1016210f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x30c>
1016210bc:     	b	0x1016212ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
1016210c0:     	ldp	q0, q1, [x8]
1016210c4:     	stp	q0, q1, [sp, #0x90]
1016210c8:     	ldr	x8, [sp, #0x20]
1016210cc:     	ldr	x8, [x8]
1016210d0:     	ldr	x1, [x8]
1016210d4:     	add	x0, sp, #0x68
1016210d8:     	add	x2, sp, #0x90
1016210dc:     	bl	0x101635f6c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1016210e0:     	ldp	x9, x8, [sp, #0x68]
1016210e4:     	cmp	x9, #0x1
1016210e8:     	ccmp	x8, #0x0, #0x4, eq
1016210ec:     	b.eq	0x1016212ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
1016210f0:     	ldr	x24, [x8]
1016210f4:     	mov	w8, #0x2c               ; =44
1016210f8:     	strb	w8, [sp, #0x90]
1016210fc:     	add	x0, sp, #0x90
101621100:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101621104:     	add	x8, sp, #0x90
101621108:     	add	x0, x24, #0x10
10162110c:     	mov	x1, x28
101621110:     	bl	0x102e2c800 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
101621114:     	ldp	x8, x1, [sp, #0x90]
101621118:     	cmp	x8, #0x1e
10162111c:     	b.ne	0x101621290 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4a8>
101621120:     	ldur	w8, [x28, #-0x18]
101621124:     	cmp	w8, #0x2
101621128:     	b.ne	0x101621070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x288>
10162112c:     	ldur	w0, [x28, #-0x14]
101621130:     	cmp	x26, x0
101621134:     	b.hi	0x101621068 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x280>
101621138:     	adrp	x2, 0x107f0f000 <_anon.797b2294c71d6bb404c294e7e4131068.123+0x2a0>
10162113c:     	add	x2, x2, #0xf10
101621140:     	mov	x1, x26
101621144:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621148:     	b	0x101621440 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x658>
10162114c:     	ldp	x9, x8, [sp, #0x48]
101621150:     	ldr	w19, [x9, #0x38]
101621154:     	cmp	x8, x19
101621158:     	b.ls	0x1016212ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
10162115c:     	mov	w24, #0x2c              ; =44
101621160:     	strb	w24, [sp, #0x90]
101621164:     	add	x0, sp, #0x90
101621168:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
10162116c:     	ldr	x8, [sp, #0x40]
101621170:     	add	x9, x8, x19, lsl #7
101621174:     	add	x8, sp, #0x68
101621178:     	add	x0, x9, #0x10
10162117c:     	ldr	x1, [sp, #0x30]
101621180:     	mov	x2, x26
101621184:     	bl	0x102da83a0 <__RNvMNtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_6Schema17instantiate_shape>
101621188:     	ldr	x8, [sp, #0x68]
10162118c:     	cmp	x8, #0x1e
101621190:     	b.ne	0x1016212d4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4ec>
101621194:     	ldp	x8, x20, [sp, #0x70]
101621198:     	str	x8, [sp, #0x30]
10162119c:     	stp	x8, x20, [sp, #0x58]
1016211a0:     	ldp	x26, x23, [x21]
1016211a4:     	ldp	x28, x9, [x21, #0x28]
1016211a8:     	ldp	x21, x27, [x21, #0x10]
1016211ac:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016211b0:     	add	x8, x8, #0xc0
1016211b4:     	stp	x8, x9, [sp, #0x48]
1016211b8:     	ldr	x22, [sp, #0x18]
1016211bc:     	cbz	x22, 0x10162133c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x554>
1016211c0:     	ldr	x0, [x25, #0x30]
1016211c4:     	cmp	x0, x23
1016211c8:     	b.hs	0x101621404 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x61c>
1016211cc:     	add	x8, x26, x0, lsl #5
1016211d0:     	ldrb	w9, [x8]
1016211d4:     	cmp	w9, #0x3
1016211d8:     	b.ne	0x101621200 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x418>
1016211dc:     	ldr	x0, [x8, #0x8]
1016211e0:     	cmp	x0, x27
1016211e4:     	b.hs	0x10162140c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x624>
1016211e8:     	cmp	x0, x28
1016211ec:     	b.hs	0x101621420 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x638>
1016211f0:     	lsl	x8, x0, #6
1016211f4:     	ldr	x19, [x21, x8]
1016211f8:     	cbnz	x19, 0x101621238 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x450>
1016211fc:     	b	0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
101621200:     	ldp	q0, q1, [x8]
101621204:     	stp	q0, q1, [sp, #0x90]
101621208:     	ldr	x8, [sp, #0x50]
10162120c:     	ldr	x8, [x8]
101621210:     	ldr	x1, [x8]
101621214:     	sub	x0, x29, #0x70
101621218:     	add	x2, sp, #0x90
10162121c:     	bl	0x101635f6c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101621220:     	ldur	x8, [x29, #-0x70]
101621224:     	cmp	x8, #0x1
101621228:     	b.ne	0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
10162122c:     	ldur	x8, [x29, #-0x68]
101621230:     	cbz	x8, 0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
101621234:     	ldr	x19, [x8]
101621238:     	strb	w24, [sp, #0x90]
10162123c:     	add	x0, sp, #0x90
101621240:     	bl	0x101633094 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101621244:     	add	x8, sp, #0x68
101621248:     	add	x0, x19, #0x10
10162124c:     	add	x1, x25, #0x18
101621250:     	bl	0x102e2c800 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
101621254:     	ldp	x8, x19, [sp, #0x68]
101621258:     	cmp	x8, #0x1e
10162125c:     	b.ne	0x101621344 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x55c>
101621260:     	add	x8, sp, #0x90
101621264:     	add	x0, sp, #0x58
101621268:     	mov	x1, x25
10162126c:     	bl	0x102e2c800 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
101621270:     	ldp	x8, x1, [sp, #0x90]
101621274:     	cmp	x8, #0x1e
101621278:     	b.ne	0x101621360 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x578>
10162127c:     	add	x25, x25, #0x38
101621280:     	sub	x22, x22, #0x38
101621284:     	cmp	x1, x19
101621288:     	b.eq	0x1016211bc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x3d4>
10162128c:     	b	0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
101621290:     	and	x8, x8, #0x1e
101621294:     	cmp	x8, #0x14
101621298:     	b.ne	0x1016212ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
10162129c:     	cbz	x1, 0x1016212ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4c4>
1016212a0:     	ldr	x0, [sp, #0xa0]
1016212a4:     	mov	w2, #0x1                ; =1
1016212a8:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1016212ac:     	mov	w8, #0x2c               ; =44
1016212b0:     	ldr	x9, [sp, #0x38]
1016212b4:     	strb	w8, [x9]
1016212b8:     	ldr	x8, [sp, #0x10]
1016212bc:     	cbz	x8, 0x10162131c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x534>
1016212c0:     	lsl	x1, x8, #3
1016212c4:     	ldr	x0, [sp, #0x30]
1016212c8:     	mov	w2, #0x8                ; =8
1016212cc:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1016212d0:     	b	0x10162131c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x534>
1016212d4:     	and	x8, x8, #0x1e
1016212d8:     	cmp	x8, #0x14
1016212dc:     	b.ne	0x101621310 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
1016212e0:     	ldr	x1, [sp, #0x70]
1016212e4:     	cbz	x1, 0x101621310 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
1016212e8:     	ldr	x0, [sp, #0x78]
1016212ec:     	b	0x101621308 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x520>
1016212f0:     	and	x8, x8, #0x1e
1016212f4:     	cmp	x8, #0x14
1016212f8:     	b.ne	0x101621310 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
1016212fc:     	ldr	x1, [sp, #0x98]
101621300:     	cbz	x1, 0x101621310 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x528>
101621304:     	ldr	x0, [sp, #0xa0]
101621308:     	mov	w2, #0x1                ; =1
10162130c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
101621310:     	mov	w8, #0x2c               ; =44
101621314:     	ldr	x9, [sp, #0x38]
101621318:     	strb	w8, [x9]
10162131c:     	ldp	x29, x30, [sp, #0x140]
101621320:     	ldp	x20, x19, [sp, #0x130]
101621324:     	ldp	x22, x21, [sp, #0x120]
101621328:     	ldp	x24, x23, [sp, #0x110]
10162132c:     	ldp	x26, x25, [sp, #0x100]
101621330:     	ldp	x28, x27, [sp, #0xf0]
101621334:     	add	sp, sp, #0x150
101621338:     	ret
10162133c:     	mov	w8, #0x2e               ; =46
101621340:     	b	0x101621380 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x598>
101621344:     	and	x8, x8, #0x1e
101621348:     	cmp	x8, #0x14
10162134c:     	b.ne	0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
101621350:     	cbz	x19, 0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
101621354:     	ldr	x0, [sp, #0x78]
101621358:     	mov	x1, x19
10162135c:     	b	0x101621374 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x58c>
101621360:     	and	x8, x8, #0x1e
101621364:     	cmp	x8, #0x14
101621368:     	b.ne	0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
10162136c:     	cbz	x1, 0x10162137c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x594>
101621370:     	ldr	x0, [sp, #0xa0]
101621374:     	mov	w2, #0x1                ; =1
101621378:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10162137c:     	mov	w8, #0x2c               ; =44
101621380:     	ldr	x9, [sp, #0x38]
101621384:     	strb	w8, [x9]
101621388:     	cbz	x20, 0x10162131c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x534>
10162138c:     	lsl	x1, x20, #3
101621390:     	b	0x1016212c4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x4dc>
101621394:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101621398:     	add	x2, x2, #0xc0
10162139c:     	ldr	x0, [sp, #0x8]
1016213a0:     	mov	x1, x0
1016213a4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016213a8:     	mov	x27, x22
1016213ac:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016213b0:     	add	x8, x8, #0xd8
1016213b4:     	b	0x1016213c4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x5dc>
1016213b8:     	ldr	x27, [sp, #0x28]
1016213bc:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016213c0:     	add	x8, x8, #0xf0
1016213c4:     	str	x8, [sp, #0x8]
1016213c8:     	mov	x1, x27
1016213cc:     	ldr	x2, [sp, #0x8]
1016213d0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016213d4:     	b	0x101621440 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x658>
1016213d8:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016213dc:     	add	x2, x2, #0xd8
1016213e0:     	ldr	x1, [sp, #0x30]
1016213e4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016213e8:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
1016213ec:     	add	x2, x2, #0xf0
1016213f0:     	ldr	x1, [sp, #0x28]
1016213f4:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1016213f8:     	mov	x1, x28
1016213fc:     	mov	w0, #0x8                ; =8
101621400:     	bl	0x103a01dd4 <__RNvNtCsgKscDXrlV49_5alloc7raw_vec12handle_error>
101621404:     	str	x20, [sp, #0x10]
101621408:     	b	0x101621434 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x64c>
10162140c:     	str	x20, [sp, #0x10]
101621410:     	mov	x23, x27
101621414:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101621418:     	add	x8, x8, #0xd8
10162141c:     	b	0x101621430 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x648>
101621420:     	str	x20, [sp, #0x10]
101621424:     	mov	x23, x28
101621428:     	adrp	x8, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
10162142c:     	add	x8, x8, #0xf0
101621430:     	str	x8, [sp, #0x48]
101621434:     	mov	x1, x23
101621438:     	ldr	x2, [sp, #0x48]
10162143c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621440:     	brk	#0x1
101621444:     	b	0x10162145c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x674>
101621448:     	mov	x19, x0
10162144c:     	str	x20, [sp, #0x10]
101621450:     	cbnz	x20, 0x101621468 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x680>
101621454:     	b	0x10162147c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x694>
101621458:     	b	0x10162145c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x674>
10162145c:     	mov	x19, x0
101621460:     	ldr	x8, [sp, #0x10]
101621464:     	cbz	x8, 0x10162147c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe8validateNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB3T_10Invocation19buffer_frame_actions0_0Es_0s0_0EB41_+0x694>
101621468:     	ldr	x8, [sp, #0x10]
10162146c:     	lsl	x1, x8, #3
101621470:     	ldr	x0, [sp, #0x30]
101621474:     	mov	w2, #0x8                ; =8
101621478:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
10162147c:     	mov	x0, x19
101621480:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
