
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023728b0 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped>:
1023728b0:     	sub	sp, sp, #0x40
1023728b4:     	stp	x20, x19, [sp, #0x20]
1023728b8:     	stp	x29, x30, [sp, #0x30]
1023728bc:     	add	x29, sp, #0x30
1023728c0:     	ldr	x19, [x0]
1023728c4:     	ldr	x9, [x19, #0x10]
1023728c8:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1023728cc:     	cmp	x9, x10
1023728d0:     	b.hs	0x102372974 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0xc4>
1023728d4:     	ldr	x9, [x19, #0x38]
1023728d8:     	adds	x9, x9, x2
1023728dc:     	b.hs	0x102372980 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0xd0>
1023728e0:     	cmp	x9, x3
1023728e4:     	b.ls	0x102372900 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x50>
1023728e8:     	mov	w10, #0x606             ; =1542
1023728ec:     	strh	w10, [x8]
1023728f0:     	mov	w10, #0x1               ; =1
1023728f4:     	strb	w10, [x8, #0x2]
1023728f8:     	stp	x9, x3, [x8, #0x8]
1023728fc:     	b	0x102372964 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0xb4>
102372900:     	ldr	x9, [x1, #0x20]
102372904:     	cmp	x9, x10
102372908:     	b.hs	0x102372988 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0xd8>
10237290c:     	ldr	x9, [x1, #0x28]
102372910:     	cbz	x9, 0x102372924 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x74>
102372914:     	cmp	x9, x19
102372918:     	b.eq	0x102372924 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x74>
10237291c:     	strb	wzr, [x8]
102372920:     	b	0x102372964 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0xb4>
102372924:     	ldr	x9, [x19, #0x10]
102372928:     	cbnz	x9, 0x102372994 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0xe4>
10237292c:     	mov	x9, #-0x1               ; =-1
102372930:     	str	x9, [x19, #0x10]
102372934:     	ldr	q0, [x1, #0x30]
102372938:     	str	q0, [sp]
10237293c:     	ldr	x9, [x1, #0x40]
102372940:     	str	x9, [sp, #0x10]
102372944:     	add	x1, x19, #0x18
102372948:     	mov	x4, sp
10237294c:     	mov	x0, x8
102372950:     	mov	x3, #0x0                ; =0
102372954:     	bl	0x102381918 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget32charge_control_account_at_limits>
102372958:     	ldr	x8, [x19, #0x10]
10237295c:     	add	x8, x8, #0x1
102372960:     	str	x8, [x19, #0x10]
102372964:     	ldp	x29, x30, [sp, #0x30]
102372968:     	ldp	x20, x19, [sp, #0x20]
10237296c:     	add	sp, sp, #0x40
102372970:     	ret
102372974:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
102372978:     	add	x0, x0, #0x130
10237297c:     	bl	0x103a01f28 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102372980:     	mov	x9, #-0x1               ; =-1
102372984:     	b	0x1023728e8 <__RNvMs_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget19native_work_contextNtB6_23NativeLibraryWorkBudget32charge_compute_with_limit_scoped+0x38>
102372988:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
10237298c:     	add	x0, x0, #0xe8
102372990:     	bl	0x103a01f28 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102372994:     	adrp	x0, 0x108034000 <_anon.b751fc49bcc701379c8af7be5d8e914b.511+0x50>
102372998:     	add	x0, x0, #0x100
10237299c:     	bl	0x103a01ef8 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1023729a0:     	ldr	x8, [x19, #0x10]
1023729a4:     	add	x8, x8, #0x1
1023729a8:     	str	x8, [x19, #0x10]
1023729ac:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
