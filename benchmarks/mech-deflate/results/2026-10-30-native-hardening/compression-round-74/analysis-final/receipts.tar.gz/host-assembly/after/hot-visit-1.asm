
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010153f4b8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit>:
10153f4b8:     	stp	x28, x27, [sp, #-0x60]!
10153f4bc:     	stp	x26, x25, [sp, #0x10]
10153f4c0:     	stp	x24, x23, [sp, #0x20]
10153f4c4:     	stp	x22, x21, [sp, #0x30]
10153f4c8:     	stp	x20, x19, [sp, #0x40]
10153f4cc:     	stp	x29, x30, [sp, #0x50]
10153f4d0:     	add	x29, sp, #0x50
10153f4d4:     	sub	sp, sp, #0x2f0
10153f4d8:     	mov	x19, x8
10153f4dc:     	ldr	x8, [x0, #0x238]
10153f4e0:     	ldr	w9, [x0, #0x268]
10153f4e4:     	cmp	x8, #0x3
10153f4e8:     	ccmp	w9, #0x0, #0x4, ne
10153f4ec:     	b.ne	0x10153f520 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x68>
10153f4f0:     	ldr	x8, [x0, #0xc0]
10153f4f4:     	cmp	x8, #0x2
10153f4f8:     	b.ne	0x10153f53c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x84>
10153f4fc:     	ldr	x8, [x0, #0xa8]
10153f500:     	cbz	x8, 0x10153f578 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc0>
10153f504:     	str	wzr, [x19]
10153f508:     	mov	w8, #0xc                ; =12
10153f50c:     	strb	w8, [x19, #0x8]
10153f510:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f514:     	add	x8, x8, #0x2da
10153f518:     	mov	w9, #0x2a               ; =42
10153f51c:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f520:     	str	wzr, [x19]
10153f524:     	mov	w8, #0xc                ; =12
10153f528:     	strb	w8, [x19, #0x8]
10153f52c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f530:     	add	x8, x8, #0x462
10153f534:     	mov	w9, #0x24               ; =36
10153f538:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f53c:     	str	wzr, [x19]
10153f540:     	mov	w8, #0xc                ; =12
10153f544:     	strb	w8, [x19, #0x8]
10153f548:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f54c:     	add	x8, x8, #0x2a6
10153f550:     	mov	w9, #0x34               ; =52
10153f554:     	stp	x8, x9, [x19, #0x10]
10153f558:     	add	sp, sp, #0x2f0
10153f55c:     	ldp	x29, x30, [sp, #0x50]
10153f560:     	ldp	x20, x19, [sp, #0x40]
10153f564:     	ldp	x22, x21, [sp, #0x30]
10153f568:     	ldp	x24, x23, [sp, #0x20]
10153f56c:     	ldp	x26, x25, [sp, #0x10]
10153f570:     	ldp	x28, x27, [sp], #0x60
10153f574:     	ret
10153f578:     	mov	x20, x1
10153f57c:     	ldrb	w8, [x0, #0x510]
10153f580:     	tbz	w8, #0x0, 0x10153f5bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
10153f584:     	ldr	x8, [x0, #0x4a0]
10153f588:     	ldr	w9, [x8, #0x300]
10153f58c:     	cmp	w9, #0x1
10153f590:     	b.ne	0x10153f5bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
10153f594:     	ldr	w8, [x8, #0x304]
10153f598:     	cmp	x20, x8
10153f59c:     	b.ne	0x10153f5bc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x104>
10153f5a0:     	str	wzr, [x19]
10153f5a4:     	mov	w8, #0xc                ; =12
10153f5a8:     	strb	w8, [x19, #0x8]
10153f5ac:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f5b0:     	add	x8, x8, #0x42a
10153f5b4:     	mov	w9, #0x38               ; =56
10153f5b8:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f5bc:     	ldr	x24, [x0, #0x490]
10153f5c0:     	ldr	w8, [x24, #0x2f0]
10153f5c4:     	tbz	w8, #0x0, 0x10153f5ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
10153f5c8:     	ldr	w1, [x24, #0x2f4]
10153f5cc:     	mov	x21, x0
10153f5d0:     	bl	0x10153ef2c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation15action_required>
10153f5d4:     	mov	x8, x0
10153f5d8:     	mov	x0, x21
10153f5dc:     	ldr	x24, [x21, #0x490]
10153f5e0:     	tbz	w8, #0x0, 0x10153f5ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x134>
10153f5e4:     	ldrb	w8, [x24, #0x460]
10153f5e8:     	tbz	w8, #0x0, 0x10153f6e8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x230>
10153f5ec:     	ldr	x21, [x0, #0x4a0]
10153f5f0:     	ldr	w9, [x24, #0xb8]
10153f5f4:     	ldr	w8, [x24, #0x2f0]
10153f5f8:     	cmp	w9, #0x1
10153f5fc:     	b.ne	0x10153f634 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x17c>
10153f600:     	tbz	w8, #0x0, 0x10153f618 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x160>
10153f604:     	ldp	w22, w8, [x24, #0xbc]
10153f608:     	ldr	w9, [x24, #0x2f4]
10153f60c:     	cmp	x20, x8
10153f610:     	ccmp	w9, w22, #0x0, eq
10153f614:     	b.eq	0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f618:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f61c:     	add	x8, x8, #0x1f8
10153f620:     	mov	w9, #0x26               ; =38
10153f624:     	str	wzr, [x19]
10153f628:     	mov	w10, #0xc               ; =12
10153f62c:     	str	w10, [x19, #0x8]
10153f630:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f634:     	ldr	w22, [x24, #0x2f4]
10153f638:     	tbz	w8, #0x0, 0x10153f6c8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x210>
10153f63c:     	ldr	x8, [x21, #0x590]
10153f640:     	cmp	x8, x22
10153f644:     	b.ls	0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f648:     	ldr	x8, [x21, #0x588]
10153f64c:     	add	x8, x8, x22, lsl #4
10153f650:     	ldr	x9, [x8]
10153f654:     	cmp	x9, #0x1
10153f658:     	b.ne	0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f65c:     	ldr	x8, [x8, #0x8]
10153f660:     	ldr	x1, [x21, #0x580]
10153f664:     	cmp	x8, x1
10153f668:     	b.hs	0x1015401a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcec>
10153f66c:     	ldr	x9, [x21, #0x578]
10153f670:     	mov	w10, #0x38              ; =56
10153f674:     	madd	x8, x8, x10, x9
10153f678:     	ldr	x9, [x8]
10153f67c:     	cmp	x9, #0x1
10153f680:     	b.ne	0x10153f704 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x24c>
10153f684:     	ldr	x9, [x24, #0x10]
10153f688:     	cmp	x9, #0x2
10153f68c:     	b.eq	0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f690:     	ldr	x9, [x8, #0x8]
10153f694:     	ldr	x10, [x24, #0x40]
10153f698:     	cmp	x9, x10
10153f69c:     	b.hs	0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f6a0:     	ldr	x10, [x24, #0x38]
10153f6a4:     	mov	w11, #0x3c8             ; =968
10153f6a8:     	madd	x9, x9, x11, x10
10153f6ac:     	ldr	x9, [x9, #0x290]
10153f6b0:     	cbz	x9, 0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f6b4:     	ldr	x9, [x8, #0x18]
10153f6b8:     	cbz	x9, 0x101540190 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153f6bc:     	ldr	x9, [x8, #0x10]
10153f6c0:     	ldr	w9, [x9]
10153f6c4:     	b	0x10153f728 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x270>
10153f6c8:     	mov	w25, #0x0               ; =0
10153f6cc:     	mov	w23, #0x0               ; =0
10153f6d0:     	add	x27, sp, #0x130
10153f6d4:     	mov	x28, x0
10153f6d8:     	ldr	x26, [x28, #0xf8]!
10153f6dc:     	cmp	x26, #0x2
10153f6e0:     	b.eq	0x10153f764 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
10153f6e4:     	b	0x10153f87c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
10153f6e8:     	str	wzr, [x19]
10153f6ec:     	mov	w8, #0xc                ; =12
10153f6f0:     	strb	w8, [x19, #0x8]
10153f6f4:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f6f8:     	add	x8, x8, #0x304
10153f6fc:     	mov	w9, #0x25               ; =37
10153f700:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153f704:     	ldr	x9, [x8, #0x18]
10153f708:     	cbz	x9, 0x101540190 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153f70c:     	ldr	w9, [x24, #0x340]
10153f710:     	tbz	w9, #0x0, 0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f714:     	ldr	x9, [x8, #0x10]
10153f718:     	ldr	w9, [x9]
10153f71c:     	ldr	w10, [x24, #0x344]
10153f720:     	cmp	w10, w9
10153f724:     	b.ne	0x10153f748 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x290>
10153f728:     	cmp	w22, w9
10153f72c:     	b.ne	0x10153f834 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x37c>
10153f730:     	lsr	x9, x20, #32
10153f734:     	cbz	x9, 0x10153f844 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x38c>
10153f738:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f73c:     	add	x8, x8, #0x248
10153f740:     	mov	w9, #0x1a               ; =26
10153f744:     	b	0x10153f624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
10153f748:     	mov	w25, #0x1               ; =1
10153f74c:     	mov	w23, #0x1               ; =1
10153f750:     	add	x27, sp, #0x130
10153f754:     	mov	x28, x0
10153f758:     	ldr	x26, [x28, #0xf8]!
10153f75c:     	cmp	x26, #0x2
10153f760:     	b.ne	0x10153f87c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3c4>
10153f764:     	cbz	w23, 0x10153f818 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x360>
10153f768:     	mov	w2, w22
10153f76c:     	ldr	x8, [x21, #0x188]
10153f770:     	cmp	x8, x2
10153f774:     	b.ls	0x10153fd20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
10153f778:     	ldr	x8, [x21, #0x180]
10153f77c:     	ldr	x8, [x8, x2, lsl #3]
10153f780:     	cbz	x8, 0x10153fd20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
10153f784:     	sub	x8, x8, #0x1
10153f788:     	and	x9, x8, #0x3
10153f78c:     	cmp	x9, #0x2
10153f790:     	b.ne	0x10153fd20 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x868>
10153f794:     	lsr	x8, x8, #2
10153f798:     	ldr	x1, [x21, #0x160]
10153f79c:     	cmp	x8, x1
10153f7a0:     	b.hs	0x1015401b4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcfc>
10153f7a4:     	ldr	x9, [x21, #0x158]
10153f7a8:     	mov	w10, #0x48              ; =72
10153f7ac:     	madd	x9, x8, x10, x9
10153f7b0:     	ldr	w10, [x9, #0x40]
10153f7b4:     	cmp	x20, x10
10153f7b8:     	b.ne	0x10153f808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
10153f7bc:     	ldr	w10, [x24, #0x2e8]
10153f7c0:     	cmp	w10, #0x1
10153f7c4:     	b.ne	0x10153f808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
10153f7c8:     	ldr	w10, [x9, #0x30]
10153f7cc:     	ldr	w11, [x24, #0x2ec]
10153f7d0:     	cmp	w11, w10
10153f7d4:     	b.ne	0x10153f808 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x350>
10153f7d8:     	ldr	w9, [x9, #0x34]
10153f7dc:     	mov	w10, #0x1               ; =1
10153f7e0:     	orr	x9, x10, x9, lsl #1
10153f7e4:     	ldr	x1, [x0, #0x4c0]
10153f7e8:     	cmp	x9, x1
10153f7ec:     	b.hs	0x101540204 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd4c>
10153f7f0:     	ldr	x10, [x0, #0x4b8]
10153f7f4:     	ldr	x9, [x10, x9, lsl #3]
10153f7f8:     	ldr	x10, [x0, #0xc0]
10153f7fc:     	cmp	x9, #0x0
10153f800:     	ccmp	x10, #0x2, #0x0, eq
10153f804:     	b.eq	0x10153fd08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x850>
10153f808:     	adrp	x8, 0x107550000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x25f0>
10153f80c:     	add	x8, x8, #0xec0
10153f810:     	mov	w9, #0x35               ; =53
10153f814:     	b	0x10153fd40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x888>
10153f818:     	ldrb	w8, [x24, #0x338]
10153f81c:     	cmp	w8, #0x1
10153f820:     	b.ne	0x10153f82c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x374>
10153f824:     	ldr	x8, [x0, #0x4c8]
10153f828:     	cbnz	x8, 0x10153fd34 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x87c>
10153f82c:     	str	x20, [sp, #0x20]
10153f830:     	b	0x10153f9d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x520>
10153f834:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153f838:     	add	x8, x8, #0x262
10153f83c:     	mov	w9, #0x1a               ; =26
10153f840:     	b	0x10153f624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
10153f844:     	mov	x25, x0
10153f848:     	mov	x0, x8
10153f84c:     	mov	x1, x20
10153f850:     	bl	0x101517e70 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB2_5Group11predecessor>
10153f854:     	tbz	w0, #0x0, 0x10153fcf8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x840>
10153f858:     	mov	x22, x1
10153f85c:     	mov	w23, #0x1               ; =1
10153f860:     	mov	x0, x25
10153f864:     	mov	w25, #0x1               ; =1
10153f868:     	add	x27, sp, #0x130
10153f86c:     	mov	x28, x0
10153f870:     	ldr	x26, [x28, #0xf8]!
10153f874:     	cmp	x26, #0x2
10153f878:     	b.eq	0x10153f764 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x2ac>
10153f87c:     	cbz	w23, 0x10153f99c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e4>
10153f880:     	mov	w2, w22
10153f884:     	str	w23, [sp, #0x1c]
10153f888:     	ldr	x1, [x21, #0x380]
10153f88c:     	cmp	x1, x2
10153f890:     	b.ls	0x10154016c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcb4>
10153f894:     	mov	x23, x25
10153f898:     	ldr	x8, [x21, #0x378]
10153f89c:     	mov	w9, #0x170              ; =368
10153f8a0:     	umaddl	x8, w2, w9, x8
10153f8a4:     	ldp	x10, x9, [x8]
10153f8a8:     	mov	w11, #0x11              ; =17
10153f8ac:     	eor	x10, x10, x11
10153f8b0:     	orr	x9, x10, x9
10153f8b4:     	cbnz	x9, 0x10153f980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4c8>
10153f8b8:     	ldr	x1, [x21, #0x390]
10153f8bc:     	ldr	w25, [x8, #0x10]
10153f8c0:     	cmp	x1, x25
10153f8c4:     	b.ls	0x101540180 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcc8>
10153f8c8:     	ldr	x8, [x21, #0x388]
10153f8cc:     	mov	w9, #0x180              ; =384
10153f8d0:     	umaddl	x27, w25, w9, x8
10153f8d4:     	ldp	x9, x8, [x27]
10153f8d8:     	mov	w10, #0x5               ; =5
10153f8dc:     	eor	x9, x9, x10
10153f8e0:     	orr	x8, x9, x8
10153f8e4:     	cbnz	x8, 0x10153f980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4c8>
10153f8e8:     	ldr	x8, [x21, #0x558]
10153f8ec:     	cmp	x8, x2
10153f8f0:     	b.ls	0x10153f90c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x454>
10153f8f4:     	ldr	x8, [x21, #0x550]
10153f8f8:     	mov	w9, #0x28               ; =40
10153f8fc:     	umull	x9, w2, w9
10153f900:     	ldr	w8, [x8, x9]
10153f904:     	cmp	w8, #0x5
10153f908:     	b.ne	0x10153f950 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x498>
10153f90c:     	str	x0, [sp, #0x10]
10153f910:     	mov	x0, x24
10153f914:     	mov	x1, x21
10153f918:     	bl	0x10154fdc0 <__RNvMs_NtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime4maps5owner9map_callsNtNtBa_10invocation10Invocation22retained_native_action>
10153f91c:     	mov	x8, x0
10153f920:     	ldr	x0, [sp, #0x10]
10153f924:     	tbnz	w8, #0x0, 0x10153f950 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x498>
10153f928:     	ldr	x1, [x21, #0x360]
10153f92c:     	ldr	w8, [x27, #0x30]
10153f930:     	cmp	x1, x8
10153f934:     	b.ls	0x1015401c4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd0c>
10153f938:     	ldr	x9, [x21, #0x358]
10153f93c:     	mov	w10, #0x140             ; =320
10153f940:     	umaddl	x8, w8, w10, x9
10153f944:     	ldrb	w8, [x8, #0x124]
10153f948:     	cmp	w8, #0x7
10153f94c:     	b.eq	0x10153f980 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4c8>
10153f950:     	mov	x1, x0
10153f954:     	add	x0, sp, #0x188
10153f958:     	mov	x21, x1
10153f95c:     	mov	x2, x25
10153f960:     	mov	w3, #0x1                ; =1
10153f964:     	bl	0x10153f120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
10153f968:     	ldr	w8, [sp, #0x188]
10153f96c:     	cmp	w8, #0x6
10153f970:     	b.ne	0x10153fb38 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x680>
10153f974:     	mov	x0, x21
10153f978:     	ldr	x26, [x21, #0xf8]
10153f97c:     	ldr	x21, [x21, #0x4a0]
10153f980:     	str	x20, [sp, #0x20]
10153f984:     	cmp	x26, #0x2
10153f988:     	add	x27, sp, #0x130
10153f98c:     	mov	x25, x23
10153f990:     	ldr	w23, [sp, #0x1c]
10153f994:     	b.ne	0x10153f9a0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x4e8>
10153f998:     	b	0x10153f9d8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x520>
10153f99c:     	str	x20, [sp, #0x20]
10153f9a0:     	ldr	x9, [x21, #0x5a0]
10153f9a4:     	ldr	x8, [x0, #0x1c0]
10153f9a8:     	cmp	x8, x9
10153f9ac:     	b.hs	0x10153fafc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x644>
10153f9b0:     	ldr	x9, [x21, #0x598]
10153f9b4:     	mov	w10, #0x58              ; =88
10153f9b8:     	madd	x8, x8, x10, x9
10153f9bc:     	mov	x24, x0
10153f9c0:     	mov	x0, x8
10153f9c4:     	mov	x1, x20
10153f9c8:     	bl	0x1015182c4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare8parallelNtB2_6Region8contains>
10153f9cc:     	mov	x8, x0
10153f9d0:     	mov	x0, x24
10153f9d4:     	tbz	w8, #0x0, 0x10153fafc <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x644>
10153f9d8:     	ldr	x8, [x21, #0x380]
10153f9dc:     	cmp	x20, x8
10153f9e0:     	b.hs	0x10153fb18 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x660>
10153f9e4:     	ldr	x24, [x21, #0x378]
10153f9e8:     	mov	x1, x0
10153f9ec:     	add	x0, sp, #0x188
10153f9f0:     	mov	x21, x1
10153f9f4:     	mov	x2, x20
10153f9f8:     	bl	0x10154ae00 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation5joinsNtB6_10Invocation31validate_selected_join_boundary>
10153f9fc:     	ldr	w8, [sp, #0x188]
10153fa00:     	cmp	w8, #0x6
10153fa04:     	b.ne	0x10153ff28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153fa08:     	mov	w8, #0x170              ; =368
10153fa0c:     	madd	x24, x20, x8, x24
10153fa10:     	mov	x8, x21
10153fa14:     	ldr	x9, [x21, #0x490]
10153fa18:     	ldr	x10, [x9, #0x1e0]
10153fa1c:     	mov	x11, #-0x8000000000000000 ; =-9223372036854775808
10153fa20:     	cmp	x10, x11
10153fa24:     	b.eq	0x10153fa50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x598>
10153fa28:     	ldr	x1, [x9, #0x2d0]
10153fa2c:     	ldr	x2, [x9, #0x2e0]
10153fa30:     	ldp	x3, x4, [x24]
10153fa34:     	ldrb	w5, [x24, #0x10]
10153fa38:     	add	x0, sp, #0x188
10153fa3c:     	bl	0x101545430 <__RNvMs0_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections11string_spanNtB7_5State22validate_span_boundary>
10153fa40:     	ldr	w8, [sp, #0x188]
10153fa44:     	cmp	w8, #0x6
10153fa48:     	b.ne	0x10153ff28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153fa4c:     	mov	x8, x21
10153fa50:     	mov	x26, x23
10153fa54:     	ldr	x9, [x8, #0x4a0]
10153fa58:     	mov	x23, x25
10153fa5c:     	mov	x25, x8
10153fa60:     	add	x0, x9, #0x578
10153fa64:     	mov	x1, x20
10153fa68:     	bl	0x101547d50 <__RNvMs_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admissionNtB4_6Layout5group>
10153fa6c:     	ldr	x8, [x25, #0x490]
10153fa70:     	add	x9, x8, #0x3b8
10153fa74:     	add	x10, x8, #0x2f8
10153fa78:     	stp	x8, x9, [sp, #0x188]
10153fa7c:     	stp	x10, x28, [sp, #0x198]
10153fa80:     	add	x8, sp, #0x20
10153fa84:     	str	x8, [sp, #0x1a8]
10153fa88:     	add	x1, sp, #0x188
10153fa8c:     	bl	0x101521c2c <__RINvMNtCsgDHHaSskbIF_4core6optionINtB3_6OptionRNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7prepare13map_admission5GroupE6filterNCNvMs0_NtNtBP_7runtime10invocationNtB2o_10Invocation5visits2_0EBT_>
10153fa90:     	cbz	x0, 0x10153faac <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x5f4>
10153fa94:     	ldr	x8, [x0, #0x18]
10153fa98:     	cbz	x8, 0x101540190 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153fa9c:     	ldr	x8, [x0, #0x10]
10153faa0:     	ldr	w8, [x8]
10153faa4:     	cmp	x20, x8
10153faa8:     	b.ne	0x10153fbc4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x70c>
10153faac:     	mov	x8, x21
10153fab0:     	ldr	x9, [x21, #0xf8]
10153fab4:     	cmp	x9, #0x2
10153fab8:     	csinc	w9, w23, wzr, ne
10153fabc:     	tbz	w9, #0x0, 0x10153fb5c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x6a4>
10153fac0:     	ldr	x9, [x8, #0x498]
10153fac4:     	ldr	x10, [x8, #0x490]
10153fac8:     	add	x11, x10, #0x2e8
10153facc:     	ldr	x10, [x8, #0x4a0]
10153fad0:     	ldr	x12, [x8, #0x4b8]
10153fad4:     	ldr	x8, [x8, #0x4c0]
10153fad8:     	stp	x11, x10, [sp, #0x1c0]
10153fadc:     	stp	x12, x8, [sp, #0x1d0]
10153fae0:     	mov	w8, #0x13               ; =19
10153fae4:     	strb	w8, [sp, #0x188]
10153fae8:     	cbz	x0, 0x10153fc00 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x748>
10153faec:     	mov	x25, x0
10153faf0:     	ldr	x4, [x0, #0x30]
10153faf4:     	mov	w3, #0x1                ; =1
10153faf8:     	b	0x10153fc08 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x750>
10153fafc:     	str	wzr, [x19]
10153fb00:     	mov	w8, #0xc                ; =12
10153fb04:     	strb	w8, [x19, #0x8]
10153fb08:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153fb0c:     	add	x8, x8, #0x329
10153fb10:     	mov	w9, #0x2f               ; =47
10153fb14:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fb18:     	str	wzr, [x19]
10153fb1c:     	mov	w8, #0xc                ; =12
10153fb20:     	adrp	x9, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
10153fb24:     	add	x9, x9, #0xbf9
10153fb28:     	stp	x8, x9, [x19, #0x8]
10153fb2c:     	mov	w8, #0x25               ; =37
10153fb30:     	str	x8, [x19, #0x18]
10153fb34:     	b	0x10153f558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153fb38:     	add	x8, sp, #0x130
10153fb3c:     	ldur	q0, [x8, #0x68]
10153fb40:     	ldur	q1, [x8, #0x78]
10153fb44:     	ldur	q2, [x8, #0x88]
10153fb48:     	stp	q1, q2, [x19, #0x20]
10153fb4c:     	ldur	q1, [x8, #0x98]
10153fb50:     	str	q1, [x19, #0x40]
10153fb54:     	ldur	q1, [x8, #0x58]
10153fb58:     	b	0x10153ff44 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa8c>
10153fb5c:     	ldr	x9, [x8, #0x4a0]
10153fb60:     	ldr	x11, [x9, #0x5a0]
10153fb64:     	ldr	x10, [x8, #0x1c0]
10153fb68:     	cmp	x10, x11
10153fb6c:     	b.hs	0x10153fbe0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x728>
10153fb70:     	cbnz	x0, 0x10153fcd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x818>
10153fb74:     	ldr	x11, [x9, #0x598]
10153fb78:     	mov	w12, #0x58              ; =88
10153fb7c:     	madd	x10, x10, x12, x11
10153fb80:     	ldr	w3, [x10, #0x38]
10153fb84:     	cmp	x20, x3
10153fb88:     	b.ne	0x10153fcd0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x818>
10153fb8c:     	mov	x25, x0
10153fb90:     	ldr	x10, [x8, #0x490]
10153fb94:     	add	x10, x10, #0x2e8
10153fb98:     	ldr	x11, [x8, #0x4b8]
10153fb9c:     	ldr	x8, [x8, #0x4c0]
10153fba0:     	stp	x10, x9, [sp, #0x1c0]
10153fba4:     	stp	x11, x8, [sp, #0x1d0]
10153fba8:     	mov	w8, #0x13               ; =19
10153fbac:     	strb	w8, [sp, #0x188]
10153fbb0:     	add	x0, sp, #0x28
10153fbb4:     	add	x1, sp, #0x188
10153fbb8:     	mov	x2, x20
10153fbbc:     	bl	0x10154737c <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE20visit_outlined_entryB9_>
10153fbc0:     	b	0x10153fc28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x770>
10153fbc4:     	str	wzr, [x19]
10153fbc8:     	mov	w8, #0xc                ; =12
10153fbcc:     	strb	w8, [x19, #0x8]
10153fbd0:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153fbd4:     	add	x8, x8, #0x3ff
10153fbd8:     	mov	w9, #0x2b               ; =43
10153fbdc:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fbe0:     	str	wzr, [x19]
10153fbe4:     	mov	w8, #0xc                ; =12
10153fbe8:     	adrp	x9, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
10153fbec:     	add	x9, x9, #0xc1e
10153fbf0:     	stp	x8, x9, [x19, #0x8]
10153fbf4:     	mov	w8, #0x1a               ; =26
10153fbf8:     	str	x8, [x19, #0x18]
10153fbfc:     	b	0x10153f558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153fc00:     	mov	x25, x0
10153fc04:     	mov	x3, #0x0                ; =0
10153fc08:     	mov	x5, x26
10153fc0c:     	ldr	w7, [x10, #0x3f0]
10153fc10:     	str	x9, [sp]
10153fc14:     	add	x0, sp, #0x28
10153fc18:     	add	x1, sp, #0x188
10153fc1c:     	mov	x2, x20
10153fc20:     	mov	x6, x22
10153fc24:     	bl	0x101546cd4 <__RNvMs3_NtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtimeINtB5_11ControlViewNtNtNtB7_7program5image23NativeProgramDescriptorE16visit_from_entryB9_>
10153fc28:     	ldrb	w8, [sp, #0x28]
10153fc2c:     	cmp	w8, #0x13
10153fc30:     	b.ne	0x10153fc70 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x7b8>
10153fc34:     	add	x0, sp, #0x188
10153fc38:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
10153fc3c:     	add	x0, sp, #0x188
10153fc40:     	mov	x1, x21
10153fc44:     	mov	x2, x20
10153fc48:     	bl	0x1015489f8 <__RNvMs_NtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation12continuationNtB6_10Invocation23arm_parent_continuation>
10153fc4c:     	ldr	w8, [sp, #0x188]
10153fc50:     	cmp	w8, #0x6
10153fc54:     	b.ne	0x10153ff28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153fc58:     	cbz	x25, 0x10153fcec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x834>
10153fc5c:     	ldr	x8, [x25]
10153fc60:     	mov	x0, x21
10153fc64:     	cbz	x8, 0x10153fd50 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x898>
10153fc68:     	mov	w8, #0x0                ; =0
10153fc6c:     	b	0x10153fd64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8ac>
10153fc70:     	ldur	q0, [sp, #0x28]
10153fc74:     	ldur	q1, [sp, #0x38]
10153fc78:     	stp	q0, q1, [sp, #0x130]
10153fc7c:     	ldur	q2, [sp, #0x48]
10153fc80:     	str	q2, [sp, #0x150]
10153fc84:     	ldr	x8, [sp, #0x58]
10153fc88:     	str	x8, [sp, #0x160]
10153fc8c:     	stur	q0, [sp, #0x2c]
10153fc90:     	stur	q1, [sp, #0x3c]
10153fc94:     	stur	q2, [sp, #0x4c]
10153fc98:     	stur	x8, [sp, #0x5c]
10153fc9c:     	mov	w8, #0x1                ; =1
10153fca0:     	str	w8, [x19]
10153fca4:     	ldur	q0, [sp, #0x28]
10153fca8:     	ldur	q1, [sp, #0x38]
10153fcac:     	stur	q0, [x19, #0x4]
10153fcb0:     	stur	q1, [x19, #0x14]
10153fcb4:     	ldur	q0, [sp, #0x48]
10153fcb8:     	stur	q0, [x19, #0x24]
10153fcbc:     	ldur	q0, [sp, #0x54]
10153fcc0:     	str	q0, [x19, #0x30]
10153fcc4:     	add	x0, sp, #0x188
10153fcc8:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
10153fccc:     	b	0x10153f558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153fcd0:     	str	wzr, [x19]
10153fcd4:     	mov	w8, #0xc                ; =12
10153fcd8:     	strb	w8, [x19, #0x8]
10153fcdc:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153fce0:     	add	x8, x8, #0x358
10153fce4:     	mov	w9, #0x26               ; =38
10153fce8:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fcec:     	mov	w8, #0x0                ; =0
10153fcf0:     	mov	x0, x21
10153fcf4:     	b	0x10153fd64 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x8ac>
10153fcf8:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153fcfc:     	add	x8, x8, #0x21e
10153fd00:     	mov	w9, #0x2a               ; =42
10153fd04:     	b	0x10153f624 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x16c>
10153fd08:     	ldr	x9, [x0, #0x4c8]
10153fd0c:     	str	xzr, [x0, #0x4c8]
10153fd10:     	cbz	x9, 0x10153ff94 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xadc>
10153fd14:     	sub	x9, x9, #0x1
10153fd18:     	cmp	x9, x8
10153fd1c:     	b.ne	0x10153ffa4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xaec>
10153fd20:     	ldrb	w8, [x24, #0x338]
10153fd24:     	cmp	w8, #0x1
10153fd28:     	b.ne	0x10153f884 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
10153fd2c:     	ldr	x8, [x0, #0x4c8]
10153fd30:     	cbz	x8, 0x10153f884 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x3cc>
10153fd34:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
10153fd38:     	add	x8, x8, #0x37e
10153fd3c:     	mov	w9, #0x29               ; =41
10153fd40:     	str	wzr, [x19]
10153fd44:     	mov	w10, #0xc               ; =12
10153fd48:     	str	x10, [x19, #0x8]
10153fd4c:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153fd50:     	ldr	x8, [x25, #0x18]
10153fd54:     	cbz	x8, 0x101540190 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xcd8>
10153fd58:     	ldr	x8, [x25, #0x10]
10153fd5c:     	ldr	w9, [x8]
10153fd60:     	mov	w8, #0x1                ; =1
10153fd64:     	ldr	x10, [x0, #0x490]
10153fd68:     	str	w8, [x10, #0x340]
10153fd6c:     	str	w9, [x10, #0x344]
10153fd70:     	ldr	x8, [x0, #0x490]
10153fd74:     	str	wzr, [x8, #0xb8]
10153fd78:     	ldr	x22, [x0, #0x4a0]
10153fd7c:     	mov	x1, x20
10153fd80:     	bl	0x10153549c <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowedNtB4_10Invocation15borrowed_action>
10153fd84:     	cbz	x0, 0x10153fdb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x900>
10153fd88:     	ldrb	w8, [x0]
10153fd8c:     	cmp	w8, #0x6
10153fd90:     	b.ne	0x10153fdb8 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x900>
10153fd94:     	ldr	x9, [x21, #0x490]
10153fd98:     	add	x8, sp, #0x188
10153fd9c:     	add	x0, x9, #0x3b8
10153fda0:     	mov	w1, #0x20               ; =32
10153fda4:     	mov	w2, #0x20               ; =32
10153fda8:     	bl	0x10236d5e4 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget6charge>
10153fdac:     	ldrb	w8, [sp, #0x188]
10153fdb0:     	cmp	w8, #0x8
10153fdb4:     	b.ne	0x10153ff4c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa94>
10153fdb8:     	ldr	x1, [x22, #0x458]
10153fdbc:     	cmp	x20, x1
10153fdc0:     	b.hs	0x1015401d4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd1c>
10153fdc4:     	ldr	x8, [x22, #0x450]
10153fdc8:     	add	x10, x8, x20, lsl #6
10153fdcc:     	ldr	w8, [x10, #0x18]
10153fdd0:     	cmp	w8, #0x4
10153fdd4:     	mov	x9, x21
10153fdd8:     	b.ne	0x10153fe30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x978>
10153fddc:     	ldr	x8, [x9, #0x220]
10153fde0:     	cmp	x8, #0x2
10153fde4:     	b.eq	0x10153fe30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x978>
10153fde8:     	ldr	x8, [x22, #0x208]
10153fdec:     	ldr	x0, [x9, #0x1d8]
10153fdf0:     	cmp	x0, x8
10153fdf4:     	b.hs	0x101540240 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd88>
10153fdf8:     	ldr	w8, [x10, #0x1c]
10153fdfc:     	ldr	x10, [x22, #0x200]
10153fe00:     	mov	w11, #0x70              ; =112
10153fe04:     	madd	x10, x0, x11, x10
10153fe08:     	ldr	w10, [x10, #0x40]
10153fe0c:     	cmp	w10, w8
10153fe10:     	b.ne	0x10153fe30 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x978>
10153fe14:     	add	x0, x9, #0x1d8
10153fe18:     	bl	0x101526afc <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation8borrowed5StateEBS_>
10153fe1c:     	mov	w8, #0x2                ; =2
10153fe20:     	mov	x9, x21
10153fe24:     	str	x8, [x21, #0x220]
10153fe28:     	ldr	x1, [x22, #0x458]
10153fe2c:     	add	x27, sp, #0x130
10153fe30:     	cmp	x20, x1
10153fe34:     	b.hs	0x1015401e4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd2c>
10153fe38:     	ldr	x8, [x22, #0x450]
10153fe3c:     	add	x8, x8, x20, lsl #6
10153fe40:     	ldr	w10, [x8, #0x18]
10153fe44:     	cmp	w10, #0x4
10153fe48:     	b.ne	0x10153fea0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9e8>
10153fe4c:     	ldr	w2, [x8, #0x1c]
10153fe50:     	ldr	x8, [x22, #0x390]
10153fe54:     	cmp	x8, x2
10153fe58:     	b.ls	0x101540214 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd5c>
10153fe5c:     	ldr	x8, [x22, #0x388]
10153fe60:     	mov	w10, #0x180             ; =384
10153fe64:     	umaddl	x8, w2, w10, x8
10153fe68:     	ldp	x8, x10, [x8]
10153fe6c:     	mov	w11, #0x5               ; =5
10153fe70:     	eor	x8, x8, x11
10153fe74:     	orr	x8, x8, x10
10153fe78:     	cbnz	x8, 0x10153fea0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9e8>
10153fe7c:     	mov	x1, x9
10153fe80:     	add	x0, sp, #0x188
10153fe84:     	mov	w3, #0x2                ; =2
10153fe88:     	bl	0x10153f120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation18retire_tail_locals>
10153fe8c:     	ldr	w8, [sp, #0x188]
10153fe90:     	cmp	w8, #0x6
10153fe94:     	b.ne	0x10153ff28 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa70>
10153fe98:     	ldr	x1, [x22, #0x458]
10153fe9c:     	mov	x9, x21
10153fea0:     	cmp	x20, x1
10153fea4:     	b.hs	0x1015401f4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd3c>
10153fea8:     	ldr	x8, [x22, #0x450]
10153feac:     	add	x8, x8, x20, lsl #6
10153feb0:     	ldr	w10, [x8, #0x18]
10153feb4:     	cmp	w10, #0x4
10153feb8:     	b.ne	0x101540098 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbe0>
10153febc:     	ldr	w2, [x8, #0x1c]
10153fec0:     	ldr	x1, [x22, #0x390]
10153fec4:     	cmp	x1, x2
10153fec8:     	b.ls	0x10154022c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xd74>
10153fecc:     	ldr	x8, [x22, #0x388]
10153fed0:     	mov	w10, #0x180             ; =384
10153fed4:     	umaddl	x8, w2, w10, x8
10153fed8:     	ldp	x8, x10, [x8]
10153fedc:     	cmp	x8, #0x3
10153fee0:     	sbcs	xzr, x10, xzr
10153fee4:     	b.hs	0x101540098 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbe0>
10153fee8:     	ldr	x12, [x9, #0x490]
10153feec:     	ldr	x8, [x12, #0x1e0]
10153fef0:     	ldr	d0, [x12, #0x1e8]
10153fef4:     	ldrb	w9, [x12, #0x1f0]
10153fef8:     	ldp	x10, x11, [x12, #0x1f8]
10153fefc:     	mov	x13, #-0x8000000000000000 ; =-9223372036854775808
10153ff00:     	str	x13, [x12, #0x1e0]
10153ff04:     	cmp	x8, x13
10153ff08:     	b.ne	0x10153ffb4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xafc>
10153ff0c:     	str	wzr, [x19]
10153ff10:     	mov	w8, #0xc                ; =12
10153ff14:     	strb	w8, [x19, #0x8]
10153ff18:     	adrp	x8, 0x10754c000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x403>
10153ff1c:     	add	x8, x8, #0xc38
10153ff20:     	mov	w9, #0x1d               ; =29
10153ff24:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10153ff28:     	ldur	q0, [x27, #0x68]
10153ff2c:     	ldur	q1, [x27, #0x78]
10153ff30:     	ldur	q2, [x27, #0x88]
10153ff34:     	stp	q1, q2, [x19, #0x20]
10153ff38:     	ldur	q1, [x27, #0x98]
10153ff3c:     	str	q1, [x19, #0x40]
10153ff40:     	ldur	q1, [x27, #0x58]
10153ff44:     	stp	q1, q0, [x19]
10153ff48:     	b	0x10153f558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153ff4c:     	ldur	q0, [x27, #0x58]
10153ff50:     	ldur	q1, [x27, #0x68]
10153ff54:     	stp	q0, q1, [x29, #-0xb0]
10153ff58:     	ldr	x8, [sp, #0x1a8]
10153ff5c:     	stur	x8, [x29, #-0x90]
10153ff60:     	add	x9, x24, #0x148
10153ff64:     	ldr	w10, [x24, #0x158]
10153ff68:     	stur	w10, [x29, #-0x70]
10153ff6c:     	ldr	q2, [x9]
10153ff70:     	stur	q2, [x29, #-0x80]
10153ff74:     	mov	w9, #0x4                ; =4
10153ff78:     	str	w9, [x19]
10153ff7c:     	stur	q2, [x19, #0x4]
10153ff80:     	str	w10, [x19, #0x14]
10153ff84:     	stur	q0, [x19, #0x18]
10153ff88:     	stur	q1, [x19, #0x28]
10153ff8c:     	str	x8, [x19, #0x38]
10153ff90:     	b	0x10153f558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
10153ff94:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10153ff98:     	add	x8, x8, #0xaaa
10153ff9c:     	mov	w9, #0x2c               ; =44
10153ffa0:     	b	0x10153fd40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x888>
10153ffa4:     	adrp	x8, 0x10754d000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.11+0x1403>
10153ffa8:     	add	x8, x8, #0xad6
10153ffac:     	mov	w9, #0x31               ; =49
10153ffb0:     	b	0x10153fd40 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x888>
10153ffb4:     	add	x13, sp, #0x28
10153ffb8:     	add	x14, x12, #0x238
10153ffbc:     	add	x15, x12, #0x208
10153ffc0:     	ldp	q1, q2, [x15]
10153ffc4:     	stp	q1, q2, [sp, #0x50]
10153ffc8:     	ldr	q4, [x15, #0x20]
10153ffcc:     	ldp	q1, q2, [x14, #0x90]
10153ffd0:     	stur	q2, [x13, #0xf8]
10153ffd4:     	ldr	q2, [x14, #0x80]
10153ffd8:     	stur	q1, [x13, #0xe8]
10153ffdc:     	stur	q2, [x13, #0xd8]
10153ffe0:     	ldp	q2, q1, [x14, #0x60]
10153ffe4:     	stur	q1, [x13, #0xc8]
10153ffe8:     	stur	q2, [x13, #0xb8]
10153ffec:     	ldp	q2, q1, [x14, #0x40]
10153fff0:     	stur	q1, [x13, #0xa8]
10153fff4:     	stur	q2, [x13, #0x98]
10153fff8:     	ldp	q2, q1, [x14, #0x20]
10153fffc:     	stur	q1, [x13, #0x88]
101540000:     	ldp	q1, q3, [x14]
101540004:     	stp	q4, q1, [sp, #0x70]
101540008:     	stur	q3, [sp, #0x90]
10154000c:     	add	x14, x12, #0x1f1
101540010:     	ldr	w12, [x12, #0x1f4]
101540014:     	str	w12, [sp, #0x3c]
101540018:     	ldr	w12, [x14]
10154001c:     	stur	w12, [sp, #0x39]
101540020:     	stur	q2, [x13, #0x78]
101540024:     	str	x8, [sp, #0x28]
101540028:     	str	d0, [sp, #0x30]
10154002c:     	strb	w9, [sp, #0x38]
101540030:     	stp	x10, x11, [sp, #0x40]
101540034:     	str	x21, [sp, #0x188]
101540038:     	add	x8, sp, #0x130
10154003c:     	add	x0, sp, #0x28
101540040:     	add	x1, sp, #0x188
101540044:     	bl	0x101590004 <__RNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections8lifetimeNtB4_5State14release_source>
101540048:     	add	x0, sp, #0x188
10154004c:     	add	x1, sp, #0x28
101540050:     	mov	w2, #0x108              ; =264
101540054:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101540058:     	ldr	x8, [x21, #0x490]
10154005c:     	ldr	x9, [x8, #0x1e0]
101540060:     	mov	x10, #-0x8000000000000000 ; =-9223372036854775808
101540064:     	cmp	x9, x10
101540068:     	b.eq	0x101540078 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xbc0>
10154006c:     	add	x0, x8, #0x1e0
101540070:     	bl	0x101525948 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101540074:     	ldr	x8, [x21, #0x490]
101540078:     	add	x0, x8, #0x1e0
10154007c:     	add	x1, sp, #0x188
101540080:     	mov	w2, #0x108              ; =264
101540084:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101540088:     	ldr	w8, [sp, #0x130]
10154008c:     	cmp	w8, #0x6
101540090:     	b.ne	0x10154013c <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc84>
101540094:     	mov	x9, x21
101540098:     	ldr	x20, [x9, #0x490]
10154009c:     	ldrb	w8, [x20, #0x338]
1015400a0:     	tbz	w8, #0x0, 0x101540110 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc58>
1015400a4:     	ldr	x8, [x20, #0x1e0]
1015400a8:     	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
1015400ac:     	cmp	x8, x9
1015400b0:     	b.eq	0x1015400c0 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc08>
1015400b4:     	add	x0, x20, #0x1e0
1015400b8:     	bl	0x1015872d4 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collectionsNtB2_5State11is_complete>
1015400bc:     	tbz	w0, #0x0, 0x101540120 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc68>
1015400c0:     	ldr	x8, [x20, #0x10]
1015400c4:     	cmp	x8, #0x2
1015400c8:     	b.eq	0x1015400ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc34>
1015400cc:     	ldr	x8, [x20, #0xa8]
1015400d0:     	cbz	x8, 0x1015400ec <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc34>
1015400d4:     	str	wzr, [x19]
1015400d8:     	mov	w8, #0xc                ; =12
1015400dc:     	strb	w8, [x19, #0x8]
1015400e0:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
1015400e4:     	add	x8, x8, #0x3a7
1015400e8:     	b	0x101540134 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc7c>
1015400ec:     	ldr	x8, [x21, #0x4c8]
1015400f0:     	cbz	x8, 0x101540110 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc58>
1015400f4:     	str	wzr, [x19]
1015400f8:     	mov	w8, #0xc                ; =12
1015400fc:     	strb	w8, [x19, #0x8]
101540100:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540104:     	add	x8, x8, #0x37e
101540108:     	mov	w9, #0x29               ; =41
10154010c:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
101540110:     	strb	wzr, [x20, #0x460]
101540114:     	mov	w8, #0x6                ; =6
101540118:     	str	w8, [x19]
10154011c:     	b	0x10153f558 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xa0>
101540120:     	str	wzr, [x19]
101540124:     	mov	w8, #0xc                ; =12
101540128:     	strb	w8, [x19, #0x8]
10154012c:     	adrp	x8, 0x10754f000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.376+0x15f0>
101540130:     	add	x8, x8, #0x3d3
101540134:     	mov	w9, #0x2c               ; =44
101540138:     	b	0x10153f554 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0x9c>
10154013c:     	add	x9, sp, #0x130
101540140:     	ldur	q0, [x9, #0x14]
101540144:     	stur	q0, [x19, #0x14]
101540148:     	ldur	q0, [x9, #0x24]
10154014c:     	stur	q0, [x19, #0x24]
101540150:     	ldur	q0, [x9, #0x34]
101540154:     	stur	q0, [x19, #0x34]
101540158:     	ldr	q0, [sp, #0x170]
10154015c:     	str	q0, [x19, #0x40]
101540160:     	ldur	q0, [x9, #0x4]
101540164:     	stur	q0, [x19, #0x4]
101540168:     	b	0x101540118 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xc60>
10154016c:     	adrp	x8, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540170:     	add	x8, x8, #0x640
101540174:     	mov	x0, x2
101540178:     	mov	x2, x8
10154017c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540180:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540184:     	add	x2, x2, #0x658
101540188:     	mov	x0, x25
10154018c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540190:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101540194:     	add	x2, x2, #0x260
101540198:     	mov	x0, #0x0                ; =0
10154019c:     	mov	x1, #0x0                ; =0
1015401a0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015401a4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015401a8:     	add	x2, x2, #0xb48
1015401ac:     	mov	x0, x8
1015401b0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015401b4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015401b8:     	add	x2, x2, #0xc68
1015401bc:     	mov	x0, x8
1015401c0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015401c4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015401c8:     	add	x2, x2, #0x670
1015401cc:     	mov	x0, x8
1015401d0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015401d4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015401d8:     	add	x2, x2, #0x688
1015401dc:     	mov	x0, x20
1015401e0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015401e4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015401e8:     	add	x2, x2, #0x6a0
1015401ec:     	mov	x0, x20
1015401f0:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015401f4:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
1015401f8:     	add	x2, x2, #0x6d0
1015401fc:     	mov	x0, x20
101540200:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540204:     	adrp	x2, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540208:     	add	x2, x2, #0xc80
10154020c:     	mov	x0, x9
101540210:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540214:     	adrp	x9, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540218:     	add	x9, x9, #0x6b8
10154021c:     	mov	x0, x2
101540220:     	mov	x1, x8
101540224:     	mov	x2, x9
101540228:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
10154022c:     	adrp	x8, 0x107f09000 <_anon.4890df2b6a753b8cc492654bd67f0ac0.319+0xbc8>
101540230:     	add	x8, x8, #0x6e8
101540234:     	mov	x0, x2
101540238:     	mov	x2, x8
10154023c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540240:     	adrp	x2, 0x107f08000 <_anon.ed765d3c3ccf3d2a11f7493ccb8d9b33.346+0x530>
101540244:     	add	x2, x2, #0x278
101540248:     	mov	x1, x8
10154024c:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101540250:     	mov	x19, x0
101540254:     	ldr	x8, [x21, #0x490]
101540258:     	add	x0, x8, #0x1e0
10154025c:     	add	x1, sp, #0x188
101540260:     	mov	w2, #0x108              ; =264
101540264:     	bl	0x103a035dc <dyld_stub_binder+0x103a035dc>
101540268:     	ldr	w8, [sp, #0x130]
10154026c:     	cmp	w8, #0x6
101540270:     	b.eq	0x1015402a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xdec>
101540274:     	add	x0, sp, #0x130
101540278:     	bl	0x101525658 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime27NativeProgramExecutionErrorEBO_>
10154027c:     	mov	x0, x19
101540280:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
101540284:     	mov	x19, x0
101540288:     	add	x0, sp, #0x28
10154028c:     	bl	0x101525948 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime11collections5StateEBQ_>
101540290:     	b	0x1015402a4 <__RNvMs0_NtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocationNtB5_10Invocation5visit+0xdec>
101540294:     	bl	0x103a0200c <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
101540298:     	mov	x19, x0
10154029c:     	mov	w8, #0x2                ; =2
1015402a0:     	str	x8, [x21, #0x220]
1015402a4:     	mov	x0, x19
1015402a8:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
1015402ac:     	mov	x19, x0
1015402b0:     	add	x0, sp, #0x188
1015402b4:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
1015402b8:     	mov	x0, x19
1015402bc:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
1015402c0:     	mov	x19, x0
1015402c4:     	add	x0, sp, #0x188
1015402c8:     	bl	0x101524284 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeINtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact17iteration_runtime11ControlViewNtNtBL_13iteration_abi25NativeIterationDescriptorEEBN_>
1015402cc:     	mov	x0, x19
1015402d0:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
