
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101621484 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_>:
101621484:     	sub	sp, sp, #0x110
101621488:     	stp	x28, x27, [sp, #0xb0]
10162148c:     	stp	x26, x25, [sp, #0xc0]
101621490:     	stp	x24, x23, [sp, #0xd0]
101621494:     	stp	x22, x21, [sp, #0xe0]
101621498:     	stp	x20, x19, [sp, #0xf0]
10162149c:     	stp	x29, x30, [sp, #0x100]
1016214a0:     	add	x29, sp, #0x100
1016214a4:     	stp	x6, x0, [sp, #0x8]
1016214a8:     	mov	x22, x3
1016214ac:     	mov	x25, x1
1016214b0:     	mov	x19, #0x0               ; =0
1016214b4:     	mov	x26, #0x0               ; =0
1016214b8:     	mov	x23, #0x0               ; =0
1016214bc:     	mov	x24, #0x0               ; =0
1016214c0:     	ldp	x27, x9, [x4]
1016214c4:     	ldr	x10, [x4, #0x30]
1016214c8:     	ldp	x8, x11, [x4, #0x10]
1016214cc:     	stp	x11, x5, [sp, #0x38]
1016214d0:     	str	x8, [sp, #0x20]
1016214d4:     	ldp	x8, x11, [x4, #0x20]
1016214d8:     	stp	x11, x10, [sp, #0x28]
1016214dc:     	str	x8, [sp, #0x18]
1016214e0:     	lsl	x8, x2, #7
1016214e4:     	sub	x28, x8, x2, lsl #3
1016214e8:     	str	x9, [sp]
1016214ec:     	add	x21, x9, #0x1
1016214f0:     	cmp	x28, x19
1016214f4:     	b.eq	0x1016216ac <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x228>
1016214f8:     	subs	x21, x21, #0x1
1016214fc:     	b.eq	0x101621744 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2c0>
101621500:     	ldrb	w8, [x27]
101621504:     	cmp	w8, #0x3
101621508:     	b.ne	0x1016215e0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x15c>
10162150c:     	ldr	x0, [x27, #0x8]
101621510:     	ldr	x8, [sp, #0x38]
101621514:     	cmp	x0, x8
101621518:     	b.hs	0x101621758 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2d4>
10162151c:     	ldr	x8, [sp, #0x28]
101621520:     	cmp	x0, x8
101621524:     	b.hs	0x101621768 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x2e4>
101621528:     	ldp	x9, x8, [sp, #0x18]
10162152c:     	add	x20, x8, x0, lsl #6
101621530:     	ldr	x8, [x20]
101621534:     	ldr	x10, [x9, x0, lsl #3]
101621538:     	cbz	x8, 0x101621614 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x190>
10162153c:     	cbnz	x10, 0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621540:     	ldr	w9, [x20, #0x38]
101621544:     	add	x8, x25, x19
101621548:     	ldr	w10, [x8, #0x70]
10162154c:     	cmp	w9, w10
101621550:     	b.ne	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621554:     	ldp	q0, q1, [x20, #0x10]
101621558:     	stp	q0, q1, [sp, #0x60]
10162155c:     	ldp	x9, x10, [sp, #0x60]
101621560:     	ldp	x11, x12, [x8, #0x50]
101621564:     	ldp	x13, x14, [sp, #0x70]
101621568:     	ldp	x15, x8, [x8, #0x60]
10162156c:     	cmp	x9, x11
101621570:     	ccmp	x10, x12, #0x0, eq
101621574:     	ccmp	x13, x15, #0x0, eq
101621578:     	ccmp	x14, x8, #0x0, eq
10162157c:     	b.ne	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621580:     	mov	x0, x20
101621584:     	ldr	x1, [sp, #0x40]
101621588:     	bl	0x102e10a94 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
10162158c:     	cmp	x0, #0x1
101621590:     	b.ne	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621594:     	add	x8, sp, #0x60
101621598:     	mov	x0, x20
10162159c:     	mov	x1, x22
1016215a0:     	bl	0x102e0eb78 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
1016215a4:     	ldrb	w8, [sp, #0x60]
1016215a8:     	cmp	w8, #0x16
1016215ac:     	b.ne	0x1016216e4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x260>
1016215b0:     	add	x8, sp, #0x60
1016215b4:     	add	x0, x25, x19
1016215b8:     	mov	x1, x20
1016215bc:     	mov	x2, x22
1016215c0:     	bl	0x102368fc0 <__RNvMNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget15frame_footprintNtB2_28PreparedNativeFrameFootprint5value>
1016215c4:     	ldr	w8, [sp, #0x60]
1016215c8:     	tbz	w8, #0x0, 0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016215cc:     	ldp	x9, x8, [sp, #0x70]
1016215d0:     	ldr	x10, [sp, #0x80]
1016215d4:     	adds	x26, x9, x26
1016215d8:     	b.lo	0x101621688 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x204>
1016215dc:     	b	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016215e0:     	ldp	q0, q1, [x27]
1016215e4:     	stp	q0, q1, [sp, #0x60]
1016215e8:     	ldr	x8, [sp, #0x30]
1016215ec:     	ldr	x8, [x8]
1016215f0:     	ldr	x1, [x8]
1016215f4:     	add	x0, sp, #0x48
1016215f8:     	add	x2, sp, #0x60
1016215fc:     	bl	0x101635f6c <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
101621600:     	ldr	x8, [sp, #0x48]
101621604:     	cmp	x8, #0x1
101621608:     	b.ne	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
10162160c:     	ldp	x20, x10, [sp, #0x50]
101621610:     	cbnz	x20, 0x10162153c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0xb8>
101621614:     	ldrb	w8, [x25, x19]
101621618:     	tbnz	w8, #0x0, 0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
10162161c:     	add	x8, x25, x19
101621620:     	ldrb	w11, [x8, #0x1]
101621624:     	ldp	x9, x8, [x8, #0x10]
101621628:     	cmp	w11, #0x3
10162162c:     	b.gt	0x101621648 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1c4>
101621630:     	sub	w11, w11, #0x1
101621634:     	cmp	w11, #0x3
101621638:     	b.lo	0x101621678 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
10162163c:     	cmp	x10, #0x2
101621640:     	b.lo	0x101621678 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101621644:     	b	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621648:     	cmp	w11, #0x4
10162164c:     	b.eq	0x101621664 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1e0>
101621650:     	cmp	w11, #0x5
101621654:     	b.ne	0x101621670 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1ec>
101621658:     	cmp	x10, #0x10, lsl #12     ; =0x10000
10162165c:     	b.lo	0x101621678 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
101621660:     	b	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621664:     	cmp	x10, #0xff
101621668:     	b.ls	0x101621678 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x1f4>
10162166c:     	b	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621670:     	lsr	x10, x10, #32
101621674:     	cbnz	x10, 0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621678:     	add	x10, x25, x19
10162167c:     	ldr	x10, [x10, #0x20]
101621680:     	adds	x26, x9, x26
101621684:     	b.hs	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
101621688:     	adds	x23, x10, x23
10162168c:     	cset	w9, hs
101621690:     	adds	x24, x8, x24
101621694:     	cset	w8, hs
101621698:     	tbnz	w9, #0x0, 0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
10162169c:     	add	x27, x27, #0x20
1016216a0:     	add	x19, x19, #0x78
1016216a4:     	tbz	w8, #0x0, 0x1016214f0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x6c>
1016216a8:     	b	0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016216ac:     	add	x8, sp, #0x60
1016216b0:     	ldr	x0, [sp, #0x8]
1016216b4:     	mov	x1, x23
1016216b8:     	mov	x2, x24
1016216bc:     	bl	0x1023757e4 <__RNvMsa_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_19ResidentBudgetMeter29try_charge_borrowed_footprint>
1016216c0:     	ldrb	w9, [sp, #0x60]
1016216c4:     	ldrb	w8, [sp, #0x61]
1016216c8:     	cmp	w9, #0x8
1016216cc:     	b.ne	0x10162171c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x298>
1016216d0:     	tbz	w8, #0x0, 0x1016216ec <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x268>
1016216d4:     	mov	w8, #0x1                ; =1
1016216d8:     	ldr	x9, [sp, #0x10]
1016216dc:     	stp	x8, x26, [x9, #0x8]
1016216e0:     	b	0x1016216f4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x270>
1016216e4:     	add	x0, sp, #0x60
1016216e8:     	bl	0x101632b30 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs7fdMCt8k5K6_8mech_gpu>
1016216ec:     	ldr	x9, [sp, #0x10]
1016216f0:     	str	xzr, [x9, #0x8]
1016216f4:     	mov	w8, #0x8                ; =8
1016216f8:     	strb	w8, [x9]
1016216fc:     	ldp	x29, x30, [sp, #0x100]
101621700:     	ldp	x20, x19, [sp, #0xf0]
101621704:     	ldp	x22, x21, [sp, #0xe0]
101621708:     	ldp	x24, x23, [sp, #0xd0]
10162170c:     	ldp	x26, x25, [sp, #0xc0]
101621710:     	ldp	x28, x27, [sp, #0xb0]
101621714:     	add	sp, sp, #0x110
101621718:     	ret
10162171c:     	ldur	q0, [sp, #0x62]
101621720:     	ldr	x11, [sp, #0x10]
101621724:     	stur	q0, [x11, #0x2]
101621728:     	ldur	q0, [sp, #0x72]
10162172c:     	stur	q0, [x11, #0x12]
101621730:     	ldr	x10, [sp, #0x80]
101621734:     	str	x10, [x11, #0x20]
101621738:     	strb	w9, [x11]
10162173c:     	strb	w8, [x11, #0x1]
101621740:     	b	0x1016216fc <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared15frame_admissionNtB3_20FrameAdmissionRecipe17try_admit_currentNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB49_10Invocation19buffer_frame_actions0_0E0EB4h_+0x278>
101621744:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
101621748:     	add	x2, x2, #0xc0
10162174c:     	ldr	x0, [sp]
101621750:     	mov	x1, x0
101621754:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621758:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
10162175c:     	add	x2, x2, #0xd8
101621760:     	ldr	x1, [sp, #0x38]
101621764:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101621768:     	adrp	x2, 0x107f10000 <_anon.fa7d5ae1f4adfbac27ec02943b631564.225+0x30>
10162176c:     	add	x2, x2, #0xf0
101621770:     	ldr	x1, [sp, #0x28]
101621774:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
