
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001014afe2c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_>:
1014afe2c:     	sub	sp, sp, #0xd0
1014afe30:     	stp	x28, x27, [sp, #0x70]
1014afe34:     	stp	x26, x25, [sp, #0x80]
1014afe38:     	stp	x24, x23, [sp, #0x90]
1014afe3c:     	stp	x22, x21, [sp, #0xa0]
1014afe40:     	stp	x20, x19, [sp, #0xb0]
1014afe44:     	stp	x29, x30, [sp, #0xc0]
1014afe48:     	add	x29, sp, #0xc0
1014afe4c:     	ldrb	w8, [x0, #0x3c]
1014afe50:     	cmp	w8, #0x1
1014afe54:     	b.ne	0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014afe58:     	ldp	x21, x24, [x0, #0x10]
1014afe5c:     	ldp	x9, x8, [x0, #0x20]
1014afe60:     	stp	x9, x8, [sp]
1014afe64:     	ldp	x27, x19, [x1]
1014afe68:     	ldp	x8, x9, [x1, #0x28]
1014afe6c:     	stp	x9, x8, [sp, #0x18]
1014afe70:     	ldp	x8, x9, [x1, #0x10]
1014afe74:     	str	x9, [sp, #0x28]
1014afe78:     	str	x8, [sp, #0x10]
1014afe7c:     	add	x26, x21, #0x8
1014afe80:     	lsl	x8, x24, #6
1014afe84:     	sub	x20, x8, x24, lsl #3
1014afe88:     	mov	x23, x21
1014afe8c:     	b	0x1014afec4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x98>
1014afe90:     	add	x8, sp, #0x30
1014afe94:     	add	x0, x9, #0x10
1014afe98:     	add	x1, x25, #0x18
1014afe9c:     	bl	0x102e30db8 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014afea0:     	ldr	x8, [sp, #0x30]
1014afea4:     	cmp	x8, #0x1e
1014afea8:     	b.ne	0x1014b0050 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x224>
1014afeac:     	ldr	x8, [sp, #0x38]
1014afeb0:     	add	x23, x23, #0x38
1014afeb4:     	add	x26, x26, #0x38
1014afeb8:     	sub	x20, x20, #0x38
1014afebc:     	cmp	x8, x28
1014afec0:     	b.ne	0x1014b0074 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014afec4:     	cmp	x20, #0x0
1014afec8:     	cset	w22, eq
1014afecc:     	cbz	x20, 0x1014b0074 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014afed0:     	ldr	x0, [x23, #0x30]
1014afed4:     	cmp	x0, x19
1014afed8:     	b.hs	0x1014b0098 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x26c>
1014afedc:     	add	x8, x27, x0, lsl #5
1014afee0:     	ldrb	w9, [x8]
1014afee4:     	cmp	w9, #0x3
1014afee8:     	b.ne	0x1014aff1c <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0xf0>
1014afeec:     	ldr	x0, [x8, #0x8]
1014afef0:     	ldr	x8, [sp, #0x28]
1014afef4:     	cmp	x0, x8
1014afef8:     	b.hs	0x1014b00a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x27c>
1014afefc:     	ldr	x8, [sp, #0x20]
1014aff00:     	cmp	x0, x8
1014aff04:     	b.hs	0x1014b00b8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x28c>
1014aff08:     	lsl	x8, x0, #6
1014aff0c:     	ldr	x9, [sp, #0x10]
1014aff10:     	ldr	x9, [x9, x8]
1014aff14:     	cbnz	x9, 0x1014aff54 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x128>
1014aff18:     	b	0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014aff1c:     	ldp	q0, q1, [x8]
1014aff20:     	stp	q0, q1, [sp, #0x30]
1014aff24:     	ldr	x8, [sp, #0x18]
1014aff28:     	ldr	x8, [x8]
1014aff2c:     	ldr	x1, [x8]
1014aff30:     	add	x0, sp, #0x58
1014aff34:     	add	x2, sp, #0x30
1014aff38:     	bl	0x1014b6e58 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014aff3c:     	ldr	x8, [sp, #0x58]
1014aff40:     	cmp	x8, #0x1
1014aff44:     	b.ne	0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014aff48:     	ldr	x8, [sp, #0x60]
1014aff4c:     	cbz	x8, 0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014aff50:     	ldr	x9, [x8]
1014aff54:     	add	x8, sp, #0x30
1014aff58:     	add	x0, x9, #0x10
1014aff5c:     	add	x1, x23, #0x18
1014aff60:     	bl	0x102e30db8 <__RNvMs_NtNtCskIfnrfrMWVM_9mech_core6schema5shapeNtB4_13ShapeInstance17resolve_dimension>
1014aff64:     	ldr	x8, [sp, #0x30]
1014aff68:     	cmp	x8, #0x1e
1014aff6c:     	b.ne	0x1014b0050 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x224>
1014aff70:     	ldr	x28, [sp, #0x38]
1014aff74:     	ldr	w8, [x23]
1014aff78:     	cmp	w8, #0x2
1014aff7c:     	b.eq	0x1014affa0 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x174>
1014aff80:     	cmp	w8, #0x1
1014aff84:     	b.ne	0x1014b0074 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014aff88:     	ldr	x8, [x26], #0x38
1014aff8c:     	add	x23, x23, #0x38
1014aff90:     	sub	x20, x20, #0x38
1014aff94:     	cmp	x8, x28
1014aff98:     	b.eq	0x1014afec4 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x98>
1014aff9c:     	b	0x1014b0074 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014affa0:     	ldur	w8, [x26, #-0x4]
1014affa4:     	ldr	x9, [sp, #0x8]
1014affa8:     	cmp	x9, x8
1014affac:     	b.ls	0x1014b0074 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014affb0:     	ldr	x9, [sp]
1014affb4:     	ldr	x8, [x9, x8, lsl #3]
1014affb8:     	cmp	x8, x24
1014affbc:     	b.hs	0x1014b0074 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x248>
1014affc0:     	mov	w9, #0x38               ; =56
1014affc4:     	madd	x25, x8, x9, x21
1014affc8:     	ldr	x0, [x25, #0x30]
1014affcc:     	cmp	x0, x19
1014affd0:     	b.hs	0x1014b0098 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x26c>
1014affd4:     	add	x8, x27, x0, lsl #5
1014affd8:     	ldrb	w9, [x8]
1014affdc:     	cmp	w9, #0x3
1014affe0:     	b.ne	0x1014b0014 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x1e8>
1014affe4:     	ldr	x0, [x8, #0x8]
1014affe8:     	ldr	x8, [sp, #0x28]
1014affec:     	cmp	x0, x8
1014afff0:     	b.hs	0x1014b00a8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x27c>
1014afff4:     	ldr	x8, [sp, #0x20]
1014afff8:     	cmp	x0, x8
1014afffc:     	b.hs	0x1014b00b8 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x28c>
1014b0000:     	lsl	x8, x0, #6
1014b0004:     	ldr	x9, [sp, #0x10]
1014b0008:     	ldr	x9, [x9, x8]
1014b000c:     	cbnz	x9, 0x1014afe90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x64>
1014b0010:     	b	0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014b0014:     	ldp	q0, q1, [x8]
1014b0018:     	stp	q0, q1, [sp, #0x30]
1014b001c:     	ldr	x8, [sp, #0x18]
1014b0020:     	ldr	x8, [x8]
1014b0024:     	ldr	x1, [x8]
1014b0028:     	add	x0, sp, #0x58
1014b002c:     	add	x2, sp, #0x30
1014b0030:     	bl	0x1014b6e58 <__RNvMNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime13buffer_framesNtB2_12BufferFrames12current_leaf>
1014b0034:     	ldr	x8, [sp, #0x58]
1014b0038:     	cmp	x8, #0x1
1014b003c:     	b.ne	0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014b0040:     	ldr	x8, [sp, #0x60]
1014b0044:     	cbz	x8, 0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014b0048:     	ldr	x9, [x8]
1014b004c:     	b	0x1014afe90 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x64>
1014b0050:     	and	x8, x8, #0x1e
1014b0054:     	cmp	x8, #0x14
1014b0058:     	b.ne	0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014b005c:     	ldr	x1, [sp, #0x38]
1014b0060:     	cbz	x1, 0x1014b0070 <__RINvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared11frame_shapeNtB3_16FrameShapeRecipe15matches_currentNCNCINvMs_NtB5_17frame_compositionNtB5_25NativePreparedLibraryCall30admit_buffer_frame_compositionNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB41_10Invocation19buffer_frame_actions5_0Es_0s_0EB49_+0x244>
1014b0064:     	ldr	x0, [sp, #0x40]
1014b0068:     	mov	w2, #0x1                ; =1
1014b006c:     	bl	0x10000969c <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
1014b0070:     	mov	w22, #0x0               ; =0
1014b0074:     	mov	x0, x22
1014b0078:     	ldp	x29, x30, [sp, #0xc0]
1014b007c:     	ldp	x20, x19, [sp, #0xb0]
1014b0080:     	ldp	x22, x21, [sp, #0xa0]
1014b0084:     	ldp	x24, x23, [sp, #0x90]
1014b0088:     	ldp	x26, x25, [sp, #0x80]
1014b008c:     	ldp	x28, x27, [sp, #0x70]
1014b0090:     	add	sp, sp, #0xd0
1014b0094:     	ret
1014b0098:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b009c:     	add	x2, x2, #0x608
1014b00a0:     	mov	x1, x19
1014b00a4:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b00a8:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b00ac:     	add	x2, x2, #0x620
1014b00b0:     	ldr	x1, [sp, #0x28]
1014b00b4:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1014b00b8:     	adrp	x2, 0x107f09000 <_anon.29461557c93bc1ad21fc3809a7dfd56e.32+0x188>
1014b00bc:     	add	x2, x2, #0x638
1014b00c0:     	ldr	x1, [sp, #0x20]
1014b00c4:     	bl	0x103a05d40 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
