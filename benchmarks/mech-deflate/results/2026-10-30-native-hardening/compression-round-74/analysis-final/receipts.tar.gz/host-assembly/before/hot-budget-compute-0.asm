
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/before/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001023640c0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit>:
1023640c0:     	sub	sp, sp, #0x80
1023640c4:     	stp	x22, x21, [sp, #0x50]
1023640c8:     	stp	x20, x19, [sp, #0x60]
1023640cc:     	stp	x29, x30, [sp, #0x70]
1023640d0:     	add	x29, sp, #0x70
1023640d4:     	mov	x19, x8
1023640d8:     	ldr	x20, [x0]
1023640dc:     	ldr	x8, [x20, #0x10]
1023640e0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1023640e4:     	cmp	x8, x9
1023640e8:     	b.hs	0x102364154 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x94>
1023640ec:     	add	x9, x8, #0x1
1023640f0:     	str	x9, [x20, #0x10]
1023640f4:     	ldr	x9, [x20, #0x38]
1023640f8:     	adds	x9, x9, x1
1023640fc:     	b.hs	0x102364160 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xa0>
102364100:     	str	x8, [x20, #0x10]
102364104:     	cmp	x9, x2
102364108:     	b.ls	0x102364124 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x64>
10236410c:     	mov	w8, #0x606              ; =1542
102364110:     	strh	w8, [x19]
102364114:     	mov	w8, #0x1                ; =1
102364118:     	strb	w8, [x19, #0x2]
10236411c:     	stp	x9, x2, [x19, #0x8]
102364120:     	b	0x1023642f0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
102364124:     	adrp	x0, 0x108073000 <__mi_heap_main+0xb28>
102364128:     	add	x0, x0, #0x550
10236412c:     	ldr	x8, [x0]
102364130:     	blr	x8
102364134:     	ldrb	w8, [x0, #0x48]
102364138:     	cmp	w8, #0x1
10236413c:     	b.eq	0x1023641a8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xe8>
102364140:     	cmp	w8, #0x2
102364144:     	b.ne	0x102364180 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0xc0>
102364148:     	adrp	x0, 0x108035000 <_anon.686517066f445f70c1782692b9896900.7+0x55f00>
10236414c:     	add	x0, x0, #0xc40
102364150:     	bl	0x103a05590 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102364154:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102364158:     	add	x0, x0, #0x8b8
10236415c:     	bl	0x103a05c44 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102364160:     	mov	w9, #0x606              ; =1542
102364164:     	strh	w9, [x19]
102364168:     	mov	w9, #0x1                ; =1
10236416c:     	strb	w9, [x19, #0x2]
102364170:     	mov	x9, #-0x1               ; =-1
102364174:     	stp	x9, x2, [x19, #0x8]
102364178:     	str	x8, [x20, #0x10]
10236417c:     	b	0x1023642f0 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x230>
102364180:     	adrp	x8, 0x10277d000 <__RINvNtNtNtCskIfnrfrMWVM_9mech_core11type_system10conversion10population4walkNtNtNtB8_8function8resident19ResidentKernelErrorNCNvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident14set_conversion5stats11draft_nodes0EB28_+0x5dc>
102364184:     	add	x8, x8, #0x6bc
102364188:     	str	x0, [sp, #0x8]
10236418c:     	mov	x21, x1
102364190:     	mov	x1, x8
102364194:     	bl	0x102e7282c <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102364198:     	ldr	x0, [sp, #0x8]
10236419c:     	mov	x1, x21
1023641a0:     	mov	w8, #0x1                ; =1
1023641a4:     	strb	w8, [x0, #0x48]
1023641a8:     	ldr	x8, [x0, #0x20]
1023641ac:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1023641b0:     	cmp	x8, x9
1023641b4:     	b.hs	0x102364310 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x250>
1023641b8:     	ldr	x8, [x0, #0x28]
1023641bc:     	cmp	x8, #0x0
1023641c0:     	ccmp	x8, x20, #0x4, ne
1023641c4:     	b.ne	0x102364240 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x180>
1023641c8:     	ldr	x8, [x20, #0x10]
1023641cc:     	cbnz	x8, 0x10236431c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x25c>
1023641d0:     	mov	x8, #-0x1               ; =-1
1023641d4:     	str	x8, [x20, #0x10]
1023641d8:     	ldr	w8, [x0, #0x30]
1023641dc:     	ldp	x9, x10, [x0, #0x38]
1023641e0:     	ldp	x11, x12, [x20, #0x60]
1023641e4:     	cmp	x9, x11
1023641e8:     	csel	x9, x9, x11, lo
1023641ec:     	cmp	x10, x12
1023641f0:     	csel	x10, x10, x12, lo
1023641f4:     	tst	w8, #0x1
1023641f8:     	csel	x9, x9, x11, ne
1023641fc:     	csel	x13, x10, x12, ne
102364200:     	ldr	x8, [x20, #0x38]
102364204:     	adds	x21, x8, x1
102364208:     	b.hs	0x102364304 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
10236420c:     	ldr	x8, [x20, #0x48]
102364210:     	adds	x10, x8, x21
102364214:     	b.hs	0x102364304 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102364218:     	ldr	x22, [x20, #0x40]
10236421c:     	ldr	x8, [x20, #0x50]
102364220:     	adds	x14, x8, x22
102364224:     	b.hs	0x102364304 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x244>
102364228:     	cmp	x10, x9
10236422c:     	b.ls	0x102364248 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x188>
102364230:     	mov	w12, #0x6               ; =6
102364234:     	mov	w11, #0x1               ; =1
102364238:     	mov	w8, #0x6                ; =6
10236423c:     	b	0x1023642bc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102364240:     	mov	w8, #0x0                ; =0
102364244:     	b	0x1023642c8 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x208>
102364248:     	cmp	x14, x13
10236424c:     	b.ls	0x102364268 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1a8>
102364250:     	mov	w8, #0x6                ; =6
102364254:     	mov	w12, #0x5               ; =5
102364258:     	mov	w11, #0x1               ; =1
10236425c:     	mov	x9, x13
102364260:     	mov	x10, x14
102364264:     	b	0x1023642bc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102364268:     	mov	x0, x20
10236426c:     	ldr	x8, [x0, #0x70]!
102364270:     	cbz	x8, 0x10236428c <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1cc>
102364274:     	add	x8, sp, #0x28
102364278:     	mov	x2, #0x0                ; =0
10236427c:     	bl	0x10291be84 <__RNvMs1_NtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget7workersNtB5_20NativeWorkerWorkLoan6charge>
102364280:     	ldrb	w8, [sp, #0x28]
102364284:     	cmp	w8, #0x8
102364288:     	b.ne	0x102364298 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d8>
10236428c:     	stp	x21, x22, [x20, #0x38]
102364290:     	mov	w8, #0x8                ; =8
102364294:     	b	0x1023642bc <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1fc>
102364298:     	ldrb	w12, [sp, #0x29]
10236429c:     	ldrb	w11, [sp, #0x2a]
1023642a0:     	ldur	w9, [sp, #0x2b]
1023642a4:     	str	w9, [sp, #0x20]
1023642a8:     	ldrb	w9, [sp, #0x2f]
1023642ac:     	strb	w9, [sp, #0x24]
1023642b0:     	ldp	x10, x9, [sp, #0x30]
1023642b4:     	ldur	q0, [sp, #0x40]
1023642b8:     	str	q0, [sp, #0x10]
1023642bc:     	ldr	x13, [x20, #0x10]
1023642c0:     	add	x13, x13, #0x1
1023642c4:     	str	x13, [x20, #0x10]
1023642c8:     	strb	w8, [x19]
1023642cc:     	strb	w12, [x19, #0x1]
1023642d0:     	strb	w11, [x19, #0x2]
1023642d4:     	ldr	w8, [sp, #0x20]
1023642d8:     	stur	w8, [x19, #0x3]
1023642dc:     	ldrb	w8, [sp, #0x24]
1023642e0:     	strb	w8, [x19, #0x7]
1023642e4:     	stp	x10, x9, [x19, #0x8]
1023642e8:     	ldr	q0, [sp, #0x10]
1023642ec:     	stur	q0, [x19, #0x18]
1023642f0:     	ldp	x29, x30, [sp, #0x70]
1023642f4:     	ldp	x20, x19, [sp, #0x60]
1023642f8:     	ldp	x22, x21, [sp, #0x50]
1023642fc:     	add	sp, sp, #0x80
102364300:     	ret
102364304:     	mov	w8, #0x2                ; =2
102364308:     	mov	w11, #0x1               ; =1
10236430c:     	b	0x102364294 <__RNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB5_23NativeLibraryWorkBudget25charge_compute_with_limit+0x1d4>
102364310:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102364314:     	add	x0, x0, #0x870
102364318:     	bl	0x103a05c44 <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
10236431c:     	adrp	x0, 0x108037000 <_anon.2bf03b07bb14881f9e7a07d073725bdc.306+0x1a8>
102364320:     	add	x0, x0, #0x888
102364324:     	bl	0x103a05c14 <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102364328:     	ldr	x8, [x20, #0x10]
10236432c:     	add	x8, x8, #0x1
102364330:     	str	x8, [x20, #0x10]
102364334:     	bl	0x103a0710c <dyld_stub_binder+0x103a0710c>
