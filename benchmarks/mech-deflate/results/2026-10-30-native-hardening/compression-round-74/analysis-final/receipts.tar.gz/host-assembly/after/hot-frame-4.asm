
/private/tmp/mech-scoped-work-context-round74-20261031/linked-primary/after/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001015283f8 <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_>:
1015283f8:     	stp	x20, x19, [sp, #-0x20]!
1015283fc:     	stp	x29, x30, [sp, #0x10]
101528400:     	add	x29, sp, #0x10
101528404:     	mov	x19, x4
101528408:     	cmp	x3, x2
10152840c:     	b.hs	0x10152845c <__RNCNvMNtNtNtNtNtCs7fdMCt8k5K6_8mech_gpu15native_artifact7program7runtime10invocation13buffer_framesNtB6_10Invocation19buffer_frame_actions8_0Be_+0x64>
101528410:     	mov	w8, #0x170              ; =368
101528414:     	madd	x8, x3, x8, x1
101528418:     	add	x9, x8, #0x148
10152841c:     	ldr	q0, [x9]
101528420:     	stur	q0, [x0, #0x4]
101528424:     	ldp	q0, q1, [x19]
101528428:     	stur	q0, [x0, #0x18]
10152842c:     	ldr	w8, [x8, #0x158]
101528430:     	str	w8, [x0, #0x14]
101528434:     	stur	q1, [x0, #0x28]
101528438:     	ldr	q0, [x19, #0x20]
10152843c:     	stur	q0, [x0, #0x38]
101528440:     	ldr	x8, [x19, #0x30]
101528444:     	str	x8, [x0, #0x48]
101528448:     	mov	w8, #0x3                ; =3
10152844c:     	str	w8, [x0]
101528450:     	ldp	x29, x30, [sp, #0x10]
101528454:     	ldp	x20, x19, [sp], #0x20
101528458:     	ret
10152845c:     	adrp	x8, 0x107f07000 <_anon.b75e85eb86b947635c2754ac9db6558a.290+0x1b8>
101528460:     	add	x8, x8, #0xff0
101528464:     	mov	x0, x3
101528468:     	mov	x1, x2
10152846c:     	mov	x2, x8
101528470:     	bl	0x103a02024 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101528474:     	brk	#0x1
101528478:     	mov	x20, x0
10152847c:     	mov	x0, x19
101528480:     	bl	0x1015257ec <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs7fdMCt8k5K6_8mech_gpu>
101528484:     	mov	x0, x20
101528488:     	bl	0x103a033f0 <dyld_stub_binder+0x103a033f0>
