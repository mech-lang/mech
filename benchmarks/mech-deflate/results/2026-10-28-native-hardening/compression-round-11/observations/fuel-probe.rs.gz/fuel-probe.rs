use mech_core::{ManagedMemoryBudget,Value,ValueDataDraft,snapshot::{ValueDraft,SnapshotValidationContext}};
use mech_engine::{ProgramArtifact,CanonicalSourceFrontend};
use mech_gpu::native_artifact::{JitProgramArtifact,NativeExecutionLimits,NativeProgramExecutionLimits,emit_program_object};
use mech_syntax::document::{AstNode,DocumentId,Revision,TextSnapshot,ParseConfig,DocumentSyntax,parse_canonical_document};
fn inputs(
    artifact: &ProgramArtifact,
    named: &[(&str, ValueDataDraft)],
    memory: &ManagedMemoryBudget,
) -> Vec<Value> {
    artifact
        .inputs()
        .iter()
        .map(|input| {
            let name = mech_engine::decode_source_input_name(&input.name).unwrap();
            let data = named
                .iter()
                .find(|(key, _)| *key == name)
                .unwrap_or_else(|| panic!("missing {name}"))
                .1
                .clone();
            let shape_values = match &data {
                ValueDataDraft::Matrix(_)
                    if artifact
                        .schemas()
                        .get(input.schema)
                        .unwrap()
                        .dimension_parameters()
                        .is_empty() =>
                {
                    Box::new([])
                }
                ValueDataDraft::Matrix(values) => mech_core::shape_for_resolved_extents(
                    artifact.schemas().get(input.schema).unwrap(),
                    &[1, values.len() as u64],
                )
                .unwrap()
                .parameter_values()
                .to_vec()
                .into_boxed_slice(),
                _ => Box::new([]),
            };
            let value = ValueDraft {
                schema: input.schema,
                shape_values,
                data,
            }
            .finalize(&SnapshotValidationContext::new(artifact.schemas()))
            .unwrap();
            let mut reservation = memory
                .reserve_capacity(value.memory_budget_admission_bytes(memory).unwrap())
                .unwrap();
            value.into_memory_budget(&mut reservation).unwrap()
        })
        .collect()
}
fn limits() -> NativeProgramExecutionLimits {
    let mut library = mech_core::TargetMemoryProfile::current_resident_cpu()
        .unwrap()
        .limits;
    // Explicit finite qualification policy, NOT a default-budget/performance claim.
    library.max_compute_work = Some(134_217_728);
    library.max_comparison_work = Some(1_000_000);
    library.max_temporary_bytes = Some(128 * 1024 * 1024);
    NativeProgramExecutionLimits {
        execution: NativeExecutionLimits {
            max_work: 1_000_000_000,
            ..NativeExecutionLimits::default()
        },
        library,
    }
}
fn main(){
    let source = "walk(words<[u32]>, left<u64>, total<u64>, expected<u64>) => (out<bool>) :=\n  more := left > 0u64\n  value<u64> := (more? | true => words[1u64] | false => 0u32)\n  out := (more? | true => walk(words, left - 1u64, total + value, expected) | false => total == expected).\nwalk(words<[u32]>, steps<u64>, 0u64, expected<u64>)\n";
let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(42),Revision(1),source).unwrap(),ParseConfig::default());
let artifact=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),mech_stdlib::source_catalog()).unwrap().compile_artifact().unwrap();
let catalog=mech_stdlib::source_catalog();let jit=JitProgramArtifact::compile(&artifact,&catalog).unwrap();
let metadata=emit_program_object(&artifact,&catalog).unwrap().metadata();
let cost=metadata["readonly_numeric_regions"][0]["compute_per_traversal"].as_u64().unwrap();
let memory=ManagedMemoryBudget::new(256*1024*1024);let mut output=vec![None];
let mut policy=limits();policy.execution.max_work=1_000_000_000_000;policy.library.max_compute_work=Some(1_000_000_000_000);
for steps in [0,1,8,64] {
 let args=inputs(&artifact,&[("words",ValueDataDraft::Matrix(vec![ValueDataDraft::U32(3)].into())),("steps",ValueDataDraft::U64(steps)),("expected",ValueDataDraft::U64(steps*3))],&memory);
 let full=jit.evaluate_into(&args,&mut output,policy,&memory).unwrap();
 println!("{}",serde_json::json!({"steps":steps,"full_work":full.work,"full_visits":full.visits,"body_cost":cost}));
 for quarter in -4i64..=8 {
  let limit=(full.work as i64+quarter*cost as i64/4) as u64; let mut bounded=policy; bounded.execution.max_work=limit;
  let prior=output.clone();let before=(memory.used_bytes(),memory.retained_snapshot_nodes());
  let run=jit.evaluate_into(&args,&mut output,bounded,&memory);
  if run.is_err(){assert_eq!(before,(memory.used_bytes(),memory.retained_snapshot_nodes()));assert!(output[0].as_ref().unwrap().shares_frozen_storage(prior[0].as_ref().unwrap()));}
  else {assert_eq!(output[0].as_ref().unwrap().canonical_data_draft().unwrap(),ValueDataDraft::Bool(true));}
  println!("{}",serde_json::json!({"steps":steps,"quarter_delta":quarter,"limit":limit,"result":format!("{run:?}")}));
 }
}
drop(output);assert_eq!(memory.used_bytes(),0);assert_eq!(memory.retained_snapshot_nodes(),0);
}
