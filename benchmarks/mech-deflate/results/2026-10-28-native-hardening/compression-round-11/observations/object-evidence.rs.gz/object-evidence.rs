use mech_gpu::native_artifact::{emit_program_object_with_limits, NativeProgramLimitMode};
fn main() {
 let args: Vec<_> = std::env::args().skip(1).collect(); assert_eq!(args.len(), 2);
 let artifact = mech_engine::decode_program_artifact_bytecode_v1(&std::fs::read(&args[0]).unwrap()).unwrap();
 let object = emit_program_object_with_limits(&artifact, &mech_stdlib::source_catalog(), NativeProgramLimitMode::NoLimits.compilation()).unwrap();
 std::fs::write(format!("{}.o", args[1]), object.bytes()).unwrap();
 let metadata = object.metadata();
 std::fs::write(format!("{}.json", args[1]), serde_json::to_vec_pretty(&metadata).unwrap()).unwrap();
 let regions = metadata["compiled_readonly_numeric_loops"].as_array().unwrap();
 assert!(!regions.is_empty());
 assert!(regions.iter().any(|r| r["parent"].is_number()));
 assert!(regions.iter().all(|r| r["successful_backedge_helpers"] == 0));
 println!("{}", serde_json::json!({"selected":regions.len(), "parents":regions.iter().filter(|r| r["parent"].is_number()).count(),"typed_load_sites":regions.iter().map(|r| r["typed_loads"].as_array().unwrap().len()).sum::<usize>(),"object_bytes":object.bytes().len()}));
}
