
/private/tmp/mech-consuming-stores-round06-20261028/current:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101584968 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation12word_updatesNtB6_10Invocation28unsigned_matrix_replace_calls4_0Be_>:
101584968: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
10158496c: a9017bfd    	stp	x29, x30, [sp, #0x10]
101584970: 910043fd    	add	x29, sp, #0x10
101584974: aa0403f3    	mov	x19, x4
101584978: eb02007f    	cmp	x3, x2
10158497c: 54000282    	b.hs	0x1015849cc <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation12word_updatesNtB6_10Invocation28unsigned_matrix_replace_calls4_0Be_+0x64>
101584980: 52802e08    	mov	w8, #0x170              ; =368
101584984: 9b080468    	madd	x8, x3, x8, x1
101584988: 91052109    	add	x9, x8, #0x148
10158498c: 3dc00120    	ldr	q0, [x9]
101584990: 3c804000    	stur	q0, [x0, #0x4]
101584994: ad400660    	ldp	q0, q1, [x19]
101584998: 3c818000    	stur	q0, [x0, #0x18]
10158499c: b9415908    	ldr	w8, [x8, #0x158]
1015849a0: b9001408    	str	w8, [x0, #0x14]
1015849a4: 3c828001    	stur	q1, [x0, #0x28]
1015849a8: 3dc00a60    	ldr	q0, [x19, #0x20]
1015849ac: 3c838000    	stur	q0, [x0, #0x38]
1015849b0: f9401a68    	ldr	x8, [x19, #0x30]
1015849b4: f9002408    	str	x8, [x0, #0x48]
1015849b8: 52800068    	mov	w8, #0x3                ; =3
1015849bc: b9000008    	str	w8, [x0]
1015849c0: a9417bfd    	ldp	x29, x30, [sp, #0x10]
1015849c4: a8c24ff4    	ldp	x20, x19, [sp], #0x20
1015849c8: d65f03c0    	ret
1015849cc: f0011fc8    	adrp	x8, 0x10397f000 <_anon.9857cef1afd9a1048098b729939c7a99.396+0x28>
1015849d0: 913a2108    	add	x8, x8, #0xe88
1015849d4: aa0303e0    	mov	x0, x3
1015849d8: aa0203e1    	mov	x1, x2
1015849dc: aa0803e2    	mov	x2, x8
1015849e0: 9460b142    	bl	0x102db0ee8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1015849e4: d4200020    	brk	#0x1
1015849e8: aa0003f4    	mov	x20, x0
1015849ec: aa1303e0    	mov	x0, x19
1015849f0: 97fff442    	bl	0x101581af8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorECs29QkOtpKx6e_8mech_gpu>
1015849f4: aa1403e0    	mov	x0, x20
1015849f8: 9460b62f    	bl	0x102db22b4 <dyld_stub_binder+0x102db22b4>
