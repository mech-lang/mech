
/private/tmp/mech-consuming-stores-round06-20261028/current:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010244e32c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace>:
10244e32c: d101c3ff    	sub	sp, sp, #0x70
10244e330: a90457f6    	stp	x22, x21, [sp, #0x40]
10244e334: a9054ff4    	stp	x20, x19, [sp, #0x50]
10244e338: a9067bfd    	stp	x29, x30, [sp, #0x60]
10244e33c: 910183fd    	add	x29, sp, #0x60
10244e340: aa0203f4    	mov	x20, x2
10244e344: aa0103f5    	mov	x21, x1
10244e348: aa0803f3    	mov	x19, x8
10244e34c: f9400008    	ldr	x8, [x0]
10244e350: f100051f    	cmp	x8, #0x1
10244e354: 540001cc    	b.gt	0x10244e38c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0x60>
10244e358: b5000368    	cbnz	x8, 0x10244e3c4 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0x98>
10244e35c: 52800588    	mov	w8, #0x2c               ; =44
10244e360: f103fe9f    	cmp	x20, #0xff
10244e364: 540005c8    	b.hi	0x10244e41c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xf0>
10244e368: f9400c09    	ldr	x9, [x0, #0x18]
10244e36c: eb0902bf    	cmp	x21, x9
10244e370: 54000562    	b.hs	0x10244e41c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xf0>
10244e374: f9400816    	ldr	x22, [x0, #0x10]
10244e378: 390023e8    	strb	w8, [sp, #0x8]
10244e37c: 910023e0    	add	x0, sp, #0x8
10244e380: 97fdcf38    	bl	0x1023c2060 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10244e384: 38356ad4    	strb	w20, [x22, x21]
10244e388: 14000024    	b	0x10244e418 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xec>
10244e38c: f100091f    	cmp	x8, #0x2
10244e390: 54000321    	b.ne	0x10244e3f4 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xc8>
10244e394: 52800588    	mov	w8, #0x2c               ; =44
10244e398: d360fe89    	lsr	x9, x20, #32
10244e39c: b5000409    	cbnz	x9, 0x10244e41c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xf0>
10244e3a0: f9400c09    	ldr	x9, [x0, #0x18]
10244e3a4: eb0902bf    	cmp	x21, x9
10244e3a8: 540003a2    	b.hs	0x10244e41c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xf0>
10244e3ac: f9400816    	ldr	x22, [x0, #0x10]
10244e3b0: 390023e8    	strb	w8, [sp, #0x8]
10244e3b4: 910023e0    	add	x0, sp, #0x8
10244e3b8: 97fdcf2a    	bl	0x1023c2060 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10244e3bc: b8357ad4    	str	w20, [x22, x21, lsl #2]
10244e3c0: 14000016    	b	0x10244e418 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xec>
10244e3c4: 52800588    	mov	w8, #0x2c               ; =44
10244e3c8: d350fe89    	lsr	x9, x20, #16
10244e3cc: b5000289    	cbnz	x9, 0x10244e41c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xf0>
10244e3d0: f9400c09    	ldr	x9, [x0, #0x18]
10244e3d4: eb0902bf    	cmp	x21, x9
10244e3d8: 54000222    	b.hs	0x10244e41c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xf0>
10244e3dc: f9400816    	ldr	x22, [x0, #0x10]
10244e3e0: 390023e8    	strb	w8, [sp, #0x8]
10244e3e4: 910023e0    	add	x0, sp, #0x8
10244e3e8: 97fdcf1e    	bl	0x1023c2060 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10244e3ec: 78357ad4    	strh	w20, [x22, x21, lsl #1]
10244e3f0: 1400000a    	b	0x10244e418 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xec>
10244e3f4: f9400c09    	ldr	x9, [x0, #0x18]
10244e3f8: 52800588    	mov	w8, #0x2c               ; =44
10244e3fc: eb0902bf    	cmp	x21, x9
10244e400: 540000e2    	b.hs	0x10244e41c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace+0xf0>
10244e404: f9400816    	ldr	x22, [x0, #0x10]
10244e408: 390023e8    	strb	w8, [sp, #0x8]
10244e40c: 910023e0    	add	x0, sp, #0x8
10244e410: 97fdcf14    	bl	0x1023c2060 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10244e414: f8357ad4    	str	x20, [x22, x21, lsl #3]
10244e418: 528005c8    	mov	w8, #0x2e               ; =46
10244e41c: 39000268    	strb	w8, [x19]
10244e420: a9467bfd    	ldp	x29, x30, [sp, #0x60]
10244e424: a9454ff4    	ldp	x20, x19, [sp, #0x50]
10244e428: a94457f6    	ldp	x22, x21, [sp, #0x40]
10244e42c: 9101c3ff    	add	sp, sp, #0x70
10244e430: d65f03c0    	ret
