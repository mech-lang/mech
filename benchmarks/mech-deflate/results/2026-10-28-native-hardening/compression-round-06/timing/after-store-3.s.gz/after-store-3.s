
/private/tmp/mech-consuming-stores-round06-20261028/current:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010260ed14 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width>:
10260ed14: f9403c08    	ldr	x8, [x0, #0x78]
10260ed18: f1000d1f    	cmp	x8, #0x3
10260ed1c: 54000301    	b.ne	0x10260ed7c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x68>
10260ed20: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
10260ed24: a9015ff8    	stp	x24, x23, [sp, #0x10]
10260ed28: a90257f6    	stp	x22, x21, [sp, #0x20]
10260ed2c: a9034ff4    	stp	x20, x19, [sp, #0x30]
10260ed30: a9047bfd    	stp	x29, x30, [sp, #0x40]
10260ed34: 910103fd    	add	x29, sp, #0x40
10260ed38: aa0003f5    	mov	x21, x0
10260ed3c: f9403813    	ldr	x19, [x0, #0x70]
10260ed40: aa1303f4    	mov	x20, x19
10260ed44: 384a0688    	ldrb	w8, [x20], #0xa0
10260ed48: f9400809    	ldr	x9, [x0, #0x10]
10260ed4c: 7100411f    	cmp	w8, #0x10
10260ed50: fa4d0920    	ccmp	x9, #0xd, #0x0, eq
10260ed54: 54000961    	b.ne	0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ed58: f9402676    	ldr	x22, [x19, #0x48]
10260ed5c: f94036a8    	ldr	x8, [x21, #0x68]
10260ed60: eb0802df    	cmp	x22, x8
10260ed64: 540008e1    	b.ne	0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ed68: b4000436    	cbz	x22, 0x10260edec <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0xd8>
10260ed6c: d2800017    	mov	x23, #0x0               ; =0
10260ed70: f94032b8    	ldr	x24, [x21, #0x60]
10260ed74: f9402279    	ldr	x25, [x19, #0x40]
10260ed78: 14000009    	b	0x10260ed9c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x88>
10260ed7c: d2800000    	mov	x0, #0x0                ; =0
10260ed80: d65f03c0    	ret
10260ed84: 71001d1f    	cmp	w8, #0x7
10260ed88: 7a470920    	ccmp	w9, #0x7, #0x0, eq
10260ed8c: 540007a1    	b.ne	0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ed90: 9100e2f7    	add	x23, x23, #0x38
10260ed94: f10006d6    	subs	x22, x22, #0x1
10260ed98: 540002a0    	b.eq	0x10260edec <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0xd8>
10260ed9c: 8b170328    	add	x8, x25, x23
10260eda0: 8b170309    	add	x9, x24, x23
10260eda4: 3940c108    	ldrb	w8, [x8, #0x30]
10260eda8: 3940c129    	ldrb	w9, [x9, #0x30]
10260edac: 6b09011f    	cmp	w8, w9
10260edb0: 54000681    	b.ne	0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260edb4: 8b170320    	add	x0, x25, x23
10260edb8: 8b170301    	add	x1, x24, x23
10260edbc: 9401f731    	bl	0x10268ca80 <__RNvXst_NtCskIfnrfrMWVM_9mech_core9dimensionNtB5_13DimensionExprNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
10260edc0: 34000600    	cbz	w0, 0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260edc4: 8b170320    	add	x0, x25, x23
10260edc8: b8418c08    	ldr	w8, [x0, #0x18]!
10260edcc: 8b170301    	add	x1, x24, x23
10260edd0: b8418c29    	ldr	w9, [x1, #0x18]!
10260edd4: 71001d1f    	cmp	w8, #0x7
10260edd8: 7a471924    	ccmp	w9, #0x7, #0x4, ne
10260eddc: 54fffd40    	b.eq	0x10260ed84 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x70>
10260ede0: 9401f728    	bl	0x10268ca80 <__RNvXst_NtCskIfnrfrMWVM_9mech_core9dimensionNtB5_13DimensionExprNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
10260ede4: 3707fd60    	tbnz	w0, #0x0, 0x10260ed90 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x7c>
10260ede8: 14000026    	b	0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260edec: 910082a1    	add	x1, x21, #0x20
10260edf0: aa1303e0    	mov	x0, x19
10260edf4: 9400ac1a    	bl	0x102639e5c <__RNvXsl_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
10260edf8: 34000440    	cbz	w0, 0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260edfc: f9400e68    	ldr	x8, [x19, #0x18]
10260ee00: f100091f    	cmp	x8, #0x2
10260ee04: 540003e1    	b.ne	0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ee08: f9400675    	ldr	x21, [x19, #0x8]
10260ee0c: 91014261    	add	x1, x19, #0x50
10260ee10: aa1503e0    	mov	x0, x21
10260ee14: 9400ac12    	bl	0x102639e5c <__RNvXsl_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
10260ee18: 34000340    	cbz	w0, 0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ee1c: f9404e68    	ldr	x8, [x19, #0x98]
10260ee20: b5000308    	cbnz	x8, 0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ee24: d0005a61    	adrp	x1, 0x10315c000 <_anon.e5fbae1d60c5dc9136622cd4548a9142.93+0x18>
10260ee28: 91038021    	add	x1, x1, #0xe0
10260ee2c: aa1403e0    	mov	x0, x20
10260ee30: 9400ac0b    	bl	0x102639e5c <__RNvXsl_NtCskIfnrfrMWVM_9mech_core6schemaNtB5_10SchemaBodyNtNtCsgDHHaSskbIF_4core3cmp9PartialEq2eq>
10260ee34: 34000260    	cbz	w0, 0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ee38: f9407668    	ldr	x8, [x19, #0xe8]
10260ee3c: b5000228    	cbnz	x8, 0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ee40: 394002a8    	ldrb	w8, [x21]
10260ee44: 7100091f    	cmp	w8, #0x2
10260ee48: 540001c1    	b.ne	0x10260ee80 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x16c>
10260ee4c: 794006a8    	ldrh	w8, [x21, #0x2]
10260ee50: 5ac00108    	rbit	w8, w8
10260ee54: 5ac01108    	clz	w8, w8
10260ee58: 531d7108    	lsl	w8, w8, #3
10260ee5c: 51006108    	sub	w8, w8, #0x18
10260ee60: 927d3d08    	and	x8, x8, #0x7fff8
10260ee64: f0005a69    	adrp	x9, 0x10315d000 <_anon.e5fbae1d60c5dc9136622cd4548a9142.481+0x5d5>
10260ee68: 9136a129    	add	x9, x9, #0xda8
10260ee6c: f8686921    	ldr	x1, [x9, x8]
10260ee70: f0005a69    	adrp	x9, 0x10315d000 <_anon.e5fbae1d60c5dc9136622cd4548a9142.481+0x5d5>
10260ee74: 91374129    	add	x9, x9, #0xdd0
10260ee78: f8686920    	ldr	x0, [x9, x8]
10260ee7c: 14000002    	b	0x10260ee84 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width+0x170>
10260ee80: d2800000    	mov	x0, #0x0                ; =0
10260ee84: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10260ee88: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10260ee8c: a94257f6    	ldp	x22, x21, [sp, #0x20]
10260ee90: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10260ee94: a8c567fa    	ldp	x26, x25, [sp], #0x50
10260ee98: d65f03c0    	ret
