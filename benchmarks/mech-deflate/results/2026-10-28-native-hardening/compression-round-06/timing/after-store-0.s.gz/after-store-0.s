
/private/tmp/mech-consuming-stores-round06-20261028/current:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101584904 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation12word_updatesNtB6_10Invocation28unsigned_matrix_replace_calls0_0Be_>:
101584904: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
101584908: 910003fd    	mov	x29, sp
10158490c: f9400808    	ldr	x8, [x0, #0x10]
101584910: eb08003f    	cmp	x1, x8
101584914: 54000182    	b.hs	0x101584944 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation12word_updatesNtB6_10Invocation28unsigned_matrix_replace_calls0_0Be_+0x40>
101584918: a9402809    	ldp	x9, x10, [x0]
10158491c: f9418928    	ldr	x8, [x9, #0x310]
101584920: b8617940    	ldr	w0, [x10, x1, lsl #2]
101584924: eb00011f    	cmp	x8, x0
101584928: 54000189    	b.ls	0x101584958 <__RNCNvMNtNtNtNtNtCs29QkOtpKx6e_8mech_gpu15native_artifact7program7runtime10invocation12word_updatesNtB6_10Invocation28unsigned_matrix_replace_calls0_0Be_+0x54>
10158492c: f9418528    	ldr	x8, [x9, #0x308]
101584930: 52802809    	mov	w9, #0x140              ; =320
101584934: 9ba92008    	umaddl	x8, w0, w9, x8
101584938: 39449100    	ldrb	w0, [x8, #0x124]
10158493c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
101584940: d65f03c0    	ret
101584944: f0011fc2    	adrp	x2, 0x10397f000 <_anon.9857cef1afd9a1048098b729939c7a99.396+0x28>
101584948: 91396042    	add	x2, x2, #0xe58
10158494c: aa0103e0    	mov	x0, x1
101584950: aa0803e1    	mov	x1, x8
101584954: 9460b165    	bl	0x102db0ee8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
101584958: f0011fc2    	adrp	x2, 0x10397f000 <_anon.9857cef1afd9a1048098b729939c7a99.396+0x28>
10158495c: 9139c042    	add	x2, x2, #0xe70
101584960: aa0803e1    	mov	x1, x8
101584964: 9460b161    	bl	0x102db0ee8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
