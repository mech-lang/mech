
/private/tmp/mech-consuming-stores-round06-20261028/current:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010260ee9c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall32supports_unsigned_matrix_replace>:
10260ee9c: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
10260eea0: 910003fd    	mov	x29, sp
10260eea4: 97ffff9c    	bl	0x10260ed14 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width>
10260eea8: f100041f    	cmp	x0, #0x1
10260eeac: 1a9f17e0    	cset	w0, eq
10260eeb0: a8c17bfd    	ldp	x29, x30, [sp], #0x10
10260eeb4: d65f03c0    	ret
