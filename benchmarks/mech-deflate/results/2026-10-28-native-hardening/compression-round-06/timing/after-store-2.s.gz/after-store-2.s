
/private/tmp/mech-consuming-stores-round06-20261028/current:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010260eaf4 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace>:
10260eaf4: d10643ff    	sub	sp, sp, #0x190
10260eaf8: a9136ffc    	stp	x28, x27, [sp, #0x130]
10260eafc: a91467fa    	stp	x26, x25, [sp, #0x140]
10260eb00: a9155ff8    	stp	x24, x23, [sp, #0x150]
10260eb04: a91657f6    	stp	x22, x21, [sp, #0x160]
10260eb08: a9174ff4    	stp	x20, x19, [sp, #0x170]
10260eb0c: a9187bfd    	stp	x29, x30, [sp, #0x180]
10260eb10: 910603fd    	add	x29, sp, #0x180
10260eb14: aa0103f5    	mov	x21, x1
10260eb18: aa0803f3    	mov	x19, x8
10260eb1c: a9000fe2    	stp	x2, x3, [sp]
10260eb20: 39005fe4    	strb	w4, [sp, #0x17]
10260eb24: f94018a8    	ldr	x8, [x5, #0x30]
10260eb28: ad4080a1    	ldp	q1, q0, [x5, #0x10]
10260eb2c: 3dc000a2    	ldr	q2, [x5]
10260eb30: 4e181d00    	mov.d	v0[1], x8
10260eb34: 4ec13841    	zip1.2d	v1, v2, v1
10260eb38: 4ee09800    	cmeq.2d	v0, v0, #0
10260eb3c: 4ee09821    	cmeq.2d	v1, v1, #0
10260eb40: 4e801820    	uzp1.4s	v0, v1, v0
10260eb44: 6eb0a800    	umaxv.4s	s0, v0
10260eb48: 1e260008    	fmov	w8, s0
10260eb4c: 370003a8    	tbnz	w8, #0x0, 0x10260ebc0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0xcc>
10260eb50: aa0503f7    	mov	x23, x5
10260eb54: f94020a8    	ldr	x8, [x5, #0x40]
10260eb58: b4000348    	cbz	x8, 0x10260ebc0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0xcc>
10260eb5c: f9402ae8    	ldr	x8, [x23, #0x50]
10260eb60: b4000308    	cbz	x8, 0x10260ebc0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0xcc>
10260eb64: f94032e8    	ldr	x8, [x23, #0x60]
10260eb68: b40002c8    	cbz	x8, 0x10260ebc0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0xcc>
10260eb6c: aa0703f6    	mov	x22, x7
10260eb70: aa0603f4    	mov	x20, x6
10260eb74: aa0303f8    	mov	x24, x3
10260eb78: aa0003fa    	mov	x26, x0
10260eb7c: 94000066    	bl	0x10260ed14 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall29unsigned_matrix_replace_width>
10260eb80: 52800588    	mov	w8, #0x2c               ; =44
10260eb84: 3902c3e8    	strb	w8, [sp, #0xb0]
10260eb88: f100041f    	cmp	x0, #0x1
10260eb8c: 54000141    	b.ne	0x10260ebb4 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0xc0>
10260eb90: aa0103f9    	mov	x25, x1
10260eb94: 9102c3e0    	add	x0, sp, #0xb0
10260eb98: 97fed87f    	bl	0x1025c4d94 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10260eb9c: f9000ff9    	str	x25, [sp, #0x18]
10260eba0: f100233f    	cmp	x25, #0x8
10260eba4: 54000342    	b.hs	0x10260ec0c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0x118>
10260eba8: d37df328    	lsl	x8, x25, #3
10260ebac: 9ac82708    	lsr	x8, x24, x8
10260ebb0: b40002e8    	cbz	x8, 0x10260ec0c <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0x118>
10260ebb4: 52800588    	mov	w8, #0x2c               ; =44
10260ebb8: 39000268    	strb	w8, [x19]
10260ebbc: 14000009    	b	0x10260ebe0 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0xec>
10260ebc0: b9411008    	ldr	w8, [x0, #0x110]
10260ebc4: 52800449    	mov	w9, #0x22               ; =34
10260ebc8: 39000269    	strb	w9, [x19]
10260ebcc: f0005a69    	adrp	x9, 0x10315d000 <_anon.e5fbae1d60c5dc9136622cd4548a9142.481+0x5d5>
10260ebd0: 911b2129    	add	x9, x9, #0x6c8
10260ebd4: 528006ca    	mov	w10, #0x36              ; =54
10260ebd8: a900aa69    	stp	x9, x10, [x19, #0x8]
10260ebdc: b9001a68    	str	w8, [x19, #0x18]
10260ebe0: 52800048    	mov	w8, #0x2                ; =2
10260ebe4: 39010268    	strb	w8, [x19, #0x40]
10260ebe8: aa1503e0    	mov	x0, x21
10260ebec: a9587bfd    	ldp	x29, x30, [sp, #0x180]
10260ebf0: a9574ff4    	ldp	x20, x19, [sp, #0x170]
10260ebf4: a95657f6    	ldp	x22, x21, [sp, #0x160]
10260ebf8: a9555ff8    	ldp	x24, x23, [sp, #0x150]
10260ebfc: a95467fa    	ldp	x26, x25, [sp, #0x140]
10260ec00: a9536ffc    	ldp	x28, x27, [sp, #0x130]
10260ec04: 910643ff    	add	sp, sp, #0x190
10260ec08: 17fed524    	b	0x1025c4098 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10260ec0c: 9101a3f8    	add	x24, sp, #0x68
10260ec10: f94036e1    	ldr	x1, [x23, #0x68]
10260ec14: f9402ee2    	ldr	x2, [x23, #0x58]
10260ec18: ad4006a0    	ldp	q0, q1, [x21]
10260ec1c: ad028700    	stp	q0, q1, [x24, #0x50]
10260ec20: ad4106a0    	ldp	q0, q1, [x21, #0x20]
10260ec24: ad038700    	stp	q0, q1, [x24, #0x70]
10260ec28: f9005bfa    	str	x26, [sp, #0xb0]
10260ec2c: a90fdff4    	stp	x20, x23, [sp, #0xf8]
10260ec30: 910003e8    	mov	x8, sp
10260ec34: 910063e9    	add	x9, sp, #0x18
10260ec38: a910a3f6    	stp	x22, x8, [sp, #0x108]
10260ec3c: f9008fe9    	str	x9, [sp, #0x118]
10260ec40: 910023e8    	add	x8, sp, #0x8
10260ec44: 91005fe9    	add	x9, sp, #0x17
10260ec48: a91227e8    	stp	x8, x9, [sp, #0x120]
10260ec4c: 9101a3e8    	add	x8, sp, #0x68
10260ec50: 9102c3e3    	add	x3, sp, #0xb0
10260ec54: aa1403e0    	mov	x0, x20
10260ec58: 94022220    	bl	0x1026974d8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_>
10260ec5c: 3942a3e8    	ldrb	w8, [sp, #0xa8]
10260ec60: 71000d1f    	cmp	w8, #0x3
10260ec64: 54000241    	b.ne	0x10260ecac <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0x1b8>
10260ec68: 3cc683e0    	ldur	q0, [sp, #0x68]
10260ec6c: 3cc783e1    	ldur	q1, [sp, #0x78]
10260ec70: ad0107e0    	stp	q0, q1, [sp, #0x20]
10260ec74: f94047e8    	ldr	x8, [sp, #0x88]
10260ec78: f90023e8    	str	x8, [sp, #0x40]
10260ec7c: 3c84f300    	stur	q0, [x24, #0x4f]
10260ec80: 3c85f301    	stur	q1, [x24, #0x5f]
10260ec84: f806f308    	stur	x8, [x24, #0x6f]
10260ec88: 52800528    	mov	w8, #0x29               ; =41
10260ec8c: 39000268    	strb	w8, [x19]
10260ec90: ad4587e0    	ldp	q0, q1, [sp, #0xb0]
10260ec94: 3c801260    	stur	q0, [x19, #0x1]
10260ec98: 3c811261    	stur	q1, [x19, #0x11]
10260ec9c: 3cc67300    	ldur	q0, [x24, #0x67]
10260eca0: 3d800a60    	str	q0, [x19, #0x20]
10260eca4: 52800048    	mov	w8, #0x2                ; =2
10260eca8: 1400000c    	b	0x10260ecd8 <__RNvMNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updatesNtB4_25NativePreparedLibraryCall23unsigned_matrix_replace+0x1e4>
10260ecac: 3cc683e0    	ldur	q0, [sp, #0x68]
10260ecb0: 3cc783e1    	ldur	q1, [sp, #0x78]
10260ecb4: ad0107e0    	stp	q0, q1, [sp, #0x20]
10260ecb8: ad410f02    	ldp	q2, q3, [x24, #0x20]
10260ecbc: ad020fe2    	stp	q2, q3, [sp, #0x40]
10260ecc0: b8441309    	ldur	w9, [x24, #0x41]
10260ecc4: b8041269    	stur	w9, [x19, #0x41]
10260ecc8: b940afe9    	ldr	w9, [sp, #0xac]
10260eccc: b9004669    	str	w9, [x19, #0x44]
10260ecd0: ad000660    	stp	q0, q1, [x19]
10260ecd4: ad010e62    	stp	q2, q3, [x19, #0x20]
10260ecd8: 39010268    	strb	w8, [x19, #0x40]
10260ecdc: a9587bfd    	ldp	x29, x30, [sp, #0x180]
10260ece0: a9574ff4    	ldp	x20, x19, [sp, #0x170]
10260ece4: a95657f6    	ldp	x22, x21, [sp, #0x160]
10260ece8: a9555ff8    	ldp	x24, x23, [sp, #0x150]
10260ecec: a95467fa    	ldp	x26, x25, [sp, #0x140]
10260ecf0: a9536ffc    	ldp	x28, x27, [sp, #0x130]
10260ecf4: 910643ff    	add	sp, sp, #0x190
10260ecf8: d65f03c0    	ret
10260ecfc: aa0003f3    	mov	x19, x0
10260ed00: aa1503e0    	mov	x0, x21
10260ed04: 97fed4e5    	bl	0x1025c4098 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
10260ed08: aa1303e0    	mov	x0, x19
10260ed0c: 941e8d6a    	bl	0x102db22b4 <dyld_stub_binder+0x102db22b4>
10260ed10: 941e8870    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
