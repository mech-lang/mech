
/private/tmp/mech-consuming-stores-round06-20261028/current:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001026974d8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_>:
1026974d8: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1026974dc: a90167fa    	stp	x26, x25, [sp, #0x10]
1026974e0: a9025ff8    	stp	x24, x23, [sp, #0x20]
1026974e4: a90357f6    	stp	x22, x21, [sp, #0x30]
1026974e8: a9044ff4    	stp	x20, x19, [sp, #0x40]
1026974ec: a9057bfd    	stp	x29, x30, [sp, #0x50]
1026974f0: 910143fd    	add	x29, sp, #0x50
1026974f4: d12383ff    	sub	sp, sp, #0x8e0
1026974f8: f90003ff    	str	xzr, [sp]
1026974fc: aa0803f4    	mov	x20, x8
102697500: ad420460    	ldp	q0, q1, [x3, #0x40]
102697504: 3c8f03e0    	stur	q0, [sp, #0xf0]
102697508: 910263f3    	add	x19, sp, #0x98
10269750c: 910007e8    	add	x8, sp, #0x1
102697510: 3c8ff101    	stur	q1, [x8, #0xff]
102697514: ad430460    	ldp	q0, q1, [x3, #0x60]
102697518: 3c878260    	stur	q0, [x19, #0x78]
10269751c: 3c888261    	stur	q1, [x19, #0x88]
102697520: ad400460    	ldp	q0, q1, [x3]
102697524: ad0587e0    	stp	q0, q1, [sp, #0xb0]
102697528: ad410460    	ldp	q0, q1, [x3, #0x20]
10269752c: ad0687e0    	stp	q0, q1, [sp, #0xd0]
102697530: a9088be1    	stp	x1, x2, [sp, #0x88]
102697534: 910223e8    	add	x8, sp, #0x88
102697538: a909a3e0    	stp	x0, x8, [sp, #0x98]
10269753c: 910243e8    	add	x8, sp, #0x90
102697540: f90057e8    	str	x8, [sp, #0xa8]
102697544: 9000a220    	adrp	x0, 0x103adb000 <__mi_heap_main+0xb68>
102697548: 9114a000    	add	x0, x0, #0x528
10269754c: f9400008    	ldr	x8, [x0]
102697550: d63f0100    	blr	x8
102697554: 39404008    	ldrb	w8, [x0, #0x10]
102697558: 7100051f    	cmp	w8, #0x1
10269755c: 54000200    	b.eq	0x10269759c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xc4>
102697560: 7100091f    	cmp	w8, #0x2
102697564: 540000e1    	b.ne	0x102697580 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xa8>
102697568: 910263e8    	add	x8, sp, #0x98
10269756c: 91008100    	add	x0, x8, #0x20
102697570: 94007070    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102697574: d000a0a0    	adrp	x0, 0x103aad000 <_anon.765e5019d1254bf8dfb752f0db35bb73.628+0x448>
102697578: 911e0000    	add	x0, x0, #0x780
10269757c: 941c646f    	bl	0x102db0738 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
102697580: f0fff9a1    	adrp	x1, 0x1025ce000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy3_EB8_+0x91c>
102697584: 91341021    	add	x1, x1, #0xd04
102697588: aa0003f5    	mov	x21, x0
10269758c: 941b2357    	bl	0x102d602e8 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102697590: 52800028    	mov	w8, #0x1                ; =1
102697594: aa1503e0    	mov	x0, x21
102697598: 390042a8    	strb	w8, [x21, #0x10]
10269759c: 9104c3e8    	add	x8, sp, #0x130
1026975a0: 3ccf83e0    	ldur	q0, [sp, #0xf8]
1026975a4: 910027e9    	add	x9, sp, #0x9
1026975a8: 3ccff121    	ldur	q1, [x9, #0xff]
1026975ac: 3c8f8260    	stur	q0, [x19, #0xf8]
1026975b0: 910067e9    	add	x9, sp, #0x19
1026975b4: 3ccff120    	ldur	q0, [x9, #0xff]
1026975b8: ad038101    	stp	q1, q0, [x8, #0x70]
1026975bc: f94097e9    	ldr	x9, [sp, #0x128]
1026975c0: f900e3e9    	str	x9, [sp, #0x1c0]
1026975c4: 3ccb83e0    	ldur	q0, [sp, #0xb8]
1026975c8: 3ccc83e1    	ldur	q1, [sp, #0xc8]
1026975cc: ad010500    	stp	q0, q1, [x8, #0x20]
1026975d0: 3ccd83e0    	ldur	q0, [sp, #0xd8]
1026975d4: 3cce83e1    	ldur	q1, [sp, #0xe8]
1026975d8: ad020500    	stp	q0, q1, [x8, #0x40]
1026975dc: 3cc983e0    	ldur	q0, [sp, #0x98]
1026975e0: 3cca83e1    	ldur	q1, [sp, #0xa8]
1026975e4: ad000500    	stp	q0, q1, [x8]
1026975e8: f9400009    	ldr	x9, [x0]
1026975ec: b50007c9    	cbnz	x9, 0x1026976e4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x20c>
1026975f0: 911b43f5    	add	x21, sp, #0x6d0
1026975f4: 92800009    	mov	x9, #-0x1               ; =-1
1026975f8: f9000009    	str	x9, [x0]
1026975fc: f940040b    	ldr	x11, [x0, #0x8]
102697600: f9409be9    	ldr	x9, [sp, #0x130]
102697604: f940012a    	ldr	x10, [x9]
102697608: b400014b    	cbz	x11, 0x102697630 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x158>
10269760c: eb0a017f    	cmp	x11, x10
102697610: 54000100    	b.eq	0x102697630 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x158>
102697614: f900001f    	str	xzr, [x0]
102697618: 9104c3e8    	add	x8, sp, #0x130
10269761c: 91008100    	add	x0, x8, #0x20
102697620: 94007044    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102697624: 52800016    	mov	w22, #0x0               ; =0
102697628: 52800079    	mov	w25, #0x3               ; =3
10269762c: 14000133    	b	0x102697af8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x620>
102697630: f940014b    	ldr	x11, [x10]
102697634: b100056b    	adds	x11, x11, #0x1
102697638: f900014b    	str	x11, [x10]
10269763c: 5400a1c2    	b.hs	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
102697640: 910763f3    	add	x19, sp, #0x1d8
102697644: a9402c0c    	ldp	x12, x11, [x0]
102697648: 9100058c    	add	x12, x12, #0x1
10269764c: a900280c    	stp	x12, x10, [x0]
102697650: 910723fb    	add	x27, sp, #0x1c8
102697654: a91cafe0    	stp	x0, x11, [sp, #0x1c8]
102697658: f900efe9    	str	x9, [sp, #0x1d8]
10269765c: 3cc08100    	ldur	q0, [x8, #0x8]
102697660: 3c8b0100    	stur	q0, [x8, #0xb0]
102697664: 3cc58100    	ldur	q0, [x8, #0x58]
102697668: 3c858260    	stur	q0, [x19, #0x58]
10269766c: 3cc68100    	ldur	q0, [x8, #0x68]
102697670: 3c868260    	stur	q0, [x19, #0x68]
102697674: 3cc78100    	ldur	q0, [x8, #0x78]
102697678: 3c878260    	stur	q0, [x19, #0x78]
10269767c: 3cc88100    	ldur	q0, [x8, #0x88]
102697680: 3c888260    	stur	q0, [x19, #0x88]
102697684: 3cc18100    	ldur	q0, [x8, #0x18]
102697688: 3c818260    	stur	q0, [x19, #0x18]
10269768c: 3cc28100    	ldur	q0, [x8, #0x28]
102697690: 3c828260    	stur	q0, [x19, #0x28]
102697694: 3cc38100    	ldur	q0, [x8, #0x38]
102697698: 3c838260    	stur	q0, [x19, #0x38]
10269769c: 3cc48100    	ldur	q0, [x8, #0x48]
1026976a0: 3c848260    	stur	q0, [x19, #0x48]
1026976a4: 9000a220    	adrp	x0, 0x103adb000 <__mi_heap_main+0xb68>
1026976a8: 91138000    	add	x0, x0, #0x4e0
1026976ac: f9400008    	ldr	x8, [x0]
1026976b0: d63f0100    	blr	x8
1026976b4: 39408008    	ldrb	w8, [x0, #0x20]
1026976b8: 7100051f    	cmp	w8, #0x1
1026976bc: 540002a0    	b.eq	0x102697710 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x238>
1026976c0: 7100091f    	cmp	w8, #0x2
1026976c4: 54000181    	b.ne	0x1026976f4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x21c>
1026976c8: 910763e8    	add	x8, sp, #0x1d8
1026976cc: 91008100    	add	x0, x8, #0x20
1026976d0: 94007018    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1026976d4: d000a0a0    	adrp	x0, 0x103aad000 <_anon.765e5019d1254bf8dfb752f0db35bb73.628+0x448>
1026976d8: 911e0000    	add	x0, x0, #0x780
1026976dc: 941c6417    	bl	0x102db0738 <__RNvNtNtCsgirOGyZpP7g_3std6thread5local18panic_access_error>
1026976e0: 140004e5    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
1026976e4: d000a0a0    	adrp	x0, 0x103aad000 <_anon.765e5019d1254bf8dfb752f0db35bb73.628+0x448>
1026976e8: 9139a000    	add	x0, x0, #0xe68
1026976ec: 941c65b4    	bl	0x102db0dbc <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
1026976f0: 140004e1    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
1026976f4: f0fff9a1    	adrp	x1, 0x1025ce000 <__RINvNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric17nested_assignment4bindKy3_EB8_+0x91c>
1026976f8: 91371021    	add	x1, x1, #0xdc4
1026976fc: aa0003f5    	mov	x21, x0
102697700: 941b22fa    	bl	0x102d602e8 <__RNvNtNtNtNtCsgirOGyZpP7g_3std3sys12thread_local11destructors4list8register>
102697704: 52800028    	mov	w8, #0x1                ; =1
102697708: aa1503e0    	mov	x0, x21
10269770c: 390082a8    	strb	w8, [x21, #0x20]
102697710: 9109c3fb    	add	x27, sp, #0x270
102697714: 9104e7e8    	add	x8, sp, #0x139
102697718: 3ccff100    	ldur	q0, [x8, #0xff]
10269771c: 910527e8    	add	x8, sp, #0x149
102697720: 3ccff101    	ldur	q1, [x8, #0xff]
102697724: 3c8f8260    	stur	q0, [x19, #0xf8]
102697728: 910567e8    	add	x8, sp, #0x159
10269772c: 3ccff100    	ldur	q0, [x8, #0xff]
102697730: ad038361    	stp	q1, q0, [x27, #0x70]
102697734: f94137e8    	ldr	x8, [sp, #0x268]
102697738: f90183e8    	str	x8, [sp, #0x300]
10269773c: 9103e7e8    	add	x8, sp, #0xf9
102697740: 3ccff100    	ldur	q0, [x8, #0xff]
102697744: 910427e8    	add	x8, sp, #0x109
102697748: 3ccff101    	ldur	q1, [x8, #0xff]
10269774c: ad010760    	stp	q0, q1, [x27, #0x20]
102697750: 910467e8    	add	x8, sp, #0x119
102697754: 3ccff100    	ldur	q0, [x8, #0xff]
102697758: 9104a7e8    	add	x8, sp, #0x129
10269775c: 3ccff101    	ldur	q1, [x8, #0xff]
102697760: ad020760    	stp	q0, q1, [x27, #0x40]
102697764: 910367e8    	add	x8, sp, #0xd9
102697768: 3ccff100    	ldur	q0, [x8, #0xff]
10269776c: 9103a7e8    	add	x8, sp, #0xe9
102697770: 3ccff101    	ldur	q1, [x8, #0xff]
102697774: ad000760    	stp	q0, q1, [x27]
102697778: f9413be8    	ldr	x8, [sp, #0x270]
10269777c: f9400113    	ldr	x19, [x8]
102697780: f9400269    	ldr	x9, [x19]
102697784: b1000529    	adds	x9, x9, #0x1
102697788: f9000269    	str	x9, [x19]
10269778c: 54009742    	b.hs	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
102697790: f90213ff    	str	xzr, [sp, #0x420]
102697794: f9020bf3    	str	x19, [sp, #0x410]
102697798: f9020fff    	str	xzr, [sp, #0x418]
10269779c: f9400009    	ldr	x9, [x0]
1026977a0: b5003089    	cbnz	x9, 0x102697db0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8d8>
1026977a4: 910fe3f5    	add	x21, sp, #0x3f8
1026977a8: 3cc08000    	ldur	q0, [x0, #0x8]
1026977ac: 3c8a0360    	stur	q0, [x27, #0xa0]
1026977b0: f9400c09    	ldr	x9, [x0, #0x18]
1026977b4: 3cc182a0    	ldur	q0, [x21, #0x18]
1026977b8: 3c808000    	stur	q0, [x0, #0x8]
1026977bc: f94213ea    	ldr	x10, [sp, #0x420]
1026977c0: f9000c0a    	str	x10, [x0, #0x18]
1026977c4: f90193e9    	str	x9, [sp, #0x320]
1026977c8: f90187e0    	str	x0, [sp, #0x308]
1026977cc: f9400108    	ldr	x8, [x8]
1026977d0: f9400903    	ldr	x3, [x8, #0x10]
1026977d4: 92f00009    	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1026977d8: eb09007f    	cmp	x3, x9
1026977dc: f9001fe3    	str	x3, [sp, #0x38]
1026977e0: 54002f02    	b.hs	0x102697dc0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8e8>
1026977e4: a943a109    	ldp	x9, x8, [x8, #0x38]
1026977e8: f9413fea    	ldr	x10, [sp, #0x278]
1026977ec: f94143eb    	ldr	x11, [sp, #0x280]
1026977f0: 9000a220    	adrp	x0, 0x103adb000 <__mi_heap_main+0xb68>
1026977f4: 9113e000    	add	x0, x0, #0x4f8
1026977f8: f940000c    	ldr	x12, [x0]
1026977fc: d63f0180    	blr	x12
102697800: aa0003f3    	mov	x19, x0
102697804: f9400000    	ldr	x0, [x0]
102697808: a9408a61    	ldp	x1, x2, [x19, #0x8]
10269780c: f940014a    	ldr	x10, [x10]
102697810: ab0a0129    	adds	x9, x9, x10
102697814: da9f3129    	csinv	x9, x9, xzr, lo
102697818: eb09003f    	cmp	x1, x9
10269781c: 9a89302a    	csel	x10, x1, x9, lo
102697820: f940016b    	ldr	x11, [x11]
102697824: ab0b0108    	adds	x8, x8, x11
102697828: da9f3108    	csinv	x8, x8, xzr, lo
10269782c: eb08005f    	cmp	x2, x8
102697830: 9a88304b    	csel	x11, x2, x8, lo
102697834: 7200001f    	tst	w0, #0x1
102697838: 9a891149    	csel	x9, x10, x9, ne
10269783c: 9a881168    	csel	x8, x11, x8, ne
102697840: 5280002a    	mov	w10, #0x1               ; =1
102697844: a900266a    	stp	x10, x9, [x19]
102697848: f9000a68    	str	x8, [x19, #0x10]
10269784c: 3cc58360    	ldur	q0, [x27, #0x58]
102697850: 3cc68361    	ldur	q1, [x27, #0x68]
102697854: ad080760    	stp	q0, q1, [x27, #0x100]
102697858: 3cc78360    	ldur	q0, [x27, #0x78]
10269785c: 3cc88361    	ldur	q1, [x27, #0x88]
102697860: ad090760    	stp	q0, q1, [x27, #0x120]
102697864: 3cc18360    	ldur	q0, [x27, #0x18]
102697868: 3cc28361    	ldur	q1, [x27, #0x28]
10269786c: ad060760    	stp	q0, q1, [x27, #0xc0]
102697870: 3cc38360    	ldur	q0, [x27, #0x38]
102697874: 3cc48361    	ldur	q1, [x27, #0x48]
102697878: ad070760    	stp	q0, q1, [x27, #0xe0]
10269787c: f9419be8    	ldr	x8, [sp, #0x330]
102697880: 910cc3e9    	add	x9, sp, #0x330
102697884: b27d0137    	orr	x23, x9, #0x8
102697888: f9405909    	ldr	x9, [x8, #0xb0]
10269788c: aa1703fc    	mov	x28, x23
102697890: a90783e1    	stp	x1, x0, [sp, #0x78]
102697894: f9003be2    	str	x2, [sp, #0x70]
102697898: b4004ce9    	cbz	x9, 0x102698234 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd5c>
10269789c: f940550a    	ldr	x10, [x8, #0xa8]
1026978a0: b94373e9    	ldr	w9, [sp, #0x370]
1026978a4: b940014a    	ldr	w10, [x10]
1026978a8: 6b0a013f    	cmp	w9, w10
1026978ac: 54000c61    	b.ne	0x102697a38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x560>
1026978b0: ad418760    	ldp	q0, q1, [x27, #0x30]
1026978b4: 3c8182a0    	stur	q0, [x21, #0x18]
1026978b8: 3c8282a1    	stur	q1, [x21, #0x28]
1026978bc: f940950a    	ldr	x10, [x8, #0x128]
1026978c0: b4004c0a    	cbz	x10, 0x102698240 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd68>
1026978c4: f940910a    	ldr	x10, [x8, #0x120]
1026978c8: f9420beb    	ldr	x11, [sp, #0x410]
1026978cc: f9420fec    	ldr	x12, [sp, #0x418]
1026978d0: a940394d    	ldp	x13, x14, [x10]
1026978d4: f94213ef    	ldr	x15, [sp, #0x420]
1026978d8: f94217f0    	ldr	x16, [sp, #0x428]
1026978dc: a9412951    	ldp	x17, x10, [x10, #0x10]
1026978e0: eb0d017f    	cmp	x11, x13
1026978e4: fa4e0180    	ccmp	x12, x14, #0x0, eq
1026978e8: fa5101e0    	ccmp	x15, x17, #0x0, eq
1026978ec: fa4a0200    	ccmp	x16, x10, #0x0, eq
1026978f0: 54000a41    	b.ne	0x102697a38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x560>
1026978f4: f940610a    	ldr	x10, [x8, #0xc0]
1026978f8: b4004caa    	cbz	x10, 0x10269828c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xdb4>
1026978fc: f9405d1a    	ldr	x26, [x8, #0xb8]
102697900: b9402f4a    	ldr	w10, [x26, #0x2c]
102697904: 6b0a013f    	cmp	w9, w10
102697908: 54000981    	b.ne	0x102697a38 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x560>
10269790c: f940b909    	ldr	x9, [x8, #0x170]
102697910: 910ec3e8    	add	x8, sp, #0x3b0
102697914: 91004121    	add	x1, x9, #0x10
102697918: aa1703e0    	mov	x0, x23
10269791c: 9416e7ad    	bl	0x102c517d0 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value16validate_against>
102697920: 394ec3e8    	ldrb	w8, [sp, #0x3b0]
102697924: 7100591f    	cmp	w8, #0x16
102697928: 54000841    	b.ne	0x102697a30 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x558>
10269792c: f941bfe8    	ldr	x8, [sp, #0x378]
102697930: f9400116    	ldr	x22, [x8]
102697934: f9400ac8    	ldr	x8, [x22, #0x10]
102697938: 92f00009    	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10269793c: eb09011f    	cmp	x8, x9
102697940: 54003582    	b.hs	0x102697ff0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xb18>
102697944: 91000508    	add	x8, x8, #0x1
102697948: f9000ac8    	str	x8, [x22, #0x10]
10269794c: f9400ec8    	ldr	x8, [x22, #0x18]
102697950: b4003588    	cbz	x8, 0x102698000 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xb28>
102697954: 52800029    	mov	w9, #0x1                ; =1
102697958: f8290109    	ldadd	x9, x9, [x8]
10269795c: b7f888c9    	tbnz	x9, #0x3f, 0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
102697960: f901ffe8    	str	x8, [sp, #0x3f8]
102697964: 3dc00ac0    	ldr	q0, [x22, #0x20]
102697968: 3c8082a0    	stur	q0, [x21, #0x8]
10269796c: f9400ac8    	ldr	x8, [x22, #0x10]
102697970: d1000508    	sub	x8, x8, #0x1
102697974: f9000ac8    	str	x8, [x22, #0x10]
102697978: 910fe3e1    	add	x1, sp, #0x3f8
10269797c: aa1703e0    	mov	x0, x23
102697980: 9416f142    	bl	0x102c53e88 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_bytes>
102697984: 528005a8    	mov	w8, #0x2d               ; =45
102697988: 391043e8    	strb	w8, [sp, #0x410]
10269798c: f100041f    	cmp	x0, #0x1
102697990: 54000d61    	b.ne	0x102697b3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x664>
102697994: aa0103f6    	mov	x22, x1
102697998: 911043e0    	add	x0, sp, #0x410
10269799c: 94007621    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1026979a0: 910fe3e1    	add	x1, sp, #0x3f8
1026979a4: aa1703e0    	mov	x0, x23
1026979a8: 9416f16d    	bl	0x102c53f5c <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value28memory_budget_retained_nodes>
1026979ac: 528005a8    	mov	w8, #0x2d               ; =45
1026979b0: 391043e8    	strb	w8, [sp, #0x410]
1026979b4: f100041f    	cmp	x0, #0x1
1026979b8: 54000c21    	b.ne	0x102697b3c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x664>
1026979bc: aa0103f7    	mov	x23, x1
1026979c0: 911043e0    	add	x0, sp, #0x410
1026979c4: 94007617    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1026979c8: f941bfea    	ldr	x10, [sp, #0x378]
1026979cc: f940014c    	ldr	x12, [x10]
1026979d0: f9400988    	ldr	x8, [x12, #0x10]
1026979d4: 92f00009    	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1026979d8: eb09011f    	cmp	x8, x9
1026979dc: 540036a2    	b.hs	0x1026980b0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xbd8>
1026979e0: f941c7e9    	ldr	x9, [sp, #0x388]
1026979e4: f9401928    	ldr	x8, [x9, #0x30]
1026979e8: ab16010d    	adds	x13, x8, x22
1026979ec: 540033a2    	b.hs	0x102698060 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xb88>
1026979f0: f9402928    	ldr	x8, [x9, #0x50]
1026979f4: ab17010b    	adds	x11, x8, x23
1026979f8: 54003342    	b.hs	0x102698060 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xb88>
1026979fc: f941c3ee    	ldr	x14, [sp, #0x380]
102697a00: a94061c8    	ldp	x8, x24, [x14]
102697a04: ad4089c0    	ldp	q0, q2, [x14, #0x10]
102697a08: f100091f    	cmp	x8, #0x2
102697a0c: 54000b61    	b.ne	0x102697b78 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x6a0>
102697a10: ad020be0    	stp	q0, q2, [sp, #0x40]
102697a14: 52800536    	mov	w22, #0x29              ; =41
102697a18: f941ffe8    	ldr	x8, [sp, #0x3f8]
102697a1c: 92800009    	mov	x9, #-0x1               ; =-1
102697a20: f8690108    	ldaddl	x9, x8, [x8]
102697a24: f100051f    	cmp	x8, #0x1
102697a28: 54000960    	b.eq	0x102697b54 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x67c>
102697a2c: 1400004d    	b	0x102697b60 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x688>
102697a30: 910ec3e0    	add	x0, sp, #0x3b0
102697a34: 9400720e    	bl	0x1026b426c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
102697a38: 52800017    	mov	w23, #0x0               ; =0
102697a3c: 52800596    	mov	w22, #0x2c              ; =44
102697a40: 52800059    	mov	w25, #0x2               ; =2
102697a44: f90037e8    	str	x8, [sp, #0x68]
102697a48: aa1c03e0    	mov	x0, x28
102697a4c: 94006f39    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102697a50: 910c23fc    	add	x28, sp, #0x308
102697a54: b9432be8    	ldr	w8, [sp, #0x328]
102697a58: b90413e8    	str	w8, [sp, #0x410]
102697a5c: b84bb368    	ldur	w8, [x27, #0xbb]
102697a60: 911043e9    	add	x9, sp, #0x410
102697a64: b8003128    	stur	w8, [x9, #0x3]
102697a68: a947a7e8    	ldp	x8, x9, [sp, #0x78]
102697a6c: a9002269    	stp	x9, x8, [x19]
102697a70: f9403be8    	ldr	x8, [sp, #0x70]
102697a74: f9000a68    	str	x8, [x19, #0x10]
102697a78: 910c23e0    	add	x0, sp, #0x308
102697a7c: 94019f87    	bl	0x1026ff898 <__RNvXs_NvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBa_23NativeLibraryWorkBudget16with_call_limitsNtB4_10ScopeGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
102697a80: f9418be8    	ldr	x8, [sp, #0x310]
102697a84: 910723fb    	add	x27, sp, #0x1c8
102697a88: b40000e8    	cbz	x8, 0x102697aa4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x5cc>
102697a8c: f9400109    	ldr	x9, [x8]
102697a90: f1000529    	subs	x9, x9, #0x1
102697a94: f9000109    	str	x9, [x8]
102697a98: 54000061    	b.ne	0x102697aa4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x5cc>
102697a9c: 91002380    	add	x0, x28, #0x8
102697aa0: 94011028    	bl	0x1026dbb40 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102697aa4: b94413e8    	ldr	w8, [sp, #0x410]
102697aa8: b906d3e8    	str	w8, [sp, #0x6d0]
102697aac: 911043e8    	add	x8, sp, #0x410
102697ab0: b8403108    	ldur	w8, [x8, #0x3]
102697ab4: 911b43e9    	add	x9, sp, #0x6d0
102697ab8: b8003128    	stur	w8, [x9, #0x3]
102697abc: 910723e0    	add	x0, sp, #0x1c8
102697ac0: 94018f07    	bl	0x1026fb6dc <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
102697ac4: f94037e8    	ldr	x8, [sp, #0x68]
102697ac8: 2a0822e8    	orr	w8, w23, w8, lsl #8
102697acc: aa158113    	orr	x19, x8, x21, lsl #32
102697ad0: f940ebe8    	ldr	x8, [sp, #0x1d0]
102697ad4: b40000e8    	cbz	x8, 0x102697af0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x618>
102697ad8: f9400109    	ldr	x9, [x8]
102697adc: f1000529    	subs	x9, x9, #0x1
102697ae0: f9000109    	str	x9, [x8]
102697ae4: 54000061    	b.ne	0x102697af0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x618>
102697ae8: 91002360    	add	x0, x27, #0x8
102697aec: 94011015    	bl	0x1026dbb40 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102697af0: 911b43f5    	add	x21, sp, #0x6d0
102697af4: ad4203e1    	ldp	q1, q0, [sp, #0x40]
102697af8: b946d3e8    	ldr	w8, [sp, #0x6d0]
102697afc: b8001288    	stur	w8, [x20, #0x1]
102697b00: b84032a8    	ldur	w8, [x21, #0x3]
102697b04: b9000688    	str	w8, [x20, #0x4]
102697b08: 39000296    	strb	w22, [x20]
102697b0c: f9000693    	str	x19, [x20, #0x8]
102697b10: ad008281    	stp	q1, q0, [x20, #0x10]
102697b14: a9036a98    	stp	x24, x26, [x20, #0x30]
102697b18: 39010299    	strb	w25, [x20, #0x40]
102697b1c: 912383ff    	add	sp, sp, #0x8e0
102697b20: a9457bfd    	ldp	x29, x30, [sp, #0x50]
102697b24: a9444ff4    	ldp	x20, x19, [sp, #0x40]
102697b28: a94357f6    	ldp	x22, x21, [sp, #0x30]
102697b2c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
102697b30: a94167fa    	ldp	x26, x25, [sp, #0x10]
102697b34: a8c66ffc    	ldp	x28, x27, [sp], #0x60
102697b38: d65f03c0    	ret
102697b3c: 528005b6    	mov	w22, #0x2d              ; =45
102697b40: f941ffe8    	ldr	x8, [sp, #0x3f8]
102697b44: 92800009    	mov	x9, #-0x1               ; =-1
102697b48: f8690108    	ldaddl	x9, x8, [x8]
102697b4c: f100051f    	cmp	x8, #0x1
102697b50: 54000081    	b.ne	0x102697b60 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x688>
102697b54: d50339bf    	dmb	ishld
102697b58: 910fe3e0    	add	x0, sp, #0x3f8
102697b5c: 941707a4    	bl	0x102c599ec <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102697b60: d360ff15    	lsr	x21, x24, #32
102697b64: 12001f17    	and	w23, w24, #0xff
102697b68: 53087f08    	lsr	w8, w24, #8
102697b6c: f90037e8    	str	x8, [sp, #0x68]
102697b70: 52800059    	mov	w25, #0x2               ; =2
102697b74: 17ffffb5    	b	0x102697a48 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x570>
102697b78: 4ea01c03    	mov.16b	v3, v0
102697b7c: ad4385c0    	ldp	q0, q1, [x14, #0x70]
102697b80: 3c8882a0    	stur	q0, [x21, #0x88]
102697b84: 3c8982a1    	stur	q1, [x21, #0x98]
102697b88: 3cc901c0    	ldur	q0, [x14, #0x90]
102697b8c: 3c8a82a0    	stur	q0, [x21, #0xa8]
102697b90: ad4185c0    	ldp	q0, q1, [x14, #0x30]
102697b94: 3c8482a0    	stur	q0, [x21, #0x48]
102697b98: 3c8582a1    	stur	q1, [x21, #0x58]
102697b9c: ad4285c0    	ldp	q0, q1, [x14, #0x50]
102697ba0: 3c8682a0    	stur	q0, [x21, #0x68]
102697ba4: 3c8782a1    	stur	q1, [x21, #0x78]
102697ba8: ad408520    	ldp	q0, q1, [x9, #0x10]
102697bac: 3c8e82a1    	stur	q1, [x21, #0xe8]
102697bb0: 3dc00121    	ldr	q1, [x9]
102697bb4: 3c8d82a0    	stur	q0, [x21, #0xd8]
102697bb8: 3cc38180    	ldur	q0, [x12, #0x38]
102697bbc: f84a01cc    	ldur	x12, [x14, #0xa0]
102697bc0: f9025bec    	str	x12, [sp, #0x4b0]
102697bc4: f9025fea    	str	x10, [sp, #0x4b8]
102697bc8: 3c8c82a1    	stur	q1, [x21, #0xc8]
102697bcc: f844812a    	ldur	x10, [x9, #0x48]
102697bd0: f9027bed    	str	x13, [sp, #0x4f0]
102697bd4: f90287ea    	str	x10, [sp, #0x508]
102697bd8: 3cc38121    	ldur	q1, [x9, #0x38]
102697bdc: 911043ed    	add	x13, sp, #0x410
102697be0: 3c8e81a1    	stur	q1, [x13, #0xe8]
102697be4: 911043ea    	add	x10, sp, #0x410
102697be8: 9104214c    	add	x12, x10, #0x108
102697bec: 3cc58121    	ldur	q1, [x9, #0x58]
102697bf0: 3d800181    	str	q1, [x12]
102697bf4: 91046149    	add	x9, x10, #0x118
102697bf8: 3d800120    	str	q0, [x9]
102697bfc: f9028beb    	str	x11, [sp, #0x510]
102697c00: f9029fff    	str	xzr, [sp, #0x538]
102697c04: 52800349    	mov	w9, #0x1a               ; =26
102697c08: b90543e9    	str	w9, [sp, #0x540]
102697c0c: ad0089a3    	stp	q3, q2, [x13, #0x10]
102697c10: 52800039    	mov	w25, #0x1               ; =1
102697c14: f9020ff8    	str	x24, [sp, #0x418]
102697c18: f9020be8    	str	x8, [sp, #0x410]
102697c1c: 911b43e0    	add	x0, sp, #0x6d0
102697c20: 911043e1    	add	x1, sp, #0x410
102697c24: d2800002    	mov	x2, #0x0                ; =0
102697c28: d2800003    	mov	x3, #0x0                ; =0
102697c2c: d2800004    	mov	x4, #0x0                ; =0
102697c30: d2800005    	mov	x5, #0x0                ; =0
102697c34: 97fc486c    	bl	0x1025a9de4 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
102697c38: 395b43e8    	ldrb	w8, [sp, #0x6d0]
102697c3c: 7100211f    	cmp	w8, #0x8
102697c40: 54001a61    	b.ne	0x102697f8c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xab4>
102697c44: f9419be8    	ldr	x8, [sp, #0x330]
102697c48: f940d515    	ldr	x21, [x8, #0x1a8]
102697c4c: b10206bf    	cmn	x21, #0x81
102697c50: 54002e48    	b.hi	0x102698218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd40>
102697c54: 52800588    	mov	w8, #0x2c               ; =44
102697c58: 391b43e8    	strb	w8, [sp, #0x6d0]
102697c5c: 911b43e0    	add	x0, sp, #0x6d0
102697c60: 94007570    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102697c64: 52800039    	mov	w25, #0x1               ; =1
102697c68: 911743e8    	add	x8, sp, #0x5d0
102697c6c: 911043e0    	add	x0, sp, #0x410
102697c70: 910202a1    	add	x1, x21, #0x80
102697c74: d2800002    	mov	x2, #0x0                ; =0
102697c78: 97fc48b5    	bl	0x1025a9f4c <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
102697c7c: 911643e9    	add	x9, sp, #0x590
102697c80: 395743e8    	ldrb	w8, [sp, #0x5d0]
102697c84: 7100211f    	cmp	w8, #0x8
102697c88: 54000861    	b.ne	0x102697d94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8bc>
102697c8c: f941a3e8    	ldr	x8, [sp, #0x340]
102697c90: f9400915    	ldr	x21, [x8, #0x10]
102697c94: 394042a8    	ldrb	w8, [x21, #0x10]
102697c98: 7100651f    	cmp	w8, #0x19
102697c9c: 54001fc1    	b.ne	0x102698094 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xbbc>
102697ca0: 52800039    	mov	w25, #0x1               ; =1
102697ca4: 911b43f7    	add	x23, sp, #0x6d0
102697ca8: 911b43e8    	add	x8, sp, #0x6d0
102697cac: 910062a0    	add	x0, x21, #0x18
102697cb0: 9416f29c    	bl	0x102c54720 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot4dataNtB5_11MatrixValue8elements>
102697cb4: f9436be8    	ldr	x8, [sp, #0x6d0]
102697cb8: 52800209    	mov	w9, #0x10               ; =16
102697cbc: 5280010a    	mov	w10, #0x8               ; =8
102697cc0: f1004d1f    	cmp	x8, #0x13
102697cc4: 9a890148    	csel	x8, x10, x9, eq
102697cc8: f84182a9    	ldur	x9, [x21, #0x18]
102697ccc: 52800596    	mov	w22, #0x2c              ; =44
102697cd0: f1000d3f    	cmp	x9, #0x3
102697cd4: 540007e8    	b.hi	0x102697dd0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8f8>
102697cd8: f8686af7    	ldr	x23, [x23, x8]
102697cdc: f94012a8    	ldr	x8, [x21, #0x20]
102697ce0: f90017e8    	str	x8, [sp, #0x28]
102697ce4: 391b43f6    	strb	w22, [sp, #0x6d0]
102697ce8: 911b43e0    	add	x0, sp, #0x6d0
102697cec: 9400754d    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102697cf0: f941cbe8    	ldr	x8, [sp, #0x390]
102697cf4: f9400100    	ldr	x0, [x8]
102697cf8: 52800039    	mov	w25, #0x1               ; =1
102697cfc: 911b43e8    	add	x8, sp, #0x6d0
102697d00: f90037f7    	str	x23, [sp, #0x68]
102697d04: aa1703e1    	mov	x1, x23
102697d08: 940499f7    	bl	0x1027be4e4 <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric22available_scalar_index>
102697d0c: 395b43f7    	ldrb	w23, [sp, #0x6d0]
102697d10: 710022ff    	cmp	w23, #0x8
102697d14: 540006c1    	b.ne	0x102697dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x914>
102697d18: f9419be8    	ldr	x8, [sp, #0x330]
102697d1c: f9403d09    	ldr	x9, [x8, #0x78]
102697d20: b40069e9    	cbz	x9, 0x102698a5c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1584>
102697d24: f9436ff6    	ldr	x22, [sp, #0x6d8]
102697d28: f9403901    	ldr	x1, [x8, #0x70]
102697d2c: 52800039    	mov	w25, #0x1               ; =1
102697d30: 911b43e8    	add	x8, sp, #0x6d0
102697d34: aa1c03e0    	mov	x0, x28
102697d38: 9404dfc1    	bl	0x1027cfc3c <__RNvNtNtCs1qJAwyMG1lC_11mech_engine8resident7numeric26snapshot_matrix_dimensions>
102697d3c: 395b43f7    	ldrb	w23, [sp, #0x6d0]
102697d40: 710022ff    	cmp	w23, #0x8
102697d44: 54000541    	b.ne	0x102697dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x914>
102697d48: f9436fea    	ldr	x10, [sp, #0x6d8]
102697d4c: b400016a    	cbz	x10, 0x102697d78 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8a0>
102697d50: f94373e8    	ldr	x8, [sp, #0x6e0]
102697d54: 9aca0ac9    	udiv	x9, x22, x10
102697d58: 9b0ad92a    	msub	x10, x9, x10, x22
102697d5c: 9bc87d4b    	umulh	x11, x10, x8
102697d60: eb0b03ff    	cmp	xzr, x11
102697d64: 540000a1    	b.ne	0x102697d78 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8a0>
102697d68: 9b087d48    	mul	x8, x10, x8
102697d6c: ab080128    	adds	x8, x9, x8
102697d70: f90013e8    	str	x8, [sp, #0x20]
102697d74: 54000503    	b.lo	0x102697e14 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x93c>
102697d78: 52800028    	mov	w8, #0x1                ; =1
102697d7c: b90037e8    	str	w8, [sp, #0x34]
102697d80: 52800536    	mov	w22, #0x29              ; =41
102697d84: 52800057    	mov	w23, #0x2               ; =2
102697d88: f90037e8    	str	x8, [sp, #0x68]
102697d8c: 52800059    	mov	w25, #0x2               ; =2
102697d90: 140000c7    	b	0x1026980ac <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xbd4>
102697d94: b945d7f5    	ldr	w21, [sp, #0x5d4]
102697d98: b945d3e8    	ldr	w8, [sp, #0x5d0]
102697d9c: 3cc58120    	ldur	q0, [x9, #0x58]
102697da0: 3d8017e0    	str	q0, [sp, #0x50]
102697da4: 12001d17    	and	w23, w8, #0xff
102697da8: 3cc48120    	ldur	q0, [x9, #0x48]
102697dac: 1400007f    	b	0x102697fa8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xad0>
102697db0: d000a0a0    	adrp	x0, 0x103aad000 <_anon.765e5019d1254bf8dfb752f0db35bb73.628+0x448>
102697db4: 913ac000    	add	x0, x0, #0xeb0
102697db8: 941c6401    	bl	0x102db0dbc <__RNvNtCsgDHHaSskbIF_4core4cell22panic_already_borrowed>
102697dbc: 1400032e    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
102697dc0: f000a0a0    	adrp	x0, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
102697dc4: 913ae000    	add	x0, x0, #0xeb8
102697dc8: 941c6409    	bl	0x102db0dec <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102697dcc: 1400032a    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
102697dd0: f90037ff    	str	xzr, [sp, #0x68]
102697dd4: 52800017    	mov	w23, #0x0               ; =0
102697dd8: 52800015    	mov	w21, #0x0               ; =0
102697ddc: 52800028    	mov	w8, #0x1                ; =1
102697de0: b90037e8    	str	w8, [sp, #0x34]
102697de4: 52800059    	mov	w25, #0x2               ; =2
102697de8: 14000077    	b	0x102697fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xaec>
102697dec: 395b4fe8    	ldrb	w8, [sp, #0x6d3]
102697df0: 911b43ea    	add	x10, sp, #0x6d0
102697df4: 78401149    	ldurh	w9, [x10, #0x1]
102697df8: 2a084128    	orr	w8, w9, w8, lsl #16
102697dfc: f90037e8    	str	x8, [sp, #0x68]
102697e00: b946d7f5    	ldr	w21, [sp, #0x6d4]
102697e04: 3cc18141    	ldur	q1, [x10, #0x18]
102697e08: 3cc08140    	ldur	q0, [x10, #0x8]
102697e0c: ad0207e0    	stp	q0, q1, [sp, #0x40]
102697e10: 14000069    	b	0x102697fb4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xadc>
102697e14: 52800039    	mov	w25, #0x1               ; =1
102697e18: 911743e8    	add	x8, sp, #0x5d0
102697e1c: 910062a0    	add	x0, x21, #0x18
102697e20: 9416f240    	bl	0x102c54720 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot4dataNtB5_11MatrixValue8elements>
102697e24: f941cfe8    	ldr	x8, [sp, #0x398]
102697e28: f9400101    	ldr	x1, [x8]
102697e2c: 52800039    	mov	w25, #0x1               ; =1
102697e30: 911b43e8    	add	x8, sp, #0x6d0
102697e34: 911743e0    	add	x0, sp, #0x5d0
102697e38: f94013e2    	ldr	x2, [sp, #0x20]
102697e3c: 97f6d8f7    	bl	0x10244e218 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates4word>
102697e40: 395b43f6    	ldrb	w22, [sp, #0x6d0]
102697e44: 7100badf    	cmp	w22, #0x2e
102697e48: 54000ea1    	b.ne	0x10269801c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xb44>
102697e4c: f9436ff7    	ldr	x23, [sp, #0x6d8]
102697e50: f9419be8    	ldr	x8, [sp, #0x330]
102697e54: f940b909    	ldr	x9, [x8, #0x170]
102697e58: 52800039    	mov	w25, #0x1               ; =1
102697e5c: 911b43e8    	add	x8, sp, #0x6d0
102697e60: 91004121    	add	x1, x9, #0x10
102697e64: aa1c03e0    	mov	x0, x28
102697e68: 9416f2ec    	bl	0x102c54a18 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot8encodingNtNtB7_10validation5Value18retained_footprint>
102697e6c: 395b43e8    	ldrb	w8, [sp, #0x6d0]
102697e70: 7100611f    	cmp	w8, #0x18
102697e74: 54001061    	b.ne	0x102698080 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xba8>
102697e78: f94373e3    	ldr	x3, [sp, #0x6e0]
102697e7c: f94377f5    	ldr	x21, [sp, #0x6e8]
102697e80: f9419be8    	ldr	x8, [sp, #0x330]
102697e84: f941c3e9    	ldr	x9, [sp, #0x380]
102697e88: b9411100    	ldr	w0, [x8, #0x110]
102697e8c: 3dc01d20    	ldr	q0, [x9, #0x70]
102697e90: 911b43ea    	add	x10, sp, #0x6d0
102697e94: 3d801d40    	str	q0, [x10, #0x70]
102697e98: 3dc02120    	ldr	q0, [x9, #0x80]
102697e9c: 3d802140    	str	q0, [x10, #0x80]
102697ea0: 3dc02520    	ldr	q0, [x9, #0x90]
102697ea4: 3d802540    	str	q0, [x10, #0x90]
102697ea8: f9405128    	ldr	x8, [x9, #0xa0]
102697eac: f903bbe8    	str	x8, [sp, #0x770]
102697eb0: 3dc00d20    	ldr	q0, [x9, #0x30]
102697eb4: 3d800d40    	str	q0, [x10, #0x30]
102697eb8: 3dc01120    	ldr	q0, [x9, #0x40]
102697ebc: 3d801140    	str	q0, [x10, #0x40]
102697ec0: 3dc01520    	ldr	q0, [x9, #0x50]
102697ec4: 3d801540    	str	q0, [x10, #0x50]
102697ec8: 3dc01920    	ldr	q0, [x9, #0x60]
102697ecc: 3d801940    	str	q0, [x10, #0x60]
102697ed0: 3dc00120    	ldr	q0, [x9]
102697ed4: 3d800140    	str	q0, [x10]
102697ed8: 3dc00520    	ldr	q0, [x9, #0x10]
102697edc: 3d800540    	str	q0, [x10, #0x10]
102697ee0: 3dc00920    	ldr	q0, [x9, #0x20]
102697ee4: 3d800940    	str	q0, [x10, #0x20]
102697ee8: 52800039    	mov	w25, #0x1               ; =1
102697eec: 911743e8    	add	x8, sp, #0x5d0
102697ef0: 911b43e1    	add	x1, sp, #0x6d0
102697ef4: f94037e2    	ldr	x2, [sp, #0x68]
102697ef8: f9000fe3    	str	x3, [sp, #0x18]
102697efc: d2800004    	mov	x4, #0x0                ; =0
102697f00: 97f6d7c8    	bl	0x10244de20 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates12check_output>
102697f04: 395743f6    	ldrb	w22, [sp, #0x5d0]
102697f08: 7100badf    	cmp	w22, #0x2e
102697f0c: 54000da1    	b.ne	0x1026980c0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xbe8>
102697f10: 52800039    	mov	w25, #0x1               ; =1
102697f14: 911b43e8    	add	x8, sp, #0x6d0
102697f18: 911043e0    	add	x0, sp, #0x410
102697f1c: 52800201    	mov	w1, #0x10               ; =16
102697f20: 52800022    	mov	w2, #0x1                ; =1
102697f24: 97fc480a    	bl	0x1025a9f4c <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
102697f28: 395b43e8    	ldrb	w8, [sp, #0x6d0]
102697f2c: 7100211f    	cmp	w8, #0x8
102697f30: 540002e1    	b.ne	0x102697f8c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xab4>
102697f34: f941d3e8    	ldr	x8, [sp, #0x3a0]
102697f38: f9400108    	ldr	x8, [x8]
102697f3c: eb0802ff    	cmp	x23, x8
102697f40: 54000dc1    	b.ne	0x1026980f8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xc20>
102697f44: 52800019    	mov	w25, #0x0               ; =0
102697f48: b90037ff    	str	wzr, [sp, #0x34]
102697f4c: 394ce3f6    	ldrb	w22, [sp, #0x338]
102697f50: b84c9368    	ldur	w8, [x27, #0xc9]
102697f54: b9032be8    	str	w8, [sp, #0x328]
102697f58: b9433fe8    	ldr	w8, [sp, #0x33c]
102697f5c: b94343e9    	ldr	w9, [sp, #0x340]
102697f60: b80bb368    	stur	w8, [x27, #0xbb]
102697f64: b94347f5    	ldr	w21, [sp, #0x344]
102697f68: 12001d37    	and	w23, w9, #0xff
102697f6c: 53087d28    	lsr	w8, w9, #8
102697f70: f90037e8    	str	x8, [sp, #0x68]
102697f74: 3cce8361    	ldur	q1, [x27, #0xe8]
102697f78: 3ccd8360    	ldur	q0, [x27, #0xd8]
102697f7c: ad0207e0    	stp	q0, q1, [sp, #0x40]
102697f80: f941b7f8    	ldr	x24, [sp, #0x368]
102697f84: f941bbfa    	ldr	x26, [sp, #0x370]
102697f88: 1400000f    	b	0x102697fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xaec>
102697f8c: b946d7f5    	ldr	w21, [sp, #0x6d4]
102697f90: b946d3e8    	ldr	w8, [sp, #0x6d0]
102697f94: 911b43e9    	add	x9, sp, #0x6d0
102697f98: 3cc18120    	ldur	q0, [x9, #0x18]
102697f9c: 3d8017e0    	str	q0, [sp, #0x50]
102697fa0: 12001d17    	and	w23, w8, #0xff
102697fa4: 3cc08120    	ldur	q0, [x9, #0x8]
102697fa8: 3d8013e0    	str	q0, [sp, #0x40]
102697fac: 53087d08    	lsr	w8, w8, #8
102697fb0: f90037e8    	str	x8, [sp, #0x68]
102697fb4: 52800028    	mov	w8, #0x1                ; =1
102697fb8: b90037e8    	str	w8, [sp, #0x34]
102697fbc: 52800536    	mov	w22, #0x29              ; =41
102697fc0: 52800059    	mov	w25, #0x2               ; =2
102697fc4: f941ffe8    	ldr	x8, [sp, #0x3f8]
102697fc8: 92800009    	mov	x9, #-0x1               ; =-1
102697fcc: f8690108    	ldaddl	x9, x8, [x8]
102697fd0: f100051f    	cmp	x8, #0x1
102697fd4: 54000081    	b.ne	0x102697fe4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xb0c>
102697fd8: d50339bf    	dmb	ishld
102697fdc: 910fe3e0    	add	x0, sp, #0x3f8
102697fe0: 94170683    	bl	0x102c599ec <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102697fe4: b94037e8    	ldr	w8, [sp, #0x34]
102697fe8: 35ffd308    	cbnz	w8, 0x102697a48 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x570>
102697fec: 17fffe99    	b	0x102697a50 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x578>
102697ff0: f000a0a0    	adrp	x0, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
102697ff4: 91396000    	add	x0, x0, #0xe58
102697ff8: 941c637d    	bl	0x102db0dec <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
102697ffc: 1400029e    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
102698000: b0005640    	adrp	x0, 0x103161000 <_anon.1794c5ae655e7d08df762cb3f886e887.86+0x15a>
102698004: 910cd400    	add	x0, x0, #0x335
102698008: d000a0a2    	adrp	x2, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
10269800c: 9139c042    	add	x2, x2, #0xe70
102698010: 52800541    	mov	w1, #0x2a               ; =42
102698014: 941c6382    	bl	0x102db0e1c <__RNvNtCsgDHHaSskbIF_4core6option13expect_failed>
102698018: 14000297    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
10269801c: 911b43ea    	add	x10, sp, #0x6d0
102698020: b8401148    	ldur	w8, [x10, #0x1]
102698024: b9032be8    	str	w8, [sp, #0x328]
102698028: b946d7e8    	ldr	w8, [sp, #0x6d4]
10269802c: b946dbe9    	ldr	w9, [sp, #0x6d8]
102698030: b80bb368    	stur	w8, [x27, #0xbb]
102698034: b946dff5    	ldr	w21, [sp, #0x6dc]
102698038: ad408540    	ldp	q0, q1, [x10, #0x10]
10269803c: ad0207e0    	stp	q0, q1, [sp, #0x40]
102698040: f94383f8    	ldr	x24, [sp, #0x700]
102698044: 12001d37    	and	w23, w9, #0xff
102698048: 53087d28    	lsr	w8, w9, #8
10269804c: f90037e8    	str	x8, [sp, #0x68]
102698050: 52800028    	mov	w8, #0x1                ; =1
102698054: b90037e8    	str	w8, [sp, #0x34]
102698058: 52800059    	mov	w25, #0x2               ; =2
10269805c: 17ffffda    	b	0x102697fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xaec>
102698060: 52800058    	mov	w24, #0x2               ; =2
102698064: 52800536    	mov	w22, #0x29              ; =41
102698068: f941ffe8    	ldr	x8, [sp, #0x3f8]
10269806c: 92800009    	mov	x9, #-0x1               ; =-1
102698070: f8690108    	ldaddl	x9, x8, [x8]
102698074: f100051f    	cmp	x8, #0x1
102698078: 54ffd6e0    	b.eq	0x102697b54 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x67c>
10269807c: 17fffeb9    	b	0x102697b60 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x688>
102698080: 395b43e8    	ldrb	w8, [sp, #0x6d0]
102698084: 7100551f    	cmp	w8, #0x15
102698088: 54000068    	b.hi	0x102698094 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xbbc>
10269808c: 911b43e0    	add	x0, sp, #0x6d0
102698090: 94007077    	bl	0x1026b426c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
102698094: 52800017    	mov	w23, #0x0               ; =0
102698098: 52800028    	mov	w8, #0x1                ; =1
10269809c: b90037e8    	str	w8, [sp, #0x34]
1026980a0: 52800596    	mov	w22, #0x2c              ; =44
1026980a4: 52800059    	mov	w25, #0x2               ; =2
1026980a8: f90037e8    	str	x8, [sp, #0x68]
1026980ac: 17ffffc6    	b	0x102697fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xaec>
1026980b0: d000a0a0    	adrp	x0, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
1026980b4: 913ae000    	add	x0, x0, #0xeb8
1026980b8: 941c634d    	bl	0x102db0dec <__RNvNtCsgDHHaSskbIF_4core4cell30panic_already_mutably_borrowed>
1026980bc: 1400026e    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
1026980c0: 911643ea    	add	x10, sp, #0x590
1026980c4: b8441148    	ldur	w8, [x10, #0x41]
1026980c8: b9032be8    	str	w8, [sp, #0x328]
1026980cc: b945d7e8    	ldr	w8, [sp, #0x5d4]
1026980d0: b945dbe9    	ldr	w9, [sp, #0x5d8]
1026980d4: b80bb368    	stur	w8, [x27, #0xbb]
1026980d8: b945dff5    	ldr	w21, [sp, #0x5dc]
1026980dc: 12001d37    	and	w23, w9, #0xff
1026980e0: 53087d28    	lsr	w8, w9, #8
1026980e4: f90037e8    	str	x8, [sp, #0x68]
1026980e8: ad428540    	ldp	q0, q1, [x10, #0x50]
1026980ec: ad0207e0    	stp	q0, q1, [sp, #0x40]
1026980f0: f94303f8    	ldr	x24, [sp, #0x600]
1026980f4: 17ffffd7    	b	0x102698050 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xb78>
1026980f8: f9419be8    	ldr	x8, [sp, #0x330]
1026980fc: f940c516    	ldr	x22, [x8, #0x188]
102698100: f940b908    	ldr	x8, [x8, #0x170]
102698104: b9401109    	ldr	w9, [x8, #0x10]
102698108: f9400d17    	ldr	x23, [x8, #0x18]
10269810c: 52800588    	mov	w8, #0x2c               ; =44
102698110: 391b43e8    	strb	w8, [sp, #0x6d0]
102698114: 36000829    	tbz	w9, #0x0, 0x102698218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd40>
102698118: 911b43e0    	add	x0, sp, #0x6d0
10269811c: 94007441    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102698120: ab1602f6    	adds	x22, x23, x22
102698124: 54000942    	b.hs	0x10269824c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd74>
102698128: 52800588    	mov	w8, #0x2c               ; =44
10269812c: 391b43e8    	strb	w8, [sp, #0x6d0]
102698130: b14006df    	cmn	x22, #0x1, lsl #12      ; =0x1000
102698134: 540008c2    	b.hs	0x10269824c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd74>
102698138: 911b43e0    	add	x0, sp, #0x6d0
10269813c: 94007439    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102698140: b10026bf    	cmn	x21, #0x9
102698144: 540006a8    	b.hi	0x102698218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd40>
102698148: 914006d6    	add	x22, x22, #0x1, lsl #12 ; =0x1000
10269814c: 52800588    	mov	w8, #0x2c               ; =44
102698150: 391b43e8    	strb	w8, [sp, #0x6d0]
102698154: 911b43e0    	add	x0, sp, #0x6d0
102698158: 94007432    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
10269815c: 52800039    	mov	w25, #0x1               ; =1
102698160: 911743e0    	add	x0, sp, #0x5d0
102698164: 911043e1    	add	x1, sp, #0x410
102698168: 910022a5    	add	x5, x21, #0x8
10269816c: d2800002    	mov	x2, #0x0                ; =0
102698170: d2800003    	mov	x3, #0x0                ; =0
102698174: aa1603e4    	mov	x4, x22
102698178: 97fc471b    	bl	0x1025a9de4 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
10269817c: 395743e8    	ldrb	w8, [sp, #0x5d0]
102698180: 7100211f    	cmp	w8, #0x8
102698184: 540007c1    	b.ne	0x10269827c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xda4>
102698188: d37cfec8    	lsr	x8, x22, #60
10269818c: b5000468    	cbnz	x8, 0x102698218 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xd40>
102698190: d37ceed7    	lsl	x23, x22, #4
102698194: 52800588    	mov	w8, #0x2c               ; =44
102698198: 391b43e8    	strb	w8, [sp, #0x6d0]
10269819c: 911b43e0    	add	x0, sp, #0x6d0
1026981a0: 94007420    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1026981a4: 52800039    	mov	w25, #0x1               ; =1
1026981a8: 911743e8    	add	x8, sp, #0x5d0
1026981ac: 911043e0    	add	x0, sp, #0x410
1026981b0: aa1703e1    	mov	x1, x23
1026981b4: d2800002    	mov	x2, #0x0                ; =0
1026981b8: 97fc4765    	bl	0x1025a9f4c <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
1026981bc: 395743e8    	ldrb	w8, [sp, #0x5d0]
1026981c0: 7100211f    	cmp	w8, #0x8
1026981c4: 540005c1    	b.ne	0x10269827c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xda4>
1026981c8: 52800039    	mov	w25, #0x1               ; =1
1026981cc: 911b43e8    	add	x8, sp, #0x6d0
1026981d0: 910fe3e0    	add	x0, sp, #0x3f8
1026981d4: aa1603e1    	mov	x1, x22
1026981d8: 9416dc90    	bl	0x102c4f418 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
1026981dc: b946d3f7    	ldr	w23, [sp, #0x6d0]
1026981e0: 71006aff    	cmp	w23, #0x1a
1026981e4: 1a9f07e8    	cset	w8, ne
1026981e8: b90037e8    	str	w8, [sp, #0x34]
1026981ec: 540005c0    	b.eq	0x1026982a4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xdcc>
1026981f0: f90037ff    	str	xzr, [sp, #0x68]
1026981f4: b946d7f5    	ldr	w21, [sp, #0x6d4]
1026981f8: 911b43e8    	add	x8, sp, #0x6d0
1026981fc: 3cc18101    	ldur	q1, [x8, #0x18]
102698200: 3cc08100    	ldur	q0, [x8, #0x8]
102698204: ad0207e0    	stp	q0, q1, [sp, #0x40]
102698208: 52800576    	mov	w22, #0x2b              ; =43
10269820c: f9437ff8    	ldr	x24, [sp, #0x6f8]
102698210: 52800059    	mov	w25, #0x2               ; =2
102698214: 17ffff6c    	b	0x102697fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xaec>
102698218: f90037ff    	str	xzr, [sp, #0x68]
10269821c: 52800017    	mov	w23, #0x0               ; =0
102698220: 52800015    	mov	w21, #0x0               ; =0
102698224: 52800028    	mov	w8, #0x1                ; =1
102698228: b90037e8    	str	w8, [sp, #0x34]
10269822c: 52800596    	mov	w22, #0x2c              ; =44
102698230: 17fffeed    	b	0x102697de4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x90c>
102698234: d000a0a2    	adrp	x2, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
102698238: 91084042    	add	x2, x2, #0x210
10269823c: 14000016    	b	0x102698294 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xdbc>
102698240: d000a0a2    	adrp	x2, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
102698244: 9108a042    	add	x2, x2, #0x228
102698248: 14000013    	b	0x102698294 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xdbc>
10269824c: f90037ff    	str	xzr, [sp, #0x68]
102698250: 52800017    	mov	w23, #0x0               ; =0
102698254: 52800015    	mov	w21, #0x0               ; =0
102698258: 911b43e8    	add	x8, sp, #0x6d0
10269825c: b8401108    	ldur	w8, [x8, #0x1]
102698260: b9032be8    	str	w8, [sp, #0x328]
102698264: b946d7e8    	ldr	w8, [sp, #0x6d4]
102698268: b80bb368    	stur	w8, [x27, #0xbb]
10269826c: 52800028    	mov	w8, #0x1                ; =1
102698270: b90037e8    	str	w8, [sp, #0x34]
102698274: 52800596    	mov	w22, #0x2c              ; =44
102698278: 17fffec5    	b	0x102697d8c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8b4>
10269827c: b945d7f5    	ldr	w21, [sp, #0x5d4]
102698280: b945d3e8    	ldr	w8, [sp, #0x5d0]
102698284: 911643e9    	add	x9, sp, #0x590
102698288: 17fffec5    	b	0x102697d9c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x8c4>
10269828c: d000a0a2    	adrp	x2, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
102698290: 91090042    	add	x2, x2, #0x240
102698294: d2800000    	mov	x0, #0x0                ; =0
102698298: d2800001    	mov	x1, #0x0                ; =0
10269829c: 941c6313    	bl	0x102db0ee8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
1026982a0: 140001f5    	b	0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
1026982a4: 911b43e8    	add	x8, sp, #0x6d0
1026982a8: 3cc08100    	ldur	q0, [x8, #0x8]
1026982ac: 3cc18101    	ldur	q1, [x8, #0x18]
1026982b0: 911043e8    	add	x8, sp, #0x410
1026982b4: ad0b0500    	stp	q0, q1, [x8, #0x160]
1026982b8: f9419fe8    	ldr	x8, [sp, #0x338]
1026982bc: 91004100    	add	x0, x8, #0x10
1026982c0: 940a8fba    	bl	0x10293c1a8 <__RNvXse_NtCsgKscDXrlV49_5alloc5boxedINtB5_3BoxSyENtNtCsgDHHaSskbIF_4core5clone5Clone5cloneCs1qJAwyMG1lC_11mech_engine>
1026982c4: a90087e0    	stp	x0, x1, [sp, #0x8]
1026982c8: f941d7e8    	ldr	x8, [sp, #0x3a8]
1026982cc: 39400108    	ldrb	w8, [x8]
1026982d0: 36000348    	tbz	w8, #0x0, 0x102698338 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xe60>
1026982d4: ad400780    	ldp	q0, q1, [x28]
1026982d8: 911643e9    	add	x9, sp, #0x590
1026982dc: ad020520    	stp	q0, q1, [x9, #0x40]
1026982e0: ad410780    	ldp	q0, q1, [x28, #0x20]
1026982e4: ad030520    	stp	q0, q1, [x9, #0x60]
1026982e8: 911b43e8    	add	x8, sp, #0x6d0
1026982ec: 911743e0    	add	x0, sp, #0x5d0
1026982f0: 910fe3e1    	add	x1, sp, #0x3f8
1026982f4: 9417001e    	bl	0x102c5836c <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB6_5Value30try_into_owned_unsigned_matrix>
1026982f8: f9436be8    	ldr	x8, [sp, #0x6d0]
1026982fc: f9436fe9    	ldr	x9, [sp, #0x6d8]
102698300: 911b43ea    	add	x10, sp, #0x6d0
102698304: ad408540    	ldp	q0, q1, [x10, #0x10]
102698308: ad0207e0    	stp	q0, q1, [sp, #0x40]
10269830c: f94383f8    	ldr	x24, [sp, #0x700]
102698310: f100151f    	cmp	x8, #0x5
102698314: 540019a1    	b.ne	0x102698648 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1170>
102698318: 12001d37    	and	w23, w9, #0xff
10269831c: 53087d28    	lsr	w8, w9, #8
102698320: f90037e8    	str	x8, [sp, #0x68]
102698324: d360fd35    	lsr	x21, x9, #32
102698328: 52800576    	mov	w22, #0x2b              ; =43
10269832c: f9400be8    	ldr	x8, [sp, #0x10]
102698330: b5002128    	cbnz	x8, 0x102698754 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x127c>
102698334: 1400010c    	b	0x102698764 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x128c>
102698338: ad468361    	ldp	q1, q0, [x27, #0xd0]
10269833c: ad0203e1    	stp	q1, q0, [sp, #0x40]
102698340: f9419fea    	ldr	x10, [sp, #0x338]
102698344: f941b3f8    	ldr	x24, [sp, #0x360]
102698348: 3ccf8360    	ldur	q0, [x27, #0xf8]
10269834c: 911643e8    	add	x8, sp, #0x590
102698350: 3d803d00    	str	q0, [x8, #0xf0]
102698354: 52800088    	mov	w8, #0x4                ; =4
102698358: 911643eb    	add	x11, sp, #0x590
10269835c: ad478560    	ldp	q0, q1, [x11, #0xf0]
102698360: 3d800d60    	str	q0, [x11, #0x30]
102698364: ad4203e2    	ldp	q2, q0, [sp, #0x40]
102698368: 3c808162    	stur	q2, [x11, #0x8]
10269836c: 3c818160    	stur	q0, [x11, #0x18]
102698370: f902cbea    	str	x10, [sp, #0x590]
102698374: f902dff8    	str	x24, [sp, #0x5b8]
102698378: f902ebe8    	str	x8, [sp, #0x5d0]
10269837c: f902efe9    	str	x9, [sp, #0x5d8]
102698380: ad028162    	stp	q2, q0, [x11, #0x50]
102698384: 3c878161    	stur	q1, [x11, #0x78]
102698388: ad488560    	ldp	q0, q1, [x11, #0x110]
10269838c: 3c888160    	stur	q0, [x11, #0x88]
102698390: 3c898161    	stur	q1, [x11, #0x98]
102698394: f94363e9    	ldr	x9, [sp, #0x6c0]
102698398: f90303f8    	str	x24, [sp, #0x600]
10269839c: f9031fe9    	str	x9, [sp, #0x638]
1026983a0: f100111f    	cmp	x8, #0x4
1026983a4: 540003a1    	b.ne	0x102698418 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xf40>
1026983a8: f941cfe8    	ldr	x8, [sp, #0x398]
1026983ac: f9400108    	ldr	x8, [x8]
1026983b0: f94017e9    	ldr	x9, [sp, #0x28]
1026983b4: 9bc87d29    	umulh	x9, x9, x8
1026983b8: eb0903ff    	cmp	xzr, x9
1026983bc: 540036a1    	b.ne	0x102698a90 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x15b8>
1026983c0: f94017e9    	ldr	x9, [sp, #0x28]
1026983c4: 9b087d37    	mul	x23, x9, x8
1026983c8: 52800588    	mov	w8, #0x2c               ; =44
1026983cc: 391b43e8    	strb	w8, [sp, #0x6d0]
1026983d0: 911b43e0    	add	x0, sp, #0x6d0
1026983d4: 94007393    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1026983d8: f942ebe8    	ldr	x8, [sp, #0x5d0]
1026983dc: f100111f    	cmp	x8, #0x4
1026983e0: 540001e1    	b.ne	0x10269841c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xf44>
1026983e4: f941cfe8    	ldr	x8, [sp, #0x398]
1026983e8: f9400108    	ldr	x8, [x8]
1026983ec: f94037e9    	ldr	x9, [sp, #0x68]
1026983f0: 9bc87d29    	umulh	x9, x9, x8
1026983f4: eb0903ff    	cmp	xzr, x9
1026983f8: 540034c1    	b.ne	0x102698a90 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x15b8>
1026983fc: f94037e9    	ldr	x9, [sp, #0x68]
102698400: 9b087d38    	mul	x24, x9, x8
102698404: 52800588    	mov	w8, #0x2c               ; =44
102698408: 391b43e8    	strb	w8, [sp, #0x6d0]
10269840c: 911b43e0    	add	x0, sp, #0x6d0
102698410: 94007384    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102698414: 14000003    	b	0x102698420 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xf48>
102698418: d2800017    	mov	x23, #0x0               ; =0
10269841c: d2800018    	mov	x24, #0x0               ; =0
102698420: ab1602f9    	adds	x25, x23, x22
102698424: 54003362    	b.hs	0x102698a90 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x15b8>
102698428: 52800596    	mov	w22, #0x2c              ; =44
10269842c: 391b43f6    	strb	w22, [sp, #0x6d0]
102698430: 911b43e0    	add	x0, sp, #0x6d0
102698434: 9400737b    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102698438: 391b43f6    	strb	w22, [sp, #0x6d0]
10269843c: 911b43e0    	add	x0, sp, #0x6d0
102698440: 94007378    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102698444: 52800036    	mov	w22, #0x1               ; =1
102698448: d10283a0    	sub	x0, x29, #0xa0
10269844c: 911043e1    	add	x1, sp, #0x410
102698450: 910022a5    	add	x5, x21, #0x8
102698454: d2800002    	mov	x2, #0x0                ; =0
102698458: d2800003    	mov	x3, #0x0                ; =0
10269845c: aa1903e4    	mov	x4, x25
102698460: 97fc4661    	bl	0x1025a9de4 <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext5check>
102698464: 385603a8    	ldurb	w8, [x29, #-0xa0]
102698468: 7100211f    	cmp	w8, #0x8
10269846c: 54000d41    	b.ne	0x102698614 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x113c>
102698470: f9419be8    	ldr	x8, [sp, #0x330]
102698474: f941c3e9    	ldr	x9, [sp, #0x380]
102698478: b9411100    	ldr	w0, [x8, #0x110]
10269847c: 3dc01d20    	ldr	q0, [x9, #0x70]
102698480: 911b43ea    	add	x10, sp, #0x6d0
102698484: 3d801d40    	str	q0, [x10, #0x70]
102698488: 3dc02120    	ldr	q0, [x9, #0x80]
10269848c: 3d802140    	str	q0, [x10, #0x80]
102698490: 3dc02520    	ldr	q0, [x9, #0x90]
102698494: 3d802540    	str	q0, [x10, #0x90]
102698498: f9405128    	ldr	x8, [x9, #0xa0]
10269849c: f903bbe8    	str	x8, [sp, #0x770]
1026984a0: 3dc00d20    	ldr	q0, [x9, #0x30]
1026984a4: 3d800d40    	str	q0, [x10, #0x30]
1026984a8: 3dc01120    	ldr	q0, [x9, #0x40]
1026984ac: 3d801140    	str	q0, [x10, #0x40]
1026984b0: 3dc01520    	ldr	q0, [x9, #0x50]
1026984b4: 3d801540    	str	q0, [x10, #0x50]
1026984b8: 3dc01920    	ldr	q0, [x9, #0x60]
1026984bc: 3d801940    	str	q0, [x10, #0x60]
1026984c0: 3dc00120    	ldr	q0, [x9]
1026984c4: 3d800140    	str	q0, [x10]
1026984c8: 3dc00520    	ldr	q0, [x9, #0x10]
1026984cc: 3d800540    	str	q0, [x10, #0x10]
1026984d0: 3dc00920    	ldr	q0, [x9, #0x20]
1026984d4: 3d800940    	str	q0, [x10, #0x20]
1026984d8: d10283a8    	sub	x8, x29, #0xa0
1026984dc: 911b43e1    	add	x1, sp, #0x6d0
1026984e0: f94037e2    	ldr	x2, [sp, #0x68]
1026984e4: f9400fe3    	ldr	x3, [sp, #0x18]
1026984e8: aa1803e4    	mov	x4, x24
1026984ec: 97f6d64d    	bl	0x10244de20 <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates12check_output>
1026984f0: 385603b6    	ldurb	w22, [x29, #-0xa0]
1026984f4: 7100badf    	cmp	w22, #0x2e
1026984f8: 54000ca1    	b.ne	0x10269868c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x11b4>
1026984fc: d37dff08    	lsr	x8, x24, #61
102698500: b5000fc8    	cbnz	x8, 0x1026986f8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1220>
102698504: 52800588    	mov	w8, #0x2c               ; =44
102698508: 391b43e8    	strb	w8, [sp, #0x6d0]
10269850c: 92801008    	mov	x8, #-0x81              ; =-129
102698510: f2e3ffe8    	movk	x8, #0x1fff, lsl #48
102698514: eb08031f    	cmp	x24, x8
102698518: 54000f08    	b.hi	0x1026986f8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1220>
10269851c: d37df315    	lsl	x21, x24, #3
102698520: 911b43e0    	add	x0, sp, #0x6d0
102698524: 9400733f    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
102698528: 52800036    	mov	w22, #0x1               ; =1
10269852c: d10283a8    	sub	x8, x29, #0xa0
102698530: 911043e0    	add	x0, sp, #0x410
102698534: 911002a1    	add	x1, x21, #0x400
102698538: d2800002    	mov	x2, #0x0                ; =0
10269853c: 97fc4684    	bl	0x1025a9f4c <__RNvMNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget22native_turn_plan_cache17string_projectionNtB2_28NativeProjectionIndexContext6charge>
102698540: 385603a8    	ldurb	w8, [x29, #-0xa0]
102698544: 7100211f    	cmp	w8, #0x8
102698548: 54000661    	b.ne	0x102698614 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x113c>
10269854c: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698550: f9000fe8    	str	x8, [sp, #0x18]
102698554: f100111f    	cmp	x8, #0x4
102698558: 1a9f17e8    	cset	w8, eq
10269855c: b9006be8    	str	w8, [sp, #0x68]
102698560: 540010c1    	b.ne	0x102698778 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x12a0>
102698564: 911b43e8    	add	x8, sp, #0x6d0
102698568: 910fe3e0    	add	x0, sp, #0x3f8
10269856c: aa1703e1    	mov	x1, x23
102698570: 9416dbaa    	bl	0x102c4f418 <__RNvMs0_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_19ManagedMemoryBudget16reserve_capacity>
102698574: b946d3f7    	ldr	w23, [sp, #0x6d0]
102698578: 71006aff    	cmp	w23, #0x1a
10269857c: 54001781    	b.ne	0x10269886c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1394>
102698580: 911b43e8    	add	x8, sp, #0x6d0
102698584: 3cc08100    	ldur	q0, [x8, #0x8]
102698588: 3cc18101    	ldur	q1, [x8, #0x18]
10269858c: ad068500    	stp	q0, q1, [x8, #0xd0]
102698590: d10283a8    	sub	x8, x29, #0xa0
102698594: 9115c3e0    	add	x0, sp, #0x570
102698598: 911e83e1    	add	x1, sp, #0x7a0
10269859c: 9416e3af    	bl	0x102c51458 <__RNvMs5_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservation14merge_capacity>
1026985a0: b85603a8    	ldur	w8, [x29, #-0xa0]
1026985a4: 7100691f    	cmp	w8, #0x1a
1026985a8: 540023e1    	b.ne	0x102698a24 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x154c>
1026985ac: f942cbe8    	ldr	x8, [sp, #0x590]
1026985b0: b4002708    	cbz	x8, 0x102698a90 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x15b8>
1026985b4: 52800596    	mov	w22, #0x2c              ; =44
1026985b8: 391b43f6    	strb	w22, [sp, #0x6d0]
1026985bc: 911b43e0    	add	x0, sp, #0x6d0
1026985c0: 94007318    	bl	0x1026b5220 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls10invocation31NativeCollectionInvocationErrorEBQ_>
1026985c4: f942cfe8    	ldr	x8, [sp, #0x598]
1026985c8: f9400909    	ldr	x9, [x8, #0x10]
1026985cc: 39404128    	ldrb	w8, [x9, #0x10]
1026985d0: 7100651f    	cmp	w8, #0x19
1026985d4: 54002701    	b.ne	0x102698ab4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x15dc>
1026985d8: 52800036    	mov	w22, #0x1               ; =1
1026985dc: d10283a8    	sub	x8, x29, #0xa0
1026985e0: 91006120    	add	x0, x9, #0x18
1026985e4: 9416f04f    	bl	0x102c54720 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot4dataNtB5_11MatrixValue8elements>
1026985e8: 911b43e8    	add	x8, sp, #0x6d0
1026985ec: d10283a0    	sub	x0, x29, #0xa0
1026985f0: f94017e1    	ldr	x1, [sp, #0x28]
1026985f4: 97f6d636    	bl	0x10244decc <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates4copy>
1026985f8: 395b43f6    	ldrb	w22, [sp, #0x6d0]
1026985fc: 7100badf    	cmp	w22, #0x2e
102698600: 54002801    	b.ne	0x102698b00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1628>
102698604: 911b43e8    	add	x8, sp, #0x6d0
102698608: 3cc08100    	ldur	q0, [x8, #0x8]
10269860c: 3cc18101    	ldur	q1, [x8, #0x18]
102698610: 1400007c    	b	0x102698800 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1328>
102698614: 296c57a8    	ldp	w8, w21, [x29, #-0xa0]
102698618: 912023e9    	add	x9, sp, #0x808
10269861c: ad448520    	ldp	q0, q1, [x9, #0x90]
102698620: ad0207e0    	stp	q0, q1, [sp, #0x40]
102698624: 12001d17    	and	w23, w8, #0xff
102698628: 53087d08    	lsr	w8, w8, #8
10269862c: f90037e8    	str	x8, [sp, #0x68]
102698630: 52800536    	mov	w22, #0x29              ; =41
102698634: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698638: 52800039    	mov	w25, #0x1               ; =1
10269863c: f100111f    	cmp	x8, #0x4
102698640: 54000761    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
102698644: 1400003c    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
102698648: 911b43ea    	add	x10, sp, #0x6d0
10269864c: 3cc38140    	ldur	q0, [x10, #0x38]
102698650: 3cc48141    	ldur	q1, [x10, #0x48]
102698654: 911643eb    	add	x11, sp, #0x590
102698658: ad058560    	stp	q0, q1, [x11, #0xb0]
10269865c: 3cc58140    	ldur	q0, [x10, #0x58]
102698660: 3d803560    	str	q0, [x11, #0xd0]
102698664: f9439fea    	ldr	x10, [sp, #0x738]
102698668: f9033bea    	str	x10, [sp, #0x670]
10269866c: f100111f    	cmp	x8, #0x4
102698670: 54000321    	b.ne	0x1026986d4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x11fc>
102698674: 911643e8    	add	x8, sp, #0x590
102698678: 3dc02d00    	ldr	q0, [x8, #0xb0]
10269867c: 3d803d00    	str	q0, [x8, #0xf0]
102698680: 52800088    	mov	w8, #0x4                ; =4
102698684: aa0903ea    	mov	x10, x9
102698688: 17ffff34    	b	0x102698358 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xe80>
10269868c: 912023ea    	add	x10, sp, #0x808
102698690: b8489148    	ldur	w8, [x10, #0x89]
102698694: b9032be8    	str	w8, [sp, #0x328]
102698698: 296ca7a8    	ldp	w8, w9, [x29, #-0x9c]
10269869c: b80bb368    	stur	w8, [x27, #0xbb]
1026986a0: b856c3b5    	ldur	w21, [x29, #-0x94]
1026986a4: 12001d37    	and	w23, w9, #0xff
1026986a8: 53087d28    	lsr	w8, w9, #8
1026986ac: f90037e8    	str	x8, [sp, #0x68]
1026986b0: 3cca8141    	ldur	q1, [x10, #0xa8]
1026986b4: 3cc98140    	ldur	q0, [x10, #0x98]
1026986b8: ad0207e0    	stp	q0, q1, [sp, #0x40]
1026986bc: f85903b8    	ldur	x24, [x29, #-0x70]
1026986c0: f942ebe8    	ldr	x8, [sp, #0x5d0]
1026986c4: 52800039    	mov	w25, #0x1               ; =1
1026986c8: f100111f    	cmp	x8, #0x4
1026986cc: 54000301    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
1026986d0: 14000019    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
1026986d4: d280000a    	mov	x10, #0x0               ; =0
1026986d8: 911643eb    	add	x11, sp, #0x590
1026986dc: ad458560    	ldp	q0, q1, [x11, #0xb0]
1026986e0: ad080560    	stp	q0, q1, [x11, #0x100]
1026986e4: 3dc03560    	ldr	q0, [x11, #0xd0]
1026986e8: 3d804960    	str	q0, [x11, #0x120]
1026986ec: f9433beb    	ldr	x11, [sp, #0x670]
1026986f0: f90363eb    	str	x11, [sp, #0x6c0]
1026986f4: 17ffff19    	b	0x102698358 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xe80>
1026986f8: f90037ff    	str	xzr, [sp, #0x68]
1026986fc: 52800017    	mov	w23, #0x0               ; =0
102698700: 52800015    	mov	w21, #0x0               ; =0
102698704: 911b43e8    	add	x8, sp, #0x6d0
102698708: b8401108    	ldur	w8, [x8, #0x1]
10269870c: b9032be8    	str	w8, [sp, #0x328]
102698710: b946d7e8    	ldr	w8, [sp, #0x6d4]
102698714: b80bb368    	stur	w8, [x27, #0xbb]
102698718: 52800596    	mov	w22, #0x2c              ; =44
10269871c: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698720: 52800039    	mov	w25, #0x1               ; =1
102698724: f100111f    	cmp	x8, #0x4
102698728: 54000060    	b.eq	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
10269872c: 911743e0    	add	x0, sp, #0x5d0
102698730: 9400724f    	bl	0x1026b506c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
102698734: f942cbe8    	ldr	x8, [sp, #0x590]
102698738: b4000068    	cbz	x8, 0x102698744 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x126c>
10269873c: 911643e0    	add	x0, sp, #0x590
102698740: 94006bfc    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698744: f9400be8    	ldr	x8, [sp, #0x10]
102698748: f100011f    	cmp	x8, #0x0
10269874c: 1a9903e8    	csel	w8, wzr, w25, eq
102698750: 360000a8    	tbz	w8, #0x0, 0x102698764 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x128c>
102698754: a940a3e0    	ldp	x0, x8, [sp, #0x8]
102698758: d37df101    	lsl	x1, x8, #3
10269875c: 52800102    	mov	w2, #0x8                ; =8
102698760: 9765cf00    	bl	0x10000c360 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102698764: 52800019    	mov	w25, #0x0               ; =0
102698768: 9115c3e0    	add	x0, sp, #0x570
10269876c: 94006913    	bl	0x1026b2bb8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
102698770: 52800059    	mov	w25, #0x2               ; =2
102698774: 17fffe14    	b	0x102697fc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0xaec>
102698778: 911643e9    	add	x9, sp, #0x590
10269877c: ad440520    	ldp	q0, q1, [x9, #0x80]
102698780: 911b43e8    	add	x8, sp, #0x6d0
102698784: ad020500    	stp	q0, q1, [x8, #0x40]
102698788: 3dc02920    	ldr	q0, [x9, #0xa0]
10269878c: 3d801900    	str	q0, [x8, #0x60]
102698790: ad420520    	ldp	q0, q1, [x9, #0x40]
102698794: ad000500    	stp	q0, q1, [x8]
102698798: ad430121    	ldp	q1, q0, [x9, #0x60]
10269879c: ad010101    	stp	q1, q0, [x8, #0x20]
1026987a0: 52800016    	mov	w22, #0x0               ; =0
1026987a4: d10283a8    	sub	x8, x29, #0xa0
1026987a8: 911b43e0    	add	x0, sp, #0x6d0
1026987ac: 9416da96    	bl	0x102c4f204 <__RNvMNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrixNtB2_27OwnedSnapshotUnsignedMatrix10into_parts>
1026987b0: 912023e8    	add	x8, sp, #0x808
1026987b4: 3cc88100    	ldur	q0, [x8, #0x88]
1026987b8: 3c848100    	stur	q0, [x8, #0x48]
1026987bc: 3cc98100    	ldur	q0, [x8, #0x98]
1026987c0: 3c858100    	stur	q0, [x8, #0x58]
1026987c4: 3cca8100    	ldur	q0, [x8, #0xa8]
1026987c8: 3ccb8101    	ldur	q1, [x8, #0xb8]
1026987cc: 911b43e8    	add	x8, sp, #0x6d0
1026987d0: ad068500    	stp	q0, q1, [x8, #0xd0]
1026987d4: d10283a8    	sub	x8, x29, #0xa0
1026987d8: 9115c3e0    	add	x0, sp, #0x570
1026987dc: 911e83e1    	add	x1, sp, #0x7a0
1026987e0: 9416e31e    	bl	0x102c51458 <__RNvMs5_NtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budgetNtB5_24ManagedMemoryReservation14merge_capacity>
1026987e4: b85603a8    	ldur	w8, [x29, #-0xa0]
1026987e8: 7100691f    	cmp	w8, #0x1a
1026987ec: 540005a1    	b.ne	0x1026988a0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x13c8>
1026987f0: 912023e8    	add	x8, sp, #0x808
1026987f4: 3cc48100    	ldur	q0, [x8, #0x48]
1026987f8: 3cc58101    	ldur	q1, [x8, #0x58]
1026987fc: 911b43e8    	add	x8, sp, #0x6d0
102698800: ad058500    	stp	q0, q1, [x8, #0xb0]
102698804: f941d3e8    	ldr	x8, [sp, #0x3a0]
102698808: f9400102    	ldr	x2, [x8]
10269880c: d10283a8    	sub	x8, x29, #0xa0
102698810: 911e03e0    	add	x0, sp, #0x780
102698814: f94013e1    	ldr	x1, [sp, #0x20]
102698818: 97f6d6c5    	bl	0x10244e32c <__RNvNtNtNtNtNtCs1qJAwyMG1lC_11mech_engine8resident7general23native_collection_calls8prepared12word_updates7replace>
10269881c: 385603b6    	ldurb	w22, [x29, #-0xa0]
102698820: 7100badf    	cmp	w22, #0x2e
102698824: 1a9f07f9    	cset	w25, ne
102698828: 54000560    	b.eq	0x1026988d4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x13fc>
10269882c: 912023ea    	add	x10, sp, #0x808
102698830: b8489148    	ldur	w8, [x10, #0x89]
102698834: b9032be8    	str	w8, [sp, #0x328]
102698838: 296ca7a8    	ldp	w8, w9, [x29, #-0x9c]
10269883c: b80bb368    	stur	w8, [x27, #0xbb]
102698840: b856c3b5    	ldur	w21, [x29, #-0x94]
102698844: 12001d37    	and	w23, w9, #0xff
102698848: 53087d28    	lsr	w8, w9, #8
10269884c: f90037e8    	str	x8, [sp, #0x68]
102698850: 3cca8141    	ldur	q1, [x10, #0xa8]
102698854: 3cc98140    	ldur	q0, [x10, #0x98]
102698858: ad0207e0    	stp	q0, q1, [sp, #0x40]
10269885c: f85903b8    	ldur	x24, [x29, #-0x70]
102698860: 911e03e0    	add	x0, sp, #0x780
102698864: 940071e4    	bl	0x1026b4ff4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
102698868: 1400009f    	b	0x102698ae4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x160c>
10269886c: f90037ff    	str	xzr, [sp, #0x68]
102698870: b946d7f5    	ldr	w21, [sp, #0x6d4]
102698874: 911b43e8    	add	x8, sp, #0x6d0
102698878: 3cc18101    	ldur	q1, [x8, #0x18]
10269887c: 3cc08100    	ldur	q0, [x8, #0x8]
102698880: ad0207e0    	stp	q0, q1, [sp, #0x40]
102698884: 52800576    	mov	w22, #0x2b              ; =43
102698888: f9437ff8    	ldr	x24, [sp, #0x6f8]
10269888c: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698890: 52800039    	mov	w25, #0x1               ; =1
102698894: f100111f    	cmp	x8, #0x4
102698898: 54fff4a1    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
10269889c: 17ffffa6    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
1026988a0: 296c57b6    	ldp	w22, w21, [x29, #-0xa0]
1026988a4: 912023e8    	add	x8, sp, #0x808
1026988a8: ad448500    	ldp	q0, q1, [x8, #0x90]
1026988ac: ad0207e0    	stp	q0, q1, [sp, #0x40]
1026988b0: f85883b8    	ldur	x24, [x29, #-0x78]
1026988b4: d10383a0    	sub	x0, x29, #0xe0
1026988b8: 940071cf    	bl	0x1026b4ff4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
1026988bc: 53087ec8    	lsr	w8, w22, #8
1026988c0: f90037e8    	str	x8, [sp, #0x68]
1026988c4: 12001ed7    	and	w23, w22, #0xff
1026988c8: 52800039    	mov	w25, #0x1               ; =1
1026988cc: 52800576    	mov	w22, #0x2b              ; =43
1026988d0: 17ffff99    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
1026988d4: b9402f40    	ldr	w0, [x26, #0x2c]
1026988d8: f9419be8    	ldr	x8, [sp, #0x330]
1026988dc: f940b904    	ldr	x4, [x8, #0x170]
1026988e0: 52800028    	mov	w8, #0x1                ; =1
1026988e4: f8280088    	ldadd	x8, x8, [x4]
1026988e8: b7f80c68    	tbnz	x8, #0x3f, 0x102698a74 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x159c>
1026988ec: 912023e8    	add	x8, sp, #0x808
1026988f0: 911e03e3    	add	x3, sp, #0x780
1026988f4: a9408be1    	ldp	x1, x2, [sp, #0x8]
1026988f8: 9416fe84    	bl	0x102c58308 <__RNvMs_NtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrixNtB6_5Value27from_unsigned_matrix_buffer>
1026988fc: 396023e8    	ldrb	w8, [sp, #0x808]
102698900: 7100591f    	cmp	w8, #0x16
102698904: 54000ba1    	b.ne	0x102698a78 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x15a0>
102698908: f9440be8    	ldr	x8, [sp, #0x810]
10269890c: 396063e9    	ldrb	w9, [sp, #0x818]
102698910: 912023ea    	add	x10, sp, #0x808
102698914: 3cc11140    	ldur	q0, [x10, #0x11]
102698918: 3c851140    	stur	q0, [x10, #0x51]
10269891c: 3cc21140    	ldur	q0, [x10, #0x21]
102698920: 3c861140    	stur	q0, [x10, #0x61]
102698924: 3cc31140    	ldur	q0, [x10, #0x31]
102698928: 3c871140    	stur	q0, [x10, #0x71]
10269892c: f94427ea    	ldr	x10, [sp, #0x848]
102698930: f81583aa    	stur	x10, [x29, #-0xa8]
102698934: f81203a8    	stur	x8, [x29, #-0xe0]
102698938: 381283a9    	sturb	w9, [x29, #-0xd8]
10269893c: d10283a8    	sub	x8, x29, #0xa0
102698940: d10383a0    	sub	x0, x29, #0xe0
102698944: 9115c3e1    	add	x1, sp, #0x570
102698948: 9416e3d2    	bl	0x102c51890 <__RNvMs7_NtNtCskIfnrfrMWVM_9mech_core8snapshot10validationNtB5_5Value18into_memory_budget>
10269894c: a97627b6    	ldp	x22, x9, [x29, #-0xa0]
102698950: 912023e8    	add	x8, sp, #0x808
102698954: 3cca8101    	ldur	q1, [x8, #0xa8]
102698958: 3cc98100    	ldur	q0, [x8, #0x98]
10269895c: ad0207e0    	stp	q0, q1, [sp, #0x40]
102698960: f85903b8    	ldur	x24, [x29, #-0x70]
102698964: aa0903f7    	mov	x23, x9
102698968: d360fd35    	lsr	x21, x9, #32
10269896c: b4000b36    	cbz	x22, 0x102698ad0 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x15f8>
102698970: 911643e8    	add	x8, sp, #0x590
102698974: ad400500    	ldp	q0, q1, [x8]
102698978: 912023e9    	add	x9, sp, #0x808
10269897c: 3c888120    	stur	q0, [x9, #0x88]
102698980: 3c898121    	stur	q1, [x9, #0x98]
102698984: ad410500    	ldp	q0, q1, [x8, #0x20]
102698988: 3c8a8120    	stur	q0, [x9, #0xa8]
10269898c: ad4203e2    	ldp	q2, q0, [sp, #0x40]
102698990: 911b67e8    	add	x8, sp, #0x6d9
102698994: 3c8ff102    	stur	q2, [x8, #0xff]
102698998: 911ba7e8    	add	x8, sp, #0x6e9
10269899c: 3c8ff100    	stur	q0, [x8, #0xff]
1026989a0: f903ebf7    	str	x23, [sp, #0x7d0]
1026989a4: f903e7f6    	str	x22, [sp, #0x7c8]
1026989a8: f85983ba    	ldur	x26, [x29, #-0x68]
1026989ac: f85603a8    	ldur	x8, [x29, #-0xa0]
1026989b0: f903fff8    	str	x24, [sp, #0x7f8]
1026989b4: f90403fa    	str	x26, [sp, #0x800]
1026989b8: 3c8b8121    	stur	q1, [x9, #0xb8]
1026989bc: b4000068    	cbz	x8, 0x1026989c8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x14f0>
1026989c0: d10283a0    	sub	x0, x29, #0xa0
1026989c4: 94006b5b    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
1026989c8: 911b43e8    	add	x8, sp, #0x6d0
1026989cc: b84f9108    	ldur	w8, [x8, #0xf9]
1026989d0: b9032be8    	str	w8, [sp, #0x328]
1026989d4: b947cfe8    	ldr	w8, [sp, #0x7cc]
1026989d8: b80bb368    	stur	w8, [x27, #0xbb]
1026989dc: 52800019    	mov	w25, #0x0               ; =0
1026989e0: 9115c3e0    	add	x0, sp, #0x570
1026989e4: 94006875    	bl	0x1026b2bb8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
1026989e8: f941ffe8    	ldr	x8, [sp, #0x3f8]
1026989ec: 92800009    	mov	x9, #-0x1               ; =-1
1026989f0: f8690108    	ldaddl	x9, x8, [x8]
1026989f4: f100051f    	cmp	x8, #0x1
1026989f8: 54000081    	b.ne	0x102698a08 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1530>
1026989fc: d50339bf    	dmb	ishld
102698a00: 910fe3e0    	add	x0, sp, #0x3f8
102698a04: 941703fa    	bl	0x102c599ec <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102698a08: 12001ed6    	and	w22, w22, #0xff
102698a0c: aa1703e8    	mov	x8, x23
102698a10: 12001d17    	and	w23, w8, #0xff
102698a14: 53087d08    	lsr	w8, w8, #8
102698a18: f90037e8    	str	x8, [sp, #0x68]
102698a1c: 52800039    	mov	w25, #0x1               ; =1
102698a20: 17fffc0c    	b	0x102697a50 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x578>
102698a24: 296c57a8    	ldp	w8, w21, [x29, #-0xa0]
102698a28: 912023e9    	add	x9, sp, #0x808
102698a2c: ad448520    	ldp	q0, q1, [x9, #0x90]
102698a30: ad0207e0    	stp	q0, q1, [sp, #0x40]
102698a34: f85883b8    	ldur	x24, [x29, #-0x78]
102698a38: 12001d17    	and	w23, w8, #0xff
102698a3c: 53087d08    	lsr	w8, w8, #8
102698a40: f90037e8    	str	x8, [sp, #0x68]
102698a44: 52800576    	mov	w22, #0x2b              ; =43
102698a48: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698a4c: 52800039    	mov	w25, #0x1               ; =1
102698a50: f100111f    	cmp	x8, #0x4
102698a54: 54ffe6c1    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
102698a58: 17ffff37    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
102698a5c: 52800039    	mov	w25, #0x1               ; =1
102698a60: d000a0a2    	adrp	x2, 0x103aae000 <_anon.1794c5ae655e7d08df762cb3f886e887.211+0x168>
102698a64: 91096042    	add	x2, x2, #0x258
102698a68: d2800000    	mov	x0, #0x0                ; =0
102698a6c: d2800001    	mov	x1, #0x0                ; =0
102698a70: 941c611e    	bl	0x102db0ee8 <__RNvNtCsgDHHaSskbIF_4core9panicking18panic_bounds_check>
102698a74: d4200020    	brk	#0x1
102698a78: 912023e0    	add	x0, sp, #0x808
102698a7c: 94006dfc    	bl	0x1026b426c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot5error18SnapshotValueErrorECs1qJAwyMG1lC_11mech_engine>
102698a80: 52800017    	mov	w23, #0x0               ; =0
102698a84: 52800596    	mov	w22, #0x2c              ; =44
102698a88: f90037e8    	str	x8, [sp, #0x68]
102698a8c: 14000016    	b	0x102698ae4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x160c>
102698a90: f90037ff    	str	xzr, [sp, #0x68]
102698a94: 52800017    	mov	w23, #0x0               ; =0
102698a98: 52800015    	mov	w21, #0x0               ; =0
102698a9c: 52800596    	mov	w22, #0x2c              ; =44
102698aa0: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698aa4: 52800039    	mov	w25, #0x1               ; =1
102698aa8: f100111f    	cmp	x8, #0x4
102698aac: 54ffe401    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
102698ab0: 17ffff21    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
102698ab4: 52800017    	mov	w23, #0x0               ; =0
102698ab8: f90037e8    	str	x8, [sp, #0x68]
102698abc: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698ac0: 52800039    	mov	w25, #0x1               ; =1
102698ac4: f100111f    	cmp	x8, #0x4
102698ac8: 54ffe321    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
102698acc: 17ffff1a    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
102698ad0: aa1703e8    	mov	x8, x23
102698ad4: 12001d17    	and	w23, w8, #0xff
102698ad8: 53087d08    	lsr	w8, w8, #8
102698adc: 52800576    	mov	w22, #0x2b              ; =43
102698ae0: f90037e8    	str	x8, [sp, #0x68]
102698ae4: f9400fe8    	ldr	x8, [sp, #0x18]
102698ae8: f100111f    	cmp	x8, #0x4
102698aec: 54ffe241    	b.ne	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
102698af0: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698af4: f100111f    	cmp	x8, #0x4
102698af8: 54ffe1a1    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
102698afc: 17ffff0e    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
102698b00: 911b43ea    	add	x10, sp, #0x6d0
102698b04: b8401148    	ldur	w8, [x10, #0x1]
102698b08: b9032be8    	str	w8, [sp, #0x328]
102698b0c: b946d7e8    	ldr	w8, [sp, #0x6d4]
102698b10: b946dbe9    	ldr	w9, [sp, #0x6d8]
102698b14: b80bb368    	stur	w8, [x27, #0xbb]
102698b18: b946dff5    	ldr	w21, [sp, #0x6dc]
102698b1c: ad408540    	ldp	q0, q1, [x10, #0x10]
102698b20: ad0207e0    	stp	q0, q1, [sp, #0x40]
102698b24: f94383f8    	ldr	x24, [sp, #0x700]
102698b28: 12001d37    	and	w23, w9, #0xff
102698b2c: 53087d28    	lsr	w8, w9, #8
102698b30: f90037e8    	str	x8, [sp, #0x68]
102698b34: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698b38: 52800039    	mov	w25, #0x1               ; =1
102698b3c: f100111f    	cmp	x8, #0x4
102698b40: 54ffdf61    	b.ne	0x10269872c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1254>
102698b44: 17fffefc    	b	0x102698734 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x125c>
102698b48: aa0003f4    	mov	x20, x0
102698b4c: 911f23e0    	add	x0, sp, #0x7c8
102698b50: 94006af8    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698b54: 52800019    	mov	w25, #0x0               ; =0
102698b58: 52800015    	mov	w21, #0x0               ; =0
102698b5c: 1400001c    	b	0x102698bcc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x16f4>
102698b60: aa0003f4    	mov	x20, x0
102698b64: 52800019    	mov	w25, #0x0               ; =0
102698b68: 14000018    	b	0x102698bc8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x16f0>
102698b6c: aa0003f4    	mov	x20, x0
102698b70: 911e03e0    	add	x0, sp, #0x780
102698b74: 94007120    	bl	0x1026b4ff4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
102698b78: 52800039    	mov	w25, #0x1               ; =1
102698b7c: 14000013    	b	0x102698bc8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x16f0>
102698b80: aa0003f4    	mov	x20, x0
102698b84: d10383a0    	sub	x0, x29, #0xe0
102698b88: 9400711b    	bl	0x1026b4ff4 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation14numeric_matrix20UnsignedMatrixBufferECs1qJAwyMG1lC_11mech_engine>
102698b8c: 52800039    	mov	w25, #0x1               ; =1
102698b90: 14000017    	b	0x102698bec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1714>
102698b94: aa0003f4    	mov	x20, x0
102698b98: 14000015    	b	0x102698bec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1714>
102698b9c: aa0003f4    	mov	x20, x0
102698ba0: 37000319    	tbnz	w25, #0x0, 0x102698c00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1728>
102698ba4: 1400001d    	b	0x102698c18 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1740>
102698ba8: aa0003f4    	mov	x20, x0
102698bac: 14000015    	b	0x102698c00 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1728>
102698bb0: aa0003f4    	mov	x20, x0
102698bb4: 52800039    	mov	w25, #0x1               ; =1
102698bb8: 14000019    	b	0x102698c1c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1744>
102698bbc: aa0003f4    	mov	x20, x0
102698bc0: 52800039    	mov	w25, #0x1               ; =1
102698bc4: b9006bf6    	str	w22, [sp, #0x68]
102698bc8: 52800035    	mov	w21, #0x1               ; =1
102698bcc: b9406be8    	ldr	w8, [sp, #0x68]
102698bd0: 340000c8    	cbz	w8, 0x102698be8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1710>
102698bd4: f942ebe8    	ldr	x8, [sp, #0x5d0]
102698bd8: f100111f    	cmp	x8, #0x4
102698bdc: 54000060    	b.eq	0x102698be8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1710>
102698be0: 911743e0    	add	x0, sp, #0x5d0
102698be4: 94007122    	bl	0x1026b506c <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation21owned_unsigned_matrix27OwnedSnapshotUnsignedMatrixECs1qJAwyMG1lC_11mech_engine>
102698be8: 360000b5    	tbz	w21, #0x0, 0x102698bfc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1724>
102698bec: f942cbe8    	ldr	x8, [sp, #0x590]
102698bf0: b4000068    	cbz	x8, 0x102698bfc <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1724>
102698bf4: 911643e0    	add	x0, sp, #0x590
102698bf8: 94006ace    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698bfc: 360000f9    	tbz	w25, #0x0, 0x102698c18 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1740>
102698c00: f9400be8    	ldr	x8, [sp, #0x10]
102698c04: b40000a8    	cbz	x8, 0x102698c18 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1740>
102698c08: a940a3e0    	ldp	x0, x8, [sp, #0x8]
102698c0c: d37df101    	lsl	x1, x8, #3
102698c10: 52800102    	mov	w2, #0x8                ; =8
102698c14: 9765cdd3    	bl	0x10000c360 <__RNvCsfBzVIH1HIC6_7___rustc14___rust_dealloc>
102698c18: 52800019    	mov	w25, #0x0               ; =0
102698c1c: 9115c3e0    	add	x0, sp, #0x570
102698c20: 940067e6    	bl	0x1026b2bb8 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget24ManagedMemoryReservationECs1qJAwyMG1lC_11mech_engine>
102698c24: 14000031    	b	0x102698ce8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1810>
102698c28: aa0003f4    	mov	x20, x0
102698c2c: 910763e8    	add	x8, sp, #0x1d8
102698c30: 91008100    	add	x0, x8, #0x20
102698c34: 94006abf    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698c38: 14000027    	b	0x102698cd4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x17fc>
102698c3c: 941c60a5    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698c40: aa0003f4    	mov	x20, x0
102698c44: 910263e8    	add	x8, sp, #0x98
102698c48: 91008100    	add	x0, x8, #0x20
102698c4c: 94006ab9    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698c50: 14000067    	b	0x102698dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1914>
102698c54: 941c609f    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698c58: aa0003f4    	mov	x20, x0
102698c5c: b94037e8    	ldr	w8, [sp, #0x34]
102698c60: 37000648    	tbnz	w8, #0x0, 0x102698d28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1850>
102698c64: 14000033    	b	0x102698d30 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1858>
102698c68: aa0003f4    	mov	x20, x0
102698c6c: 1400001f    	b	0x102698ce8 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1810>
102698c70: aa0003f4    	mov	x20, x0
102698c74: 1400002f    	b	0x102698d30 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1858>
102698c78: 910723ea    	add	x10, sp, #0x1c8
102698c7c: aa0003f4    	mov	x20, x0
102698c80: f940ebe8    	ldr	x8, [sp, #0x1d0]
102698c84: b4000b48    	cbz	x8, 0x102698dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1914>
102698c88: f9400109    	ldr	x9, [x8]
102698c8c: f1000529    	subs	x9, x9, #0x1
102698c90: f9000109    	str	x9, [x8]
102698c94: 54000ac1    	b.ne	0x102698dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1914>
102698c98: 91002140    	add	x0, x10, #0x8
102698c9c: 94010ba9    	bl	0x1026dbb40 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102698ca0: 14000053    	b	0x102698dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1914>
102698ca4: 941c608b    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698ca8: aa0003f4    	mov	x20, x0
102698cac: f9418be8    	ldr	x8, [sp, #0x310]
102698cb0: b4000128    	cbz	x8, 0x102698cd4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x17fc>
102698cb4: f9400109    	ldr	x9, [x8]
102698cb8: f1000529    	subs	x9, x9, #0x1
102698cbc: f9000109    	str	x9, [x8]
102698cc0: 540000a1    	b.ne	0x102698cd4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x17fc>
102698cc4: 91002380    	add	x0, x28, #0x8
102698cc8: 94010b9e    	bl	0x1026dbb40 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102698ccc: 910723fb    	add	x27, sp, #0x1c8
102698cd0: 1400003d    	b	0x102698dc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x18ec>
102698cd4: 910723fb    	add	x27, sp, #0x1c8
102698cd8: 1400003b    	b	0x102698dc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x18ec>
102698cdc: 941c607d    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698ce0: aa0003f4    	mov	x20, x0
102698ce4: 52800039    	mov	w25, #0x1               ; =1
102698ce8: f941ffe8    	ldr	x8, [sp, #0x3f8]
102698cec: 92800009    	mov	x9, #-0x1               ; =-1
102698cf0: f8690108    	ldaddl	x9, x8, [x8]
102698cf4: f100051f    	cmp	x8, #0x1
102698cf8: 54000081    	b.ne	0x102698d08 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1830>
102698cfc: d50339bf    	dmb	ishld
102698d00: 910fe3e0    	add	x0, sp, #0x3f8
102698d04: 9417033a    	bl	0x102c599ec <__RNvMsn_NtCsgKscDXrlV49_5alloc4syncINtB5_3ArcNtNtNtCskIfnrfrMWVM_9mech_core14memory_runtime6budget26ManagedMemoryBudgetAccountE9drop_slowBM_>
102698d08: 37000119    	tbnz	w25, #0x0, 0x102698d28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1850>
102698d0c: 14000009    	b	0x102698d30 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1858>
102698d10: aa0003f4    	mov	x20, x0
102698d14: f9400ac8    	ldr	x8, [x22, #0x10]
102698d18: d1000508    	sub	x8, x8, #0x1
102698d1c: f9000ac8    	str	x8, [x22, #0x10]
102698d20: 14000002    	b	0x102698d28 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1850>
102698d24: aa0003f4    	mov	x20, x0
102698d28: aa1c03e0    	mov	x0, x28
102698d2c: 94006a81    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698d30: a947a7e8    	ldp	x8, x9, [sp, #0x78]
102698d34: a9002269    	stp	x9, x8, [x19]
102698d38: f9403be8    	ldr	x8, [sp, #0x70]
102698d3c: f9000a68    	str	x8, [x19, #0x10]
102698d40: 14000003    	b	0x102698d4c <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1874>
102698d44: 941c6063    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698d48: aa0003f4    	mov	x20, x0
102698d4c: 910c23e0    	add	x0, sp, #0x308
102698d50: 94007348    	bl	0x1026b5a70 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtBO_23NativeLibraryWorkBudget16with_call_limits10ScopeGuardEBS_>
102698d54: 910723fb    	add	x27, sp, #0x1c8
102698d58: b27ff7e8    	mov	x8, #0x7ffffffffffffffe ; =9223372036854775806
102698d5c: f9401fe9    	ldr	x9, [sp, #0x38]
102698d60: eb08013f    	cmp	x9, x8
102698d64: 54000188    	b.hi	0x102698d94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x18bc>
102698d68: 14000017    	b	0x102698dc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x18ec>
102698d6c: aa0003f4    	mov	x20, x0
102698d70: f9400268    	ldr	x8, [x19]
102698d74: f1000508    	subs	x8, x8, #0x1
102698d78: f9000268    	str	x8, [x19]
102698d7c: 540000a1    	b.ne	0x102698d90 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x18b8>
102698d80: 911043e0    	add	x0, sp, #0x410
102698d84: 94010b6f    	bl	0x1026dbb40 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102698d88: 910723fb    	add	x27, sp, #0x1c8
102698d8c: 14000002    	b	0x102698d94 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x18bc>
102698d90: 910723fb    	add	x27, sp, #0x1c8
102698d94: 9109c3e8    	add	x8, sp, #0x270
102698d98: 91008100    	add	x0, x8, #0x20
102698d9c: 94006a65    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698da0: 14000009    	b	0x102698dc4 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x18ec>
102698da4: 941c604b    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698da8: 941c604a    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698dac: aa0003f4    	mov	x20, x0
102698db0: 9104c3e8    	add	x8, sp, #0x130
102698db4: 91008100    	add	x0, x8, #0x20
102698db8: 94006a5e    	bl	0x1026b3730 <__RINvNtCsgDHHaSskbIF_4core3ptr13drop_in_placeNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValueECs1qJAwyMG1lC_11mech_engine>
102698dbc: 1400000c    	b	0x102698dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1914>
102698dc0: aa0003f4    	mov	x20, x0
102698dc4: 910723e0    	add	x0, sp, #0x1c8
102698dc8: 94018a45    	bl	0x1026fb6dc <__RNvXNvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB8_23NativeLibraryWorkBudget16with_call_limitsNtB2_12AccountGuardNtNtNtCsgDHHaSskbIF_4core3ops4drop4Drop4drop>
102698dcc: f940ebe8    	ldr	x8, [sp, #0x1d0]
102698dd0: b40000e8    	cbz	x8, 0x102698dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1914>
102698dd4: f9400109    	ldr	x9, [x8]
102698dd8: f1000529    	subs	x9, x9, #0x1
102698ddc: f9000109    	str	x9, [x8]
102698de0: 54000061    	b.ne	0x102698dec <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1914>
102698de4: 91002360    	add	x0, x27, #0x8
102698de8: 94010b56    	bl	0x1026dbb40 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102698dec: aa1403e0    	mov	x0, x20
102698df0: 941c6531    	bl	0x102db22b4 <dyld_stub_binder+0x102db22b4>
102698df4: 941c6037    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698df8: f940ebe8    	ldr	x8, [sp, #0x1d0]
102698dfc: b40000e8    	cbz	x8, 0x102698e18 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1940>
102698e00: f9400109    	ldr	x9, [x8]
102698e04: f1000529    	subs	x9, x9, #0x1
102698e08: f9000109    	str	x9, [x8]
102698e0c: 54000061    	b.ne	0x102698e18 <__RINvMs0_NtNtCs1qJAwyMG1lC_11mech_engine8resident6budgetNtB6_23NativeLibraryWorkBudget16with_call_limitsINtNtCsgDHHaSskbIF_4core6result6ResultTNtNtNtCskIfnrfrMWVM_9mech_core8snapshot10validation5ValuebENtNtNtNtB8_7general23native_collection_calls10invocation31NativeCollectionInvocationErrorENCNvMNtNtB3h_8prepared12word_updatesNtB4M_25NativePreparedLibraryCall23unsigned_matrix_replace0EBa_+0x1940>
102698e10: 91002360    	add	x0, x27, #0x8
102698e14: 94010b4b    	bl	0x1026dbb40 <__RNvMs6_NtCsgKscDXrlV49_5alloc2rcINtB5_2RcINtNtCsgDHHaSskbIF_4core4cell7RefCellNtNtNtCs1qJAwyMG1lC_11mech_engine8resident6budget18ControlWorkAccountEE9drop_slowB1k_>
102698e18: 941c602e    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
102698e1c: 941c602d    	bl	0x102db0ed0 <__RNvNtCsgDHHaSskbIF_4core9panicking16panic_in_cleanup>
