use mech_engine::CanonicalSourceFrontend;
use mech_syntax::document::{AstNode,DocumentId,DocumentSyntax,ParseConfig,Revision,TextSnapshot,parse_canonical_document};
fn run(){
 let args=std::env::args().collect::<Vec<_>>();
 let source=std::fs::read_to_string(&args[1]).unwrap();
 let parsed=parse_canonical_document(TextSnapshot::new(DocumentId(0x53544154),Revision(1),source.as_str()).unwrap(),ParseConfig::default());
 assert!(parsed.is_strictly_clean(),"{:?}",parsed.diagnostics);
 let product=CanonicalSourceFrontend.compile_document_with_catalog(&DocumentSyntax::cast(parsed.syntax()).unwrap(),mech_stdlib::source_catalog()).unwrap();
 let artifact=product.compile_artifact().unwrap();
 let bytes=mech_engine::encode_program_artifact_bytecode_v1(&artifact).unwrap();
 std::fs::write(&args[2],&bytes).unwrap();
 println!("{}",serde_json::json!({"source_bytes":source.len(),"artifact_bytes":bytes.len(),"inputs":artifact.inputs().iter().map(|input| &input.name).collect::<Vec<_>>() }));
}
fn main(){std::thread::Builder::new().stack_size(32*1024*1024).spawn(run).unwrap().join().unwrap();}
