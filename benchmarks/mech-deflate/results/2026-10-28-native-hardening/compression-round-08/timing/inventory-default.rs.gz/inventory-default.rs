use mech_core::SchemaBody;
use mech_engine::native_artifact::{NativeScalarKind, NativeControlLoop, lower_native_program_artifact};
use std::collections::BTreeMap;
fn signature(body: &SchemaBody) -> String {
    if let Some(kind) = NativeScalarKind::from_schema_body(body) { return format!("{kind:?}"); }
    match body {
        SchemaBody::Tuple(fields) => format!("({})", fields.iter().map(signature).collect::<Vec<_>>().join(",")),
        SchemaBody::Enum { variants, .. } => format!("Enum[{}]", variants.iter().map(|variant| variant.payload.as_ref().map(signature).unwrap_or("Unit".to_owned())).collect::<Vec<_>>().join("|")),
        SchemaBody::Matrix { .. } => "Matrix".to_owned(),
        SchemaBody::Record(_) => "Record".to_owned(),
        _ => "Other".to_owned(),
    }
}
fn run() {
    let path = std::env::args().nth(1).unwrap();
    let bytes = std::fs::read(&path).unwrap();
    let artifact = mech_engine::decode_program_artifact_bytecode_v1(&bytes).unwrap();
    let plan = lower_native_program_artifact(&artifact, &mech_stdlib::source_catalog()).unwrap();
    let aggregates = plan.scalar_aggregates();
    let mut selected = BTreeMap::<String, usize>::new();
    for (index, ty) in plan.values().iter().enumerate() {
        if aggregates.slot_at(index).is_some() {
            *selected.entry(signature(ty.definition().body())).or_default() += 1;
        }
    }
    let mut tail = BTreeMap::<String, [usize; 2]>::new();
    for control in plan.iterations() {
        if let NativeControlLoop::Tail(t) = control {
            let schema = plan.values()[t.carrier().get() as usize].definition().body();
            let selected = usize::from(aggregates.slot(t.carrier()).is_some());
            let key = signature(schema);
            // Only finite scalar/enum signatures are useful here, not buffers.
            if !key.contains("Matrix") && !key.contains("Record") {
                tail.entry(key).or_default()[selected] += 1;
            }
        }
    }
    println!("{}", serde_json::json!({"artifact_bytes":bytes.len(),"aggregate_values":aggregates.value_count(),"aggregate_words":aggregates.words(),"selected_by_body":selected,"tail_by_body_canonical_then_native":tail,"dynamic_execution_claim":false}));
}
fn main() {
    std::thread::Builder::new().stack_size(32 * 1024 * 1024).spawn(run).unwrap().join().unwrap();
}
