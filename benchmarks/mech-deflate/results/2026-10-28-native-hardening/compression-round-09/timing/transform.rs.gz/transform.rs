#[path = "/private/tmp/mech-deflate-linear-stack/benchmarks/mech-deflate/source-variants/independent_tables.rs"]
mod independent_tables;
fn main(){let args=std::env::args().collect::<Vec<_>>();let pinned=std::fs::read_to_string(&args[1]).unwrap();let variant=independent_tables::source(&pinned);std::fs::write(&args[2],variant).unwrap();}
