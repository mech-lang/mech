
/private/tmp/roc-deflate-repro-20261024/results/reymont/cbench:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100021d04 <_deflate_compress_near_optimal>:
100021d04: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100021d08: a90167fa    	stp	x26, x25, [sp, #0x10]
100021d0c: a9025ff8    	stp	x24, x23, [sp, #0x20]
100021d10: a90357f6    	stp	x22, x21, [sp, #0x30]
100021d14: a9044ff4    	stp	x20, x19, [sp, #0x40]
100021d18: a9057bfd    	stp	x29, x30, [sp, #0x50]
100021d1c: 910143fd    	add	x29, sp, #0x50
100021d20: d106c3ff    	sub	sp, sp, #0x1b0
100021d24: f9001be3    	str	x3, [sp, #0x30]
100021d28: aa0103fc    	mov	x28, x1
100021d2c: aa0003f5    	mov	x21, x0
100021d30: f00032c8    	adrp	x8, 0x10067c000 <_task_info+0x10067c000>
100021d34: f9401908    	ldr	x8, [x8, #0x30]
100021d38: f9400108    	ldr	x8, [x8]
100021d3c: f81983a8    	stur	x8, [x29, #-0x68]
100021d40: 91625c08    	add	x8, x0, #0x897, lsl #12 ; =0x897000
100021d44: 91268109    	add	x9, x8, #0x9a0
100021d48: 91625c08    	add	x8, x0, #0x897, lsl #12 ; =0x897000
100021d4c: 91373108    	add	x8, x8, #0xdcc
100021d50: a900a7e8    	stp	x8, x9, [sp, #0x8]
100021d54: 9114a016    	add	x22, x0, #0x528
100021d58: 8b020039    	add	x25, x1, x2
100021d5c: 52900008    	mov	w8, #0x8000             ; =32768
100021d60: f140205f    	cmp	x2, #0x8, lsl #12       ; =0x8000
100021d64: 9a883053    	csel	x19, x2, x8, lo
100021d68: b9402414    	ldr	w20, [x0, #0x24]
100021d6c: 5282f808    	mov	w8, #0x17c0             ; =6080
100021d70: 8b080017    	add	x23, x0, x8
100021d74: 39023fff    	strb	wzr, [sp, #0x8f]
100021d78: f00032a1    	adrp	x1, 0x100678000 <_corpus_input+0x651f00>
100021d7c: 910e0021    	add	x1, x1, #0x380
100021d80: aa1703e0    	mov	x0, x23
100021d84: 52a000c2    	mov	w2, #0x60000            ; =393216
100021d88: 94000cd9    	bl	0x1000250ec <_task_info+0x1000250ec>
100021d8c: 8b130388    	add	x8, x28, x19
100021d90: f9003fe8    	str	x8, [sp, #0x78]
100021d94: 5280205b    	mov	w27, #0x102             ; =258
100021d98: f902bebf    	str	xzr, [x21, #0x578]
100021d9c: 6f00e400    	movi.2d	v0, #0000000000000000
100021da0: ad0182c0    	stp	q0, q0, [x22, #0x30]
100021da4: 71040a9f    	cmp	w20, #0x102
100021da8: 1a9b3298    	csel	w24, w20, w27, lo
100021dac: ad0082c0    	stp	q0, q0, [x22, #0x10]
100021db0: 3d8002c0    	str	q0, [x22]
100021db4: 91625ea8    	add	x8, x21, #0x897, lsl #12 ; =0x897000
100021db8: 91273100    	add	x0, x8, #0x9cc
100021dbc: a90383f6    	stp	x22, x0, [sp, #0x38]
100021dc0: 52808181    	mov	w1, #0x40c              ; =1036
100021dc4: 94000ca3    	bl	0x100025050 <_task_info+0x100025050>
100021dc8: 97ff99b5    	bl	0x10000849c <_OUTLINED_FUNCTION_12>
100021dcc: aa1903e7    	mov	x7, x25
100021dd0: 5280001a    	mov	w26, #0x0               ; =0
100021dd4: 52800019    	mov	w25, #0x0               ; =0
100021dd8: d10012a8    	sub	x8, x21, #0x4
100021ddc: f90027e8    	str	x8, [sp, #0x48]
100021de0: 914106a8    	add	x8, x21, #0x41, lsl #12 ; =0x41000
100021de4: 911f0102    	add	x2, x8, #0x7c0
100021de8: 914186a8    	add	x8, x21, #0x61, lsl #12 ; =0x61000
100021dec: 911f0116    	add	x22, x8, #0x7c0
100021df0: 911542a8    	add	x8, x21, #0x550
100021df4: f90003e8    	str	x8, [sp]
100021df8: 91625ea8    	add	x8, x21, #0x897, lsl #12 ; =0x897000
100021dfc: 9137a108    	add	x8, x8, #0xde8
100021e00: f90017e8    	str	x8, [sp, #0x28]
100021e04: 4f04a402    	movi.8h	v2, #0x80, lsl #8
100021e08: 5282f814    	mov	w20, #0x17c0            ; =6080
100021e0c: 72a00114    	movk	w20, #0x8, lsl #16
100021e10: aa1c03eb    	mov	x11, x28
100021e14: f9000ffc    	str	x28, [sp, #0x18]
100021e18: f9003bfc    	str	x28, [sp, #0x70]
100021e1c: f9002fe7    	str	x7, [sp, #0x58]
100021e20: f90043e2    	str	x2, [sp, #0x80]
100021e24: 97ff99fb    	bl	0x100008610 <_OUTLINED_FUNCTION_25>
100021e28: 8b080168    	add	x8, x11, x8
100021e2c: cb0b00e9    	sub	x9, x7, x11
100021e30: 5294ed0a    	mov	w10, #0xa768            ; =42856
100021e34: 72a0008a    	movk	w10, #0x4, lsl #16
100021e38: eb0a013f    	cmp	x9, x10
100021e3c: 9a8830e9    	csel	x9, x7, x8, lo
100021e40: 39423fe8    	ldrb	w8, [sp, #0x8f]
100021e44: a90627eb    	stp	x11, x9, [sp, #0x60]
100021e48: 36000108    	tbz	w8, #0x0, 0x100021e68 <_deflate_compress_near_optimal+0x164>
100021e4c: 52802068    	mov	w8, #0x103              ; =259
100021e50: b90057e8    	str	w8, [sp, #0x54]
100021e54: f9401fe0    	ldr	x0, [sp, #0x38]
100021e58: 5294f7be    	mov	w30, #0xa7bd            ; =42941
100021e5c: 72a3c6be    	movk	w30, #0x1e35, lsl #16
100021e60: 52900011    	mov	w17, #0x8000            ; =32768
100021e64: 1400002e    	b	0x100021f1c <_deflate_compress_near_optimal+0x218>
100021e68: cb0b0133    	sub	x19, x9, x11
100021e6c: b94022a8    	ldr	w8, [x21, #0x20]
100021e70: b90023e8    	str	w8, [sp, #0x20]
100021e74: 910243e0    	add	x0, sp, #0x90
100021e78: 97ff99a6    	bl	0x100008510 <_OUTLINED_FUNCTION_15>
100021e7c: f108027f    	cmp	x19, #0x200
100021e80: 54000142    	b.hs	0x100021ea8 <_deflate_compress_near_optimal+0x1a4>
100021e84: 52800068    	mov	w8, #0x3                ; =3
100021e88: b90057e8    	str	w8, [sp, #0x54]
100021e8c: f9401fe0    	ldr	x0, [sp, #0x38]
100021e90: 5294f7be    	mov	w30, #0xa7bd            ; =42941
100021e94: 72a3c6be    	movk	w30, #0x1e35, lsl #16
100021e98: f9402fe7    	ldr	x7, [sp, #0x58]
100021e9c: 52900011    	mov	w17, #0x8000            ; =32768
100021ea0: f94043e2    	ldr	x2, [sp, #0x80]
100021ea4: 1400001d    	b	0x100021f18 <_deflate_compress_near_optimal+0x214>
100021ea8: f140067f    	cmp	x19, #0x1, lsl #12      ; =0x1000
100021eac: 52820008    	mov	w8, #0x1000             ; =4096
100021eb0: 9a883268    	csel	x8, x19, x8, lo
100021eb4: f94033e9    	ldr	x9, [sp, #0x60]
100021eb8: 910243eb    	add	x11, sp, #0x90
100021ebc: 5280002c    	mov	w12, #0x1               ; =1
100021ec0: 97ff99a3    	bl	0x10000854c <_OUTLINED_FUNCTION_18>
100021ec4: 54ffffe1    	b.ne	0x100021ec0 <_deflate_compress_near_optimal+0x1bc>
100021ec8: ad4487e0    	ldp	q0, q1, [sp, #0x90]
100021ecc: ad458fe2    	ldp	q2, q3, [sp, #0xb0]
100021ed0: ad4697e4    	ldp	q4, q5, [sp, #0xd0]
100021ed4: ad479fe6    	ldp	q6, q7, [sp, #0xf0]
100021ed8: 97ff98db    	bl	0x100008244 <_OUTLINED_FUNCTION_2>
100021edc: ad444567    	ldp	q7, q17, [x11, #0x80]
100021ee0: ad454d72    	ldp	q18, q19, [x11, #0xa0]
100021ee4: 97ff98bf    	bl	0x1000081e0 <_OUTLINED_FUNCTION_1>
100021ee8: ad465d73    	ldp	q19, q23, [x11, #0xc0]
100021eec: ad476d7a    	ldp	q26, q27, [x11, #0xe0]
100021ef0: 97ff9891    	bl	0x100008134 <_OUTLINED_FUNCTION_0>
100021ef4: f9401fe0    	ldr	x0, [sp, #0x38]
100021ef8: 5294f7be    	mov	w30, #0xa7bd            ; =42941
100021efc: 72a3c6be    	movk	w30, #0x1e35, lsl #16
100021f00: f9402fe7    	ldr	x7, [sp, #0x58]
100021f04: 52900011    	mov	w17, #0x8000            ; =32768
100021f08: f94043e2    	ldr	x2, [sp, #0x80]
100021f0c: 540045a9    	b.ls	0x1000227c0 <_deflate_compress_near_optimal+0xabc>
100021f10: 52800068    	mov	w8, #0x3                ; =3
100021f14: b90057e8    	str	w8, [sp, #0x54]
100021f18: 4f04a402    	movi.8h	v2, #0x80, lsl #8
100021f1c: f90013ff    	str	xzr, [sp, #0x20]
100021f20: f9403bf3    	ldr	x19, [sp, #0x70]
100021f24: cb1300e8    	sub	x8, x7, x19
100021f28: f9403fe1    	ldr	x1, [sp, #0x78]
100021f2c: eb01027f    	cmp	x19, x1
100021f30: 54000241    	b.ne	0x100021f78 <_deflate_compress_near_optimal+0x274>
100021f34: d2800009    	mov	x9, #0x0                ; =0
100021f38: 8b0902ea    	add	x10, x23, x9
100021f3c: ad400540    	ldp	q0, q1, [x10]
100021f40: 4e620c00    	sqadd.8h	v0, v0, v2
100021f44: 4e620c21    	sqadd.8h	v1, v1, v2
100021f48: ad000540    	stp	q0, q1, [x10]
100021f4c: ad410540    	ldp	q0, q1, [x10, #0x20]
100021f50: 4e620c00    	sqadd.8h	v0, v0, v2
100021f54: 4e620c21    	sqadd.8h	v1, v1, v2
100021f58: ad010540    	stp	q0, q1, [x10, #0x20]
100021f5c: 91010129    	add	x9, x9, #0x40
100021f60: f142013f    	cmp	x9, #0x80, lsl #12      ; =0x80000
100021f64: 54fffea1    	b.ne	0x100021f38 <_deflate_compress_near_optimal+0x234>
100021f68: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
100021f6c: 9a913109    	csel	x9, x8, x17, lo
100021f70: 8b090261    	add	x1, x19, x9
100021f74: aa1303fc    	mov	x28, x19
100021f78: 6b08031f    	cmp	w24, w8
100021f7c: 1a883309    	csel	w9, w24, w8, lo
100021f80: f104051f    	cmp	x8, #0x101
100021f84: 1a88837b    	csel	w27, w27, w8, hi
100021f88: 1a898318    	csel	w24, w24, w9, hi
100021f8c: 7100177f    	cmp	w27, #0x5
100021f90: 54003923    	b.lo	0x1000226b4 <_deflate_compress_near_optimal+0x9b0>
100021f94: cb1c026b    	sub	x11, x19, x28
100021f98: b94022ac    	ldr	w12, [x21, #0x20]
100021f9c: 5140216d    	sub	w13, w11, #0x8, lsl #12 ; =0x8000
100021fa0: b8401268    	ldur	w8, [x19, #0x1]
100021fa4: 12005d09    	and	w9, w8, #0xffffff
100021fa8: 1b1e7d29    	mul	w9, w9, w30
100021fac: 53107d29    	lsr	w9, w9, #16
100021fb0: 1b1e7d08    	mul	w8, w8, w30
100021fb4: 53107d0a    	lsr	w10, w8, #16
100021fb8: 8b294ae8    	add	x8, x23, w9, uxtw #2
100021fbc: f9800110    	prfm	pstl1keep, [x8]
100021fc0: 8b2a4448    	add	x8, x2, w10, uxtw #1
100021fc4: f9800110    	prfm	pstl1keep, [x8]
100021fc8: 8b394ae8    	add	x8, x23, w25, uxtw #2
100021fcc: 79c0010f    	ldrsh	w15, [x8]
100021fd0: 7900010b    	strh	w11, [x8]
100021fd4: 79c0050e    	ldrsh	w14, [x8, #0x2]
100021fd8: 7900050f    	strh	w15, [x8, #0x2]
100021fdc: aa1403e8    	mov	x8, x20
100021fe0: 6b0f01bf    	cmp	w13, w15
100021fe4: 5400032a    	b.ge	0x100022048 <_deflate_compress_near_optimal+0x344>
100021fe8: b9400268    	ldr	w8, [x19]
100021fec: 12005d10    	and	w16, w8, #0xffffff
100021ff0: b86fcb88    	ldr	w8, [x28, w15, sxtw]
100021ff4: 12005d08    	and	w8, w8, #0xffffff
100021ff8: 6b08021f    	cmp	w16, w8
100021ffc: 54000121    	b.ne	0x100022020 <_deflate_compress_near_optimal+0x31c>
100022000: 12003de8    	and	w8, w15, #0xffff
100022004: 8b1402ae    	add	x14, x21, x20
100022008: 5280006f    	mov	w15, #0x3               ; =3
10002200c: 790001cf    	strh	w15, [x14]
100022010: 4b080168    	sub	w8, w11, w8
100022014: 790005c8    	strh	w8, [x14, #0x2]
100022018: 91001288    	add	x8, x20, #0x4
10002201c: 1400000b    	b	0x100022048 <_deflate_compress_near_optimal+0x344>
100022020: aa1403e8    	mov	x8, x20
100022024: 6b0e01bf    	cmp	w13, w14
100022028: 5400010a    	b.ge	0x100022048 <_deflate_compress_near_optimal+0x344>
10002202c: b86ecb88    	ldr	w8, [x28, w14, sxtw]
100022030: 12005d0f    	and	w15, w8, #0xffffff
100022034: aa1403e8    	mov	x8, x20
100022038: 6b0f021f    	cmp	w16, w15
10002203c: 54000061    	b.ne	0x100022048 <_deflate_compress_near_optimal+0x344>
100022040: 12003dc8    	and	w8, w14, #0xffff
100022044: 17fffff0    	b	0x100022004 <_deflate_compress_near_optimal+0x300>
100022048: 78fa5843    	ldrsh	w3, [x2, w26, uxtw #1]
10002204c: 783a584b    	strh	w11, [x2, w26, uxtw #1]
100022050: 531f396e    	ubfiz	w14, w11, #1, #15
100022054: 8b2e46cf    	add	x15, x22, w14, uxtw #1
100022058: 5280002e    	mov	w14, #0x1               ; =1
10002205c: 331f396e    	bfi	w14, w11, #1, #15
100022060: 8b2e46ce    	add	x14, x22, w14, uxtw #1
100022064: 6b0301bf    	cmp	w13, w3
100022068: 54000c8a    	b.ge	0x1000221f8 <_deflate_compress_near_optimal+0x4f4>
10002206c: aa0103f9    	mov	x25, x1
100022070: 52800007    	mov	w7, #0x0                ; =0
100022074: 52800010    	mov	w16, #0x0               ; =0
100022078: 52800001    	mov	w1, #0x0                ; =0
10002207c: 52800071    	mov	w17, #0x3               ; =3
100022080: 93407c62    	sxtw	x2, w3
100022084: 8b23c383    	add	x3, x28, w3, sxtw
100022088: 38614864    	ldrb	w4, [x3, w1, uxtw]
10002208c: 38614a65    	ldrb	w5, [x19, w1, uxtw]
100022090: 6b05009f    	cmp	w4, w5
100022094: 54000661    	b.ne	0x100022160 <_deflate_compress_near_optimal+0x45c>
100022098: 11000424    	add	w4, w1, #0x1
10002209c: 4b040365    	sub	w5, w27, w4
1000220a0: 710080bf    	cmp	w5, #0x20
1000220a4: 540002a3    	b.lo	0x1000220f8 <_deflate_compress_near_optimal+0x3f4>
1000220a8: f8644865    	ldr	x5, [x3, w4, uxtw]
1000220ac: f8644a66    	ldr	x6, [x19, w4, uxtw]
1000220b0: eb0600bf    	cmp	x5, x6
1000220b4: 540003a1    	b.ne	0x100022128 <_deflate_compress_near_optimal+0x424>
1000220b8: 11002424    	add	w4, w1, #0x9
1000220bc: f8644865    	ldr	x5, [x3, w4, uxtw]
1000220c0: f8644a66    	ldr	x6, [x19, w4, uxtw]
1000220c4: eb0600bf    	cmp	x5, x6
1000220c8: 54000301    	b.ne	0x100022128 <_deflate_compress_near_optimal+0x424>
1000220cc: 11004424    	add	w4, w1, #0x11
1000220d0: f8644865    	ldr	x5, [x3, w4, uxtw]
1000220d4: f8644a66    	ldr	x6, [x19, w4, uxtw]
1000220d8: eb0600bf    	cmp	x5, x6
1000220dc: 54000261    	b.ne	0x100022128 <_deflate_compress_near_optimal+0x424>
1000220e0: 11006424    	add	w4, w1, #0x19
1000220e4: f8644865    	ldr	x5, [x3, w4, uxtw]
1000220e8: f8644a66    	ldr	x6, [x19, w4, uxtw]
1000220ec: eb0600bf    	cmp	x5, x6
1000220f0: 540001c1    	b.ne	0x100022128 <_deflate_compress_near_optimal+0x424>
1000220f4: 11008424    	add	w4, w1, #0x21
1000220f8: aa0403e1    	mov	x1, x4
1000220fc: 11002024    	add	w4, w1, #0x8
100022100: 6b1b009f    	cmp	w4, w27
100022104: 54000628    	b.hi	0x1000221c8 <_deflate_compress_near_optimal+0x4c4>
100022108: f8614865    	ldr	x5, [x3, w1, uxtw]
10002210c: f8614a66    	ldr	x6, [x19, w1, uxtw]
100022110: aa0403e1    	mov	x1, x4
100022114: eb0600bf    	cmp	x5, x6
100022118: 54ffff20    	b.eq	0x1000220fc <_deflate_compress_near_optimal+0x3f8>
10002211c: ca0500c1    	eor	x1, x6, x5
100022120: 51002084    	sub	w4, w4, #0x8
100022124: 14000002    	b	0x10002212c <_deflate_compress_near_optimal+0x428>
100022128: ca0500c1    	eor	x1, x6, x5
10002212c: dac00021    	rbit	x1, x1
100022130: dac01021    	clz	x1, x1
100022134: 0b410c81    	add	w1, w4, w1, lsr #3
100022138: 6b11003f    	cmp	w1, w17
10002213c: 54000129    	b.ls	0x100022160 <_deflate_compress_near_optimal+0x45c>
100022140: 8b0802b1    	add	x17, x21, x8
100022144: 79000221    	strh	w1, [x17]
100022148: 4b020164    	sub	w4, w11, w2
10002214c: 79000624    	strh	w4, [x17, #0x2]
100022150: 91001108    	add	x8, x8, #0x4
100022154: 6b18003f    	cmp	w1, w24
100022158: 54000602    	b.hs	0x100022218 <_deflate_compress_near_optimal+0x514>
10002215c: aa0103f1    	mov	x17, x1
100022160: 38614864    	ldrb	w4, [x3, w1, uxtw]
100022164: 38614a65    	ldrb	w5, [x19, w1, uxtw]
100022168: 531f3843    	ubfiz	w3, w2, #1, #15
10002216c: 6b05009f    	cmp	w4, w5
100022170: 54000102    	b.hs	0x100022190 <_deflate_compress_near_optimal+0x48c>
100022174: 790001e2    	strh	w2, [x15]
100022178: 3200006f    	orr	w15, w3, #0x1
10002217c: 8b2f46c2    	add	x2, x22, w15, uxtw #1
100022180: aa0203ef    	mov	x15, x2
100022184: aa0103e7    	mov	x7, x1
100022188: aa1003e4    	mov	x4, x16
10002218c: 14000006    	b	0x1000221a4 <_deflate_compress_near_optimal+0x4a0>
100022190: 790001c2    	strh	w2, [x14]
100022194: 8b2346c2    	add	x2, x22, w3, uxtw #1
100022198: aa0703f0    	mov	x16, x7
10002219c: aa0203ee    	mov	x14, x2
1000221a0: aa0103e4    	mov	x4, x1
1000221a4: 6b01021f    	cmp	w16, w1
1000221a8: 1a813201    	csel	w1, w16, w1, lo
1000221ac: 79c00043    	ldrsh	w3, [x2]
1000221b0: 5100058c    	sub	w12, w12, #0x1
1000221b4: 6b0301bf    	cmp	w13, w3
1000221b8: 7a40b984    	ccmp	w12, #0x0, #0x4, lt
1000221bc: aa0403f0    	mov	x16, x4
1000221c0: 54fff601    	b.ne	0x100022080 <_deflate_compress_near_optimal+0x37c>
1000221c4: 14000010    	b	0x100022204 <_deflate_compress_near_optimal+0x500>
1000221c8: 6b1b003f    	cmp	w1, w27
1000221cc: 54fffb62    	b.hs	0x100022138 <_deflate_compress_near_optimal+0x434>
1000221d0: 2a0103e1    	mov	w1, w1
1000221d4: 38616864    	ldrb	w4, [x3, x1]
1000221d8: 38616a65    	ldrb	w5, [x19, x1]
1000221dc: 6b05009f    	cmp	w4, w5
1000221e0: 54fffac1    	b.ne	0x100022138 <_deflate_compress_near_optimal+0x434>
1000221e4: 91000421    	add	x1, x1, #0x1
1000221e8: eb1b003f    	cmp	x1, x27
1000221ec: 54ffff43    	b.lo	0x1000221d4 <_deflate_compress_near_optimal+0x4d0>
1000221f0: aa1b03e1    	mov	x1, x27
1000221f4: 17ffffd1    	b	0x100022138 <_deflate_compress_near_optimal+0x434>
1000221f8: 790001f1    	strh	w17, [x15]
1000221fc: 790001d1    	strh	w17, [x14]
100022200: 14000011    	b	0x100022244 <_deflate_compress_near_optimal+0x540>
100022204: 52900011    	mov	w17, #0x8000            ; =32768
100022208: 790001f1    	strh	w17, [x15]
10002220c: 790001d1    	strh	w17, [x14]
100022210: f9402fe7    	ldr	x7, [sp, #0x58]
100022214: 1400000a    	b	0x10002223c <_deflate_compress_near_optimal+0x538>
100022218: 531f384b    	ubfiz	w11, w2, #1, #15
10002221c: 786b5acb    	ldrh	w11, [x22, w11, uxtw #1]
100022220: 790001eb    	strh	w11, [x15]
100022224: 5280002b    	mov	w11, #0x1               ; =1
100022228: 331f384b    	bfi	w11, w2, #1, #15
10002222c: 786b5acb    	ldrh	w11, [x22, w11, uxtw #1]
100022230: 790001cb    	strh	w11, [x14]
100022234: f9402fe7    	ldr	x7, [sp, #0x58]
100022238: 52900011    	mov	w17, #0x8000            ; =32768
10002223c: f94043e2    	ldr	x2, [sp, #0x80]
100022240: aa1903e1    	mov	x1, x25
100022244: eb14011f    	cmp	x8, x20
100022248: 5400008d    	b.le	0x100022258 <_deflate_compress_near_optimal+0x554>
10002224c: f94027eb    	ldr	x11, [sp, #0x48]
100022250: 7868696b    	ldrh	w11, [x11, x8]
100022254: 14000002    	b	0x10002225c <_deflate_compress_near_optimal+0x558>
100022258: 5280000b    	mov	w11, #0x0               ; =0
10002225c: aa0a03fa    	mov	x26, x10
100022260: aa0903f9    	mov	x25, x9
100022264: f9403be9    	ldr	x9, [sp, #0x70]
100022268: eb09027f    	cmp	x19, x9
10002226c: 54000423    	b.lo	0x1000222f0 <_deflate_compress_near_optimal+0x5ec>
100022270: b94057e9    	ldr	w9, [sp, #0x54]
100022274: 6b09017f    	cmp	w11, w9
100022278: 540001c2    	b.hs	0x1000222b0 <_deflate_compress_near_optimal+0x5ac>
10002227c: aa1303ea    	mov	x10, x19
100022280: 38401549    	ldrb	w9, [x10], #0x1
100022284: f9003bea    	str	x10, [sp, #0x70]
100022288: 53061d2a    	ubfx	w10, w9, #6, #2
10002228c: 12000129    	and	w9, w9, #0x1
100022290: 2a0a0529    	orr	w9, w9, w10, lsl #1
100022294: b869580a    	ldr	w10, [x0, w9, uxtw #2]
100022298: 1100054a    	add	w10, w10, #0x1
10002229c: b829580a    	str	w10, [x0, w9, uxtw #2]
1000222a0: b9457aa9    	ldr	w9, [x21, #0x578]
1000222a4: 11000529    	add	w9, w9, #0x1
1000222a8: b9057aa9    	str	w9, [x21, #0x578]
1000222ac: 14000011    	b	0x1000222f0 <_deflate_compress_near_optimal+0x5ec>
1000222b0: 7100217f    	cmp	w11, #0x8
1000222b4: 52800409    	mov	w9, #0x20               ; =32
1000222b8: 5280048a    	mov	w10, #0x24              ; =36
1000222bc: 9a898149    	csel	x9, x10, x9, hi
1000222c0: b869680a    	ldr	w10, [x0, x9]
1000222c4: 1100054a    	add	w10, w10, #0x1
1000222c8: b829680a    	str	w10, [x0, x9]
1000222cc: b9457aa9    	ldr	w9, [x21, #0x578]
1000222d0: 11000529    	add	w9, w9, #0x1
1000222d4: b9057aa9    	str	w9, [x21, #0x578]
1000222d8: 8b2b4269    	add	x9, x19, w11, uxtw
1000222dc: f9003be9    	str	x9, [sp, #0x70]
1000222e0: f94023ea    	ldr	x10, [sp, #0x40]
1000222e4: b86b5949    	ldr	w9, [x10, w11, uxtw #2]
1000222e8: 11000529    	add	w9, w9, #0x1
1000222ec: b82b5949    	str	w9, [x10, w11, uxtw #2]
1000222f0: 8b0802a9    	add	x9, x21, x8
1000222f4: 4b14010a    	sub	w10, w8, w20
1000222f8: 53027d4a    	lsr	w10, w10, #2
1000222fc: 7900012a    	strh	w10, [x9]
100022300: aa1303ea    	mov	x10, x19
100022304: 3840154c    	ldrb	w12, [x10], #0x1
100022308: 7900052c    	strh	w12, [x9, #0x2]
10002230c: 91001114    	add	x20, x8, #0x4
100022310: 71000d7f    	cmp	w11, #0x3
100022314: 7a582160    	ccmp	w11, w24, #0x0, hs
100022318: 54000062    	b.hs	0x100022324 <_deflate_compress_near_optimal+0x620>
10002231c: aa0a03f3    	mov	x19, x10
100022320: 140000b3    	b	0x1000225ec <_deflate_compress_near_optimal+0x8e8>
100022324: 51000568    	sub	w8, w11, #0x1
100022328: 91000669    	add	x9, x19, #0x1
10002232c: aa1a03ec    	mov	x12, x26
100022330: aa1903ed    	mov	x13, x25
100022334: aa0a03f3    	mov	x19, x10
100022338: cb1300ea    	sub	x10, x7, x19
10002233c: eb01027f    	cmp	x19, x1
100022340: 54000241    	b.ne	0x100022388 <_deflate_compress_near_optimal+0x684>
100022344: d280000b    	mov	x11, #0x0               ; =0
100022348: 8b0b02ee    	add	x14, x23, x11
10002234c: ad4005c0    	ldp	q0, q1, [x14]
100022350: 4e620c00    	sqadd.8h	v0, v0, v2
100022354: 4e620c21    	sqadd.8h	v1, v1, v2
100022358: ad0005c0    	stp	q0, q1, [x14]
10002235c: ad4105c0    	ldp	q0, q1, [x14, #0x20]
100022360: 4e620c00    	sqadd.8h	v0, v0, v2
100022364: 4e620c21    	sqadd.8h	v1, v1, v2
100022368: ad0105c0    	stp	q0, q1, [x14, #0x20]
10002236c: 9101016b    	add	x11, x11, #0x40
100022370: f142017f    	cmp	x11, #0x80, lsl #12     ; =0x80000
100022374: 54fffea1    	b.ne	0x100022348 <_deflate_compress_near_optimal+0x644>
100022378: f140215f    	cmp	x10, #0x8, lsl #12      ; =0x8000
10002237c: 9a91314b    	csel	x11, x10, x17, lo
100022380: 8b0b0261    	add	x1, x19, x11
100022384: aa1303fc    	mov	x28, x19
100022388: 6b0a031f    	cmp	w24, w10
10002238c: 1a8a330b    	csel	w11, w24, w10, lo
100022390: f104055f    	cmp	x10, #0x101
100022394: 1a8a837b    	csel	w27, w27, w10, hi
100022398: 1a8b8318    	csel	w24, w24, w11, hi
10002239c: 7100177f    	cmp	w27, #0x5
1000223a0: 54000ec3    	b.lo	0x100022578 <_deflate_compress_near_optimal+0x874>
1000223a4: 4b1c026f    	sub	w15, w19, w28
1000223a8: b94022aa    	ldr	w10, [x21, #0x20]
1000223ac: 514021eb    	sub	w11, w15, #0x8, lsl #12 ; =0x8000
1000223b0: b840126e    	ldur	w14, [x19, #0x1]
1000223b4: 12005dd0    	and	w16, w14, #0xffffff
1000223b8: 1b1e7e10    	mul	w16, w16, w30
1000223bc: 53107e19    	lsr	w25, w16, #16
1000223c0: 1b1e7dce    	mul	w14, w14, w30
1000223c4: 53107dda    	lsr	w26, w14, #16
1000223c8: 8b394aee    	add	x14, x23, w25, uxtw #2
1000223cc: f98001d0    	prfm	pstl1keep, [x14]
1000223d0: 8b3a444e    	add	x14, x2, w26, uxtw #1
1000223d4: f98001d0    	prfm	pstl1keep, [x14]
1000223d8: 8b2d4aed    	add	x13, x23, w13, uxtw #2
1000223dc: 794001ae    	ldrh	w14, [x13]
1000223e0: 790001af    	strh	w15, [x13]
1000223e4: 790005ae    	strh	w14, [x13, #0x2]
1000223e8: 78ec584e    	ldrsh	w14, [x2, w12, uxtw #1]
1000223ec: 782c584f    	strh	w15, [x2, w12, uxtw #1]
1000223f0: 531f39ec    	ubfiz	w12, w15, #1, #15
1000223f4: 8b2c46cd    	add	x13, x22, w12, uxtw #1
1000223f8: 5280002c    	mov	w12, #0x1               ; =1
1000223fc: 331f39ec    	bfi	w12, w15, #1, #15
100022400: 8b2c46cc    	add	x12, x22, w12, uxtw #1
100022404: 6b0e017f    	cmp	w11, w14
100022408: 54000bea    	b.ge	0x100022584 <_deflate_compress_near_optimal+0x880>
10002240c: aa0103e6    	mov	x6, x1
100022410: 52800005    	mov	w5, #0x0                ; =0
100022414: 5280000f    	mov	w15, #0x0               ; =0
100022418: 52800011    	mov	w17, #0x0               ; =0
10002241c: 8b2ec381    	add	x1, x28, w14, sxtw
100022420: 38714822    	ldrb	w2, [x1, w17, uxtw]
100022424: 38714a63    	ldrb	w3, [x19, w17, uxtw]
100022428: 531f39d0    	ubfiz	w16, w14, #1, #15
10002242c: 6b03005f    	cmp	w2, w3
100022430: 540005a1    	b.ne	0x1000224e4 <_deflate_compress_near_optimal+0x7e0>
100022434: 11000622    	add	w2, w17, #0x1
100022438: 4b020303    	sub	w3, w24, w2
10002243c: 7100807f    	cmp	w3, #0x20
100022440: 540002a3    	b.lo	0x100022494 <_deflate_compress_near_optimal+0x790>
100022444: f8624823    	ldr	x3, [x1, w2, uxtw]
100022448: f8624a64    	ldr	x4, [x19, w2, uxtw]
10002244c: eb04007f    	cmp	x3, x4
100022450: 540003a1    	b.ne	0x1000224c4 <_deflate_compress_near_optimal+0x7c0>
100022454: 11002622    	add	w2, w17, #0x9
100022458: f8624823    	ldr	x3, [x1, w2, uxtw]
10002245c: f8624a64    	ldr	x4, [x19, w2, uxtw]
100022460: eb04007f    	cmp	x3, x4
100022464: 54000301    	b.ne	0x1000224c4 <_deflate_compress_near_optimal+0x7c0>
100022468: 11004622    	add	w2, w17, #0x11
10002246c: f8624823    	ldr	x3, [x1, w2, uxtw]
100022470: f8624a64    	ldr	x4, [x19, w2, uxtw]
100022474: eb04007f    	cmp	x3, x4
100022478: 54000261    	b.ne	0x1000224c4 <_deflate_compress_near_optimal+0x7c0>
10002247c: 11006622    	add	w2, w17, #0x19
100022480: f8624823    	ldr	x3, [x1, w2, uxtw]
100022484: f8624a64    	ldr	x4, [x19, w2, uxtw]
100022488: eb04007f    	cmp	x3, x4
10002248c: 540001c1    	b.ne	0x1000224c4 <_deflate_compress_near_optimal+0x7c0>
100022490: 11008622    	add	w2, w17, #0x21
100022494: aa0203f1    	mov	x17, x2
100022498: 11002222    	add	w2, w17, #0x8
10002249c: 6b18005f    	cmp	w2, w24
1000224a0: 54000508    	b.hi	0x100022540 <_deflate_compress_near_optimal+0x83c>
1000224a4: f8714823    	ldr	x3, [x1, w17, uxtw]
1000224a8: f8714a64    	ldr	x4, [x19, w17, uxtw]
1000224ac: aa0203f1    	mov	x17, x2
1000224b0: eb04007f    	cmp	x3, x4
1000224b4: 54ffff20    	b.eq	0x100022498 <_deflate_compress_near_optimal+0x794>
1000224b8: ca030091    	eor	x17, x4, x3
1000224bc: 51002042    	sub	w2, w2, #0x8
1000224c0: 14000002    	b	0x1000224c8 <_deflate_compress_near_optimal+0x7c4>
1000224c4: ca030091    	eor	x17, x4, x3
1000224c8: dac00231    	rbit	x17, x17
1000224cc: dac01231    	clz	x17, x17
1000224d0: 0b510c51    	add	w17, w2, w17, lsr #3
1000224d4: 6b18023f    	cmp	w17, w24
1000224d8: 54000642    	b.hs	0x1000225a0 <_deflate_compress_near_optimal+0x89c>
1000224dc: 38714822    	ldrb	w2, [x1, w17, uxtw]
1000224e0: 38714a63    	ldrb	w3, [x19, w17, uxtw]
1000224e4: 6b03005f    	cmp	w2, w3
1000224e8: 54000102    	b.hs	0x100022508 <_deflate_compress_near_optimal+0x804>
1000224ec: 790001ae    	strh	w14, [x13]
1000224f0: 3200020d    	orr	w13, w16, #0x1
1000224f4: 8b2d46ce    	add	x14, x22, w13, uxtw #1
1000224f8: aa0e03ed    	mov	x13, x14
1000224fc: aa1103e5    	mov	x5, x17
100022500: aa0f03e1    	mov	x1, x15
100022504: 14000006    	b	0x10002251c <_deflate_compress_near_optimal+0x818>
100022508: 7900018e    	strh	w14, [x12]
10002250c: 8b3046ce    	add	x14, x22, w16, uxtw #1
100022510: aa0503ef    	mov	x15, x5
100022514: aa0e03ec    	mov	x12, x14
100022518: aa1103e1    	mov	x1, x17
10002251c: 6b1101ff    	cmp	w15, w17
100022520: 1a9131f1    	csel	w17, w15, w17, lo
100022524: 79c001ce    	ldrsh	w14, [x14]
100022528: 5100054a    	sub	w10, w10, #0x1
10002252c: 6b0e017f    	cmp	w11, w14
100022530: 7a40b944    	ccmp	w10, #0x0, #0x4, lt
100022534: aa0103ef    	mov	x15, x1
100022538: 54fff721    	b.ne	0x10002241c <_deflate_compress_near_optimal+0x718>
10002253c: 14000015    	b	0x100022590 <_deflate_compress_near_optimal+0x88c>
100022540: 6b18023f    	cmp	w17, w24
100022544: 54fffc82    	b.hs	0x1000224d4 <_deflate_compress_near_optimal+0x7d0>
100022548: 2a1103e2    	mov	w2, w17
10002254c: 8b314131    	add	x17, x9, w17, uxtw
100022550: 38626823    	ldrb	w3, [x1, x2]
100022554: 38401624    	ldrb	w4, [x17], #0x1
100022558: 6b04007f    	cmp	w3, w4
10002255c: 540000a1    	b.ne	0x100022570 <_deflate_compress_near_optimal+0x86c>
100022560: 91000442    	add	x2, x2, #0x1
100022564: eb18005f    	cmp	x2, x24
100022568: 54ffff43    	b.lo	0x100022550 <_deflate_compress_near_optimal+0x84c>
10002256c: 1400000d    	b	0x1000225a0 <_deflate_compress_near_optimal+0x89c>
100022570: aa0203f1    	mov	x17, x2
100022574: 17ffffd8    	b	0x1000224d4 <_deflate_compress_near_optimal+0x7d0>
100022578: aa0c03fa    	mov	x26, x12
10002257c: aa0d03f9    	mov	x25, x13
100022580: 14000011    	b	0x1000225c4 <_deflate_compress_near_optimal+0x8c0>
100022584: 790001b1    	strh	w17, [x13]
100022588: 79000191    	strh	w17, [x12]
10002258c: 1400000e    	b	0x1000225c4 <_deflate_compress_near_optimal+0x8c0>
100022590: 52900011    	mov	w17, #0x8000            ; =32768
100022594: 790001b1    	strh	w17, [x13]
100022598: 79000191    	strh	w17, [x12]
10002259c: 14000008    	b	0x1000225bc <_deflate_compress_near_optimal+0x8b8>
1000225a0: 78705aca    	ldrh	w10, [x22, w16, uxtw #1]
1000225a4: 790001aa    	strh	w10, [x13]
1000225a8: 5280002a    	mov	w10, #0x1               ; =1
1000225ac: 331f39ca    	bfi	w10, w14, #1, #15
1000225b0: 786a5aca    	ldrh	w10, [x22, w10, uxtw #1]
1000225b4: 7900018a    	strh	w10, [x12]
1000225b8: 52900011    	mov	w17, #0x8000            ; =32768
1000225bc: f94043e2    	ldr	x2, [sp, #0x80]
1000225c0: aa0603e1    	mov	x1, x6
1000225c4: 8b1402aa    	add	x10, x21, x20
1000225c8: 7900015f    	strh	wzr, [x10]
1000225cc: 3840166b    	ldrb	w11, [x19], #0x1
1000225d0: 91001294    	add	x20, x20, #0x4
1000225d4: 7900054b    	strh	w11, [x10, #0x2]
1000225d8: 91000529    	add	x9, x9, #0x1
1000225dc: aa1a03ec    	mov	x12, x26
1000225e0: aa1903ed    	mov	x13, x25
1000225e4: 71000508    	subs	w8, w8, #0x1
1000225e8: 54ffea81    	b.ne	0x100022338 <_deflate_compress_near_optimal+0x634>
1000225ec: f94037e8    	ldr	x8, [sp, #0x68]
1000225f0: eb08027f    	cmp	x19, x8
1000225f4: 5294a808    	mov	w8, #0xa540             ; =42304
1000225f8: 72a00c68    	movk	w8, #0x63, lsl #16
1000225fc: fa483280    	ccmp	x20, x8, #0x0, lo
100022600: f9003fe1    	str	x1, [sp, #0x78]
100022604: 540005ea    	b.ge	0x1000226c0 <_deflate_compress_near_optimal+0x9bc>
100022608: b9457aa8    	ldr	w8, [x21, #0x578]
10002260c: 7108011f    	cmp	w8, #0x200
100022610: 54ffc8a3    	b.lo	0x100021f24 <_deflate_compress_near_optimal+0x220>
100022614: cb1300e8    	sub	x8, x7, x19
100022618: f94033e9    	ldr	x9, [sp, #0x60]
10002261c: cb090261    	sub	x1, x19, x9
100022620: 52827109    	mov	w9, #0x1388             ; =5000
100022624: eb09003f    	cmp	x1, x9
100022628: fa49a108    	ccmp	x8, x9, #0x8, ge
10002262c: 54ffc7cb    	b.lt	0x100021f24 <_deflate_compress_near_optimal+0x220>
100022630: 97ff84c6    	bl	0x100003948 <_do_end_block_check>
100022634: 37000fc0    	tbnz	w0, #0x0, 0x10002282c <_deflate_compress_near_optimal+0xb28>
100022638: 3dc156a0    	ldr	q0, [x21, #0x550]
10002263c: f9401fe0    	ldr	x0, [sp, #0x38]
100022640: ad400801    	ldp	q1, q2, [x0]
100022644: 4ea18400    	add.4s	v0, v0, v1
100022648: 97ff97ff    	bl	0x100008644 <_OUTLINED_FUNCTION_28>
10002264c: 6f00e404    	movi.2d	v4, #0000000000000000
100022650: 97ff974e    	bl	0x100008388 <_OUTLINED_FUNCTION_6>
100022654: 97ff975b    	bl	0x1000083c0 <_OUTLINED_FUNCTION_7>
100022658: 54ffffe1    	b.ne	0x100022654 <_deflate_compress_near_optimal+0x950>
10002265c: f94007eb    	ldr	x11, [sp, #0x8]
100022660: b9440d68    	ldr	w8, [x11, #0x40c]
100022664: 29402969    	ldp	w9, w10, [x11]
100022668: 0b090108    	add	w8, w8, w9
10002266c: b9040d68    	str	w8, [x11, #0x40c]
100022670: b900017f    	str	wzr, [x11]
100022674: b9441168    	ldr	w8, [x11, #0x410]
100022678: 0b0a0108    	add	w8, w8, w10
10002267c: b9041168    	str	w8, [x11, #0x410]
100022680: b9400968    	ldr	w8, [x11, #0x8]
100022684: f800417f    	stur	xzr, [x11, #0x4]
100022688: b9441569    	ldr	w9, [x11, #0x414]
10002268c: 0b080128    	add	w8, w9, w8
100022690: b9041568    	str	w8, [x11, #0x414]
100022694: f90013f3    	str	x19, [sp, #0x20]
100022698: 5294f7be    	mov	w30, #0xa7bd            ; =42941
10002269c: 72a3c6be    	movk	w30, #0x1e35, lsl #16
1000226a0: f9402fe7    	ldr	x7, [sp, #0x58]
1000226a4: 52900011    	mov	w17, #0x8000            ; =32768
1000226a8: f94043e2    	ldr	x2, [sp, #0x80]
1000226ac: 4f04a402    	movi.8h	v2, #0x80, lsl #8
1000226b0: 17fffe1d    	b	0x100021f24 <_deflate_compress_near_optimal+0x220>
1000226b4: 5280000b    	mov	w11, #0x0               ; =0
1000226b8: aa1403e8    	mov	x8, x20
1000226bc: 17fffeea    	b	0x100022264 <_deflate_compress_near_optimal+0x560>
1000226c0: 8b1402a4    	add	x4, x21, x20
1000226c4: 6f00e404    	movi.2d	v4, #0000000000000000
1000226c8: f94033e2    	ldr	x2, [sp, #0x60]
1000226cc: 3dc156a0    	ldr	q0, [x21, #0x550]
1000226d0: ad400801    	ldp	q1, q2, [x0]
1000226d4: 4ea18400    	add.4s	v0, v0, v1
1000226d8: cb020263    	sub	x3, x19, x2
1000226dc: 97ff97da    	bl	0x100008644 <_OUTLINED_FUNCTION_28>
1000226e0: 97ff972a    	bl	0x100008388 <_OUTLINED_FUNCTION_6>
1000226e4: 97ff9737    	bl	0x1000083c0 <_OUTLINED_FUNCTION_7>
1000226e8: 54ffffe1    	b.ne	0x1000226e4 <_deflate_compress_near_optimal+0x9e0>
1000226ec: a94123f4    	ldp	x20, x8, [sp, #0x10]
1000226f0: eb08005f    	cmp	x2, x8
1000226f4: 1a9f17e5    	cset	w5, eq
1000226f8: b9442e88    	ldr	w8, [x20, #0x42c]
1000226fc: b9483a89    	ldr	w9, [x20, #0x838]
100022700: 0b080128    	add	w8, w9, w8
100022704: b9083a88    	str	w8, [x20, #0x838]
100022708: b9042e9f    	str	wzr, [x20, #0x42c]
10002270c: b9443288    	ldr	w8, [x20, #0x430]
100022710: b9483e89    	ldr	w9, [x20, #0x83c]
100022714: 0b080128    	add	w8, w9, w8
100022718: b9083e88    	str	w8, [x20, #0x83c]
10002271c: b9443688    	ldr	w8, [x20, #0x434]
100022720: f9021a9f    	str	xzr, [x20, #0x430]
100022724: b9484289    	ldr	w9, [x20, #0x840]
100022728: 0b080128    	add	w8, w9, w8
10002272c: b9084288    	str	w8, [x20, #0x840]
100022730: eb07027f    	cmp	x19, x7
100022734: 1a9f17e6    	cset	w6, eq
100022738: 91023fe7    	add	x7, sp, #0x8f
10002273c: aa1503e0    	mov	x0, x21
100022740: f9401be1    	ldr	x1, [sp, #0x30]
100022744: 97ff84e4    	bl	0x100003ad4 <_deflate_optimize_and_flush_block>
100022748: 3dc156a0    	ldr	q0, [x21, #0x550]
10002274c: 3dc15aa1    	ldr	q1, [x21, #0x560]
100022750: ad000680    	stp	q0, q1, [x20]
100022754: fd42baa0    	ldr	d0, [x21, #0x570]
100022758: fd001280    	str	d0, [x20, #0x20]
10002275c: b9457ea8    	ldr	w8, [x21, #0x57c]
100022760: b9002a88    	str	w8, [x20, #0x28]
100022764: a94383e8    	ldp	x8, x0, [sp, #0x38]
100022768: 6f00e400    	movi.2d	v0, #0000000000000000
10002276c: ad000100    	stp	q0, q0, [x8]
100022770: f900291f    	str	xzr, [x8, #0x50]
100022774: ad018100    	stp	q0, q0, [x8, #0x30]
100022778: 3d800900    	str	q0, [x8, #0x20]
10002277c: 52808181    	mov	w1, #0x40c              ; =1036
100022780: 94000a34    	bl	0x100025050 <_task_info+0x100025050>
100022784: 5282f814    	mov	w20, #0x17c0            ; =6080
100022788: 72a00114    	movk	w20, #0x8, lsl #16
10002278c: f90033f3    	str	x19, [sp, #0x60]
100022790: 97ff9743    	bl	0x10000849c <_OUTLINED_FUNCTION_12>
100022794: a945afe7    	ldp	x7, x11, [sp, #0x58]
100022798: eb07027f    	cmp	x19, x7
10002279c: f94043e2    	ldr	x2, [sp, #0x80]
1000227a0: 4f04a402    	movi.8h	v2, #0x80, lsl #8
1000227a4: 54000ac0    	b.eq	0x1000228fc <_deflate_compress_near_optimal+0xbf8>
1000227a8: f9401be8    	ldr	x8, [sp, #0x30]
1000227ac: 39408108    	ldrb	w8, [x8, #0x20]
1000227b0: f9003bf3    	str	x19, [sp, #0x70]
1000227b4: 7100051f    	cmp	w8, #0x1
1000227b8: 54ffb361    	b.ne	0x100021e24 <_deflate_compress_near_optimal+0x120>
1000227bc: 14000050    	b	0x1000228fc <_deflate_compress_near_optimal+0xbf8>
1000227c0: d00032a9    	adrp	x9, 0x100678000 <_corpus_input+0x651f00>
1000227c4: 911be129    	add	x9, x9, #0x6f8
1000227c8: 38684929    	ldrb	w9, [x9, w8, uxtw]
1000227cc: b90057e9    	str	w9, [sp, #0x54]
1000227d0: b94023e9    	ldr	w9, [sp, #0x20]
1000227d4: 71003d3f    	cmp	w9, #0xf
1000227d8: 4f04a402    	movi.8h	v2, #0x80, lsl #8
1000227dc: 54ffba08    	b.hi	0x100021f1c <_deflate_compress_near_optimal+0x218>
1000227e0: 7100113f    	cmp	w9, #0x4
1000227e4: 540000a8    	b.hi	0x1000227f8 <_deflate_compress_near_optimal+0xaf4>
1000227e8: d100b508    	sub	x8, x8, #0x2d
1000227ec: f1008d1f    	cmp	x8, #0x23
1000227f0: 52800088    	mov	w8, #0x4                ; =4
1000227f4: 1400000a    	b	0x10002281c <_deflate_compress_near_optimal+0xb18>
1000227f8: 7100253f    	cmp	w9, #0x9
1000227fc: 540000a8    	b.hi	0x100022810 <_deflate_compress_near_optimal+0xb0c>
100022800: d1004108    	sub	x8, x8, #0x10
100022804: f101011f    	cmp	x8, #0x40
100022808: 528000a8    	mov	w8, #0x5                ; =5
10002280c: 14000004    	b	0x10002281c <_deflate_compress_near_optimal+0xb18>
100022810: d1002108    	sub	x8, x8, #0x8
100022814: f101211f    	cmp	x8, #0x48
100022818: 528000e8    	mov	w8, #0x7                ; =7
10002281c: b94057e9    	ldr	w9, [sp, #0x54]
100022820: 1a883129    	csel	w9, w9, w8, lo
100022824: b90057e9    	str	w9, [sp, #0x54]
100022828: 17fffdbd    	b	0x100021f1c <_deflate_compress_near_optimal+0x218>
10002282c: 8b1402a4    	add	x4, x21, x20
100022830: 6f00e404    	movi.2d	v4, #0000000000000000
100022834: f94033e2    	ldr	x2, [sp, #0x60]
100022838: f94013e8    	ldr	x8, [sp, #0x20]
10002283c: b40005a8    	cbz	x8, 0x1000228f0 <_deflate_compress_near_optimal+0xbec>
100022840: 4b020103    	sub	w3, w8, w2
100022844: 4b130108    	sub	w8, w8, w19
100022848: aa0403f4    	mov	x20, x4
10002284c: 785fce89    	ldrh	w9, [x20, #-0x4]!
100022850: cb090a94    	sub	x20, x20, x9, lsl #2
100022854: 31000508    	adds	w8, w8, #0x1
100022858: 54ffffa3    	b.lo	0x10002284c <_deflate_compress_near_optimal+0xb48>
10002285c: f9400fe8    	ldr	x8, [sp, #0x18]
100022860: eb08005f    	cmp	x2, x8
100022864: 1a9f17e5    	cset	w5, eq
100022868: cb140088    	sub	x8, x4, x20
10002286c: f9003be8    	str	x8, [sp, #0x70]
100022870: 91023fe7    	add	x7, sp, #0x8f
100022874: aa1503e0    	mov	x0, x21
100022878: f9401be1    	ldr	x1, [sp, #0x30]
10002287c: aa1403e4    	mov	x4, x20
100022880: 52800006    	mov	w6, #0x0                ; =0
100022884: 97ff8494    	bl	0x100003ad4 <_deflate_optimize_and_flush_block>
100022888: 5282f808    	mov	w8, #0x17c0             ; =6080
10002288c: 72a00108    	movk	w8, #0x8, lsl #16
100022890: 8b0802a0    	add	x0, x21, x8
100022894: aa1403e1    	mov	x1, x20
100022898: f9403bf4    	ldr	x20, [sp, #0x70]
10002289c: aa1403e2    	mov	x2, x20
1000228a0: 94000a0d    	bl	0x1000250d4 <_task_info+0x1000250d4>
1000228a4: 5282f808    	mov	w8, #0x17c0             ; =6080
1000228a8: 72a00108    	movk	w8, #0x8, lsl #16
1000228ac: 8b080294    	add	x20, x20, x8
1000228b0: 3dc156a0    	ldr	q0, [x21, #0x550]
1000228b4: 3dc15aa1    	ldr	q1, [x21, #0x560]
1000228b8: f9400be9    	ldr	x9, [sp, #0x10]
1000228bc: ad000520    	stp	q0, q1, [x9]
1000228c0: fd42baa0    	ldr	d0, [x21, #0x570]
1000228c4: fd001120    	str	d0, [x9, #0x20]
1000228c8: b9457ea8    	ldr	w8, [x21, #0x57c]
1000228cc: b9002928    	str	w8, [x9, #0x28]
1000228d0: f94003e8    	ldr	x8, [sp]
1000228d4: f900111f    	str	xzr, [x8, #0x20]
1000228d8: 6f00e400    	movi.2d	v0, #0000000000000000
1000228dc: ad000100    	stp	q0, q0, [x8]
1000228e0: f94013e8    	ldr	x8, [sp, #0x20]
1000228e4: f90033e8    	str	x8, [sp, #0x60]
1000228e8: b9057ebf    	str	wzr, [x21, #0x57c]
1000228ec: 17ffffa9    	b	0x100022790 <_deflate_compress_near_optimal+0xa8c>
1000228f0: f9401fe0    	ldr	x0, [sp, #0x38]
1000228f4: f9402fe7    	ldr	x7, [sp, #0x58]
1000228f8: 17ffff75    	b	0x1000226cc <_deflate_compress_near_optimal+0x9c8>
1000228fc: f85983a8    	ldur	x8, [x29, #-0x68]
100022900: d00032c9    	adrp	x9, 0x10067c000 <_task_info+0x10067c000>
100022904: f9401929    	ldr	x9, [x9, #0x30]
100022908: f9400129    	ldr	x9, [x9]
10002290c: eb08013f    	cmp	x9, x8
100022910: 54000121    	b.ne	0x100022934 <_deflate_compress_near_optimal+0xc30>
100022914: 9106c3ff    	add	sp, sp, #0x1b0
100022918: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10002291c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100022920: a94357f6    	ldp	x22, x21, [sp, #0x30]
100022924: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100022928: a94167fa    	ldp	x26, x25, [sp, #0x10]
10002292c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100022930: d65f03c0    	ret
100022934: 940009bb    	bl	0x100025020 <_task_info+0x100025020>
