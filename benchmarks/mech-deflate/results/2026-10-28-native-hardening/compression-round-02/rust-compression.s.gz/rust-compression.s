
/private/tmp/mech-deflate-comparison-final-20261028/rust-target/release/deflate-comparison:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010000fab4 <miniz_oxide::deflate::core::compress_inner>:
10000fab4: d102c3ff    	sub	sp, sp, #0xb0
10000fab8: 6d0423e9    	stp	d9, d8, [sp, #0x40]
10000fabc: a9056ffc    	stp	x28, x27, [sp, #0x50]
10000fac0: a90667fa    	stp	x26, x25, [sp, #0x60]
10000fac4: a9075ff8    	stp	x24, x23, [sp, #0x70]
10000fac8: a90857f6    	stp	x22, x21, [sp, #0x80]
10000facc: a9094ff4    	stp	x20, x19, [sp, #0x90]
10000fad0: a90a7bfd    	stp	x29, x30, [sp, #0xa0]
10000fad4: 910283fd    	add	x29, sp, #0xa0
10000fad8: aa0103fc    	mov	x28, x1
10000fadc: aa0003f5    	mov	x21, x0
10000fae0: aa0803f3    	mov	x19, x8
10000fae4: 9140401b    	add	x27, x0, #0x10, lsl #12 ; =0x10000
10000fae8: 91404016    	add	x22, x0, #0x10, lsl #12 ; =0x10000
10000faec: f8068edf    	str	xzr, [x22, #0x68]!
10000faf0: f9003b7f    	str	xzr, [x27, #0x70]
10000faf4: b940a768    	ldr	w8, [x27, #0xa4]
10000faf8: 3942ab69    	ldrb	w9, [x27, #0xaa]
10000fafc: 7100113f    	cmp	w9, #0x4
10000fb00: 54000561    	b.ne	0x10000fbac <miniz_oxide::deflate::core::compress_inner+0xf8>
10000fb04: 12001c49    	and	w9, w2, #0xff
10000fb08: 3902ab62    	strb	w2, [x27, #0xaa]
10000fb0c: 7100113f    	cmp	w9, #0x4
10000fb10: 54000521    	b.ne	0x10000fbb4 <miniz_oxide::deflate::core::compress_inner+0x100>
10000fb14: 35000508    	cbnz	w8, 0x10000fbb4 <miniz_oxide::deflate::core::compress_inner+0x100>
10000fb18: b9409774    	ldr	w20, [x27, #0x94]
10000fb1c: 35000074    	cbnz	w20, 0x10000fb28 <miniz_oxide::deflate::core::compress_inner+0x74>
10000fb20: 3942b368    	ldrb	w8, [x27, #0xac]
10000fb24: 360006c8    	tbz	w8, #0x0, 0x10000fbfc <miniz_oxide::deflate::core::compress_inner+0x148>
10000fb28: b9000a7f    	str	wzr, [x19, #0x8]
10000fb2c: f900027f    	str	xzr, [x19]
10000fb30: f9000a7f    	str	xzr, [x19, #0x10]
10000fb34: f9400388    	ldr	x8, [x28]
10000fb38: f100051f    	cmp	x8, #0x1
10000fb3c: 540002c1    	b.ne	0x10000fb94 <miniz_oxide::deflate::core::compress_inner+0xe0>
10000fb40: f9400b88    	ldr	x8, [x28, #0x10]
10000fb44: eb08029f    	cmp	x20, x8
10000fb48: 9a883295    	csel	x21, x20, x8, lo
10000fb4c: b9409376    	ldr	w22, [x27, #0x90]
10000fb50: b4000195    	cbz	x21, 0x10000fb80 <miniz_oxide::deflate::core::compress_inner+0xcc>
10000fb54: 52899988    	mov	w8, #0x4ccc             ; =19660
10000fb58: 72a00028    	movk	w8, #0x1, lsl #16
10000fb5c: b2400108    	orr	x8, x8, #0x1
10000fb60: 8b1602a1    	add	x1, x21, x22
10000fb64: eb08003f    	cmp	x1, x8
10000fb68: 5400ae82    	b.hs	0x100011138 <miniz_oxide::deflate::core::compress_inner+0x1684>
10000fb6c: f9403f68    	ldr	x8, [x27, #0x78]
10000fb70: f9400780    	ldr	x0, [x28, #0x8]
10000fb74: 8b160101    	add	x1, x8, x22
10000fb78: aa1503e2    	mov	x2, x21
10000fb7c: 94012b39    	bl	0x10005a860 <dyld_stub_binder+0x10005a860>
10000fb80: 0b1502c8    	add	w8, w22, w21
10000fb84: 4b150294    	sub	w20, w20, w21
10000fb88: 29125368    	stp	w8, w20, [x27, #0x90]
10000fb8c: f9003b75    	str	x21, [x27, #0x70]
10000fb90: f9000a75    	str	x21, [x19, #0x10]
10000fb94: 3942b368    	ldrb	w8, [x27, #0xac]
10000fb98: 7100051f    	cmp	w8, #0x1
10000fb9c: 7a400a80    	ccmp	w20, #0x0, #0x0, eq
10000fba0: 54000160    	b.eq	0x10000fbcc <miniz_oxide::deflate::core::compress_inner+0x118>
10000fba4: b900a77f    	str	wzr, [x27, #0xa4]
10000fba8: 1400000c    	b	0x10000fbd8 <miniz_oxide::deflate::core::compress_inner+0x124>
10000fbac: 3902ab62    	strb	w2, [x27, #0xaa]
10000fbb0: 34fffb48    	cbz	w8, 0x10000fb18 <miniz_oxide::deflate::core::compress_inner+0x64>
10000fbb4: 12800028    	mov	w8, #-0x2               ; =-2
10000fbb8: b900a768    	str	w8, [x27, #0xa4]
10000fbbc: b9000a68    	str	w8, [x19, #0x8]
10000fbc0: f900027f    	str	xzr, [x19]
10000fbc4: f9000a7f    	str	xzr, [x19, #0x10]
10000fbc8: 14000004    	b	0x10000fbd8 <miniz_oxide::deflate::core::compress_inner+0x124>
10000fbcc: 52800028    	mov	w8, #0x1                ; =1
10000fbd0: b9000a68    	str	w8, [x19, #0x8]
10000fbd4: b900a768    	str	w8, [x27, #0xa4]
10000fbd8: a94a7bfd    	ldp	x29, x30, [sp, #0xa0]
10000fbdc: a9494ff4    	ldp	x20, x19, [sp, #0x90]
10000fbe0: a94857f6    	ldp	x22, x21, [sp, #0x80]
10000fbe4: a9475ff8    	ldp	x24, x23, [sp, #0x70]
10000fbe8: a94667fa    	ldp	x26, x25, [sp, #0x60]
10000fbec: a9456ffc    	ldp	x28, x27, [sp, #0x50]
10000fbf0: 6d4423e9    	ldp	d9, d8, [sp, #0x40]
10000fbf4: 9102c3ff    	add	sp, sp, #0xb0
10000fbf8: d65f03c0    	ret
10000fbfc: b9408368    	ldr	w8, [x27, #0x80]
10000fc00: 379846c8    	tbnz	w8, #0x13, 0x1000104d8 <miniz_oxide::deflate::core::compress_inner+0xa24>
10000fc04: 5289ffe9    	mov	w9, #0x4fff             ; =20479
10000fc08: 72a00049    	movk	w9, #0x2, lsl #16
10000fc0c: 0a090108    	and	w8, w8, w9
10000fc10: 52880029    	mov	w9, #0x4001             ; =16385
10000fc14: 6b09011f    	cmp	w8, w9
10000fc18: 540046c1    	b.ne	0x1000104f0 <miniz_oxide::deflate::core::compress_inner+0xa3c>
10000fc1c: f9400f88    	ldr	x8, [x28, #0x18]
10000fc20: b4009b68    	cbz	x8, 0x100010f8c <miniz_oxide::deflate::core::compress_inner+0x14d8>
10000fc24: f9001be8    	str	x8, [sp, #0x30]
10000fc28: f9000bf6    	str	x22, [sp, #0x10]
10000fc2c: d2800018    	mov	x24, #0x0               ; =0
10000fc30: a9445f68    	ldp	x8, x23, [x27, #0x40]
10000fc34: f90013e8    	str	x8, [sp, #0x20]
10000fc38: 92403af6    	and	x22, x23, #0x7fff
10000fc3c: f9401394    	ldr	x20, [x28, #0x20]
10000fc40: f0000288    	adrp	x8, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
10000fc44: fd444508    	ldr	d8, [x8, #0x888]
10000fc48: f90007fc    	str	x28, [sp, #0x8]
10000fc4c: f90017f4    	str	x20, [sp, #0x28]
10000fc50: eb180288    	subs	x8, x20, x24
10000fc54: f94013ea    	ldr	x10, [sp, #0x20]
10000fc58: 54000088    	b.hi	0x10000fc68 <miniz_oxide::deflate::core::compress_inner+0x1b4>
10000fc5c: b400a52a    	cbz	x10, 0x100011100 <miniz_oxide::deflate::core::compress_inner+0x164c>
10000fc60: 3942ab69    	ldrb	w9, [x27, #0xaa]
10000fc64: 3400a4e9    	cbz	w9, 0x100011100 <miniz_oxide::deflate::core::compress_inner+0x164c>
10000fc68: 52820009    	mov	w9, #0x1000             ; =4096
10000fc6c: cb0a0129    	sub	x9, x9, x10
10000fc70: eb08013f    	cmp	x9, x8
10000fc74: 9a883134    	csel	x20, x9, x8, lo
10000fc78: f9000ff4    	str	x20, [sp, #0x18]
10000fc7c: b4000554    	cbz	x20, 0x10000fd24 <miniz_oxide::deflate::core::compress_inner+0x270>
10000fc80: 8b0a02e8    	add	x8, x23, x10
10000fc84: aa1803f9    	mov	x25, x24
10000fc88: 1400000b    	b	0x10000fcb4 <miniz_oxide::deflate::core::compress_inner+0x200>
10000fc8c: f9400f68    	ldr	x8, [x27, #0x18]
10000fc90: 8b1c0108    	add	x8, x8, x28
10000fc94: 91402100    	add	x0, x8, #0x8, lsl #12   ; =0x8000
10000fc98: f9401be8    	ldr	x8, [sp, #0x30]
10000fc9c: 8b190101    	add	x1, x8, x25
10000fca0: 94012af0    	bl	0x10005a860 <dyld_stub_binder+0x10005a860>
10000fca4: 8b1c0348    	add	x8, x26, x28
10000fca8: aa1803f9    	mov	x25, x24
10000fcac: eb1a0294    	subs	x20, x20, x26
10000fcb0: 540003a0    	b.eq	0x10000fd24 <miniz_oxide::deflate::core::compress_inner+0x270>
10000fcb4: 9240391c    	and	x28, x8, #0x7fff
10000fcb8: 52900008    	mov	w8, #0x8000             ; =32768
10000fcbc: cb1c0108    	sub	x8, x8, x28
10000fcc0: eb08029f    	cmp	x20, x8
10000fcc4: 9a88329a    	csel	x26, x20, x8, lo
10000fcc8: ab190358    	adds	x24, x26, x25
10000fccc: 5400a202    	b.hs	0x10001110c <miniz_oxide::deflate::core::compress_inner+0x1658>
10000fcd0: f94017e8    	ldr	x8, [sp, #0x28]
10000fcd4: eb08031f    	cmp	x24, x8
10000fcd8: 5400a1a8    	b.hi	0x10001110c <miniz_oxide::deflate::core::compress_inner+0x1658>
10000fcdc: f9400f68    	ldr	x8, [x27, #0x18]
10000fce0: 8b1c0100    	add	x0, x8, x28
10000fce4: f9401be8    	ldr	x8, [sp, #0x30]
10000fce8: 8b190101    	add	x1, x8, x25
10000fcec: aa1a03e2    	mov	x2, x26
10000fcf0: 94012adc    	bl	0x10005a860 <dyld_stub_binder+0x10005a860>
10000fcf4: f104039f    	cmp	x28, #0x100
10000fcf8: 54fffd68    	b.hi	0x10000fca4 <miniz_oxide::deflate::core::compress_inner+0x1f0>
10000fcfc: 52802028    	mov	w8, #0x101              ; =257
10000fd00: cb1c0108    	sub	x8, x8, x28
10000fd04: eb1a011f    	cmp	x8, x26
10000fd08: 9a9a3102    	csel	x2, x8, x26, lo
10000fd0c: ab190041    	adds	x1, x2, x25
10000fd10: 5400a0a2    	b.hs	0x100011124 <miniz_oxide::deflate::core::compress_inner+0x1670>
10000fd14: f94017e8    	ldr	x8, [sp, #0x28]
10000fd18: eb08003f    	cmp	x1, x8
10000fd1c: 54fffb89    	b.ls	0x10000fc8c <miniz_oxide::deflate::core::compress_inner+0x1d8>
10000fd20: 14000501    	b	0x100011124 <miniz_oxide::deflate::core::compress_inner+0x1670>
10000fd24: a941a3e9    	ldp	x9, x8, [sp, #0x18]
10000fd28: 8b080128    	add	x8, x9, x8
10000fd2c: 52900009    	mov	w9, #0x8000             ; =32768
10000fd30: cb080129    	sub	x9, x9, x8
10000fd34: f9402b6a    	ldr	x10, [x27, #0x50]
10000fd38: eb09015f    	cmp	x10, x9
10000fd3c: 9a893149    	csel	x9, x10, x9, lo
10000fd40: f9002b69    	str	x9, [x27, #0x50]
10000fd44: 3942ab69    	ldrb	w9, [x27, #0xaa]
10000fd48: f13ffd1f    	cmp	x8, #0xfff
10000fd4c: 7a409920    	ccmp	w9, #0x0, #0x0, ls
10000fd50: 54009d20    	b.eq	0x1000110f4 <miniz_oxide::deflate::core::compress_inner+0x1640>
10000fd54: f100111f    	cmp	x8, #0x4
10000fd58: f94007fc    	ldr	x28, [sp, #0x8]
10000fd5c: f94017f4    	ldr	x20, [sp, #0x28]
10000fd60: 52800119    	mov	w25, #0x8               ; =8
10000fd64: 529fff3a    	mov	w26, #0xfff9            ; =65529
10000fd68: 540006a2    	b.hs	0x10000fe3c <miniz_oxide::deflate::core::compress_inner+0x388>
10000fd6c: f90013ff    	str	xzr, [sp, #0x20]
10000fd70: b50000a8    	cbnz	x8, 0x10000fd84 <miniz_oxide::deflate::core::compress_inner+0x2d0>
10000fd74: 17ffffb7    	b	0x10000fc50 <miniz_oxide::deflate::core::compress_inner+0x19c>
10000fd78: 110006c9    	add	w9, w22, #0x1
10000fd7c: 92403936    	and	x22, x9, #0x7fff
10000fd80: b4003a88    	cbz	x8, 0x1000104d0 <miniz_oxide::deflate::core::compress_inner+0xa1c>
10000fd84: f9400f69    	ldr	x9, [x27, #0x18]
10000fd88: 38766929    	ldrb	w9, [x9, x22]
10000fd8c: f940036a    	ldr	x10, [x27]
10000fd90: 92403d4b    	and	x11, x10, #0xffff
10000fd94: 382b6aa9    	strb	w9, [x21, x11]
10000fd98: 9100054b    	add	x11, x10, #0x1
10000fd9c: 7940136c    	ldrh	w12, [x27, #0x8]
10000fda0: 386c6aad    	ldrb	w13, [x21, x12]
10000fda4: 53017dad    	lsr	w13, w13, #1
10000fda8: 382c6aad    	strb	w13, [x21, x12]
10000fdac: f900036b    	str	x11, [x27]
10000fdb0: fd400b60    	ldr	d0, [x27, #0x10]
10000fdb4: 0ea88400    	add.2s	v0, v0, v8
10000fdb8: fd000b60    	str	d0, [x27, #0x10]
10000fdbc: 0e0c3c0c    	mov.s	w12, v0[1]
10000fdc0: 3500008c    	cbnz	w12, 0x10000fdd0 <miniz_oxide::deflate::core::compress_inner+0x31c>
10000fdc4: b9001779    	str	w25, [x27, #0x14]
10000fdc8: 9100094a    	add	x10, x10, #0x2
10000fdcc: a9002f6a    	stp	x10, x11, [x27]
10000fdd0: f940336a    	ldr	x10, [x27, #0x60]
10000fdd4: 7869794b    	ldrh	w11, [x10, x9, lsl #1]
10000fdd8: 1100056b    	add	w11, w11, #0x1
10000fddc: 7829794b    	strh	w11, [x10, x9, lsl #1]
10000fde0: 910006f7    	add	x23, x23, #0x1
10000fde4: f9402b69    	ldr	x9, [x27, #0x50]
10000fde8: 9100052a    	add	x10, x9, #0x1
10000fdec: f140215f    	cmp	x10, #0x8, lsl #12      ; =0x8000
10000fdf0: 5290000a    	mov	w10, #0x8000            ; =32768
10000fdf4: 9a892549    	csinc	x9, x10, x9, hs
10000fdf8: f9002b69    	str	x9, [x27, #0x50]
10000fdfc: d1000508    	sub	x8, x8, #0x1
10000fe00: f9400369    	ldr	x9, [x27]
10000fe04: eb1a013f    	cmp	x9, x26
10000fe08: 54fffb83    	b.lo	0x10000fd78 <miniz_oxide::deflate::core::compress_inner+0x2c4>
10000fe0c: a9045f68    	stp	x8, x23, [x27, #0x40]
10000fe10: aa1503e0    	mov	x0, x21
10000fe14: aa1c03e1    	mov	x1, x28
10000fe18: 52800002    	mov	w2, #0x0                ; =0
10000fe1c: 97fff821    	bl	0x10000dea0 <miniz_oxide::deflate::core::flush_block>
10000fe20: 37008720    	tbnz	w0, #0x0, 0x100010f04 <miniz_oxide::deflate::core::compress_inner+0x1450>
10000fe24: 35008681    	cbnz	w1, 0x100010ef4 <miniz_oxide::deflate::core::compress_inner+0x1440>
10000fe28: a9445f68    	ldp	x8, x23, [x27, #0x40]
10000fe2c: 17ffffd3    	b	0x10000fd78 <miniz_oxide::deflate::core::compress_inner+0x2c4>
10000fe30: a9445f68    	ldp	x8, x23, [x27, #0x40]
10000fe34: f1000d1f    	cmp	x8, #0x3
10000fe38: 54fff9a9    	b.ls	0x10000fd6c <miniz_oxide::deflate::core::compress_inner+0x2b8>
10000fe3c: f9400f69    	ldr	x9, [x27, #0x18]
10000fe40: b8766929    	ldr	w9, [x9, x22]
10000fe44: 12005d2b    	and	w11, w9, #0xffffff
10000fe48: 12002d2a    	and	w10, w9, #0xfff
10000fe4c: 4a4b454a    	eor	w10, w10, w11, lsr #17
10000fe50: f940176c    	ldr	x12, [x27, #0x28]
10000fe54: 786a598d    	ldrh	w13, [x12, w10, uxtw #1]
10000fe58: 782a5997    	strh	w23, [x12, w10, uxtw #1]
10000fe5c: 4b0d02ea    	sub	w10, w23, w13
10000fe60: f9402b6c    	ldr	x12, [x27, #0x50]
10000fe64: eb2a219f    	cmp	x12, w10, uxth
10000fe68: 54fffe63    	b.lo	0x10000fe34 <miniz_oxide::deflate::core::compress_inner+0x380>
10000fe6c: 924039b0    	and	x16, x13, #0x7fff
10000fe70: f9400f6e    	ldr	x14, [x27, #0x18]
10000fe74: b87069cc    	ldr	w12, [x14, x16]
10000fe78: 12005d8c    	and	w12, w12, #0xffffff
10000fe7c: 6b0c017f    	cmp	w11, w12
10000fe80: 54002121    	b.ne	0x1000102a4 <miniz_oxide::deflate::core::compress_inner+0x7f0>
10000fe84: 91000ecb    	add	x11, x22, #0x3
10000fe88: 11000e0f    	add	w15, w16, #0x3
10000fe8c: 9240396c    	and	x12, x11, #0x7fff
10000fe90: f86c69cc    	ldr	x12, [x14, x12]
10000fe94: 924039ef    	and	x15, x15, #0x7fff
10000fe98: f86f69cf    	ldr	x15, [x14, x15]
10000fe9c: eb0f019f    	cmp	x12, x15
10000fea0: 540026c1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000fea4: 91002ecb    	add	x11, x22, #0xb
10000fea8: 11002e0f    	add	w15, w16, #0xb
10000feac: 9240396c    	and	x12, x11, #0x7fff
10000feb0: f86c69cc    	ldr	x12, [x14, x12]
10000feb4: 924039ef    	and	x15, x15, #0x7fff
10000feb8: f86f69cf    	ldr	x15, [x14, x15]
10000febc: eb0f019f    	cmp	x12, x15
10000fec0: 540025c1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000fec4: 91004ecb    	add	x11, x22, #0x13
10000fec8: 11004e0f    	add	w15, w16, #0x13
10000fecc: 9240396c    	and	x12, x11, #0x7fff
10000fed0: f86c69cc    	ldr	x12, [x14, x12]
10000fed4: 924039ef    	and	x15, x15, #0x7fff
10000fed8: f86f69cf    	ldr	x15, [x14, x15]
10000fedc: eb0f019f    	cmp	x12, x15
10000fee0: 540024c1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000fee4: 91006ecb    	add	x11, x22, #0x1b
10000fee8: 11006e0f    	add	w15, w16, #0x1b
10000feec: 9240396c    	and	x12, x11, #0x7fff
10000fef0: f86c69cc    	ldr	x12, [x14, x12]
10000fef4: 924039ef    	and	x15, x15, #0x7fff
10000fef8: f86f69cf    	ldr	x15, [x14, x15]
10000fefc: eb0f019f    	cmp	x12, x15
10000ff00: 540023c1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000ff04: 91008ecb    	add	x11, x22, #0x23
10000ff08: 11008e0f    	add	w15, w16, #0x23
10000ff0c: 9240396c    	and	x12, x11, #0x7fff
10000ff10: f86c69cc    	ldr	x12, [x14, x12]
10000ff14: 924039ef    	and	x15, x15, #0x7fff
10000ff18: f86f69cf    	ldr	x15, [x14, x15]
10000ff1c: eb0f019f    	cmp	x12, x15
10000ff20: 540022c1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000ff24: 9100aecb    	add	x11, x22, #0x2b
10000ff28: 1100ae0f    	add	w15, w16, #0x2b
10000ff2c: 9240396c    	and	x12, x11, #0x7fff
10000ff30: f86c69cc    	ldr	x12, [x14, x12]
10000ff34: 924039ef    	and	x15, x15, #0x7fff
10000ff38: f86f69cf    	ldr	x15, [x14, x15]
10000ff3c: eb0f019f    	cmp	x12, x15
10000ff40: 540021c1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000ff44: 9100cecb    	add	x11, x22, #0x33
10000ff48: 1100ce0f    	add	w15, w16, #0x33
10000ff4c: 9240396c    	and	x12, x11, #0x7fff
10000ff50: f86c69cc    	ldr	x12, [x14, x12]
10000ff54: 924039ef    	and	x15, x15, #0x7fff
10000ff58: f86f69cf    	ldr	x15, [x14, x15]
10000ff5c: eb0f019f    	cmp	x12, x15
10000ff60: 540020c1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000ff64: 9100eecb    	add	x11, x22, #0x3b
10000ff68: 1100ee0f    	add	w15, w16, #0x3b
10000ff6c: 9240396c    	and	x12, x11, #0x7fff
10000ff70: f86c69cc    	ldr	x12, [x14, x12]
10000ff74: 924039ef    	and	x15, x15, #0x7fff
10000ff78: f86f69cf    	ldr	x15, [x14, x15]
10000ff7c: eb0f019f    	cmp	x12, x15
10000ff80: 54001fc1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000ff84: 91010ecb    	add	x11, x22, #0x43
10000ff88: 11010e0f    	add	w15, w16, #0x43
10000ff8c: 9240396c    	and	x12, x11, #0x7fff
10000ff90: f86c69cc    	ldr	x12, [x14, x12]
10000ff94: 924039ef    	and	x15, x15, #0x7fff
10000ff98: f86f69cf    	ldr	x15, [x14, x15]
10000ff9c: eb0f019f    	cmp	x12, x15
10000ffa0: 54001ec1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000ffa4: 91012ecb    	add	x11, x22, #0x4b
10000ffa8: 11012e0f    	add	w15, w16, #0x4b
10000ffac: 9240396c    	and	x12, x11, #0x7fff
10000ffb0: f86c69cc    	ldr	x12, [x14, x12]
10000ffb4: 924039ef    	and	x15, x15, #0x7fff
10000ffb8: f86f69cf    	ldr	x15, [x14, x15]
10000ffbc: eb0f019f    	cmp	x12, x15
10000ffc0: 54001dc1    	b.ne	0x100010378 <miniz_oxide::deflate::core::compress_inner+0x8c4>
10000ffc4: 91014ecb    	add	x11, x22, #0x53
10000ffc8: 11014e0f    	add	w15, w16, #0x53
10000ffcc: 9240396c    	and	x12, x11, #0x7fff
10000ffd0: f86c69cc    	ldr	x12, [x14, x12]
10000ffd4: 924039ef    	and	x15, x15, #0x7fff
10000ffd8: f86f69cf    	ldr	x15, [x14, x15]
10000ffdc: eb0f019f    	cmp	x12, x15
10000ffe0: 54001c41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
10000ffe4: 91016ecb    	add	x11, x22, #0x5b
10000ffe8: 11016e0f    	add	w15, w16, #0x5b
10000ffec: 9240396c    	and	x12, x11, #0x7fff
10000fff0: f86c69cc    	ldr	x12, [x14, x12]
10000fff4: 924039ef    	and	x15, x15, #0x7fff
10000fff8: f86f69cf    	ldr	x15, [x14, x15]
10000fffc: eb0f019f    	cmp	x12, x15
100010000: 54001b41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010004: 91018ecb    	add	x11, x22, #0x63
100010008: 11018e0f    	add	w15, w16, #0x63
10001000c: 9240396c    	and	x12, x11, #0x7fff
100010010: f86c69cc    	ldr	x12, [x14, x12]
100010014: 924039ef    	and	x15, x15, #0x7fff
100010018: f86f69cf    	ldr	x15, [x14, x15]
10001001c: eb0f019f    	cmp	x12, x15
100010020: 54001a41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010024: 9101aecb    	add	x11, x22, #0x6b
100010028: 1101ae0f    	add	w15, w16, #0x6b
10001002c: 9240396c    	and	x12, x11, #0x7fff
100010030: f86c69cc    	ldr	x12, [x14, x12]
100010034: 924039ef    	and	x15, x15, #0x7fff
100010038: f86f69cf    	ldr	x15, [x14, x15]
10001003c: eb0f019f    	cmp	x12, x15
100010040: 54001941    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010044: 9101cecb    	add	x11, x22, #0x73
100010048: 1101ce0f    	add	w15, w16, #0x73
10001004c: 9240396c    	and	x12, x11, #0x7fff
100010050: f86c69cc    	ldr	x12, [x14, x12]
100010054: 924039ef    	and	x15, x15, #0x7fff
100010058: f86f69cf    	ldr	x15, [x14, x15]
10001005c: eb0f019f    	cmp	x12, x15
100010060: 54001841    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010064: 9101eecb    	add	x11, x22, #0x7b
100010068: 1101ee0f    	add	w15, w16, #0x7b
10001006c: 9240396c    	and	x12, x11, #0x7fff
100010070: f86c69cc    	ldr	x12, [x14, x12]
100010074: 924039ef    	and	x15, x15, #0x7fff
100010078: f86f69cf    	ldr	x15, [x14, x15]
10001007c: eb0f019f    	cmp	x12, x15
100010080: 54001741    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010084: 91020ecb    	add	x11, x22, #0x83
100010088: 11020e0f    	add	w15, w16, #0x83
10001008c: 9240396c    	and	x12, x11, #0x7fff
100010090: f86c69cc    	ldr	x12, [x14, x12]
100010094: 924039ef    	and	x15, x15, #0x7fff
100010098: f86f69cf    	ldr	x15, [x14, x15]
10001009c: eb0f019f    	cmp	x12, x15
1000100a0: 54001641    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
1000100a4: 91022ecb    	add	x11, x22, #0x8b
1000100a8: 11022e0f    	add	w15, w16, #0x8b
1000100ac: 9240396c    	and	x12, x11, #0x7fff
1000100b0: f86c69cc    	ldr	x12, [x14, x12]
1000100b4: 924039ef    	and	x15, x15, #0x7fff
1000100b8: f86f69cf    	ldr	x15, [x14, x15]
1000100bc: eb0f019f    	cmp	x12, x15
1000100c0: 54001541    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
1000100c4: 91024ecb    	add	x11, x22, #0x93
1000100c8: 11024e0f    	add	w15, w16, #0x93
1000100cc: 9240396c    	and	x12, x11, #0x7fff
1000100d0: f86c69cc    	ldr	x12, [x14, x12]
1000100d4: 924039ef    	and	x15, x15, #0x7fff
1000100d8: f86f69cf    	ldr	x15, [x14, x15]
1000100dc: eb0f019f    	cmp	x12, x15
1000100e0: 54001441    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
1000100e4: 91026ecb    	add	x11, x22, #0x9b
1000100e8: 11026e0f    	add	w15, w16, #0x9b
1000100ec: 9240396c    	and	x12, x11, #0x7fff
1000100f0: f86c69cc    	ldr	x12, [x14, x12]
1000100f4: 924039ef    	and	x15, x15, #0x7fff
1000100f8: f86f69cf    	ldr	x15, [x14, x15]
1000100fc: eb0f019f    	cmp	x12, x15
100010100: 54001341    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010104: 91028ecb    	add	x11, x22, #0xa3
100010108: 11028e0f    	add	w15, w16, #0xa3
10001010c: 9240396c    	and	x12, x11, #0x7fff
100010110: f86c69cc    	ldr	x12, [x14, x12]
100010114: 924039ef    	and	x15, x15, #0x7fff
100010118: f86f69cf    	ldr	x15, [x14, x15]
10001011c: eb0f019f    	cmp	x12, x15
100010120: 54001241    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010124: 9102aecb    	add	x11, x22, #0xab
100010128: 1102ae0f    	add	w15, w16, #0xab
10001012c: 9240396c    	and	x12, x11, #0x7fff
100010130: f86c69cc    	ldr	x12, [x14, x12]
100010134: 924039ef    	and	x15, x15, #0x7fff
100010138: f86f69cf    	ldr	x15, [x14, x15]
10001013c: eb0f019f    	cmp	x12, x15
100010140: 54001141    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010144: 9102cecb    	add	x11, x22, #0xb3
100010148: 1102ce0f    	add	w15, w16, #0xb3
10001014c: 9240396c    	and	x12, x11, #0x7fff
100010150: f86c69cc    	ldr	x12, [x14, x12]
100010154: 924039ef    	and	x15, x15, #0x7fff
100010158: f86f69cf    	ldr	x15, [x14, x15]
10001015c: eb0f019f    	cmp	x12, x15
100010160: 54001041    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010164: 9102eecb    	add	x11, x22, #0xbb
100010168: 1102ee0f    	add	w15, w16, #0xbb
10001016c: 9240396c    	and	x12, x11, #0x7fff
100010170: f86c69cc    	ldr	x12, [x14, x12]
100010174: 924039ef    	and	x15, x15, #0x7fff
100010178: f86f69cf    	ldr	x15, [x14, x15]
10001017c: eb0f019f    	cmp	x12, x15
100010180: 54000f41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010184: 91030ecb    	add	x11, x22, #0xc3
100010188: 11030e0f    	add	w15, w16, #0xc3
10001018c: 9240396c    	and	x12, x11, #0x7fff
100010190: f86c69cc    	ldr	x12, [x14, x12]
100010194: 924039ef    	and	x15, x15, #0x7fff
100010198: f86f69cf    	ldr	x15, [x14, x15]
10001019c: eb0f019f    	cmp	x12, x15
1000101a0: 54000e41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
1000101a4: 91032ecb    	add	x11, x22, #0xcb
1000101a8: 11032e0f    	add	w15, w16, #0xcb
1000101ac: 9240396c    	and	x12, x11, #0x7fff
1000101b0: f86c69cc    	ldr	x12, [x14, x12]
1000101b4: 924039ef    	and	x15, x15, #0x7fff
1000101b8: f86f69cf    	ldr	x15, [x14, x15]
1000101bc: eb0f019f    	cmp	x12, x15
1000101c0: 54000d41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
1000101c4: 91034ecb    	add	x11, x22, #0xd3
1000101c8: 11034e0f    	add	w15, w16, #0xd3
1000101cc: 9240396c    	and	x12, x11, #0x7fff
1000101d0: f86c69cc    	ldr	x12, [x14, x12]
1000101d4: 924039ef    	and	x15, x15, #0x7fff
1000101d8: f86f69cf    	ldr	x15, [x14, x15]
1000101dc: eb0f019f    	cmp	x12, x15
1000101e0: 54000c41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
1000101e4: 91036ecb    	add	x11, x22, #0xdb
1000101e8: 11036e0f    	add	w15, w16, #0xdb
1000101ec: 9240396c    	and	x12, x11, #0x7fff
1000101f0: f86c69cc    	ldr	x12, [x14, x12]
1000101f4: 924039ef    	and	x15, x15, #0x7fff
1000101f8: f86f69cf    	ldr	x15, [x14, x15]
1000101fc: eb0f019f    	cmp	x12, x15
100010200: 54000b41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010204: 91038ecb    	add	x11, x22, #0xe3
100010208: 11038e0f    	add	w15, w16, #0xe3
10001020c: 9240396c    	and	x12, x11, #0x7fff
100010210: f86c69cc    	ldr	x12, [x14, x12]
100010214: 924039ef    	and	x15, x15, #0x7fff
100010218: f86f69cf    	ldr	x15, [x14, x15]
10001021c: eb0f019f    	cmp	x12, x15
100010220: 54000a41    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010224: 9103aecb    	add	x11, x22, #0xeb
100010228: 1103ae0f    	add	w15, w16, #0xeb
10001022c: 9240396c    	and	x12, x11, #0x7fff
100010230: f86c69cc    	ldr	x12, [x14, x12]
100010234: 924039ef    	and	x15, x15, #0x7fff
100010238: f86f69cf    	ldr	x15, [x14, x15]
10001023c: eb0f019f    	cmp	x12, x15
100010240: 54000941    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010244: 9103cecb    	add	x11, x22, #0xf3
100010248: 1103ce0f    	add	w15, w16, #0xf3
10001024c: 9240396c    	and	x12, x11, #0x7fff
100010250: f86c69cc    	ldr	x12, [x14, x12]
100010254: 924039ef    	and	x15, x15, #0x7fff
100010258: f86f69cf    	ldr	x15, [x14, x15]
10001025c: eb0f019f    	cmp	x12, x15
100010260: 54000841    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010264: 9103eecb    	add	x11, x22, #0xfb
100010268: 1103ee0f    	add	w15, w16, #0xfb
10001026c: 9240396c    	and	x12, x11, #0x7fff
100010270: f86c69cc    	ldr	x12, [x14, x12]
100010274: 924039ef    	and	x15, x15, #0x7fff
100010278: f86f69cf    	ldr	x15, [x14, x15]
10001027c: eb0f019f    	cmp	x12, x15
100010280: 54000741    	b.ne	0x100010368 <miniz_oxide::deflate::core::compress_inner+0x8b4>
100010284: 6b3721bf    	cmp	w13, w23, uxth
100010288: f94007fc    	ldr	x28, [sp, #0x8]
10001028c: f94017f4    	ldr	x20, [sp, #0x28]
100010290: 52800119    	mov	w25, #0x8               ; =8
100010294: 529fff3a    	mov	w26, #0xfff9            ; =65529
100010298: 54000be0    	b.eq	0x100010414 <miniz_oxide::deflate::core::compress_inner+0x960>
10001029c: 5280204b    	mov	w11, #0x102             ; =258
1000102a0: 14000041    	b	0x1000103a4 <miniz_oxide::deflate::core::compress_inner+0x8f0>
1000102a4: f940036a    	ldr	x10, [x27]
1000102a8: 92403d4b    	and	x11, x10, #0xffff
1000102ac: 382b6aa9    	strb	w9, [x21, x11]
1000102b0: 9100054a    	add	x10, x10, #0x1
1000102b4: 7940136b    	ldrh	w11, [x27, #0x8]
1000102b8: 386b6aac    	ldrb	w12, [x21, x11]
1000102bc: f900036a    	str	x10, [x27]
1000102c0: 53017d8a    	lsr	w10, w12, #1
1000102c4: 382b6aaa    	strb	w10, [x21, x11]
1000102c8: 92401d29    	and	x9, x9, #0xff
1000102cc: f940336a    	ldr	x10, [x27, #0x60]
1000102d0: 7869794b    	ldrh	w11, [x10, x9, lsl #1]
1000102d4: 1100056b    	add	w11, w11, #0x1
1000102d8: 7829794b    	strh	w11, [x10, x9, lsl #1]
1000102dc: 52800029    	mov	w9, #0x1                ; =1
1000102e0: b940176b    	ldr	w11, [x27, #0x14]
1000102e4: f940036a    	ldr	x10, [x27]
1000102e8: 7100056b    	subs	w11, w11, #0x1
1000102ec: b900176b    	str	w11, [x27, #0x14]
1000102f0: 540000a1    	b.ne	0x100010304 <miniz_oxide::deflate::core::compress_inner+0x850>
1000102f4: b9001779    	str	w25, [x27, #0x14]
1000102f8: f900076a    	str	x10, [x27, #0x8]
1000102fc: 9100054a    	add	x10, x10, #0x1
100010300: f900036a    	str	x10, [x27]
100010304: b940136b    	ldr	w11, [x27, #0x10]
100010308: 0b09016b    	add	w11, w11, w9
10001030c: b900136b    	str	w11, [x27, #0x10]
100010310: 2a0903eb    	mov	w11, w9
100010314: 8b0b02f7    	add	x23, x23, x11
100010318: f9402b6c    	ldr	x12, [x27, #0x50]
10001031c: 8b0b018c    	add	x12, x12, x11
100010320: f140219f    	cmp	x12, #0x8, lsl #12      ; =0x8000
100010324: 5290000d    	mov	w13, #0x8000            ; =32768
100010328: 9a8d318c    	csel	x12, x12, x13, lo
10001032c: f9002b6c    	str	x12, [x27, #0x50]
100010330: 0b0902c9    	add	w9, w22, w9
100010334: 92403936    	and	x22, x9, #0x7fff
100010338: cb0b0108    	sub	x8, x8, x11
10001033c: eb1a015f    	cmp	x10, x26
100010340: 54ffd7a3    	b.lo	0x10000fe34 <miniz_oxide::deflate::core::compress_inner+0x380>
100010344: a9045f68    	stp	x8, x23, [x27, #0x40]
100010348: aa1503e0    	mov	x0, x21
10001034c: aa1c03e1    	mov	x1, x28
100010350: 52800002    	mov	w2, #0x0                ; =0
100010354: 97fff6d3    	bl	0x10000dea0 <miniz_oxide::deflate::core::flush_block>
100010358: 7100041f    	cmp	w0, #0x1
10001035c: 54006ba0    	b.eq	0x1000110d0 <miniz_oxide::deflate::core::compress_inner+0x161c>
100010360: 34ffd681    	cbz	w1, 0x10000fe30 <miniz_oxide::deflate::core::compress_inner+0x37c>
100010364: 140002e4    	b	0x100010ef4 <miniz_oxide::deflate::core::compress_inner+0x1440>
100010368: f94007fc    	ldr	x28, [sp, #0x8]
10001036c: f94017f4    	ldr	x20, [sp, #0x28]
100010370: 52800119    	mov	w25, #0x8               ; =8
100010374: 529fff3a    	mov	w26, #0xfff9            ; =65529
100010378: ca0c01ec    	eor	x12, x15, x12
10001037c: dac0018c    	rbit	x12, x12
100010380: dac0118c    	clz	x12, x12
100010384: 4b16016b    	sub	w11, w11, w22
100010388: 0b4c0d6b    	add	w11, w11, w12, lsr #3
10001038c: 71000d7f    	cmp	w11, #0x3
100010390: 54000423    	b.lo	0x100010414 <miniz_oxide::deflate::core::compress_inner+0x960>
100010394: 12003d4c    	and	w12, w10, #0xffff
100010398: 7140099f    	cmp	w12, #0x2, lsl #12      ; =0x2000
10001039c: 7a432960    	ccmp	w11, #0x3, #0x0, hs
1000103a0: 540003a0    	b.eq	0x100010414 <miniz_oxide::deflate::core::compress_inner+0x960>
1000103a4: 6b0b011f    	cmp	w8, w11
1000103a8: 1a8b3109    	csel	w9, w8, w11, lo
1000103ac: 5100054b    	sub	w11, w10, #0x1
1000103b0: 51000d2a    	sub	w10, w9, #0x3
1000103b4: f940036c    	ldr	x12, [x27]
1000103b8: 92403d8d    	and	x13, x12, #0xffff
1000103bc: 382d6aaa    	strb	w10, [x21, x13]
1000103c0: 1100058d    	add	w13, w12, #0x1
1000103c4: 92403dad    	and	x13, x13, #0xffff
1000103c8: 382d6aab    	strb	w11, [x21, x13]
1000103cc: 1100098d    	add	w13, w12, #0x2
1000103d0: 92403dad    	and	x13, x13, #0xffff
1000103d4: 53083d60    	ubfx	w0, w11, #8, #8
1000103d8: 382d6aa0    	strb	w0, [x21, x13]
1000103dc: 91000d8c    	add	x12, x12, #0x3
1000103e0: f900036c    	str	x12, [x27]
1000103e4: 7940136c    	ldrh	w12, [x27, #0x8]
1000103e8: 386c6aad    	ldrb	w13, [x21, x12]
1000103ec: 12003d6e    	and	w14, w11, #0xffff
1000103f0: 53017dad    	lsr	w13, w13, #1
1000103f4: 321901ad    	orr	w13, w13, #0x80
1000103f8: 382c6aad    	strb	w13, [x21, x12]
1000103fc: 710801df    	cmp	w14, #0x200
100010400: 54000342    	b.hs	0x100010468 <miniz_oxide::deflate::core::compress_inner+0x9b4>
100010404: d000028c    	adrp	x12, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010408: 9125f98c    	add	x12, x12, #0x97e
10001040c: 8b2b218b    	add	x11, x12, w11, uxth
100010410: 1400001a    	b	0x100010478 <miniz_oxide::deflate::core::compress_inner+0x9c4>
100010414: f940036a    	ldr	x10, [x27]
100010418: 92403d4b    	and	x11, x10, #0xffff
10001041c: 382b6aa9    	strb	w9, [x21, x11]
100010420: 9100054a    	add	x10, x10, #0x1
100010424: 7940136b    	ldrh	w11, [x27, #0x8]
100010428: 386b6aac    	ldrb	w12, [x21, x11]
10001042c: f900036a    	str	x10, [x27]
100010430: 53017d8a    	lsr	w10, w12, #1
100010434: 382b6aaa    	strb	w10, [x21, x11]
100010438: 12001d29    	and	w9, w9, #0xff
10001043c: f940336a    	ldr	x10, [x27, #0x60]
100010440: 7869594b    	ldrh	w11, [x10, w9, uxtw #1]
100010444: 1100056b    	add	w11, w11, #0x1
100010448: 7829594b    	strh	w11, [x10, w9, uxtw #1]
10001044c: 52800029    	mov	w9, #0x1                ; =1
100010450: b940176b    	ldr	w11, [x27, #0x14]
100010454: f940036a    	ldr	x10, [x27]
100010458: 7100056b    	subs	w11, w11, #0x1
10001045c: b900176b    	str	w11, [x27, #0x14]
100010460: 54fff521    	b.ne	0x100010304 <miniz_oxide::deflate::core::compress_inner+0x850>
100010464: 17ffffa4    	b	0x1000102f4 <miniz_oxide::deflate::core::compress_inner+0x840>
100010468: 377869cb    	tbnz	w11, #0xf, 0x1000111a0 <miniz_oxide::deflate::core::compress_inner+0x16ec>
10001046c: d000028b    	adrp	x11, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010470: 9123f96b    	add	x11, x11, #0x8fe
100010474: 8b00016b    	add	x11, x11, x0
100010478: 3940016b    	ldrb	w11, [x11]
10001047c: f940336c    	ldr	x12, [x27, #0x60]
100010480: 8b0b058b    	add	x11, x12, x11, lsl #1
100010484: 7944816c    	ldrh	w12, [x11, #0x240]
100010488: 1100058c    	add	w12, w12, #0x1
10001048c: 7904816c    	strh	w12, [x11, #0x240]
100010490: 92401d4a    	and	x10, x10, #0xff
100010494: d000028b    	adrp	x11, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010498: 912df96b    	add	x11, x11, #0xb7e
10001049c: 386a696a    	ldrb	w10, [x11, x10]
1000104a0: 9240114a    	and	x10, x10, #0x1f
1000104a4: f940336b    	ldr	x11, [x27, #0x60]
1000104a8: 8b0a056a    	add	x10, x11, x10, lsl #1
1000104ac: 7944014b    	ldrh	w11, [x10, #0x200]
1000104b0: 1100056b    	add	w11, w11, #0x1
1000104b4: 7904014b    	strh	w11, [x10, #0x200]
1000104b8: b940176b    	ldr	w11, [x27, #0x14]
1000104bc: f940036a    	ldr	x10, [x27]
1000104c0: 7100056b    	subs	w11, w11, #0x1
1000104c4: b900176b    	str	w11, [x27, #0x14]
1000104c8: 54fff1e1    	b.ne	0x100010304 <miniz_oxide::deflate::core::compress_inner+0x850>
1000104cc: 17ffff8a    	b	0x1000102f4 <miniz_oxide::deflate::core::compress_inner+0x840>
1000104d0: f90013ff    	str	xzr, [sp, #0x20]
1000104d4: 17fffddf    	b	0x10000fc50 <miniz_oxide::deflate::core::compress_inner+0x19c>
1000104d8: aa1503e0    	mov	x0, x21
1000104dc: aa1c03e1    	mov	x1, x28
1000104e0: 94000f7c    	bl	0x1000142d0 <miniz_oxide::deflate::stored::compress_stored>
1000104e4: 34005fc0    	cbz	w0, 0x1000110dc <miniz_oxide::deflate::core::compress_inner+0x1628>
1000104e8: a941d381    	ldp	x1, x20, [x28, #0x18]
1000104ec: 14000297    	b	0x100010f48 <miniz_oxide::deflate::core::compress_inner+0x1494>
1000104f0: f9400f88    	ldr	x8, [x28, #0x18]
1000104f4: b40054c8    	cbz	x8, 0x100010f8c <miniz_oxide::deflate::core::compress_inner+0x14d8>
1000104f8: f9001be8    	str	x8, [sp, #0x30]
1000104fc: f9000bf6    	str	x22, [sp, #0x10]
100010500: d2800007    	mov	x7, #0x0                ; =0
100010504: 91006379    	add	x25, x27, #0x18
100010508: f9401394    	ldr	x20, [x28, #0x20]
10001050c: 52802058    	mov	w24, #0x102             ; =258
100010510: 52900016    	mov	w22, #0x8000            ; =32768
100010514: a9446b77    	ldp	x23, x26, [x27, #0x40]
100010518: 3942a768    	ldrb	w8, [x27, #0xa9]
10001051c: f90013e8    	str	x8, [sp, #0x20]
100010520: 528f801e    	mov	w30, #0x7c00            ; =31744
100010524: 29511768    	ldp	w8, w5, [x27, #0x88]
100010528: b9002be8    	str	w8, [sp, #0x28]
10001052c: eb07029f    	cmp	x20, x7
100010530: 54000088    	b.hi	0x100010540 <miniz_oxide::deflate::core::compress_inner+0xa8c>
100010534: b4004cf7    	cbz	x23, 0x100010ed0 <miniz_oxide::deflate::core::compress_inner+0x141c>
100010538: 3942ab68    	ldrb	w8, [x27, #0xaa]
10001053c: 34004ca8    	cbz	w8, 0x100010ed0 <miniz_oxide::deflate::core::compress_inner+0x141c>
100010540: eb070288    	subs	x8, x20, x7
100010544: 54006063    	b.lo	0x100011150 <miniz_oxide::deflate::core::compress_inner+0x169c>
100010548: f9401be9    	ldr	x9, [sp, #0x30]
10001054c: 8b070129    	add	x9, x9, x7
100010550: cb17030a    	sub	x10, x24, x23
100010554: eb08015f    	cmp	x10, x8
100010558: 9a883148    	csel	x8, x10, x8, lo
10001055c: b40004c8    	cbz	x8, 0x1000105f4 <miniz_oxide::deflate::core::compress_inner+0xb40>
100010560: f9402b6a    	ldr	x10, [x27, #0x50]
100010564: 8b17014a    	add	x10, x10, x23
100010568: f100055f    	cmp	x10, #0x1
10001056c: 54000449    	b.ls	0x1000105f4 <miniz_oxide::deflate::core::compress_inner+0xb40>
100010570: f940032b    	ldr	x11, [x25]
100010574: 8b1a02ed    	add	x13, x23, x26
100010578: d10009aa    	sub	x10, x13, #0x2
10001057c: 9240394c    	and	x12, x10, #0x7fff
100010580: 386c696c    	ldrb	w12, [x11, x12]
100010584: 510005ae    	sub	w14, w13, #0x1
100010588: 924039ce    	and	x14, x14, #0x7fff
10001058c: 386e696b    	ldrb	w11, [x11, x14]
100010590: 4a0c156b    	eor	w11, w11, w12, lsl #5
100010594: aa0803ec    	mov	x12, x8
100010598: 1400000d    	b	0x1000105cc <miniz_oxide::deflate::core::compress_inner+0xb18>
10001059c: 531b256b    	ubfiz	w11, w11, #5, #10
1000105a0: 4a0e016b    	eor	w11, w11, w14
1000105a4: 9240394e    	and	x14, x10, #0x7fff
1000105a8: a9423f70    	ldp	x16, x15, [x27, #0x20]
1000105ac: 786b59ef    	ldrh	w15, [x15, w11, uxtw #1]
1000105b0: 782e7a0f    	strh	w15, [x16, x14, lsl #1]
1000105b4: f940176e    	ldr	x14, [x27, #0x28]
1000105b8: 782b59ca    	strh	w10, [x14, w11, uxtw #1]
1000105bc: 910005ad    	add	x13, x13, #0x1
1000105c0: 9100054a    	add	x10, x10, #0x1
1000105c4: f100058c    	subs	x12, x12, #0x1
1000105c8: 54000780    	b.eq	0x1000106b8 <miniz_oxide::deflate::core::compress_inner+0xc04>
1000105cc: 924039ad    	and	x13, x13, #0x7fff
1000105d0: 3840152e    	ldrb	w14, [x9], #0x1
1000105d4: f940032f    	ldr	x15, [x25]
1000105d8: 382d69ee    	strb	w14, [x15, x13]
1000105dc: f10405bf    	cmp	x13, #0x101
1000105e0: 54fffde2    	b.hs	0x10001059c <miniz_oxide::deflate::core::compress_inner+0xae8>
1000105e4: f940032f    	ldr	x15, [x25]
1000105e8: 8b0d01ef    	add	x15, x15, x13
1000105ec: 383669ee    	strb	w14, [x15, x22]
1000105f0: 17ffffeb    	b	0x10001059c <miniz_oxide::deflate::core::compress_inner+0xae8>
1000105f4: b4000688    	cbz	x8, 0x1000106c4 <miniz_oxide::deflate::core::compress_inner+0xc10>
1000105f8: d280000a    	mov	x10, #0x0               ; =0
1000105fc: 8b1a02eb    	add	x11, x23, x26
100010600: 528fffec    	mov	w12, #0x7fff            ; =32767
100010604: 8b0c016c    	add	x12, x11, x12
100010608: 14000004    	b	0x100010618 <miniz_oxide::deflate::core::compress_inner+0xb64>
10001060c: 9100054a    	add	x10, x10, #0x1
100010610: eb0a011f    	cmp	x8, x10
100010614: 54000560    	b.eq	0x1000106c0 <miniz_oxide::deflate::core::compress_inner+0xc0c>
100010618: 386a692d    	ldrb	w13, [x9, x10]
10001061c: 0b0a016e    	add	w14, w11, w10
100010620: 924039ce    	and	x14, x14, #0x7fff
100010624: f940032f    	ldr	x15, [x25]
100010628: 382e69ed    	strb	w13, [x15, x14]
10001062c: f10405df    	cmp	x14, #0x101
100010630: 54000162    	b.hs	0x10001065c <miniz_oxide::deflate::core::compress_inner+0xba8>
100010634: f940032f    	ldr	x15, [x25]
100010638: 8b0e01ee    	add	x14, x15, x14
10001063c: 383669cd    	strb	w13, [x14, x22]
100010640: f9402b6e    	ldr	x14, [x27, #0x50]
100010644: 8b0a02ef    	add	x15, x23, x10
100010648: 8b0e01ee    	add	x14, x15, x14
10001064c: 910005ce    	add	x14, x14, #0x1
100010650: f10009df    	cmp	x14, #0x2
100010654: 54fffdc9    	b.ls	0x10001060c <miniz_oxide::deflate::core::compress_inner+0xb58>
100010658: 14000007    	b	0x100010674 <miniz_oxide::deflate::core::compress_inner+0xbc0>
10001065c: f9402b6e    	ldr	x14, [x27, #0x50]
100010660: 8b0a02ef    	add	x15, x23, x10
100010664: 8b0e01ee    	add	x14, x15, x14
100010668: 910005ce    	add	x14, x14, #0x1
10001066c: f10009df    	cmp	x14, #0x2
100010670: 54fffce9    	b.ls	0x10001060c <miniz_oxide::deflate::core::compress_inner+0xb58>
100010674: 8b0a016e    	add	x14, x11, x10
100010678: d10009ce    	sub	x14, x14, #0x2
10001067c: 924039cf    	and	x15, x14, #0x7fff
100010680: 0b0a0190    	add	w16, w12, w10
100010684: 92403a10    	and	x16, x16, #0x7fff
100010688: a9418371    	ldp	x17, x0, [x27, #0x18]
10001068c: 38706a30    	ldrb	w16, [x17, x16]
100010690: 386f6a31    	ldrb	w17, [x17, x15]
100010694: ca1015ad    	eor	x13, x13, x16, lsl #5
100010698: d3761230    	ubfiz	x16, x17, #10, #5
10001069c: ca1001ad    	eor	x13, x13, x16
1000106a0: f9401770    	ldr	x16, [x27, #0x28]
1000106a4: 786d7a10    	ldrh	w16, [x16, x13, lsl #1]
1000106a8: 782f7810    	strh	w16, [x0, x15, lsl #1]
1000106ac: f940176f    	ldr	x15, [x27, #0x28]
1000106b0: 782d79ee    	strh	w14, [x15, x13, lsl #1]
1000106b4: 17ffffd6    	b	0x10001060c <miniz_oxide::deflate::core::compress_inner+0xb58>
1000106b8: 8b170117    	add	x23, x8, x23
1000106bc: 14000002    	b	0x1000106c4 <miniz_oxide::deflate::core::compress_inner+0xc10>
1000106c0: 8b0a02f7    	add	x23, x23, x10
1000106c4: 8b070107    	add	x7, x8, x7
1000106c8: f9402b68    	ldr	x8, [x27, #0x50]
1000106cc: cb1702c9    	sub	x9, x22, x23
1000106d0: eb09011f    	cmp	x8, x9
1000106d4: 9a89310b    	csel	x11, x8, x9, lo
1000106d8: f9002b6b    	str	x11, [x27, #0x50]
1000106dc: f10406ff    	cmp	x23, #0x101
1000106e0: 54000068    	b.hi	0x1000106ec <miniz_oxide::deflate::core::compress_inner+0xc38>
1000106e4: 3942ab68    	ldrb	w8, [x27, #0xaa]
1000106e8: 34003f48    	cbz	w8, 0x100010ed0 <miniz_oxide::deflate::core::compress_inner+0x141c>
1000106ec: 92403b40    	and	x0, x26, #0x7fff
1000106f0: b9408369    	ldr	w9, [x27, #0x80]
1000106f4: 34000125    	cbz	w5, 0x100010718 <miniz_oxide::deflate::core::compress_inner+0xc64>
1000106f8: aa0503e8    	mov	x8, x5
1000106fc: 36800129    	tbz	w9, #0x10, 0x100010720 <miniz_oxide::deflate::core::compress_inner+0xc6c>
100010700: b5000f0b    	cbnz	x11, 0x1000108e0 <miniz_oxide::deflate::core::compress_inner+0xe2c>
100010704: 5280000a    	mov	w10, #0x0               ; =0
100010708: aa0503e8    	mov	x8, x5
10001070c: 71000d1f    	cmp	w8, #0x3
100010710: 54001ac0    	b.eq	0x100010a68 <miniz_oxide::deflate::core::compress_inner+0xfb4>
100010714: 140000c3    	b	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010718: 37800e29    	tbnz	w9, #0x10, 0x1000108dc <miniz_oxide::deflate::core::compress_inner+0xe28>
10001071c: 52800048    	mov	w8, #0x2                ; =2
100010720: 71040aff    	cmp	w23, #0x102
100010724: 1a9832ec    	csel	w12, w23, w24, lo
100010728: 6b08019f    	cmp	w12, w8
10001072c: 54001749    	b.ls	0x100010a14 <miniz_oxide::deflate::core::compress_inner+0xf60>
100010730: 7100811f    	cmp	w8, #0x20
100010734: 5280038a    	mov	w10, #0x1c              ; =28
100010738: 5280030d    	mov	w13, #0x18              ; =24
10001073c: 9a8a31aa    	csel	x10, x13, x10, lo
100010740: b86a6b2a    	ldr	w10, [x25, x10]
100010744: 71000544    	subs	w4, w10, #0x1
100010748: 54001660    	b.eq	0x100010a14 <miniz_oxide::deflate::core::compress_inner+0xf60>
10001074c: f940032d    	ldr	x13, [x25]
100010750: 2a0803ea    	mov	w10, w8
100010754: 8b0001ae    	add	x14, x13, x0
100010758: 8b0a01cf    	add	x15, x14, x10
10001075c: 785ff1f0    	ldurh	w16, [x15, #-0x1]
100010760: 794001ce    	ldrh	w14, [x14]
100010764: f940136f    	ldr	x15, [x27, #0x20]
100010768: 39416371    	ldrb	w17, [x27, #0x58]
10001076c: 72001e31    	ands	w17, w17, #0xff
100010770: 54001000    	b.eq	0x100010970 <miniz_oxide::deflate::core::compress_inner+0xebc>
100010774: b9001bf1    	str	w17, [sp, #0x18]
100010778: 5280000a    	mov	w10, #0x0               ; =0
10001077c: 92403b43    	and	x3, x26, #0x7fff
100010780: 34001508    	cbz	w8, 0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010784: aa0503f1    	mov	x17, x5
100010788: 2a0803e5    	mov	w5, w8
10001078c: 8b0501a6    	add	x6, x13, x5
100010790: 52800021    	mov	w1, #0x1                ; =1
100010794: 4b040022    	sub	w2, w1, w4
100010798: 786379e3    	ldrh	w3, [x15, x3, lsl #1]
10001079c: 4b030341    	sub	w1, w26, w3
1000107a0: 92403c21    	and	x1, x1, #0xffff
1000107a4: 7100007f    	cmp	w3, #0x0
1000107a8: fa4b1022    	ccmp	x1, x11, #0x2, ne
1000107ac: 54000d48    	b.hi	0x100010954 <miniz_oxide::deflate::core::compress_inner+0xea0>
1000107b0: 92403863    	and	x3, x3, #0x7fff
1000107b4: 8b0300c4    	add	x4, x6, x3
1000107b8: 785ff084    	ldurh	w4, [x4, #-0x1]
1000107bc: 6b10009f    	cmp	w4, w16
1000107c0: 540002e0    	b.eq	0x10001081c <miniz_oxide::deflate::core::compress_inner+0xd68>
1000107c4: 786379e3    	ldrh	w3, [x15, x3, lsl #1]
1000107c8: 4b030341    	sub	w1, w26, w3
1000107cc: 92403c21    	and	x1, x1, #0xffff
1000107d0: 7100007f    	cmp	w3, #0x0
1000107d4: fa4b1022    	ccmp	x1, x11, #0x2, ne
1000107d8: 54000be8    	b.hi	0x100010954 <miniz_oxide::deflate::core::compress_inner+0xea0>
1000107dc: 92403863    	and	x3, x3, #0x7fff
1000107e0: 8b0300c4    	add	x4, x6, x3
1000107e4: 785ff084    	ldurh	w4, [x4, #-0x1]
1000107e8: 6b10009f    	cmp	w4, w16
1000107ec: 54000180    	b.eq	0x10001081c <miniz_oxide::deflate::core::compress_inner+0xd68>
1000107f0: 786379e3    	ldrh	w3, [x15, x3, lsl #1]
1000107f4: 4b030341    	sub	w1, w26, w3
1000107f8: 92403c21    	and	x1, x1, #0xffff
1000107fc: 7100007f    	cmp	w3, #0x0
100010800: fa4b1022    	ccmp	x1, x11, #0x2, ne
100010804: 54000a88    	b.hi	0x100010954 <miniz_oxide::deflate::core::compress_inner+0xea0>
100010808: 92403863    	and	x3, x3, #0x7fff
10001080c: 8b0300c4    	add	x4, x6, x3
100010810: 785ff084    	ldurh	w4, [x4, #-0x1]
100010814: 6b10009f    	cmp	w4, w16
100010818: 540000a1    	b.ne	0x10001082c <miniz_oxide::deflate::core::compress_inner+0xd78>
10001081c: b40009c1    	cbz	x1, 0x100010954 <miniz_oxide::deflate::core::compress_inner+0xea0>
100010820: 786369a4    	ldrh	w4, [x13, x3]
100010824: 6b0e009f    	cmp	w4, w14
100010828: 540000a0    	b.eq	0x10001083c <miniz_oxide::deflate::core::compress_inner+0xd88>
10001082c: 11000442    	add	w2, w2, #0x1
100010830: 7100045f    	cmp	w2, #0x1
100010834: 54fffb21    	b.ne	0x100010798 <miniz_oxide::deflate::core::compress_inner+0xce4>
100010838: 14000047    	b	0x100010954 <miniz_oxide::deflate::core::compress_inner+0xea0>
10001083c: f90003e7    	str	x7, [sp]
100010840: aa1403fe    	mov	x30, x20
100010844: b9401be6    	ldr	w6, [sp, #0x18]
100010848: 52800044    	mov	w4, #0x2                ; =2
10001084c: 0b040007    	add	w7, w0, w4
100010850: 0b040074    	add	w20, w3, w4
100010854: 924038e7    	and	x7, x7, #0x7fff
100010858: f86769a7    	ldr	x7, [x13, x7]
10001085c: 92403a94    	and	x20, x20, #0x7fff
100010860: f87469b4    	ldr	x20, [x13, x20]
100010864: eb1400ff    	cmp	x7, x20
100010868: 540000a1    	b.ne	0x10001087c <miniz_oxide::deflate::core::compress_inner+0xdc8>
10001086c: 91002084    	add	x4, x4, #0x8
100010870: 710004c6    	subs	w6, w6, #0x1
100010874: 54fffec1    	b.ne	0x10001084c <miniz_oxide::deflate::core::compress_inner+0xd98>
100010878: 14000070    	b	0x100010a38 <miniz_oxide::deflate::core::compress_inner+0xf84>
10001087c: ca070286    	eor	x6, x20, x7
100010880: dac000c6    	rbit	x6, x6
100010884: dac010c6    	clz	x6, x6
100010888: d343fcc6    	lsr	x6, x6, #3
10001088c: 8b0400c7    	add	x7, x6, x4
100010890: eb0500ff    	cmp	x7, x5
100010894: aa1e03f4    	mov	x20, x30
100010898: f94003e7    	ldr	x7, [sp]
10001089c: 528f801e    	mov	w30, #0x7c00            ; =31744
1000108a0: 54000169    	b.ls	0x1000108cc <miniz_oxide::deflate::core::compress_inner+0xe18>
1000108a4: 0b0400ca    	add	w10, w6, w4
1000108a8: 6b0c015f    	cmp	w10, w12
1000108ac: 1a8c3148    	csel	w8, w10, w12, lo
1000108b0: 6b0a019f    	cmp	w12, w10
1000108b4: 54003049    	b.ls	0x100010ebc <miniz_oxide::deflate::core::compress_inner+0x1408>
1000108b8: ab28400a    	adds	x10, x0, w8, uxtw
1000108bc: 1a9f07f0    	cset	w16, ne
1000108c0: cb10014a    	sub	x10, x10, x16
1000108c4: 786a69b0    	ldrh	w16, [x13, x10]
1000108c8: aa0103ea    	mov	x10, x1
1000108cc: 4b0203e4    	neg	w4, w2
1000108d0: aa1103e5    	mov	x5, x17
1000108d4: 35fff562    	cbnz	w2, 0x100010780 <miniz_oxide::deflate::core::compress_inner+0xccc>
1000108d8: 14000062    	b	0x100010a60 <miniz_oxide::deflate::core::compress_inner+0xfac>
1000108dc: b400044b    	cbz	x11, 0x100010964 <miniz_oxide::deflate::core::compress_inner+0xeb0>
1000108e0: 8b0002e1    	add	x1, x23, x0
1000108e4: eb00003f    	cmp	x1, x0
1000108e8: 54004403    	b.lo	0x100011168 <miniz_oxide::deflate::core::compress_inner+0x16b4>
1000108ec: 52902068    	mov	w8, #0x8103             ; =33027
1000108f0: eb08003f    	cmp	x1, x8
1000108f4: 540043a2    	b.hs	0x100011168 <miniz_oxide::deflate::core::compress_inner+0x16b4>
1000108f8: b4000217    	cbz	x23, 0x100010938 <miniz_oxide::deflate::core::compress_inner+0xe84>
1000108fc: d2800008    	mov	x8, #0x0                ; =0
100010900: 5100074a    	sub	w10, w26, #0x1
100010904: 9240394a    	and	x10, x10, #0x7fff
100010908: f940032b    	ldr	x11, [x25]
10001090c: 386a696a    	ldrb	w10, [x11, x10]
100010910: 8b00016b    	add	x11, x11, x0
100010914: 3868696c    	ldrb	w12, [x11, x8]
100010918: 6b0a019f    	cmp	w12, w10
10001091c: 540000a1    	b.ne	0x100010930 <miniz_oxide::deflate::core::compress_inner+0xe7c>
100010920: 91000508    	add	x8, x8, #0x1
100010924: eb0802ff    	cmp	x23, x8
100010928: 54ffff61    	b.ne	0x100010914 <miniz_oxide::deflate::core::compress_inner+0xe60>
10001092c: aa1703e8    	mov	x8, x23
100010930: 7100091f    	cmp	w8, #0x2
100010934: 54000088    	b.hi	0x100010944 <miniz_oxide::deflate::core::compress_inner+0xe90>
100010938: 52800008    	mov	w8, #0x0                ; =0
10001093c: 5280000a    	mov	w10, #0x0               ; =0
100010940: 14000038    	b	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010944: 5280002a    	mov	w10, #0x1               ; =1
100010948: 71000d1f    	cmp	w8, #0x3
10001094c: 540008e0    	b.eq	0x100010a68 <miniz_oxide::deflate::core::compress_inner+0xfb4>
100010950: 14000034    	b	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010954: aa1103e5    	mov	x5, x17
100010958: 71000d1f    	cmp	w8, #0x3
10001095c: 54000860    	b.eq	0x100010a68 <miniz_oxide::deflate::core::compress_inner+0xfb4>
100010960: 14000030    	b	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010964: 5280000a    	mov	w10, #0x0               ; =0
100010968: 52800048    	mov	w8, #0x2                ; =2
10001096c: 1400002d    	b	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010970: 8b0a01aa    	add	x10, x13, x10
100010974: 92403b51    	and	x17, x26, #0x7fff
100010978: 787179f1    	ldrh	w17, [x15, x17, lsl #1]
10001097c: 4b110341    	sub	w1, w26, w17
100010980: 92403c21    	and	x1, x1, #0xffff
100010984: 7100023f    	cmp	w17, #0x0
100010988: fa4b1022    	ccmp	x1, x11, #0x2, ne
10001098c: 54000448    	b.hi	0x100010a14 <miniz_oxide::deflate::core::compress_inner+0xf60>
100010990: 92403a31    	and	x17, x17, #0x7fff
100010994: 8b110142    	add	x2, x10, x17
100010998: 785ff042    	ldurh	w2, [x2, #-0x1]
10001099c: 6b10005f    	cmp	w2, w16
1000109a0: 540002e0    	b.eq	0x1000109fc <miniz_oxide::deflate::core::compress_inner+0xf48>
1000109a4: 787179f1    	ldrh	w17, [x15, x17, lsl #1]
1000109a8: 4b110341    	sub	w1, w26, w17
1000109ac: 92403c21    	and	x1, x1, #0xffff
1000109b0: 7100023f    	cmp	w17, #0x0
1000109b4: fa4b1022    	ccmp	x1, x11, #0x2, ne
1000109b8: 540002e8    	b.hi	0x100010a14 <miniz_oxide::deflate::core::compress_inner+0xf60>
1000109bc: 92403a31    	and	x17, x17, #0x7fff
1000109c0: 8b110142    	add	x2, x10, x17
1000109c4: 785ff042    	ldurh	w2, [x2, #-0x1]
1000109c8: 6b10005f    	cmp	w2, w16
1000109cc: 54000180    	b.eq	0x1000109fc <miniz_oxide::deflate::core::compress_inner+0xf48>
1000109d0: 787179f1    	ldrh	w17, [x15, x17, lsl #1]
1000109d4: 4b110341    	sub	w1, w26, w17
1000109d8: 92403c21    	and	x1, x1, #0xffff
1000109dc: 7100023f    	cmp	w17, #0x0
1000109e0: fa4b1022    	ccmp	x1, x11, #0x2, ne
1000109e4: 540003c8    	b.hi	0x100010a5c <miniz_oxide::deflate::core::compress_inner+0xfa8>
1000109e8: 92403a31    	and	x17, x17, #0x7fff
1000109ec: 8b110142    	add	x2, x10, x17
1000109f0: 785ff042    	ldurh	w2, [x2, #-0x1]
1000109f4: 6b10005f    	cmp	w2, w16
1000109f8: 540000a1    	b.ne	0x100010a0c <miniz_oxide::deflate::core::compress_inner+0xf58>
1000109fc: b40000c1    	cbz	x1, 0x100010a14 <miniz_oxide::deflate::core::compress_inner+0xf60>
100010a00: 787169a2    	ldrh	w2, [x13, x17]
100010a04: 6b0e005f    	cmp	w2, w14
100010a08: 54000200    	b.eq	0x100010a48 <miniz_oxide::deflate::core::compress_inner+0xf94>
100010a0c: 71000484    	subs	w4, w4, #0x1
100010a10: 54fffb41    	b.ne	0x100010978 <miniz_oxide::deflate::core::compress_inner+0xec4>
100010a14: 5280000a    	mov	w10, #0x0               ; =0
100010a18: 71000d1f    	cmp	w8, #0x3
100010a1c: 54000260    	b.eq	0x100010a68 <miniz_oxide::deflate::core::compress_inner+0xfb4>
100010a20: 36880069    	tbz	w9, #0x11, 0x100010a2c <miniz_oxide::deflate::core::compress_inner+0xf78>
100010a24: 7100191f    	cmp	w8, #0x6
100010a28: 540002c3    	b.lo	0x100010a80 <miniz_oxide::deflate::core::compress_inner+0xfcc>
100010a2c: eb2a401f    	cmp	x0, w10, uxtw
100010a30: 540009c1    	b.ne	0x100010b68 <miniz_oxide::deflate::core::compress_inner+0x10b4>
100010a34: 14000013    	b	0x100010a80 <miniz_oxide::deflate::core::compress_inner+0xfcc>
100010a38: aa1e03f4    	mov	x20, x30
100010a3c: f94003e7    	ldr	x7, [sp]
100010a40: 528f801e    	mov	w30, #0x7c00            ; =31744
100010a44: aa1103e5    	mov	x5, x17
100010a48: aa0c03e8    	mov	x8, x12
100010a4c: aa0103ea    	mov	x10, x1
100010a50: 71000d1f    	cmp	w8, #0x3
100010a54: 540000a0    	b.eq	0x100010a68 <miniz_oxide::deflate::core::compress_inner+0xfb4>
100010a58: 17fffff2    	b	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010a5c: 5280000a    	mov	w10, #0x0               ; =0
100010a60: 71000d1f    	cmp	w8, #0x3
100010a64: 54fffde1    	b.ne	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010a68: 378800c9    	tbnz	w9, #0x11, 0x100010a80 <miniz_oxide::deflate::core::compress_inner+0xfcc>
100010a6c: 7140095f    	cmp	w10, #0x2, lsl #12      ; =0x2000
100010a70: 54000082    	b.hs	0x100010a80 <miniz_oxide::deflate::core::compress_inner+0xfcc>
100010a74: 52800068    	mov	w8, #0x3                ; =3
100010a78: eb2a401f    	cmp	x0, w10, uxtw
100010a7c: 54000761    	b.ne	0x100010b68 <miniz_oxide::deflate::core::compress_inner+0x10b4>
100010a80: b940136b    	ldr	w11, [x27, #0x10]
100010a84: f9400369    	ldr	x9, [x27]
100010a88: 340017e5    	cbz	w5, 0x100010d84 <miniz_oxide::deflate::core::compress_inner+0x12d0>
100010a8c: f9403368    	ldr	x8, [x27, #0x60]
100010a90: 0b05016d    	add	w13, w11, w5
100010a94: b9402bea    	ldr	w10, [sp, #0x28]
100010a98: 5100054b    	sub	w11, w10, #0x1
100010a9c: 51000caa    	sub	w10, w5, #0x3
100010aa0: 92403d2c    	and	x12, x9, #0xffff
100010aa4: 382c6aaa    	strb	w10, [x21, x12]
100010aa8: 1100052c    	add	w12, w9, #0x1
100010aac: 92403d8c    	and	x12, x12, #0xffff
100010ab0: 382c6aab    	strb	w11, [x21, x12]
100010ab4: 1100092c    	add	w12, w9, #0x2
100010ab8: 53087d6e    	lsr	w14, w11, #8
100010abc: 92403d8c    	and	x12, x12, #0xffff
100010ac0: 382c6aae    	strb	w14, [x21, x12]
100010ac4: 7940136c    	ldrh	w12, [x27, #0x8]
100010ac8: 386c6aae    	ldrb	w14, [x21, x12]
100010acc: 53017dce    	lsr	w14, w14, #1
100010ad0: 321901ce    	orr	w14, w14, #0x80
100010ad4: 382c6aae    	strb	w14, [x21, x12]
100010ad8: 91000d2c    	add	x12, x9, #0x3
100010adc: f900036c    	str	x12, [x27]
100010ae0: b940176e    	ldr	w14, [x27, #0x14]
100010ae4: 710005ce    	subs	w14, w14, #0x1
100010ae8: 29023b6d    	stp	w13, w14, [x27, #0x10]
100010aec: 540000a1    	b.ne	0x100010b00 <miniz_oxide::deflate::core::compress_inner+0x104c>
100010af0: 5280010d    	mov	w13, #0x8               ; =8
100010af4: b900176d    	str	w13, [x27, #0x14]
100010af8: 91001129    	add	x9, x9, #0x4
100010afc: a9003369    	stp	x9, x12, [x27]
100010b00: d0000289    	adrp	x9, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010b04: 9125f929    	add	x9, x9, #0x97e
100010b08: 8b2b4129    	add	x9, x9, w11, uxtw
100010b0c: 5308396c    	ubfx	w12, w11, #8, #7
100010b10: d000028d    	adrp	x13, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010b14: 9123f9ad    	add	x13, x13, #0x8fe
100010b18: 8b0c01ac    	add	x12, x13, x12
100010b1c: 7108017f    	cmp	w11, #0x200
100010b20: 9a8c3129    	csel	x9, x9, x12, lo
100010b24: 39400129    	ldrb	w9, [x9]
100010b28: 8b090509    	add	x9, x8, x9, lsl #1
100010b2c: 7944812b    	ldrh	w11, [x9, #0x240]
100010b30: 1100056b    	add	w11, w11, #0x1
100010b34: 7904812b    	strh	w11, [x9, #0x240]
100010b38: 92401d49    	and	x9, x10, #0xff
100010b3c: d000028a    	adrp	x10, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010b40: 912df94a    	add	x10, x10, #0xb7e
100010b44: 38696949    	ldrb	w9, [x10, x9]
100010b48: 92401129    	and	x9, x9, #0x1f
100010b4c: 8b090508    	add	x8, x8, x9, lsl #1
100010b50: 79440109    	ldrh	w9, [x8, #0x200]
100010b54: 11000529    	add	w9, w9, #0x1
100010b58: 79040109    	strh	w9, [x8, #0x200]
100010b5c: 510004a9    	sub	w9, w5, #0x1
100010b60: 52800005    	mov	w5, #0x0                ; =0
100010b64: 140000a1    	b	0x100010de8 <miniz_oxide::deflate::core::compress_inner+0x1334>
100010b68: 34000965    	cbz	w5, 0x100010c94 <miniz_oxide::deflate::core::compress_inner+0x11e0>
100010b6c: b940136b    	ldr	w11, [x27, #0x10]
100010b70: f9400369    	ldr	x9, [x27]
100010b74: 6b05011f    	cmp	w8, w5
100010b78: 54fff8a9    	b.ls	0x100010a8c <miniz_oxide::deflate::core::compress_inner+0xfd8>
100010b7c: f940336c    	ldr	x12, [x27, #0x60]
100010b80: 1100056d    	add	w13, w11, #0x1
100010b84: 92403d2b    	and	x11, x9, #0xffff
100010b88: f94013f0    	ldr	x16, [sp, #0x20]
100010b8c: 382b6ab0    	strb	w16, [x21, x11]
100010b90: 9100052b    	add	x11, x9, #0x1
100010b94: f900036b    	str	x11, [x27]
100010b98: 7940136e    	ldrh	w14, [x27, #0x8]
100010b9c: 386e6aaf    	ldrb	w15, [x21, x14]
100010ba0: 53017def    	lsr	w15, w15, #1
100010ba4: 382e6aaf    	strb	w15, [x21, x14]
100010ba8: b940176e    	ldr	w14, [x27, #0x14]
100010bac: 710005ce    	subs	w14, w14, #0x1
100010bb0: 29023b6d    	stp	w13, w14, [x27, #0x10]
100010bb4: 540000a1    	b.ne	0x100010bc8 <miniz_oxide::deflate::core::compress_inner+0x1114>
100010bb8: 5280010d    	mov	w13, #0x8               ; =8
100010bbc: b900176d    	str	w13, [x27, #0x14]
100010bc0: 91000929    	add	x9, x9, #0x2
100010bc4: a9002f69    	stp	x9, x11, [x27]
100010bc8: 78707989    	ldrh	w9, [x12, x16, lsl #1]
100010bcc: 11000529    	add	w9, w9, #0x1
100010bd0: 78307989    	strh	w9, [x12, x16, lsl #1]
100010bd4: 7102011f    	cmp	w8, #0x80
100010bd8: 54001643    	b.lo	0x100010ea0 <miniz_oxide::deflate::core::compress_inner+0x13ec>
100010bdc: f9403369    	ldr	x9, [x27, #0x60]
100010be0: 5100054b    	sub	w11, w10, #0x1
100010be4: 51000d0a    	sub	w10, w8, #0x3
100010be8: f940036c    	ldr	x12, [x27]
100010bec: 92403d8d    	and	x13, x12, #0xffff
100010bf0: 382d6aaa    	strb	w10, [x21, x13]
100010bf4: 1100058d    	add	w13, w12, #0x1
100010bf8: 92403dad    	and	x13, x13, #0xffff
100010bfc: 382d6aab    	strb	w11, [x21, x13]
100010c00: 1100098d    	add	w13, w12, #0x2
100010c04: 53087d6e    	lsr	w14, w11, #8
100010c08: 92403dad    	and	x13, x13, #0xffff
100010c0c: 382d6aae    	strb	w14, [x21, x13]
100010c10: 7940136d    	ldrh	w13, [x27, #0x8]
100010c14: 386d6aae    	ldrb	w14, [x21, x13]
100010c18: 53017dce    	lsr	w14, w14, #1
100010c1c: 321901ce    	orr	w14, w14, #0x80
100010c20: 382d6aae    	strb	w14, [x21, x13]
100010c24: 29423b6d    	ldp	w13, w14, [x27, #0x10]
100010c28: 0b0801af    	add	w15, w13, w8
100010c2c: 91000d8d    	add	x13, x12, #0x3
100010c30: f900036d    	str	x13, [x27]
100010c34: 710005ce    	subs	w14, w14, #0x1
100010c38: 29023b6f    	stp	w15, w14, [x27, #0x10]
100010c3c: 540000a1    	b.ne	0x100010c50 <miniz_oxide::deflate::core::compress_inner+0x119c>
100010c40: 5280010e    	mov	w14, #0x8               ; =8
100010c44: b900176e    	str	w14, [x27, #0x14]
100010c48: 9100118c    	add	x12, x12, #0x4
100010c4c: a900376c    	stp	x12, x13, [x27]
100010c50: 52800005    	mov	w5, #0x0                ; =0
100010c54: d000028c    	adrp	x12, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010c58: 9125f98c    	add	x12, x12, #0x97e
100010c5c: 8b2b418c    	add	x12, x12, w11, uxtw
100010c60: 7108017f    	cmp	w11, #0x200
100010c64: 5308396b    	ubfx	w11, w11, #8, #7
100010c68: d000028d    	adrp	x13, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010c6c: 9123f9ad    	add	x13, x13, #0x8fe
100010c70: 8b0b01ab    	add	x11, x13, x11
100010c74: 9a8b318b    	csel	x11, x12, x11, lo
100010c78: 3940016b    	ldrb	w11, [x11]
100010c7c: 8b0b052b    	add	x11, x9, x11, lsl #1
100010c80: 7944816c    	ldrh	w12, [x11, #0x240]
100010c84: 1100058c    	add	w12, w12, #0x1
100010c88: 7904816c    	strh	w12, [x11, #0x240]
100010c8c: 92401d4a    	and	x10, x10, #0xff
100010c90: 14000031    	b	0x100010d54 <miniz_oxide::deflate::core::compress_inner+0x12a0>
100010c94: 3400074a    	cbz	w10, 0x100010d7c <miniz_oxide::deflate::core::compress_inner+0x12c8>
100010c98: 3942af6b    	ldrb	w11, [x27, #0xab]
100010c9c: 36000fcb    	tbz	w11, #0x0, 0x100010e94 <miniz_oxide::deflate::core::compress_inner+0x13e0>
100010ca0: f9403369    	ldr	x9, [x27, #0x60]
100010ca4: 5100054c    	sub	w12, w10, #0x1
100010ca8: 51000d0b    	sub	w11, w8, #0x3
100010cac: f940036d    	ldr	x13, [x27]
100010cb0: 92403dae    	and	x14, x13, #0xffff
100010cb4: 382e6aab    	strb	w11, [x21, x14]
100010cb8: 110005ae    	add	w14, w13, #0x1
100010cbc: 92403dce    	and	x14, x14, #0xffff
100010cc0: 382e6aac    	strb	w12, [x21, x14]
100010cc4: 110009ae    	add	w14, w13, #0x2
100010cc8: 53087d8f    	lsr	w15, w12, #8
100010ccc: 92403dce    	and	x14, x14, #0xffff
100010cd0: 382e6aaf    	strb	w15, [x21, x14]
100010cd4: 7940136e    	ldrh	w14, [x27, #0x8]
100010cd8: 386e6aaf    	ldrb	w15, [x21, x14]
100010cdc: 53017def    	lsr	w15, w15, #1
100010ce0: 321901ef    	orr	w15, w15, #0x80
100010ce4: 382e6aaf    	strb	w15, [x21, x14]
100010ce8: 29423f6e    	ldp	w14, w15, [x27, #0x10]
100010cec: 0b0801d0    	add	w16, w14, w8
100010cf0: 91000dae    	add	x14, x13, #0x3
100010cf4: f900036e    	str	x14, [x27]
100010cf8: 710005ef    	subs	w15, w15, #0x1
100010cfc: 29023f70    	stp	w16, w15, [x27, #0x10]
100010d00: 540000a1    	b.ne	0x100010d14 <miniz_oxide::deflate::core::compress_inner+0x1260>
100010d04: 5280010f    	mov	w15, #0x8               ; =8
100010d08: b900176f    	str	w15, [x27, #0x14]
100010d0c: 910011ad    	add	x13, x13, #0x4
100010d10: a9003b6d    	stp	x13, x14, [x27]
100010d14: 52800005    	mov	w5, #0x0                ; =0
100010d18: 7108055f    	cmp	w10, #0x201
100010d1c: d000028a    	adrp	x10, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010d20: 9125f94a    	add	x10, x10, #0x97e
100010d24: 8b2c414a    	add	x10, x10, w12, uxtw
100010d28: 5308398c    	ubfx	w12, w12, #8, #7
100010d2c: d000028d    	adrp	x13, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010d30: 9123f9ad    	add	x13, x13, #0x8fe
100010d34: 8b0c01ac    	add	x12, x13, x12
100010d38: 9a8c314a    	csel	x10, x10, x12, lo
100010d3c: 3940014a    	ldrb	w10, [x10]
100010d40: 8b0a052a    	add	x10, x9, x10, lsl #1
100010d44: 7944814c    	ldrh	w12, [x10, #0x240]
100010d48: 1100058c    	add	w12, w12, #0x1
100010d4c: 7904814c    	strh	w12, [x10, #0x240]
100010d50: 92401d6a    	and	x10, x11, #0xff
100010d54: d000028b    	adrp	x11, 0x100062000 <zlib_rs::crc32::braid::CRC32_WORD_TABLE+0x28f8>
100010d58: 912df96b    	add	x11, x11, #0xb7e
100010d5c: 386a696a    	ldrb	w10, [x11, x10]
100010d60: 9240114a    	and	x10, x10, #0x1f
100010d64: 8b0a0529    	add	x9, x9, x10, lsl #1
100010d68: 7944012a    	ldrh	w10, [x9, #0x200]
100010d6c: 1100054a    	add	w10, w10, #0x1
100010d70: 7904012a    	strh	w10, [x9, #0x200]
100010d74: aa0803e9    	mov	x9, x8
100010d78: 1400001c    	b	0x100010de8 <miniz_oxide::deflate::core::compress_inner+0x1334>
100010d7c: b940136b    	ldr	w11, [x27, #0x10]
100010d80: f9400369    	ldr	x9, [x27]
100010d84: f9403368    	ldr	x8, [x27, #0x60]
100010d88: f9400f6a    	ldr	x10, [x27, #0x18]
100010d8c: 3860694a    	ldrb	w10, [x10, x0]
100010d90: 1100056c    	add	w12, w11, #0x1
100010d94: 92403d2b    	and	x11, x9, #0xffff
100010d98: 382b6aaa    	strb	w10, [x21, x11]
100010d9c: 7940136b    	ldrh	w11, [x27, #0x8]
100010da0: 386b6aad    	ldrb	w13, [x21, x11]
100010da4: 53017dad    	lsr	w13, w13, #1
100010da8: 382b6aad    	strb	w13, [x21, x11]
100010dac: 9100052b    	add	x11, x9, #0x1
100010db0: f900036b    	str	x11, [x27]
100010db4: b940176d    	ldr	w13, [x27, #0x14]
100010db8: 710005ad    	subs	w13, w13, #0x1
100010dbc: 2902376c    	stp	w12, w13, [x27, #0x10]
100010dc0: 540000a1    	b.ne	0x100010dd4 <miniz_oxide::deflate::core::compress_inner+0x1320>
100010dc4: 5280010c    	mov	w12, #0x8               ; =8
100010dc8: b900176c    	str	w12, [x27, #0x14]
100010dcc: 91000929    	add	x9, x9, #0x2
100010dd0: a9002f69    	stp	x9, x11, [x27]
100010dd4: 52800005    	mov	w5, #0x0                ; =0
100010dd8: 786a7909    	ldrh	w9, [x8, x10, lsl #1]
100010ddc: 11000529    	add	w9, w9, #0x1
100010de0: 782a7909    	strh	w9, [x8, x10, lsl #1]
100010de4: 52800029    	mov	w9, #0x1                ; =1
100010de8: 2a0903e8    	mov	w8, w9
100010dec: 8b08035a    	add	x26, x26, x8
100010df0: cb0802f7    	sub	x23, x23, x8
100010df4: f9402b69    	ldr	x9, [x27, #0x50]
100010df8: 8b080128    	add	x8, x9, x8
100010dfc: f140211f    	cmp	x8, #0x8, lsl #12       ; =0x8000
100010e00: 9a963108    	csel	x8, x8, x22, lo
100010e04: f9002b68    	str	x8, [x27, #0x50]
100010e08: f9400368    	ldr	x8, [x27]
100010e0c: b9401369    	ldr	w9, [x27, #0x10]
100010e10: 6b1e013f    	cmp	w9, w30
100010e14: 54000149    	b.ls	0x100010e3c <miniz_oxide::deflate::core::compress_inner+0x1388>
100010e18: 529fff0a    	mov	w10, #0xfff8            ; =65528
100010e1c: eb0a011f    	cmp	x8, x10
100010e20: 54000148    	b.hi	0x100010e48 <miniz_oxide::deflate::core::compress_inner+0x1394>
100010e24: 52800e6a    	mov	w10, #0x73              ; =115
100010e28: 9b0a7d08    	mul	x8, x8, x10
100010e2c: d347fd08    	lsr	x8, x8, #7
100010e30: eb09011f    	cmp	x8, x9
100010e34: 54ffb7c3    	b.lo	0x10001052c <miniz_oxide::deflate::core::compress_inner+0xa78>
100010e38: 14000004    	b	0x100010e48 <miniz_oxide::deflate::core::compress_inner+0x1394>
100010e3c: 529fff09    	mov	w9, #0xfff8             ; =65528
100010e40: eb09011f    	cmp	x8, x9
100010e44: 54ffb749    	b.ls	0x10001052c <miniz_oxide::deflate::core::compress_inner+0xa78>
100010e48: aa0503f6    	mov	x22, x5
100010e4c: aa1403f8    	mov	x24, x20
100010e50: aa0703f4    	mov	x20, x7
100010e54: f9003767    	str	x7, [x27, #0x68]
100010e58: a9046b77    	stp	x23, x26, [x27, #0x40]
100010e5c: aa1503e0    	mov	x0, x21
100010e60: aa1c03e1    	mov	x1, x28
100010e64: 52800002    	mov	w2, #0x0                ; =0
100010e68: 97fff40e    	bl	0x10000dea0 <miniz_oxide::deflate::core::flush_block>
100010e6c: 7100041f    	cmp	w0, #0x1
100010e70: 54000520    	b.eq	0x100010f14 <miniz_oxide::deflate::core::compress_inner+0x1460>
100010e74: aa1403e7    	mov	x7, x20
100010e78: aa1803f4    	mov	x20, x24
100010e7c: 52802058    	mov	w24, #0x102             ; =258
100010e80: 528f801e    	mov	w30, #0x7c00            ; =31744
100010e84: aa1603e5    	mov	x5, x22
100010e88: 52900016    	mov	w22, #0x8000            ; =32768
100010e8c: 34ffb501    	cbz	w1, 0x10001052c <miniz_oxide::deflate::core::compress_inner+0xa78>
100010e90: 14000026    	b	0x100010f28 <miniz_oxide::deflate::core::compress_inner+0x1474>
100010e94: 3787f069    	tbnz	w9, #0x10, 0x100010ca0 <miniz_oxide::deflate::core::compress_inner+0x11ec>
100010e98: 7102011f    	cmp	w8, #0x80
100010e9c: 54fff022    	b.hs	0x100010ca0 <miniz_oxide::deflate::core::compress_inner+0x11ec>
100010ea0: f9400329    	ldr	x9, [x25]
100010ea4: 38606929    	ldrb	w9, [x9, x0]
100010ea8: f90013e9    	str	x9, [sp, #0x20]
100010eac: 52800029    	mov	w9, #0x1                ; =1
100010eb0: aa0803e5    	mov	x5, x8
100010eb4: b9002bea    	str	w10, [sp, #0x28]
100010eb8: 17ffffcc    	b	0x100010de8 <miniz_oxide::deflate::core::compress_inner+0x1334>
100010ebc: aa0103ea    	mov	x10, x1
100010ec0: aa1103e5    	mov	x5, x17
100010ec4: 71000d1f    	cmp	w8, #0x3
100010ec8: 54ffdd00    	b.eq	0x100010a68 <miniz_oxide::deflate::core::compress_inner+0xfb4>
100010ecc: 17fffed5    	b	0x100010a20 <miniz_oxide::deflate::core::compress_inner+0xf6c>
100010ed0: f9003767    	str	x7, [x27, #0x68]
100010ed4: a9046b77    	stp	x23, x26, [x27, #0x40]
100010ed8: f94013e8    	ldr	x8, [sp, #0x20]
100010edc: 3902a768    	strb	w8, [x27, #0xa9]
100010ee0: b9402be8    	ldr	w8, [sp, #0x28]
100010ee4: 29111768    	stp	w8, w5, [x27, #0x88]
100010ee8: f9400bf6    	ldr	x22, [sp, #0x10]
100010eec: f9401be1    	ldr	x1, [sp, #0x30]
100010ef0: 14000016    	b	0x100010f48 <miniz_oxide::deflate::core::compress_inner+0x1494>
100010ef4: f9400bf6    	ldr	x22, [sp, #0x10]
100010ef8: f90002d8    	str	x24, [x22]
100010efc: 7100003f    	cmp	w1, #0x0
100010f00: 14000010    	b	0x100010f40 <miniz_oxide::deflate::core::compress_inner+0x148c>
100010f04: 12800008    	mov	w8, #-0x1               ; =-1
100010f08: b900a768    	str	w8, [x27, #0xa4]
100010f0c: f9003778    	str	x24, [x27, #0x68]
100010f10: 14000073    	b	0x1000110dc <miniz_oxide::deflate::core::compress_inner+0x1628>
100010f14: f94013e8    	ldr	x8, [sp, #0x20]
100010f18: 3902a768    	strb	w8, [x27, #0xa9]
100010f1c: b9402be8    	ldr	w8, [sp, #0x28]
100010f20: 29115b68    	stp	w8, w22, [x27, #0x88]
100010f24: 1400006e    	b	0x1000110dc <miniz_oxide::deflate::core::compress_inner+0x1628>
100010f28: f94013e8    	ldr	x8, [sp, #0x20]
100010f2c: 3902a768    	strb	w8, [x27, #0xa9]
100010f30: b9402be8    	ldr	w8, [sp, #0x28]
100010f34: 29111768    	stp	w8, w5, [x27, #0x88]
100010f38: 7100003f    	cmp	w1, #0x0
100010f3c: f9400bf6    	ldr	x22, [sp, #0x10]
100010f40: f9401be1    	ldr	x1, [sp, #0x30]
100010f44: 54000ccd    	b.le	0x1000110dc <miniz_oxide::deflate::core::compress_inner+0x1628>
100010f48: b4000221    	cbz	x1, 0x100010f8c <miniz_oxide::deflate::core::compress_inner+0x14d8>
100010f4c: 39420768    	ldrb	w8, [x27, #0x81]
100010f50: 721c051f    	tst	w8, #0x30
100010f54: 540001e0    	b.eq	0x100010f90 <miniz_oxide::deflate::core::compress_inner+0x14dc>
100010f58: f94002c2    	ldr	x2, [x22]
100010f5c: eb14005f    	cmp	x2, x20
100010f60: 540010c8    	b.hi	0x100011178 <miniz_oxide::deflate::core::compress_inner+0x16c4>
100010f64: b9409b68    	ldr	w8, [x27, #0x98]
100010f68: b9003fe8    	str	w8, [sp, #0x3c]
100010f6c: 9100f3e0    	add	x0, sp, #0x3c
100010f70: 94000e69    	bl	0x100014914 <<adler2::Adler32>::write_slice>
100010f74: b9403fe8    	ldr	w8, [sp, #0x3c]
100010f78: b9009b68    	str	w8, [x27, #0x98]
100010f7c: a941a788    	ldp	x8, x9, [x28, #0x18]
100010f80: f100011f    	cmp	x8, #0x0
100010f84: 9a8903f4    	csel	x20, xzr, x9, eq
100010f88: 14000002    	b	0x100010f90 <miniz_oxide::deflate::core::compress_inner+0x14dc>
100010f8c: d2800014    	mov	x20, #0x0               ; =0
100010f90: 3942ab62    	ldrb	w2, [x27, #0xaa]
100010f94: 340003c2    	cbz	w2, 0x10001100c <miniz_oxide::deflate::core::compress_inner+0x1558>
100010f98: f9403768    	ldr	x8, [x27, #0x68]
100010f9c: eb08029f    	cmp	x20, x8
100010fa0: 54000361    	b.ne	0x10001100c <miniz_oxide::deflate::core::compress_inner+0x1558>
100010fa4: b9409768    	ldr	w8, [x27, #0x94]
100010fa8: 35000328    	cbnz	w8, 0x10001100c <miniz_oxide::deflate::core::compress_inner+0x1558>
100010fac: f9402368    	ldr	x8, [x27, #0x40]
100010fb0: b50002e8    	cbnz	x8, 0x10001100c <miniz_oxide::deflate::core::compress_inner+0x1558>
100010fb4: aa1503e0    	mov	x0, x21
100010fb8: aa1c03e1    	mov	x1, x28
100010fbc: 97fff3b9    	bl	0x10000dea0 <miniz_oxide::deflate::core::flush_block>
100010fc0: 7100041f    	cmp	w0, #0x1
100010fc4: 54000081    	b.ne	0x100010fd4 <miniz_oxide::deflate::core::compress_inner+0x1520>
100010fc8: 12800008    	mov	w8, #-0x1               ; =-1
100010fcc: b900a768    	str	w8, [x27, #0xa4]
100010fd0: 14000044    	b	0x1000110e0 <miniz_oxide::deflate::core::compress_inner+0x162c>
100010fd4: 37f80841    	tbnz	w1, #0x1f, 0x1000110dc <miniz_oxide::deflate::core::compress_inner+0x1628>
100010fd8: 3942ab68    	ldrb	w8, [x27, #0xaa]
100010fdc: 7100111f    	cmp	w8, #0x4
100010fe0: 1a9f17e9    	cset	w9, eq
100010fe4: 3902b369    	strb	w9, [x27, #0xac]
100010fe8: 71000d1f    	cmp	w8, #0x3
100010fec: 54000101    	b.ne	0x10001100c <miniz_oxide::deflate::core::compress_inner+0x1558>
100010ff0: f9401760    	ldr	x0, [x27, #0x28]
100010ff4: 52a00021    	mov	w1, #0x10000            ; =65536
100010ff8: 940125de    	bl	0x10005a770 <dyld_stub_binder+0x10005a770>
100010ffc: f9401360    	ldr	x0, [x27, #0x20]
100011000: 52a00021    	mov	w1, #0x10000            ; =65536
100011004: 940125db    	bl	0x10005a770 <dyld_stub_binder+0x10005a770>
100011008: f9002b7f    	str	xzr, [x27, #0x50]
10001100c: f94002c8    	ldr	x8, [x22]
100011010: b9000a7f    	str	wzr, [x19, #0x8]
100011014: f9000268    	str	x8, [x19]
100011018: f9000a7f    	str	xzr, [x19, #0x10]
10001101c: b9400388    	ldr	w8, [x28]
100011020: 36000368    	tbz	w8, #0x0, 0x10001108c <miniz_oxide::deflate::core::compress_inner+0x15d8>
100011024: f9400b82    	ldr	x2, [x28, #0x10]
100011028: f9403b60    	ldr	x0, [x27, #0x70]
10001102c: b9409774    	ldr	w20, [x27, #0x94]
100011030: cb000048    	sub	x8, x2, x0
100011034: eb08029f    	cmp	x20, x8
100011038: 9a883295    	csel	x21, x20, x8, lo
10001103c: b40002d5    	cbz	x21, 0x100011094 <miniz_oxide::deflate::core::compress_inner+0x15e0>
100011040: ab0002b7    	adds	x23, x21, x0
100011044: 54000a62    	b.hs	0x100011190 <miniz_oxide::deflate::core::compress_inner+0x16dc>
100011048: eb0202ff    	cmp	x23, x2
10001104c: 54000a28    	b.hi	0x100011190 <miniz_oxide::deflate::core::compress_inner+0x16dc>
100011050: 52899988    	mov	w8, #0x4ccc             ; =19660
100011054: 72a00028    	movk	w8, #0x1, lsl #16
100011058: b9409376    	ldr	w22, [x27, #0x90]
10001105c: b2400108    	orr	x8, x8, #0x1
100011060: 8b1602a1    	add	x1, x21, x22
100011064: eb08003f    	cmp	x1, x8
100011068: 54000682    	b.hs	0x100011138 <miniz_oxide::deflate::core::compress_inner+0x1684>
10001106c: f9403f68    	ldr	x8, [x27, #0x78]
100011070: f9400789    	ldr	x9, [x28, #0x8]
100011074: 8b000120    	add	x0, x9, x0
100011078: 8b160101    	add	x1, x8, x22
10001107c: aa1503e2    	mov	x2, x21
100011080: 940125f8    	bl	0x10005a860 <dyld_stub_binder+0x10005a860>
100011084: aa1703e0    	mov	x0, x23
100011088: 14000004    	b	0x100011098 <miniz_oxide::deflate::core::compress_inner+0x15e4>
10001108c: b9409768    	ldr	w8, [x27, #0x94]
100011090: 14000007    	b	0x1000110ac <miniz_oxide::deflate::core::compress_inner+0x15f8>
100011094: b9409376    	ldr	w22, [x27, #0x90]
100011098: 0b1502c9    	add	w9, w22, w21
10001109c: 4b150288    	sub	w8, w20, w21
1000110a0: 29122369    	stp	w9, w8, [x27, #0x90]
1000110a4: f9003b60    	str	x0, [x27, #0x70]
1000110a8: f9000a60    	str	x0, [x19, #0x10]
1000110ac: 52800009    	mov	w9, #0x0                ; =0
1000110b0: 3942b36a    	ldrb	w10, [x27, #0xac]
1000110b4: 7100055f    	cmp	w10, #0x1
1000110b8: 54000081    	b.ne	0x1000110c8 <miniz_oxide::deflate::core::compress_inner+0x1614>
1000110bc: 35000068    	cbnz	w8, 0x1000110c8 <miniz_oxide::deflate::core::compress_inner+0x1614>
1000110c0: 52800029    	mov	w9, #0x1                ; =1
1000110c4: b9000a69    	str	w9, [x19, #0x8]
1000110c8: b900a769    	str	w9, [x27, #0xa4]
1000110cc: 17fffac3    	b	0x10000fbd8 <miniz_oxide::deflate::core::compress_inner+0x124>
1000110d0: f9003778    	str	x24, [x27, #0x68]
1000110d4: 12800008    	mov	w8, #-0x1               ; =-1
1000110d8: b900a768    	str	w8, [x27, #0xa4]
1000110dc: b940a768    	ldr	w8, [x27, #0xa4]
1000110e0: a946ab69    	ldp	x9, x10, [x27, #0x68]
1000110e4: b9000a68    	str	w8, [x19, #0x8]
1000110e8: f9000269    	str	x9, [x19]
1000110ec: f9000a6a    	str	x10, [x19, #0x10]
1000110f0: 17fffaba    	b	0x10000fbd8 <miniz_oxide::deflate::core::compress_inner+0x124>
1000110f4: aa0803ea    	mov	x10, x8
1000110f8: f94007fc    	ldr	x28, [sp, #0x8]
1000110fc: f94017f4    	ldr	x20, [sp, #0x28]
100011100: f9003778    	str	x24, [x27, #0x68]
100011104: a9045f6a    	stp	x10, x23, [x27, #0x40]
100011108: 17ffff78    	b	0x100010ee8 <miniz_oxide::deflate::core::compress_inner+0x1434>
10001110c: b0000323    	adrp	x3, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
100011110: 91236063    	add	x3, x3, #0x8d8
100011114: aa1903e0    	mov	x0, x25
100011118: aa1803e1    	mov	x1, x24
10001111c: f94017e2    	ldr	x2, [sp, #0x28]
100011120: 940120f4    	bl	0x1000594f0 <core::slice::index::slice_index_fail>
100011124: b0000323    	adrp	x3, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
100011128: 91230063    	add	x3, x3, #0x8c0
10001112c: aa1903e0    	mov	x0, x25
100011130: f94017e2    	ldr	x2, [sp, #0x28]
100011134: 940120ef    	bl	0x1000594f0 <core::slice::index::slice_index_fail>
100011138: b0000323    	adrp	x3, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
10001113c: 91254063    	add	x3, x3, #0x950
100011140: aa1603e0    	mov	x0, x22
100011144: 52899982    	mov	w2, #0x4ccc             ; =19660
100011148: 72a00022    	movk	w2, #0x1, lsl #16
10001114c: 940120e9    	bl	0x1000594f0 <core::slice::index::slice_index_fail>
100011150: b0000323    	adrp	x3, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
100011154: 91248063    	add	x3, x3, #0x920
100011158: aa0703e0    	mov	x0, x7
10001115c: aa1403e1    	mov	x1, x20
100011160: aa1403e2    	mov	x2, x20
100011164: 940120e3    	bl	0x1000594f0 <core::slice::index::slice_index_fail>
100011168: b0000323    	adrp	x3, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
10001116c: 91242063    	add	x3, x3, #0x908
100011170: 52902042    	mov	w2, #0x8102             ; =33026
100011174: 940120df    	bl	0x1000594f0 <core::slice::index::slice_index_fail>
100011178: b0000323    	adrp	x3, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
10001117c: 9123c063    	add	x3, x3, #0x8f0
100011180: d2800000    	mov	x0, #0x0                ; =0
100011184: aa0203e1    	mov	x1, x2
100011188: aa1403e2    	mov	x2, x20
10001118c: 940120d9    	bl	0x1000594f0 <core::slice::index::slice_index_fail>
100011190: b0000323    	adrp	x3, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
100011194: 9125a063    	add	x3, x3, #0x968
100011198: aa1703e1    	mov	x1, x23
10001119c: 940120d5    	bl	0x1000594f0 <core::slice::index::slice_index_fail>
1000111a0: b0000322    	adrp	x2, 0x100076000 <_anon.d68ef8d7792929a3448f1b722f46a0d6.8+0x70>
1000111a4: 9122a042    	add	x2, x2, #0x8a8
1000111a8: 52801001    	mov	w1, #0x80               ; =128
1000111ac: 9401206b    	bl	0x100059358 <core::panicking::panic_bounds_check>
