#!/usr/bin/env python3
"""Render Mandelbrot speed/size endpoints, with explicit cohort filters."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

COLORS = {"chapel": "#188754", "julia": "#9558b2", "rust": "#aa5724", "java": "#326994",
          "go": "#008b9b", "mech": "#e24b4b", "c": "#606770", "cpp": "#c39111"}
LABELS = {"chapel": "Chapel", "julia": "Julia", "rust": "Rust", "java": "Java (OpenJDK JIT)",
          "go": "Go", "mech": "Mech (Cranelift AOT; .mec only)", "c": "C (GCC + LLVM)", "cpp": "C++ (GCC + LLVM)"}


def render(path, data, key, suffix, description):
    endpoints = data[key]
    by_id = {r["id"]: r for r in data["programs"]}
    candidates = data["programs"]
    if key == "nonheroic_endpoints": candidates = [r for r in candidates if not r["upstream_starred"]]
    if key == "exact_image_endpoints": candidates = [r for r in candidates if r["warmup_image"]["exact_reference_match"]]
    fig, ax = plt.subplots(figsize=(11.5, 7.6), layout="constrained")
    ax.set_xscale("log", base=2)
    ax.set_yscale("log", base=2)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}×"))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}×"))
    ax.grid(which="both", color="#dfe3e8", linewidth=0.7)
    ax.set_axisbelow(True)
    table = ["| Language | Fastest | Seconds | LOC | gzip bytes | Smallest | Seconds | LOC | gzip bytes | Time tradeoff |",
             "| --- | --- | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |"]
    for language, endpoint in endpoints["languages"].items():
        rows = [r for r in candidates if r["language"] == language]
        source_count = len({r["path"] for r in rows})
        color = COLORS[language]
        ax.scatter([r["source"]["gzip1_bytes"] / endpoints["size_baseline_bytes"] for r in rows],
                   [r["median_seconds"] / endpoints["time_baseline_seconds"] for r in rows],
                   color=color, s=22, alpha=0.25)
        fast, small = endpoint["points"]["fastest"], endpoint["points"]["smallest"]
        ax.plot([fast["size_ratio"], small["size_ratio"]], [fast["time_ratio"], small["time_ratio"]], color=color, linewidth=1.6)
        ax.scatter(fast["size_ratio"], fast["time_ratio"], color=color, s=65,
                   label=f"{LABELS[language]} ({source_count} sources, {len(rows)} builds)")
        if not endpoint["same_entry"]: ax.scatter(small["size_ratio"], small["time_ratio"], color=color, marker="s", s=55)
        f, s = by_id[endpoint["fastest"]], by_id[endpoint["smallest"]]
        table.append(f"| {LABELS[language]} | {f['id']} | {f['median_seconds']:.3f} | {f['source']['nonblank_noncomment_lines']} | {f['source']['gzip1_bytes']} | {s['id']} | {s['median_seconds']:.3f} | {s['source']['nonblank_noncomment_lines']} | {s['source']['gzip1_bytes']} | {endpoint['smallest_time_over_fastest']:.2f}× |")
    p = data["protocol"]
    ax.set_title(f"Mandelbrot: execution time and program size\n{data['hardware']['cpu']}; N={p['size']:,}; median of {p['samples']} fresh runs", loc="left", fontsize=15, pad=15)
    ax.set_xlabel("Normalized compressed program size — smaller ←", fontsize=11)
    ax.set_ylabel("Normalized elapsed time — faster ↓", fontsize=11)
    ax.legend(loc="upper right", fontsize=8.5, framealpha=0.95)
    fig.text(0.015, -0.025,
             "Circle: fastest; square: smallest; faint points: all builds in this cohort.\n"
             f"{description} Requested workers: {p['requested_threads']}; source policies are recorded in JSON.\n"
             "Complete PBM output and startup/JIT included; AOT build excluded. Mech program source only; generic runtime excluded.\n"
             f"All pass the official N=200 byte comparison. {len(data['excluded'])} excluded configurations; see report.",
             fontsize=9, va="top", color="#424b57")
    stem = path.with_suffix("")
    target = stem.parent / (stem.name + suffix)
    for ext in ("svg", "png"): fig.savefig(str(target) + "." + ext, dpi=170, bbox_inches="tight")
    plt.close(fig)
    Path(str(target) + ".table.md").write_text("\n".join(table) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    data = json.loads(args.results.read_text())
    render(args.results, data, "endpoints", "", "All locally validated sources, including starred submissions.")
    render(args.results, data, "nonheroic_endpoints", ".nonstarred", "Upstream starred submissions excluded.")
    render(args.results, data, "exact_image_endpoints", ".exact", "Only byte-identical full images relative to local Rust #4.")
    print(args.results.with_suffix(".svg"))


if __name__ == "__main__": main()
