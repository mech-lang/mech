use cranelift_codegen::{ir::{AbiParam, ConstantData, InstBuilder, MemFlags, StackSlotData, StackSlotKind, Value, Type, condcodes::IntCC, types}, settings::{self,Configurable}};
use cranelift_frontend::{FunctionBuilder,FunctionBuilderContext};
use cranelift_module::{DataDescription,DataId,FuncId,Linkage,Module,default_libcall_names};
use cranelift_object::{ObjectBuilder,ObjectModule};
use mech_engine::native_sequence::control::{Expr,Kind,Op,Program};
use std::{collections::BTreeMap,path::Path};
type Values=Vec<Value>;
fn types_for(k:&Kind)->Vec<Type>{match k {Kind::Integer=>vec![types::I64],Kind::Boolean=>vec![types::I8],Kind::Bytes(n)=>vec![types::I8X16;n.div_ceil(16)],Kind::Tuple(k)=>k.iter().flat_map(types_for).collect(),Kind::Text=>vec![]}}
struct Emit<'a,'b,'c> { b: &'a mut FunctionBuilder<'b>, module:&'a mut ObjectModule, program:&'c Program, simd:bool, callbacks:&'c BTreeMap<String,FuncId>, reduce:FuncId, arguments:Value, tables:&'a mut BTreeMap<String,DataId> }
impl Emit<'_,'_,'_>{
 fn int(&mut self,n:u64)->Value{self.b.ins().iconst(types::I64,n as i64)}
 fn guard(&mut self,valid:Value,status:i64){let good=self.b.create_block();let bad=self.b.create_block();self.b.ins().brif(valid,good,&[],bad,&[]);self.b.switch_to_block(bad);let error=self.b.ins().iconst(types::I64,status);self.b.ins().return_(&[error]);self.b.switch_to_block(good);}
 fn vector(&mut self,data:[u8;16])->Value{let constant=self.b.func.dfg.constants.insert(ConstantData::from(data.to_vec()));self.b.ins().vconst(types::I8X16,constant)}
 fn slot(&mut self,n:usize)->Value{let s=self.b.create_sized_stack_slot(StackSlotData::new(StackSlotKind::ExplicitSlot,n as u32,4));self.b.ins().stack_addr(types::I64,s,0)}
 fn call(&mut self,name:&str,params:&[Value])->Result<Values,String>{let f=self.program.functions.get(name).ok_or("missing native function")?;self.expression(&f.output,params,&mut BTreeMap::new())}
 fn table(&mut self,name:String,data:Vec<u8>)->Result<Value,String>{
  let id=if let Some(id)=self.tables.get(&name){*id}else{let id=self.module.declare_data(&name,Linkage::Local,false,false).map_err(|e|e.to_string())?;let mut desc=DataDescription::new();desc.define(data.into_boxed_slice());desc.set_align(16);self.module.define_data(id,&desc).map_err(|e|e.to_string())?;self.tables.insert(name,id);id};
  let gv=self.module.declare_data_in_func(id,self.b.func);Ok(self.b.ins().global_value(types::I64,gv))
 }
 fn expression(&mut self,e:&Expr,params:&[Value],memo:&mut BTreeMap<Expr,Values>)->Result<Values,String>{
  if let Some(value)=memo.get(e){return Ok(value.clone());}
  let out=match &e.op {
   Op::Integer(n)=>vec![self.int(*n)],Op::Boolean(b)=>vec![self.b.ins().iconst(types::I8,i64::from(*b))],Op::Text(_)=>vec![],
   Op::Parameter(i)=>params[*i..*i+types_for(&e.kind).len()].to_vec(),
   Op::Tuple(items)=>{let mut out=Vec::new();for item in items{out.extend(self.expression(item,params,memo)?);}out},
   Op::Field(value,i)=>{let Kind::Tuple(kinds)=&value.kind else{return Err("tuple field type".into())};let offset:usize=kinds[..*i].iter().map(|k|types_for(k).len()).sum();let values=self.expression(value,params,memo)?;values[offset..offset+types_for(&kinds[*i]).len()].to_vec()},
   Op::Call(name,args)=>{let mut values=Vec::new();for arg in args{values.extend(self.expression(arg,params,memo)?);}self.call(name,&values)?},
   Op::Loop{initial,predicate,step}=>{
     let initial_values=self.expression(initial,params,memo)?;let head=self.b.create_block();let body=self.b.create_block();let exit=self.b.create_block();for t in types_for(&e.kind){self.b.append_block_param(head,t);self.b.append_block_param(exit,t);}
     self.b.ins().jump(head,&initial_values.iter().copied().map(Into::into).collect::<Vec<_>>());self.b.switch_to_block(head);let state=self.b.block_params(head).to_vec();let condition=self.call(predicate,&state)?[0];
     self.b.ins().brif(condition,body,&[],exit,&state.iter().copied().map(Into::into).collect::<Vec<_>>());self.b.switch_to_block(body);let next=self.call(step,&state)?;
     self.b.ins().jump(head,&next.iter().copied().map(Into::into).collect::<Vec<_>>());self.b.switch_to_block(exit);self.b.block_params(exit).to_vec()
   },
   Op::Branch{condition,yes,no,state}=>{
     let condition=self.expression(condition,params,memo)?[0];let state=self.expression(state,params,memo)?;let y=self.b.create_block();let n=self.b.create_block();let exit=self.b.create_block();for t in types_for(&e.kind){self.b.append_block_param(exit,t);}
     self.b.ins().brif(condition,y,&[],n,&[]);self.b.switch_to_block(y);let out=self.call(yes,&state)?;self.b.ins().jump(exit,&out.iter().copied().map(Into::into).collect::<Vec<_>>());self.b.switch_to_block(n);let out=self.call(no,&state)?;self.b.ins().jump(exit,&out.iter().copied().map(Into::into).collect::<Vec<_>>());self.b.switch_to_block(exit);self.b.block_params(exit).to_vec()
   },
   Op::Parallel{start,end,grain,function,arguments,reductions}=>{
     let first=self.expression(start,params,memo)?[0];let last=self.expression(end,params,memo)?[0];let grain=self.expression(grain,params,memo)?[0];let args=self.expression(arguments,params,memo)?;
     let argptr=self.slot(args.len()*8);for (i,v) in args.iter().enumerate(){self.b.ins().store(MemFlags::new(),*v,argptr,(i*8) as i32);}let arglen=self.int(args.len() as u64);
     let function=self.module.declare_func_in_func(self.callbacks[function],self.b.func);let function=self.b.ins().func_addr(types::I64,function);
     let codes=reductions.iter().map(|r|if r=="sum"{0u8}else{1u8}).collect::<Vec<_>>();let table=self.table(format!("mech_control_reducers_{}",reductions.join("_")),codes)?;let len=self.int(reductions.len() as u64);let out=self.slot(reductions.len()*8);let reduce=self.module.declare_func_in_func(self.reduce,self.b.func);
     let call=self.b.ins().call(reduce,&[first,last,grain,argptr,arglen,function,table,len,out]);let status=self.b.inst_results(call)[0];let valid=self.b.ins().icmp_imm(IntCC::Equal,status,0);self.guard(valid,5);
     (0..reductions.len()).map(|i|self.b.ins().load(types::I64,MemFlags::new(),out,(i*8) as i32)).collect()
   },
   Op::Primitive(name,args)=>{
     let mut v=Vec::new();for arg in args{v.push(self.expression(arg,params,memo)?);}
     let x=v.first().and_then(|v|v.first()).copied();
     match name.as_str(){
      "io/argument-u64"=>{let Op::Integer(index)=args[0].op else{return Err("argument index".into())};vec![self.b.ins().load(types::I64,MemFlags::new(),self.arguments,((index-1)*8) as i32)]},
      "sequence/iota-bytes"|"sequence/zero-bytes"=>{let Kind::Bytes(n)=e.kind else{return Err("byte constructor".into())};(0..n.div_ceil(16)).map(|block|self.vector(std::array::from_fn(|i|if name=="sequence/iota-bytes"&&block*16+i<n {(block*16+i) as u8}else{0}))).collect()},
      "+"=>vec![self.b.ins().iadd(x.unwrap(),v[1][0])],"-"=>vec![self.b.ins().isub(x.unwrap(),v[1][0])],"*"=>vec![self.b.ins().imul(x.unwrap(),v[1][0])],
      "/"|"number/mod"=>{let a=x.unwrap();let d=v[1][0];if let Op::Integer(n)=args[1].op {if n==0{return Err("constant division by zero".into());}if n.is_power_of_two(){vec![if name=="/"{self.b.ins().ushr_imm(a,n.trailing_zeros() as i64)}else{self.b.ins().band_imm(a,(n-1) as i64)}]}else{vec![if name=="/"{self.b.ins().udiv(a,d)}else{self.b.ins().urem(a,d)}]}}else{let valid=self.b.ins().icmp_imm(IntCC::NotEqual,d,0);self.guard(valid,2);vec![if name=="/"{self.b.ins().udiv(a,d)}else{self.b.ins().urem(a,d)}]}},
      "=="|"!="|"<"|"<="|">"|">="=>{let cc=match name.as_str(){"=="=>IntCC::Equal,"!="=>IntCC::NotEqual,"<"=>IntCC::UnsignedLessThan,"<="=>IntCC::UnsignedLessThanOrEqual,">"=>IntCC::UnsignedGreaterThan,_=>IntCC::UnsignedGreaterThanOrEqual};vec![self.b.ins().icmp(cc,x.unwrap(),v[1][0])]},
      "&&"=>vec![self.b.ins().band(x.unwrap(),v[1][0])],"||"=>vec![self.b.ins().bor(x.unwrap(),v[1][0])],
      "number/max"=>{let a=x.unwrap();let b=v[1][0];let greater=self.b.ins().icmp(IntCC::UnsignedGreaterThan,a,b);vec![self.b.ins().select(greater,a,b)]},
      "control/select"=>v[1].iter().zip(&v[2]).map(|(a,b)|self.b.ins().select(x.unwrap(),*a,*b)).collect(),
      "number/bounded"=>{let a=x.unwrap();let low=self.b.ins().icmp(IntCC::UnsignedGreaterThanOrEqual,a,v[1][0]);let high=self.b.ins().icmp(IntCC::UnsignedLessThanOrEqual,a,v[2][0]);let valid=self.b.ins().band(low,high);self.guard(valid,1);vec![a]},
      "number/factorial"=>{let n=x.unwrap();let valid=self.b.ins().icmp_imm(IntCC::UnsignedLessThanOrEqual,n,20);self.guard(valid,3);let head=self.b.create_block();let body=self.b.create_block();let done=self.b.create_block();self.b.append_block_param(head,types::I64);self.b.append_block_param(head,types::I64);self.b.append_block_param(done,types::I64);let one=self.int(1);self.b.ins().jump(head,&[one.into(),one.into()]);self.b.switch_to_block(head);let i=self.b.block_params(head)[0];let product=self.b.block_params(head)[1];let more=self.b.ins().icmp(IntCC::UnsignedLessThanOrEqual,i,n);self.b.ins().brif(more,body,&[],done,&[product.into()]);self.b.switch_to_block(body);let product=self.b.ins().imul(product,i);let next=self.b.ins().iadd_imm(i,1);self.b.ins().jump(head,&[next.into(),product.into()]);self.b.switch_to_block(done);vec![self.b.block_params(done)[0]]},
      "sequence/get"|"sequence/set"|"sequence/reverse-prefix"|"sequence/rotate-prefix"=>self.bytes(name,args,&v)?,
      _=>return Err(format!("unlowered native primitive {name}")),
     }
   }
  };
  memo.insert(e.clone(),out.clone());Ok(out)
 }
 fn bytes(&mut self,name:&str,args:&[Expr],v:&[Values])->Result<Values,String>{
   let Kind::Bytes(n)=args[0].kind else{return Err("byte operand".into())};let index=v[1][0];
   let upper=self.b.ins().icmp_imm(IntCC::UnsignedLessThanOrEqual,index,n as i64);let valid=if name=="sequence/get"||name=="sequence/set"{let lower=self.b.ins().icmp_imm(IntCC::UnsignedGreaterThanOrEqual,index,1);self.b.ins().band(lower,upper)}else{upper};self.guard(valid,4);
   if name=="sequence/set"{let valid=self.b.ins().icmp_imm(IntCC::UnsignedLessThanOrEqual,v[2][0],255);self.guard(valid,4);}
   if name=="sequence/get" {
     if let Op::Integer(i)=args[1].op{let lane=self.b.ins().extractlane(v[0][(i as usize-1)/16],((i-1)%16) as u8);return Ok(vec![self.b.ins().uextend(types::I64,lane)]);}
     let offset=self.b.ins().iadd_imm(index,-1);let byte=self.b.ins().ireduce(types::I8,offset);let mask=self.b.ins().splat(types::I8X16,byte);let mut selected=self.b.ins().swizzle(v[0][0],mask);
     for (chunk,vector) in v[0].iter().enumerate().skip(1){let byte=self.b.ins().iadd_imm(byte,-((chunk*16) as i64));let mask=self.b.ins().splat(types::I8X16,byte);let candidate=self.b.ins().swizzle(*vector,mask);selected=self.b.ins().bor(selected,candidate);}
     let byte=self.b.ins().extractlane(selected,0);return Ok(vec![self.b.ins().uextend(types::I64,byte)]);
   }
   if name=="sequence/set"&&self.simd{
     let offset=self.b.ins().iadd_imm(index,-1);let byte=self.b.ins().ireduce(types::I8,offset);let indices=self.b.ins().splat(types::I8X16,byte);let data=self.b.ins().ireduce(types::I8,v[2][0]);let data=self.b.ins().splat(types::I8X16,data);
     return Ok(v[0].iter().enumerate().map(|(chunk,vector)|{let lanes=self.vector(std::array::from_fn(|i|(chunk*16+i) as u8));let mask=self.b.ins().icmp(IntCC::Equal,indices,lanes);self.b.ins().bitselect(mask,data,*vector)}).collect());
   }
   if self.simd&&n<=16&&name!="sequence/set"{
     // Exhaustively precompute each legal byte permutation; only shape and
     // operation semantics determine this immutable shuffle table.
     let rotate=name=="sequence/rotate-prefix";let shift=if rotate{v[2][0]}else{self.int(0)};
     let length_nonzero=self.b.ins().icmp_imm(IntCC::NotEqual,index,0);let one_value=self.int(1);let safe=self.b.ins().select(length_nonzero,index,one_value);let shift=self.b.ins().urem(shift,safe);
     let one=rotate&&matches!(args[2].op,Op::Integer(1));let rows=if one||!rotate {1}else{16};let mut data=Vec::new();
     for length in 0..=n {for shift in 0..rows {for i in 0..16 {data.push(if i>=length{i as u8}else if rotate{((i+if one{1}else{shift})%length) as u8}else{(length-1-i) as u8});}}}
     let key=format!("mech_control_{}_{}_{}",if rotate{"rotate"}else{"reverse"},n,rows);let table=self.table(key,data)?;
     let offset=if rows==1{self.b.ins().ishl_imm(index,4)}else{let row=self.b.ins().ishl_imm(index,4);let row=self.b.ins().iadd(row,shift);self.b.ins().ishl_imm(row,4)};let address=self.b.ins().iadd(table,offset);let mask=self.b.ins().load(types::I8X16,MemFlags::new(),address,0);return Ok(vec![self.b.ins().swizzle(v[0][0],mask)]);
   }
   let source=self.slot(n.div_ceil(16)*16);let out=self.slot(n.div_ceil(16)*16);for (i,vector) in v[0].iter().enumerate(){self.b.ins().store(MemFlags::new(),*vector,source,(i*16) as i32);self.b.ins().store(MemFlags::new(),*vector,out,(i*16) as i32);}
   if name=="sequence/set"{let offset=self.b.ins().iadd_imm(index,-1);let address=self.b.ins().iadd(out,offset);let byte=self.b.ins().ireduce(types::I8,v[2][0]);self.b.ins().store(MemFlags::new(),byte,address,0);}else{
     let head=self.b.create_block();let body=self.b.create_block();let exit=self.b.create_block();self.b.append_block_param(head,types::I64);let zero=self.int(0);self.b.ins().jump(head,&[zero.into()]);self.b.switch_to_block(head);let i=self.b.block_params(head)[0];let more=self.b.ins().icmp(IntCC::UnsignedLessThan,i,index);self.b.ins().brif(more,body,&[],exit,&[]);self.b.switch_to_block(body);
     let from=if name=="sequence/reverse-prefix"{let last=self.b.ins().iadd_imm(index,-1);self.b.ins().isub(last,i)}else{let shifted=self.b.ins().iadd(i,v[2][0]);self.b.ins().urem(shifted,index)};let from=self.b.ins().iadd(source,from);let byte=self.b.ins().load(types::I8,MemFlags::new(),from,0);let dest=self.b.ins().iadd(out,i);self.b.ins().store(MemFlags::new(),byte,dest,0);let next=self.b.ins().iadd_imm(i,1);self.b.ins().jump(head,&[next.into()]);self.b.switch_to_block(exit);
   }
   Ok((0..n.div_ceil(16)).map(|i|self.b.ins().load(types::I8X16,MemFlags::new(),out,(i*16) as i32)).collect())
 }
}
fn flatten_parameters(e:&mut Expr,inputs:&[Kind]){match &mut e.op {Op::Parameter(i)=>{*i=inputs[..*i].iter().map(|k|types_for(k).len()).sum();},Op::Tuple(a)|Op::Call(_,a)|Op::Primitive(_,a)=>for e in a{flatten_parameters(e,inputs)},Op::Field(e,_)=>flatten_parameters(e,inputs),Op::Loop{initial,..}=>flatten_parameters(initial,inputs),Op::Branch{condition,state,..}=>{flatten_parameters(condition,inputs);flatten_parameters(state,inputs)},Op::Parallel{start,end,grain,arguments,..}=>for e in [start,end,grain,arguments]{flatten_parameters(e,inputs)},_=>{}}}
fn parallel_names(e:&Expr,out:&mut Vec<String>){match &e.op {Op::Parallel{function,start,end,grain,arguments,..}=>{if !out.contains(function){out.push(function.clone());}for e in [start,end,grain,arguments]{parallel_names(e,out)}},Op::Tuple(a)|Op::Call(_,a)|Op::Primitive(_,a)=>for e in a{parallel_names(e,out)},Op::Field(e,_)=>parallel_names(e,out),_=>{}}}
pub fn emit(source:&str,directory:&Path,simd:bool)->Result<(),String>{
 let mut program=mech_engine::native_sequence::control::compile(source,mech_stdlib::native_control_catalog())?;
 for function in program.functions.values_mut(){flatten_parameters(&mut function.output,&function.inputs);}
 let mut flags=settings::builder();flags.set("is_pic","true").map_err(|e|e.to_string())?;flags.set("opt_level","speed").map_err(|e|e.to_string())?;let isa=cranelift_native::builder().map_err(|e|e.to_string())?.finish(settings::Flags::new(flags)).map_err(|e|e.to_string())?;
 let mut module=ObjectModule::new(ObjectBuilder::new(isa,"mech_control",default_libcall_names()).map_err(|e|e.to_string())?);let mut signature=module.make_signature();signature.params=vec![AbiParam::new(types::I64);9];signature.returns.push(AbiParam::new(types::I64));let reduce=module.declare_function("mech_control_reduce",Linkage::Import,&signature).map_err(|e|e.to_string())?;
 let mut names=Vec::new();parallel_names(&program.output,&mut names);let mut callbacks=BTreeMap::new();for (i,name) in names.iter().enumerate(){let mut sig=module.make_signature();sig.params=vec![AbiParam::new(types::I64);4];sig.returns.push(AbiParam::new(types::I64));let id=module.declare_function(&format!("mech_control_range_{i}"),Linkage::Local,&sig).map_err(|e|e.to_string())?;callbacks.insert(name.clone(),id);}
 let mut units=names.iter().map(|name|(Some(name.clone()),callbacks[name])).collect::<Vec<_>>();let mut sig=module.make_signature();sig.params=vec![AbiParam::new(types::I64);2];sig.returns.push(AbiParam::new(types::I64));let main=module.declare_function("mech_control_entry",Linkage::Export,&sig).map_err(|e|e.to_string())?;units.push((None,main));
 let mut tables=BTreeMap::new();
 for (name,id) in units {
   let mut ctx=module.make_context();ctx.func.signature=module.declarations().get_function_decl(id).signature.clone();let mut fb=FunctionBuilderContext::new();let mut b=FunctionBuilder::new(&mut ctx.func,&mut fb);let entry=b.create_block();b.append_block_params_for_function_params(entry);b.switch_to_block(entry);let p=b.block_params(entry).to_vec();
   let arguments=if name.is_some(){p[2]}else{p[0]};let output=if name.is_some(){p[3]}else{p[1]};let mut emit=Emit{b:&mut b,module:&mut module,program:&program,simd,callbacks:&callbacks,reduce,arguments,tables:&mut tables};
   let values=if let Some(name)=&name{let f=&program.functions[name];let mut args=vec![p[0],p[1]];for i in 2..f.inputs.len(){args.push(emit.b.ins().load(types::I64,MemFlags::new(),arguments,((i-2)*8) as i32));}emit.call(name,&args)?}else{emit.expression(&program.output,&[],&mut BTreeMap::new())?};
   for (i,v) in values.iter().enumerate(){emit.b.ins().store(MemFlags::new(),*v,output,(i*8) as i32);}let zero=emit.int(0);emit.b.ins().return_(&[zero]);drop(emit);b.seal_all_blocks();b.finalize();module.define_function(id,&mut ctx).map_err(|e|format!("native control codegen: {e}"))?;
 }
 let object=module.finish().emit().map_err(|e|e.to_string())?;std::fs::write(directory.join("mech-control.o"),object).map_err(|e|e.to_string())?;
 std::fs::write(directory.join("control.json"),serde_json::to_string(&serde_json::json!({"arguments":program.argument_count,"format":program.format,"outputs":types_for(&program.output.kind).len(),"simd":simd})).unwrap()).map_err(|e|e.to_string())?;Ok(())
}
