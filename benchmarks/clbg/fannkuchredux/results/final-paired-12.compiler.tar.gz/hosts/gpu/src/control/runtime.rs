//! Storage, CLI formatting and general range scheduling; all callbacks are native.
use rayon::prelude::*;
use std::io::Write;
type Entry = unsafe extern "C" fn(*const u64, *mut u64) -> u64;
type Range = unsafe extern "C" fn(u64, u64, *const u64, *mut u64) -> u64;

/// Run the object and its source-derived IO descriptor emitted together.
/// # Safety
/// `entry` must obey the admitted native ABI and match this compiler descriptor.
pub unsafe fn run_cli(entry: Entry, descriptor: &str) -> Result<(), String> {
    let spec: serde_json::Value = serde_json::from_str(descriptor).map_err(|e| e.to_string())?;
    let required = spec["arguments"].as_u64().ok_or("argument descriptor")? as usize;
    let count = spec["outputs"].as_u64().ok_or("output descriptor")? as usize;
    let format = spec["format"].as_str().ok_or("format descriptor")?;
    let args = std::env::args()
        .skip(1)
        .map(|s| {
            s.parse::<u64>()
                .map_err(|_| "expected unsigned integer arguments".to_string())
        })
        .collect::<Result<Vec<_>, _>>()?;
    if args.len() < required || required > 32 || count > 64 {
        return Err("missing arguments or malformed native descriptor".into());
    }
    let mut output = vec![0; count];
    // SAFETY: caller guarantees this object/descriptor pair; argument/output
    // storage has the exact validated lengths and stays live for synchronous entry.
    let status = unsafe { entry(args.as_ptr(), output.as_mut_ptr()) };
    if status != 0 {
        return Err(format!(
            "native control error {status}: bounds, arithmetic domain or range callback"
        ));
    }
    let stdout = std::io::stdout();
    let mut writer = stdout.lock();
    let mut rest = format;
    for value in output {
        let index = rest.find('{').ok_or("format descriptor mismatch")?;
        writer
            .write_all(rest[..index].as_bytes())
            .map_err(|e| e.to_string())?;
        if rest[index..].starts_with("{:i64}") {
            write!(writer, "{}", value as i64).map_err(|e| e.to_string())?;
            rest = &rest[index + 6..];
        } else if rest[index..].starts_with("{}") {
            write!(writer, "{value}").map_err(|e| e.to_string())?;
            rest = &rest[index + 2..];
        } else {
            return Err("unsupported format descriptor".into());
        }
    }
    writer
        .write_all(rest.as_bytes())
        .map_err(|e| e.to_string())?;
    Ok(())
}

/// Generic parallel half-open range reduction over emitted pure callbacks.
/// # Safety
/// Pointers/function and lengths must come from one admitted native object.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mech_control_reduce(
    start: u64,
    end: u64,
    grain: u64,
    arguments: *const u64,
    argument_count: u64,
    function: u64,
    reducers: *const u8,
    fields: u64,
    output: *mut u64,
) -> u64 {
    if end < start
        || grain == 0
        || argument_count > 32
        || fields == 0
        || fields > 64
        || function == 0
    {
        return 5;
    }
    // SAFETY: compiler ABI supplies initialized, immutable regions with validated
    // lengths, a matching native Range function, and an exclusive result region.
    let (args, codes, callback) = unsafe {
        (
            std::slice::from_raw_parts(arguments, argument_count as usize).to_vec(),
            std::slice::from_raw_parts(reducers, fields as usize).to_vec(),
            std::mem::transmute::<usize, Range>(function as usize),
        )
    };
    if codes.iter().any(|&r| r > 1) {
        return 5;
    }
    let tasks = (end - start).div_ceil(grain);
    let reduce = |mut left: Vec<u64>, right: Vec<u64>| {
        for ((l, r), code) in left.iter_mut().zip(right).zip(&codes) {
            *l = if *code == 0 {
                l.wrapping_add(r)
            } else {
                (*l).max(r)
            };
        }
        left
    };
    let result = (0..tasks)
        .into_par_iter()
        .map(|task| {
            let begin = start + task * grain;
            let last = begin.saturating_add(grain).min(end);
            let mut result = vec![0; fields as usize];
            // SAFETY: every task has private result storage. Captured args are immutable
            // and remain live; callbacks do not capture IO or host state. Rayon joins
            // before any storage is released or the combined result is published.
            let status = unsafe { callback(begin, last, args.as_ptr(), result.as_mut_ptr()) };
            if status == 0 { Ok(result) } else { Err(status) }
        })
        .try_reduce(
            || vec![0; fields as usize],
            |left, right| Ok(reduce(left, right)),
        );
    match result {
        Ok(values) => {
            // SAFETY: exclusive compiler-owned result buffer is exactly fields u64s;
            // callbacks have joined, and values is separate initialized storage.
            unsafe { std::ptr::copy_nonoverlapping(values.as_ptr(), output, fields as usize) };
            0
        }
        Err(status) => status,
    }
}
