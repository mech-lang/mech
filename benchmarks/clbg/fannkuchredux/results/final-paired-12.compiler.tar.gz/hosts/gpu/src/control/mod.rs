//! General closed-loop Cranelift AOT execution and bounded range scheduling.
#[cfg(feature = "sequence-cli")]
mod runtime;
#[cfg(feature = "sequence-cli")]
pub use runtime::run_cli;
mod compiler;
pub use compiler::emit;
