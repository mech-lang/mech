#!/usr/bin/env python3
"""Compare worker scaling and macOS time resource counters for the native paths.

Diagnostic only: collector overhead is included in wall time. These samples
are kept separate from the official fresh-process corner-chart measurements.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import re
import statistics
import subprocess
import time

import run as spectral

HERE = Path(__file__).resolve().parent


def main():
    ablation = json.loads((HERE / 'results/integer-coefficient-ablation.json').read_text())
    rows = []
    for p in ablation['programs']:
        for workers in (1, 4, 8):
            r = {k: v for k, v in p.items() if k not in ('samples_seconds', 'median_seconds')}
            r['id'] = p['id'] + f'-workers{workers}'
            r['workers'] = workers
            r['samples'] = []
            rows.append(r)
    rng = random.Random(20261007)
    orders = []
    for sample in range(7):
        order = rows.copy()
        rng.shuffle(order)
        orders.append([r['id'] for r in order])
        for r in order:
            env = os.environ | {'RAYON_NUM_THREADS': str(r['workers']),
                                'OPENBLAS_NUM_THREADS': '1'}
            if r['language'] == 'mech':
                env |= {'MECH_SEQUENCE_PARTITIONS': str(r['partitions']),
                        'MECH_ARRAY_GRAIN': str(r.get('grain', 16))}
            argv = ['/usr/bin/time', '-lp'] + r['command'] + ['5500']
            start = time.perf_counter_ns()
            result = subprocess.run(argv, env=env, cwd=spectral.ROOT, check=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    timeout=300)
            elapsed = (time.perf_counter_ns() - start) / 1e9
            if result.stdout != b'1.274224153\n':
                raise ValueError('output differs: ' + r['id'])
            counters = {}
            for line in result.stderr.decode().splitlines():
                match = re.fullmatch(r'(real|user|sys)\s+([\d.]+)', line.strip())
                if match:
                    counters[match[1]] = float(match[2])
                    continue
                match = re.fullmatch(r'\s*(\d+)\s+(.+)', line)
                if match:
                    counters[match[2]] = int(match[1])
            r['samples'].append({'wall_seconds': elapsed, 'counters': counters})
            print(f"{sample + 1}/7 {r['id']}: {elapsed:.6f}s, CPU {counters['user'] + counters['sys']:.2f}s", flush=True)
    for r in rows:
        r['median_seconds'] = statistics.median(s['wall_seconds'] for s in r['samples'])
        r['median_counters'] = {k: statistics.median(s['counters'][k] for s in r['samples'])
                                for k in r['samples'][0]['counters']}
        r['executable_sha256'] = spectral.sha(r['command'][0])
    output = HERE / 'results/worker-scaling-counters.json'
    output.write_text(json.dumps({
        'created_at': datetime.now(timezone.utc).isoformat(),
        'hardware': {'platform': platform.platform(), 'machine': platform.machine(),
                     'cpu': subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip()},
        'protocol': {'n': 5500, 'samples': 7, 'workers': [1, 4, 8],
                     'collector': '/usr/bin/time -lp; hardware counters reported by macOS, not inferred from source or instruction listings',
                     'timed_region': 'Fresh process through exit including time collector overhead. No compilation or tests run during samples.',
                     'sample_order': orders, 'diagnostic_only': True},
        'compiler_snapshot': spectral.snapshot(output),
        'programs': rows,
    }, indent=2) + '\n')


if __name__ == '__main__':
    main()
