//! Native higher-order array loops. Coefficients are typed Mech scalar graphs;
//! neither the backend nor runtime contains a particular matrix formula.
use cranelift_codegen::ir::{AbiParam, InstBuilder, MemFlags, Value, condcodes::IntCC, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{FuncId, Linkage, Module};
use cranelift_object::ObjectModule;
use mech_engine::native_sequence::{Callable, Constant, Program};
use std::collections::BTreeMap;

fn arithmetic(b: &mut FunctionBuilder, op: u64, args: &[Value]) -> Value {
    match op {
        20 => b.ins().fmul(args[0], args[1]),
        21 => b.ins().fdiv(args[0], args[1]),
        22 => b.ins().fadd(args[0], args[1]),
        23 => b.ins().fsub(args[0], args[1]),
        38 => b.ins().sqrt(args[0]),
        _ => unreachable!("admitted scalar arithmetic"),
    }
}
fn scalar_graph(
    b: &mut FunctionBuilder,
    function: &Callable,
    inputs: &[Value],
    previous: Option<&[Option<Value>]>,
    hoist: bool,
    varying: usize,
) -> (Vec<Option<Value>>, Option<Value>) {
    let graph = &function.program;
    let ty = if inputs
        .iter()
        .any(|&v| b.func.dfg.value_type(v) == types::F64X2)
    {
        types::F64X2
    } else {
        types::F64
    };
    let mut values = Vec::new();
    let mut masks = Vec::new();
    for (id, c) in graph.constants.iter().enumerate() {
        let (value, mask) = match c {
            Constant::Float(bits) => {
                let value = previous.and_then(|p| p[id]).unwrap_or_else(|| {
                    let value = b.ins().f64const(f64::from_bits(*bits));
                    if ty == types::F64 {
                        value
                    } else {
                        b.ins().splat(ty, value)
                    }
                });
                (Some(value), 0)
            }
            Constant::Parameter(index, _) => (
                if hoist && *index == varying {
                    None
                } else {
                    Some(inputs[*index])
                },
                1 << index,
            ),
            _ => (None, 0), // unrelated, precollected literals are not evaluated
        };
        values.push(value);
        masks.push(mask);
    }
    // CSE and loop invariants use graph dependencies, never source spellings.
    let mut common = BTreeMap::new();
    for (index, node) in graph.nodes.iter().enumerate() {
        let id = graph.constants.len() + index;
        let mask = node.args.iter().fold(0, |m, &i| m | masks[i]);
        let value = if let Some(value) = previous.and_then(|p| p[id]) {
            Some(value)
        } else if hoist && mask & (1 << varying) != 0 {
            None
        } else if let Some(value) = common.get(&(node.op, node.args.clone())) {
            Some(*value)
        } else {
            let args: Vec<_> = node
                .args
                .iter()
                .map(|&i| values[i].expect("typed scalar dependency"))
                .collect();
            let value = arithmetic(b, node.op, &args);
            common.insert((node.op, node.args.clone()), value);
            Some(value)
        };
        values.push(value);
        masks.push(mask);
    }
    let output = values[function.output];
    (values, output)
}

pub(super) fn emit(
    module: &mut ObjectModule,
    graph: &Program,
    node_index: usize,
    name: &str,
    simd: bool,
    callee: Option<FuncId>,
) -> Result<FuncId, String> {
    let node = &graph.nodes[node_index];
    let ptr = module.target_config().pointer_type();
    let mut ctx = module.make_context();
    let mut fbctx = FunctionBuilderContext::new();
    match node.op {
        35 | 36 => {
            let Some(Constant::Function(function)) = graph.constants.get(node.args[2]) else {
                return Err("missing matrix function".into());
            };
            let divide = match graph.constants.get(node.args[3]) {
                Some(Constant::Text(mode)) if mode == "multiply" => false,
                Some(Constant::Text(mode)) if mode == "divide" => true,
                _ => return Err("matrix weight mode must be constant multiply or divide".into()),
            };
            // (input, columns, first_row, end_row, output_for_first_row)
            ctx.func.signature.params = vec![AbiParam::new(ptr); 5];
            let id = module
                .declare_function(name, Linkage::Local, &ctx.func.signature)
                .map_err(|e| e.to_string())?;
            let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
            let entry = b.create_block();
            let row = b.create_block();
            let loop_ = b.create_block();
            let tail = b.create_block();
            let tail_body = b.create_block();
            let finish = b.create_block();
            let exit = b.create_block();
            b.append_block_params_for_function_params(entry);
            b.append_block_param(row, ptr);
            let lanes = if simd { 2 } else { 1 };
            // Independent SIMD accumulators expose ILP without changing workload.
            let unroll: usize = if simd {
                std::env::var("MECH_NUMERIC_UNROLL")
                    .unwrap_or_else(|_| "2".into())
                    .parse()
                    .map_err(|_| "invalid numeric unroll")?
            } else {
                1
            };
            if ![1, 2, 4, 8].contains(&unroll) {
                return Err("numeric unroll must be 1,2,4,8".into());
            }
            let ty = if simd { types::F64X2 } else { types::F64 };
            b.append_block_param(loop_, ptr);
            for _ in 0..unroll {
                b.append_block_param(loop_, ty);
            }
            b.append_block_param(tail, ptr);
            b.append_block_param(tail, types::F64);
            b.append_block_param(tail_body, ptr);
            b.append_block_param(tail_body, types::F64);
            b.append_block_param(finish, types::F64);
            b.switch_to_block(entry);
            let p = b.block_params(entry).to_vec();
            let more = b.ins().icmp(IntCC::UnsignedLessThan, p[2], p[3]);
            b.ins().brif(more, row, &[p[2].into()], exit, &[]);
            b.switch_to_block(row);
            let r = b.block_params(row)[0];
            let rf = b.ins().fcvt_from_uint(types::F64, r);
            let zero = b.ins().f64const(0.0);
            let z = b.ins().iconst(ptr, 0);
            let row_input = if simd { b.ins().splat(ty, rf) } else { rf };
            let varying = if node.op == 36 { 0 } else { 1 };
            let inputs = if varying == 0 {
                [zero, row_input]
            } else {
                [row_input, zero]
            };
            let (invariants, _) = scalar_graph(&mut b, function, &inputs, None, true, varying);
            let vector_zero = if simd { b.ins().splat(ty, zero) } else { zero };
            let mut init = vec![z.into()];
            init.extend((0..unroll).map(|_| cranelift_codegen::ir::BlockArg::from(vector_zero)));
            b.ins().jump(loop_, &init);
            b.switch_to_block(loop_);
            let args = b.block_params(loop_).to_vec();
            let j = args[0];
            let end = b.ins().iadd_imm(j, (lanes * unroll) as i64);
            let fits = b.ins().icmp(IntCC::UnsignedLessThanOrEqual, end, p[1]);
            let body = b.create_block();
            let reduce = b.create_block();
            b.ins().brif(fits, body, &[], reduce, &[]);
            b.switch_to_block(body);
            let mut next = vec![end.into()];
            for k in 0..unroll {
                let jk = b.ins().iadd_imm(j, (k * lanes) as i64);
                let jf = b.ins().fcvt_from_uint(types::F64, jk);
                let column = if simd {
                    let one = b.ins().f64const(1.0);
                    let second = b.ins().fadd(jf, one);
                    let v = b.ins().splat(ty, jf);
                    b.ins().insertlane(v, second, 1)
                } else {
                    jf
                };
                let inputs = if varying == 0 {
                    [column, row_input]
                } else {
                    [row_input, column]
                };
                let (_, coefficient) =
                    scalar_graph(&mut b, function, &inputs, Some(&invariants), false, varying);
                let off = b.ins().ishl_imm(jk, 3);
                let addr = b.ins().iadd(p[0], off);
                let input = b.ins().load(ty, MemFlags::new(), addr, 0);
                let term = if divide {
                    b.ins().fdiv(input, coefficient.unwrap())
                } else {
                    b.ins().fmul(input, coefficient.unwrap())
                };
                let sum = b.ins().fadd(args[k + 1], term);
                next.push(sum.into());
            }
            b.ins().jump(loop_, &next);
            b.switch_to_block(reduce);
            let mut sum = args[1];
            for &part in &args[2..] {
                sum = b.ins().fadd(sum, part);
            }
            if simd {
                let a = b.ins().extractlane(sum, 0);
                let c = b.ins().extractlane(sum, 1);
                sum = b.ins().fadd(a, c);
            }
            b.ins().jump(tail, &[j.into(), sum.into()]);
            b.switch_to_block(tail);
            let t = b.block_params(tail).to_vec();
            let more = b.ins().icmp(IntCC::UnsignedLessThan, t[0], p[1]);
            b.ins().brif(
                more,
                tail_body,
                &[t[0].into(), t[1].into()],
                finish,
                &[t[1].into()],
            );
            b.switch_to_block(tail_body);
            let t = b.block_params(tail_body).to_vec();
            let jf = b.ins().fcvt_from_uint(types::F64, t[0]);
            let inputs = if varying == 0 { [jf, rf] } else { [rf, jf] };
            let (_, coefficient) = scalar_graph(&mut b, function, &inputs, None, false, varying);
            let off = b.ins().ishl_imm(t[0], 3);
            let addr = b.ins().iadd(p[0], off);
            let v = b.ins().load(types::F64, MemFlags::new(), addr, 0);
            let term = if divide {
                b.ins().fdiv(v, coefficient.unwrap())
            } else {
                b.ins().fmul(v, coefficient.unwrap())
            };
            let sum = b.ins().fadd(t[1], term);
            let j = b.ins().iadd_imm(t[0], 1);
            b.ins().jump(tail, &[j.into(), sum.into()]);
            b.switch_to_block(finish);
            let sum = b.block_params(finish)[0];
            let offset = b.ins().isub(r, p[2]);
            let offset = b.ins().ishl_imm(offset, 3);
            let addr = b.ins().iadd(p[4], offset);
            b.ins().store(MemFlags::new(), sum, addr, 0);
            let next = b.ins().iadd_imm(r, 1);
            let more = b.ins().icmp(IntCC::UnsignedLessThan, next, p[3]);
            b.ins().brif(more, row, &[next.into()], exit, &[]);
            b.switch_to_block(exit);
            b.ins().return_(&[]);
            b.seal_all_blocks();
            b.finalize();
            module
                .define_function(id, &mut ctx)
                .map_err(|e| e.to_string())?;
            Ok(id)
        }
        37 => {
            ctx.func.signature.params = vec![AbiParam::new(ptr); 3];
            ctx.func.signature.returns.push(AbiParam::new(types::F64));
            let id = module
                .declare_function(name, Linkage::Local, &ctx.func.signature)
                .map_err(|e| e.to_string())?;
            let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
            let entry = b.create_block();
            let check = b.create_block();
            let body = b.create_block();
            let exit = b.create_block();
            b.append_block_params_for_function_params(entry);
            b.append_block_param(check, ptr);
            b.append_block_param(check, types::F64);
            b.switch_to_block(entry);
            let p = b.block_params(entry).to_vec();
            let z = b.ins().iconst(ptr, 0);
            let sum = b.ins().f64const(0.0);
            b.ins().jump(check, &[z.into(), sum.into()]);
            b.switch_to_block(check);
            let a = b.block_params(check).to_vec();
            let more = b.ins().icmp(IntCC::UnsignedLessThan, a[0], p[2]);
            b.ins().brif(more, body, &[], exit, &[]);
            b.switch_to_block(body);
            let off = b.ins().ishl_imm(a[0], 3);
            let left = b.ins().iadd(p[0], off);
            let right = b.ins().iadd(p[1], off);
            let left = b.ins().load(types::F64, MemFlags::new(), left, 0);
            let right = b.ins().load(types::F64, MemFlags::new(), right, 0);
            let product = b.ins().fmul(left, right);
            let sum = b.ins().fadd(a[1], product);
            let next = b.ins().iadd_imm(a[0], 1);
            b.ins().jump(check, &[next.into(), sum.into()]);
            b.switch_to_block(exit);
            b.ins().return_(&[a[1]]);
            b.seal_all_blocks();
            b.finalize();
            module
                .define_function(id, &mut ctx)
                .map_err(|e| e.to_string())?;
            Ok(id)
        }
        38 => {
            ctx.func.signature.params.push(AbiParam::new(types::F64));
            ctx.func.signature.returns.push(AbiParam::new(types::F64));
            let id = module
                .declare_function(name, Linkage::Local, &ctx.func.signature)
                .map_err(|e| e.to_string())?;
            let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
            let entry = b.create_block();
            b.append_block_params_for_function_params(entry);
            b.switch_to_block(entry);
            let x = b.block_params(entry)[0];
            let y = b.ins().sqrt(x);
            b.ins().return_(&[y]);
            b.seal_all_blocks();
            b.finalize();
            module
                .define_function(id, &mut ctx)
                .map_err(|e| e.to_string())?;
            Ok(id)
        }
        39 => {
            ctx.func.signature.params = vec![AbiParam::new(ptr); 2];
            let id = module
                .declare_function(name, Linkage::Local, &ctx.func.signature)
                .map_err(|e| e.to_string())?;
            let mut sig = module.make_signature();
            sig.params = vec![AbiParam::new(ptr); 2];
            sig.returns.push(AbiParam::new(ptr));
            let step = module
                .declare_function("mech_sequence_invoke", Linkage::Import, &sig)
                .map_err(|e| e.to_string())?;
            let step = module.declare_func_in_func(step, &mut ctx.func);
            let callee = module.declare_func_in_func(
                callee.ok_or("missing callable native entry")?,
                &mut ctx.func,
            );
            let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
            let entry = b.create_block();
            let check = b.create_block();
            let body = b.create_block();
            let again = b.create_block();
            let exit = b.create_block();
            b.append_block_params_for_function_params(entry);
            b.append_block_param(check, ptr);
            b.switch_to_block(entry);
            let p = b.block_params(entry).to_vec();
            let z = b.ins().iconst(ptr, 0);
            let fnptr = b.ins().func_addr(ptr, callee);
            b.ins().jump(check, &[z.into()]);
            b.switch_to_block(check);
            let i = b.block_params(check)[0];
            let more = b.ins().icmp(IntCC::UnsignedLessThan, i, p[1]);
            b.ins().brif(more, body, &[], exit, &[]);
            b.switch_to_block(body);
            let call = b.ins().call(step, &[p[0], fnptr]);
            let status = b.inst_results(call)[0];
            let good = b.ins().icmp_imm(IntCC::Equal, status, 0);
            b.ins().brif(good, again, &[], exit, &[]);
            b.switch_to_block(again);
            let next = b.ins().iadd_imm(i, 1);
            b.ins().jump(check, &[next.into()]);
            b.switch_to_block(exit);
            b.ins().return_(&[]);
            b.seal_all_blocks();
            b.finalize();
            module
                .define_function(id, &mut ctx)
                .map_err(|e| e.to_string())?;
            Ok(id)
        }
        _ => Err("unsupported native numeric loop".into()),
    }
}
