# Binary trees — Apple M3

This eighth study adds binary-trees at the official performance input **N=21**.
The full workload logically allocates 613,766,494 nodes. It builds and checks the
stretch tree at depth 22, retains the long-lived depth-21 tree during all temporary
work, constructs/checks/reclaims every required temporary tree, and finally checks
the long-lived tree. Leaves use the same node record and allocation as interiors.

The two complete Mech sources are `binarytrees.mec` and
`binarytrees-parallel.mec`. Both define construction, traversal, and destruction as
ordinary recursive Mech functions. The parallel version replaces only the
per-depth iteration with the existing general range reduction. It uses 51
nonblank, noncomment lines, like the compact sequential version.

## Native support

The native control compiler now admits opaque `<ref>` values and source-defined
recursive functions. The reusable reference operations are `heap/null`,
`heap/new-refs`, `heap/read-refs`, `heap/take-refs`, and `heap/stats`.
`heap/take-refs` returns the fields and frees that individual record. It does not
walk or reclaim children; that work is in the Mech source. Records have 1–32
reference fields and use ordinary individual Rust `Box` allocations, including
all-null records. A safe thread-local `HashMap` owns them and validates opaque
handles. It is ownership metadata, not a node arena, allocation pool, or free list.
Unknown, freed, null, wrong-arity, or foreign-thread references cannot be read.
References cannot be forged from integer expressions.

Recursive calls compile to native Cranelift functions with typed inputs, exclusive
return storage, status propagation, and a checked maximum call depth of 128.
Source statements preserve effect order; separate allocations and effectful
branch/loop occurrences cannot merge. `io/print` formats integer fields during
ordered source effects, and `number/shift-left` checks its shift count. Parallel
callbacks accept only scalar integer arguments, require balanced local record
ownership, and reject transitive IO, entry argument capture, and nested scheduling.
They cannot capture the main thread's long-lived tree.

These are general compiler/runtime operations. There is no tree kernel, closed
form node-count shortcut, benchmark-name matching, or host implementation of
construction/traversal/destruction.

## Validation and protocol

`reference-10.txt` is the official byte-for-byte output. `reference-pins.json`
records its digest and an independently calculated N=21 output digest; pinned
C #5 also validates the full output. `conformance.py` checks small inputs, node
allocation/free counts and maximum live counts, distinct identical-looking
allocations, aliases, stale handles, arities, recursion depth, shift bounds, ordered
IO, and closed parallel scopes. `regressions.py` checks byte-identical prior FASTA
and fannkuch native objects and full FASTA output. `audit.py` audits production
unsafe boundaries and checked-in source fixtures, excluding generated projects.

The comparison pins all 35 listed submissions across Chapel, Julia, Rust, Go,
Java, C, and C++. C/C++ use GCC and LLVM builds; Rust uses normal and thin-LTO
builds against the same locked, native, bitcode-enabled dependencies. Java runs
OpenJDK JIT and is explicitly labeled, because these submissions were published
with GraalVM native AOT. C++ #4/#6 use a documented macOS CPU enumeration shim
for the unavailable Linux affinity API; their tree source is unchanged. C #1 uses
a header shim for macOS's standard `malloc` declarations. LLVM libc++ does not
provide the `std::execution::par` required by C++ #7; its GCC build is included.

Timing runs one fresh process at a time, to exit, with full output to a regular
file. Every run must match the complete output digest. Compilation, conformance,
rendering, and output hashing are outside the timed region. Three samples per
build are shuffled with a fixed seed; the report retains every sample, compiler
command, source and executable hash, worker setting, and exclusion.

The official rules admit default GC, individual node allocation, and **library**
memory pools. The report labels those allocation policies and includes separate
allocator endpoint summaries. Rust's published programs use library arenas;
Mech's initial implementation uses individual allocations plus checked registry
lookups. This first study measures the entire implementation, not compiler code
generation in isolation.

## Reproduction

```sh
RUSTFLAGS='-D warnings -C target-cpu=native' \
  CARGO_TARGET_DIR=benchmarks/clbg/nbody/mech-driver/target \
  cargo build --release --locked --offline --features cranelift_build
RUSTFLAGS='-C target-cpu=native -C embed-bitcode=yes' \
  CARGO_TARGET_DIR=benchmarks/clbg/binarytrees/.build/rust-deps-bitcode \
  cargo build --release --locked \
  --manifest-path benchmarks/clbg/binarytrees/rust-deps/Cargo.toml
python3 benchmarks/clbg/binarytrees/conformance.py
python3 benchmarks/clbg/binarytrees/regressions.py
python3 benchmarks/clbg/binarytrees/audit.py
python3 benchmarks/clbg/binarytrees/run.py --prepare-only
python3 benchmarks/clbg/binarytrees/run.py --reuse-builds --samples 3 --timeout 600
```

Run the stages sequentially. The harness records the local toolchain versions.
Sources, notes, URLs, and SHA256 hashes are in `manifest.json`; sources are kept
under `upstream/` with their license and author comments. Do not refresh an
existing pin implicitly.

- [Official work and allocation rules](https://benchmarksgame-team.pages.debian.net/benchmarksgame/description/binarytrees.html)
- [Published source cohort](https://benchmarksgame-team.pages.debian.net/benchmarksgame/performance/binarytrees.html)
