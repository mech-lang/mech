//! General closed-loop Cranelift AOT execution and bounded range scheduling.
#[cfg(feature = "sequence-cli")]
mod runtime;
#[cfg(feature = "sequence-cli")]
pub use runtime::run_cli;
mod compiler;
pub use compiler::emit;

// Private same-object ABI. Storage remains owned by a core planned projection.
#[repr(C)]
struct RefArenaContext {
    base: *mut u64,
    capacity: u64,
    cursor: u64,
    arity: u64,
}
