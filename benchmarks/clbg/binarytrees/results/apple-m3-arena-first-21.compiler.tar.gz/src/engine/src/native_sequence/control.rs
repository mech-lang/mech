//! Canonical-source IR for closed native loops and small immutable byte vectors.
//! Loop bodies, predicates and range callbacks are ordinary Mech functions.
use super::{text, visit};
use mech_syntax::document::{
    AnyCallArgumentSyntax, AstNode, DocumentId, FunctionCallSyntax, ParseConfig, Revision,
    StringLiteralSyntax, SyntaxKind, SyntaxNode, TextSnapshot, TupleDestructureSyntax,
    VariableDefineSyntax, parse_canonical_document,
};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Kind {
    Integer,
    Reference,
    Float,
    Boolean,
    Bytes(usize),
    ReadBytes,
    Floats,
    Tuple(Vec<Kind>),
    Text,
}
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Expr {
    pub kind: Kind,
    pub op: Op,
}
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Op {
    Integer(u64),
    Float(u64),
    Boolean(bool),
    Text(String),
    ReadBytes(Vec<u8>),
    Floats(Vec<u64>),
    Parameter(usize),
    Tuple(Vec<Expr>),
    Field(Box<Expr>, usize),
    Primitive(String, Vec<Expr>),
    Loop {
        id: usize,
        initial: Box<Expr>,
        predicate: String,
        step: String,
    },
    Branch {
        id: usize,
        condition: Box<Expr>,
        yes: String,
        no: String,
        state: Box<Expr>,
    },
    Call(String, Vec<Expr>),
    Invoke {
        id: usize,
        name: String,
        arguments: Vec<Expr>,
    },
    Heap {
        id: usize,
        action: u64,
        arguments: Vec<Expr>,
        arity: usize,
    },
    Arena {
        id: usize,
        capacity: Option<Box<Expr>>,
        arity: usize,
        function: String,
        arguments: Box<Expr>,
    },
    Print {
        id: usize,
        format: String,
        values: Vec<Expr>,
    },
    Sequence {
        effects: Vec<Expr>,
        output: Box<Expr>,
    },
    Parallel {
        id: usize,
        start: Box<Expr>,
        end: Box<Expr>,
        grain: Box<Expr>,
        function: String,
        arguments: Box<Expr>,
        reductions: Vec<String>,
    },
    Write {
        id: usize,
        text: String,
    },
    Scan {
        id: usize,
        count: Box<Expr>,
        state: Box<Expr>,
        function: String,
        width: Box<Expr>,
        separator: String,
        buffer: Box<Expr>,
    },
}
#[derive(Clone, Debug)]
pub struct Function {
    pub inputs: Vec<Kind>,
    pub output: Expr,
}
#[derive(Clone, Debug)]
pub struct Program {
    pub heap_functions: bool,
    pub functions: BTreeMap<String, Function>,
    pub output: Expr,
    pub format: String,
    pub argument_count: usize,
    pub effects: Vec<Expr>,
}
#[derive(Clone)]
struct SourceFunction {
    inputs: Vec<(String, Kind)>,
    outputs: Vec<(String, Kind)>,
    body: SyntaxNode,
}
fn parameter(node: &SyntaxNode) -> Result<(String, Kind), String> {
    let name = node
        .children()
        .find(|n| n.kind() == SyntaxKind::Identifier)
        .ok_or("parameter name")?;
    let annotation = node
        .children()
        .find(|n| n.kind() == SyntaxKind::KindAnnotation)
        .ok_or("parameter kind required")?;
    let s = text(&annotation)?.replace(' ', "");
    let kind = match s.as_str() {
        "<u64>" => Kind::Integer,
        "<ref>" => Kind::Reference,
        "<f64>" => Kind::Float,
        "<bool>" => Kind::Boolean,
        "<[u8]>" => Kind::ReadBytes,
        "<[f64]>" => Kind::Floats,
        _ => {
            let n = s
                .strip_prefix("<[u8]:")
                .and_then(|s| s.strip_suffix(",1>"))
                .and_then(|s| s.parse().ok())
                .ok_or("native control supports u64, bool and fixed byte columns")?;
            if !(1..=64).contains(&n) {
                return Err("fixed byte length must be 1..64".into());
            }
            Kind::Bytes(n)
        }
    };
    Ok((text(&name)?, kind))
}
fn args(node: &SyntaxNode) -> Result<(String, Vec<SyntaxNode>), String> {
    let call = FunctionCallSyntax::cast(node.clone()).ok_or("function call")?;
    let name = text(call.function().ok_or("function name")?.syntax())?;
    let arguments = call
        .arguments()
        .ok_or("call arguments")?
        .arguments()
        .into_iter()
        .map(|a| match a {
            AnyCallArgumentSyntax::Positional(x) => {
                Ok(x.value().ok_or("argument")?.syntax().clone())
            }
            _ => Err("positional arguments required".into()),
        })
        .collect::<Result<Vec<_>, String>>()?;
    Ok((name, arguments))
}
fn tuple(items: Vec<Expr>) -> Expr {
    Expr {
        kind: Kind::Tuple(items.iter().map(|e| e.kind.clone()).collect()),
        op: Op::Tuple(items),
    }
}
fn flat(kind: &Kind) -> Vec<Kind> {
    match kind {
        Kind::Tuple(k) => k.clone(),
        k => vec![k.clone()],
    }
}
struct Lower<'a> {
    source: &'a BTreeMap<String, SourceFunction>,
    functions: BTreeMap<String, Function>,
    active: BTreeSet<String>,
    catalog: &'a [&'a str],
    argument_count: usize,
    next_effect: usize,
    heap_functions: bool,
}
impl Lower<'_> {
    fn function(&mut self, name: &str) -> Result<Function, String> {
        if let Some(f) = self.functions.get(name) {
            return Ok(f.clone());
        }
        if !self.active.insert(name.to_owned()) {
            if !self.heap_functions {
                return Err("recursive functions unsupported in closed native loops".into());
            }
            let declaration = self
                .source
                .get(name)
                .ok_or("missing recursive declaration")?;
            let outputs: Vec<_> = declaration.outputs.iter().map(|(_, k)| k.clone()).collect();
            return Ok(Function {
                inputs: declaration.inputs.iter().map(|(_, k)| k.clone()).collect(),
                output: Expr {
                    kind: if outputs.len() == 1 {
                        outputs[0].clone()
                    } else {
                        Kind::Tuple(outputs)
                    },
                    op: Op::Parameter(0),
                },
            });
        }
        let source = self
            .source
            .get(name)
            .ok_or_else(|| format!("undefined source function {name}"))?
            .clone();
        let mut locals = BTreeMap::new();
        for (i, (name, kind)) in source.inputs.iter().enumerate() {
            if locals
                .insert(
                    name.clone(),
                    Expr {
                        kind: kind.clone(),
                        op: Op::Parameter(i),
                    },
                )
                .is_some()
            {
                return Err("duplicate parameter".into());
            }
        }
        let mut effects = Vec::new();
        for statement in source
            .body
            .children()
            .filter(|n| n.kind() == SyntaxKind::Statement)
        {
            let previous: BTreeSet<_> = locals.keys().cloned().collect();
            self.statement(&statement, &mut locals)?;
            if self.heap_functions {
                effects.extend(
                    locals
                        .iter()
                        .filter(|(k, _)| !previous.contains(*k))
                        .map(|(_, v)| v.clone()),
                );
            }
        }
        let mut values = Vec::new();
        for (name, kind) in &source.outputs {
            let value = locals
                .get(name)
                .ok_or_else(|| format!("undefined output {name}"))?
                .clone();
            if &value.kind != kind {
                return Err(format!(
                    "{name}: declared output differs from body {:?}",
                    value.kind
                ));
            }
            values.push(value);
        }
        let output = if values.len() == 1 {
            values.remove(0)
        } else {
            tuple(values)
        };
        let output = if self.heap_functions {
            Expr {
                kind: output.kind.clone(),
                op: Op::Sequence {
                    effects,
                    output: Box::new(output),
                },
            }
        } else {
            output
        };
        let f = Function {
            inputs: source.inputs.iter().map(|(_, k)| k.clone()).collect(),
            output,
        };
        self.functions.insert(name.to_owned(), f.clone());
        self.active.remove(name);
        Ok(f)
    }
    fn statement(
        &mut self,
        node: &SyntaxNode,
        vars: &mut BTreeMap<String, Expr>,
    ) -> Result<(), String> {
        if let Some(d) = node.children().find_map(VariableDefineSyntax::cast) {
            if d.mutability_marker().is_some() {
                return Err("native control uses immutable loop state".into());
            }
            let name = text(d.name().ok_or("definition name")?.syntax())?;
            let value = self.expr(d.value().ok_or("definition value")?.syntax(), vars)?;
            if vars.insert(name, value).is_some() {
                return Err("duplicate definition".into());
            }
            return Ok(());
        }
        if let Some(d) = node.children().find_map(TupleDestructureSyntax::cast) {
            let value = self.expr(d.value().ok_or("destructure value")?.syntax(), vars)?;
            let Kind::Tuple(kinds) = &value.kind else {
                return Err("destructure requires tuple".into());
            };
            let names = d.names();
            if names.len() != kinds.len() {
                return Err("destructure arity".into());
            }
            for (i, name) in names.into_iter().enumerate() {
                if vars
                    .insert(
                        text(name.syntax())?,
                        Expr {
                            kind: kinds[i].clone(),
                            op: Op::Field(Box::new(value.clone()), i),
                        },
                    )
                    .is_some()
                {
                    return Err("duplicate definition".into());
                }
            }
            return Ok(());
        }
        Err("native control statements require definitions or tuple destructuring".into())
    }
    fn expr(&mut self, node: &SyntaxNode, vars: &BTreeMap<String, Expr>) -> Result<Expr, String> {
        let s = text(node)?;
        let s = s.trim();
        if let Some(e) = vars.get(s) {
            return Ok(e.clone());
        }
        if node.kind() == SyntaxKind::Number {
            if s.contains('.') || s.contains('e') || s.ends_with("f64") {
                let value = s
                    .strip_suffix("f64")
                    .unwrap_or(s)
                    .parse::<f64>()
                    .map_err(|_| "f64 literal required")?;
                return Ok(Expr {
                    kind: Kind::Float,
                    op: Op::Float(value.to_bits()),
                });
            }
            return Ok(Expr {
                kind: Kind::Integer,
                op: Op::Integer(s.parse().map_err(|_| "u64 literal required")?),
            });
        }
        if let Some(l) = StringLiteralSyntax::cast(node.clone()) {
            return Ok(Expr {
                kind: Kind::Text,
                op: Op::Text(l.decoded_text().ok_or("invalid string escape")?),
            });
        }
        if s == "true" || s == "false" {
            return Ok(Expr {
                kind: Kind::Boolean,
                op: Op::Boolean(s == "true"),
            });
        }
        if node.kind() == SyntaxKind::Tuple {
            let items = node
                .children()
                .filter(|n| n.kind() == SyntaxKind::Expression)
                .map(|n| self.expr(&n, vars))
                .collect::<Result<Vec<_>, _>>()?;
            if items.is_empty() {
                return Err("empty tuple".into());
            }
            return Ok(tuple(items));
        }
        if node.kind() == SyntaxKind::FunctionCall {
            let (name, a) = args(node)?;
            if self.source.contains_key(&name) {
                let f = self.function(&name)?;
                let values = a
                    .iter()
                    .map(|x| self.expr(x, vars))
                    .collect::<Result<Vec<_>, _>>()?;
                if values.iter().map(|e| e.kind.clone()).collect::<Vec<_>>() != f.inputs {
                    return Err(format!("{name}: incompatible source arguments"));
                }
                return Ok(Expr {
                    kind: f.output.kind,
                    op: if self.heap_functions {
                        let id = self.next_effect;
                        self.next_effect += 1;
                        Op::Invoke {
                            id,
                            name,
                            arguments: values,
                        }
                    } else {
                        Op::Call(name, values)
                    },
                });
            }
            if !self.catalog.contains(&name.as_str()) {
                return Err(format!("unsupported native control operation {name}"));
            }
            if !self.active.is_empty() && name == "io/argument-u64" {
                return Err("entry arguments cannot be captured by native source functions".into());
            }
            if !self.heap_functions
                && !self.active.is_empty()
                && matches!(
                    name.as_str(),
                    "io/write" | "io/write-scan" | "io/argument-u64" | "parallel/reduce-ranges"
                )
            {
                return Err("native source callbacks must be pure; host IO and scheduling belong at the entry".into());
            }
            if name == "memory/with-ref-arena" || name == "memory/with-frame" {
                let region = name == "memory/with-ref-arena";
                if a.len() != if region { 4 } else { 2 } {
                    return Err("memory scope signature".into());
                }
                let capacity = if region {
                    Some(Box::new(self.expr(&a[0], vars)?))
                } else {
                    None
                };
                let arity = if region {
                    let e = self.expr(&a[1], vars)?;
                    let Op::Integer(n) = e.op else {
                        return Err("arena arity must be literal".into());
                    };
                    if !(1..=32).contains(&n) {
                        return Err("arena arity 1..32".into());
                    }
                    n as usize
                } else {
                    0
                };
                if capacity.as_ref().is_some_and(|e| e.kind != Kind::Integer) {
                    return Err("arena capacity must be u64".into());
                }
                let i = if region { 2 } else { 0 };
                let function = text(&a[i])?.trim().to_owned();
                let arguments = self.expr(&a[i + 1], vars)?;
                let f = self.function(&function)?;
                if f.inputs != flat(&arguments.kind)
                    || f.inputs.iter().any(|k| k != &Kind::Integer)
                    || flat(&f.output.kind).iter().any(|k| k != &Kind::Integer)
                {
                    return Err("memory scope callbacks require scalar u64 inputs and outputs; references cannot escape".into());
                }
                let id = self.next_effect;
                self.next_effect += 1;
                return Ok(Expr {
                    kind: f.output.kind,
                    op: Op::Arena {
                        id,
                        capacity,
                        arity,
                        function,
                        arguments: Box::new(arguments),
                    },
                });
            }
            if name == "control/while" {
                if a.len() != 3 {
                    return Err("control/while arity".into());
                }
                let initial = self.expr(&a[0], vars)?;
                let predicate = text(&a[1])?.trim().to_owned();
                let step = text(&a[2])?.trim().to_owned();
                let p = self.function(&predicate)?;
                let f = self.function(&step)?;
                if p.inputs != flat(&initial.kind)
                    || p.output.kind != Kind::Boolean
                    || f.inputs != p.inputs
                    || f.output.kind != initial.kind
                {
                    return Err("loop callback signatures must preserve the state".into());
                }
                return Ok(Expr {
                    kind: initial.kind.clone(),
                    op: Op::Loop {
                        id: if self.heap_functions {
                            self.next_effect += 1;
                            self.next_effect - 1
                        } else {
                            0
                        },
                        initial: Box::new(initial),
                        predicate,
                        step,
                    },
                });
            }
            if name == "control/if" {
                if a.len() != 4 {
                    return Err("control/if arity".into());
                }
                let condition = self.expr(&a[0], vars)?;
                let state = self.expr(&a[3], vars)?;
                let yes = text(&a[1])?.trim().to_owned();
                let no = text(&a[2])?.trim().to_owned();
                let y = self.function(&yes)?;
                let n = self.function(&no)?;
                if condition.kind != Kind::Boolean
                    || y.inputs != flat(&state.kind)
                    || n.inputs != y.inputs
                    || n.output.kind != y.output.kind
                {
                    return Err("conditional callback signatures".into());
                }
                return Ok(Expr {
                    kind: y.output.kind,
                    op: Op::Branch {
                        id: if self.heap_functions {
                            self.next_effect += 1;
                            self.next_effect - 1
                        } else {
                            0
                        },
                        condition: Box::new(condition),
                        yes,
                        no,
                        state: Box::new(state),
                    },
                });
            }
            if name == "parallel/reduce-ranges" {
                if a.len() != 6 {
                    return Err("parallel/reduce-ranges arity".into());
                }
                let start = self.expr(&a[0], vars)?;
                let end = self.expr(&a[1], vars)?;
                let grain = self.expr(&a[2], vars)?;
                let function = text(&a[3])?.trim().to_owned();
                let arguments = self.expr(&a[4], vars)?;
                let reducers = self.expr(&a[5], vars)?;
                let Op::Text(reducers) = reducers.op else {
                    return Err("constant reducers required".into());
                };
                let reductions: Vec<_> = reducers.split(',').map(str::to_owned).collect();
                let f = self.function(&function)?;
                let mut inputs = vec![Kind::Integer; 2];
                inputs.extend(flat(&arguments.kind));
                if inputs.iter().any(|kind| kind != &Kind::Integer) {
                    return Err("parallel range arguments must be u64 scalars".into());
                }
                if [start.kind.clone(), end.kind.clone(), grain.kind.clone()]
                    != [const { Kind::Integer }; 3]
                    || f.inputs != inputs
                    || flat(&f.output.kind) != vec![Kind::Integer; reductions.len()]
                    || reductions.iter().any(|s| s != "sum" && s != "max")
                {
                    return Err("parallel range signature/reducers".into());
                }
                return Ok(Expr {
                    kind: f.output.kind,
                    op: Op::Parallel {
                        id: if self.heap_functions {
                            self.next_effect += 1;
                            self.next_effect - 1
                        } else {
                            0
                        },
                        start: Box::new(start),
                        end: Box::new(end),
                        grain: Box::new(grain),
                        function,
                        arguments: Box::new(arguments),
                        reductions,
                    },
                });
            }
            if name == "io/write-scan" {
                if a.len() != 6 {
                    return Err("io/write-scan expects count, state, source step, width, separator, buffer size".into());
                }
                let count = self.expr(&a[0], vars)?;
                let state = self.expr(&a[1], vars)?;
                let function = text(&a[2])?.trim().to_owned();
                let width = self.expr(&a[3], vars)?;
                let separator = self.expr(&a[4], vars)?;
                let buffer = self.expr(&a[5], vars)?;
                let Op::Text(separator) = separator.op else {
                    return Err("constant scan separator required".into());
                };
                let kinds = flat(&state.kind);
                let callback = self.function(&function)?;
                let mut expected = kinds.clone();
                expected.push(Kind::Integer);
                if [count.kind.clone(), width.kind.clone(), buffer.kind.clone()]
                    != [const { Kind::Integer }; 3]
                    || kinds.len() > 32
                    || kinds
                        .iter()
                        .any(|k| !matches!(k, Kind::Integer | Kind::Float | Kind::Boolean))
                    || callback.inputs != kinds
                    || flat(&callback.output.kind) != expected
                {
                    return Err("scan step must return its scalar state followed by one unsigned byte value".into());
                }
                let id = self.next_effect;
                self.next_effect += 1;
                return Ok(Expr {
                    kind: state.kind.clone(),
                    op: Op::Scan {
                        id,
                        count: Box::new(count),
                        state: Box::new(state),
                        function,
                        width: Box::new(width),
                        separator,
                        buffer: Box::new(buffer),
                    },
                });
            }
            let values = a
                .iter()
                .map(|x| self.expr(x, vars))
                .collect::<Result<Vec<_>, _>>()?;
            self.primitive(name, values)
        } else {
            let children: Vec<_> = node.children().collect();
            if children.len() >= 3 && children.len() % 2 == 1 {
                let mut value = self.expr(&children[0], vars)?;
                for pair in children[1..].chunks(2) {
                    let op = text(&pair[0])?;
                    let rhs = self.expr(&pair[1], vars)?;
                    value = self.primitive(op.trim().to_owned(), vec![value, rhs])?;
                }
                return Ok(value);
            }
            if children.len() == 1 {
                return self.expr(&children[0], vars);
            }
            Err(format!(
                "unsupported native control syntax {:?}: {s}",
                node.kind()
            ))
        }
    }
    fn primitive(&mut self, name: String, values: Vec<Expr>) -> Result<Expr, String> {
        let kinds: Vec<_> = values.iter().map(|e| e.kind.clone()).collect();
        let int = Kind::Integer;
        let boolean = Kind::Boolean;
        if name.starts_with("heap/") || name.starts_with("memory/") || name == "io/print" {
            let id = self.next_effect;
            self.next_effect += 1;
            let (kind, op) = match name.as_str() {
                "heap/null" if values.is_empty() => (
                    Kind::Reference,
                    Op::Heap {
                        id,
                        action: 0,
                        arguments: values,
                        arity: 0,
                    },
                ),
                "heap/new-refs" if values.len() == 1 => {
                    let fields = flat(&values[0].kind);
                    if fields.is_empty()
                        || fields.len() > 32
                        || fields.iter().any(|k| k != &Kind::Reference)
                    {
                        return Err("heap/new-refs needs 1..32 reference fields".into());
                    }
                    (
                        Kind::Reference,
                        Op::Heap {
                            id,
                            action: 1,
                            arguments: values,
                            arity: fields.len(),
                        },
                    )
                }
                "heap/read-refs" if kinds == [Kind::Reference, int.clone()] => {
                    let Op::Integer(arity) = values[1].op else {
                        return Err("record arity must be literal".into());
                    };
                    if !(1..=32).contains(&arity) {
                        return Err("record arity 1..32".into());
                    }
                    (
                        Kind::Tuple(vec![Kind::Reference; arity as usize]),
                        Op::Heap {
                            id,
                            action: 2,
                            arguments: vec![values[0].clone()],
                            arity: arity as usize,
                        },
                    )
                }
                "io/print"
                    if values.len() >= 2
                        && kinds[0] == Kind::Text
                        && kinds[1..].iter().all(|k| k == &int) =>
                {
                    let Op::Text(format) = &values[0].op else {
                        return Err("literal print format required".into());
                    };
                    if format.len() > 4096
                        || values.len() > 33
                        || format.matches("{}").count() != values.len() - 1
                        || format.replace("{}", "").contains(['{', '}'])
                    {
                        return Err("print format/field count".into());
                    }
                    (
                        int.clone(),
                        Op::Print {
                            id,
                            format: format.clone(),
                            values: values[1..].to_vec(),
                        },
                    )
                }
                _ => {
                    return Err(format!(
                        "{name}: incompatible native record kinds {kinds:?}"
                    ));
                }
            };
            return Ok(Expr { kind, op });
        }
        let kind = match name.as_str() {
            "+" | "-" | "*" | "/" if kinds == [Kind::Float, Kind::Float] => Kind::Float,
            "==" | "!=" | "<" | "<=" | ">" | ">=" if kinds == [Kind::Float, Kind::Float] => boolean,
            "number/to-f64" if kinds == [int.clone()] => Kind::Float,
            "bytes/from-text" if kinds == [Kind::Text] => {
                let Op::Text(s) = &values[0].op else {
                    return Err("constant byte text required by this native subset".into());
                };
                return Ok(Expr {
                    kind: Kind::ReadBytes,
                    op: Op::ReadBytes(s.as_bytes().to_vec()),
                });
            }
            "sequence/f64-values" if kinds.len() == 1 && matches!(kinds[0], Kind::Tuple(_)) => {
                let Op::Tuple(items) = &values[0].op else {
                    return Err("constant f64 values required".into());
                };
                let bits = items
                    .iter()
                    .map(|e| match e.op {
                        Op::Float(v) => Ok(v),
                        Op::Integer(v) => Ok((v as f64).to_bits()),
                        _ => Err("literal numeric values required"),
                    })
                    .collect::<Result<Vec<_>, _>>()?;
                if bits.is_empty() || bits.len() > 4096 {
                    return Err("constant f64 column length must be 1..4096".into());
                }
                return Ok(Expr {
                    kind: Kind::Floats,
                    op: Op::Floats(bits),
                });
            }
            "sequence/cumulative-sum" if kinds == [Kind::Floats] => {
                let Op::Floats(bits) = &values[0].op else {
                    return Err(
                        "this native subset folds cumulative sums of constant columns".into(),
                    );
                };
                let mut sum = 0.0;
                let out = bits
                    .iter()
                    .map(|&bits| {
                        sum += f64::from_bits(bits);
                        sum.to_bits()
                    })
                    .collect();
                return Ok(Expr {
                    kind: Kind::Floats,
                    op: Op::Floats(out),
                });
            }
            "sequence/length"
                if kinds.len() == 1 && matches!(kinds[0], Kind::ReadBytes | Kind::Floats) =>
            {
                int
            }
            "sequence/get"
                if kinds.len() == 2 && kinds[0] == Kind::ReadBytes && kinds[1] == int =>
            {
                int
            }
            "sequence/get" if kinds.len() == 2 && kinds[0] == Kind::Floats && kinds[1] == int => {
                Kind::Float
            }
            "io/write" if kinds == [Kind::Text] => {
                let Op::Text(text) = &values[0].op else {
                    return Err("constant write text required by this native subset".into());
                };
                let id = self.next_effect;
                self.next_effect += 1;
                return Ok(Expr {
                    kind: Kind::Integer,
                    op: Op::Write {
                        id,
                        text: text.clone(),
                    },
                });
            }
            "+" | "-" | "*" | "/" | "number/mod" | "number/max"
                if kinds == [int.clone(), int.clone()] =>
            {
                int
            }
            "==" | "!=" if kinds == [Kind::Reference, Kind::Reference] => boolean,
            "==" | "!=" if kinds == [boolean.clone(), boolean.clone()] => boolean,
            "==" | "!=" | "<" | "<=" | ">" | ">=" if kinds == [int.clone(), int.clone()] => boolean,
            "&&" | "||" if kinds == [boolean.clone(), boolean.clone()] => boolean,
            "control/select" if kinds.len() == 3 && kinds[0] == boolean && kinds[1] == kinds[2] => {
                kinds[1].clone()
            }
            "number/shift-left" if kinds == [int.clone(), int.clone()] => int,
            "number/factorial" if kinds == [int.clone()] => int,
            "number/bounded" if kinds == vec![int.clone(); 3] => int,
            "io/argument-u64" if kinds == [int.clone()] => {
                let Op::Integer(i) = values[0].op else {
                    return Err("argument index must be constant".into());
                };
                if !(1..=32).contains(&i) {
                    return Err("argument index 1..32".into());
                }
                self.argument_count = self.argument_count.max(i as usize);
                int
            }
            "sequence/iota-bytes" | "sequence/zero-bytes" if kinds == [int.clone()] => {
                let Op::Integer(n) = values[0].op else {
                    return Err("small byte length must be constant".into());
                };
                if !(1..=64).contains(&n) {
                    return Err("byte length 1..64".into());
                }
                Kind::Bytes(n as usize)
            }
            "sequence/get"
                if kinds.len() == 2 && matches!(kinds[0], Kind::Bytes(_)) && kinds[1] == int =>
            {
                int
            }
            "sequence/set" | "sequence/rotate-prefix"
                if kinds.len() == 3
                    && matches!(kinds[0], Kind::Bytes(_))
                    && kinds[1] == int
                    && kinds[2] == int =>
            {
                kinds[0].clone()
            }
            "sequence/reverse-prefix"
                if kinds.len() == 2 && matches!(kinds[0], Kind::Bytes(_)) && kinds[1] == int =>
            {
                kinds[0].clone()
            }
            _ => return Err(format!("{name}: incompatible native kinds {kinds:?}")),
        };
        Ok(Expr {
            kind,
            op: Op::Primitive(name, values),
        })
    }
}

pub fn compile(source: &str, catalog: &[&str]) -> Result<Program, String> {
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(1), Revision(0), source).map_err(|e| format!("{e:?}"))?,
        ParseConfig::default(),
    );
    if !parsed.diagnostics.is_empty() {
        return Err(format!(
            "canonical control diagnostics: {:?}",
            parsed.diagnostics
        ));
    }
    let mut defs = Vec::new();
    visit(&parsed.syntax(), SyntaxKind::FunctionDefine, &mut defs);
    let mut functions = BTreeMap::new();
    for node in defs {
        let name = text(
            &node
                .children()
                .find(|n| n.kind() == SyntaxKind::Identifier)
                .ok_or("function name")?,
        )?;
        let inputs = node
            .children()
            .filter(|n| n.kind() == SyntaxKind::FunctionArg)
            .map(|n| parameter(&n))
            .collect::<Result<Vec<_>, _>>()?;
        let body = node
            .children()
            .find(|n| n.kind() == SyntaxKind::FunctionDefineStatements)
            .ok_or("statement body required")?;
        let out = body
            .children()
            .find(|n| {
                matches!(
                    n.kind(),
                    SyntaxKind::FunctionOutArg | SyntaxKind::FunctionOutArgs
                )
            })
            .ok_or("function outputs")?;
        let mut outputs = Vec::new();
        visit(&out, SyntaxKind::FunctionArg, &mut outputs);
        let outputs = outputs
            .iter()
            .map(parameter)
            .collect::<Result<Vec<_>, _>>()?;
        if outputs.is_empty() {
            return Err("function output required".into());
        }
        if functions
            .insert(
                name,
                SourceFunction {
                    inputs,
                    outputs,
                    body,
                },
            )
            .is_some()
        {
            return Err("duplicate function".into());
        }
    }
    let heap_functions = functions.values().any(|f| {
        f.inputs
            .iter()
            .chain(f.outputs.iter())
            .any(|(_, k)| k == &Kind::Reference)
    }) || {
        let mut calls = Vec::new();
        visit(&parsed.syntax(), SyntaxKind::FunctionCall, &mut calls);
        calls.iter().any(|n| {
            args(n).is_ok_and(|(name, _)| {
                name.starts_with("heap/") || name.starts_with("memory/") || name == "io/print"
            })
        })
    };
    let mut lower = Lower {
        source: &functions,
        functions: BTreeMap::new(),
        active: BTreeSet::new(),
        catalog,
        argument_count: 0,
        next_effect: 0,
        heap_functions,
    };
    let mut vars = BTreeMap::new();
    let mut roots = Vec::new();
    visit(&parsed.syntax(), SyntaxKind::MechCodeAlt, &mut roots);
    let mut output = None;
    let mut effects = Vec::new();
    let mut effect_ids = BTreeSet::new();
    fn collect_effects(e: &Expr, ids: &mut BTreeSet<usize>) -> bool {
        let mut new = false;
        match &e.op {
            Op::Write { id, .. } => new |= ids.insert(*id),
            Op::Scan {
                id,
                count,
                state,
                width,
                buffer,
                ..
            } => {
                for e in [count, state, width, buffer] {
                    new |= collect_effects(e, ids);
                }
                new |= ids.insert(*id);
            }
            Op::Tuple(a) | Op::Call(_, a) | Op::Primitive(_, a) => {
                for e in a {
                    new |= collect_effects(e, ids);
                }
            }
            Op::Field(e, _) => new |= collect_effects(e, ids),
            Op::Loop { initial, .. } => new |= collect_effects(initial, ids),
            Op::Branch {
                condition, state, ..
            } => {
                new |= collect_effects(condition, ids);
                new |= collect_effects(state, ids);
            }
            Op::Parallel {
                start,
                end,
                grain,
                arguments,
                ..
            } => {
                for e in [start, end, grain, arguments] {
                    new |= collect_effects(e, ids);
                }
            }
            _ => {}
        }
        new
    }
    for root in roots {
        if root.children().all(|n| n.kind() == SyntaxKind::Comment) {
            continue;
        }
        if root
            .children()
            .any(|n| n.kind() == SyntaxKind::FunctionDefine)
        {
            continue;
        }
        let mut stmt = Vec::new();
        visit(&root, SyntaxKind::Statement, &mut stmt);
        if stmt.iter().any(|s| {
            s.children().any(|c| {
                matches!(
                    c.kind(),
                    SyntaxKind::VariableDefine | SyntaxKind::TupleDestructure
                )
            })
        }) {
            for s in stmt {
                let previous: BTreeSet<_> = vars.keys().cloned().collect();
                lower.statement(&s, &mut vars)?;
                for (name, value) in &vars {
                    if (heap_functions && !previous.contains(name))
                        || collect_effects(value, &mut effect_ids)
                    {
                        effects.push(value.clone());
                    }
                }
            }
            continue;
        }
        let mut calls = Vec::new();
        visit(&root, SyntaxKind::FunctionCall, &mut calls);
        let call = calls.first().ok_or("top-level output call required")?;
        let (name, a) = args(call)?;
        let mut nested = Vec::new();
        if name == "io/write" && a.len() == 1 {
            visit(&a[0], SyntaxKind::FunctionCall, &mut nested);
        }
        if name == "io/print"
            || name == "io/write-scan"
            || (name == "io/write" && a.len() == 1 && nested.is_empty())
        {
            let value = lower.expr(call, &vars)?;
            collect_effects(&value, &mut effect_ids);
            effects.push(value);
            continue;
        }
        if name != "io/write" || a.len() != 1 || output.is_some() {
            return Err("one io/write required".into());
        }
        let mut f = Vec::new();
        visit(&a[0], SyntaxKind::FunctionCall, &mut f);
        let (name, a) = args(f.first().ok_or("text/format output required")?)?;
        if name != "text/format" || a.len() < 2 {
            return Err("text/format expects format and scalar fields".into());
        }
        let format = lower.expr(&a[0], &vars)?;
        let Op::Text(format) = format.op else {
            return Err("constant format required".into());
        };
        let values = a[1..]
            .iter()
            .map(|x| lower.expr(x, &vars))
            .collect::<Result<Vec<_>, _>>()?;
        if values.iter().any(|v| v.kind != Kind::Integer)
            || (format.matches("{}").count() + format.matches("{:i64}").count()) != values.len()
            || values.len() > 64
            || format
                .replace("{}", "")
                .replace("{:i64}", "")
                .contains(['{', '}'])
        {
            return Err("format field count/kinds".into());
        }
        output = Some((format, tuple(values)));
    }
    let (format, output) = match output {
        Some(out) => out,
        None if !effects.is_empty() => (String::new(), tuple(Vec::new())),
        None => return Err("missing native control output".into()),
    };
    // IO and range scheduling belong only to the outer coordinator.
    fn pure(e: &Expr) -> bool {
        match &e.op {
            Op::Primitive(n, a) => n != "io/argument-u64" && a.iter().all(pure),
            Op::Tuple(a) | Op::Call(_, a) => a.iter().all(pure),
            Op::Field(e, _) => pure(e),
            Op::Loop { initial, .. } => pure(initial),
            Op::Branch {
                condition, state, ..
            } => pure(condition) && pure(state),
            Op::Parallel { .. } => false,
            Op::Write { .. } | Op::Scan { .. } => false,
            _ => true,
        }
    }
    if !heap_functions && lower.functions.values().any(|f| !pure(&f.output)) {
        return Err("native callback must be pure".into());
    }
    if heap_functions {
        fn closed(
            e: &Expr,
            functions: &BTreeMap<String, Function>,
            seen: &mut BTreeSet<String>,
            allow_heap: bool,
        ) -> bool {
            let visit_name = |name: &str, seen: &mut BTreeSet<String>| {
                !seen.insert(name.to_owned())
                    || closed(&functions[name].output, functions, seen, allow_heap)
            };
            match &e.op {
                Op::Print { .. } | Op::Write { .. } | Op::Scan { .. } | Op::Parallel { .. } => {
                    false
                }
                Op::Arena {
                    capacity,
                    function,
                    arguments,
                    ..
                } => {
                    allow_heap
                        && visit_name(function, seen)
                        && capacity
                            .as_ref()
                            .is_none_or(|e| closed(e, functions, seen, allow_heap))
                        && closed(arguments, functions, seen, allow_heap)
                }
                Op::Heap { arguments, .. } => {
                    allow_heap
                        && arguments
                            .iter()
                            .all(|e| closed(e, functions, seen, allow_heap))
                }
                Op::Primitive(n, a) => {
                    n != "io/argument-u64"
                        && a.iter().all(|e| closed(e, functions, seen, allow_heap))
                }
                Op::Invoke {
                    name, arguments, ..
                }
                | Op::Call(name, arguments) => {
                    visit_name(name, seen)
                        && arguments
                            .iter()
                            .all(|e| closed(e, functions, seen, allow_heap))
                }
                Op::Sequence { effects, output } => effects
                    .iter()
                    .chain(std::iter::once(output.as_ref()))
                    .all(|e| closed(e, functions, seen, allow_heap)),
                Op::Tuple(a) => a.iter().all(|e| closed(e, functions, seen, allow_heap)),
                Op::Field(e, _) => closed(e, functions, seen, allow_heap),
                Op::Loop {
                    initial,
                    predicate,
                    step,
                    ..
                } => {
                    closed(initial, functions, seen, allow_heap)
                        && visit_name(predicate, seen)
                        && visit_name(step, seen)
                }
                Op::Branch {
                    condition,
                    state,
                    yes,
                    no,
                    ..
                } => {
                    closed(condition, functions, seen, allow_heap)
                        && closed(state, functions, seen, allow_heap)
                        && visit_name(yes, seen)
                        && visit_name(no, seen)
                }
                _ => true,
            }
        }
        fn scheduling(e: &Expr, functions: &BTreeMap<String, Function>) -> Result<(), String> {
            match &e.op {
                Op::Parallel { function, .. } | Op::Scan { function, .. } => {
                    if !closed(
                        &functions[function].output,
                        functions,
                        &mut BTreeSet::new(),
                        matches!(&e.op, Op::Parallel { .. }),
                    ) {
                        return Err("native worker callback must be closed: no IO, entry arguments, nested scheduling or heap state in scans".into());
                    }
                }
                Op::Sequence { effects, output } => {
                    for e in effects.iter().chain(std::iter::once(output.as_ref())) {
                        scheduling(e, functions)?;
                    }
                }
                Op::Invoke { arguments, .. }
                | Op::Call(_, arguments)
                | Op::Tuple(arguments)
                | Op::Primitive(_, arguments)
                | Op::Heap { arguments, .. } => {
                    for e in arguments {
                        scheduling(e, functions)?;
                    }
                }
                Op::Arena {
                    capacity,
                    arguments,
                    ..
                } => {
                    if let Some(e) = capacity {
                        scheduling(e, functions)?;
                    }
                    scheduling(arguments, functions)?;
                }
                Op::Field(e, _) => scheduling(e, functions)?,
                Op::Branch {
                    condition, state, ..
                } => {
                    scheduling(condition, functions)?;
                    scheduling(state, functions)?;
                }
                Op::Loop { initial, .. } => scheduling(initial, functions)?,
                _ => {}
            }
            Ok(())
        }
        for f in lower.functions.values() {
            scheduling(&f.output, &lower.functions)?;
        }
        for e in effects.iter().chain(std::iter::once(&output)) {
            scheduling(e, &lower.functions)?;
        }
    }
    Ok(Program {
        heap_functions,
        functions: lower.functions,
        output,
        format,
        argument_count: lower.argument_count,
        effects,
    })
}
