# Binary trees — Apple M3

This eighth benchmark uses the official performance input **N=21**. The workload
constructs and traverses 613,766,494 nodes, including separately allocated leaves.
It discards the stretch tree, retains the long-lived tree throughout temporary
work, and checks that tree last.

## Purpose and current language findings

The purpose is to stress Mech's language and stdlib across domains. Benchmark
algorithms must remain in Mech source using standard forms wherever available.
Missing expressiveness is a finding to record, not a reason to hide the algorithm
behind a host library call. Runtime/library additions and compiler optimizations
must apply to other programs; benchmark recognition, dedicated kernels, and
benchmark-specific execution modes are excluded.

`binarytrees.mec` and `binarytrees-parallel.mec` define construction, recursive
traversal, loop state, checks, and output in Mech. Both are complete sources. The
backend contains no tree construction/traversal kernel or node-count shortcut.

This native subset lacked source recursion and linked dynamic records. It now
supports ordinary record literals, declared record kinds and aliases, nested
fields, field annotations, and named field access. Records can be function
arguments/results and loop state. Source recursion compiles to ordinary native
calls with checked depth; acyclic helpers inline and scalar results return in
registers.

The benchmark declares `<node> := <{left<ref>, right<ref>}>`; construction uses
ordinary record literals and traversal reads `.left` and `.right`. Managed links
use the new opaque `<ref>` kind, with an explicit record kind on reads. They are
nullable, scoped links into homogeneous record arenas. This implements linked
recursive data through general memory operations. Implicit recursive kind
aliases, mutable/cyclic links, and pointer-containing records that outlive their
scope remain unsupported; these are explicit language findings.

## Arena integration

The rejected initial implementation used one `Box` per node and a thread-local
`HashMap` ownership registry. It bypassed Mech's existing planned arenas. Its
unfinished measurements and complete compiler snapshot are preserved in
`results/apple-m3-individual-box-abandoned.json` and the corresponding archive;
its sources are in `experiments/individual-box/`. It is not a completed study.

The current implementation uses **existing core memory authority**:
`MemoryDomain`, `RealizedMemoryPlan`, and `PlannedArenaProjection<u64>`.
`memory/with-arena(capacity, <record-kind>, callback, arguments)` realizes one
planned contiguous block and invokes source code synchronously in that exclusive
projection. `memory/with-frame(callback, arguments)` retires a bounded nested
lifetime without another physical allocation. Arguments/results may be copied
scalars or records of scalars; references, including nested reference fields,
cannot escape or cross regions. Workers create independent realizations; the
long-lived tree stays in its coordinator region.

`memory/null`, `memory/allocate(record)`, and `memory/read(ref, <record-kind>)`
provide links and typed views of ordinary records. Supported layouts contain
1–32 u64, f64, bool, or reference lanes, including nested records. Each source
layout has a distinct same-object identifier: equal arity alone cannot authorize
a differently typed or named read. Allocation/read lower to checked native
stores/loads. A proven live matching layout may select a private native function
entry without repeating that check; capacity, live-handle, and recursion checks
remain. Proofs follow control-flow dominance and do not escape branches or
possibly empty loops.

The low-level `heap/null`, `heap/new-refs`, `heap/read-refs`, and
`memory/with-ref-arena` forms remain for compatibility/conformance. The benchmark
uses ordinary named records instead. Per-node `take`/`stats` APIs were removed.
There is no free list, ownership map, or special tree allocator. The program
chooses storage capacity and lifetime; that capacity calculation does not replace
constructing and visiting every node.

## Validation and timing

`conformance.py` checks byte-exact outputs, distinct leaves and aliases, scope
escape rejection, capacity/arity guards, bounded frame reuse, nested regions,
recursion depth, shift bounds, ordered IO, and closed workers. `regressions.py`
checks byte-identical FASTA and fannkuch native objects and full FASTA output.
`records_conformance.py` exercises non-tree payload records, nested fields,
record loop state, mixed scalar codecs, aggregate calls, layout mismatches, and
proof dominance. `audit.py` checks production unsafe boundaries while excluding
generated projects.

The foreign cohort pins 35 submissions across Chapel, Julia, Rust, Go, Java, C,
and C++. C/C++ use GCC and LLVM builds; Rust uses normal and thin-LTO builds
against the same locked bitcode-enabled dependencies. Java uses OpenJDK JIT,
explicitly labeled because the submissions were published with GraalVM AOT.
Documented macOS shims supply standard malloc declarations and CPU enumeration.
LLVM libc++ cannot compile C++ #7's required parallel execution policy; GCC can.
The report labels individual allocation, default GC, and library pool policies.

Timing runs one fresh process at a time with complete output to a regular file.
Three samples per build are shuffled with a fixed seed. Compilation, tests,
rendering, and output hashing are outside timing. Full N=21 output must match
455 bytes with SHA256
`341de11a51feab3d8122b4b5d6a68b038a2d14434aa9bc2372f39300bf5f48e1`.
The official N=10 reference and hashes are retained alongside pinned sources.

The performance target is Rust's approximately **0.7 seconds**, with C's
approximately **3.3 seconds** as an intermediate milestone. Measurements, rather
than that target, determine the result.

## Reproduction

```sh
RUSTFLAGS='-D warnings -C target-cpu=native' \
  CARGO_TARGET_DIR=benchmarks/clbg/nbody/mech-driver/target \
  cargo build --release --locked --offline --features cranelift_build
RUSTFLAGS='-C target-cpu=native -C embed-bitcode=yes' \
  CARGO_TARGET_DIR=benchmarks/clbg/binarytrees/.build/rust-deps-bitcode \
  cargo build --release --locked \
  --manifest-path benchmarks/clbg/binarytrees/rust-deps/Cargo.toml
python3 benchmarks/clbg/binarytrees/conformance.py
python3 benchmarks/clbg/binarytrees/records_conformance.py
python3 benchmarks/clbg/binarytrees/regressions.py
python3 benchmarks/clbg/binarytrees/audit.py
python3 benchmarks/clbg/binarytrees/run.py --prepare-only
python3 benchmarks/clbg/binarytrees/run.py --reuse-builds --samples 3 --timeout 600
```

Run stages sequentially. Exact source pins, author comments, licenses, build
commands, compiler snapshots, worker settings, and exclusions are retained.

- [Official work and allocation rules](https://benchmarksgame-team.pages.debian.net/benchmarksgame/description/binarytrees.html)
- [Published cohort](https://benchmarksgame-team.pages.debian.net/benchmarksgame/performance/binarytrees.html)
