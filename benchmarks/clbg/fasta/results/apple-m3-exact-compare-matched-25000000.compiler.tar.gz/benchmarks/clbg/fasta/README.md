# FASTA: complete Mech sources and native execution

This is the seventh local Benchmarks Game study for the experimental v0.4
integration. Both programs contain their full generation and selection algorithm
in Mech. Cranelift emits the arithmetic, comparisons, source function calls and
native scan loops. Rust supplies general bounded IO, state storage and CLI
support; there is no host FASTA generator or nucleotide-selection kernel.

| Source | Noncomment LOC | Normalized gzip-1 bytes | Final median |
| --- | ---: | ---: | ---: |
| [Compact binary search](fasta.mec) | 33 | 827 | 3.008 s |
| [Expanded linear comparison count](fasta-optimized.mec) | 44 | 834 | 1.238 s |

The expanded program is 2.43 times faster with eleven additional source lines.
It is a line between two sources on the corner chart. Its `Count` helper is
written entirely in Mech. All fourteen IUB and three human threshold comparisons
are visible in the counted source. Compiler policies of one, four and eight
iterations per native scan loop are effectively tied in the final measurements.

## Required work and validation

At N = 25,000,000, each run produces 250,000,000 bases: 2N copies of the ALU
sequence, 3N IUB bases and 5N human bases. The random records share the prescribed
LCG state, beginning at seed 42. Every random base advances the generator and
uses direct f64 division and cumulative probabilities. Headers and 60-column
line wrapping are included.

All 65 admitted builds match the complete 254,166,745-byte reference output.
The small reference is the official N = 1000 output; the full reference comes
from the independently compiled C #1 generator already used for k-nucleotide.
Hashes, sizes and reference provenance are in [reference-pins.json](reference-pins.json).
The full SHA-256 is
`3fcf4f78104c8a65ef210fe1d469f4e473456c791225f2f1f9114f4986aa09fa`.

## Reusable language and compiler support

The new operations are `number/to-f64`, `bytes/from-text`, literal
`sequence/f64-values`, ordered `sequence/cumulative-sum`, readonly-column
`sequence/length` and `sequence/get`, literal `io/write`, and
`io/write-scan(count, state, sourceStep, width, separator, bufferSize)`.
The scan accepts up to 32 scalar integer, floating or Boolean state fields;
the source callback returns the next state and one byte. Buffering and line
wrapping are generic IO operations. The generator and search stay in the
native callback emitted from source. Source callbacks must be closed and pure.

The compiler works from typed graph operations and proven value domains:

- Literal indexed floating reads fold to their exact bit patterns.
- Independent Boolean floating comparisons followed by integer sums can pack
  into f64 SIMD comparisons. IEEE predicates and integer wrapping are preserved.
- Scan unrolling preserves state order and uses a scalar tail. The automatic
  policy avoids expanding callbacks with nested loops, where measurements show
  that expansion hurts the compact search.
- Inductive scan-state bounds and no-overflow proofs allow exact constant
  unsigned division through a low-product reciprocal and one shift.
- Readonly array checks disappear only when the index is positive and an exact
  array length proves its upper bound. Unknown or invalid indices retain guards.

These rules do not inspect benchmark names or recognize a particular RNG.
The reciprocal is derived from the divisor and proven dividend range. Its
correctness condition prevents crossing a quotient boundary, and the compiler
also proves that the widened product fits in 64 bits.

## Why indiscriminate 32-bit narrowing loses

On this AArch64 backend, narrow arithmetic often acquires an explicit extension
when its result rejoins a u64 graph. Cranelift's original I32 high-multiply
remainder recipe also used two extensions and two dependent shifts. LLVM's C
version uses `umull`, one shift and `msub`.

The new exact reciprocal lowering removes the extra shift. Keeping values in
their existing registers avoids the extensions. Matched five-sample results
with the same array-check improvements are:

| Compiler policy, optimized source, unroll 8 | Median |
| --- | ---: |
| Wide arithmetic and original wide remainder | 1.235 s |
| Full range-proved 32-bit narrowing, improved remainder | 1.378 s |
| Selective narrowing, improved remainder | 1.237 s |
| C #2, LLVM | 1.375 s |

See [the matched width study](results/apple-m3-bounds-25000000.json). On AArch64,
selective narrowing is the automatic scan policy. Source u64 semantics remain
intact. `MECH_CONTROL_NARROW_UINT=0` disables narrowing;
`MECH_CONTROL_NARROW_UINT=1` enables the full experiment;
`MECH_CONTROL_NARROW_ARITHMETIC=0` retains wide arithmetic in that experiment.
Other targets retain the previous default pending measurements.

The final matched default run measures Mech at 1.238 s and C #2 LLVM at 1.379 s,
about 10% less elapsed time for Mech. The initial expanded source measured
1.685 s. Bounds-check elimination accounts for most of the later improvement;
it should not be attributed entirely to integer width.

## Comparison cohorts and charts

[The current description](https://benchmarksgame-team.pages.debian.net/benchmarksgame/description/fasta.html)
prescribes cumulative probability lookup and restricts alternative generator
and lookup algorithms. [algorithm-audit.json](algorithm-audit.json) records a
conservative source-arithmetic cohort separately from the historical listings.
Both retain their measured full-output results.

The strict chart contains 24 builds. The full historical chart includes scaled
integer thresholds, floating reciprocal substitutions, lookup tables,
period reuse and noncumulative selection, each labeled in the audit. In
particular, the fastest listed Rust #7 uses scaled thresholds and measures
0.963 s locally; the fastest admitted strict Rust source measures about 3.62 s.
The Mech-versus-C result above refers to the strict source cohort.

The final report combines the 56 foreign-language builds from the broad run
with nine final Mech policies. Each measurement batch is normalized to its own
C #2 LLVM median; raw elapsed seconds and original reports remain available.

- [Final combined report](results/apple-m3-final-25000000.json)
- [Strict LOC chart](results/apple-m3-final-25000000.corner.loc.png)
- [Strict compressed-source chart](results/apple-m3-final-25000000.corner.png)
- [Historical LOC chart](results/apple-m3-final-25000000.corner.historical.loc.png)
- [Historical compressed-source chart](results/apple-m3-final-25000000.corner.historical.png)
- [Strict endpoint table](results/apple-m3-final-25000000.corner.loc.table.md)
- [Seven-benchmark overview exports](../overview/mega-endpoints.json)

The pinned manifest contains 42 submissions. Ten build configurations are
explicitly excluded: C++ #9 needs unavailable Boost; C++ #7 does not compile;
C++ #4 needs Linux `fwrite_unlocked`; C #4 has malformed pinned source; and
Java #5/#6 fail the official small output. C/C++ exclusions apply to both GCC
and LLVM. Original diagnostics are retained. Sources and authors' comments
remain unmodified, and upstream licensing is preserved.

## Protocol, checks and reproduction

Measurements use an Apple M3, randomized sequential fresh processes, complete
output to a regular file, and three or five samples per build. Process startup,
CLI work, IO and JIT startup are included. Compilation, output hashing, tests
and rendering run outside timing. Eight workers are requested; source limits
vary, Chapel caps at four, and Mech's stateful scan is sequential. Java runs
OpenJDK JIT rather than the site's native AOT configuration. These are local
exploratory results, with close differences treated as measurement variation.

The final compiler passes [1,567 conformance checks](results/conformance.json),
including unsigned quotient/remainder limits, typed state, NaNs, infinities,
mixed SIMD predicates, block tails, output order, invalid indices, overflowing
indices and callback purity. The scoped unsafe-boundary audit passes.

[Eleven previous benchmark variants](results/regressions-final.json) produce
identical native objects and full outputs. A
[seven-sample focused recheck](results/regressions-focused.json) resolves the
initial timing outliers: spectral norm is within about 2%, and compact
fannkuch is essentially unchanged. No reproducible slowdown was identified.

Each raw report includes compiler-source archives, overlay hashes, native
object and executable hashes, build commands, environments and generated
project files. Before the final policy rebuild, existing Mech executables and
objects were preserved by hash in `.build/preserved/`; the later width
experiments have separate reports and binaries.

Build the compiler from this workspace:

```sh
RUSTFLAGS='-D warnings -C target-cpu=native' \
CARGO_TARGET_DIR=benchmarks/clbg/nbody/mech-driver/target \
cargo build --release --locked --offline --features cranelift_build
```

Then build pinned Rust dependencies, prepare competitors with `run.py
--prepare-only`, and prepare all Mech policies with `prepare_mech.py`. The
Rust dependency build requires `RUSTFLAGS='-Cembed-bitcode=yes'` for thin LTO.
Tool paths, exact flags and dependency locks are recorded in the scripts and
reports. `fetch_sources.py` refuses to overwrite an existing manifest.

```sh
python3 benchmarks/clbg/fasta/conformance.py
python3 benchmarks/clbg/fasta/audit.py
python3 benchmarks/clbg/fasta/run.py --reuse-builds --samples 5 \
  --output benchmarks/clbg/fasta/results/local-recheck.json
python3 benchmarks/clbg/fasta/merge_results.py
python3 benchmarks/clbg/fasta/plot.py benchmarks/clbg/fasta/results/apple-m3-final-25000000.json
python3 benchmarks/clbg/overview/build_gallery.py
python3 benchmarks/clbg/overview/plot_mega.py
```

Plotting requires matplotlib; the measurements themselves use Python's standard
library. Run timing alone. The original reports are preserved rather than
replaced by newly observed medians.
