#!/usr/bin/env python3
"""Preserve and measure exact compiler optimizations against matched controls."""
import argparse
import copy
import json
import os
import random
import statistics
from datetime import datetime, timezone
from pathlib import Path

import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--reuse-builds', action='store_true')
    parser.add_argument('--samples', type=int, default=5)
    parser.add_argument('--only', help='Comma-separated build identifiers')
    parser.add_argument('--output', type=Path, default=run.HERE / 'results/apple-m3-exact-compare-matched-25000000.json')
    args = parser.parse_args()
    if args.samples < 3:
        parser.error('At least three samples are required')
    folder = run.BUILD / 'optimize-20261008'
    prepared = folder / 'prepared.json'
    env = os.environ | {'RAYON_NUM_THREADS': '8'}
    if args.reuse_builds:
        rows = json.loads(prepared.read_text())
    else:
        previous_path = run.HERE / 'results/apple-m3-final-25000000.json'
        previous = json.loads(previous_path.read_text())
        rows = []
        for id in ('mech-fasta-compact', 'mech-fasta-optimized', 'fasta-rust-7-thin', 'fasta-gcc-2-llvm'):
            row = copy.deepcopy(next(r for r in previous['programs'] if r['id'] == id))
            row['id'] += '-before' if row['language'] == 'mech' else '-control'
            row['command'] = [str(folder / (id + '-before'))]
            assert run.sha(row['command'][0]) == row['executable_sha256']
            row['comparison_stage'] = 'before' if row['language'] == 'mech' else 'foreign'
            row['previous_report'] = previous_path.name
            rows.append(row)
        compiler = argparse.Namespace(mech=str(run.ROOT / 'benchmarks/clbg/nbody/mech-driver/target/release/mech'), threads=8, timeout=300)
        policies = [('compact', 'fasta.mec', True, 1, True),
                    ('compact-u4', 'fasta.mec', True, 4, True),
                    ('expanded', 'fasta-optimized.mec', True, 1, True),
                    ('expanded-u4', 'fasta-optimized.mec', True, 4, True),
                    ('expanded-u8', 'fasta-optimized.mec', True, 8, True),
                    ('expanded-scalar', 'fasta-optimized.mec', False, 1, True),
                    ('expanded-no-exact', 'fasta-optimized.mec', True, 1, False)]
        for policy, source, simd, unroll, exact in policies:
            p = dict(id='mech-fasta-exact-' + policy + '-v2', language='mech', path=source,
                     simd=simd, scan_unroll=unroll, exact_float_compare=exact,
                     upstream_starred=False, comparison_stage='after',
                     algorithm=dict(strict=True, reason='Source f64 division and comparisons preserved exactly by range-proved compiler lowering.'))
            rows.append(run.prepare(p, compiler, env))
            print('prepared', p['id'], flush=True)
        prepared.write_text(json.dumps(rows, indent=2) + '\n')
    if args.prepare_only:
        return
    if args.only:
        ids = set(args.only.split(','))
        rows = [r for r in rows if r['id'] in ids]
        if {r['id'] for r in rows} != ids:
            parser.error('Unknown build identifier')
    for row in rows:
        assert run.sha(row['command'][0]) == row['executable_sha256']
        assert run.sha(run.HERE / row['path']) == row['source']['sha256']
        for n, key in ((1000, 'correctness_1000'), (25000000, 'correctness_25000000')):
            result = run.execute(row['command'], env | row.get('runtime_environment', {}), n, 300)
            row[key] = result['validation']
        row['samples_seconds'] = []
        print('full output passed', row['id'], flush=True)
    orders = []
    rng = random.Random(20261008)
    for sample in range(args.samples):
        order = rows.copy()
        rng.shuffle(order)
        orders.append([r['id'] for r in order])
        for row in order:
            result = run.execute(row['command'], env | row.get('runtime_environment', {}), 25000000, 300)
            row['samples_seconds'].append(result['seconds'])
            print(sample + 1, row['id'], result['seconds'], flush=True)
    for row in rows:
        row.update(median_seconds=statistics.median(row['samples_seconds']),
                   min_seconds=min(row['samples_seconds']), max_seconds=max(row['samples_seconds']))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    old = json.loads((run.HERE / 'results/apple-m3-final-25000000.json').read_text())
    protocol = dict(old['protocol'], samples=args.samples, sample_order=orders,
                    environment={'RAYON_NUM_THREADS': '8'},
                    normalization='All displayed matched times are raw elapsed seconds from the same randomized batch.')
    result = dict(schema_version=1, created_at=datetime.now(timezone.utc).isoformat(), hardware=old['hardware'],
                  protocol=protocol, programs=rows, excluded=[],
                  compiler_snapshot=run.snapshot(args.output),
                  previous_report=dict(path='apple-m3-final-25000000.json', sha256=run.sha(run.HERE / 'results/apple-m3-final-25000000.json')))
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    for row in rows:
        print('median', row['id'], f"{row['median_seconds']:.6f}", flush=True)


if __name__ == '__main__':
    main()
