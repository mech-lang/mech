use cranelift_codegen::{
    ir::{
        condcodes::{FloatCC, IntCC},
        immediates::Ieee64,
        types, AbiParam, ConstantData, InstBuilder, MemFlags, StackSlotData, StackSlotKind, Type,
        Value,
    },
    settings::{self, Configurable},
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{default_libcall_names, DataDescription, DataId, FuncId, Linkage, Module};
use cranelift_object::{ObjectBuilder, ObjectModule};
use mech_engine::native_sequence::control::{Expr, Kind, Op, Program};
use std::{collections::BTreeMap, path::Path};
type Values = Vec<Value>;
/// An exact reciprocal for every unsigned dividend in 0..=maximum.
/// For m = ceil(2^s / d), let e = m*d - 2^s. If e*maximum < 2^s,
/// the approximation cannot cross the next quotient boundary, even for
/// remainder d-1. The product must also fit the emitted 64-bit multiply.
fn bounded_reciprocal(divisor: u64, maximum: u64) -> Option<(u64, u32)> {
    if divisor == 0 || maximum > u32::MAX as u64 || divisor > u32::MAX as u64 {
        return None;
    }
    for shift in 32..64 {
        let scale = 1u128 << shift;
        let multiplier = scale.div_ceil(divisor as u128);
        if multiplier > u32::MAX as u128 {
            return None;
        }
        let error = multiplier * divisor as u128 - scale;
        if error * (maximum as u128) < scale && multiplier * (maximum as u128) <= u64::MAX as u128 {
            return Some((multiplier as u64, shift));
        }
    }
    None
}
#[derive(Clone)]
struct FloatCount {
    comparison: FloatCC,
    left: Value,
    right: Value,
    scalar: Value,
}
#[derive(Clone, Default)]
struct CountSum {
    terms: Vec<FloatCount>,
    other: Values,
}
fn types_for(k: &Kind) -> Vec<Type> {
    match k {
        Kind::Integer => vec![types::I64],
        Kind::Float => vec![types::F64],
        Kind::Boolean => vec![types::I8],
        Kind::Bytes(n) => vec![types::I8X16; n.div_ceil(16)],
        Kind::ReadBytes | Kind::Floats => vec![types::I64; 2],
        Kind::Tuple(k) => k.iter().flat_map(types_for).collect(),
        Kind::Text => vec![],
    }
}
// Conservative value domains: a proof over source operations, never input names.
fn abstract_bounds(e: &Expr, params: &[Option<u64>], program: &Program) -> Vec<Option<u64>> {
    let count = types_for(&e.kind).len();
    match &e.op {
        Op::Integer(n) => vec![Some(*n)],
        Op::Float(_) => vec![None],
        Op::ReadBytes(bytes) => vec![None, Some(bytes.len() as u64)],
        Op::Floats(bits) => vec![None, Some(bits.len() as u64)],
        Op::Boolean(b) => vec![Some(u64::from(*b))],
        Op::Text(_) => vec![],
        Op::Parameter(i) => params[*i..*i + count].to_vec(),
        Op::Tuple(a) => a
            .iter()
            .flat_map(|e| abstract_bounds(e, params, program))
            .collect(),
        Op::Field(e, i) => {
            let Kind::Tuple(k) = &e.kind else {
                unreachable!()
            };
            let first: usize = k[..*i].iter().map(|k| types_for(k).len()).sum();
            let values = abstract_bounds(e, params, program);
            values[first..first + types_for(&k[*i]).len()].to_vec()
        }
        Op::Call(name, a) => {
            let values = a
                .iter()
                .flat_map(|e| abstract_bounds(e, params, program))
                .collect::<Vec<_>>();
            abstract_bounds(&program.functions[name].output, &values, program)
        }
        Op::Loop { initial, step, .. } => loop_bounds(
            abstract_bounds(initial, params, program),
            step,
            &e.kind,
            program,
        ),
        Op::Branch { yes, no, state, .. } => {
            let state = abstract_bounds(state, params, program);
            let a = abstract_bounds(&program.functions[yes].output, &state, program);
            let b = abstract_bounds(&program.functions[no].output, &state, program);
            a.iter()
                .zip(b)
                .map(|(a, b)| a.zip(b).map(|(a, b)| a.max(b)))
                .collect()
        }
        Op::Parallel { .. } => vec![None; count],
        Op::Write { .. } => vec![Some(0)],
        Op::Scan {
            state, function, ..
        } => scan_bounds(abstract_bounds(state, params, program), function, program),
        Op::Primitive(name, a) => {
            let bounds = a
                .iter()
                .map(|e| abstract_bounds(e, params, program))
                .collect::<Vec<_>>();
            let x = bounds.first().and_then(|v| v.first()).copied().flatten();
            let y = bounds.get(1).and_then(|v| v.first()).copied().flatten();
            match name.as_str() {
                "sequence/iota-bytes" => {
                    let Kind::Bytes(n) = e.kind else {
                        unreachable!()
                    };
                    vec![Some((n - 1) as u64); count]
                }
                "sequence/zero-bytes" => vec![Some(0); count],
                "sequence/reverse-prefix" | "sequence/rotate-prefix" => bounds[0].clone(),
                "sequence/set" => {
                    let max = bounds[0]
                        .iter()
                        .copied()
                        .collect::<Option<Vec<_>>>()
                        .map(|b| b.into_iter().max().unwrap());
                    let value = bounds[2][0].unwrap_or(255).min(255);
                    vec![Some(max.unwrap_or(255).max(value)); count]
                }
                "sequence/length" => vec![bounds[0][1]],
                "sequence/get" if a[0].kind == Kind::Floats => vec![None],
                "sequence/get" if a[0].kind == Kind::ReadBytes => vec![Some(255)],
                "sequence/get" => vec![Some(
                    bounds[0]
                        .iter()
                        .copied()
                        .collect::<Option<Vec<_>>>()
                        .map(|b| b.into_iter().max().unwrap())
                        .unwrap_or(255),
                )],
                "+" => vec![x.zip(y).and_then(|(a, b)| a.checked_add(b))],
                "*" => vec![x.zip(y).and_then(|(a, b)| a.checked_mul(b))],
                "number/mod" => vec![y.and_then(|v| v.checked_sub(1))],
                "number/max" => vec![x.zip(y).map(|(a, b)| a.max(b))],
                "number/bounded" => vec![bounds[2][0]],
                "control/select" => bounds[1]
                    .iter()
                    .zip(&bounds[2])
                    .map(|(a, b)| a.zip(*b).map(|(a, b)| a.max(b)))
                    .collect(),
                "==" | "!=" | "<" | "<=" | ">" | ">=" | "&&" | "||" => vec![Some(1)],
                _ => vec![None; count],
            }
        }
    }
}
// Join initial and successor states until the domain is an inductive invariant.
// Growth that does not converge loses its bounds rather than guessing a trip count.
fn scan_bounds(mut bounds: Vec<Option<u64>>, step: &str, program: &Program) -> Vec<Option<u64>> {
    for _ in 0..8 {
        let next = abstract_bounds(&program.functions[step].output, &bounds, program);
        let joined = bounds
            .iter()
            .zip(next)
            .map(|(a, b)| a.zip(b).map(|(a, b)| a.max(b)))
            .collect::<Vec<_>>();
        if joined == bounds {
            return bounds;
        }
        bounds = joined;
    }
    vec![None; bounds.len()]
}
fn scan_domains(e: &Expr, program: &Program, domains: &mut BTreeMap<String, Vec<Option<u64>>>) {
    match &e.op {
        Op::Scan {
            state,
            function,
            count,
            width,
            buffer,
            ..
        } => {
            let bounds = scan_bounds(abstract_bounds(state, &[], program), function, program);
            domains
                .entry(function.clone())
                .and_modify(|old| {
                    for (a, b) in old.iter_mut().zip(&bounds) {
                        *a = a.zip(*b).map(|(a, b)| a.max(b));
                    }
                })
                .or_insert(bounds);
            for child in [&**state, &**count, &**width, &**buffer] {
                scan_domains(child, program, domains);
            }
        }
        Op::Tuple(items) | Op::Call(_, items) | Op::Primitive(_, items) => {
            for child in items {
                scan_domains(child, program, domains);
            }
        }
        Op::Field(child, _) => scan_domains(child, program, domains),
        _ => {}
    }
}
fn nested_loop(
    e: &Expr,
    program: &Program,
    visited: &mut std::collections::BTreeSet<String>,
) -> bool {
    match &e.op {
        Op::Loop { .. } => true,
        Op::Call(name, items) => {
            items.iter().any(|e| nested_loop(e, program, visited))
                || (visited.insert(name.clone())
                    && nested_loop(&program.functions[name].output, program, visited))
        }
        Op::Tuple(items) | Op::Primitive(_, items) => {
            items.iter().any(|e| nested_loop(e, program, visited))
        }
        Op::Field(e, _) => nested_loop(e, program, visited),
        Op::Branch {
            condition,
            state,
            yes,
            no,
        } => {
            nested_loop(condition, program, visited)
                || nested_loop(state, program, visited)
                || [yes, no].iter().any(|name| {
                    visited.insert((*name).clone())
                        && nested_loop(&program.functions[*name].output, program, visited)
                })
        }
        _ => false,
    }
}
/// Positive-index proof uses an operation's domains, including the no-wrap
/// proof for addition. A bound on a wrapped result alone is insufficient.
fn positive(e: &Expr, params: &[Option<u64>], program: &Program) -> bool {
    match &e.op {
        Op::Integer(n) => *n > 0,
        Op::Primitive(name, _) if name == "number/factorial" => true,
        Op::Primitive(name, args) if name == "number/bounded" => {
            matches!(args[1].op, Op::Integer(n) if n > 0)
        }
        Op::Primitive(name, args) if name == "+" => {
            let left = abstract_bounds(&args[0], params, program)[0];
            let right = abstract_bounds(&args[1], params, program)[0];
            left.zip(right)
                .and_then(|(a, b)| a.checked_add(b))
                .is_some()
                && (positive(&args[0], params, program) || positive(&args[1], params, program))
        }
        _ => false,
    }
}
fn loop_bounds(
    mut bounds: Vec<Option<u64>>,
    step: &str,
    kind: &Kind,
    program: &Program,
) -> Vec<Option<u64>> {
    let types = types_for(kind);
    // Widen every increasing byte domain directly to its checked type limit and
    // every increasing integer domain to unknown. One further transfer establishes
    // the invariant; no speculative loop-trip-count assumption is made.
    for _ in 0..3 {
        let next = abstract_bounds(&program.functions[step].output, &bounds, program);
        let mut changed = false;
        for i in 0..bounds.len() {
            if let Some(old) = bounds[i] {
                if next[i].is_none_or(|new| new > old) {
                    bounds[i] = if types[i] == types::I8X16 {
                        Some(255)
                    } else {
                        None
                    };
                    changed = true;
                }
            }
        }
        if !changed {
            return bounds;
        }
    }
    vec![None; bounds.len()]
}
struct Emit<'a, 'b, 'c> {
    b: &'a mut FunctionBuilder<'b>,
    module: &'a mut ObjectModule,
    program: &'c Program,
    simd: bool,
    narrow_uint: bool,
    narrow_arithmetic: bool,
    stack_index: bool,
    callbacks: &'c BTreeMap<String, FuncId>,
    reduce: FuncId,
    scan: Option<FuncId>,
    write: Option<FuncId>,
    scan_callbacks: &'c BTreeMap<String, FuncId>,
    arguments: Value,
    tables: &'a mut BTreeMap<String, DataId>,
    facts: BTreeMap<Value, u64>,
    constants: BTreeMap<Value, u64>,
    float_constants: BTreeMap<Value, u64>,
    float_tables: BTreeMap<Value, Vec<u64>>,
    float_conditions: BTreeMap<Value, (FloatCC, Value, Value)>,
    count_sums: BTreeMap<Value, CountSum>,
}
impl Emit<'_, '_, '_> {
    fn integer_arithmetic(&mut self, name: &str, a: Value, b: Value) -> Value {
        let bound = self
            .facts
            .get(&a)
            .zip(self.facts.get(&b))
            .and_then(|(&a, &b)| {
                if name == "+" {
                    a.checked_add(b)
                } else {
                    a.checked_mul(b)
                }
            });
        if self.narrow_arithmetic && bound.is_some_and(|max| max <= u32::MAX as u64) {
            let a = self.b.ins().ireduce(types::I32, a);
            let b = self.b.ins().ireduce(types::I32, b);
            let result = if name == "+" {
                self.b.ins().iadd(a, b)
            } else {
                self.b.ins().imul(a, b)
            };
            self.b.ins().uextend(types::I64, result)
        } else if name == "+" {
            self.b.ins().iadd(a, b)
        } else {
            self.b.ins().imul(a, b)
        }
    }
    fn divide(&mut self, name: &str, a: Value, b: Value) -> Value {
        if self.narrow_uint {
            if let Some((&maximum, &divisor)) = self.facts.get(&a).zip(self.constants.get(&b)) {
                if let Some((multiplier, shift)) = bounded_reciprocal(divisor, maximum) {
                    // Keep the proven 32-bit dividend in its existing 64-bit
                    // register. Cranelift's I32 umulhi expands into extensions
                    // and two shifts; a full product needs just one shift.
                    let product = self.b.ins().imul_imm(a, multiplier as i64);
                    let quotient = self.b.ins().ushr_imm(product, shift as i64);
                    return if name == "/" {
                        quotient
                    } else {
                        let multiple = self.b.ins().imul(quotient, b);
                        self.b.ins().isub(a, multiple)
                    };
                }
            }
        }
        let narrow = self.narrow_uint
            && [a, b]
                .iter()
                .all(|v| self.facts.get(v).is_some_and(|&max| max <= u32::MAX as u64));
        let (a, b) = if narrow {
            (
                self.b.ins().ireduce(types::I32, a),
                self.b.ins().ireduce(types::I32, b),
            )
        } else {
            (a, b)
        };
        let result = if name == "/" {
            self.b.ins().udiv(a, b)
        } else {
            self.b.ins().urem(a, b)
        };
        if narrow {
            self.b.ins().uextend(types::I64, result)
        } else {
            result
        }
    }
    /// Pack independent Boolean counts, preserving each IEEE comparison and
    /// ordinary wrapping integer addition. No floating arithmetic is reassociated.
    fn add_counts(&mut self, left: Value, right: Value) -> Value {
        let mut sum = CountSum::default();
        for value in [left, right] {
            if let Some(part) = self.count_sums.get(&value) {
                sum.terms.extend(part.terms.clone());
                sum.other.extend(&part.other);
            } else {
                sum.other.push(value);
            }
        }
        let value = if self.simd && (4..=64).contains(&sum.terms.len()) {
            let one = self.int(1);
            let ones = self.b.ins().splat(types::I64X2, one);
            let zero = self.int(0);
            let mut packed_sum = self.b.ins().splat(types::I64X2, zero);
            let mut scalar_sum = self.int(0);
            for pair in sum.terms.chunks(2) {
                if pair.len() == 2 && pair[0].comparison == pair[1].comparison {
                    let left = self.pair_floats(pair[0].left, pair[1].left);
                    let right = self.pair_floats(pair[0].right, pair[1].right);
                    let masks = self.b.ins().fcmp(pair[0].comparison, left, right);
                    let counts = self.b.ins().band(masks, ones);
                    packed_sum = self.b.ins().iadd(packed_sum, counts);
                } else {
                    for term in pair {
                        scalar_sum = self.b.ins().iadd(scalar_sum, term.scalar);
                    }
                }
            }
            let lo = self.b.ins().extractlane(packed_sum, 0);
            let hi = self.b.ins().extractlane(packed_sum, 1);
            let packed = self.b.ins().iadd(lo, hi);
            let mut result = self.b.ins().iadd(packed, scalar_sum);
            for other in &sum.other {
                result = self.b.ins().iadd(result, *other);
            }
            result
        } else {
            self.integer_arithmetic("+", left, right)
        };
        if !sum.terms.is_empty() && sum.terms.len() <= 64 {
            self.count_sums.insert(value, sum);
        }
        value
    }
    fn pair_floats(&mut self, first: Value, second: Value) -> Value {
        if let Some((&a, &b)) = self
            .float_constants
            .get(&first)
            .zip(self.float_constants.get(&second))
        {
            let bytes = a
                .to_le_bytes()
                .into_iter()
                .chain(b.to_le_bytes())
                .collect::<Vec<_>>();
            let constant = self.b.func.dfg.constants.insert(ConstantData::from(bytes));
            return self.b.ins().vconst(types::F64X2, constant);
        }
        let vector = self.b.ins().splat(types::F64X2, first);
        if first == second {
            vector
        } else {
            self.b.ins().insertlane(vector, second, 1)
        }
    }
    fn literal_table(&mut self, data: Vec<u8>) -> Result<Value, String> {
        let key = format!(
            "mech_control_literal_{}",
            data.iter().map(|v| format!("{v:02x}")).collect::<String>()
        );
        self.table(key, data)
    }
    fn encoded_scalar(&mut self, value: Value) -> Value {
        match self.b.func.dfg.value_type(value) {
            types::F64 => self.b.ins().bitcast(types::I64, MemFlags::new(), value),
            types::I8 => self.b.ins().uextend(types::I64, value),
            _ => value,
        }
    }
    fn decoded_scalar(&mut self, value: Value, kind: Type) -> Value {
        match kind {
            types::F64 => self.b.ins().bitcast(types::F64, MemFlags::new(), value),
            types::I8 => self.b.ins().ireduce(types::I8, value),
            _ => value,
        }
    }
    fn int(&mut self, n: u64) -> Value {
        let v = self.b.ins().iconst(types::I64, n as i64);
        self.facts.insert(v, n);
        self.constants.insert(v, n);
        v
    }
    fn guard(&mut self, valid: Value, status: i64) {
        let good = self.b.create_block();
        let bad = self.b.create_block();
        self.b.ins().brif(valid, good, &[], bad, &[]);
        self.b.switch_to_block(bad);
        let error = self.b.ins().iconst(types::I64, status);
        self.b.ins().return_(&[error]);
        self.b.switch_to_block(good);
    }
    fn vector(&mut self, data: [u8; 16]) -> Value {
        let constant = self
            .b
            .func
            .dfg
            .constants
            .insert(ConstantData::from(data.to_vec()));
        self.b.ins().vconst(types::I8X16, constant)
    }
    fn slot(&mut self, n: usize) -> Value {
        let s = self.b.create_sized_stack_slot(StackSlotData::new(
            StackSlotKind::ExplicitSlot,
            n as u32,
            4,
        ));
        self.b.ins().stack_addr(types::I64, s, 0)
    }
    fn call(&mut self, name: &str, params: &[Value]) -> Result<Values, String> {
        let f = self
            .program
            .functions
            .get(name)
            .ok_or("missing native function")?;
        self.expression(&f.output, params, &mut BTreeMap::new())
    }
    fn table(&mut self, name: String, data: Vec<u8>) -> Result<Value, String> {
        let id = if let Some(id) = self.tables.get(&name) {
            *id
        } else {
            let id = self
                .module
                .declare_data(&name, Linkage::Local, false, false)
                .map_err(|e| e.to_string())?;
            let mut desc = DataDescription::new();
            desc.define(data.into_boxed_slice());
            desc.set_align(16);
            self.module
                .define_data(id, &desc)
                .map_err(|e| e.to_string())?;
            self.tables.insert(name, id);
            id
        };
        let gv = self.module.declare_data_in_func(id, self.b.func);
        Ok(self.b.ins().global_value(types::I64, gv))
    }
    fn expression(
        &mut self,
        e: &Expr,
        params: &[Value],
        memo: &mut BTreeMap<Expr, Values>,
    ) -> Result<Values, String> {
        if let Some(value) = memo.get(e) {
            return Ok(value.clone());
        }
        let out = match &e.op {
            Op::Integer(n) => vec![self.int(*n)],
            Op::Float(bits) => {
                let value = self.b.ins().f64const(Ieee64::with_bits(*bits));
                self.float_constants.insert(value, *bits);
                vec![value]
            }
            Op::ReadBytes(data) => vec![
                self.literal_table(data.clone())?,
                self.int(data.len() as u64),
            ],
            Op::Floats(bits) => {
                let ptr =
                    self.literal_table(bits.iter().flat_map(|v| v.to_le_bytes()).collect())?;
                self.float_tables.insert(ptr, bits.clone());
                vec![ptr, self.int(bits.len() as u64)]
            }
            Op::Boolean(b) => vec![self.b.ins().iconst(types::I8, i64::from(*b))],
            Op::Text(_) => vec![],
            Op::Parameter(i) => params[*i..*i + types_for(&e.kind).len()].to_vec(),
            Op::Tuple(items) => {
                let mut out = Vec::new();
                for item in items {
                    out.extend(self.expression(item, params, memo)?);
                }
                out
            }
            Op::Field(value, i) => {
                let Kind::Tuple(kinds) = &value.kind else {
                    return Err("tuple field type".into());
                };
                let offset: usize = kinds[..*i].iter().map(|k| types_for(k).len()).sum();
                let values = self.expression(value, params, memo)?;
                values[offset..offset + types_for(&kinds[*i]).len()].to_vec()
            }
            Op::Call(name, args) => {
                let mut values = Vec::new();
                for arg in args {
                    values.extend(self.expression(arg, params, memo)?);
                }
                self.call(name, &values)?
            }
            Op::Loop {
                initial,
                predicate,
                step,
            } => {
                let initial_values = self.expression(initial, params, memo)?;
                let head = self.b.create_block();
                let body = self.b.create_block();
                let exit = self.b.create_block();
                for t in types_for(&e.kind) {
                    self.b.append_block_param(head, t);
                    self.b.append_block_param(exit, t);
                }
                self.b.ins().jump(
                    head,
                    &initial_values
                        .iter()
                        .copied()
                        .map(Into::into)
                        .collect::<Vec<_>>(),
                );
                self.b.switch_to_block(head);
                let state = self.b.block_params(head).to_vec();
                let bounds = loop_bounds(
                    initial_values
                        .iter()
                        .map(|v| self.facts.get(v).copied())
                        .collect(),
                    step,
                    &e.kind,
                    self.program,
                );
                for (v, bound) in state.iter().zip(bounds) {
                    if let Some(bound) = bound {
                        self.facts.insert(*v, bound);
                    }
                }
                let condition = self.call(predicate, &state)?[0];
                self.b.ins().brif(
                    condition,
                    body,
                    &[],
                    exit,
                    &state.iter().copied().map(Into::into).collect::<Vec<_>>(),
                );
                self.b.switch_to_block(body);
                let next = self.call(step, &state)?;
                self.b.ins().jump(
                    head,
                    &next.iter().copied().map(Into::into).collect::<Vec<_>>(),
                );
                self.b.switch_to_block(exit);
                self.b.block_params(exit).to_vec()
            }
            Op::Branch {
                condition,
                yes,
                no,
                state,
            } => {
                let condition = self.expression(condition, params, memo)?[0];
                let state = self.expression(state, params, memo)?;
                let branch_facts = self.facts.clone();
                let y = self.b.create_block();
                let n = self.b.create_block();
                let exit = self.b.create_block();
                for t in types_for(&e.kind) {
                    self.b.append_block_param(exit, t);
                }
                self.b.ins().brif(condition, y, &[], n, &[]);
                self.b.switch_to_block(y);
                let out = self.call(yes, &state)?;
                self.b.ins().jump(
                    exit,
                    &out.iter().copied().map(Into::into).collect::<Vec<_>>(),
                );
                self.facts = branch_facts.clone();
                self.b.switch_to_block(n);
                let out = self.call(no, &state)?;
                self.b.ins().jump(
                    exit,
                    &out.iter().copied().map(Into::into).collect::<Vec<_>>(),
                );
                self.facts = branch_facts;
                self.b.switch_to_block(exit);
                self.b.block_params(exit).to_vec()
            }
            Op::Parallel {
                start,
                end,
                grain,
                function,
                arguments,
                reductions,
            } => {
                let first = self.expression(start, params, memo)?[0];
                let last = self.expression(end, params, memo)?[0];
                let grain = self.expression(grain, params, memo)?[0];
                let args = self.expression(arguments, params, memo)?;
                let argptr = self.slot(args.len() * 8);
                for (i, v) in args.iter().enumerate() {
                    self.b
                        .ins()
                        .store(MemFlags::new(), *v, argptr, (i * 8) as i32);
                }
                let arglen = self.int(args.len() as u64);
                let function = self
                    .module
                    .declare_func_in_func(self.callbacks[function], self.b.func);
                let function = self.b.ins().func_addr(types::I64, function);
                let codes = reductions
                    .iter()
                    .map(|r| if r == "sum" { 0u8 } else { 1u8 })
                    .collect::<Vec<_>>();
                let table = self.table(
                    format!("mech_control_reducers_{}", reductions.join("_")),
                    codes,
                )?;
                let len = self.int(reductions.len() as u64);
                let out = self.slot(reductions.len() * 8);
                let reduce = self.module.declare_func_in_func(self.reduce, self.b.func);
                let call = self.b.ins().call(
                    reduce,
                    &[
                        first, last, grain, argptr, arglen, function, table, len, out,
                    ],
                );
                let status = self.b.inst_results(call)[0];
                let valid = self.b.ins().icmp_imm(IntCC::Equal, status, 0);
                self.guard(valid, 5);
                (0..reductions.len())
                    .map(|i| {
                        self.b
                            .ins()
                            .load(types::I64, MemFlags::new(), out, (i * 8) as i32)
                    })
                    .collect()
            }
            Op::Write { text, .. } => {
                let data = self.literal_table(text.as_bytes().to_vec())?;
                let len = self.int(text.len() as u64);
                let f = self
                    .module
                    .declare_func_in_func(self.write.ok_or("missing writer import")?, self.b.func);
                let call = self.b.ins().call(f, &[data, len]);
                let status = self.b.inst_results(call)[0];
                let valid = self.b.ins().icmp_imm(IntCC::Equal, status, 0);
                self.guard(valid, 6);
                vec![self.int(0)]
            }
            Op::Scan {
                count,
                state,
                function,
                width,
                separator,
                buffer,
                ..
            } => {
                let count = self.expression(count, params, memo)?[0];
                let values = self.expression(state, params, memo)?;
                let stateptr = self.slot(values.len() * 8);
                for (i, value) in values.iter().enumerate() {
                    let encoded = self.encoded_scalar(*value);
                    self.b
                        .ins()
                        .store(MemFlags::new(), encoded, stateptr, (i * 8) as i32);
                }
                let fields = self.int(values.len() as u64);
                let f = self
                    .module
                    .declare_func_in_func(self.scan_callbacks[function], self.b.func);
                let callback = self.b.ins().func_addr(types::I64, f);
                let width = self.expression(width, params, memo)?[0];
                let sep = self.literal_table(separator.as_bytes().to_vec())?;
                let seplen = self.int(separator.len() as u64);
                let buffer = self.expression(buffer, params, memo)?[0];
                let out = self.slot(values.len() * 8);
                let scan = self
                    .module
                    .declare_func_in_func(self.scan.ok_or("missing scan import")?, self.b.func);
                let call = self.b.ins().call(
                    scan,
                    &[
                        count, stateptr, fields, callback, width, sep, seplen, buffer, out,
                    ],
                );
                let status = self.b.inst_results(call)[0];
                let valid = self.b.ins().icmp_imm(IntCC::Equal, status, 0);
                self.guard(valid, 6);
                types_for(&state.kind)
                    .iter()
                    .enumerate()
                    .map(|(i, kind)| {
                        let v = self
                            .b
                            .ins()
                            .load(types::I64, MemFlags::new(), out, (i * 8) as i32);
                        self.decoded_scalar(v, *kind)
                    })
                    .collect()
            }
            Op::Primitive(name, args) => {
                let mut v = Vec::new();
                for arg in args {
                    v.push(self.expression(arg, params, memo)?);
                }
                let x = v.first().and_then(|v| v.first()).copied();
                if args.first().is_some_and(|e| e.kind == Kind::Float) {
                    let a = x.unwrap();
                    let b = v[1][0];
                    let value = match name.as_str() {
                        "+" => self.b.ins().fadd(a, b),
                        "-" => self.b.ins().fsub(a, b),
                        "*" => self.b.ins().fmul(a, b),
                        "/" => self.b.ins().fdiv(a, b),
                        "==" => self.b.ins().fcmp(FloatCC::Equal, a, b),
                        "!=" => self.b.ins().fcmp(FloatCC::NotEqual, a, b),
                        "<" => self.b.ins().fcmp(FloatCC::LessThan, a, b),
                        "<=" => self.b.ins().fcmp(FloatCC::LessThanOrEqual, a, b),
                        ">" => self.b.ins().fcmp(FloatCC::GreaterThan, a, b),
                        ">=" => self.b.ins().fcmp(FloatCC::GreaterThanOrEqual, a, b),
                        _ => return Err("floating control operation".into()),
                    };
                    let comparison = match name.as_str() {
                        "==" => Some(FloatCC::Equal),
                        "!=" => Some(FloatCC::NotEqual),
                        "<" => Some(FloatCC::LessThan),
                        "<=" => Some(FloatCC::LessThanOrEqual),
                        ">" => Some(FloatCC::GreaterThan),
                        ">=" => Some(FloatCC::GreaterThanOrEqual),
                        _ => None,
                    };
                    if let Some(cc) = comparison {
                        self.float_conditions.insert(value, (cc, a, b));
                    }
                    memo.insert(e.clone(), vec![value]);
                    return Ok(vec![value]);
                }
                match name.as_str() {
                    "number/to-f64" => {
                        let mut value = x.unwrap();
                        if self.narrow_uint
                            && self
                                .facts
                                .get(&value)
                                .is_some_and(|&max| max <= u32::MAX as u64)
                        {
                            value = self.b.ins().ireduce(types::I32, value);
                        }
                        vec![self.b.ins().fcvt_from_uint(types::F64, value)]
                    }
                    "sequence/length" => vec![v[0][1]],
                    "sequence/get" if matches!(args[0].kind, Kind::ReadBytes | Kind::Floats) => {
                        let index = v[1][0];
                        let lower =
                            self.b
                                .ins()
                                .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, index, 1);
                        let upper =
                            self.b
                                .ins()
                                .icmp(IntCC::UnsignedLessThanOrEqual, index, v[0][1]);
                        let valid = self.b.ins().band(lower, upper);
                        self.guard(valid, 4);
                        let mut offset = self.b.ins().iadd_imm(index, -1);
                        if args[0].kind == Kind::Floats {
                            offset = self.b.ins().ishl_imm(offset, 3);
                        }
                        let address = self.b.ins().iadd(v[0][0], offset);
                        if args[0].kind == Kind::Floats {
                            if let Some(bits) = self
                                .constants
                                .get(&index)
                                .and_then(|i| i.checked_sub(1))
                                .and_then(|i| usize::try_from(i).ok())
                                .and_then(|i| {
                                    self.float_tables
                                        .get(&v[0][0])
                                        .and_then(|table| table.get(i))
                                })
                                .copied()
                            {
                                let value = self.b.ins().f64const(Ieee64::with_bits(bits));
                                self.float_constants.insert(value, bits);
                                vec![value]
                            } else {
                                vec![self.b.ins().load(types::F64, MemFlags::new(), address, 0)]
                            }
                        } else {
                            let byte = self.b.ins().load(types::I8, MemFlags::new(), address, 0);
                            vec![self.b.ins().uextend(types::I64, byte)]
                        }
                    }
                    "io/argument-u64" => {
                        let Op::Integer(index) = args[0].op else {
                            return Err("argument index".into());
                        };
                        vec![self.b.ins().load(
                            types::I64,
                            MemFlags::new(),
                            self.arguments,
                            ((index - 1) * 8) as i32,
                        )]
                    }
                    "sequence/iota-bytes" | "sequence/zero-bytes" => {
                        let Kind::Bytes(n) = e.kind else {
                            return Err("byte constructor".into());
                        };
                        (0..n.div_ceil(16))
                            .map(|block| {
                                self.vector(std::array::from_fn(|i| {
                                    if name == "sequence/iota-bytes" && block * 16 + i < n {
                                        (block * 16 + i) as u8
                                    } else {
                                        0
                                    }
                                }))
                            })
                            .collect()
                    }
                    "+" => vec![self.add_counts(x.unwrap(), v[1][0])],
                    "-" => vec![self.b.ins().isub(x.unwrap(), v[1][0])],
                    "*" => vec![self.integer_arithmetic("*", x.unwrap(), v[1][0])],
                    "/" | "number/mod" => {
                        let a = x.unwrap();
                        let d = v[1][0];
                        if let Op::Integer(n) = args[1].op {
                            if n == 0 {
                                return Err("constant division by zero".into());
                            }
                            if n.is_power_of_two() {
                                vec![if name == "/" {
                                    self.b.ins().ushr_imm(a, n.trailing_zeros() as i64)
                                } else {
                                    self.b.ins().band_imm(a, (n - 1) as i64)
                                }]
                            } else {
                                vec![self.divide(name, a, d)]
                            }
                        } else {
                            let valid = self.b.ins().icmp_imm(IntCC::NotEqual, d, 0);
                            self.guard(valid, 2);
                            vec![self.divide(name, a, d)]
                        }
                    }
                    "==" | "!=" | "<" | "<=" | ">" | ">=" => {
                        let cc = match name.as_str() {
                            "==" => IntCC::Equal,
                            "!=" => IntCC::NotEqual,
                            "<" => IntCC::UnsignedLessThan,
                            "<=" => IntCC::UnsignedLessThanOrEqual,
                            ">" => IntCC::UnsignedGreaterThan,
                            _ => IntCC::UnsignedGreaterThanOrEqual,
                        };
                        vec![self.b.ins().icmp(cc, x.unwrap(), v[1][0])]
                    }
                    "&&" => vec![self.b.ins().band(x.unwrap(), v[1][0])],
                    "||" => vec![self.b.ins().bor(x.unwrap(), v[1][0])],
                    "number/max" => {
                        let a = x.unwrap();
                        let b = v[1][0];
                        let greater = self.b.ins().icmp(IntCC::UnsignedGreaterThan, a, b);
                        vec![self.b.ins().select(greater, a, b)]
                    }
                    "control/select" => {
                        let values: Values = v[1]
                            .iter()
                            .zip(&v[2])
                            .map(|(a, b)| self.b.ins().select(x.unwrap(), *a, *b))
                            .collect();
                        if v[1].len() == 1
                            && self.constants.get(&v[1][0]) == Some(&1)
                            && self.constants.get(&v[2][0]) == Some(&0)
                        {
                            if let Some(&(comparison, left, right)) =
                                self.float_conditions.get(&x.unwrap())
                            {
                                self.count_sums.insert(
                                    values[0],
                                    CountSum {
                                        terms: vec![FloatCount {
                                            comparison,
                                            left,
                                            right,
                                            scalar: values[0],
                                        }],
                                        other: vec![],
                                    },
                                );
                            }
                        }
                        values
                    }
                    "number/bounded" => {
                        let a = x.unwrap();
                        let low = self
                            .b
                            .ins()
                            .icmp(IntCC::UnsignedGreaterThanOrEqual, a, v[1][0]);
                        let high = self
                            .b
                            .ins()
                            .icmp(IntCC::UnsignedLessThanOrEqual, a, v[2][0]);
                        let valid = self.b.ins().band(low, high);
                        self.guard(valid, 1);
                        vec![a]
                    }
                    "number/factorial" => {
                        let n = x.unwrap();
                        let valid = self.b.ins().icmp_imm(IntCC::UnsignedLessThanOrEqual, n, 20);
                        self.guard(valid, 3);
                        let head = self.b.create_block();
                        let body = self.b.create_block();
                        let done = self.b.create_block();
                        self.b.append_block_param(head, types::I64);
                        self.b.append_block_param(head, types::I64);
                        self.b.append_block_param(done, types::I64);
                        let one = self.int(1);
                        self.b.ins().jump(head, &[one.into(), one.into()]);
                        self.b.switch_to_block(head);
                        let i = self.b.block_params(head)[0];
                        let product = self.b.block_params(head)[1];
                        let more = self.b.ins().icmp(IntCC::UnsignedLessThanOrEqual, i, n);
                        self.b.ins().brif(more, body, &[], done, &[product.into()]);
                        self.b.switch_to_block(body);
                        let product = self.b.ins().imul(product, i);
                        let next = self.b.ins().iadd_imm(i, 1);
                        self.b.ins().jump(head, &[next.into(), product.into()]);
                        self.b.switch_to_block(done);
                        vec![self.b.block_params(done)[0]]
                    }
                    "sequence/get"
                    | "sequence/set"
                    | "sequence/reverse-prefix"
                    | "sequence/rotate-prefix" => self.bytes(name, args, &v, params)?,
                    _ => return Err(format!("unlowered native primitive {name}")),
                }
            }
        };
        let domains = abstract_bounds(
            e,
            &params
                .iter()
                .map(|v| self.facts.get(v).copied())
                .collect::<Vec<_>>(),
            self.program,
        );
        for (v, bound) in out.iter().zip(domains) {
            if let Some(bound) = bound {
                self.facts.insert(*v, bound);
            }
        }
        memo.insert(e.clone(), out.clone());
        Ok(out)
    }
    fn bytes(
        &mut self,
        name: &str,
        args: &[Expr],
        v: &[Values],
        params: &[Value],
    ) -> Result<Values, String> {
        let Kind::Bytes(n) = args[0].kind else {
            return Err("byte operand".into());
        };
        let index = v[1][0];
        let upper = self
            .b
            .ins()
            .icmp_imm(IntCC::UnsignedLessThanOrEqual, index, n as i64);
        let valid = if name == "sequence/get" || name == "sequence/set" {
            let lower = self
                .b
                .ins()
                .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, index, 1);
            self.b.ins().band(lower, upper)
        } else {
            upper
        };
        let proved = if name == "sequence/get" || name == "sequence/set" {
            self.facts.get(&index).is_some_and(|&max| max <= n as u64)
                && positive(
                    &args[1],
                    &params
                        .iter()
                        .map(|v| self.facts.get(v).copied())
                        .collect::<Vec<_>>(),
                    self.program,
                )
        } else {
            self.facts.get(&index).is_some_and(|&max| max <= n as u64)
        };
        if !proved {
            self.guard(valid, 4);
        }
        if name == "sequence/set" {
            let valid = self
                .b
                .ins()
                .icmp_imm(IntCC::UnsignedLessThanOrEqual, v[2][0], 255);
            if !self.facts.get(&v[2][0]).is_some_and(|&max| max <= 255) {
                self.guard(valid, 4);
            }
        }
        if name == "sequence/get" {
            if let Op::Integer(i) = args[1].op {
                if i == 0 || i > n as u64 {
                    // The failing bounds guard above dominates this unreachable
                    // continuation. Avoid indexing the compiler's vector list;
                    // a lazy source branch can still leave this read untaken.
                    return Ok(vec![self.int(0)]);
                }
                let lane = self
                    .b
                    .ins()
                    .extractlane(v[0][(i as usize - 1) / 16], ((i - 1) % 16) as u8);
                return Ok(vec![self.b.ins().uextend(types::I64, lane)]);
            }
            if !self.simd || self.stack_index {
                let temp = self.slot(n.div_ceil(16) * 16);
                for (i, vector) in v[0].iter().enumerate() {
                    self.b
                        .ins()
                        .store(MemFlags::new(), *vector, temp, (i * 16) as i32);
                }
                let offset = self.b.ins().iadd_imm(index, -1);
                let address = self.b.ins().iadd(temp, offset);
                let byte = self.b.ins().load(types::I8, MemFlags::new(), address, 0);
                return Ok(vec![self.b.ins().uextend(types::I64, byte)]);
            }
            let offset = self.b.ins().iadd_imm(index, -1);
            let byte = self.b.ins().ireduce(types::I8, offset);
            let mask = self.b.ins().splat(types::I8X16, byte);
            let mut selected = self.b.ins().swizzle(v[0][0], mask);
            for (chunk, vector) in v[0].iter().enumerate().skip(1) {
                let byte = self.b.ins().iadd_imm(byte, -((chunk * 16) as i64));
                let mask = self.b.ins().splat(types::I8X16, byte);
                let candidate = self.b.ins().swizzle(*vector, mask);
                selected = self.b.ins().bor(selected, candidate);
            }
            let byte = self.b.ins().extractlane(selected, 0);
            return Ok(vec![self.b.ins().uextend(types::I64, byte)]);
        }
        if name == "sequence/set" && self.simd {
            let offset = self.b.ins().iadd_imm(index, -1);
            let byte = self.b.ins().ireduce(types::I8, offset);
            let indices = self.b.ins().splat(types::I8X16, byte);
            let data = self.b.ins().ireduce(types::I8, v[2][0]);
            let data = self.b.ins().splat(types::I8X16, data);
            return Ok(v[0]
                .iter()
                .enumerate()
                .map(|(chunk, vector)| {
                    let lanes = self.vector(std::array::from_fn(|i| (chunk * 16 + i) as u8));
                    let mask = self.b.ins().icmp(IntCC::Equal, indices, lanes);
                    self.b.ins().bitselect(mask, data, *vector)
                })
                .collect());
        }
        if self.simd && n <= 16 && name != "sequence/set" {
            // Exhaustively precompute each legal byte permutation; only shape and
            // operation semantics determine this immutable shuffle table.
            let rotate = name == "sequence/rotate-prefix";
            let one = rotate && matches!(args[2].op, Op::Integer(1));
            let rows = if one || !rotate { 1 } else { 16 };
            let shift = if rows == 1 {
                self.int(0)
            } else {
                let length_nonzero = self.b.ins().icmp_imm(IntCC::NotEqual, index, 0);
                let one_value = self.int(1);
                let safe = self.b.ins().select(length_nonzero, index, one_value);
                self.b.ins().urem(v[2][0], safe)
            };
            let mut data = Vec::new();
            for length in 0..=n {
                for shift in 0..rows {
                    for i in 0..16 {
                        data.push(if i >= length {
                            i as u8
                        } else if rotate {
                            ((i + if one { 1 } else { shift }) % length) as u8
                        } else {
                            (length - 1 - i) as u8
                        });
                    }
                }
            }
            let key = format!(
                "mech_control_{}_{}_{}",
                if rotate { "rotate" } else { "reverse" },
                n,
                rows
            );
            let table = self.table(key, data)?;
            let offset = if rows == 1 {
                self.b.ins().ishl_imm(index, 4)
            } else {
                let row = self.b.ins().ishl_imm(index, 4);
                let row = self.b.ins().iadd(row, shift);
                self.b.ins().ishl_imm(row, 4)
            };
            let address = self.b.ins().iadd(table, offset);
            let mask = self.b.ins().load(types::I8X16, MemFlags::new(), address, 0);
            return Ok(vec![self.b.ins().swizzle(v[0][0], mask)]);
        }
        let source = self.slot(n.div_ceil(16) * 16);
        let out = self.slot(n.div_ceil(16) * 16);
        for (i, vector) in v[0].iter().enumerate() {
            self.b
                .ins()
                .store(MemFlags::new(), *vector, source, (i * 16) as i32);
            self.b
                .ins()
                .store(MemFlags::new(), *vector, out, (i * 16) as i32);
        }
        if name == "sequence/set" {
            let offset = self.b.ins().iadd_imm(index, -1);
            let address = self.b.ins().iadd(out, offset);
            let byte = self.b.ins().ireduce(types::I8, v[2][0]);
            self.b.ins().store(MemFlags::new(), byte, address, 0);
        } else {
            let head = self.b.create_block();
            let body = self.b.create_block();
            let exit = self.b.create_block();
            self.b.append_block_param(head, types::I64);
            let zero = self.int(0);
            self.b.ins().jump(head, &[zero.into()]);
            self.b.switch_to_block(head);
            let i = self.b.block_params(head)[0];
            let more = self.b.ins().icmp(IntCC::UnsignedLessThan, i, index);
            self.b.ins().brif(more, body, &[], exit, &[]);
            self.b.switch_to_block(body);
            let from = if name == "sequence/reverse-prefix" {
                let last = self.b.ins().iadd_imm(index, -1);
                self.b.ins().isub(last, i)
            } else {
                let shift = self.b.ins().urem(v[2][0], index);
                let shifted = self.b.ins().iadd(i, shift);
                self.b.ins().urem(shifted, index)
            };
            let from = self.b.ins().iadd(source, from);
            let byte = self.b.ins().load(types::I8, MemFlags::new(), from, 0);
            let dest = self.b.ins().iadd(out, i);
            self.b.ins().store(MemFlags::new(), byte, dest, 0);
            let next = self.b.ins().iadd_imm(i, 1);
            self.b.ins().jump(head, &[next.into()]);
            self.b.switch_to_block(exit);
        }
        Ok((0..n.div_ceil(16))
            .map(|i| {
                self.b
                    .ins()
                    .load(types::I8X16, MemFlags::new(), out, (i * 16) as i32)
            })
            .collect())
    }
}
fn flatten_parameters(e: &mut Expr, inputs: &[Kind]) {
    match &mut e.op {
        Op::Parameter(i) => {
            *i = inputs[..*i].iter().map(|k| types_for(k).len()).sum();
        }
        Op::Tuple(a) | Op::Call(_, a) | Op::Primitive(_, a) => {
            for e in a {
                flatten_parameters(e, inputs)
            }
        }
        Op::Field(e, _) => flatten_parameters(e, inputs),
        Op::Loop { initial, .. } => flatten_parameters(initial, inputs),
        Op::Branch {
            condition, state, ..
        } => {
            flatten_parameters(condition, inputs);
            flatten_parameters(state, inputs)
        }
        Op::Parallel {
            start,
            end,
            grain,
            arguments,
            ..
        } => {
            for e in [start, end, grain, arguments] {
                flatten_parameters(e, inputs)
            }
        }
        _ => {}
    }
}
fn parallel_names(e: &Expr, out: &mut Vec<String>) {
    match &e.op {
        Op::Parallel {
            function,
            start,
            end,
            grain,
            arguments,
            ..
        } => {
            if !out.contains(function) {
                out.push(function.clone());
            }
            for e in [start, end, grain, arguments] {
                parallel_names(e, out)
            }
        }
        Op::Tuple(a) | Op::Call(_, a) | Op::Primitive(_, a) => {
            for e in a {
                parallel_names(e, out)
            }
        }
        Op::Field(e, _) => parallel_names(e, out),
        _ => {}
    }
}
fn scan_names(e: &Expr, out: &mut Vec<String>) {
    match &e.op {
        Op::Scan {
            function,
            count,
            state,
            width,
            buffer,
            ..
        } => {
            if !out.contains(function) {
                out.push(function.clone());
            }
            for e in [count, state, width, buffer] {
                scan_names(e, out);
            }
        }
        Op::Tuple(a) | Op::Call(_, a) | Op::Primitive(_, a) => {
            for e in a {
                scan_names(e, out);
            }
        }
        Op::Field(e, _) => scan_names(e, out),
        Op::Loop { initial, .. } => scan_names(initial, out),
        Op::Branch {
            condition, state, ..
        } => {
            scan_names(condition, out);
            scan_names(state, out);
        }
        _ => {}
    }
}
pub fn emit(source: &str, directory: &Path, simd: bool) -> Result<(), String> {
    let stack_index = match std::env::var("MECH_CONTROL_BYTE_INDEX")
        .unwrap_or_else(|_| "auto".into())
        .as_str()
    {
        // Scalar byte results with dynamic indices need a shuffle and lane
        // transfer on ARM. A private vector store plus indexed byte load has a
        // shorter dependent instruction chain. Constant indices still extract
        // a lane directly; prefix operations retain their SIMD lowering.
        "auto" => cfg!(target_arch = "aarch64"),
        "vector" => false,
        "stack" => true,
        _ => return Err("MECH_CONTROL_BYTE_INDEX must be auto, vector or stack".into()),
    };
    let mut program = mech_engine::native_sequence::control::compile(
        source,
        mech_stdlib::native_control_catalog(),
    )?;
    for function in program.functions.values_mut() {
        flatten_parameters(&mut function.output, &function.inputs);
    }
    let mut flags = settings::builder();
    flags.set("is_pic", "true").map_err(|e| e.to_string())?;
    flags.set("opt_level", "speed").map_err(|e| e.to_string())?;
    let isa = cranelift_native::builder()
        .map_err(|e| e.to_string())?
        .finish(settings::Flags::new(flags))
        .map_err(|e| e.to_string())?;
    let mut module = ObjectModule::new(
        ObjectBuilder::new(isa, "mech_control", default_libcall_names())
            .map_err(|e| e.to_string())?,
    );
    if module.target_config().pointer_type() != types::I64 {
        return Err("native control requires a 64-bit host".into());
    }
    let mut signature = module.make_signature();
    signature.params = vec![AbiParam::new(types::I64); 9];
    signature.returns.push(AbiParam::new(types::I64));
    let reduce = module
        .declare_function("mech_control_reduce", Linkage::Import, &signature)
        .map_err(|e| e.to_string())?;
    let (scan, write) = if !program.effects.is_empty() {
        let scan = module
            .declare_function("mech_control_scan", Linkage::Import, &signature)
            .map_err(|e| e.to_string())?;
        let mut sig = module.make_signature();
        sig.params = vec![AbiParam::new(types::I64); 2];
        sig.returns.push(AbiParam::new(types::I64));
        let write = module
            .declare_function("mech_control_write", Linkage::Import, &sig)
            .map_err(|e| e.to_string())?;
        (Some(scan), Some(write))
    } else {
        (None, None)
    };
    let mut names = Vec::new();
    parallel_names(&program.output, &mut names);
    let mut callbacks = BTreeMap::new();
    for (i, name) in names.iter().enumerate() {
        let mut sig = module.make_signature();
        sig.params = vec![AbiParam::new(types::I64); 4];
        sig.returns.push(AbiParam::new(types::I64));
        let id = module
            .declare_function(&format!("mech_control_range_{i}"), Linkage::Local, &sig)
            .map_err(|e| e.to_string())?;
        callbacks.insert(name.clone(), id);
    }
    let mut units = names
        .iter()
        .map(|name| (Some(name.clone()), callbacks[name], false))
        .collect::<Vec<_>>();
    let mut scans = Vec::new();
    for e in &program.effects {
        scan_names(e, &mut scans);
    }
    scan_names(&program.output, &mut scans);
    let mut state_domains = BTreeMap::new();
    for e in program
        .effects
        .iter()
        .chain(std::iter::once(&program.output))
    {
        scan_domains(e, &program, &mut state_domains);
    }
    let mut scan_callbacks = BTreeMap::new();
    for (i, name) in scans.iter().enumerate() {
        let mut sig = module.make_signature();
        sig.params = vec![AbiParam::new(types::I64); 4];
        sig.returns.push(AbiParam::new(types::I64));
        let id = module
            .declare_function(
                &format!("mech_control_scan_block_{i}"),
                Linkage::Local,
                &sig,
            )
            .map_err(|e| e.to_string())?;
        scan_callbacks.insert(name.clone(), id);
        units.push((Some(name.clone()), id, true));
    }
    let mut sig = module.make_signature();
    sig.params = vec![AbiParam::new(types::I64); 2];
    sig.returns.push(AbiParam::new(types::I64));
    let main = module
        .declare_function("mech_control_entry", Linkage::Export, &sig)
        .map_err(|e| e.to_string())?;
    units.push((None, main, false));
    let mut tables = BTreeMap::new();
    for (name, id, is_scan) in units {
        let mut ctx = module.make_context();
        ctx.func.signature = module
            .declarations()
            .get_function_decl(id)
            .signature
            .clone();
        let mut fb = FunctionBuilderContext::new();
        let mut b = FunctionBuilder::new(&mut ctx.func, &mut fb);
        let entry = b.create_block();
        b.append_block_params_for_function_params(entry);
        b.switch_to_block(entry);
        let p = b.block_params(entry).to_vec();
        let arguments = if is_scan {
            p[1]
        } else if name.is_some() {
            p[2]
        } else {
            p[0]
        };
        let output = if name.is_some() { p[3] } else { p[1] };
        let mut emit = Emit {
            b: &mut b,
            module: &mut module,
            program: &program,
            simd,
            // Explicit experiment: AArch64's current 32-bit constant remainder
            // lowering is slower than its 64-bit recipe on measured workloads.
            narrow_uint: is_scan && std::env::var("MECH_CONTROL_NARROW_UINT").as_deref() == Ok("1"),
            narrow_arithmetic: is_scan
                && std::env::var("MECH_CONTROL_NARROW_UINT").as_deref() == Ok("1")
                && std::env::var("MECH_CONTROL_NARROW_ARITHMETIC").as_deref() != Ok("0"),
            stack_index,
            callbacks: &callbacks,
            reduce,
            scan,
            write,
            scan_callbacks: &scan_callbacks,
            arguments,
            tables: &mut tables,
            facts: BTreeMap::new(),
            constants: BTreeMap::new(),
            float_constants: BTreeMap::new(),
            float_tables: BTreeMap::new(),
            float_conditions: BTreeMap::new(),
            count_sums: BTreeMap::new(),
        };
        let values = if is_scan {
            let f = &program.functions[name.as_ref().unwrap()];
            let state_types = f.inputs.iter().flat_map(types_for).collect::<Vec<_>>();
            let mut state = Vec::new();
            for (i, kind) in state_types.iter().enumerate() {
                let bits =
                    emit.b
                        .ins()
                        .load(types::I64, MemFlags::new(), arguments, (i * 8) as i32);
                state.push(emit.decoded_scalar(bits, *kind));
            }
            let domains = &state_domains[name.as_ref().unwrap()];
            for (value, bound) in state.iter().zip(domains) {
                if let Some(max) = bound {
                    let valid =
                        emit.b
                            .ins()
                            .icmp_imm(IntCC::UnsignedLessThanOrEqual, *value, *max as i64);
                    emit.guard(valid, 4);
                    emit.facts.insert(*value, *max);
                }
            }
            let default_unroll = if state_types.len() <= 4
                && !nested_loop(&f.output, &program, &mut std::collections::BTreeSet::new())
            {
                4
            } else {
                1
            };
            let unroll = std::env::var("MECH_CONTROL_SCAN_UNROLL")
                .ok()
                .map(|v| v.parse::<usize>())
                .transpose()
                .map_err(|_| "scan unroll must be 1, 2, 4 or 8")?
                .unwrap_or(default_unroll);
            if ![1, 2, 4, 8].contains(&unroll) {
                return Err("scan unroll must be 1, 2, 4 or 8".into());
            }
            let zero = emit.int(0);
            let mut carried = vec![zero];
            carried.extend(state);
            // Unroll a pure stateful transducer to expose independent output
            // calculations around its recurrence. The scalar tail preserves
            // every step and handles all lengths, including zero.
            for factor in if unroll == 1 {
                vec![1]
            } else {
                vec![unroll, 1]
            } {
                let head = emit.b.create_block();
                let body = emit.b.create_block();
                let done = emit.b.create_block();
                for block in [head, done] {
                    emit.b.append_block_param(block, types::I64);
                    for kind in &state_types {
                        emit.b.append_block_param(block, *kind);
                    }
                }
                emit.b.ins().jump(
                    head,
                    &carried.iter().copied().map(Into::into).collect::<Vec<_>>(),
                );
                emit.b.switch_to_block(head);
                let values = emit.b.block_params(head).to_vec();
                for (value, bound) in values[1..].iter().zip(domains) {
                    if let Some(max) = bound {
                        emit.facts.insert(*value, *max);
                    }
                }
                let remaining = emit.b.ins().isub(p[0], values[0]);
                let valid = emit.b.ins().icmp_imm(
                    IntCC::UnsignedGreaterThanOrEqual,
                    remaining,
                    factor as i64,
                );
                emit.b.ins().brif(
                    valid,
                    body,
                    &[],
                    done,
                    &values.iter().copied().map(Into::into).collect::<Vec<_>>(),
                );
                emit.b.switch_to_block(body);
                let mut state = values[1..].to_vec();
                for offset in 0..factor {
                    let next = emit.call(name.as_ref().unwrap(), &state)?;
                    let byte = *next.last().ok_or("scan byte output")?;
                    if !emit.facts.get(&byte).is_some_and(|&max| max <= 255) {
                        let valid =
                            emit.b
                                .ins()
                                .icmp_imm(IntCC::UnsignedLessThanOrEqual, byte, 255);
                        emit.guard(valid, 4);
                    }
                    let index = emit.b.ins().iadd_imm(values[0], offset as i64);
                    let address = emit.b.ins().iadd(p[2], index);
                    let byte = emit.b.ins().ireduce(types::I8, byte);
                    emit.b.ins().store(MemFlags::new(), byte, address, 0);
                    state = next[..state_types.len()].to_vec();
                }
                let index = emit.b.ins().iadd_imm(values[0], factor as i64);
                let mut arguments = vec![index];
                arguments.extend(state);
                emit.b.ins().jump(
                    head,
                    &arguments
                        .iter()
                        .copied()
                        .map(Into::into)
                        .collect::<Vec<_>>(),
                );
                emit.b.switch_to_block(done);
                carried = emit.b.block_params(done).to_vec();
            }
            let state = carried[1..].to_vec();
            for (i, value) in state.iter().enumerate() {
                let encoded = emit.encoded_scalar(*value);
                emit.b
                    .ins()
                    .store(MemFlags::new(), encoded, p[3], (i * 8) as i32);
            }
            Vec::new()
        } else if let Some(name) = &name {
            let f = &program.functions[name];
            let mut args = vec![p[0], p[1]];
            for i in 2..f.inputs.len() {
                args.push(emit.b.ins().load(
                    types::I64,
                    MemFlags::new(),
                    arguments,
                    ((i - 2) * 8) as i32,
                ));
            }
            emit.call(name, &args)?
        } else {
            let mut memo = BTreeMap::new();
            for e in &program.effects {
                emit.expression(e, &[], &mut memo)?;
            }
            emit.expression(&program.output, &[], &mut memo)?
        };
        for (i, v) in values.iter().enumerate() {
            emit.b
                .ins()
                .store(MemFlags::new(), *v, output, (i * 8) as i32);
        }
        let zero = emit.int(0);
        emit.b.ins().return_(&[zero]);
        drop(emit);
        b.seal_all_blocks();
        b.finalize();
        module
            .define_function(id, &mut ctx)
            .map_err(|e| format!("native control codegen: {e}"))?;
    }
    let object = module.finish().emit().map_err(|e| e.to_string())?;
    std::fs::write(directory.join("mech-control.o"), object).map_err(|e| e.to_string())?;
    let mut descriptor = serde_json::json!({"arguments":program.argument_count,"format":program.format,"outputs":types_for(&program.output.kind).len(),"simd":simd,"dynamic_byte_index_lowering":if !simd || stack_index {"stack"} else {"vector"}});
    if !program.effects.is_empty() {
        descriptor["stream_output"] = true.into();
    }
    std::fs::write(
        directory.join("control.json"),
        serde_json::to_string(&descriptor).unwrap(),
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}
