use std::{env, fs, path::PathBuf, process::Command};
fn main() {
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_SOURCE");
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_BATCH");
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_SCHEDULE");
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_PACK8");
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_SIMD");
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_FUSE_ENCODE");
    let source = env::var("MECH_SEQUENCE_SOURCE").unwrap_or_else(|_| "../knucleotide.mec".into());
    println!("cargo:rerun-if-changed={source}");
    let batch = env::var("MECH_SEQUENCE_BATCH")
        .unwrap_or_else(|_| "4096".into())
        .parse()
        .unwrap();
    let mut program =
        mech_gpu::sequence::compile(&fs::read_to_string(source).unwrap(), batch).unwrap();
    match env::var("MECH_SEQUENCE_SCHEDULE")
        .as_deref()
        .unwrap_or("source")
    {
        "source" => (),
        "dag" => program = program.scheduled().unwrap(),
        _ => panic!("MECH_SEQUENCE_SCHEDULE must be source or dag"),
    }
    let pack8 = match env::var("MECH_SEQUENCE_PACK8").as_deref().unwrap_or("0") {
        "0" => false,
        "1" => true,
        _ => panic!("MECH_SEQUENCE_PACK8 must be 0 or 1"),
    };
    match env::var("MECH_SEQUENCE_FUSE_ENCODE")
        .as_deref()
        .unwrap_or("0")
    {
        "0" => (),
        "1" => program = program.fuse_record_encoding(),
        _ => panic!("MECH_SEQUENCE_FUSE_ENCODE must be 0 or 1"),
    }
    let simd = match env::var("MECH_SEQUENCE_SIMD").as_deref().unwrap_or("0") {
        "0" => false,
        "1" => true,
        _ => panic!("MECH_SEQUENCE_SIMD must be 0 or 1"),
    };
    let out = PathBuf::from(env::var("OUT_DIR").unwrap());
    let object = out.join("mech-sequence.o");
    fs::write(
        &object,
        program.object_with_packing(batch, pack8, simd).unwrap(),
    )
    .unwrap();
    fs::write(
        out.join("constants.json"),
        serde_json::to_vec(&program.constants).unwrap(),
    )
    .unwrap();
    let status = Command::new("ar")
        .args(["crs"])
        .arg(out.join("libmech_sequence_program.a"))
        .arg(object)
        .status()
        .unwrap();
    assert!(status.success());
    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=mech_sequence_program");
}
