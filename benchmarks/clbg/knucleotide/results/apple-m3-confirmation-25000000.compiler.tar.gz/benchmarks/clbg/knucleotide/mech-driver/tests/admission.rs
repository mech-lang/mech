use mech_gpu::sequence::compile;
#[test]
fn checked_collection_admission_rejects_unsupported_and_invalid_shapes() {
    for source in [
        "io/write(1)\n",
        "~x := 1\nio/write(\"mutable\")\n",
        "x := 1\nx = 2\nio/write(\"assignment\")\n",
        "x := unknown/function(1)\n",
        "x := bytes/encode(3, \"AB\", \"exact\")\n",
        "x := sequence/packed-windows(bytes/encode(\"AB\", \"AB\", \"exact\"), 1, 65)\n",
        "x := sequence/packed-windows(bytes/encode(\"AB\", \"AB\", \"exact\"), 2, 33)\n",
        "x := sequence/packed-windows(bytes/encode(\"AB\", \"AB\", \"exact\"), 0, 2)\n",
        "io/write(undefined)\n",
        "x := 1\nx := 2\nio/write(\"duplicate\")\n",
        "x := [1 2]\nio/write(\"unsupported matrix\")\n",
    ] {
        assert!(compile(source, 256).is_err(), "{source}");
    }
    assert!(compile("io/write(\"ok\")\n", 0).is_err());
    assert!(compile("io/write(\"ok\")\n", 8193).is_err());
}
#[test]
fn generic_source_and_full_width_key_emit_valid_objects() {
    let source = "b := bytes/encode(\"ABBA\", \"AB\", \"exact\")\nh := map/histogram(sequence/packed-windows(b, 1, 64))\nio/write(format/frequencies(h, \"AB\", 100, 3))\n";
    let program = compile(source, 256).unwrap();
    assert!(!program.object(256).unwrap().is_empty());
    assert!(program.object(0).is_err());
    assert!(program.object(8193).is_err());
}

#[test]
fn compact_and_expanded_graphs_emit_identical_scheduled_objects() {
    let compact = compile(include_str!("../../knucleotide-compact.mec"), 256)
        .unwrap()
        .scheduled()
        .unwrap();
    let expanded = compile(include_str!("../../knucleotide.mec"), 256)
        .unwrap()
        .scheduled()
        .unwrap();
    assert_eq!(compact.constants, expanded.constants);
    for fuse in [false, true] {
        let compact = if fuse {
            compact.clone().fuse_record_encoding()
        } else {
            compact.clone()
        };
        let expanded = if fuse {
            expanded.clone().fuse_record_encoding()
        } else {
            expanded.clone()
        };
        if fuse {
            assert!(compact.clone().scheduled().is_err());
        }
        for pack8 in [false, true] {
            assert_eq!(
                compact.object_with_packing(256, pack8, pack8).unwrap(),
                expanded.object_with_packing(256, pack8, pack8).unwrap()
            );
        }
    }
}
