#!/usr/bin/env python3
"""Independent collection conformance: all keys, boundary lengths and alphabets."""
import collections,json,os,pathlib,random,subprocess,tempfile
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parents[2]
TARGET=ROOT/'benchmarks/clbg/nbody/mech-driver/target'
random.seed(20261007)
source=['input := io/read()'];data=bytearray();expected=bytearray();checks=[]
for case,(alphabet,bits,n) in enumerate([('AB',1,n) for n in (0,1,2,3,17,18,19,63,64,65,255,256,257,4095,4096,4097,8201)]+[('ABCDEFGH',3,517),('ACGT',2,1024)]):
 seq=''.join(random.choice(alphabet) for _ in range(n));prefix=f'>CASE{case} '
 data.extend((prefix+'test\r\n').encode())
 for i in range(0,n,37):data.extend((seq[i:i+37].lower()+'\r\n').encode())
 source.append(f's{case} := bytes/encode(text/record(input, "{prefix}", ">"), "{alphabet}", "ignore-ascii-case")')
 widths=sorted({1,2,3,6,12,18,64//bits})
 for width in widths:
  name=f'h{case}-{width}'
  source.append(f'{name} := map/histogram(sequence/packed-windows(s{case}, {bits}, {width}))')
  source.append(f'io/write(format/frequencies({name}, "{alphabet}", 100, 3))')
  counts=collections.Counter(seq[i:i+width] for i in range(max(0,n-width+1)));total=sum(counts.values())
  for key,count in sorted(counts.items(),key=lambda x:(-x[1],x[0])):expected.extend(f'{key} {100.0*count/total:.3f}\n'.encode())
  expected.extend(b'\n');query=alphabet[0]*width
  source.append(f'io/write(format/lookup({name}, "{query}", "{alphabet}", "\\t"))')
  expected.extend(f'{counts[query]}\t{query}\n'.encode());checks.append({'alphabet':alphabet,'length':n,'width':width,'all_keys':len(counts),'updates':total})
# Verify following records never enter the selected sequence and no final newline is required.
data.extend(b'>AFTER final\nTHIS_IS_NOT_IN_ANY_ALPHABET')
with tempfile.TemporaryDirectory(prefix='mech-sequence-conformance-') as temp:
 p=pathlib.Path(temp)/'generic.mec';p.write_text('\n'.join(source)+'\n')
 for batch in (1,256,4096):
  env=os.environ|{'CARGO_TARGET_DIR':str(TARGET),'MECH_SEQUENCE_SOURCE':str(p),'MECH_SEQUENCE_BATCH':str(batch),'RUSTFLAGS':'-D warnings -C target-cpu=native'}
  subprocess.run(['cargo','build','--release','--locked','--manifest-path',str(HERE/'mech-driver/Cargo.toml')],env=env,cwd=ROOT,check=True)
  result=subprocess.run([str(TARGET/'release/mech-clbg-knucleotide')],input=data,capture_output=True,check=True)
  if result.stdout!=expected:
   (HERE/'.build/verify-expected.txt').write_bytes(expected);(HERE/'.build/verify-actual.txt').write_bytes(result.stdout)
   raise AssertionError(f'batch {batch}: independent all-key output differs')
  print(f'batch={batch}: {len(checks)} all-key histograms and lookups passed',flush=True)
  # An out-of-alphabet byte must be rejected without native invocation.
  bad=data.replace(b'>CASE0 test\r\n',b'>CASE0 test\r\nZ\r\n',1)
  rejected=subprocess.run([str(TARGET/'release/mech-clbg-knucleotide')],input=bad,capture_output=True)
  assert rejected.returncode==1 and b'not in the alphabet' in rejected.stderr
# Test the single-consumer IO fusion, including its EOF consumption effect.
with tempfile.TemporaryDirectory(prefix='mech-record-fusion-') as temp:
 p=pathlib.Path(temp)/'record.mec'
 p.write_text('s := bytes/encode(text/record(io/read(), ">FRUIT ", ">"), "AB", "ignore-ascii-case")\nh := map/histogram(sequence/packed-windows(s, 1, 2))\nio/write(format/frequencies(h, "AB", 100, 3))\nio/write(io/read())\n')
 env=os.environ|{'CARGO_TARGET_DIR':str(TARGET),'MECH_SEQUENCE_SOURCE':str(p),'MECH_SEQUENCE_BATCH':'256','RUSTFLAGS':'-D warnings -C target-cpu=native'}
 subprocess.run(['cargo','build','--release','--locked','--manifest-path',str(HERE/'mech-driver/Cargo.toml')],env=env,cwd=ROOT,check=True)
 output=subprocess.run([str(TARGET/'release/mech-clbg-knucleotide')],input=b'>OTHER ignore\nIGNORE\n>FRUIT test\r\nabba\r\n>AFTER discard\nINVALID',capture_output=True,check=True).stdout
 assert output==b'AB 33.333\nBA 33.333\nBB 33.333\n\n'
 print('fused record selection and subsequent EOF read passed',flush=True)
(HERE/'results').mkdir(exist_ok=True)
(HERE/'results/generic-conformance.json').write_text(json.dumps({'batches':[1,256,4096],'checked_histograms':checks,'exact_all_key_frequency_and_lookup_output':True,'invalid_encoding_rejected':True,'fused_record_and_eof_effect':True,'input_cases':'CRLF, lowercase encoding, following records, absent keys, empty/short input, batch tails, packed 64-bit keys, non-DNA alphabet'},indent=2)+'\n')
