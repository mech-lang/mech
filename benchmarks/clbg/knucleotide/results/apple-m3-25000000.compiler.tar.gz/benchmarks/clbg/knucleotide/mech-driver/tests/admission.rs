use mech_gpu::sequence::compile;
#[test]
fn checked_collection_admission_rejects_unsupported_and_invalid_shapes() {
    for source in [
        "io/write(1)\n",
        "~x := 1\nio/write(\"mutable\")\n",
        "x := 1\nx = 2\nio/write(\"assignment\")\n",
        "x := unknown/function(1)\n",
        "x := bytes/encode(3, \"AB\", \"exact\")\n",
        "x := sequence/packed-windows(bytes/encode(\"AB\", \"AB\", \"exact\"), 1, 65)\n",
        "x := sequence/packed-windows(bytes/encode(\"AB\", \"AB\", \"exact\"), 2, 33)\n",
        "x := sequence/packed-windows(bytes/encode(\"AB\", \"AB\", \"exact\"), 0, 2)\n",
        "io/write(undefined)\n",
        "x := 1\nx := 2\nio/write(\"duplicate\")\n",
        "x := [1 2]\nio/write(\"unsupported matrix\")\n",
    ] {
        assert!(compile(source, 256).is_err(), "{source}");
    }
    assert!(compile("io/write(\"ok\")\n", 0).is_err());
    assert!(compile("io/write(\"ok\")\n", 8193).is_err());
}
#[test]
fn generic_source_and_full_width_key_emit_valid_objects() {
    let source = "b := bytes/encode(\"ABBA\", \"AB\", \"exact\")\nh := map/histogram(sequence/packed-windows(b, 1, 64))\nio/write(format/frequencies(h, \"AB\", 100, 3))\n";
    let program = compile(source, 256).unwrap();
    assert!(!program.object(256).unwrap().is_empty());
    assert!(program.object(0).is_err());
    assert!(program.object(8193).is_err());
}
