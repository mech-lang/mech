use std::{env, fs, path::PathBuf, process::Command};
fn main() {
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_SOURCE");
    println!("cargo:rerun-if-env-changed=MECH_SEQUENCE_BATCH");
    let source = env::var("MECH_SEQUENCE_SOURCE").unwrap_or_else(|_| "../knucleotide.mec".into());
    println!("cargo:rerun-if-changed={source}");
    let batch = env::var("MECH_SEQUENCE_BATCH")
        .unwrap_or_else(|_| "4096".into())
        .parse()
        .unwrap();
    let program = mech_gpu::sequence::compile(&fs::read_to_string(source).unwrap(), batch).unwrap();
    let out = PathBuf::from(env::var("OUT_DIR").unwrap());
    let object = out.join("mech-sequence.o");
    fs::write(&object, program.object(batch).unwrap()).unwrap();
    fs::write(
        out.join("constants.json"),
        serde_json::to_vec(&program.constants).unwrap(),
    )
    .unwrap();
    let status = Command::new("ar")
        .args(["crs"])
        .arg(out.join("libmech_sequence_program.a"))
        .arg(object)
        .status()
        .unwrap();
    assert!(status.success());
    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=mech_sequence_program");
}
