use cranelift_codegen::{
    ir::{AbiParam, InstBuilder, MemFlags, StackSlotData, StackSlotKind, condcodes::IntCC, types},
    settings::{self, Configurable},
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{Linkage, Module, default_libcall_names};
use cranelift_object::{ObjectBuilder, ObjectModule};
use mech_syntax::document::{
    AnyCallArgumentSyntax, AstNode, DocumentId, FunctionCallSyntax, ParseConfig, Revision,
    StringLiteralSyntax, SyntaxKind, SyntaxNode, TextSnapshot, VariableDefineSyntax,
    parse_canonical_document,
};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum Constant {
    Text(String),
    Integer(u64),
}
#[derive(Clone, Copy, Debug, PartialEq)]
enum Kind {
    Text,
    Integer,
    Bytes,
    Windows,
    Histogram,
    Unit,
}
#[derive(Clone, Debug)]
struct Node {
    op: u64,
    args: Vec<usize>,
    kernel: Option<(u8, u8)>,
}
#[derive(Clone, Debug)]
pub struct Program {
    pub constants: Vec<Constant>,
    nodes: Vec<Node>,
    kinds: Vec<Kind>,
    windows: BTreeMap<usize, (u8, u8)>,
}

// The admitted operation signatures. Runtime implementations check handles too.
fn operation(name: &str) -> Option<(u64, &'static [Kind], Kind)> {
    use Kind::*;
    Some(match name {
        "io/read" => (1, &[], Text),
        "text/record" => (2, &[Text, Text, Text], Text),
        "bytes/encode" => (3, &[Text, Text, Text], Bytes),
        "sequence/packed-windows" => (4, &[Bytes, Integer, Integer], Windows),
        "map/histogram" => (5, &[Windows], Histogram),
        "format/frequencies" => (6, &[Histogram, Text, Integer, Integer], Text),
        "format/lookup" => (7, &[Histogram, Text, Text, Text], Text),
        "io/write" => (8, &[Text], Unit),
        _ => return None,
    })
}

fn text(node: &SyntaxNode) -> Result<String, String> {
    node.text().map_err(|e| format!("{e:?}"))
}
fn visit(node: &SyntaxNode, kind: SyntaxKind, out: &mut Vec<SyntaxNode>) {
    if node.kind() == kind {
        out.push(node.clone());
        return;
    }
    for child in node.children() {
        visit(&child, kind, out);
    }
}
fn literal(node: SyntaxNode) -> Result<Constant, String> {
    match node.kind() {
        SyntaxKind::StringLiteral => Ok(Constant::Text(
            StringLiteralSyntax::cast(node)
                .ok_or("invalid string")?
                .decoded_text()
                .ok_or("invalid string escape")?,
        )),
        SyntaxKind::Number => Ok(Constant::Integer(
            text(&node)?
                .trim()
                .parse::<u64>()
                .map_err(|_| "only nonnegative integer literals admitted")?,
        )),
        _ => Err("unsupported literal".into()),
    }
}

/// Admits immutable definitions, calls, strings and integers from Mech's
/// canonical parser. Every unknown syntax, operation and kind is rejected.
pub fn compile(source: &str, batch: usize) -> Result<Program, String> {
    if !(1..=8192).contains(&batch) {
        return Err("batch must be 1..8192".into());
    }
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(1), Revision(0), source).map_err(|e| format!("{e:?}"))?,
        ParseConfig::default(),
    );
    if !parsed.diagnostics.is_empty() {
        return Err(format!(
            "canonical source diagnostics: {:?}",
            parsed.diagnostics
        ));
    }
    // Constants are collected first, then native instructions reference their
    // stable value IDs. Lowering uses a temporary interleaved instruction list.
    let mut program = Program {
        constants: Vec::new(),
        nodes: Vec::new(),
        kinds: Vec::new(),
        windows: BTreeMap::new(),
    };
    let mut variables = BTreeMap::new();
    fn items(node: &SyntaxNode, out: &mut Vec<SyntaxNode>) {
        if node.kind() == SyntaxKind::MechCodeAlt {
            out.push(node.clone());
            return;
        }
        for child in node.children() {
            items(&child, out);
        }
    }
    let mut all = Vec::new();
    items(&parsed.syntax(), &mut all);
    if all.is_empty() {
        return Err("no executable Mech items".into());
    }
    // Precollect literals, so constants occupy the beginning of the handle
    // space and all subsequent node IDs agree with native runtime allocation.
    let mut literals = Vec::new();
    visit(&parsed.syntax(), SyntaxKind::StringLiteral, &mut literals);
    visit(&parsed.syntax(), SyntaxKind::Number, &mut literals);
    for literal in &literals {
        let value = self::literal(literal.clone())?;
        program.kinds.push(match value {
            Constant::Text(_) => Kind::Text,
            Constant::Integer(_) => Kind::Integer,
        });
        program.constants.push(value);
    }
    // Expression lowering reuses precollected literals via syntax ranges.
    let mut literal_ids = BTreeMap::new();
    for (id, literal) in literals.into_iter().enumerate() {
        literal_ids.insert((literal.range().start.0, literal.range().end.0), id);
    }
    fn lower(
        node: SyntaxNode,
        p: &mut Program,
        vars: &BTreeMap<String, usize>,
        literals: &BTreeMap<(u32, u32), usize>,
    ) -> Result<usize, String> {
        if let Some(id) = literals.get(&(node.range().start.0, node.range().end.0)) {
            return Ok(*id);
        }
        if node.kind() == SyntaxKind::FunctionCall {
            let call = FunctionCallSyntax::cast(node).ok_or("invalid call")?;
            let name = text(call.function().ok_or("missing function")?.syntax())?;
            let (op, inputs, output) = operation(&name)
                .ok_or_else(|| format!("unsupported collection operation {name}"))?;
            let arguments = call.arguments().ok_or("missing arguments")?.arguments();
            if arguments.len() != inputs.len() {
                return Err(format!("{name}: incorrect arity"));
            }
            let mut args = Vec::new();
            for (argument, expected) in arguments.into_iter().zip(inputs) {
                let value = match argument {
                    AnyCallArgumentSyntax::Positional(x) => x.value(),
                    _ => return Err("bound arguments unsupported".into()),
                }
                .ok_or("missing value")?;
                let id = lower(value.syntax().clone(), p, vars, literals)?;
                if p.kinds[id] != *expected {
                    return Err(format!(
                        "{name} expects {expected:?}, got {:?}",
                        p.kinds[id]
                    ));
                }
                args.push(id);
            }
            let id = p.kinds.len();
            let kernel = if op == 5 {
                Some(*p.windows.get(&args[0]).ok_or("missing window shape")?)
            } else {
                None
            };
            if op == 4 {
                let int = |id| match p.constants.get(id) {
                    Some(Constant::Integer(x)) => Ok(*x),
                    _ => Err("window shape must be constant"),
                };
                let bits = int(args[1])?;
                let width = int(args[2])?;
                if bits == 0 || bits > 8 || width == 0 || width > 64 || bits * width > 64 {
                    return Err("invalid packed window shape".into());
                }
                p.windows.insert(id, (bits as u8, width as u8));
            }
            p.nodes.push(Node { op, args, kernel });
            p.kinds.push(output);
            return Ok(id);
        }
        if node.kind() == SyntaxKind::Variable {
            let name = text(&node)?.trim().to_string();
            return vars
                .get(&name)
                .copied()
                .ok_or_else(|| format!("undefined variable {name}"));
        }
        let children: Vec<_> = node.children().collect();
        if children.len() != 1 {
            return Err(format!("unsupported syntax {:?}", node.kind()));
        }
        lower(children[0].clone(), p, vars, literals)
    }
    for item in all {
        if item
            .children()
            .all(|child| child.kind() == SyntaxKind::Comment)
        {
            continue;
        }
        let owners: Vec<_> = item.children().collect();
        if owners.len() != 1 {
            return Err("unsupported code item".into());
        }
        let owner = &owners[0];
        if owner.kind() == SyntaxKind::Statement {
            let statements: Vec<_> = owner.children().collect();
            if statements.len() != 1 || statements[0].kind() != SyntaxKind::VariableDefine {
                return Err("only immutable definitions are admitted statements".into());
            }
            let def =
                VariableDefineSyntax::cast(statements[0].clone()).ok_or("invalid definition")?;
            if def.mutability_marker().is_some() {
                return Err(
                    "mutable definitions are not admitted by the collection backend".into(),
                );
            }
            let name = text(def.name().ok_or("missing name")?.syntax())?;
            if variables.contains_key(&name) {
                return Err(format!("duplicate definition {name}"));
            }
            let value = lower(
                def.value().ok_or("missing expression")?.syntax().clone(),
                &mut program,
                &variables,
                &literal_ids,
            )?;
            variables.insert(name, value);
        } else {
            if owner.kind() != SyntaxKind::Expression {
                return Err("only call expressions are admitted code items".into());
            }
            let value = lower(owner.clone(), &mut program, &variables, &literal_ids)?;
            if program.kinds[value] != Kind::Unit {
                return Err("bare expressions must return unit".into());
            }
        }
    }
    if program.nodes.is_empty() {
        return Err("source contains no admitted executable operations".into());
    }
    Ok(program)
}

impl Program {
    pub fn object(&self, batch: usize) -> Result<Vec<u8>, String> {
        if !(1..=8192).contains(&batch) {
            return Err("batch must be 1..8192".into());
        }
        let mut flags = settings::builder();
        flags.set("is_pic", "true").map_err(|e| e.to_string())?;
        flags.set("opt_level", "speed").map_err(|e| e.to_string())?;
        let isa = cranelift_native::builder()
            .map_err(|e| e.to_string())?
            .finish(settings::Flags::new(flags))
            .map_err(|e| e.to_string())?;
        let mut module = ObjectModule::new(
            ObjectBuilder::new(isa, "mech_sequence", default_libcall_names())
                .map_err(|e| e.to_string())?,
        );
        let ptr = module.target_config().pointer_type();
        if ptr != types::I64 {
            return Err("collection ABI currently requires 64-bit host".into());
        }
        let mut dispatch_sig = module.make_signature();
        dispatch_sig.params = vec![AbiParam::new(ptr); 8];
        dispatch_sig.returns.push(AbiParam::new(ptr));
        let dispatch = module
            .declare_function("mech_sequence_dispatch", Linkage::Import, &dispatch_sig)
            .map_err(|e| e.to_string())?;
        let mut counter_sig = module.make_signature();
        counter_sig.params = vec![AbiParam::new(ptr); 3];
        let counter = module
            .declare_function("mech_sequence_increment", Linkage::Import, &counter_sig)
            .map_err(|e| e.to_string())?;
        let mut kernels = BTreeMap::new();
        for (bits, width) in self.nodes.iter().filter_map(|n| n.kernel) {
            if kernels.contains_key(&(bits, width)) {
                continue;
            }
            let name = format!("mech_window_{bits}_{width}");
            let mut ctx = module.make_context();
            ctx.func.signature = counter_sig.clone();
            let id = module
                .declare_function(&name, Linkage::Local, &ctx.func.signature)
                .map_err(|e| e.to_string())?;
            let counter_ref = module.declare_func_in_func(counter, &mut ctx.func);
            let mut fbctx = FunctionBuilderContext::new();
            let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
            let entry = b.create_block();
            let loop_block = b.create_block();
            let flush = b.create_block();
            let advance = b.create_block();
            let exit = b.create_block();
            b.append_block_params_for_function_params(entry);
            for t in [ptr, ptr, ptr] {
                b.append_block_param(loop_block, t);
                b.append_block_param(advance, t);
            }
            b.append_block_param(flush, ptr);
            b.append_block_param(flush, ptr);
            b.append_block_param(flush, ptr);
            let slot = b.create_sized_stack_slot(StackSlotData::new(
                StackSlotKind::ExplicitSlot,
                (batch * 8) as u32,
                3,
            ));
            b.switch_to_block(entry);
            let params = b.block_params(entry).to_vec();
            let (data, len, map) = (params[0], params[1], params[2]);
            let enough = b
                .ins()
                .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, len, width as i64);
            let init = b.create_block();
            b.ins().brif(enough, init, &[], exit, &[]);
            b.switch_to_block(init);
            let mut key = b.ins().iconst(ptr, 0);
            for index in 0..width - 1 {
                let byte = b.ins().load(types::I8, MemFlags::new(), data, index as i32);
                let byte = b.ins().uextend(ptr, byte);
                let shifted = b.ins().ishl_imm(key, bits as i64);
                key = b.ins().bor(shifted, byte);
            }
            let index = b.ins().iconst(ptr, (width - 1) as i64);
            let zero = b.ins().iconst(ptr, 0);
            b.ins()
                .jump(loop_block, &[index.into(), key.into(), zero.into()]);
            b.switch_to_block(loop_block);
            let p = b.block_params(loop_block).to_vec();
            let (index, key, used) = (p[0], p[1], p[2]);
            let addr = b.ins().iadd(data, index);
            let byte = b.ins().load(types::I8, MemFlags::new(), addr, 0);
            let byte = b.ins().uextend(ptr, byte);
            let shifted = b.ins().ishl_imm(key, bits as i64);
            let key = b.ins().bor(shifted, byte);
            let key = if bits as u32 * width as u32 == 64 {
                key
            } else {
                b.ins()
                    .band_imm(key, ((1u64 << (bits as u32 * width as u32)) - 1) as i64)
            };
            let buffer = b.ins().stack_addr(ptr, slot, 0);
            let offset = b.ins().ishl_imm(used, 3);
            let addr = b.ins().iadd(buffer, offset);
            b.ins().store(MemFlags::new(), key, addr, 0);
            let next = b.ins().iadd_imm(index, 1);
            let used = b.ins().iadd_imm(used, 1);
            let full = b.ins().icmp_imm(IntCC::Equal, used, batch as i64);
            let end = b.ins().icmp(IntCC::Equal, next, len);
            let should_flush = b.ins().bor(full, end);
            b.ins().brif(
                should_flush,
                flush,
                &[next.into(), key.into(), used.into()],
                advance,
                &[next.into(), key.into(), used.into()],
            );
            b.switch_to_block(flush);
            let p = b.block_params(flush).to_vec();
            let buffer = b.ins().stack_addr(ptr, slot, 0);
            b.ins().call(counter_ref, &[map, buffer, p[2]]);
            let zero = b.ins().iconst(ptr, 0);
            b.ins()
                .jump(advance, &[p[0].into(), p[1].into(), zero.into()]);
            b.switch_to_block(advance);
            let p = b.block_params(advance).to_vec();
            let more = b.ins().icmp(IntCC::UnsignedLessThan, p[0], len);
            b.ins().brif(
                more,
                loop_block,
                &[p[0].into(), p[1].into(), p[2].into()],
                exit,
                &[],
            );
            b.switch_to_block(exit);
            b.ins().return_(&[]);
            b.seal_all_blocks();
            b.finalize();
            module
                .define_function(id, &mut ctx)
                .map_err(|e| e.to_string())?;
            kernels.insert((bits, width), id);
        }
        let mut ctx = module.make_context();
        ctx.func.signature.params.push(AbiParam::new(ptr));
        let entry_id = module
            .declare_function("mech_sequence_entry", Linkage::Export, &ctx.func.signature)
            .map_err(|e| e.to_string())?;
        let dispatch_ref = module.declare_func_in_func(dispatch, &mut ctx.func);
        let refs: BTreeMap<_, _> = kernels
            .iter()
            .map(|(shape, id)| (*shape, module.declare_func_in_func(*id, &mut ctx.func)))
            .collect();
        let mut fbctx = FunctionBuilderContext::new();
        let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
        let block = b.create_block();
        b.append_block_params_for_function_params(block);
        b.switch_to_block(block);
        let context = b.block_params(block)[0];
        let mut last_use = BTreeMap::new();
        let mut uses = BTreeMap::<usize, usize>::new();
        for (index, node) in self.nodes.iter().enumerate() {
            for &arg in &node.args {
                last_use.insert(arg, index);
                *uses.entry(arg).or_default() += 1;
            }
        }
        // Fuse a single-consumer record extraction with stdin reading. Keep
        // handle allocation order and drain stdin to preserve IO effect order.
        let mut fused = BTreeMap::new();
        for (index, node) in self.nodes.iter().enumerate() {
            if node.op == 2 && uses.get(&node.args[0]) == Some(&1) {
                if let Some(read_index) = node.args[0].checked_sub(self.constants.len()) {
                    if self.nodes.get(read_index).is_some_and(|n| n.op == 1) {
                        fused.insert(read_index, 11);
                        fused.insert(index, 10);
                    }
                }
            }
        }
        for (index, node) in self.nodes.iter().enumerate() {
            let op = fused.get(&index).copied().unwrap_or(node.op);
            let mut args = vec![context, b.ins().iconst(ptr, op as i64)];
            for i in 0..5 {
                args.push(
                    b.ins()
                        .iconst(ptr, node.args.get(i).copied().unwrap_or(0) as i64),
                );
            }
            let kernel = if let Some(shape) = node.kernel {
                b.ins().func_addr(ptr, refs[&shape])
            } else {
                b.ins().iconst(ptr, 0)
            };
            args.push(kernel);
            b.ins().call(dispatch_ref, &args);
            // Release dead intermediates without changing the stable handle IDs.
            let releases: Vec<_> = node
                .args
                .iter()
                .copied()
                .filter(|id| last_use.get(id) == Some(&index))
                .collect();
            for id in releases
                .into_iter()
                .collect::<std::collections::BTreeSet<_>>()
            {
                let nine = b.ins().iconst(ptr, 9);
                let handle = b.ins().iconst(ptr, id as i64);
                let zero = b.ins().iconst(ptr, 0);
                b.ins().call(
                    dispatch_ref,
                    &[context, nine, handle, zero, zero, zero, zero, zero],
                );
            }
        }
        b.ins().return_(&[]);
        b.seal_all_blocks();
        b.finalize();
        module
            .define_function(entry_id, &mut ctx)
            .map_err(|e| e.to_string())?;
        module.finish().emit().map_err(|e| e.to_string())
    }
}
