//! Reusable sequence, map, text and numeric operations for native dataflows.
//! This catalog is opt-in; it does not modify the frozen resident distribution.
use mech_engine::native_sequence::{Catalog, Kind::*, OperationSignature, OutputKind::*};

macro_rules! operation {
    ($name:literal, $id:literal, [$([$($kind:ident),+]),*], $output:expr) => {
        OperationSignature { name: $name, op: $id, inputs: &[$(&[$($kind),+]),*], output: $output }
    };
}
const OPERATIONS: Catalog = &[
    operation!("io/read", 1, [], Fixed(Text)),
    operation!("text/record", 2, [[Text], [Text], [Text]], Fixed(Text)),
    operation!("bytes/encode", 3, [[Text], [Text], [Text]], Fixed(Bytes)),
    operation!(
        "sequence/packed-windows",
        4,
        [[Bytes], [Integer], [Integer]],
        Fixed(Windows)
    ),
    operation!("map/histogram", 5, [[Windows]], Fixed(Histogram)),
    operation!("io/write", 8, [[Text]], Fixed(Unit)),
    operation!("map/keys", 13, [[Histogram]], Fixed(Integers)),
    operation!("map/values", 14, [[Histogram]], Fixed(Integers)),
    operation!(
        "sequence/decode",
        15,
        [[Integers], [Integer], [Integer], [Text]],
        Fixed(Texts)
    ),
    operation!(
        "sequence/sort-indices",
        16,
        [
            [Integers, Numbers, Texts],
            [Text],
            [Integers, Numbers, Texts],
            [Text]
        ],
        Fixed(Indices)
    ),
    operation!(
        "sequence/select",
        17,
        [[Integers, Numbers, Texts], [Indices]],
        Input(0)
    ),
    operation!("stats/sum", 18, [[Integers]], Fixed(Integer)),
    operation!("number/to-f64", 19, [[Integer, Integers]], Numeric),
    operation!(
        "number/format",
        24,
        [[Integer, Integers, Float, Numbers], [Integer]],
        Formatted
    ),
    operation!("text/zip", 25, [[Texts], [Texts], [Text]], Fixed(Texts)),
    operation!("text/join", 26, [[Texts], [Text]], Fixed(Text)),
    operation!("string/concat", 27, [[Text], [Text]], Fixed(Text)),
    operation!("text/length", 28, [[Text]], Fixed(Integer)),
    operation!("sequence/pack", 29, [[Bytes], [Integer]], Fixed(Integer)),
    operation!("map/get", 30, [[Histogram], [Integer]], Fixed(Integer)),
    operation!("text/join-terminated", 31, [[Texts], [Text]], Fixed(Text)),
];

pub fn native_sequence_catalog() -> Catalog {
    OPERATIONS
}

/// General grid orchestration and image serialization source operations.
pub fn native_grid_catalog() -> &'static [&'static str] {
    &["io/argument-u64", "grid/map-until", "image/pbm", "io/write"]
}
