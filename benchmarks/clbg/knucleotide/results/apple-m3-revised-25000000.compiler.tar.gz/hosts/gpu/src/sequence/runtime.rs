use super::compiler::Constant;
use super::counts::Counts;
use rayon::prelude::*;
use std::{
    io::{BufRead, Write},
    sync::{Arc, Mutex, OnceLock},
    thread::JoinHandle,
};

pub type NativeEntry = unsafe extern "C" fn(*mut std::ffi::c_void);
type NativeWindow = unsafe extern "C" fn(*const u8, usize, *mut Counts);
type NativeNumeric = unsafe extern "C" fn(*const f64, usize, *const f64, usize, *mut f64, usize);
#[derive(Clone)]
struct Window {
    bytes: Arc<Vec<u8>>,
    bits: u8,
    width: u8,
}
struct Histogram {
    map: Counts,
}
struct Pending {
    value: OnceLock<Arc<Histogram>>,
    task: Mutex<Option<JoinHandle<Histogram>>>,
}
impl Pending {
    fn resolve(&self) -> Result<Arc<Histogram>, String> {
        if let Some(value) = self.value.get() {
            return Ok(value.clone());
        }
        let mut task = self
            .task
            .lock()
            .map_err(|_| "histogram task lock poisoned")?;
        if let Some(value) = self.value.get() {
            return Ok(value.clone());
        }
        let value = Arc::new(
            task.take()
                .ok_or("missing histogram task")?
                .join()
                .map_err(|_| "histogram task panicked")?,
        );
        self.value
            .set(value.clone())
            .map_err(|_| "duplicate histogram result")?;
        Ok(value)
    }
}
#[derive(Clone)]
enum Value {
    Text(Arc<Vec<u8>>),
    Integer(u64),
    Integers(Arc<Vec<u64>>),
    Numbers(Arc<Vec<f64>>, bool),
    Texts(Arc<Vec<Vec<u8>>>),
    Indices(Arc<Vec<usize>>),
    Bytes(Arc<Vec<u8>>, usize),
    Window(Window),
    Histogram(Arc<Pending>),
    Unit,
}

impl Value {
    fn vector_len(&self) -> Result<usize, String> {
        match self {
            Self::Integers(v) => Ok(v.len()),
            Self::Numbers(v, _) => Ok(v.len()),
            Self::Texts(v) => Ok(v.len()),
            _ => Err("expected a vector".into()),
        }
    }
    fn compare_at(&self, i: usize, j: usize) -> std::cmp::Ordering {
        match self {
            Self::Integers(v) => v[i].cmp(&v[j]),
            Self::Numbers(v, _) => v[i].total_cmp(&v[j]),
            Self::Texts(v) => v[i].cmp(&v[j]),
            _ => unreachable!("validated sort key kind"),
        }
    }
}

/// Private handle storage used by the compiled collection program. Inputs and
/// outputs belong to the generic host; all program constants come from source.
pub struct Context {
    values: Vec<Value>,
    input: Option<Vec<u8>>,
    pub output: Vec<u8>,
    error: Option<String>,
    write_stdout: bool,
    partitions: usize,
    compact_counts: bool,
    standard_map: bool,
    pool: Option<Arc<rayon::ThreadPool>>,
    profile: bool,
}
impl Context {
    pub fn new(constants: &[Constant], input: Option<Vec<u8>>, write_stdout: bool) -> Self {
        Self {
            values: constants
                .iter()
                .map(|c| match c {
                    Constant::Text(s) => Value::Text(Arc::new(s.as_bytes().to_vec())),
                    Constant::Integer(x) => Value::Integer(*x),
                    Constant::Float(bits) => {
                        Value::Numbers(Arc::new(vec![f64::from_bits(*bits)]), true)
                    }
                })
                .collect(),
            input,
            output: Vec::new(),
            error: None,
            write_stdout,
            partitions: 1,
            compact_counts: false,
            standard_map: false,
            pool: None,
            profile: false,
        }
    }
    /// Generic histogram policy; partitions use disjoint window starts and
    /// overlap only the input bytes needed to complete boundary windows.
    pub fn with_histogram_policy(
        mut self,
        partitions: usize,
        compact_counts: bool,
        profile: bool,
    ) -> Result<Self, String> {
        if !(1..=64).contains(&partitions) {
            return Err("partitions must be 1..64".into());
        }
        self.partitions = partitions;
        self.compact_counts = compact_counts;
        self.profile = profile;
        if partitions > 1 {
            self.pool = Some(Arc::new(
                rayon::ThreadPoolBuilder::new()
                    .build()
                    .map_err(|e| e.to_string())?,
            ));
        }
        Ok(self)
    }
    pub fn with_standard_map(mut self, enabled: bool) -> Self {
        self.standard_map = enabled;
        self
    }

    /// # Safety
    /// `entry` must be the entry point of an object emitted for precisely the
    /// constants used to construct this context, linked with this ABI version.
    pub unsafe fn run(&mut self, entry: NativeEntry) -> Result<(), String> {
        // SAFETY: Required by this API's contract; self stays exclusively live.
        unsafe { entry((self as *mut Context).cast()) };
        // Join unused computations as well so process completion includes all
        // requested histogram work, even if the source doesn't read a result.
        for value in &self.values {
            if let Value::Histogram(p) = value {
                p.resolve()?;
            }
        }
        if self.write_stdout {
            std::io::stdout().flush().map_err(|e| e.to_string())?;
        }
        if let Some(error) = self.error.take() {
            Err(error)
        } else {
            Ok(())
        }
    }
    fn text(&self, id: usize) -> Result<Arc<Vec<u8>>, String> {
        match self.values.get(id) {
            Some(Value::Text(s)) => Ok(s.clone()),
            _ => Err("expected text handle".into()),
        }
    }
    fn integer(&self, id: usize) -> Result<u64, String> {
        match self.values.get(id) {
            Some(Value::Integer(n)) => Ok(*n),
            _ => Err("expected integer handle".into()),
        }
    }
    fn histogram(&self, id: usize) -> Result<Arc<Histogram>, String> {
        match self.values.get(id) {
            Some(Value::Histogram(p)) => p.resolve(),
            _ => Err("expected histogram handle".into()),
        }
    }
    fn integers(&self, id: usize) -> Result<Arc<Vec<u64>>, String> {
        match self.values.get(id) {
            Some(Value::Integers(v)) => Ok(v.clone()),
            _ => Err("expected integer vector".into()),
        }
    }
    fn texts(&self, id: usize) -> Result<Arc<Vec<Vec<u8>>>, String> {
        match self.values.get(id) {
            Some(Value::Texts(v)) => Ok(v.clone()),
            _ => Err("expected text vector".into()),
        }
    }
    fn op(&mut self, op: u64, a: [usize; 5], kernel: usize) -> Result<Value, String> {
        Ok(match op {
            1 => {
                let bytes = if let Some(input) = self.input.take() {
                    input
                } else {
                    let mut reader = std::io::stdin().lock();
                    let mut bytes = Vec::new();
                    while reader
                        .read_until(b'\n', &mut bytes)
                        .map_err(|e| e.to_string())?
                        != 0
                    {}
                    bytes
                };
                Value::Text(Arc::new(bytes))
            }
            2 | 10 => {
                let begin = self.text(a[1])?;
                let end = self.text(a[2])?;
                let bytes = if op == 2 {
                    let input = self.text(a[0])?;
                    record(std::io::Cursor::new(input.as_slice()), &begin, &end, None)?
                } else if let Some(input) = self.input.take() {
                    record(std::io::Cursor::new(input), &begin, &end, None)?
                } else {
                    record(std::io::stdin().lock(), &begin, &end, None)?
                };
                Value::Text(Arc::new(bytes))
            }
            11 => Value::Unit,
            3 => {
                let text = self.text(a[0])?;
                let alphabet = self.text(a[1])?;
                let mode = self.text(a[2])?;
                let table = encoding_table(&alphabet, &mode)?;
                let mut bytes = Vec::with_capacity(text.len());
                for &byte in text.iter() {
                    let code = table[byte as usize];
                    if code == u16::MAX {
                        return Err(format!("byte {byte} is not in the alphabet"));
                    }
                    bytes.push(code as u8);
                }
                Value::Bytes(Arc::new(bytes), alphabet.len())
            }
            12 => {
                let begin = self.text(a[0])?;
                let alphabet = self.text(a[1])?;
                let mode = self.text(a[2])?;
                let end = self.text(a[3])?;
                let table = encoding_table(&alphabet, &mode)?;
                let bytes = if let Some(input) = self.input.take() {
                    record(std::io::Cursor::new(input), &begin, &end, Some(&table))?
                } else {
                    record(std::io::stdin().lock(), &begin, &end, Some(&table))?
                };
                Value::Bytes(Arc::new(bytes), alphabet.len())
            }
            4 => {
                let (bytes, symbols) = match self.values.get(a[0]) {
                    Some(Value::Bytes(b, n)) => (b.clone(), *n),
                    _ => return Err("expected bytes".into()),
                };
                let bits = self.integer(a[1])?;
                let width = self.integer(a[2])?;
                if bits == 0 || bits > 8 || width == 0 || width > 64 || bits * width > 64 {
                    return Err("invalid packed window shape".into());
                }
                if symbols as u64 > (1u64 << bits) {
                    return Err("encoded symbol exceeds window bit width".into());
                }
                Value::Window(Window {
                    bytes,
                    bits: bits as u8,
                    width: width as u8,
                })
            }
            5 => {
                let window = match self.values.get(a[0]) {
                    Some(Value::Window(w)) => w.clone(),
                    _ => return Err("expected packed windows".into()),
                };
                if kernel == 0 {
                    return Err("missing native window kernel".into());
                }
                // SAFETY: The compiler supplies a same-object function address
                // with exactly NativeWindow ABI and this admitted window shape.
                let function = unsafe { std::mem::transmute::<usize, NativeWindow>(kernel) };
                let (partitions, compact, pool, profile) = (
                    self.partitions,
                    self.compact_counts,
                    self.pool.clone(),
                    self.profile,
                );
                let standard = self.standard_map;
                let task = std::thread::spawn(move || {
                    let start_time = std::time::Instant::now();
                    let total = window.bytes.len().saturating_sub(window.width as usize - 1);
                    let pieces = if total < 1024 { 1 } else { partitions };
                    let count = |piece| {
                        let mut map = Counts::new(
                            window.bits as u32 * window.width as u32,
                            total,
                            compact,
                            standard,
                        );
                        let boundary = |i| total / pieces * i + (total % pieces) * i / pieces;
                        let start = boundary(piece);
                        let end = boundary(piece + 1);
                        if start < end {
                            let bytes = &window.bytes[start..end + window.width as usize - 1];
                            // SAFETY: This slice contains exactly end-start
                            // window starts plus their trailing symbols. Its
                            // allocation stays live; this worker owns its table.
                            unsafe { function(bytes.as_ptr(), bytes.len(), &mut map) };
                        }
                        map
                    };
                    let mut maps = if let Some(pool) = &pool {
                        pool.install(|| (0..pieces).into_par_iter().map(count).collect::<Vec<_>>())
                    } else {
                        vec![count(0)]
                    }
                    .into_iter();
                    let mut map = maps.next().expect("at least one histogram partition");
                    for other in maps {
                        map.merge(other);
                    }
                    assert_eq!(
                        map.rows().iter().map(|(_, count)| count).sum::<u64>(),
                        total as u64,
                        "native traversal changed the number of histogram updates"
                    );
                    if profile {
                        eprintln!(
                            "histogram bits={} width={} partitions={} windows={} elapsed={:.6}",
                            window.bits,
                            window.width,
                            pieces,
                            total,
                            start_time.elapsed().as_secs_f64()
                        );
                    }
                    Histogram { map }
                });
                Value::Histogram(Arc::new(Pending {
                    value: OnceLock::new(),
                    task: Mutex::new(Some(task)),
                }))
            }
            13 | 14 => {
                let h = self.histogram(a[0])?;
                Value::Integers(Arc::new(
                    h.map
                        .rows()
                        .into_iter()
                        .map(|(key, count)| if op == 13 { key } else { count })
                        .collect(),
                ))
            }
            15 => {
                let values = self.integers(a[0])?;
                let bits = self.integer(a[1])?;
                let width = self.integer(a[2])?;
                let alphabet = self.text(a[3])?;
                if bits == 0 || bits > 8 || width == 0 || width > 64 || bits * width > 64 {
                    return Err("invalid decode shape".into());
                }
                Value::Texts(Arc::new(
                    values
                        .iter()
                        .map(|&key| decode(key, bits as u8, width as u8, &alphabet))
                        .collect::<Result<Vec<_>, _>>()?,
                ))
            }
            16 => {
                let first = self.values.get(a[0]).ok_or("missing sort key")?;
                let second = self.values.get(a[2]).ok_or("missing sort key")?;
                let len = first.vector_len()?;
                if len != second.vector_len()? {
                    return Err("sort key lengths differ".into());
                }
                let descending = |mode: &[u8]| match mode {
                    b"asc" => Ok(false),
                    b"desc" => Ok(true),
                    _ => Err("sort direction must be asc or desc"),
                };
                let reverse1 = descending(&self.text(a[1])?)?;
                let reverse2 = descending(&self.text(a[3])?)?;
                let mut indices = (0..len).collect::<Vec<_>>();
                indices.sort_unstable_by(|&i, &j| {
                    let c = first.compare_at(i, j);
                    let c = if reverse1 { c.reverse() } else { c };
                    c.then_with(|| {
                        let c = second.compare_at(i, j);
                        if reverse2 { c.reverse() } else { c }
                    })
                    .then(i.cmp(&j))
                });
                Value::Indices(Arc::new(indices))
            }
            17 => {
                let Some(Value::Indices(indices)) = self.values.get(a[1]) else {
                    return Err("expected indices".into());
                };
                let source = self.values.get(a[0]).ok_or("missing selected vector")?;
                if indices
                    .iter()
                    .any(|&i| i >= source.vector_len().unwrap_or(0))
                {
                    return Err("selection index outside vector".into());
                }
                match source {
                    Value::Integers(v) => {
                        Value::Integers(Arc::new(indices.iter().map(|&i| v[i]).collect()))
                    }
                    Value::Numbers(v, _) => {
                        Value::Numbers(Arc::new(indices.iter().map(|&i| v[i]).collect()), false)
                    }
                    Value::Texts(v) => {
                        Value::Texts(Arc::new(indices.iter().map(|&i| v[i].clone()).collect()))
                    }
                    _ => return Err("unsupported selected vector".into()),
                }
            }
            18 => {
                let values = self.integers(a[0])?;
                Value::Integer(
                    values
                        .iter()
                        .try_fold(0u64, |a, b| a.checked_add(*b).ok_or("integer sum overflow"))?,
                )
            }
            19 => match self.values.get(a[0]) {
                Some(Value::Integer(value)) => Value::Numbers(Arc::new(vec![*value as f64]), true),
                Some(Value::Integers(values)) => Value::Numbers(
                    Arc::new(values.iter().map(|&value| value as f64).collect()),
                    false,
                ),
                _ => return Err("expected integer values".into()),
            },
            20..=23 => {
                let (Some(Value::Numbers(left, scalar1)), Some(Value::Numbers(right, scalar2))) =
                    (self.values.get(a[0]), self.values.get(a[1]))
                else {
                    return Err("expected numeric values".into());
                };
                let length = if *scalar1 {
                    right.len()
                } else if *scalar2 || left.len() == right.len() {
                    left.len()
                } else {
                    return Err("numeric vector shapes differ".into());
                };
                if kernel == 0 {
                    return Err("missing native numeric kernel".into());
                }
                let mut output = vec![0.0; length];
                // SAFETY: The same-object compiler supplies this typed native
                // arithmetic function. Checked vector shapes bound every load,
                // and this invocation exclusively owns its output allocation.
                let function = unsafe { std::mem::transmute::<usize, NativeNumeric>(kernel) };
                unsafe {
                    function(
                        left.as_ptr(),
                        left.len(),
                        right.as_ptr(),
                        right.len(),
                        output.as_mut_ptr(),
                        length,
                    )
                };
                Value::Numbers(Arc::new(output), *scalar1 && *scalar2)
            }
            24 => {
                let decimals = self.integer(a[1])?;
                if decimals > 12 {
                    return Err("decimal precision exceeds 12".into());
                }
                let (rows, scalar) = match self.values.get(a[0]) {
                    Some(Value::Integer(value)) => {
                        if decimals != 0 {
                            return Err("integer formatting requires precision zero".into());
                        }
                        (vec![value.to_string().into_bytes()], true)
                    }
                    Some(Value::Integers(values)) => {
                        if decimals != 0 {
                            return Err("integer formatting requires precision zero".into());
                        }
                        (
                            values.iter().map(|v| v.to_string().into_bytes()).collect(),
                            false,
                        )
                    }
                    Some(Value::Numbers(values, scalar)) => (
                        values
                            .iter()
                            .map(|value| format!("{:.*}", decimals as usize, value).into_bytes())
                            .collect(),
                        *scalar,
                    ),
                    _ => return Err("expected numeric format input".into()),
                };
                if scalar {
                    Value::Text(Arc::new(
                        rows.into_iter()
                            .next()
                            .ok_or("missing scalar format value")?,
                    ))
                } else {
                    Value::Texts(Arc::new(rows))
                }
            }
            25 => {
                let left = self.texts(a[0])?;
                let right = self.texts(a[1])?;
                let separator = self.text(a[2])?;
                if left.len() != right.len() {
                    return Err("text columns have unequal lengths".into());
                }
                Value::Texts(Arc::new(
                    left.iter()
                        .zip(right.iter())
                        .map(|(a, b)| {
                            let mut row = a.clone();
                            row.extend_from_slice(&separator);
                            row.extend_from_slice(b);
                            row
                        })
                        .collect(),
                ))
            }
            26 | 31 => {
                let rows = self.texts(a[0])?;
                let separator = self.text(a[1])?;
                let mut bytes = Vec::new();
                for (i, row) in rows.iter().enumerate() {
                    if op == 26 && i > 0 {
                        bytes.extend_from_slice(&separator);
                    }
                    bytes.extend_from_slice(row);
                    if op == 31 {
                        bytes.extend_from_slice(&separator);
                    }
                }
                Value::Text(Arc::new(bytes))
            }
            27 => {
                let left = self.text(a[0])?;
                let right = self.text(a[1])?;
                let mut bytes = left.as_ref().clone();
                bytes.extend_from_slice(&right);
                Value::Text(Arc::new(bytes))
            }
            28 => Value::Integer(self.text(a[0])?.len() as u64),
            29 => {
                let Some(Value::Bytes(bytes, symbols)) = self.values.get(a[0]) else {
                    return Err("expected encoded symbols".into());
                };
                let bits = self.integer(a[1])?;
                if bits == 0
                    || bits > 8
                    || bytes.len() as u64 * bits > 64
                    || *symbols as u64 > 1u64 << bits
                {
                    return Err("invalid key packing shape".into());
                }
                Value::Integer(
                    bytes
                        .iter()
                        .fold(0u64, |key, &byte| (key << bits) | byte as u64),
                )
            }
            30 => Value::Integer(self.histogram(a[0])?.map.get(self.integer(a[1])?)),
            8 => {
                let bytes = self.text(a[0])?;
                if self.write_stdout {
                    std::io::stdout()
                        .write_all(&bytes)
                        .map_err(|e| e.to_string())?;
                } else {
                    self.output.extend_from_slice(&bytes);
                }
                Value::Unit
            }
            _ => return Err("unknown native collection operation".into()),
        })
    }
}
fn encoding_table(alphabet: &[u8], mode: &[u8]) -> Result<[u16; 256], String> {
    if alphabet.is_empty() || alphabet.len() > 256 {
        return Err("invalid byte alphabet".into());
    }
    let ignore = match mode {
        b"ignore-ascii-case" => true,
        b"exact" => false,
        _ => return Err("unknown byte encoding mode".into()),
    };
    let mut table = [u16::MAX; 256];
    for (index, &byte) in alphabet.iter().enumerate() {
        let keys = if ignore {
            [byte.to_ascii_lowercase(), byte.to_ascii_uppercase()]
        } else {
            [byte, byte]
        };
        for key in keys {
            if table[key as usize] != u16::MAX && table[key as usize] != index as u16 {
                return Err("duplicate alphabet symbol".into());
            }
            table[key as usize] = index as u16;
        }
    }
    Ok(table)
}

fn record(
    mut reader: impl BufRead,
    begin: &[u8],
    end: &[u8],
    encoding: Option<&[u16; 256]>,
) -> Result<Vec<u8>, String> {
    if begin.is_empty() || end.is_empty() {
        return Err("record prefixes cannot be empty".into());
    }
    let mut found = false;
    let mut ended = false;
    let mut bytes = Vec::new();
    let mut line = Vec::new();
    loop {
        line.clear();
        if reader
            .read_until(b'\n', &mut line)
            .map_err(|e| e.to_string())?
            == 0
        {
            break;
        }
        let line = line.strip_suffix(b"\n").unwrap_or(&line);
        let line = line.strip_suffix(b"\r").unwrap_or(line);
        if ended {
            continue;
        }
        if !found {
            if line.starts_with(begin) {
                found = true;
            }
            continue;
        }
        if line.starts_with(end) {
            ended = true;
            continue;
        }
        if let Some(table) = encoding {
            for &byte in line {
                let code = table[byte as usize];
                if code == u16::MAX {
                    return Err(format!("byte {byte} is not in the alphabet"));
                }
                bytes.push(code as u8);
            }
        } else {
            bytes.extend_from_slice(line);
        }
    }
    if !found {
        return Err("record start was not found".into());
    }
    Ok(bytes)
}

fn decode(mut key: u64, bits: u8, width: u8, alphabet: &[u8]) -> Result<Vec<u8>, String> {
    let mut bytes = vec![0; width as usize];
    let mask = (1u64 << bits) - 1;
    for byte in bytes.iter_mut().rev() {
        *byte = *alphabet
            .get((key & mask) as usize)
            .ok_or("histogram code exceeds alphabet")?;
        key >>= bits;
    }
    Ok(bytes)
}

#[unsafe(no_mangle)]
unsafe extern "C" fn mech_sequence_dispatch(
    context: *mut Context,
    op: u64,
    a0: usize,
    a1: usize,
    a2: usize,
    a3: usize,
    a4: usize,
    kernel: usize,
) -> usize {
    // SAFETY: The generated entry passes its exclusively borrowed live Context.
    let context = unsafe { &mut *context };
    if context.error.is_some() {
        return 0;
    }
    if op == 9 {
        if let Some(value) = context.values.get_mut(a0) {
            if let Value::Histogram(p) = value {
                if let Err(e) = p.resolve() {
                    context.error = Some(e);
                    return 0;
                }
            }
            *value = Value::Unit;
        } else {
            context.error = Some("invalid release handle".into());
        }
        return 0;
    }
    match context.op(op, [a0, a1, a2, a3, a4], kernel) {
        Ok(value) => {
            let id = context.values.len();
            context.values.push(value);
            id
        }
        Err(error) => {
            context.error = Some(error);
            0
        }
    }
}
#[unsafe(no_mangle)]
unsafe extern "C" fn mech_sequence_increment(map: *mut Counts, keys: *const u64, len: usize) {
    // SAFETY: The compiled kernel passes its exclusive live map and a stack
    // buffer containing exactly len initialized keys, with len <= batch <=8192.
    let map = unsafe { &mut *map };
    let keys = unsafe { std::slice::from_raw_parts(keys, len) };
    map.increment(keys);
}
