# k-nucleotide: v0.4 compiled comparison

This is a local blog benchmark on the v0.4 integration checkout
`c4777b7015fe8ff47fdfa48d18606c49aace7d97`. It adds an experimental typed
collection backend; these operations are not yet installed in the general
resident compiler/catalog. It does not establish stock v0.4 support or a
language-wide performance ranking.

The [Benchmarks Game task](https://benchmarksgame-team.pages.debian.net/benchmarksgame/description/knucleotide.html)
requires counting **all** overlapping windows for lengths 1, 2, 3, 4, 6,
12 and 18 using a library hash table. Every window performs a lookup and
count update. Counting only the five queried strings would change the work.

## Input and validation

The pinned, unchanged FASTA C program generates input with N=25,000,000.
The complete input is 254,166,745 bytes, with 125,000,000 letters in THREE.
Every program performs 874,999,961 window updates in total, plus any
source-specific table merging. No code exploits the generator's periodicity.
The exact full input is hashed in `input25000000.json`; generating N=1000
with the same executable also reproduces the official input byte-for-byte.

The complete official N=1000 input and output are in `inputs/`.
Full output is compared byte-for-byte with unchanged Rust #7 and with the
published full output. All locally measured configurations must match the
complete full output. The official small test is checked separately.

Some unchanged upstream sources fail the small reference despite passing
full input: Rust #4/#5, Julia #1, and Java #4/#5 assume absent query keys
exist; Julia #7 divides frequencies by one fewer window than it counts.
The full-cohort chart flags these sources. The strict chart additionally
requires passing the official small reference. This distinction matters:
filtering small-test failures can remove a language's smallest implementation.

`verify.py` independently checks complete all-key frequency tables and
lookups for 133 histograms at each of three native key batch sizes. Cases
include empty/short inputs, batch tails, 64-bit keys, CRLF, lowercase input,
missing queries, frequency ties, later records, and non-DNA alphabets.
A separate case verifies fused record extraction still consumes stdin
through EOF before a later read. Native workers also check that the sum
of all table counts equals the number of admitted windows.
The source-admission tests reject unsupported syntax, wrong argument kinds,
mutable assignments and window shapes that exceed a 64-bit packed key.

## Mech sources and execution

- `knucleotide-compact.mec`: eight nonblank source lines; computes and
  prints each histogram before starting the next.
- `knucleotide.mec`: fifteen nonblank source lines; starts the seven
  independent histogram computations, then prints them in required order.
  Longer windows start first, as in the fastest upstream Rust source.

The source selects THREE, specifies the alphabet and case handling,
requests every window length and histogram, and specifies output queries,
percent scaling, precision and separators. There are no nucleotide letters,
window lengths or query strings in the generic host implementation.

`hosts/gpu/src/sequence` uses Mech's canonical syntax parser, checks an
admitted immutable call graph, and emits a native entry point and packed
window kernels with Cranelift 0.131.3. An AOT object is emitted and linked
**before** timing. The executable does not parse or compile Mech at runtime.
Small serialized constants from the compiled source are loaded at startup.

Generic runtime services implement record extraction, alphabet encoding,
hashbrown 0.15.5 storage, asynchronous histogram tasks, sorting and text
formatting. The Rust runtime is compiled by rustc/LLVM with native CPU
features. Cranelift generates the program calls and rolling-key traversal;
the hash-table library and bulk increment service are ordinary runtime code.
This division is recorded explicitly in each Mech measurement.

The backend streams a single-consumer record selection instead of storing
unwanted records, releases dead intermediates, carries rolling integer keys
between batches, and avoids constructing a full vector of all window keys.
Each batch still performs the same library lookup/update for every key.
Tables begin at the library's small default capacity and grow normally.

As requested, source-size measurements include **Mech code only**. Generic
compiler/runtime/CLI code and library dependencies are excluded. This relies
on the new generic collection API: it should be described as an extension
prototype in the blog and implemented in the maintained catalog before
making a claim about the standard language in a paper. Compiler/library
abstraction boundaries also affect cross-language source-size comparisons.

## Competitors and timing

`manifest.json` pins all 28 currently listed sources for C, C++, Chapel,
Julia, Rust, Go and Java, including starred entries. Sources and their author
comments remain unchanged. Separate dependency pins cover khash, fastutil
and locked Rust crates. Local Java uses OpenJDK JIT with the published
GraalVM AOT submission sources; it must be labelled accordingly.

C/C++ builds test native O3 and fast-math/unrolling/LTO with GCC and LLVM.
Clang can use the GNU pb_ds sources with GCC's headers/libstdc++ and
emulated TLS. Two std::async LLVM LTO configurations fail to link against
this host's GCC TLS runtime; their errors are retained, and separate
fast-math/unrolling configurations without LTO are measured.
The SDK compatibility header only adjusts unused system-library declarations.

Timing uses fresh processes with identical regular-file stdin and stdout
sinks. Reading, encoding, every hash-table update, sorting, output, startup
and Julia/Java JIT work are timed. AOT builds, input generation and validation
are excluded. Full input is checked once before randomized timed rounds;
medians, min/max, all raw samples, execution order and executable hashes
are saved. No compiler builds or tests run alongside measured executions.

Runtime environment controls request eight workers. Unchanged source
policies may use different thread counts, per-frame partitions or serial
execution; every row records its policy. The compact Mech source waits
between tasks, while the parallel source can have seven histogram workers.

## Reproduce

```sh
# Pin only on first setup; refuses to refresh an existing manifest.
python3 benchmarks/clbg/knucleotide/fetch_sources.py

# Full input was produced with the pinned FASTA source:
# compile upstream/fasta-gcc-1.c with native O3 and strict contraction,
# then run .build/fasta 25000000 > .build/knucleotide-input25000000.txt.

RUSTFLAGS='-D warnings -C target-cpu=native' \
CARGO_TARGET_DIR=benchmarks/clbg/nbody/mech-driver/target \
cargo test --release --locked \
  --manifest-path benchmarks/clbg/knucleotide/mech-driver/Cargo.toml \
  --test admission
python3 benchmarks/clbg/knucleotide/verify.py

# Build/check all candidates, then time without further compilation.
python3 benchmarks/clbg/knucleotide/run.py --prepare-only
python3 benchmarks/clbg/knucleotide/run.py --reuse-builds --samples 3

# Python environment requires matplotlib; generates gzip and LOC charts,
# both full-input and strict-small-reference cohorts, SVG/PNG and tables.
python3 benchmarks/clbg/knucleotide/plot.py \
  benchmarks/clbg/knucleotide/results/apple-m3-25000000.json
```

The source-only metric removes comments, collapses whitespace and applies
gzip level 1 with a deterministic timestamp. This is a local compressed
metric, not a claim to reproduce the website's `gz` values. The LOC chart
selects the smallest source by nonblank, noncomment lines independently of
the gzip chart; each joins the fastest and smallest endpoints. A coincident
point only describes the sampled implementations, not an absence of a
possible size/performance tradeoff in the language.
