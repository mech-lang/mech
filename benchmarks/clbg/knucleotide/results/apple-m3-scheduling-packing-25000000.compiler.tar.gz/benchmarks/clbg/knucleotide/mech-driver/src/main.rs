use mech_gpu::sequence::Context;
unsafe extern "C" {
    fn mech_sequence_entry(context: *mut std::ffi::c_void);
}
fn main() {
    let constants: Vec<_> =
        serde_json::from_str(include_str!(concat!(env!("OUT_DIR"), "/constants.json"))).unwrap();
    let mut context = Context::new(&constants, None, true);
    // SAFETY: build.rs emits and links this entry from the very same constants,
    // using the collection backend's checked native ABI and library services.
    if let Err(error) = unsafe { context.run(mech_sequence_entry) } {
        eprintln!("{error}");
        std::process::exit(1);
    }
}
