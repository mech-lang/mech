#include "/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/_stdio.h"
#ifdef __cplusplus
#include <bits/c++config.h>
#undef _GLIBCXX_HAVE_AT_QUICK_EXIT
#undef _GLIBCXX_HAVE_QUICK_EXIT
#endif
