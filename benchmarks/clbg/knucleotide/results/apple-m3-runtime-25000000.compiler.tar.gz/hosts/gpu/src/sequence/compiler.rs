use cranelift_codegen::{
    ir::{AbiParam, InstBuilder, MemFlags, StackSlotData, StackSlotKind, condcodes::IntCC, types},
    settings::{self, Configurable},
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_module::{Linkage, Module, default_libcall_names};
use cranelift_object::{ObjectBuilder, ObjectModule};
use mech_syntax::document::{
    AnyCallArgumentSyntax, AstNode, DocumentId, FunctionCallSyntax, ParseConfig, Revision,
    StringLiteralSyntax, SyntaxKind, SyntaxNode, TextSnapshot, VariableDefineSyntax,
    parse_canonical_document,
};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum Constant {
    Text(String),
    Integer(u64),
}
#[derive(Clone, Copy, Debug, PartialEq)]
enum Kind {
    Text,
    Integer,
    Bytes,
    Windows,
    Histogram,
    Unit,
}
#[derive(Clone, Debug)]
struct Node {
    op: u64,
    args: Vec<usize>,
    kernel: Option<(u8, u8)>,
}
#[derive(Clone, Debug)]
pub struct Program {
    pub constants: Vec<Constant>,
    nodes: Vec<Node>,
    kinds: Vec<Kind>,
    windows: BTreeMap<usize, (u8, u8)>,
}

// The admitted operation signatures. Runtime implementations check handles too.
fn operation(name: &str) -> Option<(u64, &'static [Kind], Kind)> {
    use Kind::*;
    Some(match name {
        "io/read" => (1, &[], Text),
        "text/record" => (2, &[Text, Text, Text], Text),
        "bytes/encode" => (3, &[Text, Text, Text], Bytes),
        "sequence/packed-windows" => (4, &[Bytes, Integer, Integer], Windows),
        "map/histogram" => (5, &[Windows], Histogram),
        "format/frequencies" => (6, &[Histogram, Text, Integer, Integer], Text),
        "format/lookup" => (7, &[Histogram, Text, Text, Text], Text),
        "io/write" => (8, &[Text], Unit),
        _ => return None,
    })
}

fn text(node: &SyntaxNode) -> Result<String, String> {
    node.text().map_err(|e| format!("{e:?}"))
}
fn visit(node: &SyntaxNode, kind: SyntaxKind, out: &mut Vec<SyntaxNode>) {
    if node.kind() == kind {
        out.push(node.clone());
        return;
    }
    for child in node.children() {
        visit(&child, kind, out);
    }
}
fn literal(node: SyntaxNode) -> Result<Constant, String> {
    match node.kind() {
        SyntaxKind::StringLiteral => Ok(Constant::Text(
            StringLiteralSyntax::cast(node)
                .ok_or("invalid string")?
                .decoded_text()
                .ok_or("invalid string escape")?,
        )),
        SyntaxKind::Number => Ok(Constant::Integer(
            text(&node)?
                .trim()
                .parse::<u64>()
                .map_err(|_| "only nonnegative integer literals admitted")?,
        )),
        _ => Err("unsupported literal".into()),
    }
}

/// Admits immutable definitions, calls, strings and integers from Mech's
/// canonical parser. Every unknown syntax, operation and kind is rejected.
pub fn compile(source: &str, batch: usize) -> Result<Program, String> {
    if !(1..=8192).contains(&batch) {
        return Err("batch must be 1..8192".into());
    }
    let parsed = parse_canonical_document(
        TextSnapshot::new(DocumentId(1), Revision(0), source).map_err(|e| format!("{e:?}"))?,
        ParseConfig::default(),
    );
    if !parsed.diagnostics.is_empty() {
        return Err(format!(
            "canonical source diagnostics: {:?}",
            parsed.diagnostics
        ));
    }
    // Constants are collected first, then native instructions reference their
    // stable value IDs. Lowering uses a temporary interleaved instruction list.
    let mut program = Program {
        constants: Vec::new(),
        nodes: Vec::new(),
        kinds: Vec::new(),
        windows: BTreeMap::new(),
    };
    let mut variables = BTreeMap::new();
    fn items(node: &SyntaxNode, out: &mut Vec<SyntaxNode>) {
        if node.kind() == SyntaxKind::MechCodeAlt {
            out.push(node.clone());
            return;
        }
        for child in node.children() {
            items(&child, out);
        }
    }
    let mut all = Vec::new();
    items(&parsed.syntax(), &mut all);
    if all.is_empty() {
        return Err("no executable Mech items".into());
    }
    // Precollect literals, so constants occupy the beginning of the handle
    // space and all subsequent node IDs agree with native runtime allocation.
    let mut literals = Vec::new();
    visit(&parsed.syntax(), SyntaxKind::StringLiteral, &mut literals);
    visit(&parsed.syntax(), SyntaxKind::Number, &mut literals);
    for literal in &literals {
        let value = self::literal(literal.clone())?;
        program.kinds.push(match value {
            Constant::Text(_) => Kind::Text,
            Constant::Integer(_) => Kind::Integer,
        });
        program.constants.push(value);
    }
    // Expression lowering reuses precollected literals via syntax ranges.
    let mut literal_ids = BTreeMap::new();
    for (id, literal) in literals.into_iter().enumerate() {
        literal_ids.insert((literal.range().start.0, literal.range().end.0), id);
    }
    fn lower(
        node: SyntaxNode,
        p: &mut Program,
        vars: &BTreeMap<String, usize>,
        literals: &BTreeMap<(u32, u32), usize>,
    ) -> Result<usize, String> {
        if let Some(id) = literals.get(&(node.range().start.0, node.range().end.0)) {
            return Ok(*id);
        }
        if node.kind() == SyntaxKind::FunctionCall {
            let call = FunctionCallSyntax::cast(node).ok_or("invalid call")?;
            let name = text(call.function().ok_or("missing function")?.syntax())?;
            let (op, inputs, output) = operation(&name)
                .ok_or_else(|| format!("unsupported collection operation {name}"))?;
            let arguments = call.arguments().ok_or("missing arguments")?.arguments();
            if arguments.len() != inputs.len() {
                return Err(format!("{name}: incorrect arity"));
            }
            let mut args = Vec::new();
            for (argument, expected) in arguments.into_iter().zip(inputs) {
                let value = match argument {
                    AnyCallArgumentSyntax::Positional(x) => x.value(),
                    _ => return Err("bound arguments unsupported".into()),
                }
                .ok_or("missing value")?;
                let id = lower(value.syntax().clone(), p, vars, literals)?;
                if p.kinds[id] != *expected {
                    return Err(format!(
                        "{name} expects {expected:?}, got {:?}",
                        p.kinds[id]
                    ));
                }
                args.push(id);
            }
            let id = p.kinds.len();
            let kernel = if op == 5 {
                Some(*p.windows.get(&args[0]).ok_or("missing window shape")?)
            } else {
                None
            };
            if op == 4 {
                let int = |id| match p.constants.get(id) {
                    Some(Constant::Integer(x)) => Ok(*x),
                    _ => Err("window shape must be constant"),
                };
                let bits = int(args[1])?;
                let width = int(args[2])?;
                if bits == 0 || bits > 8 || width == 0 || width > 64 || bits * width > 64 {
                    return Err("invalid packed window shape".into());
                }
                p.windows.insert(id, (bits as u8, width as u8));
            }
            p.nodes.push(Node { op, args, kernel });
            p.kinds.push(output);
            return Ok(id);
        }
        if node.kind() == SyntaxKind::Variable {
            let name = text(&node)?.trim().to_string();
            return vars
                .get(&name)
                .copied()
                .ok_or_else(|| format!("undefined variable {name}"));
        }
        let children: Vec<_> = node.children().collect();
        if children.len() != 1 {
            return Err(format!("unsupported syntax {:?}", node.kind()));
        }
        lower(children[0].clone(), p, vars, literals)
    }
    for item in all {
        if item
            .children()
            .all(|child| child.kind() == SyntaxKind::Comment)
        {
            continue;
        }
        let owners: Vec<_> = item.children().collect();
        if owners.len() != 1 {
            return Err("unsupported code item".into());
        }
        let owner = &owners[0];
        if owner.kind() == SyntaxKind::Statement {
            let statements: Vec<_> = owner.children().collect();
            if statements.len() != 1 || statements[0].kind() != SyntaxKind::VariableDefine {
                return Err("only immutable definitions are admitted statements".into());
            }
            let def =
                VariableDefineSyntax::cast(statements[0].clone()).ok_or("invalid definition")?;
            if def.mutability_marker().is_some() {
                return Err(
                    "mutable definitions are not admitted by the collection backend".into(),
                );
            }
            let name = text(def.name().ok_or("missing name")?.syntax())?;
            if variables.contains_key(&name) {
                return Err(format!("duplicate definition {name}"));
            }
            let value = lower(
                def.value().ok_or("missing expression")?.syntax().clone(),
                &mut program,
                &variables,
                &literal_ids,
            )?;
            variables.insert(name, value);
        } else {
            if owner.kind() != SyntaxKind::Expression {
                return Err("only call expressions are admitted code items".into());
            }
            let value = lower(owner.clone(), &mut program, &variables, &literal_ids)?;
            if program.kinds[value] != Kind::Unit {
                return Err("bare expressions must return unit".into());
            }
        }
    }
    if program.nodes.is_empty() {
        return Err("source contains no admitted executable operations".into());
    }
    Ok(program)
}

impl Program {
    /// Fuse adjacent, single-consumer read/record/encode operations. The
    /// placeholders preserve handle IDs; adjacency preserves IO effect order.
    pub fn fuse_record_encoding(mut self) -> Self {
        let base = self.constants.len();
        let mut uses = BTreeMap::<usize, usize>::new();
        for node in &self.nodes {
            for &arg in &node.args {
                *uses.entry(arg).or_default() += 1;
            }
        }
        for i in 2..self.nodes.len() {
            if self.nodes[i].op != 3 || self.nodes[i - 1].op != 2 || self.nodes[i - 2].op != 1 {
                continue;
            }
            let record_id = base + i - 1;
            let read_id = base + i - 2;
            if self.nodes[i].args[0] != record_id
                || self.nodes[i - 1].args[0] != read_id
                || uses.get(&record_id) != Some(&1)
                || uses.get(&read_id) != Some(&1)
            {
                continue;
            }
            let args = vec![
                self.nodes[i - 1].args[1],
                self.nodes[i].args[1],
                self.nodes[i].args[2],
                self.nodes[i - 1].args[2],
            ];
            self.nodes[i].op = 12;
            self.nodes[i].args = args;
            for index in [i - 2, i - 1] {
                self.nodes[index].op = 11;
                self.nodes[index].args.clear();
                self.kinds[base + index] = Kind::Unit;
            }
        }
        self
    }

    /// Schedule independent immutable computations before blocking consumers.
    /// Reads and writes retain their original effect order. Canonical constants
    /// and handle renumbering make equivalent call graphs emit the same object.
    pub fn scheduled(self) -> Result<Self, String> {
        if self.nodes.iter().any(|node| node.op > 8) {
            return Err("schedule must precede host IO fusion".into());
        }
        let constants: Vec<_> = self
            .constants
            .iter()
            .cloned()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect();
        let mut renamed = BTreeMap::new();
        for (old, constant) in self.constants.iter().enumerate() {
            renamed.insert(old, constants.binary_search(constant).unwrap());
        }
        let old_base = self.constants.len();
        let mut dependencies = Vec::new();
        let mut previous_effect = None;
        for node in &self.nodes {
            let mut parents: BTreeSet<_> = node
                .args
                .iter()
                .filter_map(|id| id.checked_sub(old_base))
                .collect();
            if matches!(node.op, 1 | 8) {
                if let Some(parent) = previous_effect {
                    parents.insert(parent);
                }
                previous_effect = Some(dependencies.len());
            }
            dependencies.push(parents);
        }
        let mut output = Program {
            kinds: constants
                .iter()
                .map(|c| match c {
                    Constant::Text(_) => Kind::Text,
                    Constant::Integer(_) => Kind::Integer,
                })
                .collect(),
            constants,
            nodes: Vec::new(),
            windows: BTreeMap::new(),
        };
        let mut done = BTreeSet::new();
        while done.len() < self.nodes.len() {
            let selected = (0..self.nodes.len())
                .filter(|i| !done.contains(i) && dependencies[*i].is_subset(&done))
                .min_by_key(|&i| {
                    let node = &self.nodes[i];
                    let width = node
                        .kernel
                        .or_else(|| self.windows.get(&(old_base + i)).copied())
                        .map_or(0, |(_, width)| width);
                    let rank = match node.op {
                        5 => 0,
                        4 => 1,
                        1..=3 => 2,
                        6 | 7 => 3,
                        _ => 4,
                    };
                    (rank, std::cmp::Reverse(width), i)
                })
                .ok_or("collection dependency cycle")?;
            let old_id = old_base + selected;
            let new_id = output.kinds.len();
            let mut node = self.nodes[selected].clone();
            for arg in &mut node.args {
                *arg = *renamed.get(arg).ok_or("unscheduled input")?;
            }
            output.nodes.push(node);
            output.kinds.push(self.kinds[old_id]);
            if let Some(shape) = self.windows.get(&old_id) {
                output.windows.insert(new_id, *shape);
            }
            renamed.insert(old_id, new_id);
            done.insert(selected);
        }
        Ok(output)
    }

    pub fn object(&self, batch: usize) -> Result<Vec<u8>, String> {
        self.object_with_pack8(batch, false)
    }

    /// Pack eight two-bit symbols with wide integer operations when enabled.
    /// Other alphabets and every boundary/tail use the scalar checked kernel.
    pub fn object_with_pack8(&self, batch: usize, pack8: bool) -> Result<Vec<u8>, String> {
        if !(1..=8192).contains(&batch) {
            return Err("batch must be 1..8192".into());
        }
        let mut flags = settings::builder();
        flags.set("is_pic", "true").map_err(|e| e.to_string())?;
        flags.set("opt_level", "speed").map_err(|e| e.to_string())?;
        let isa = cranelift_native::builder()
            .map_err(|e| e.to_string())?
            .finish(settings::Flags::new(flags))
            .map_err(|e| e.to_string())?;
        let mut module = ObjectModule::new(
            ObjectBuilder::new(isa, "mech_sequence", default_libcall_names())
                .map_err(|e| e.to_string())?,
        );
        let ptr = module.target_config().pointer_type();
        if ptr != types::I64 {
            return Err("collection ABI currently requires 64-bit host".into());
        }
        let mut dispatch_sig = module.make_signature();
        dispatch_sig.params = vec![AbiParam::new(ptr); 8];
        dispatch_sig.returns.push(AbiParam::new(ptr));
        let dispatch = module
            .declare_function("mech_sequence_dispatch", Linkage::Import, &dispatch_sig)
            .map_err(|e| e.to_string())?;
        let mut counter_sig = module.make_signature();
        counter_sig.params = vec![AbiParam::new(ptr); 3];
        let counter = module
            .declare_function("mech_sequence_increment", Linkage::Import, &counter_sig)
            .map_err(|e| e.to_string())?;
        let mut kernels = BTreeMap::new();
        for (bits, width) in self.nodes.iter().filter_map(|n| n.kernel) {
            if kernels.contains_key(&(bits, width)) {
                continue;
            }
            let name = format!("mech_window_{bits}_{width}");
            let mut ctx = module.make_context();
            ctx.func.signature = counter_sig.clone();
            let id = module
                .declare_function(&name, Linkage::Local, &ctx.func.signature)
                .map_err(|e| e.to_string())?;
            let counter_ref = module.declare_func_in_func(counter, &mut ctx.func);
            let mut fbctx = FunctionBuilderContext::new();
            let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
            let entry = b.create_block();
            let loop_block = b.create_block();
            let scalar = b.create_block();
            let packed = b.create_block();
            let check_flush = b.create_block();
            let flush = b.create_block();
            let advance = b.create_block();
            let exit = b.create_block();
            b.append_block_params_for_function_params(entry);
            for t in [ptr, ptr, ptr] {
                b.append_block_param(loop_block, t);
                b.append_block_param(advance, t);
                b.append_block_param(check_flush, t);
            }
            b.append_block_param(flush, ptr);
            b.append_block_param(flush, ptr);
            b.append_block_param(flush, ptr);
            let slot = b.create_sized_stack_slot(StackSlotData::new(
                StackSlotKind::ExplicitSlot,
                (batch * 8) as u32,
                3,
            ));
            b.switch_to_block(entry);
            let params = b.block_params(entry).to_vec();
            let (data, len, map) = (params[0], params[1], params[2]);
            let enough = b
                .ins()
                .icmp_imm(IntCC::UnsignedGreaterThanOrEqual, len, width as i64);
            let init = b.create_block();
            b.ins().brif(enough, init, &[], exit, &[]);
            b.switch_to_block(init);
            let mut key = b.ins().iconst(ptr, 0);
            for index in 0..width - 1 {
                let byte = b.ins().load(types::I8, MemFlags::new(), data, index as i32);
                let byte = b.ins().uextend(ptr, byte);
                let shifted = b.ins().ishl_imm(key, bits as i64);
                key = b.ins().bor(shifted, byte);
            }
            let index = b.ins().iconst(ptr, (width - 1) as i64);
            let zero = b.ins().iconst(ptr, 0);
            b.ins()
                .jump(loop_block, &[index.into(), key.into(), zero.into()]);
            b.switch_to_block(loop_block);
            let p = b.block_params(loop_block).to_vec();
            let (index, key, used) = (p[0], p[1], p[2]);
            if pack8 && bits == 2 && batch >= 8 && cfg!(target_endian = "little") {
                let end = b.ins().iadd_imm(index, 8);
                let fits_input = b.ins().icmp(IntCC::UnsignedLessThanOrEqual, end, len);
                let end = b.ins().iadd_imm(used, 8);
                let fits_buffer =
                    b.ins()
                        .icmp_imm(IntCC::UnsignedLessThanOrEqual, end, batch as i64);
                let fits = b.ins().band(fits_input, fits_buffer);
                b.ins().brif(fits, packed, &[], scalar, &[]);
                b.switch_to_block(packed);
                let addr = b.ins().iadd(data, index);
                let word = b.ins().load(ptr, MemFlags::new(), addr, 0);
                let mut word = b.ins().bswap(word);
                for (shift, mask) in [
                    (6, 0x000f000f000f000fu64),
                    (12, 0x000000ff000000ff),
                    (24, 0xffff),
                ] {
                    let shifted = b.ins().ushr_imm(word, shift);
                    word = b.ins().bor(word, shifted);
                    word = b.ins().band_imm(word, mask as i64);
                }
                let buffer = b.ins().stack_addr(ptr, slot, 0);
                let offset = b.ins().ishl_imm(used, 3);
                let addr = b.ins().iadd(buffer, offset);
                let mut last = key;
                for j in 0..8 {
                    let old = b.ins().ishl_imm(key, 2 * (j + 1));
                    let added = b.ins().ushr_imm(word, 14 - 2 * j);
                    let combined = b.ins().bor(old, added);
                    last = if width == 32 {
                        combined
                    } else {
                        b.ins()
                            .band_imm(combined, ((1u64 << (2 * width as u32)) - 1) as i64)
                    };
                    b.ins().store(MemFlags::new(), last, addr, 8 * j as i32);
                }
                let next = b.ins().iadd_imm(index, 8);
                let used = b.ins().iadd_imm(used, 8);
                b.ins()
                    .jump(check_flush, &[next.into(), last.into(), used.into()]);
                b.switch_to_block(scalar);
            } else {
                b.ins().jump(scalar, &[]);
                b.switch_to_block(packed);
                b.ins()
                    .trap(cranelift_codegen::ir::TrapCode::unwrap_user(1));
                b.switch_to_block(scalar);
            }
            let addr = b.ins().iadd(data, index);
            let byte = b.ins().load(types::I8, MemFlags::new(), addr, 0);
            let byte = b.ins().uextend(ptr, byte);
            let shifted = b.ins().ishl_imm(key, bits as i64);
            let key = b.ins().bor(shifted, byte);
            let key = if bits as u32 * width as u32 == 64 {
                key
            } else {
                b.ins()
                    .band_imm(key, ((1u64 << (bits as u32 * width as u32)) - 1) as i64)
            };
            let buffer = b.ins().stack_addr(ptr, slot, 0);
            let offset = b.ins().ishl_imm(used, 3);
            let addr = b.ins().iadd(buffer, offset);
            b.ins().store(MemFlags::new(), key, addr, 0);
            let next = b.ins().iadd_imm(index, 1);
            let used = b.ins().iadd_imm(used, 1);
            b.ins()
                .jump(check_flush, &[next.into(), key.into(), used.into()]);
            b.switch_to_block(check_flush);
            let p = b.block_params(check_flush).to_vec();
            let (next, key, used) = (p[0], p[1], p[2]);
            let full = b.ins().icmp_imm(IntCC::Equal, used, batch as i64);
            let end = b.ins().icmp(IntCC::Equal, next, len);
            let should_flush = b.ins().bor(full, end);
            b.ins().brif(
                should_flush,
                flush,
                &[next.into(), key.into(), used.into()],
                advance,
                &[next.into(), key.into(), used.into()],
            );
            b.switch_to_block(flush);
            let p = b.block_params(flush).to_vec();
            let buffer = b.ins().stack_addr(ptr, slot, 0);
            b.ins().call(counter_ref, &[map, buffer, p[2]]);
            let zero = b.ins().iconst(ptr, 0);
            b.ins()
                .jump(advance, &[p[0].into(), p[1].into(), zero.into()]);
            b.switch_to_block(advance);
            let p = b.block_params(advance).to_vec();
            let more = b.ins().icmp(IntCC::UnsignedLessThan, p[0], len);
            b.ins().brif(
                more,
                loop_block,
                &[p[0].into(), p[1].into(), p[2].into()],
                exit,
                &[],
            );
            b.switch_to_block(exit);
            b.ins().return_(&[]);
            b.seal_all_blocks();
            b.finalize();
            module
                .define_function(id, &mut ctx)
                .map_err(|e| e.to_string())?;
            kernels.insert((bits, width), id);
        }
        let mut ctx = module.make_context();
        ctx.func.signature.params.push(AbiParam::new(ptr));
        let entry_id = module
            .declare_function("mech_sequence_entry", Linkage::Export, &ctx.func.signature)
            .map_err(|e| e.to_string())?;
        let dispatch_ref = module.declare_func_in_func(dispatch, &mut ctx.func);
        let refs: BTreeMap<_, _> = kernels
            .iter()
            .map(|(shape, id)| (*shape, module.declare_func_in_func(*id, &mut ctx.func)))
            .collect();
        let mut fbctx = FunctionBuilderContext::new();
        let mut b = FunctionBuilder::new(&mut ctx.func, &mut fbctx);
        let block = b.create_block();
        b.append_block_params_for_function_params(block);
        b.switch_to_block(block);
        let context = b.block_params(block)[0];
        let mut last_use = BTreeMap::new();
        let mut uses = BTreeMap::<usize, usize>::new();
        for (index, node) in self.nodes.iter().enumerate() {
            for &arg in &node.args {
                last_use.insert(arg, index);
                *uses.entry(arg).or_default() += 1;
            }
        }
        // Fuse a single-consumer record extraction with stdin reading. Keep
        // handle allocation order and drain stdin to preserve IO effect order.
        let mut fused = BTreeMap::new();
        for (index, node) in self.nodes.iter().enumerate() {
            if node.op == 2 && uses.get(&node.args[0]) == Some(&1) {
                if let Some(read_index) = node.args[0].checked_sub(self.constants.len()) {
                    if self.nodes.get(read_index).is_some_and(|n| n.op == 1) {
                        fused.insert(read_index, 11);
                        fused.insert(index, 10);
                    }
                }
            }
        }
        for (index, node) in self.nodes.iter().enumerate() {
            let op = fused.get(&index).copied().unwrap_or(node.op);
            let mut args = vec![context, b.ins().iconst(ptr, op as i64)];
            for i in 0..5 {
                args.push(
                    b.ins()
                        .iconst(ptr, node.args.get(i).copied().unwrap_or(0) as i64),
                );
            }
            let kernel = if let Some(shape) = node.kernel {
                b.ins().func_addr(ptr, refs[&shape])
            } else {
                b.ins().iconst(ptr, 0)
            };
            args.push(kernel);
            b.ins().call(dispatch_ref, &args);
            // Release dead intermediates without changing the stable handle IDs.
            let releases: Vec<_> = node
                .args
                .iter()
                .copied()
                .filter(|id| last_use.get(id) == Some(&index))
                .collect();
            for id in releases
                .into_iter()
                .collect::<std::collections::BTreeSet<_>>()
            {
                let nine = b.ins().iconst(ptr, 9);
                let handle = b.ins().iconst(ptr, id as i64);
                let zero = b.ins().iconst(ptr, 0);
                b.ins().call(
                    dispatch_ref,
                    &[context, nine, handle, zero, zero, zero, zero, zero],
                );
            }
        }
        b.ins().return_(&[]);
        b.seal_all_blocks();
        b.finalize();
        module
            .define_function(entry_id, &mut ctx)
            .map_err(|e| e.to_string())?;
        module.finish().emit().map_err(|e| e.to_string())
    }
}
