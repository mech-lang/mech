//! Experimental typed collection AOT backend for the v0.4 canonical syntax.
//!
//! Source expressions become native calls; packed-window traversal is emitted
//! by Cranelift. Byte storage, IO, formatting and hashbrown are library services.
//! This is a separate admitted subset, not the general resident artifact path.
mod compiler;
mod counts;
mod runtime;
pub use compiler::{Constant, Program, compile};
pub use runtime::{Context, NativeEntry};
