//! CLI/energy adapter for the experimental compiled Mech n-body paths.
//! JIT source-size measurements include this file in full.
use mech_core::{CellSlotId, ReactiveInstanceId};
use mech_engine::__resident::{ActivationFacts, ReactiveInstance, ResidentValueBorrow, activate};
use mech_engine::SlotRole;
use mech_gpu::fused_f64::{FusedProgram, JitKernel};
use mech_runtime::RuntimeBuilder;
use std::{collections::BTreeMap, fmt::Write, time::Instant};

fn values(instance: &ReactiveInstance, slot: CellSlotId) -> &[f64] {
    let ResidentValueBorrow::F64 { values, .. } = instance.state_borrow(slot).unwrap() else {
        panic!("expected f64 state")
    };
    values
}

fn energy(x: &[f64], v: &[f64]) -> f64 {
    let solar = 4.0 * std::f64::consts::PI * std::f64::consts::PI;
    let m = [
        solar,
        0.000954791938424326609 * solar,
        0.000285885980666130812 * solar,
        0.0000436624404335156298 * solar,
        0.0000515138902046611451 * solar,
    ];
    let mut e = 0.0;
    for i in 0..5 {
        e += 0.5 * m[i] * (0..3).map(|axis| v[i + 5 * axis].powi(2)).sum::<f64>();
        for j in i + 1..5 {
            let d2 = (0..3)
                .map(|axis| (x[i + 5 * axis] - x[j + 5 * axis]).powi(2))
                .sum::<f64>();
            e -= m[i] * m[j] / d2.sqrt();
        }
    }
    e
}

fn main() {
    let start = Instant::now();
    let mut args = std::env::args().skip(1);
    let n: usize = args.next().expect("step count").parse().unwrap();
    let source = std::fs::read_to_string(args.next().expect("Mech source path")).unwrap();
    let mode = args.next().unwrap_or_else(|| "jit".into());
    let catalog = mech_stdlib::source_catalog();
    let (artifact, _) = RuntimeBuilder::new()
        .function_catalog(catalog.clone())
        .build_compiler()
        .expect("build compiler")
        .compile_source(&source)
        .expect("compile source")
        .into_parts();
    let states = artifact
        .slots()
        .iter()
        .filter(|slot| slot.role == SlotRole::State)
        .map(|slot| slot.slot)
        .collect::<Vec<_>>();
    assert_eq!(states.len(), 2);
    let mut instance = activate(
        ReactiveInstanceId::new(500, 0),
        &artifact,
        &catalog,
        &ActivationFacts::default(),
    )
    .expect("activate source");
    // Identify the position state by the Sun's initial (0, 0, 0), independent
    // of compiler slot ordering and output-projection storage.
    let x = states
        .iter()
        .copied()
        .find(|slot| (0..3).all(|axis| values(&instance, *slot)[5 * axis] == 0.0))
        .expect("position state");
    let v = states.into_iter().find(|slot| *slot != x).unwrap();
    if mode == "resident" {
        println!("{:.9}", energy(values(&instance, x), values(&instance, v)));
        let prepared = Instant::now();
        for _ in 0..n {
            instance.turn_without_summary(&[]).expect("advance");
        }
        println!("{:.9}", energy(values(&instance, x), values(&instance, v)));
        diagnostic(
            values(&instance, x),
            values(&instance, v),
            prepared.duration_since(start).as_secs_f64(),
            prepared.elapsed().as_secs_f64(),
        );
        return;
    }
    let initial = artifact
        .slots()
        .iter()
        .filter(|slot| slot.role == SlotRole::State)
        .map(|slot| (slot.slot, values(&instance, slot.slot).to_vec()))
        .collect::<BTreeMap<_, _>>();
    let program = FusedProgram::lower(&artifact, &initial).expect("lower fixed-shape f64 artifact");
    let x_offset = program
        .states
        .iter()
        .find(|(slot, _, _)| *slot == x)
        .unwrap()
        .1;
    let v_offset = program
        .states
        .iter()
        .find(|(slot, _, _)| *slot == v)
        .unwrap()
        .1;
    if mode == "emit-c" || mode == "emit-cranelift" || mode == "emit-cranelift-simd" {
        let path = args.next().expect("generated C path");
        let mut code = if mode == "emit-c" {
            program.c_kernel()
        } else {
            let object = args.next().expect("native object path");
            std::fs::write(
                object,
                (if mode.ends_with("-simd") {
                    program.aot_object_simd()
                } else {
                    program.aot_object()
                })
                .expect("emit Cranelift object"),
            )
            .expect("write native object");
            String::from(
                "#include <stddef.h>\n#include <math.h>\nvoid mech_turns(double *state, size_t turns);\ndouble mech_fused_pow(double x, double y) { return pow(x,y); }\n",
            )
        };
        writeln!(
            code,
            "#define X_OFFSET {x_offset}\n#define V_OFFSET {v_offset}"
        )
        .unwrap();
        writeln!(
            code,
            "static const double initial[{}] = {{",
            program.initial.len()
        )
        .unwrap();
        for value in &program.initial {
            writeln!(code, "{value:.17e},").unwrap();
        }
        code.push_str("};\n");
        code.push_str(include_str!("../../native-main.c"));
        std::fs::write(path, code).expect("write C artifact");
        return;
    }
    assert!(
        mode == "jit" || mode == "jit-simd",
        "execution mode must be resident, jit[-simd], emit-c, or emit-cranelift[-simd]"
    );
    let kernel =
        JitKernel::compile_with_simd(&program, mode == "jit-simd").expect("compile fused JIT loop");
    let mut state = program.initial.clone();
    println!(
        "{:.9}",
        energy(
            &state[x_offset..x_offset + 15],
            &state[v_offset..v_offset + 15]
        )
    );
    let prepared = Instant::now();
    kernel.run(&mut state, n);
    println!(
        "{:.9}",
        energy(
            &state[x_offset..x_offset + 15],
            &state[v_offset..v_offset + 15]
        )
    );
    diagnostic(
        &state[x_offset..x_offset + 15],
        &state[v_offset..v_offset + 15],
        prepared.duration_since(start).as_secs_f64(),
        prepared.elapsed().as_secs_f64(),
    );
}

fn diagnostic(x: &[f64], v: &[f64], prepare: f64, run: f64) {
    if std::env::var_os("MECH_DUMP_STATE").is_some() {
        eprintln!("STATE {:?}", [x, v].concat());
    }
    if std::env::var_os("MECH_TIMINGS").is_some() {
        eprintln!("TIMING {{\"prepare_seconds\":{prepare},\"kernel_seconds\":{run}}}");
    }
}
