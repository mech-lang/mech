//! Experimental fixed-shape f64 backend for the CLBG study.
//! Lowers canonical artifacts, never recognizes n-body source or body counts.
//! Pure arithmetic, static selectors and indexed updates only; other programs
//! are rejected. Resident activation supplies the authoritative initial state.
use std::collections::{BTreeMap, BTreeSet};
use std::fmt::Write;

use mech_core::snapshot::{SequenceView, ValueData};
use mech_core::{CellSlotId, DimensionExpr, FloatWidth, SchemaBody, SchemaId};
use mech_engine::{ArtifactSource, BindingDeclaration, ProgramArtifact, SlotRole};

mod native;
pub use native::JitKernel;

#[derive(Clone, Copy, Debug)]
enum Operand {
    Constant(f64),
    Register(usize),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Op {
    Add,
    Sub,
    Mul,
    Div,
    Pow,
    Sqrt,
    Neg,
}

#[derive(Clone, Debug)]
struct Instruction {
    op: Op,
    inputs: Vec<Operand>,
}

#[derive(Clone)]
struct Tensor {
    rows: usize,
    columns: usize,
    values: Vec<Operand>,
}

impl Tensor {
    fn at(&self, row: usize, column: usize) -> Operand {
        self.values[row + self.rows * column]
    }
    fn broadcast(&self, row: usize, column: usize) -> Operand {
        self.at(
            if self.rows == 1 { 0 } else { row },
            if self.columns == 1 { 0 } else { column },
        )
    }
    fn indices(&self, bound: usize) -> Result<Vec<usize>, String> {
        self.values
            .iter()
            .map(|operand| match operand {
                Operand::Constant(x)
                    if x.is_finite() && *x >= 1.0 && x.fract() == 0.0 && *x <= bound as f64 =>
                {
                    Ok(*x as usize - 1)
                }
                _ => Err(
                    "selector must contain constant, in-bounds, one-based integer positions".into(),
                ),
            })
            .collect()
    }
}

pub struct FusedProgram {
    pub states: Vec<(CellSlotId, usize, usize)>,
    pub initial: Vec<f64>,
    instructions: Vec<Instruction>,
    updates: Vec<Operand>,
    simd_pairs: BTreeSet<usize>,
    state_shapes: Vec<(usize, usize)>,
}

impl FusedProgram {
    /// Emit a native object from the same Cranelift IR used by the JIT.
    pub fn aot_object(&self) -> Result<Vec<u8>, String> {
        native::compile_object(self, false)
    }

    pub fn aot_object_simd(&self) -> Result<Vec<u8>, String> {
        native::compile_object(self, true)
    }

    pub fn lower(
        artifact: &ProgramArtifact,
        initial: &BTreeMap<CellSlotId, Vec<f64>>,
    ) -> Result<Self, String> {
        if !artifact.inputs().is_empty()
            || !artifact.constraints().is_empty()
            || !artifact.requirements().is_empty()
        {
            return Err("fused experiment requires a pure, autonomous program without integrity constraints".into());
        }
        let mut program = Self {
            states: Vec::new(),
            initial: Vec::new(),
            instructions: Vec::new(),
            updates: Vec::new(),
            simd_pairs: BTreeSet::new(),
            state_shapes: Vec::new(),
        };
        let mut slots = BTreeMap::new();
        for slot in artifact
            .slots()
            .iter()
            .filter(|slot| slot.role == SlotRole::State)
        {
            let (rows, columns) = shape(artifact, slot.schema)?;
            program.state_shapes.push((rows, columns));
            let values = initial
                .get(&slot.slot)
                .ok_or("missing authoritative initial state")?;
            if values.len() != rows * columns {
                return Err("state shape mismatch".into());
            }
            let offset = program.initial.len();
            program.states.push((slot.slot, offset, values.len()));
            program.initial.extend(values);
            slots.insert(
                slot.slot,
                Tensor {
                    rows,
                    columns,
                    values: (offset..offset + values.len())
                        .map(Operand::Register)
                        .collect(),
                },
            );
        }
        let constants = |source: ArtifactSource,
                         slots: &BTreeMap<CellSlotId, Tensor>|
         -> Result<Tensor, String> {
            match source {
                ArtifactSource::Slot(slot) => slots
                    .get(&slot)
                    .cloned()
                    .ok_or_else(|| format!("slot {} is unavailable", slot.get())),
                ArtifactSource::Constant(id) => {
                    let value = artifact.constants().get(id).ok_or("missing constant")?;
                    let (rows, columns) = shape(artifact, value.schema())?;
                    let row_major = match value.data() {
                        ValueData::F64(x) => vec![x.to_f64()],
                        ValueData::Matrix(matrix) => match matrix.elements() {
                            SequenceView::F64(xs) => xs.iter().map(|x| x.to_f64()).collect(),
                            _ => return Err("only f64 constants are admitted".into()),
                        },
                        _ => return Err("only f64 constants are admitted".into()),
                    };
                    let mut values = Vec::with_capacity(rows * columns);
                    for column in 0..columns {
                        for row in 0..rows {
                            values.push(Operand::Constant(row_major[row * columns + column]));
                        }
                    }
                    Ok(Tensor {
                        rows,
                        columns,
                        values,
                    })
                }
            }
        };
        let mut updates = BTreeMap::new();
        for declaration in artifact.nodes() {
            let node = declaration
                .as_operation()
                .ok_or("control nodes require resident execution")?;
            let name = node.operation.canonical_name();
            let inputs = node
                .input_bindings
                .clone()
                .map(|index| match artifact.bindings()[index as usize] {
                    BindingDeclaration::Input { source, .. } => constants(source, &slots),
                    _ => Err("invalid input binding".into()),
                })
                .collect::<Result<Vec<_>, _>>()?;
            let outputs = node
                .output_bindings
                .clone()
                .map(|index| match artifact.bindings()[index as usize] {
                    BindingDeclaration::Output { target, .. } => Ok(target),
                    _ => Err("invalid output binding".into()),
                })
                .collect::<Result<Vec<_>, String>>()?;
            if outputs.len() != 1 {
                return Err(format!("{name}: expected one output"));
            }
            let target = outputs[0];
            let result = program
                .operation(&name, &inputs)
                .map_err(|error| format!("node {} {name}: {error}", node.node.get()))?;
            if artifact.slots()[target.get() as usize].role == SlotRole::State {
                if name != "core/assign" {
                    return Err("state writes must be whole-value commits".into());
                }
                if updates.insert(target, result).is_some() {
                    return Err("multiple state commits".into());
                }
            } else {
                slots.insert(target, result);
            }
        }
        for (slot, _, len) in &program.states {
            let update = updates.remove(slot).ok_or("state has no next value")?;
            if update.values.len() != *len {
                return Err("state update shape mismatch".into());
            }
            program.updates.extend(update.values);
        }
        Ok(program)
    }

    fn emit(&mut self, op: Op, inputs: Vec<Operand>) -> Operand {
        let constants = inputs
            .iter()
            .map(|operand| match operand {
                Operand::Constant(x) => Some(*x),
                _ => None,
            })
            .collect::<Option<Vec<_>>>();
        if let Some(xs) = constants {
            return Operand::Constant(match op {
                Op::Add => xs[0] + xs[1],
                Op::Sub => xs[0] - xs[1],
                Op::Mul => xs[0] * xs[1],
                Op::Div => xs[0] / xs[1],
                Op::Pow => xs[0].powf(xs[1]),
                Op::Sqrt => xs[0].sqrt(),
                Op::Neg => -xs[0],
            });
        }
        // Preserve arithmetic order; do not enable reassociation or FMA.
        if matches!(op, Op::Pow)
            && let Operand::Constant(exponent) = inputs[1]
        {
            if exponent == 2.0 {
                return self.emit(Op::Mul, vec![inputs[0], inputs[0]]);
            }
            // Only reduce half powers when a nonnegative expression proves
            // sqrt's domain, including its zero sign, matches powf.
            if exponent == 0.5 && self.nonnegative(inputs[0]) {
                return self.emit(Op::Sqrt, vec![inputs[0]]);
            }
        }
        let result = Operand::Register(self.initial.len() + self.instructions.len());
        self.instructions.push(Instruction { op, inputs });
        result
    }

    fn nonnegative(&self, operand: Operand) -> bool {
        match operand {
            Operand::Constant(x) => x >= 0.0 && !x.is_sign_negative(),
            Operand::Register(index) if index >= self.initial.len() => {
                let instruction = &self.instructions[index - self.initial.len()];
                match instruction.op {
                    Op::Mul => {
                        matches!((instruction.inputs[0], instruction.inputs[1]), (Operand::Register(a), Operand::Register(b)) if a == b)
                    }
                    Op::Add => instruction.inputs.iter().all(|x| self.nonnegative(*x)),
                    _ => false,
                }
            }
            _ => false,
        }
    }

    fn mark_simd_pairs(&mut self, values: &[Operand]) {
        for pair in values.chunks_exact(2) {
            let [Operand::Register(first), Operand::Register(second)] = pair else {
                continue;
            };
            if *first < self.initial.len() || *second != first + 1 {
                continue;
            }
            let index = first - self.initial.len();
            let a = &self.instructions[index];
            let b = &self.instructions[index + 1];
            if a.op == b.op
                && a.op != Op::Pow
                && !b
                    .inputs
                    .iter()
                    .any(|x| matches!(x, Operand::Register(r) if r == first))
            {
                self.simd_pairs.insert(index);
            }
        }
    }

    fn operation(&mut self, name: &str, inputs: &[Tensor]) -> Result<Tensor, String> {
        match name {
            "core/assign" if inputs.len() == 1 => Ok(inputs[0].clone()),
            "math/neg" if inputs.len() == 1 => {
                let mut out = inputs[0].clone();
                for group in element_groups(out.rows, out.columns) {
                    let values = group
                        .iter()
                        .map(|i| {
                            out.values[*i] = self.emit(Op::Neg, vec![inputs[0].values[*i]]);
                            out.values[*i]
                        })
                        .collect::<Vec<_>>();
                    self.mark_simd_pairs(&values);
                }
                Ok(out)
            }
            "math/add" | "math/sub" | "math/mul" | "math/div" | "math/pow" if inputs.len() == 2 => {
                let op = match name {
                    "math/add" => Op::Add,
                    "math/sub" => Op::Sub,
                    "math/mul" => Op::Mul,
                    "math/div" => Op::Div,
                    _ => Op::Pow,
                };
                let a = &inputs[0];
                let b = &inputs[1];
                let rows = a.rows.max(b.rows);
                let columns = a.columns.max(b.columns);
                if ![a, b].iter().all(|x| {
                    (x.rows == 1 || x.rows == rows) && (x.columns == 1 || x.columns == columns)
                }) {
                    return Err("incompatible broadcasting shapes".into());
                }
                let mut values = vec![Operand::Constant(0.0); rows * columns];
                for group in element_groups(rows, columns) {
                    let group_values = group
                        .iter()
                        .map(|index| {
                            let row = index % rows;
                            let column = index / rows;
                            values[*index] = self
                                .emit(op, vec![a.broadcast(row, column), b.broadcast(row, column)]);
                            values[*index]
                        })
                        .collect::<Vec<_>>();
                    self.mark_simd_pairs(&group_values);
                }
                Ok(Tensor {
                    rows,
                    columns,
                    values,
                })
            }
            "stats/sum/row" | "stats/sum/column" if inputs.len() == 1 => {
                let source = &inputs[0];
                let (rows, columns) = if name.ends_with("/row") {
                    (1, source.columns)
                } else {
                    (source.rows, 1)
                };
                let across_rows = name.ends_with("/row");
                let terms = if across_rows {
                    source.rows
                } else {
                    source.columns
                };
                let mut values = vec![Operand::Constant(0.0); rows * columns];
                // Interleave independent reductions, preserving the summand
                // order within each output. Matching elements remain in the
                // same SIMD lanes for every stage of the reduction.
                for term in 0..terms {
                    for column in 0..columns {
                        for row in 0..rows {
                            let index = row + rows * column;
                            let input = if across_rows {
                                source.at(term, column)
                            } else {
                                source.at(row, term)
                            };
                            values[index] = self.emit(Op::Add, vec![values[index], input]);
                        }
                    }
                    self.mark_simd_pairs(&values);
                }
                Ok(Tensor {
                    rows,
                    columns,
                    values,
                })
            }
            "matrix/horzcat" | "matrix/vertcat" if !inputs.is_empty() => {
                let horizontal = name.ends_with("horzcat");
                let rows = if horizontal {
                    inputs[0].rows
                } else {
                    inputs.iter().map(|x| x.rows).sum()
                };
                let columns = if horizontal {
                    inputs.iter().map(|x| x.columns).sum()
                } else {
                    inputs[0].columns
                };
                if inputs.iter().any(|x| {
                    if horizontal {
                        x.rows != rows
                    } else {
                        x.columns != columns
                    }
                }) {
                    return Err("concatenation shape mismatch".into());
                }
                let mut values = Vec::new();
                if horizontal {
                    for input in inputs {
                        values.extend(&input.values);
                    }
                } else {
                    for column in 0..columns {
                        for input in inputs {
                            for row in 0..input.rows {
                                values.push(input.at(row, column));
                            }
                        }
                    }
                }
                Ok(Tensor {
                    rows,
                    columns,
                    values,
                })
            }
            "range/inclusive" if inputs.len() == 2 => {
                let start = scalar_constant(&inputs[0])?;
                let end = scalar_constant(&inputs[1])?;
                if start.fract() != 0.0
                    || end.fract() != 0.0
                    || start < 1.0
                    || end < start
                    || end - start > 4096.0
                {
                    return Err("unsupported static range".into());
                }
                let values = (start as usize..=end as usize)
                    .map(|x| Operand::Constant(x as f64))
                    .collect::<Vec<_>>();
                Ok(Tensor {
                    rows: values.len(),
                    columns: 1,
                    values,
                })
            }
            "combinatorics/n-choose-k" if inputs.len() == 2 => {
                let k = scalar_constant(&inputs[1])?;
                if k != 2.0 || inputs[0].values.len() > 64 {
                    return Err("experimental combinations support only static k=2".into());
                }
                let mut values = Vec::new();
                for i in 0..inputs[0].values.len() {
                    for j in i + 1..inputs[0].values.len() {
                        values.extend([inputs[0].values[i], inputs[0].values[j]]);
                    }
                }
                Ok(Tensor {
                    rows: 2,
                    columns: values.len() / 2,
                    values,
                })
            }
            "access/rows" | "access/range" if inputs.len() == 2 => {
                let source = &inputs[0];
                if name.ends_with("rows") {
                    let indices = inputs[1].indices(source.rows)?;
                    let values = (0..source.columns)
                        .flat_map(|column| indices.iter().map(move |row| source.at(*row, column)))
                        .collect();
                    Ok(Tensor {
                        rows: indices.len(),
                        columns: source.columns,
                        values,
                    })
                } else {
                    let indices = inputs[1].indices(source.values.len())?;
                    Ok(Tensor {
                        rows: indices.len(),
                        columns: 1,
                        values: indices.iter().map(|index| source.values[*index]).collect(),
                    })
                }
            }
            "core/assign/indexed-rows/add" | "core/assign/indexed-rows/sub"
                if inputs.len() == 3 =>
            {
                let mut out = inputs[0].clone();
                let update = &inputs[1];
                let indices = inputs[2].indices(out.rows)?;
                if update.rows != indices.len() || update.columns != out.columns {
                    return Err("indexed update shape mismatch".into());
                }
                let op = if name.ends_with("add") {
                    Op::Add
                } else {
                    Op::Sub
                };
                // Repeated selectors accumulate in source order, exactly as
                // resident indexed arithmetic; they are not parallel stores.
                for (row, target) in indices.iter().enumerate() {
                    let mut group = Vec::new();
                    for column in 0..out.columns {
                        let index = target + out.rows * column;
                        out.values[index] =
                            self.emit(op, vec![out.values[index], update.at(row, column)]);
                        group.push(out.values[index]);
                    }
                    self.mark_simd_pairs(&group);
                }
                Ok(out)
            }
            _ => Err("operation is outside the experimental fused subset".into()),
        }
    }

    pub fn c_kernel(&self) -> String {
        let mut code = String::from(
            "#include <stddef.h>\n#include <math.h>\nvoid mech_turns(double *restrict state, size_t turns) {\n",
        );
        for index in 0..self.initial.len() {
            writeln!(code, "  double s{index} = state[{index}];").unwrap();
        }
        code.push_str("  for (size_t turn = 0; turn < turns; ++turn) {\n");
        let operand = |x| self.c_operand(x);
        for (index, instruction) in self.instructions.iter().enumerate() {
            let a = operand(instruction.inputs[0]);
            let expression = match instruction.op {
                Op::Neg => format!("(-{a})"),
                Op::Sqrt => format!("sqrt({a})"),
                Op::Pow => format!("pow({a}, {})", operand(instruction.inputs[1])),
                op => format!(
                    "({a} {} {})",
                    match op {
                        Op::Add => "+",
                        Op::Sub => "-",
                        Op::Mul => "*",
                        Op::Div => "/",
                        _ => unreachable!(),
                    },
                    operand(instruction.inputs[1])
                ),
            };
            writeln!(code, "    const double r{index} = {expression};").unwrap();
        }
        for (index, update) in self.updates.iter().enumerate() {
            writeln!(code, "    const double next{index} = {};", operand(*update)).unwrap();
        }
        for index in 0..self.initial.len() {
            writeln!(code, "    s{index} = next{index};").unwrap();
        }
        code.push_str("  }\n");
        for index in 0..self.initial.len() {
            writeln!(code, "  state[{index}] = s{index};").unwrap();
        }
        code.push_str("}\n");
        code
    }

    fn c_operand(&self, operand: Operand) -> String {
        match operand {
            Operand::Constant(x) if x.is_nan() => "NAN".into(),
            Operand::Constant(x) if x == f64::INFINITY => "INFINITY".into(),
            Operand::Constant(x) if x == f64::NEG_INFINITY => "(-INFINITY)".into(),
            Operand::Constant(x) => format!("{x:.17e}"),
            Operand::Register(index) if index < self.initial.len() => format!("s{index}"),
            Operand::Register(index) => format!("r{}", index - self.initial.len()),
        }
    }
}

fn element_groups(rows: usize, columns: usize) -> Vec<Vec<usize>> {
    if columns == 1 {
        return vec![(0..rows).collect()];
    }
    (0..rows)
        .map(|row| (0..columns).map(|column| row + rows * column).collect())
        .collect()
}

fn scalar_constant(tensor: &Tensor) -> Result<f64, String> {
    match tensor.values.as_slice() {
        [Operand::Constant(x)] if x.is_finite() => Ok(*x),
        _ => Err("expected a finite static scalar".into()),
    }
}

fn shape(artifact: &ProgramArtifact, id: SchemaId) -> Result<(usize, usize), String> {
    match artifact.schemas().get(id).ok_or("missing schema")?.body() {
        SchemaBody::FloatingPoint(FloatWidth::W64) => Ok((1, 1)),
        SchemaBody::Matrix {
            element,
            dimensions,
        } if matches!(element.as_ref(), SchemaBody::FloatingPoint(FloatWidth::W64)) => {
            let dimensions = dimensions
                .iter()
                .map(|x| match x {
                    DimensionExpr::Constant(n) => {
                        usize::try_from(*n).map_err(|_| "oversized shape".into())
                    }
                    _ => Err("dynamic shapes are unsupported".into()),
                })
                .collect::<Result<Vec<_>, String>>()?;
            if dimensions.is_empty()
                || dimensions.len() > 2
                || dimensions.contains(&0)
                || dimensions.iter().any(|n| *n > 4096)
                || dimensions.iter().product::<usize>() > 4096
            {
                return Err("unsupported shape".into());
            }
            Ok((dimensions[0], dimensions.get(1).copied().unwrap_or(1)))
        }
        _ => Err("only fixed-shape f64 data is admitted".into()),
    }
}
