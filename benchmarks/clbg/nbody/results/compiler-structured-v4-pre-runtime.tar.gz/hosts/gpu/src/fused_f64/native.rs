use super::{FusedProgram, Op, Operand, element_groups};
use cranelift_codegen::ir::{
    AbiParam, ConstantData, Endianness, InstBuilder, MemFlags, Value, condcodes::IntCC, types,
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{FuncId, Linkage, Module, default_libcall_names};
use std::collections::BTreeMap;

type NativeLoop = unsafe extern "C" fn(*mut f64, usize);
pub struct JitKernel {
    _module: JITModule,
    run: NativeLoop,
    state_len: usize,
}

extern "C" fn mech_fused_pow(x: f64, y: f64) -> f64 {
    x.powf(y)
}

impl JitKernel {
    pub fn compile(program: &FusedProgram) -> Result<Self, String> {
        Self::compile_with_simd(program, false)
    }

    pub fn compile_with_simd(program: &FusedProgram, simd: bool) -> Result<Self, String> {
        let mut jit = JITBuilder::with_flags(&[("opt_level", "speed")], default_libcall_names())
            .map_err(error)?;
        jit.symbol("mech_fused_pow", mech_fused_pow as *const u8);
        let mut module = JITModule::new(jit);
        let function = define_program(program, &mut module, simd)?;
        module.finalize_definitions().map_err(error)?;
        let address = module.get_finalized_function(function);
        // SAFETY: The compiled signature is exactly NativeLoop; the owning
        // JITModule is retained for every invocation of its executable memory.
        let run = unsafe { std::mem::transmute::<*const u8, NativeLoop>(address) };
        Ok(Self {
            _module: module,
            run,
            state_len: program.initial.len(),
        })
    }

    pub fn run(&self, state: &mut [f64], turns: usize) {
        assert_eq!(state.len(), self.state_len);
        // SAFETY: The slice has the admitted size, is exclusively borrowed,
        // and generated accesses use only constant indices within that size.
        unsafe { (self.run)(state.as_mut_ptr(), turns) };
    }
}

fn value(operand: Operand, registers: &[Value], builder: &mut FunctionBuilder<'_>) -> Value {
    match operand {
        Operand::Constant(x) => builder.ins().f64const(x),
        Operand::Register(index) => registers[index],
    }
}

type PackedValues = BTreeMap<((u8, u64), (u8, u64)), Value>;
type LaneOrigins = BTreeMap<usize, (Value, u8)>;

fn shuffle_pair(a: (Value, u8), b: (Value, u8), builder: &mut FunctionBuilder<'_>) -> Value {
    if a.0 == b.0 && a.1 == 0 && b.1 == 1 {
        return a.0;
    }
    let mask = (a.1 * 8..a.1 * 8 + 8)
        .chain(16 + b.1 * 8..16 + b.1 * 8 + 8)
        .collect::<Vec<_>>();
    let mask = builder.func.dfg.immediates.push(ConstantData::from(mask));
    let flags = MemFlags::new().with_endianness(Endianness::Little);
    let a = builder.ins().bitcast(types::I8X16, flags, a.0);
    let b = builder.ins().bitcast(types::I8X16, flags, b.0);
    let vector = builder.ins().shuffle(a, b, mask);
    builder.ins().bitcast(types::F64X2, flags, vector)
}

fn packed_pair(
    first: Operand,
    second: Operand,
    registers: &[Value],
    packed: &mut PackedValues,
    origins: &LaneOrigins,
    builder: &mut FunctionBuilder<'_>,
) -> Value {
    let key = (operand_key(first), operand_key(second));
    if let Some(vector) = packed.get(&key) {
        return *vector;
    }
    let origin = |operand| match operand {
        Operand::Register(index) => origins.get(&index).copied(),
        Operand::Constant(_) => None,
    };
    let vector = if let (Operand::Constant(a), Operand::Constant(b)) = (first, second) {
        let bytes = a
            .to_bits()
            .to_le_bytes()
            .into_iter()
            .chain(b.to_bits().to_le_bytes())
            .collect::<Vec<_>>();
        let constant = builder.func.dfg.constants.insert(ConstantData::from(bytes));
        builder.ins().vconst(types::F64X2, constant)
    } else if let (Some(a), Some(b)) = (origin(first), origin(second)) {
        shuffle_pair(a, b, builder)
    } else if operand_key(first) == operand_key(second) {
        let scalar = value(first, registers, builder);
        builder.ins().splat(types::F64X2, scalar)
    } else {
        let first = value(first, registers, builder);
        let second = value(second, registers, builder);
        let vector = builder.ins().scalar_to_vector(types::F64X2, first);
        builder.ins().insertlane(vector, second, 1)
    };
    packed.insert(key, vector);
    vector
}

fn error(error: impl std::fmt::Display) -> String {
    error.to_string()
}

pub(super) fn compile_object(program: &FusedProgram, simd: bool) -> Result<Vec<u8>, String> {
    crate::batched::aot::emit_native_object("mech_fused_f64", |module| {
        define_program(program, module, simd).map_err(crate::BatchedExecutionError::Native)?;
        Ok(())
    })
    .map_err(error)
}

fn define_program<M: Module>(
    program: &FusedProgram,
    module: &mut M,
    simd: bool,
) -> Result<FuncId, String> {
    let pointer = module.target_config().pointer_type();
    let mut signature = module.make_signature();
    signature
        .params
        .extend([AbiParam::new(pointer), AbiParam::new(pointer)]);
    let function = module
        .declare_function("mech_turns", Linkage::Export, &signature)
        .map_err(error)?;
    let mut pow_signature = module.make_signature();
    pow_signature
        .params
        .extend([AbiParam::new(types::F64), AbiParam::new(types::F64)]);
    pow_signature.returns.push(AbiParam::new(types::F64));
    let pow = module
        .declare_function("mech_fused_pow", Linkage::Import, &pow_signature)
        .map_err(error)?;
    let mut context = module.make_context();
    context.func.signature = signature;
    let mut function_context = FunctionBuilderContext::new();
    {
        let mut builder = FunctionBuilder::new(&mut context.func, &mut function_context);
        let entry = builder.create_block();
        let header = builder.create_block();
        let body = builder.create_block();
        let exit = builder.create_block();
        builder.append_block_params_for_function_params(entry);
        builder.append_block_param(header, pointer);
        let state_groups = if simd {
            program
                .states
                .iter()
                .zip(&program.state_shapes)
                .flat_map(|((_, offset, _), (rows, columns))| {
                    element_groups(*rows, *columns)
                        .into_iter()
                        .flat_map(move |group| {
                            group
                                .chunks(2)
                                .map(|chunk| chunk.iter().map(|i| offset + i).collect::<Vec<_>>())
                                .collect::<Vec<_>>()
                        })
                })
                .collect::<Vec<_>>()
        } else {
            (0..program.initial.len()).map(|i| vec![i]).collect()
        };
        for chunk in &state_groups {
            builder.append_block_param(
                header,
                if chunk.len() == 2 {
                    types::F64X2
                } else {
                    types::F64
                },
            );
        }
        builder.switch_to_block(entry);
        let state = builder.block_params(entry)[0];
        let turns = builder.block_params(entry)[1];
        let mut initial = vec![turns];
        for chunk in &state_groups {
            let a = builder
                .ins()
                .load(types::F64, MemFlags::new(), state, (chunk[0] * 8) as i32);
            initial.push(if chunk.len() == 2 {
                let b =
                    builder
                        .ins()
                        .load(types::F64, MemFlags::new(), state, (chunk[1] * 8) as i32);
                let vector = builder.ins().scalar_to_vector(types::F64X2, a);
                builder.ins().insertlane(vector, b, 1)
            } else {
                a
            });
        }
        builder.ins().jump(
            header,
            &initial.iter().copied().map(Into::into).collect::<Vec<_>>(),
        );
        builder.seal_block(entry);
        builder.switch_to_block(header);
        let remaining = builder.block_params(header)[0];
        let states = builder.block_params(header)[1..].to_vec();
        let done = builder.ins().icmp_imm(IntCC::Equal, remaining, 0);
        builder.ins().brif(done, exit, &[], body, &[]);
        builder.switch_to_block(body);
        builder.seal_block(body);
        let pow_ref = module.declare_func_in_func(pow, builder.func);
        let mut registers = vec![remaining; program.initial.len()];
        let mut packed = BTreeMap::new();
        let mut origins = BTreeMap::new();
        for (state, chunk) in states.iter().zip(&state_groups) {
            if chunk.len() == 2 {
                registers[chunk[0]] = builder.ins().extractlane(*state, 0);
                registers[chunk[1]] = builder.ins().extractlane(*state, 1);
                origins.insert(chunk[0], (*state, 0));
                origins.insert(chunk[1], (*state, 1));
                packed.insert(
                    (
                        operand_key(Operand::Register(chunk[0])),
                        operand_key(Operand::Register(chunk[1])),
                    ),
                    *state,
                );
            } else {
                registers[chunk[0]] = *state;
            }
        }
        let mut index = 0;
        while index < program.instructions.len() {
            let instruction = &program.instructions[index];
            if simd
                && program.simd_pairs.contains(&index)
                && instruction.op != Op::Pow
                && let Some(second) = program.instructions.get(index + 1)
                && instruction.op == second.op
                && !second
                    .inputs
                    .iter()
                    .any(|x| matches!(x, Operand::Register(r) if *r == program.initial.len()+index))
            {
                let inputs = instruction
                    .inputs
                    .iter()
                    .zip(&second.inputs)
                    .map(|(a, b)| {
                        packed_pair(*a, *b, &registers, &mut packed, &origins, &mut builder)
                    })
                    .collect::<Vec<_>>();
                let vector = arithmetic(instruction.op, &inputs, &mut builder, pow_ref);
                let first_index = registers.len();
                registers.push(builder.ins().extractlane(vector, 0));
                registers.push(builder.ins().extractlane(vector, 1));
                origins.insert(first_index, (vector, 0));
                origins.insert(first_index + 1, (vector, 1));
                packed.insert(
                    (
                        operand_key(Operand::Register(first_index)),
                        operand_key(Operand::Register(first_index + 1)),
                    ),
                    vector,
                );
                index += 2;
                continue;
            }
            let inputs = instruction
                .inputs
                .iter()
                .map(|operand| value(*operand, &registers, &mut builder))
                .collect::<Vec<_>>();
            let result = arithmetic(instruction.op, &inputs, &mut builder, pow_ref);
            registers.push(result);
            index += 1;
        }
        let next_turns = builder.ins().iadd_imm(remaining, -1);
        let mut next = vec![next_turns];
        for chunk in &state_groups {
            next.push(if chunk.len() == 2 {
                packed_pair(
                    program.updates[chunk[0]],
                    program.updates[chunk[1]],
                    &registers,
                    &mut packed,
                    &origins,
                    &mut builder,
                )
            } else {
                value(program.updates[chunk[0]], &registers, &mut builder)
            });
        }
        builder.ins().jump(
            header,
            &next.iter().copied().map(Into::into).collect::<Vec<_>>(),
        );
        builder.seal_block(header);
        builder.switch_to_block(exit);
        builder.seal_block(exit);
        for (value, chunk) in states.iter().zip(&state_groups) {
            for (lane, index) in chunk.iter().enumerate() {
                let scalar = if chunk.len() == 2 {
                    builder.ins().extractlane(*value, lane as u8)
                } else {
                    *value
                };
                builder
                    .ins()
                    .store(MemFlags::new(), scalar, state, (index * 8) as i32);
            }
        }
        builder.ins().return_(&[]);
        builder.finalize();
    }
    module
        .define_function(function, &mut context)
        .map_err(|error| format!("{error:?}"))?;
    Ok(function)
}

fn operand_key(operand: Operand) -> (u8, u64) {
    match operand {
        Operand::Constant(x) => (0, x.to_bits()),
        Operand::Register(index) => (1, index as u64),
    }
}

fn arithmetic(
    op: Op,
    inputs: &[Value],
    builder: &mut FunctionBuilder<'_>,
    pow: cranelift_codegen::ir::FuncRef,
) -> Value {
    match op {
        Op::Add => builder.ins().fadd(inputs[0], inputs[1]),
        Op::Sub => builder.ins().fsub(inputs[0], inputs[1]),
        Op::Mul => builder.ins().fmul(inputs[0], inputs[1]),
        Op::Div => builder.ins().fdiv(inputs[0], inputs[1]),
        Op::Neg => builder.ins().fneg(inputs[0]),
        Op::Sqrt => builder.ins().sqrt(inputs[0]),
        Op::Pow => {
            let call = builder.ins().call(pow, inputs);
            builder.inst_results(call)[0]
        }
    }
}
