//! Executable adapter for the Mech n-body program. Included in full-program
//! source-size measurements because it supplies the CLI, loop, and energy.
use mech_core::{CellSlotId, ReactiveInstanceId};
use mech_engine::__resident::{ActivationFacts, ReactiveInstance, ResidentValueBorrow, activate};
use mech_engine::SlotRole;
use mech_runtime::RuntimeBuilder;

fn values(instance: &ReactiveInstance, slot: CellSlotId) -> &[f64] {
    let ResidentValueBorrow::F64 { values, .. } = instance.state_borrow(slot).unwrap() else {
        panic!("expected f64 state")
    };
    values
}

fn energy(instance: &ReactiveInstance, x: CellSlotId, v: CellSlotId) -> f64 {
    let x = values(instance, x);
    let v = values(instance, v);
    let solar = 4.0 * std::f64::consts::PI * std::f64::consts::PI;
    let m = [
        solar,
        0.000954791938424326609 * solar,
        0.000285885980666130812 * solar,
        0.0000436624404335156298 * solar,
        0.0000515138902046611451 * solar,
    ];
    let mut e = 0.0;
    for i in 0..5 {
        e += 0.5 * m[i] * (0..3).map(|axis| v[i + 5 * axis].powi(2)).sum::<f64>();
        for j in i + 1..5 {
            let d2 = (0..3)
                .map(|axis| (x[i + 5 * axis] - x[j + 5 * axis]).powi(2))
                .sum::<f64>();
            e -= m[i] * m[j] / d2.sqrt();
        }
    }
    e
}

fn main() {
    let mut args = std::env::args().skip(1);
    let n: usize = args.next().expect("step count").parse().unwrap();
    let source = std::fs::read_to_string(args.next().expect("Mech source path")).unwrap();
    let catalog = mech_stdlib::source_catalog();
    let (artifact, _) = RuntimeBuilder::new()
        .function_catalog(catalog.clone())
        .build_compiler()
        .expect("build compiler")
        .compile_source(&source)
        .expect("compile source")
        .into_parts();
    let states = artifact
        .slots()
        .iter()
        .filter(|slot| slot.role == SlotRole::State)
        .map(|slot| slot.slot)
        .collect::<Vec<_>>();
    assert_eq!(states.len(), 2);
    let mut instance = activate(
        ReactiveInstanceId::new(500, 0),
        &artifact,
        &catalog,
        &ActivationFacts::default(),
    )
    .expect("activate source");
    // Identify the position state by the Sun's initial (0, 0, 0), independent
    // of compiler slot ordering and output-projection storage.
    let x = states
        .iter()
        .copied()
        .find(|slot| (0..3).all(|axis| values(&instance, *slot)[5 * axis] == 0.0))
        .expect("position state");
    let v = states.into_iter().find(|slot| *slot != x).unwrap();
    println!("{:.9}", energy(&instance, x, v));
    for _ in 0..n {
        instance.turn_without_summary(&[]).expect("advance");
    }
    println!("{:.9}", energy(&instance, x, v));
}
