/* Authored CLI/energy adapter for generated Cranelift or LLVM AOT kernels. This file is
 * included in program-size measurements; generated compiler output is not. */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include <string.h>

static double energy(const double *x, const double *v) {
  const double solar = 4.0 * 3.141592653589793 * 3.141592653589793;
  const double m[] = { solar, 0.000954791938424326609 * solar,
    0.000285885980666130812 * solar, 0.0000436624404335156298 * solar,
    0.0000515138902046611451 * solar };
  double e = 0.0;
  for (size_t i = 0; i < 5; ++i) {
    double speed = 0.0;
    for (size_t a = 0; a < 3; ++a) speed += v[i+5*a] * v[i+5*a];
    e += 0.5 * m[i] * speed;
    for (size_t j = i+1; j < 5; ++j) {
      double d2 = 0.0;
      for (size_t a = 0; a < 3; ++a) {
        double d = x[i+5*a] - x[j+5*a]; d2 += d*d;
      }
      e -= m[i] * m[j] / sqrt(d2);
    }
  }
  return e;
}

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  errno = 0; char *end;
  unsigned long long turns = strtoull(argv[1], &end, 10);
  if (errno || *end || argv[1][0] == '-' || end == argv[1] || turns > (size_t)-1) return 2;
  double state[sizeof(initial) / sizeof(initial[0])];
  memcpy(state, initial, sizeof(state));
  printf("%.9f\n", energy(state+X_OFFSET, state+V_OFFSET));
  struct timespec start, finish;
  clock_gettime(CLOCK_MONOTONIC, &start);
  mech_turns(state, (size_t)turns);
  clock_gettime(CLOCK_MONOTONIC, &finish);
  printf("%.9f\n", energy(state+X_OFFSET, state+V_OFFSET));
  if (getenv("MECH_DUMP_STATE")) {
    fprintf(stderr, "STATE [");
    for (size_t i = 0; i < 30; ++i) fprintf(stderr, "%s%.17g", i ? ", " : "", state[(i < 15 ? X_OFFSET : V_OFFSET) + i%15]);
    fprintf(stderr, "]\n");
  }
  if (getenv("MECH_TIMINGS")) {
    double elapsed = finish.tv_sec-start.tv_sec + (finish.tv_nsec-start.tv_nsec)*1e-9;
    fprintf(stderr, "TIMING {\"prepare_seconds\":0,\"kernel_seconds\":%.9g}\n", elapsed);
  }
  return 0;
}
