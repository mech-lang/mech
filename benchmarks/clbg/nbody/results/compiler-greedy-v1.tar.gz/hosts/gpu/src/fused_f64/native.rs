use super::{FusedProgram, Op, Operand};
use cranelift_codegen::ir::{AbiParam, InstBuilder, MemFlags, Value, condcodes::IntCC, types};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{FuncId, Linkage, Module, default_libcall_names};
use std::collections::BTreeMap;

type NativeLoop = unsafe extern "C" fn(*mut f64, usize);
pub struct JitKernel {
    _module: JITModule,
    run: NativeLoop,
    state_len: usize,
}

extern "C" fn mech_fused_pow(x: f64, y: f64) -> f64 {
    x.powf(y)
}

impl JitKernel {
    pub fn compile(program: &FusedProgram) -> Result<Self, String> {
        Self::compile_with_simd(program, false)
    }

    pub fn compile_with_simd(program: &FusedProgram, simd: bool) -> Result<Self, String> {
        let mut jit = JITBuilder::with_flags(&[("opt_level", "speed")], default_libcall_names())
            .map_err(error)?;
        jit.symbol("mech_fused_pow", mech_fused_pow as *const u8);
        let mut module = JITModule::new(jit);
        let function = define_program(program, &mut module, simd)?;
        module.finalize_definitions().map_err(error)?;
        let address = module.get_finalized_function(function);
        // SAFETY: The compiled signature is exactly NativeLoop; the owning
        // JITModule is retained for every invocation of its executable memory.
        let run = unsafe { std::mem::transmute::<*const u8, NativeLoop>(address) };
        Ok(Self {
            _module: module,
            run,
            state_len: program.initial.len(),
        })
    }

    pub fn run(&self, state: &mut [f64], turns: usize) {
        assert_eq!(state.len(), self.state_len);
        // SAFETY: The slice has the admitted size, is exclusively borrowed,
        // and generated accesses use only constant indices within that size.
        unsafe { (self.run)(state.as_mut_ptr(), turns) };
    }
}

fn value(operand: Operand, registers: &[Value], builder: &mut FunctionBuilder<'_>) -> Value {
    match operand {
        Operand::Constant(x) => builder.ins().f64const(x),
        Operand::Register(index) => registers[index],
    }
}

type PackedValues = BTreeMap<((u8, u64), (u8, u64)), Value>;

fn packed_pair(
    first: Operand,
    second: Operand,
    registers: &[Value],
    packed: &mut PackedValues,
    builder: &mut FunctionBuilder<'_>,
) -> Value {
    let key = (operand_key(first), operand_key(second));
    if let Some(vector) = packed.get(&key) {
        return *vector;
    }
    let first = value(first, registers, builder);
    let second = value(second, registers, builder);
    let vector = builder.ins().scalar_to_vector(types::F64X2, first);
    let vector = builder.ins().insertlane(vector, second, 1);
    packed.insert(key, vector);
    vector
}

fn error(error: impl std::fmt::Display) -> String {
    error.to_string()
}

pub(super) fn compile_object(program: &FusedProgram, simd: bool) -> Result<Vec<u8>, String> {
    crate::batched::aot::emit_native_object("mech_fused_f64", |module| {
        define_program(program, module, simd).map_err(crate::BatchedExecutionError::Native)?;
        Ok(())
    })
    .map_err(error)
}

fn define_program<M: Module>(
    program: &FusedProgram,
    module: &mut M,
    simd: bool,
) -> Result<FuncId, String> {
    let pointer = module.target_config().pointer_type();
    let mut signature = module.make_signature();
    signature
        .params
        .extend([AbiParam::new(pointer), AbiParam::new(pointer)]);
    let function = module
        .declare_function("mech_turns", Linkage::Export, &signature)
        .map_err(error)?;
    let mut pow_signature = module.make_signature();
    pow_signature
        .params
        .extend([AbiParam::new(types::F64), AbiParam::new(types::F64)]);
    pow_signature.returns.push(AbiParam::new(types::F64));
    let pow = module
        .declare_function("mech_fused_pow", Linkage::Import, &pow_signature)
        .map_err(error)?;
    let mut context = module.make_context();
    context.func.signature = signature;
    let mut function_context = FunctionBuilderContext::new();
    {
        let mut builder = FunctionBuilder::new(&mut context.func, &mut function_context);
        let entry = builder.create_block();
        let header = builder.create_block();
        let body = builder.create_block();
        let exit = builder.create_block();
        builder.append_block_params_for_function_params(entry);
        builder.append_block_param(header, pointer);
        let state_width = if simd { 2 } else { 1 };
        for chunk in program.initial.chunks(state_width) {
            builder.append_block_param(
                header,
                if chunk.len() == 2 {
                    types::F64X2
                } else {
                    types::F64
                },
            );
        }
        builder.switch_to_block(entry);
        let state = builder.block_params(entry)[0];
        let turns = builder.block_params(entry)[1];
        let mut initial = vec![turns];
        for (index, chunk) in program.initial.chunks(state_width).enumerate() {
            initial.push(builder.ins().load(
                if chunk.len() == 2 {
                    types::F64X2
                } else {
                    types::F64
                },
                MemFlags::new(),
                state,
                (index * state_width * 8) as i32,
            ));
        }
        builder.ins().jump(
            header,
            &initial.iter().copied().map(Into::into).collect::<Vec<_>>(),
        );
        builder.seal_block(entry);
        builder.switch_to_block(header);
        let remaining = builder.block_params(header)[0];
        let states = builder.block_params(header)[1..].to_vec();
        let done = builder.ins().icmp_imm(IntCC::Equal, remaining, 0);
        builder.ins().brif(done, exit, &[], body, &[]);
        builder.switch_to_block(body);
        builder.seal_block(body);
        let pow_ref = module.declare_func_in_func(pow, builder.func);
        let mut registers = Vec::with_capacity(program.initial.len() + program.instructions.len());
        let mut packed = BTreeMap::new();
        for (state, chunk) in states.iter().zip(program.initial.chunks(state_width)) {
            if chunk.len() == 2 {
                let index = registers.len();
                registers.push(builder.ins().extractlane(*state, 0));
                registers.push(builder.ins().extractlane(*state, 1));
                packed.insert(
                    (
                        operand_key(Operand::Register(index)),
                        operand_key(Operand::Register(index + 1)),
                    ),
                    *state,
                );
            } else {
                registers.push(*state);
            }
        }
        let mut index = 0;
        while index < program.instructions.len() {
            let instruction = &program.instructions[index];
            if simd
                && instruction.op != Op::Pow
                && let Some(second) = program.instructions.get(index + 1)
                && instruction.op == second.op
                && !second
                    .inputs
                    .iter()
                    .any(|x| matches!(x, Operand::Register(r) if *r == program.initial.len()+index))
            {
                let inputs = instruction
                    .inputs
                    .iter()
                    .zip(&second.inputs)
                    .map(|(a, b)| packed_pair(*a, *b, &registers, &mut packed, &mut builder))
                    .collect::<Vec<_>>();
                let vector = arithmetic(instruction.op, &inputs, &mut builder, pow_ref);
                let first_index = registers.len();
                registers.push(builder.ins().extractlane(vector, 0));
                registers.push(builder.ins().extractlane(vector, 1));
                packed.insert(
                    (
                        operand_key(Operand::Register(first_index)),
                        operand_key(Operand::Register(first_index + 1)),
                    ),
                    vector,
                );
                index += 2;
                continue;
            }
            let inputs = instruction
                .inputs
                .iter()
                .map(|operand| value(*operand, &registers, &mut builder))
                .collect::<Vec<_>>();
            let result = arithmetic(instruction.op, &inputs, &mut builder, pow_ref);
            registers.push(result);
            index += 1;
        }
        let next_turns = builder.ins().iadd_imm(remaining, -1);
        let mut next = vec![next_turns];
        for updates in program.updates.chunks(state_width) {
            next.push(if updates.len() == 2 {
                packed_pair(
                    updates[0],
                    updates[1],
                    &registers,
                    &mut packed,
                    &mut builder,
                )
            } else {
                value(updates[0], &registers, &mut builder)
            });
        }
        builder.ins().jump(
            header,
            &next.iter().copied().map(Into::into).collect::<Vec<_>>(),
        );
        builder.seal_block(header);
        builder.switch_to_block(exit);
        builder.seal_block(exit);
        for (index, value) in states.iter().enumerate() {
            builder.ins().store(
                MemFlags::new(),
                *value,
                state,
                (index * state_width * 8) as i32,
            );
        }
        builder.ins().return_(&[]);
        builder.finalize();
    }
    module
        .define_function(function, &mut context)
        .map_err(error)?;
    Ok(function)
}

fn operand_key(operand: Operand) -> (u8, u64) {
    match operand {
        Operand::Constant(x) => (0, x.to_bits()),
        Operand::Register(index) => (1, index as u64),
    }
}

fn arithmetic(
    op: Op,
    inputs: &[Value],
    builder: &mut FunctionBuilder<'_>,
    pow: cranelift_codegen::ir::FuncRef,
) -> Value {
    match op {
        Op::Add => builder.ins().fadd(inputs[0], inputs[1]),
        Op::Sub => builder.ins().fsub(inputs[0], inputs[1]),
        Op::Mul => builder.ins().fmul(inputs[0], inputs[1]),
        Op::Div => builder.ins().fdiv(inputs[0], inputs[1]),
        Op::Neg => builder.ins().fneg(inputs[0]),
        Op::Sqrt => builder.ins().sqrt(inputs[0]),
        Op::Pow => {
            let call = builder.ins().call(pow, inputs);
            builder.inst_results(call)[0]
        }
    }
}
