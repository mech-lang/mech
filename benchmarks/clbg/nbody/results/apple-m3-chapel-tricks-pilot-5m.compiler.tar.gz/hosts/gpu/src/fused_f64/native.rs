use super::{FusedProgram, Op, Operand, element_groups};
use cranelift_codegen::ir::{
    AbiParam, ConstantData, Endianness, InstBuilder, MemFlags, Value, condcodes::IntCC, types,
};
use cranelift_frontend::{FunctionBuilder, FunctionBuilderContext};
use cranelift_jit::{JITBuilder, JITModule};
use cranelift_module::{FuncId, Linkage, Module, default_libcall_names};
use std::collections::BTreeMap;

type NativeLoop = unsafe extern "C" fn(*mut f64, usize);
type NativeObserve = unsafe extern "C" fn(*const f64, *mut f64);
pub struct JitKernel {
    _module: JITModule,
    run: NativeLoop,
    state_len: usize,
    output: Option<(NativeObserve, usize)>,
}

extern "C" fn mech_fused_pow(x: f64, y: f64) -> f64 {
    x.powf(y)
}

impl JitKernel {
    pub fn compile(program: &FusedProgram) -> Result<Self, String> {
        Self::compile_with_simd(program, false)
    }

    pub fn compile_with_simd(program: &FusedProgram, simd: bool) -> Result<Self, String> {
        Self::compile_internal(program, simd, None)
    }

    pub fn compile_with_output(
        program: &FusedProgram,
        output: &str,
        simd: bool,
    ) -> Result<Self, String> {
        Self::compile_internal(program, simd, Some(output))
    }

    fn compile_internal(
        program: &FusedProgram,
        simd: bool,
        output: Option<&str>,
    ) -> Result<Self, String> {
        let mut jit = JITBuilder::with_flags(&[("opt_level", "speed")], default_libcall_names())
            .map_err(error)?;
        jit.symbol("mech_fused_pow", mech_fused_pow as *const u8);
        let mut module = JITModule::new(jit);
        let function = define_program(program, &mut module, simd)?;
        let observation = output
            .map(|name| {
                Ok::<_, String>((
                    define_observer(program, &mut module, name)?,
                    program.output_len(name)?,
                ))
            })
            .transpose()?;
        module.finalize_definitions().map_err(error)?;
        let address = module.get_finalized_function(function);
        // SAFETY: The compiled signature is exactly NativeLoop; the owning
        // JITModule is retained for every invocation of its executable memory.
        let run = unsafe { std::mem::transmute::<*const u8, NativeLoop>(address) };
        let output = observation.map(|(function, len)| {
            let address = module.get_finalized_function(function);
            // SAFETY: define_observer emits exactly NativeObserve. The same
            // owning JITModule retains its executable memory for every call.
            let observe = unsafe { std::mem::transmute::<*const u8, NativeObserve>(address) };
            (observe, len)
        });
        Ok(Self {
            _module: module,
            run,
            state_len: program.initial.len(),
            output,
        })
    }

    pub fn run(&self, state: &mut [f64], turns: usize) {
        assert_eq!(state.len(), self.state_len);
        // SAFETY: The slice has the admitted size, is exclusively borrowed,
        // and generated accesses use only constant indices within that size.
        unsafe { (self.run)(state.as_mut_ptr(), turns) };
    }

    /// Evaluate the selected pure output from the current state without
    /// committing any state update or advancing the simulation.
    pub fn observe(&self, state: &[f64]) -> Result<Vec<f64>, String> {
        assert_eq!(state.len(), self.state_len);
        let (observe, len) = self.output.ok_or("kernel has no selected output")?;
        let mut output = vec![0.0; len];
        // SAFETY: Both slices have the admitted lengths, input is immutable,
        // output is exclusively borrowed, and generated offsets are bounded.
        unsafe { observe(state.as_ptr(), output.as_mut_ptr()) };
        Ok(output)
    }
}

fn value(operand: Operand, registers: &[Value], builder: &mut FunctionBuilder<'_>) -> Value {
    match operand {
        Operand::Constant(x) => builder.ins().f64const(x),
        Operand::Register(index) => registers[index],
    }
}

type PackedValues = BTreeMap<((u8, u64), (u8, u64)), Value>;
type LaneOrigins = BTreeMap<usize, (Value, u8)>;

fn shuffle_pair(a: (Value, u8), b: (Value, u8), builder: &mut FunctionBuilder<'_>) -> Value {
    if a.0 == b.0 && a.1 == 0 && b.1 == 1 {
        return a.0;
    }
    let mask = (a.1 * 8..a.1 * 8 + 8)
        .chain(16 + b.1 * 8..16 + b.1 * 8 + 8)
        .collect::<Vec<_>>();
    let mask = builder.func.dfg.immediates.push(ConstantData::from(mask));
    let flags = MemFlags::new().with_endianness(Endianness::Little);
    let a = builder.ins().bitcast(types::I8X16, flags, a.0);
    let b = builder.ins().bitcast(types::I8X16, flags, b.0);
    let vector = builder.ins().shuffle(a, b, mask);
    builder.ins().bitcast(types::F64X2, flags, vector)
}

fn packed_pair(
    first: Operand,
    second: Operand,
    registers: &[Value],
    packed: &mut PackedValues,
    origins: &LaneOrigins,
    builder: &mut FunctionBuilder<'_>,
) -> Value {
    let key = (operand_key(first), operand_key(second));
    if let Some(vector) = packed.get(&key) {
        return *vector;
    }
    let origin = |operand| match operand {
        Operand::Register(index) => origins.get(&index).copied(),
        Operand::Constant(_) => None,
    };
    let vector = if let (Operand::Constant(a), Operand::Constant(b)) = (first, second) {
        let bytes = a
            .to_bits()
            .to_le_bytes()
            .into_iter()
            .chain(b.to_bits().to_le_bytes())
            .collect::<Vec<_>>();
        let constant = builder.func.dfg.constants.insert(ConstantData::from(bytes));
        builder.ins().vconst(types::F64X2, constant)
    } else if let (Some(a), Some(b)) = (origin(first), origin(second)) {
        shuffle_pair(a, b, builder)
    } else if operand_key(first) == operand_key(second) {
        let scalar = value(first, registers, builder);
        builder.ins().splat(types::F64X2, scalar)
    } else {
        let first = value(first, registers, builder);
        let second = value(second, registers, builder);
        let vector = builder.ins().scalar_to_vector(types::F64X2, first);
        builder.ins().insertlane(vector, second, 1)
    };
    packed.insert(key, vector);
    vector
}

fn error(error: impl std::fmt::Display) -> String {
    error.to_string()
}

pub(super) fn compile_object(program: &FusedProgram, simd: bool) -> Result<Vec<u8>, String> {
    compile_object_with_output(program, simd, None)
}

pub(super) fn compile_object_with_output(
    program: &FusedProgram,
    simd: bool,
    output: Option<&str>,
) -> Result<Vec<u8>, String> {
    crate::batched::aot::emit_native_object("mech_fused_f64", |module| {
        define_program(program, module, simd).map_err(crate::BatchedExecutionError::Native)?;
        if let Some(output) = output {
            define_observer(program, module, output)
                .map_err(crate::BatchedExecutionError::Native)?;
        }
        Ok(())
    })
    .map_err(error)
}

fn define_observer<M: Module>(
    program: &FusedProgram,
    module: &mut M,
    output: &str,
) -> Result<FuncId, String> {
    let values = &program
        .outputs
        .get(output)
        .ok_or_else(|| format!("unknown output: {output}"))?
        .values;
    let pointer = module.target_config().pointer_type();
    let mut signature = module.make_signature();
    signature
        .params
        .extend([AbiParam::new(pointer), AbiParam::new(pointer)]);
    let function = module
        .declare_function("mech_observe", Linkage::Export, &signature)
        .map_err(error)?;
    let mut pow_signature = module.make_signature();
    pow_signature
        .params
        .extend([AbiParam::new(types::F64), AbiParam::new(types::F64)]);
    pow_signature.returns.push(AbiParam::new(types::F64));
    let pow = module
        .declare_function("mech_fused_pow", Linkage::Import, &pow_signature)
        .map_err(error)?;
    let mut context = module.make_context();
    context.func.signature = signature;
    let mut function_context = FunctionBuilderContext::new();
    {
        let mut builder = FunctionBuilder::new(&mut context.func, &mut function_context);
        let entry = builder.create_block();
        builder.append_block_params_for_function_params(entry);
        builder.switch_to_block(entry);
        let state = builder.block_params(entry)[0];
        let output = builder.block_params(entry)[1];
        let pow_ref = module.declare_func_in_func(pow, builder.func);
        let mut registers = (0..program.initial.len())
            .map(|i| {
                builder
                    .ins()
                    .load(types::F64, MemFlags::new(), state, (i * 8) as i32)
            })
            .collect::<Vec<_>>();
        let live = program.live_instructions(values);
        for (index, instruction) in program.instructions.iter().enumerate() {
            if !live.contains(&index) {
                registers.push(builder.ins().f64const(0.0));
                continue;
            }
            let inputs = instruction
                .inputs
                .iter()
                .map(|x| value(*x, &registers, &mut builder))
                .collect::<Vec<_>>();
            registers.push(arithmetic(instruction.op, &inputs, &mut builder, pow_ref));
        }
        for (i, operand) in values.iter().enumerate() {
            let scalar = value(*operand, &registers, &mut builder);
            builder
                .ins()
                .store(MemFlags::new(), scalar, output, (i * 8) as i32);
        }
        builder.ins().return_(&[]);
        builder.seal_all_blocks();
        builder.finalize();
    }
    module
        .define_function(function, &mut context)
        .map_err(|error| format!("{error:?}"))?;
    Ok(function)
}

fn define_program<M: Module>(
    program: &FusedProgram,
    module: &mut M,
    simd: bool,
) -> Result<FuncId, String> {
    let pointer = module.target_config().pointer_type();
    let mut signature = module.make_signature();
    signature
        .params
        .extend([AbiParam::new(pointer), AbiParam::new(pointer)]);
    let function = module
        .declare_function("mech_turns", Linkage::Export, &signature)
        .map_err(error)?;
    let mut pow_signature = module.make_signature();
    pow_signature
        .params
        .extend([AbiParam::new(types::F64), AbiParam::new(types::F64)]);
    pow_signature.returns.push(AbiParam::new(types::F64));
    let pow = module
        .declare_function("mech_fused_pow", Linkage::Import, &pow_signature)
        .map_err(error)?;
    let mut context = module.make_context();
    context.func.signature = signature;
    let mut function_context = FunctionBuilderContext::new();
    {
        let mut builder = FunctionBuilder::new(&mut context.func, &mut function_context);
        let entry = builder.create_block();
        let header = builder.create_block();
        let body = builder.create_block();
        let exit = builder.create_block();
        builder.append_block_params_for_function_params(entry);
        builder.append_block_param(header, pointer);
        let state_groups = if simd {
            program
                .states
                .iter()
                .zip(&program.state_shapes)
                .flat_map(|((_, offset, _), (rows, columns))| {
                    element_groups(*rows, *columns)
                        .into_iter()
                        .flat_map(move |group| {
                            group
                                .chunks(2)
                                .map(|chunk| chunk.iter().map(|i| offset + i).collect::<Vec<_>>())
                                .collect::<Vec<_>>()
                        })
                })
                .collect::<Vec<_>>()
        } else {
            (0..program.initial.len()).map(|i| vec![i]).collect()
        };
        for chunk in &state_groups {
            builder.append_block_param(
                header,
                if chunk.len() == 2 {
                    types::F64X2
                } else {
                    types::F64
                },
            );
        }
        builder.switch_to_block(entry);
        let state = builder.block_params(entry)[0];
        let turns = builder.block_params(entry)[1];
        let mut initial = vec![turns];
        for chunk in &state_groups {
            let a = builder
                .ins()
                .load(types::F64, MemFlags::new(), state, (chunk[0] * 8) as i32);
            initial.push(if chunk.len() == 2 {
                let b =
                    builder
                        .ins()
                        .load(types::F64, MemFlags::new(), state, (chunk[1] * 8) as i32);
                let vector = builder.ins().scalar_to_vector(types::F64X2, a);
                builder.ins().insertlane(vector, b, 1)
            } else {
                a
            });
        }
        builder.ins().jump(
            header,
            &initial.iter().copied().map(Into::into).collect::<Vec<_>>(),
        );
        builder.seal_block(entry);
        builder.switch_to_block(header);
        let remaining = builder.block_params(header)[0];
        let states = builder.block_params(header)[1..].to_vec();
        let done = builder.ins().icmp_imm(IntCC::Equal, remaining, 0);
        builder.ins().brif(done, exit, &[], body, &[]);
        builder.switch_to_block(body);
        builder.seal_block(body);
        let pow_ref = module.declare_func_in_func(pow, builder.func);
        let mut registers = vec![remaining; program.initial.len()];
        let mut packed = BTreeMap::new();
        let mut origins = BTreeMap::new();
        for (state, chunk) in states.iter().zip(&state_groups) {
            if chunk.len() == 2 {
                registers[chunk[0]] = builder.ins().extractlane(*state, 0);
                registers[chunk[1]] = builder.ins().extractlane(*state, 1);
                origins.insert(chunk[0], (*state, 0));
                origins.insert(chunk[1], (*state, 1));
                packed.insert(
                    (
                        operand_key(Operand::Register(chunk[0])),
                        operand_key(Operand::Register(chunk[1])),
                    ),
                    *state,
                );
            } else {
                registers[chunk[0]] = *state;
            }
        }
        let zero = builder.ins().f64const(0.0);
        registers.resize(program.initial.len() + program.instructions.len(), zero);
        let roots = state_groups
            .iter()
            .flatten()
            .map(|i| program.updates[*i])
            .collect::<Vec<_>>();
        let order = program.instruction_order(&roots, simd);
        let mut cursor = 0;
        while cursor < order.len() {
            let index = order[cursor];
            let instruction = &program.instructions[index];
            if simd
                && program.simd_pairs.contains(&index)
                && order.get(cursor + 1) == Some(&(index + 1))
                && instruction.op != Op::Pow
                && let Some(second) = program.instructions.get(index + 1)
                && instruction.op == second.op
                && !second
                    .inputs
                    .iter()
                    .any(|x| matches!(x, Operand::Register(r) if *r == program.initial.len()+index))
            {
                let inputs = instruction
                    .inputs
                    .iter()
                    .zip(&second.inputs)
                    .map(|(a, b)| {
                        packed_pair(*a, *b, &registers, &mut packed, &origins, &mut builder)
                    })
                    .collect::<Vec<_>>();
                let vector = arithmetic(instruction.op, &inputs, &mut builder, pow_ref);
                let first_index = program.initial.len() + index;
                registers[first_index] = builder.ins().extractlane(vector, 0);
                registers[first_index + 1] = builder.ins().extractlane(vector, 1);
                origins.insert(first_index, (vector, 0));
                origins.insert(first_index + 1, (vector, 1));
                packed.insert(
                    (
                        operand_key(Operand::Register(first_index)),
                        operand_key(Operand::Register(first_index + 1)),
                    ),
                    vector,
                );
                cursor += 2;
                continue;
            }
            let inputs = instruction
                .inputs
                .iter()
                .map(|operand| value(*operand, &registers, &mut builder))
                .collect::<Vec<_>>();
            let result = arithmetic(instruction.op, &inputs, &mut builder, pow_ref);
            registers[program.initial.len() + index] = result;
            cursor += 1;
        }
        let next_turns = builder.ins().iadd_imm(remaining, -1);
        let mut next = vec![next_turns];
        for chunk in &state_groups {
            next.push(if chunk.len() == 2 {
                packed_pair(
                    program.updates[chunk[0]],
                    program.updates[chunk[1]],
                    &registers,
                    &mut packed,
                    &origins,
                    &mut builder,
                )
            } else {
                value(program.updates[chunk[0]], &registers, &mut builder)
            });
        }
        builder.ins().jump(
            header,
            &next.iter().copied().map(Into::into).collect::<Vec<_>>(),
        );
        builder.seal_block(header);
        builder.switch_to_block(exit);
        builder.seal_block(exit);
        for (value, chunk) in states.iter().zip(&state_groups) {
            for (lane, index) in chunk.iter().enumerate() {
                let scalar = if chunk.len() == 2 {
                    builder.ins().extractlane(*value, lane as u8)
                } else {
                    *value
                };
                builder
                    .ins()
                    .store(MemFlags::new(), scalar, state, (index * 8) as i32);
            }
        }
        builder.ins().return_(&[]);
        builder.finalize();
    }
    module
        .define_function(function, &mut context)
        .map_err(|error| format!("{error:?}"))?;
    Ok(function)
}

fn operand_key(operand: Operand) -> (u8, u64) {
    match operand {
        Operand::Constant(x) => (0, x.to_bits()),
        Operand::Register(index) => (1, index as u64),
    }
}

fn arithmetic(
    op: Op,
    inputs: &[Value],
    builder: &mut FunctionBuilder<'_>,
    pow: cranelift_codegen::ir::FuncRef,
) -> Value {
    match op {
        Op::Add => builder.ins().fadd(inputs[0], inputs[1]),
        Op::Sub => builder.ins().fsub(inputs[0], inputs[1]),
        Op::Mul => builder.ins().fmul(inputs[0], inputs[1]),
        Op::Div => builder.ins().fdiv(inputs[0], inputs[1]),
        Op::Neg => builder.ins().fneg(inputs[0]),
        Op::Sqrt => builder.ins().sqrt(inputs[0]),
        Op::InverseCubeSqrt => {
            let root = builder.ins().sqrt(inputs[1]);
            let denominator = builder.ins().fmul(inputs[1], root);
            builder.ins().fdiv(inputs[0], denominator)
        }
        Op::Fma => builder.ins().fma(inputs[0], inputs[1], inputs[2]),
        Op::Fmsub => {
            let negative = builder.ins().fneg(inputs[2]);
            builder.ins().fma(inputs[0], inputs[1], negative)
        }
        Op::Fnmadd => {
            let negative = builder.ins().fneg(inputs[0]);
            builder.ins().fma(negative, inputs[1], inputs[2])
        }
        Op::RefinedInverseCube => {
            let ty = builder.func.dfg.value_type(inputs[1]);
            let vector = ty == types::F64X2;
            let q = inputs[1];
            let narrow = if vector {
                builder.ins().fvdemote(q)
            } else {
                builder.ins().fdemote(types::F32, q)
            };
            let root = builder.ins().sqrt(narrow);
            let one = builder.ins().f32const(1.0);
            let one = if vector {
                builder.ins().splat(types::F32X4, one)
            } else {
                one
            };
            let seed = builder.ins().fdiv(one, root);
            let mut seed = if vector {
                builder.ins().fvpromote_low(seed)
            } else {
                builder.ins().fpromote(types::F64, seed)
            };
            let half = builder.ins().f64const(0.5);
            let three_halves = builder.ins().f64const(1.5);
            let half = if vector {
                builder.ins().splat(ty, half)
            } else {
                half
            };
            let three_halves = if vector {
                builder.ins().splat(ty, three_halves)
            } else {
                three_halves
            };
            let half_q = builder.ins().fmul(half, q);
            for _ in 0..2 {
                let factor = builder.ins().fmul(half_q, seed);
                let factor = builder.ins().fmul(factor, seed);
                let correction = builder.ins().fsub(three_halves, factor);
                seed = builder.ins().fmul(seed, correction);
            }
            let square = builder.ins().fmul(seed, seed);
            let cube = builder.ins().fmul(seed, square);
            builder.ins().fmul(inputs[0], cube)
        }
        Op::Pow => {
            let call = builder.ins().call(pow, inputs);
            builder.inst_results(call)[0]
        }
    }
}
