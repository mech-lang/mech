//! Entry-owned arbitrary-precision cells. Handles are typed by the source IR,
//! checked at the ABI boundary, and cannot be used by independent workers.
use rug::{Assign, Integer, ops::{DivRounding, SubFrom}};
use std::cell::RefCell;

#[derive(Default)]
struct Session {
    values: Vec<Integer>,
    quotient: Integer,
    error: Option<String>,
    power2_shifts: bool,
}
impl Session {
    fn index(&self, handle: u64) -> Result<usize, String> {
        usize::try_from(handle).ok().and_then(|n| n.checked_sub(1))
            .filter(|&n| n < self.values.len()).ok_or_else(|| "invalid big-integer handle".into())
    }
    fn pair(&mut self, dst: usize, src: usize) -> (&mut Integer, &Integer) {
        assert_ne!(dst, src);
        if dst < src {
            let (left, right) = self.values.split_at_mut(src);
            (&mut left[dst], &right[0])
        } else {
            let (left, right) = self.values.split_at_mut(dst);
            (&mut right[0], &left[src])
        }
    }
    fn operation(&mut self, action: u64, a: u64, b: u64, c: u64) -> Result<u64, String> {
        if action == 10 {
            self.values.push(Integer::from(a));
            return Ok(self.values.len() as u64);
        }
        let dst = self.index(a)?;
        let src = self.index(b)?;
        if action == 18 { return Ok(u64::from(self.values[dst] <= self.values[src])); }
        if action == 15 {
            if self.values[src] == 0 { return Err("big-integer division by zero".into()); }
            // Emit a nonaliasing division into the reusable quotient. Copying
            // the numerator first would force GMP's alias-safe temporary path.
            self.quotient.assign((&self.values[dst]).div_floor(&self.values[src]));
            return self.quotient.to_u64().ok_or_else(|| "quotient does not fit u64".into());
        }
        match action {
            11 if dst != src => { let (d, s) = self.pair(dst, src); d.assign(s); }
            11 => {}
            12 if dst == src => {
                if self.power2_shifts && c.is_power_of_two() { self.values[dst] <<= c.trailing_zeros(); }
                else { self.values[dst] *= c; }
            }
            12 => {
                let shift = self.power2_shifts && c.is_power_of_two();
                let (d, s) = self.pair(dst, src);
                if shift { d.assign(s << c.trailing_zeros()); }
                else { d.assign(s * c); }
            }
            13 | 14 => {
                let rhs = self.index(c)?;
                if dst == src && dst == rhs {
                    if action == 13 { self.values[dst] *= 2u32; }
                    else { self.values[dst].assign(0); }
                } else if dst == src {
                    let (d, r) = self.pair(dst, rhs);
                    if action == 13 { *d += r; } else { *d -= r; }
                } else if dst == rhs {
                    let (d, s) = self.pair(dst, src);
                    if action == 13 { *d += s; } else { d.sub_from(s); }
                } else {
                    // Take only the destination so sources stay borrowed and
                    // the destination's limb capacity is reused without copies.
                    let mut d = std::mem::take(&mut self.values[dst]);
                    if action == 13 { d.assign(&self.values[src] + &self.values[rhs]); }
                    else { d.assign(&self.values[src] - &self.values[rhs]); }
                    self.values[dst] = d;
                }
            }
            16 | 17 if dst == src => {
                // Aliasing has ordinary mathematical semantics, including
                // the signed result of x - x*c; no wrapping scalar factor.
                let factor = if action == 16 { Integer::from(c) + 1 }
                    else { Integer::from(1) - c };
                self.values[dst] *= factor;
            }
            16 | 17 => {
                let (d, s) = self.pair(dst, src);
                if action == 16 { *d += s * c; } else { *d -= s * c; }
            }
            _ => return Err("unknown big-integer operation".into()),
        }
        Ok(a)
    }
}
thread_local! { static SESSION: RefCell<Option<Session>> = const { RefCell::new(None) }; }

struct Guard;
impl Drop for Guard {
    fn drop(&mut self) { SESSION.with(|s| { s.borrow_mut().take(); }); }
}
pub(super) fn with_session<T>(run: impl FnOnce() -> T) -> Result<T, String> {
    SESSION.with(|s| {
        let mut s = s.borrow_mut();
        if s.is_some() { return Err("nested big-integer sessions unsupported".to_owned()); }
        *s = Some(Session { power2_shifts: std::env::var("MECH_BIGINT_POWER2_SHIFTS").as_deref() == Ok("1"), ..Session::default() });
        Ok(())
    })?;
    let _guard = Guard;
    let result = run();
    let error = SESSION.with(|s| s.borrow_mut().as_mut().and_then(|s| s.error.take()));
    if let Some(error) = error { Err(error) } else { Ok(result) }
}

/// Apply one typed general arithmetic operation, never a source algorithm.
/// # Safety
/// The admitted same-object call supplies exclusive, initialized u64 output
/// storage that remains live for this synchronous operation and does not escape.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mech_control_bigint(action: u64, a: u64, b: u64, c: u64, output: *mut u64) -> u64 {
    SESSION.with(|s| {
        let mut s = s.borrow_mut();
        let Some(s) = s.as_mut() else { return 10; };
        match s.operation(action, a, b, c) {
            Ok(value) => {
                // SAFETY: the emitter supplies its exclusive live u64 slot.
                unsafe { *output = value; }
                0
            }
            Err(error) => { s.error = Some(error); 10 }
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn signed_arithmetic_aliasing_and_reused_storage() {
        let mut s = Session::default();
        let x = s.operation(10, 7, 0, 0).unwrap();
        let y = s.operation(10, 3, 0, 0).unwrap();
        let z = s.operation(10, 0, 0, 0).unwrap();
        for (op,a,b,c,want) in [(12,z,x,11,77), (13,z,x,y,10), (14,z,y,x,-4),
            (14,y,x,y,4), (16,x,y,5,27), (17,x,x,2,-27), (13,y,y,y,8), (14,y,y,y,0)] {
            s.operation(op,a,b,c).unwrap();
            assert_eq!(s.values[(a-1) as usize], want);
        }
        s.operation(11,z,x,0).unwrap();
        assert_eq!(s.values[(z-1) as usize], -27);
        s.operation(12,z,z,u64::MAX).unwrap();
        assert!(s.values[(z-1) as usize].significant_bits() > 64);
        assert!(s.operation(15,x,y,0).unwrap_err().contains("zero"));
        assert!(s.operation(11,0,x,0).is_err());
        s.power2_shifts = true;
        assert_eq!(s.operation(18,x,y,0).unwrap(),1);
        s.operation(12,z,x,4).unwrap();
        assert_eq!(s.values[(z-1) as usize],-108);
        s.operation(12,z,z,8).unwrap();
        assert_eq!(s.values[(z-1) as usize],-864);
    }
    #[test]
    fn floor_division_and_session_retirement() {
        let mut s = Session::default();
        let a = s.operation(10,7,0,0).unwrap();
        let b = s.operation(10,3,0,0).unwrap();
        assert_eq!(s.operation(15,a,b,0).unwrap(),2);
        s.values[0] = Integer::from(-7);
        s.values[1] = Integer::from(-3);
        assert_eq!(s.operation(15,a,b,0).unwrap(),2);
        s.values[1] = Integer::from(3);
        assert!(s.operation(15,a,b,0).is_err());
        assert_eq!(s.quotient,-3);
        for _ in 0..2 { with_session(|| {
            SESSION.with(|s| assert!(s.borrow().as_ref().unwrap().values.is_empty()));
            assert!(with_session(|| ()).is_err());
        }).unwrap(); }
        assert!(SESSION.with(|s| s.borrow().is_none()));
    }
}
